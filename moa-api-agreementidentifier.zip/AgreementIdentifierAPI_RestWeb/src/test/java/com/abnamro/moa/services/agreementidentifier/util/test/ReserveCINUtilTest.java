package com.abnamro.moa.services.agreementidentifier.util.test;

import com.abnamro.moa.services.agreementidentifier.util.exceptions.ContractHeaderServiceInvokerException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Date;

import com.abnamro.moa.services.agreementidentifier.util.ReserveCINUtil;
import com.abnamro.moa.services.agreementidentifier.util.dto.ReserveCINInputDTO;
import com.abnamro.moa.services.agreementidentifier.util.dto.SystemIdentifier;

/**
 * This test class validates input for reserving CIN / agreementID
 * @author c45158
 *
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = ReserveCINUtilTest.class)
public class ReserveCINUtilTest {

	private ReserveCINUtil underTest;

	@Test
	public void testReserveCINWithEmptyInputDetails() throws Exception{
		ReserveCINInputDTO inputDTO = new ReserveCINInputDTO();
		underTest = new ReserveCINUtil();
		try {
			underTest.reserveCIN(null, inputDTO);
			Assertions.fail("ContractHeaderServiceInvokerException expected");
		} catch (ContractHeaderServiceInvokerException exception) {
		}
	}

	@Test
	public void testReserveCINWithNullInput() throws Exception{
		underTest = new ReserveCINUtil();
		try {
			underTest.reserveCIN(null, null);
			Assertions.fail("ContractHeaderServiceInvokerException expected");
		} catch (ContractHeaderServiceInvokerException exception) {
		}
	}

	@Test
	public void testReserveCINWithEmptyContractIdentifierCode() throws Exception{
		ReserveCINInputDTO inputDTO = new ReserveCINInputDTO();
		inputDTO.setCreatedTimestamp(new Date());
		inputDTO.setEmpolyeeIdentifier("1234");
		inputDTO.setProgramIdentifier("CONSER");
		inputDTO.setSystemIdentifier(SystemIdentifier.ONLINE);
		inputDTO.setBoNumber("123456");
		underTest = new ReserveCINUtil();
		try {
			underTest.reserveCIN(null, inputDTO);
			Assertions.fail("ContractHeaderServiceInvokerException expected");
		} catch (ContractHeaderServiceInvokerException exception) {
		}
	}

	@Test
	public void testReserveCINWithEmptyProgramIdCode() throws Exception {
		ReserveCINInputDTO inputDTO = new ReserveCINInputDTO();
		inputDTO.setCreatedTimestamp(new Date());
		inputDTO.setEmpolyeeIdentifier("1234");
		inputDTO.setContractIdentifierCode("209");
		inputDTO.setSystemIdentifier(SystemIdentifier.ONLINE);
		inputDTO.setBoNumber("123456");
		underTest = new ReserveCINUtil();
		try {
			underTest.reserveCIN(null, inputDTO);
			Assertions.fail("ContractHeaderServiceInvokerException expected");
		} catch (ContractHeaderServiceInvokerException exception) {
		}
	}

	@Test
	public void testReserveCINWithEmptySystemIdentifierCode() throws Exception{
		ReserveCINInputDTO inputDTO = new ReserveCINInputDTO();
		inputDTO.setCreatedTimestamp(new Date());
		inputDTO.setEmpolyeeIdentifier("1234");
		inputDTO.setContractIdentifierCode("209");
		inputDTO.setProgramIdentifier("CONSER");
		inputDTO.setBoNumber("123456");
		underTest = new ReserveCINUtil();
		try {
			underTest.reserveCIN(null, inputDTO);
			Assertions.fail("ContractHeaderServiceInvokerException expected");
		} catch (ContractHeaderServiceInvokerException exception) {
		}
	}

	@Test
	public void testReserveCINWithInvalidSystemIdentifierCode() throws Exception{
		ReserveCINInputDTO inputDTO = new ReserveCINInputDTO();
		inputDTO.setCreatedTimestamp(new Date());
		inputDTO.setEmpolyeeIdentifier("1234");
		inputDTO.setContractIdentifierCode("209");
		inputDTO.setProgramIdentifier("CONSER");
		inputDTO.setBoNumber("123456");
		inputDTO.setSystemIdentifier(null);
		underTest = new ReserveCINUtil();
		try {
			underTest.reserveCIN(null, inputDTO);
			Assertions.fail("ContractHeaderServiceInvokerException expected");
		} catch (ContractHeaderServiceInvokerException exception) {
		}
	}

	@Test
	public void testReserveCINWithInvalidLengthBONumber() throws Exception{
		ReserveCINInputDTO inputDTO = new ReserveCINInputDTO();
		inputDTO.setCreatedTimestamp(new Date());
		inputDTO.setEmpolyeeIdentifier("1234");
		inputDTO.setContractIdentifierCode("209");
		inputDTO.setProgramIdentifier("CONSER");
		inputDTO.setBoNumber("1234567");
		inputDTO.setSystemIdentifier(SystemIdentifier.ONLINE);
		underTest = new ReserveCINUtil();
		try {
			underTest.reserveCIN(null, inputDTO);
			Assertions.fail("ContractHeaderServiceInvokerException expected");
		} catch (ContractHeaderServiceInvokerException exception) {
		}
	}

	@Test
	public void testReserveCINWithInvalidLengthContractId() throws Exception{
		ReserveCINInputDTO inputDTO = new ReserveCINInputDTO();
		inputDTO.setCreatedTimestamp(new Date());
		inputDTO.setEmpolyeeIdentifier("1234");
		inputDTO.setContractIdentifierCode("20");
		inputDTO.setProgramIdentifier("CONSER");
		inputDTO.setBoNumber("1234567");
		inputDTO.setSystemIdentifier(SystemIdentifier.ONLINE);
		underTest = new ReserveCINUtil();
		try {
			underTest.reserveCIN(null, inputDTO);
			Assertions.fail("ContractHeaderServiceInvokerException expected");
		} catch (ContractHeaderServiceInvokerException exception) {
		}
	}
}