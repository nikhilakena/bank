package exception;

import com.abnamro.moa.services.agreementidentifier.exception.AgreementIdentifierApplicationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(SpringExtension.class)
public class AgreementIdentifierApplicationExceptionTest {
    @Test
    public void createWithHttpStatus() {
        HttpStatus status = HttpStatus.OK;
        AgreementIdentifierApplicationException exception = new AgreementIdentifierApplicationException((status));

        Assertions.assertEquals(status, exception.getStatus());
        Assertions.assertEquals(null, exception.getMessage());
        Assertions.assertNull(exception.getParams());
    }

    @Test
    public void createWithMessageThrowableAndStatus() {
        String message = "exceptional message";
        HttpStatus status = HttpStatus.OK;
        Throwable throwable = new Throwable(("throwable message"));
        AgreementIdentifierApplicationException exception = new AgreementIdentifierApplicationException(message, throwable, status);

        Assertions.assertEquals(message, exception.getMessage());
        Assertions.assertTrue(throwable.equals(exception.getCause()));
        Assertions.assertEquals(status, exception.getStatus());
        Assertions.assertNull(exception.getParams());
    }

    @Test
    public void createWithMessageAndStatus() {
        String message = "exceptional message";
        HttpStatus status = HttpStatus.OK;
        AgreementIdentifierApplicationException exception = new AgreementIdentifierApplicationException(message, status);

        Assertions.assertEquals(message, exception.getMessage());
        Assertions.assertEquals(status, exception.getStatus());
        Assertions.assertNull(exception.getParams());
    }

    @Test
    public void createWithMessageAndStatusAsInt() {
        String message = "exceptional message";
        int status = 204;
        AgreementIdentifierApplicationException exception = new AgreementIdentifierApplicationException(message, status);

        Assertions.assertEquals(message, exception.getMessage());
        Assertions.assertEquals(HttpStatus.valueOf(status), exception.getStatus());
        Assertions.assertNull(exception.getParams());
    }

    @Test
    public void createWithMessageStatusAndParameters() {
        String message = "exceptional message";
        HttpStatus status = HttpStatus.OK;
        List<String> parameters = new ArrayList<>();
        parameters.add("parameter 1");
        parameters.add(("parameter 2"));
        AgreementIdentifierApplicationException exception = new AgreementIdentifierApplicationException(message, status, parameters);

        Assertions.assertEquals(message, exception.getMessage());
        Assertions.assertEquals(status, exception.getStatus());
        Assertions.assertNotNull(exception.getParams());
        List<String> returnedParameters = exception.getParams();
        Assertions.assertEquals(parameters.size(), returnedParameters.size());
        Assertions.assertEquals("parameter 1", returnedParameters.get(0));
        Assertions.assertEquals("parameter 2", returnedParameters.get(1));
    }
}