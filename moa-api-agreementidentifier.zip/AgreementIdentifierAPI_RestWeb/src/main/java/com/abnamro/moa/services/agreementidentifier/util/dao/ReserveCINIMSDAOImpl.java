package com.abnamro.moa.services.agreementidentifier.util.dao;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;

import com.abnamro.component.transactionconnect.factory.IMSTransactionConnectorFactory;
import com.abnamro.component.transactionconnect.interfaces.IMSTransactionException;
import com.abnamro.component.transactionconnect.interfaces.TransactionConnectorInterface;
import com.abnamro.moa.services.agreementidentifier.util.dao.generated.MO590InputRecord;
import com.abnamro.moa.services.agreementidentifier.util.dao.generated.MO590OutputRecord;
import com.abnamro.moa.services.agreementidentifier.util.dao.generated.MO590OutputRecord_BS_RETURN_CODE_GROUP;
import com.abnamro.moa.services.agreementidentifier.util.dto.InputHeaderDTO;
import com.abnamro.moa.services.agreementidentifier.util.dto.ReserveCINInputDTO;
import com.abnamro.moa.services.agreementidentifier.util.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.nl.dao.util.AbstractIMSDAO;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.messages.Message;
import com.abnamro.nl.messages.MessageKey;
import com.abnamro.nl.messages.MessageType;
import com.abnamro.nl.messages.Messages;

/**
 * This class calls IMS transactions for contract header realted operations.
 * @author c45158
 *
 */
public class ReserveCINIMSDAOImpl extends AbstractIMSDAO {
	private int imsCallAttemptCount = 0;
	private LogHelper logHelper = new LogHelper(ReserveCINIMSDAOImpl.class);
	
	/**
	 * This method reserves CIN(ContractIdentificationNumber) for an agreement of the business contact by calling MO590 service
	 * 
	 * @param inputHeaderDTO generic details which requires for IMS transaction call(MO590)
	 * @param contractHeaderServiceInputDTO contract header related input which requires for IMS transaction call(MO590) 
	 * @return long contract Identification Number
	 * @throws ContractHeaderServiceInvokerException Exception thrown if any issue in processing IMS transaction 
	 */
	public long reserveCIN(InputHeaderDTO inputHeaderDTO, ReserveCINInputDTO contractHeaderServiceInputDTO) throws ContractHeaderServiceInvokerException{

		final String logMethod = "reserveCIN(InputHeaderDTO, contractHeaderServiceInputDTO)";
		
		MO590InputRecord sendRecord = new MO590InputRecord();
		MO590OutputRecord recordReceive;
		String transactionCode = ContractHeaderServiceInvokerConstants.TRANSACTION_CODE_MO590T01;
		
		try {
			sendRecord.setZz_Veld((short) 0);
			sendRecord.setLl_Veld((short) sendRecord.getSize());
			sendRecord.setIms_Transakt_Kode(transactionCode);
			if(inputHeaderDTO != null){
				sendRecord = addDetailsInSendRecord(sendRecord, inputHeaderDTO);
				logHelper.info("reserveCIN: inputHeaderDTO is not null", "inputHeaderDTO-57");
			}
			
			sendRecord = addContractHeaderDetailsInSendRecord(sendRecord, contractHeaderServiceInputDTO);
			TransactionConnectorInterface txnConnectorIfc = IMSTransactionConnectorFactory.newInstance();
			
			logHelper.info("reserveCIN: txnConnectorIfc-63", "txnConnectorIfc-2", "txnConnectorIfc-3");
			logHelper.info("reserveCIN: txnConnectorIfc-64", txnConnectorIfc.toString());
			
			recordReceive = txnConnectorIfc.sendReceive(sendRecord, MO590OutputRecord.class);
			if (recordReceive == null) {
			    logHelper.info("reserveCIN: recordReceive is null", "ReserveCINIMSDAOImpl-67");
			    
				logHelper.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_RSLT_CODE_FAILURE_OR_NO_RESULTS);
				Messages messages = new Messages();
				messages.addMessage(new Message(ContractHeaderServiceInvokerMessageKeys.RSLT_CODE_FAILURE_OR_NO_RESULTS),MessageType.getError());
				throw new ContractHeaderServiceInvokerException(messages);
			} else {
			    logHelper.info("reserveCIN: recordReceive is not null", "ReserveCINIMSDAOImpl-74");
				return populateCIN(recordReceive);
			}
		} catch (IMSTransactionException exception) {
          	logHelper.info("reserveCIN: info-IMSTransactionException - Catch block", "ReserveCINIMSDAOImpl-78");
          	
		    imsCallAttemptCount++;
        	retryIMSCall(inputHeaderDTO,contractHeaderServiceInputDTO);
			logHelper.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_IMS_EXCEPTION_IN_RESERVE_CIN, exception);
			Messages messages = new Messages();
			messages.addMessage(new Message(ContractHeaderServiceInvokerMessageKeys.IMS_EXCEPTION_WHILE_RESERVE_CIN),MessageType.getError());
			throw new ContractHeaderServiceInvokerException(messages);
		}finally{
			logHelper.info(logMethod, transactionCode);
		}
	}
  
   private void retryIMSCall(InputHeaderDTO inputHeaderDTO, ReserveCINInputDTO contractHeaderServiceInputDTO) throws ContractHeaderServiceInvokerException {
	    logHelper.info("reserveCIN: info-retryIMSCall - method", "retry- method arg2", "retry- method arg3", "retry- method arg4");
	    if(imsCallAttemptCount == 1){
	        reserveCIN(inputHeaderDTO,contractHeaderServiceInputDTO);
	    }
    }
	
	/**
	 * @param sendRecord MO590InputRecord
	 * @param contractHeaderServiceInputDTO contract header input details
	 * @return MO590InputRecord MO590 Input Record
	 */
	private MO590InputRecord addContractHeaderDetailsInSendRecord(MO590InputRecord sendRecord,
			ReserveCINInputDTO contractHeaderServiceInputDTO) {
		
		if(contractHeaderServiceInputDTO != null){
			Date createdTimeStamp = new Date();
			if(contractHeaderServiceInputDTO.getCreatedTimestamp() != null){
				createdTimeStamp = contractHeaderServiceInputDTO.getCreatedTimestamp();
			}
			sendRecord.setBron_Ident(contractHeaderServiceInputDTO.getBoNumber());
			sendRecord.setSoort_Bron(contractHeaderServiceInputDTO.getSystemIdentifier().getValue());
			sendRecord.setMedewerker_Ident(contractHeaderServiceInputDTO.getEmpolyeeIdentifier());
			sendRecord.setProgramma_Naam(contractHeaderServiceInputDTO.getProgramIdentifier());
			sendRecord.setKontraktsoort_Kode(contractHeaderServiceInputDTO.getContractIdentifierCode());
			if(createdTimeStamp != null){
				// set dae & timestamp
				// Format: numeric (YYDDDHHMMSST) 
				//	YY= year (2 digits)
				//	DDD = number of the day in a year (julian date)
				//	HH = hour
				//	MM = minutes
				//	SS = seconds
				//	T = tenth of a second.
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ContractHeaderServiceInvokerConstants.CREATION_DATE_FORMAT, Locale.ENGLISH);
				String dateAsString = simpleDateFormat.format(createdTimeStamp);
				if(StringUtils.isNotBlank(dateAsString) && dateAsString.length() == ContractHeaderServiceInvokerConstants.CREATION_DATE_FORMAT_LENGTH){
					sendRecord.setJj(Short.parseShort(dateAsString.substring(0,2)));
					sendRecord.setDdd(Short.parseShort(dateAsString.substring(2,5)));
					sendRecord.setHh(Short.parseShort(dateAsString.substring(5,7)));
					sendRecord.setMm(Short.parseShort(dateAsString.substring(7,9)));
					sendRecord.setSs(Short.parseShort(dateAsString.substring(9,11)));
					sendRecord.setT((short)0);
				}
			}
		}
		return sendRecord;
	}

	/**
	 * This method adds the details in transaction input message based on input headerDTO
	 * 
	 * @param sendRecord MEINPUTMSG
	 * @param inputHeaderDTO InputHeaderDTO
	 * @return MO590InputRecord MO590 Input Record
	 */
	private MO590InputRecord addDetailsInSendRecord(MO590InputRecord sendRecord,InputHeaderDTO inputHeaderDTO) {
		
			if (inputHeaderDTO.getApplicationId() != null) {
				sendRecord.setBs_Application_Id(inputHeaderDTO.getApplicationId().trim());
			}
			if (inputHeaderDTO.getChannelId() != null) {
				sendRecord.setBs_Channel_Id(inputHeaderDTO.getChannelId().trim());
			}
			if (inputHeaderDTO.getIssueId() != null) {
				sendRecord.setBs_Issue_Id(inputHeaderDTO.getIssueId().trim());
			}
			if (inputHeaderDTO.getLanguageCode() != null) {
				sendRecord.setBs_Language_Code(inputHeaderDTO.getLanguageCode().trim());
			}
			if (inputHeaderDTO.getLanguageCountryCode() != null) {
				sendRecord.setBs_Language_Country_Code(inputHeaderDTO.getLanguageCountryCode().trim());
			}
			if (inputHeaderDTO.getProcessId() != null) {
				sendRecord.setBs_Process_Id(inputHeaderDTO.getProcessId().trim());
			}
			if (inputHeaderDTO.getReserved() != null) {
				sendRecord.setBs_Reserved(inputHeaderDTO.getReserved().trim());
			}
			if (inputHeaderDTO.getSessionId() != null) {
				sendRecord.setBs_Session_Id(inputHeaderDTO.getSessionId().trim());
			}
			if (inputHeaderDTO.getUserId() != null) {
				sendRecord.setBs_Userid(inputHeaderDTO.getUserId().trim());
			}
		
		return sendRecord;
	}

	
	private long populateCIN(MO590OutputRecord recordReceive) throws ContractHeaderServiceInvokerException {
		String logMethod = "populateCIN(recordReceive)";
		String resultaatCode = null;
		long cin = 0;
		if(StringUtils.isNotBlank(recordReceive.getBs_Result_Code())){
			resultaatCode = recordReceive.getBs_Result_Code().trim();
		}
		MO590OutputRecord_BS_RETURN_CODE_GROUP[] returnCodeGroup = recordReceive.getBs_Return_Code_Group();
		 
		boolean noErrors = (ContractHeaderServiceInvokerConstants.STRING_ZERO).equals(resultaatCode)
							|| (ContractHeaderServiceInvokerConstants.STRING_ONE).equals(resultaatCode);

		if (!noErrors) {
			Messages myMessages = new Messages();
			logHelper.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_RSLT_CODE_FAILURE);
			for (int i = 0; i < returnCodeGroup.length; i++) {
					MessageKey messageKey = new MessageKey("MESSAGE_RESCIN_FAIL_" + returnCodeGroup[i].getBs_Return_Code());
					logHelper.error(logMethod, "Error code is ".concat(returnCodeGroup[i].getBs_Return_Code()).concat(" and error message is ").concat(returnCodeGroup[i].getBs_Return_Message()));
					myMessages.addMessage(new Message(messageKey),MessageType.getError());
			}
			throw new ContractHeaderServiceInvokerException(myMessages);
		} 
		cin = recordReceive.getKontraktnummer();
		return cin;
	}

}
