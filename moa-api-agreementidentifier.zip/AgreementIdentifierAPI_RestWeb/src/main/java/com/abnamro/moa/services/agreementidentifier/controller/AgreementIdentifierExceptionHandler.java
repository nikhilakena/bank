package com.abnamro.moa.services.agreementidentifier.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.abnamro.moa.services.agreementidentifier.configuration.RequestScopeBeans;
import com.abnamro.moa.services.agreementidentifier.constants.AgreementIdentifierConstants;
import com.abnamro.moa.services.agreementidentifier.exception.AgreementIdentifierApplicationException;
import com.abnamro.moa.services.agreementidentifier.resourcemodel.Error;
import com.abnamro.moa.services.agreementidentifier.resourcemodel.Errors;


/**
 * This is the exception handler class for the agreement identifier API
 */
@Configuration
@PropertySource("classpath:errormessage.properties")

@ControllerAdvice
@RestController
public class AgreementIdentifierExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger loggerFactoryLogger = LoggerFactory.getLogger(AgreementIdentifierExceptionHandler.class);

    @Autowired
    private Environment env;
    
	@Autowired
	private RequestScopeBeans requestScopeBeans;

    /**
     * This is the the method which will be called in case MethodArgumentNotValidException is thrown from application.
     *
     * @param ex MethodArgumentNotValidException this will thrown in case validation mentioned on the rest service input is failed
     * @param headers http headers
     * @param status https status
     * @param request WebRequest
     * @return response entity containg error details
     */
    @Override
    public final ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException  ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        loggerFactoryLogger.error("LOG_AIAPI_007:handleMethodArgumentNotValid",ex);
        Errors errorDetails = new Errors();
        List<Error> errors = new ArrayList<>();
        if(ex!= null && !ex.getBindingResult().getAllErrors().isEmpty()){
            for(ObjectError objectError:ex.getBindingResult().getAllErrors()) {
            	
                String messageId = objectError.getDefaultMessage();
                errors.add(populateErrorDetails(messageId,HttpStatus.BAD_REQUEST,null));
            }
        }else {
            errors.add( populateErrorDetails(null,HttpStatus.BAD_REQUEST,null));
        }
        
        errorDetails.setErrors(errors);
        return new ResponseEntity<Object>(errorDetails, HttpStatus.BAD_REQUEST);
    }

    /**
     * This is the the method which will be called in case HttpMessageNotReadableException is thrown from application.
     * @param ex HttpMessageNotReadableException this will thrown in case input Json format is not valid i.e invalid Enum or date
     * @param headers http headers
     * @param status https status
     * @param request WebRequest
     * @return response entity containg error details
     */
    @Override
    public final ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        loggerFactoryLogger.error("LOG_AIAPI_008:handleHttpMessageNotReadable",ex);
        Errors errorDetails = new Errors();
        List<Error> errors = new ArrayList<>();
        Error error = new Error();
        error.setMessage(ex.getMessage());
        error.setCode("JSON_PARSE_ERROR");
        error.setStatus(HttpStatus.BAD_REQUEST.toString());
        errors.add(error);
        errorDetails.setErrors(errors);
        return new ResponseEntity<Object>(errorDetails, HttpStatus.BAD_REQUEST);
    }

   
    /**
     * This is the the method which will be called in case AgreementIdentifierApplicationException is thrown from application.
     * @param ex AgreementIdentifierApplicationException this will thrown in case customised validation or exception
     * @return response entity containing error details
     */
    @ExceptionHandler(AgreementIdentifierApplicationException.class)
    public final ResponseEntity<Errors> handleAgreementIdentifierException(AgreementIdentifierApplicationException ex) {
        loggerFactoryLogger.info("handleAgreementCustomerReferenceException",ex);
        Errors errorDetails = new Errors();
        List<Error> errors = new ArrayList<>();
        errors.add( populateErrorDetails(ex.getMessage(),ex.getStatus(), ex.getParams()));
        errorDetails.setErrors(errors);
        return new ResponseEntity<>(errorDetails, ex.getStatus());
    }

    /**
     * This is the the method which will be called in case AgreementIdentifierApplicationException is thrown from application.
     * @param ex AgreementIdentifierApplicationException this will thrown in case customised validation or exception
     * @param request WebRequest
     * @return response entity containing error details
     */
    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Errors> handleGeneralException(Exception ex, WebRequest request){
        loggerFactoryLogger.error("LOG_AIAPI_009:handleGeneralException",ex);
        Errors errorDetails = new Errors();
        List<Error> errors = new ArrayList<>();
        errors.add( populateErrorDetails(null,HttpStatus.INTERNAL_SERVER_ERROR,null));
        errorDetails.setErrors(errors);
        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }


    private Error populateErrorDetails(String messageId, HttpStatus httpStatus, List<String> params) {
        Error error = new Error();
        if(messageId==null || env.getProperty(messageId+ AgreementIdentifierConstants.CODE_LABEL)== null) {
            messageId= String.valueOf(httpStatus.value());
        }
        error.setCode(env.getProperty(messageId + AgreementIdentifierConstants.CODE_LABEL));
        error.setMessage(env.getProperty(messageId + AgreementIdentifierConstants.MESSAGE_LABEL));
        error.setStatus(String.valueOf(httpStatus.value()));
        error.setTraceId(requestScopeBeans.getTraceId());
        return error;
    }
}
