package com.abnamro.moa.services.agreementidentifier.util.dao.generated;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;

import com.ibm.etools.marshall.util.*;

/**
 * @generated
 * Generated Class: MO590OutputRecord
 * @type-descriptor.aggregate-instance-td accessor="readWrite" contentSize="461" offset="0" size="461"
 * @type-descriptor.platform-compiler-info language="COBOL" defaultBigEndian="true" defaultCodepage="ibm-037" defaultExternalDecimalSign="ebcdic" defaultFloatType="ibm390Hex"
 * @type-descriptor.child-class class-name="com.abnamro.generated.MO590OutputRecord_BS_RETURN_CODE_GROUP"
 */

public class MO590OutputRecord implements javax.resource.cci.Record,
		javax.resource.cci.Streamable, com.ibm.etools.marshall.RecordBytes {
	private static final long serialVersionUID = -4178075056106879797L;
	/**
	 * @generated
	 */
	private byte[] buffer_ = null;
	/**
	 * @generated
	 */
	private static final int bufferSize_;
	/**
	 * @generated
	 */
	private static final byte[] initializedBuffer_;
	/**
	 * @generated
	 */
	private static java.util.HashMap getterMap_ = null;
	/**
	 * @generated
	 */
	private java.util.HashMap valFieldNameMap_ = null;

	/**
	 * initializer
	 * @generated
	 */
	static {
		bufferSize_ = 461;
		initializedBuffer_ = new byte[bufferSize_];
		String bs_Application_IdInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_Application_IdInitialValue, initializedBuffer_, 13,
				"ibm-037", 8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		short zz_VeldInitialValue = (short) +0;
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(
				zz_VeldInitialValue, initializedBuffer_, 2, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		MO590OutputRecord_BS_RETURN_CODE_GROUP bs_Return_Code_Group = new MO590OutputRecord_BS_RETURN_CODE_GROUP();
		byte[] bs_Return_Code_GroupBytes = bs_Return_Code_Group.getBytes();
		for (int index1 = 0; index1 < 5; index1++) {
			int bytesToCopy = bs_Return_Code_GroupBytes.length;
			System.arraycopy(bs_Return_Code_GroupBytes, 0, initializedBuffer_,
					21 + (86 * index1), bytesToCopy);
		}
		String ims_Transakt_KodeInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				ims_Transakt_KodeInitialValue, initializedBuffer_, 4,
				"ibm-037", 8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String bs_Result_CodeInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_Result_CodeInitialValue, initializedBuffer_, 12, "ibm-037",
				1, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
	}

	/**
	 * constructor
	 * @generated
	 */
	public MO590OutputRecord() {
		initialize();
	}

	/**
	 * constructor
	 * @generated
	 */
	public MO590OutputRecord(java.util.HashMap valFieldNameMap) {
		valFieldNameMap_ = valFieldNameMap;
		initialize();
	}

	/**
	 * @generated
	 * initialize
	 */
	public void initialize() {
		buffer_ = new byte[bufferSize_];
		System.arraycopy(initializedBuffer_, 0, buffer_, 0, bufferSize_);
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Streamable#read(java.io.InputStream)
	 */
	public void read(java.io.InputStream inputStream)
			throws java.io.IOException {
		byte[] input = new byte[inputStream.available()];
		inputStream.read(input);
		buffer_ = input;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Streamable#write(java.io.OutputStream)
	 */
	public void write(java.io.OutputStream outputStream)
			throws java.io.IOException {
		outputStream.write(buffer_, 0, getSize());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#getRecordName()
	 */
	public String getRecordName() {
		return (this.getClass().getName());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#setRecordName(String)
	 */
	public void setRecordName(String recordName) {
		return;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#setRecordShortDescription(String)
	 */
	public void setRecordShortDescription(String shortDescription) {
		return;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#getRecordShortDescription()
	 */
	public String getRecordShortDescription() {
		return (this.getClass().getName());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#clone()
	 */
	public Object clone() throws CloneNotSupportedException {
		return (super.clone());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#equals
	 */
	public boolean equals(Object object) {
		return (super.equals(object));
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#hashCode
	 */
	public int hashCode() {
		return (super.hashCode());
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#getBytes
	 */
	public byte[] getBytes() {
		return (buffer_);
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#setBytes
	 */
	public void setBytes(byte[] bytes) {
		if ((bytes != null) && (bytes.length != 0))
			buffer_ = bytes;
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#getSize
	 */
	public int getSize() {
		return (461);
	}

	/**
	 * @generated
	 */
	public boolean match(Object obj) {
		if (obj == null)
			return (false);
		if (obj.getClass().isArray()) {
			byte[] currBytes = buffer_;
			try {
				byte[] objByteArray = (byte[]) obj;
				if (objByteArray.length != buffer_.length)
					return (false);
				buffer_ = objByteArray;
			} catch (ClassCastException exc) {
				return (false);
			} finally {
				buffer_ = currBytes;
			}
		} else
			return (false);
		return (true);
	}

	/**
	 * @generated
	 */
	public void populate(Object obj) {
		if (obj.getClass().isArray()) {
			try {
				buffer_ = (byte[]) obj;
			} catch (ClassCastException exc) {
			}
		}
	}

	/**
	 * @generated
	 * @see java.lang.Object#toString
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer(super.toString());
		sb.append("\n");
		ConversionUtils.dumpBytes(sb, buffer_);
		return (sb.toString());
	}

	/**
	 * @generated
	 * wrappedGetNumber
	 */
	public Number wrappedGetNumber(String propertyName) {
		Number result = null;

		if (getterMap_ == null) {
			synchronized (initializedBuffer_) {
				if (getterMap_ == null) {
					java.util.HashMap getterMap = new java.util.HashMap();
					try {
						BeanInfo info = Introspector.getBeanInfo(this
								.getClass());
						PropertyDescriptor[] props = info
								.getPropertyDescriptors();

						for (int i = 0; i < props.length; i++) {
							String propName = props[i].getName();
							getterMap.put(propName, props[i].getReadMethod());
						}
					} catch (IntrospectionException exc) {
					}
					getterMap_ = getterMap;
				}
			}
		}

		Method method = (Method) getterMap_.get(propertyName);
		if (method != null) {
			try {
				result = (Number) method.invoke(this, new Object[0]);
			} catch (Exception exc) {
			}
		}

		return (result);
	}

	/**
	 * @generated
	 * evaluateMap
	 */
	public java.util.HashMap evaluateMap(java.util.HashMap valFieldNameMap) {
		if (valFieldNameMap == null)
			return (null);
		java.util.HashMap returnMap = new java.util.HashMap(
				valFieldNameMap.size());
		java.util.Set aSet = valFieldNameMap.entrySet();

		for (java.util.Iterator cursor = aSet.iterator(); cursor.hasNext();) {
			java.util.Map.Entry element = (java.util.Map.Entry) cursor.next();
			String key = (String) element.getKey();
			String fieldName = (String) element.getValue();
			Number fieldValue = wrappedGetNumber(fieldName);
			if (fieldValue == null)
				fieldValue = new Integer(0);
			returnMap.put(key, fieldValue);
		}

		return (returnMap);
	}

	/**
	 * @generated
	 * Returns the integer value of the formula string for an offset or size.
	 * The formula can be comprised of the following functions:
	 * neg(x)   := -x       // prefix negate
	 * add(x,y) := x+y      // infix add
	 * sub(x,y) := x-y      // infix subtract
	 * mpy(x,y) := x*y      // infix multiply
	 * div(x,y) := x/y      // infix divide
	 * max(x,y) := max(x,y)
	 * min(x,y) := min(x,y)
	 *
	 * mod(x,y) := x mod y
	 *
	 * The mod function is defined as mod(x,y) = r where r is the smallest non-negative integer
	 * such that x-r is evenly divisible by y. So mod(7,4) is 3, but mod(-7,4) is 1. If y is a
	 * power of 2, then mod(x,y) is equal to the bitwise-and of x and y-1.
	 *
	 * val(1, m, n, o,..)
	 *
	 * The val function returns the value of a field in the model. The val function takes one
	 * or more arguments, and the first argument refers to a level-1 field in the type model and must be either:
	 *    - the name of a level-1 field described in the language model
	 *    - the integer 1 (indicating that the level-1 parent of the current structure is meant)
	 * If the first argument to the val function is the integer 1, then and only then are subsequent arguments
	 * permitted. These subsequent arguments are integers that the specify the ordinal number within its
	 * substructure of the subfield that should be dereferenced.
	 *
	 * @return The integer value of the formula string for an offset or size.
	 * @param formula The formula to be evaluated.
	 * @param valFieldNameMap A map of val() formulas to field names.
	 * @throws IllegalArgumentException if the formula is null.
	 */

	public int evaluateFormula(String formula, java.util.HashMap valFieldNameMap)
			throws IllegalArgumentException {
		if (formula == null)
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.MARSHRT_FORMULA_NULL));

		int result = 0;

		int index = formula.indexOf("(");

		if (index == -1) // It's a number not an expression
		{
			try {
				result = Integer.parseInt(formula);
			} catch (Exception exc) {
			}

			return (result);
		}

		// Determine the outermost function
		String function = formula.substring(0, index);

		if (function.equalsIgnoreCase("val")) {
			Object field = valFieldNameMap.get(formula);
			if (field == null)
				return (0);

			if (field instanceof String) {
				Number num = wrappedGetNumber((String) field);
				if (num == null) // Element does not exist
					return (0);
				result = num.intValue();
			} else if (field instanceof Number)
				result = ((Number) field).intValue();
			else
				return (0);

			return (result);
		} else if (function.equalsIgnoreCase("neg")) {
			// The new formula is the content between the brackets
			formula = formula.substring(index + 1, formula.length() - 1);
			result = -1 * evaluateFormula(formula, valFieldNameMap);
			return (result);
		} else {
			// Get the contents between the outermost brackets
			formula = formula.substring(index + 1, formula.length() - 1);
			char[] formulaChars = formula.toCharArray();

			// Get the left side and the right side of the operation

			int brackets = 0;
			int i = 0;

			for (; i < formulaChars.length; i++) {
				if (formulaChars[i] == '(')
					brackets++;
				else if (formulaChars[i] == ')')
					brackets--;
				else if (formulaChars[i] == ',') {
					if (brackets == 0)
						break;
				}
			}

			String leftSide = "0";
			String rightSide = "0";

			leftSide = formula.substring(0, i);
			rightSide = formula.substring(i + 1);

			if (function.equalsIgnoreCase("add"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						+ evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("mpy"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						* evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("sub"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						- evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("div"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						/ evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("max"))
				result = Math.max(evaluateFormula(leftSide, valFieldNameMap),
						evaluateFormula(rightSide, valFieldNameMap));
			else if (function.equalsIgnoreCase("min"))
				result = Math.min(evaluateFormula(leftSide, valFieldNameMap),
						evaluateFormula(rightSide, valFieldNameMap));
			else if (function.equalsIgnoreCase("mod"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						% evaluateFormula(rightSide, valFieldNameMap);
		}

		return (result);
	}

	/**
	 * @generated
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="0" size="2"
	 * @type-descriptor.integer-td signCoding="twosComplement"
	 */
	public short getLl_Veld() {
		short ll_Veld = 0;
		ll_Veld = MarshallIntegerUtils.unmarshallTwoByteIntegerFromBuffer(
				buffer_, 0, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		return (ll_Veld);
	}

	/**
	 * @generated
	 */
	public void setLl_Veld(short ll_Veld) {
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(ll_Veld, buffer_,
				0, true, MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
	}

	/**
	 * @generated
	 * @type-descriptor.initial-value kind="string_value" value="+0"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="2" size="2"
	 * @type-descriptor.integer-td signCoding="twosComplement"
	 */
	public short getZz_Veld() {
		short zz_Veld = 0;
		zz_Veld = MarshallIntegerUtils.unmarshallTwoByteIntegerFromBuffer(
				buffer_, 2, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		return (zz_Veld);
	}

	/**
	 * @generated
	 */
	public void setZz_Veld(short zz_Veld) {
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(zz_Veld, buffer_,
				2, true, MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="4" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getIms_Transakt_Kode() {
		String ims_Transakt_Kode = null;
		ims_Transakt_Kode = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 4, "ibm-037", 8);
		return (ims_Transakt_Kode);
	}

	/**
	 * @generated
	 */
	public void setIms_Transakt_Kode(String ims_Transakt_Kode) {
		if (ims_Transakt_Kode != null) {
			if (ims_Transakt_Kode.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								ims_Transakt_Kode, "8", "ims_Transakt_Kode"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					ims_Transakt_Kode, buffer_, 4, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="1"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="1" offset="12" size="1"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Result_Code() {
		String bs_Result_Code = null;
		bs_Result_Code = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 12, "ibm-037",
						1);
		return (bs_Result_Code);
	}

	/**
	 * @generated
	 */
	public void setBs_Result_Code(String bs_Result_Code) {
		if (bs_Result_Code != null) {
			if (bs_Result_Code.length() > 1)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, bs_Result_Code,
								"1", "bs_Result_Code"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					bs_Result_Code, buffer_, 12, "ibm-037", 1,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="13" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Application_Id() {
		String bs_Application_Id = null;
		bs_Application_Id = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 13, "ibm-037",
						8);
		return (bs_Application_Id);
	}

	/**
	 * @generated
	 */
	public void setBs_Application_Id(String bs_Application_Id) {
		if (bs_Application_Id != null) {
			if (bs_Application_Id.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								bs_Application_Id, "8", "bs_Application_Id"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					bs_Application_Id, buffer_, 13, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.aggregate-instance-td-method accessor="readWrite" contentSize="430" offset="21" size="430"
	 * @type-descriptor.array-td lowerBound="5" stride="86" upperBound="5"
	 */
	public MO590OutputRecord_BS_RETURN_CODE_GROUP[] getBs_Return_Code_Group() {
		int baseOffset = 21;
		int stride = 86;
		int upperBound = 5;
		MO590OutputRecord_BS_RETURN_CODE_GROUP[] bs_Return_Code_Group = new MO590OutputRecord_BS_RETURN_CODE_GROUP[upperBound];
		java.util.HashMap evaluatedMap = evaluateMap(valFieldNameMap_);
		for (int i = 0; i < upperBound; i++) {
			int offset = baseOffset + (stride * i);
			int bytesToCopy = stride;
			byte[] subBuffer = new byte[stride];
			System.arraycopy(buffer_, offset, subBuffer, 0, bytesToCopy);
			MO590OutputRecord_BS_RETURN_CODE_GROUP subRecord = new MO590OutputRecord_BS_RETURN_CODE_GROUP(
					evaluatedMap);
			subRecord.setBytes(subBuffer);
			bs_Return_Code_Group[i] = subRecord;
		}
		return (bs_Return_Code_Group);
	}

	/**
	 * @generated
	 */
	public void setBs_Return_Code_Group(
			MO590OutputRecord_BS_RETURN_CODE_GROUP[] bs_Return_Code_Group) {
		int baseOffset = 21;
		int stride = 86;
		int upperBound = 5;
		if (bs_Return_Code_Group != null) {
			if (bs_Return_Code_Group.length < 5)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0122E,
								"bs_Return_Code_Group", "5"));
			if (bs_Return_Code_Group.length > upperBound)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0123E,
								"bs_Return_Code_Group",
								Integer.toString(upperBound)));
			int numElems = Math.min(bs_Return_Code_Group.length, upperBound);
			for (int i = 0; i < numElems; i++) {
				if (bs_Return_Code_Group[i] == null)
					continue;
				int offset = baseOffset + (stride * i);
				byte[] subBuffer = bs_Return_Code_Group[i].getBytes();
				int bytesToCopy = subBuffer.length;
				System.arraycopy(subBuffer, 0, buffer_, offset, bytesToCopy);
			}
		}
	}

	/**
	 * @generated
	 */
	public MO590OutputRecord_BS_RETURN_CODE_GROUP getBs_Return_Code_Group(
			int index) {
		int upperBound = 5;
		if ((index < 0) || (index > upperBound - 1))
			throw new ArrayIndexOutOfBoundsException(index);
		int baseOffset = 21;
		int stride = 86;
		int offset = baseOffset + (stride * index);
		int bytesToCopy = stride;
		byte[] subBuffer = new byte[stride];
		System.arraycopy(buffer_, offset, subBuffer, 0, bytesToCopy);
		MO590OutputRecord_BS_RETURN_CODE_GROUP bs_Return_Code_Group = new MO590OutputRecord_BS_RETURN_CODE_GROUP(
				evaluateMap(valFieldNameMap_));
		bs_Return_Code_Group.setBytes(subBuffer);
		return (bs_Return_Code_Group);
	}

	/**
	 * @generated
	 */
	public void setBs_Return_Code_Group(int index,
			MO590OutputRecord_BS_RETURN_CODE_GROUP bs_Return_Code_Group) {
		int upperBound = 5;
		if ((index < 0) || (index > upperBound - 1))
			throw new ArrayIndexOutOfBoundsException(index);
		int baseOffset = 21;
		int stride = 86;
		int offset = baseOffset + (stride * index);
		byte[] subBuffer = bs_Return_Code_Group.getBytes();
		int bytesToCopy = subBuffer.length;
		System.arraycopy(subBuffer, 0, buffer_, offset, bytesToCopy);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="9999999999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="10" offset="451" size="10"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public long getKontraktnummer() {
		long kontraktnummer = 0;
		kontraktnummer = MarshallExternalDecimalUtils.unmarshallLongFromBuffer(
				buffer_, 451, 10, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (kontraktnummer);
	}

	/**
	 * @generated
	 */
	public void setKontraktnummer(long kontraktnummer) {
		if ((kontraktnummer < 0L) || (kontraktnummer > 9999999999L))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Long.toString(kontraktnummer), "kontraktnummer",
							"0", "9999999999"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(
				kontraktnummer, buffer_, 451, 10, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

}