package com.abnamro.moa.services.agreementidentifier.util.dao.generated;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import com.ibm.etools.marshall.util.*;

/**
 * @generated
 * Generated Class: MO590InputRecord
 * @type-descriptor.aggregate-instance-td accessor="readWrite" contentSize="145" offset="0" size="145"
 * @type-descriptor.platform-compiler-info language="COBOL" defaultBigEndian="true" defaultCodepage="ibm-037" defaultExternalDecimalSign="ebcdic" defaultFloatType="ibm390Hex"
 */

public class MO590InputRecord implements javax.resource.cci.Record,
		javax.resource.cci.Streamable, com.ibm.etools.marshall.RecordBytes {
	private static final long serialVersionUID = 570666139367299700L;
	/**
	 * @generated
	 */
	private byte[] buffer_ = null;
	/**
	 * @generated
	 */
	private static final int bufferSize_;
	/**
	 * @generated
	 */
	private static final byte[] initializedBuffer_;
	/**
	 * @generated
	 */
	private static java.util.HashMap getterMap_ = null;
	/**
	 * @generated
	 */
	private java.util.HashMap valFieldNameMap_ = null;

	/**
	 * initializer
	 * @generated
	 */
	static {
		bufferSize_ = 145;
		initializedBuffer_ = new byte[bufferSize_];
		String programma_NaamInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				programma_NaamInitialValue, initializedBuffer_, 135, "ibm-037",
				6, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		short zz_VeldInitialValue = (short) +0;
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(
				zz_VeldInitialValue, initializedBuffer_, 2, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		String ims_Transakt_KodeInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				ims_Transakt_KodeInitialValue, initializedBuffer_, 4,
				"ibm-037", 8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String bs_ReservedInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_ReservedInitialValue, initializedBuffer_, 68, "ibm-037", 44,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String bs_Language_CodeInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_Language_CodeInitialValue, initializedBuffer_, 46,
				"ibm-037", 2, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String bs_Channel_IdInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_Channel_IdInitialValue, initializedBuffer_, 27, "ibm-037",
				3, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String bs_Language_Country_CodeInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_Language_Country_CodeInitialValue, initializedBuffer_, 48,
				"ibm-037", 2, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String bs_Process_IdInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_Process_IdInitialValue, initializedBuffer_, 24, "ibm-037",
				3, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String bs_Issue_IdInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_Issue_IdInitialValue, initializedBuffer_, 50, "ibm-037", 15,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String bs_UseridInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_UseridInitialValue, initializedBuffer_, 12, "ibm-037", 12,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String bs_Session_IdInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_Session_IdInitialValue, initializedBuffer_, 38, "ibm-037",
				8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String soort_BronInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				soort_BronInitialValue, initializedBuffer_, 124, "ibm-037", 1,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String bron_IdentInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bron_IdentInitialValue, initializedBuffer_, 125, "ibm-037", 6,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String medewerker_IdentInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				medewerker_IdentInitialValue, initializedBuffer_, 131,
				"ibm-037", 4, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String bs_Application_IdInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				bs_Application_IdInitialValue, initializedBuffer_, 30,
				"ibm-037", 8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String fill_0InitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				fill_0InitialValue, initializedBuffer_, 144, "ibm-037", 1,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String kontraktsoort_KodeInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				kontraktsoort_KodeInitialValue, initializedBuffer_, 141,
				"ibm-037", 3, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
	}

	/**
	 * constructor
	 * @generated
	 */
	public MO590InputRecord() {
		initialize();
	}

	/**
	 * constructor
	 * @generated
	 */
	public MO590InputRecord(java.util.HashMap valFieldNameMap) {
		valFieldNameMap_ = valFieldNameMap;
		initialize();
	}

	/**
	 * @generated
	 * initialize
	 */
	public void initialize() {
		buffer_ = new byte[bufferSize_];
		System.arraycopy(initializedBuffer_, 0, buffer_, 0, bufferSize_);
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Streamable#read(java.io.InputStream)
	 */
	public void read(java.io.InputStream inputStream)
			throws java.io.IOException {
		byte[] input = new byte[inputStream.available()];
		inputStream.read(input);
		buffer_ = input;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Streamable#write(java.io.OutputStream)
	 */
	public void write(java.io.OutputStream outputStream)
			throws java.io.IOException {
		outputStream.write(buffer_, 0, getSize());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#getRecordName()
	 */
	public String getRecordName() {
		return (this.getClass().getName());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#setRecordName(String)
	 */
	public void setRecordName(String recordName) {
		return;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#setRecordShortDescription(String)
	 */
	public void setRecordShortDescription(String shortDescription) {
		return;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#getRecordShortDescription()
	 */
	public String getRecordShortDescription() {
		return (this.getClass().getName());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#clone()
	 */
	public Object clone() throws CloneNotSupportedException {
		return (super.clone());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#equals
	 */
	public boolean equals(Object object) {
		return (super.equals(object));
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#hashCode
	 */
	public int hashCode() {
		return (super.hashCode());
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#getBytes
	 */
	public byte[] getBytes() {
		return (buffer_);
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#setBytes
	 */
	public void setBytes(byte[] bytes) {
		if ((bytes != null) && (bytes.length != 0))
			buffer_ = bytes;
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#getSize
	 */
	public int getSize() {
		return (145);
	}

	/**
	 * @generated
	 */
	public boolean match(Object obj) {
		if (obj == null)
			return (false);
		if (obj.getClass().isArray()) {
			byte[] currBytes = buffer_;
			try {
				byte[] objByteArray = (byte[]) obj;
				if (objByteArray.length != buffer_.length)
					return (false);
				buffer_ = objByteArray;
			} catch (ClassCastException exc) {
				return (false);
			} finally {
				buffer_ = currBytes;
			}
		} else
			return (false);
		return (true);
	}

	/**
	 * @generated
	 */
	public void populate(Object obj) {
		if (obj.getClass().isArray()) {
			try {
				buffer_ = (byte[]) obj;
			} catch (ClassCastException exc) {
			}
		}
	}

	/**
	 * @generated
	 * @see java.lang.Object#toString
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer(super.toString());
		sb.append("\n");
		ConversionUtils.dumpBytes(sb, buffer_);
		return (sb.toString());
	}

	/**
	 * @generated
	 * wrappedGetNumber
	 */
	public Number wrappedGetNumber(String propertyName) {
		Number result = null;

		if (getterMap_ == null) {
			synchronized (initializedBuffer_) {
				if (getterMap_ == null) {
					java.util.HashMap getterMap = new java.util.HashMap();
					try {
						BeanInfo info = Introspector.getBeanInfo(this
								.getClass());
						PropertyDescriptor[] props = info
								.getPropertyDescriptors();

						for (int i = 0; i < props.length; i++) {
							String propName = props[i].getName();
							getterMap.put(propName, props[i].getReadMethod());
						}
					} catch (IntrospectionException exc) {
					}
					getterMap_ = getterMap;
				}
			}
		}

		Method method = (Method) getterMap_.get(propertyName);
		if (method != null) {
			try {
				result = (Number) method.invoke(this, new Object[0]);
			} catch (Exception exc) {
			}
		}

		return (result);
	}

	/**
	 * @generated
	 * evaluateMap
	 */
	public java.util.HashMap evaluateMap(java.util.HashMap valFieldNameMap) {
		if (valFieldNameMap == null)
			return (null);
		java.util.HashMap returnMap = new java.util.HashMap(
				valFieldNameMap.size());
		java.util.Set aSet = valFieldNameMap.entrySet();

		for (java.util.Iterator cursor = aSet.iterator(); cursor.hasNext();) {
			java.util.Map.Entry element = (java.util.Map.Entry) cursor.next();
			String key = (String) element.getKey();
			String fieldName = (String) element.getValue();
			Number fieldValue = wrappedGetNumber(fieldName);
			if (fieldValue == null)
				fieldValue = new Integer(0);
			returnMap.put(key, fieldValue);
		}

		return (returnMap);
	}

	/**
	 * @generated
	 * Returns the integer value of the formula string for an offset or size.
	 * The formula can be comprised of the following functions:
	 * neg(x)   := -x       // prefix negate
	 * add(x,y) := x+y      // infix add
	 * sub(x,y) := x-y      // infix subtract
	 * mpy(x,y) := x*y      // infix multiply
	 * div(x,y) := x/y      // infix divide
	 * max(x,y) := max(x,y)
	 * min(x,y) := min(x,y)
	 *
	 * mod(x,y) := x mod y
	 *
	 * The mod function is defined as mod(x,y) = r where r is the smallest non-negative integer
	 * such that x-r is evenly divisible by y. So mod(7,4) is 3, but mod(-7,4) is 1. If y is a
	 * power of 2, then mod(x,y) is equal to the bitwise-and of x and y-1.
	 *
	 * val(1, m, n, o,..)
	 *
	 * The val function returns the value of a field in the model. The val function takes one
	 * or more arguments, and the first argument refers to a level-1 field in the type model and must be either:
	 *    - the name of a level-1 field described in the language model
	 *    - the integer 1 (indicating that the level-1 parent of the current structure is meant)
	 * If the first argument to the val function is the integer 1, then and only then are subsequent arguments
	 * permitted. These subsequent arguments are integers that the specify the ordinal number within its
	 * substructure of the subfield that should be dereferenced.
	 *
	 * @return The integer value of the formula string for an offset or size.
	 * @param formula The formula to be evaluated.
	 * @param valFieldNameMap A map of val() formulas to field names.
	 * @throws IllegalArgumentException if the formula is null.
	 */

	public int evaluateFormula(String formula, java.util.HashMap valFieldNameMap)
			throws IllegalArgumentException {
		if (formula == null)
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.MARSHRT_FORMULA_NULL));

		int result = 0;

		int index = formula.indexOf("(");

		if (index == -1) // It's a number not an expression
		{
			try {
				result = Integer.parseInt(formula);
			} catch (Exception exc) {
			}

			return (result);
		}

		// Determine the outermost function
		String function = formula.substring(0, index);

		if (function.equalsIgnoreCase("val")) {
			Object field = valFieldNameMap.get(formula);
			if (field == null)
				return (0);

			if (field instanceof String) {
				Number num = wrappedGetNumber((String) field);
				if (num == null) // Element does not exist
					return (0);
				result = num.intValue();
			} else if (field instanceof Number)
				result = ((Number) field).intValue();
			else
				return (0);

			return (result);
		} else if (function.equalsIgnoreCase("neg")) {
			// The new formula is the content between the brackets
			formula = formula.substring(index + 1, formula.length() - 1);
			result = -1 * evaluateFormula(formula, valFieldNameMap);
			return (result);
		} else {
			// Get the contents between the outermost brackets
			formula = formula.substring(index + 1, formula.length() - 1);
			char[] formulaChars = formula.toCharArray();

			// Get the left side and the right side of the operation

			int brackets = 0;
			int i = 0;

			for (; i < formulaChars.length; i++) {
				if (formulaChars[i] == '(')
					brackets++;
				else if (formulaChars[i] == ')')
					brackets--;
				else if (formulaChars[i] == ',') {
					if (brackets == 0)
						break;
				}
			}

			String leftSide = "0";
			String rightSide = "0";

			leftSide = formula.substring(0, i);
			rightSide = formula.substring(i + 1);

			if (function.equalsIgnoreCase("add"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						+ evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("mpy"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						* evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("sub"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						- evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("div"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						/ evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("max"))
				result = Math.max(evaluateFormula(leftSide, valFieldNameMap),
						evaluateFormula(rightSide, valFieldNameMap));
			else if (function.equalsIgnoreCase("min"))
				result = Math.min(evaluateFormula(leftSide, valFieldNameMap),
						evaluateFormula(rightSide, valFieldNameMap));
			else if (function.equalsIgnoreCase("mod"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						% evaluateFormula(rightSide, valFieldNameMap);
		}

		return (result);
	}

	/**
	 * @generated
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="0" size="2"
	 * @type-descriptor.integer-td signCoding="twosComplement"
	 */
	public short getLl_Veld() {
		short ll_Veld = 0;
		ll_Veld = MarshallIntegerUtils.unmarshallTwoByteIntegerFromBuffer(
				buffer_, 0, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		return (ll_Veld);
	}

	/**
	 * @generated
	 */
	public void setLl_Veld(short ll_Veld) {
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(ll_Veld, buffer_,
				0, true, MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
	}

	/**
	 * @generated
	 * @type-descriptor.initial-value kind="string_value" value="+0"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="2" size="2"
	 * @type-descriptor.integer-td signCoding="twosComplement"
	 */
	public short getZz_Veld() {
		short zz_Veld = 0;
		zz_Veld = MarshallIntegerUtils.unmarshallTwoByteIntegerFromBuffer(
				buffer_, 2, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		return (zz_Veld);
	}

	/**
	 * @generated
	 */
	public void setZz_Veld(short zz_Veld) {
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(zz_Veld, buffer_,
				2, true, MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="4" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getIms_Transakt_Kode() {
		String ims_Transakt_Kode = null;
		ims_Transakt_Kode = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 4, "ibm-037", 8);
		return (ims_Transakt_Kode);
	}

	/**
	 * @generated
	 */
	public void setIms_Transakt_Kode(String ims_Transakt_Kode) {
		if (ims_Transakt_Kode != null) {
			if (ims_Transakt_Kode.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								ims_Transakt_Kode, "8", "ims_Transakt_Kode"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					ims_Transakt_Kode, buffer_, 4, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="12"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="12" offset="12" size="12"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Userid() {
		String bs_Userid = null;
		bs_Userid = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 12, "ibm-037", 12);
		return (bs_Userid);
	}

	/**
	 * @generated
	 */
	public void setBs_Userid(String bs_Userid) {
		if (bs_Userid != null) {
			if (bs_Userid.length() > 12)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, bs_Userid, "12",
								"bs_Userid"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(bs_Userid,
					buffer_, 12, "ibm-037", 12,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="3"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="3" offset="24" size="3"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Process_Id() {
		String bs_Process_Id = null;
		bs_Process_Id = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 24, "ibm-037",
						3);
		return (bs_Process_Id);
	}

	/**
	 * @generated
	 */
	public void setBs_Process_Id(String bs_Process_Id) {
		if (bs_Process_Id != null) {
			if (bs_Process_Id.length() > 3)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, bs_Process_Id,
								"3", "bs_Process_Id"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					bs_Process_Id, buffer_, 24, "ibm-037", 3,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="3"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="3" offset="27" size="3"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Channel_Id() {
		String bs_Channel_Id = null;
		bs_Channel_Id = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 27, "ibm-037",
						3);
		return (bs_Channel_Id);
	}

	/**
	 * @generated
	 */
	public void setBs_Channel_Id(String bs_Channel_Id) {
		if (bs_Channel_Id != null) {
			if (bs_Channel_Id.length() > 3)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, bs_Channel_Id,
								"3", "bs_Channel_Id"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					bs_Channel_Id, buffer_, 27, "ibm-037", 3,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="30" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Application_Id() {
		String bs_Application_Id = null;
		bs_Application_Id = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 30, "ibm-037",
						8);
		return (bs_Application_Id);
	}

	/**
	 * @generated
	 */
	public void setBs_Application_Id(String bs_Application_Id) {
		if (bs_Application_Id != null) {
			if (bs_Application_Id.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								bs_Application_Id, "8", "bs_Application_Id"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					bs_Application_Id, buffer_, 30, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="38" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Session_Id() {
		String bs_Session_Id = null;
		bs_Session_Id = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 38, "ibm-037",
						8);
		return (bs_Session_Id);
	}

	/**
	 * @generated
	 */
	public void setBs_Session_Id(String bs_Session_Id) {
		if (bs_Session_Id != null) {
			if (bs_Session_Id.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, bs_Session_Id,
								"8", "bs_Session_Id"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					bs_Session_Id, buffer_, 38, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="2"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="46" size="2"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Language_Code() {
		String bs_Language_Code = null;
		bs_Language_Code = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 46, "ibm-037",
						2);
		return (bs_Language_Code);
	}

	/**
	 * @generated
	 */
	public void setBs_Language_Code(String bs_Language_Code) {
		if (bs_Language_Code != null) {
			if (bs_Language_Code.length() > 2)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								bs_Language_Code, "2", "bs_Language_Code"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					bs_Language_Code, buffer_, 46, "ibm-037", 2,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="2"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="48" size="2"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Language_Country_Code() {
		String bs_Language_Country_Code = null;
		bs_Language_Country_Code = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 48, "ibm-037",
						2);
		return (bs_Language_Country_Code);
	}

	/**
	 * @generated
	 */
	public void setBs_Language_Country_Code(String bs_Language_Country_Code) {
		if (bs_Language_Country_Code != null) {
			if (bs_Language_Country_Code.length() > 2)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								bs_Language_Country_Code, "2",
								"bs_Language_Country_Code"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					bs_Language_Country_Code, buffer_, 48, "ibm-037", 2,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="15"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="15" offset="50" size="15"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Issue_Id() {
		String bs_Issue_Id = null;
		bs_Issue_Id = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 50, "ibm-037",
						15);
		return (bs_Issue_Id);
	}

	/**
	 * @generated
	 */
	public void setBs_Issue_Id(String bs_Issue_Id) {
		if (bs_Issue_Id != null) {
			if (bs_Issue_Id.length() > 15)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, bs_Issue_Id,
								"15", "bs_Issue_Id"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					bs_Issue_Id, buffer_, 50, "ibm-037", 15,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="3" offset="65" size="3"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public short getBs_View_Nr() {
		short bs_View_Nr = 0;
		bs_View_Nr = MarshallExternalDecimalUtils.unmarshallShortFromBuffer(
				buffer_, 65, 3, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (bs_View_Nr);
	}

	/**
	 * @generated
	 */
	public void setBs_View_Nr(short bs_View_Nr) {
		if ((bs_View_Nr < 0) || (bs_View_Nr > 999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Short.toString(bs_View_Nr), "bs_View_Nr", "0",
							"999"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(
				bs_View_Nr, buffer_, 65, 3, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="44"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="44" offset="68" size="44"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBs_Reserved() {
		String bs_Reserved = null;
		bs_Reserved = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 68, "ibm-037",
						44);
		return (bs_Reserved);
	}

	/**
	 * @generated
	 */
	public void setBs_Reserved(String bs_Reserved) {
		if (bs_Reserved != null) {
			if (bs_Reserved.length() > 44)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, bs_Reserved,
								"44", "bs_Reserved"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					bs_Reserved, buffer_, 68, "ibm-037", 44,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="99"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="112" size="2"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public short getJj() {
		short jj = 0;
		jj = MarshallExternalDecimalUtils.unmarshallShortFromBuffer(buffer_,
				112, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (jj);
	}

	/**
	 * @generated
	 */
	public void setJj(short jj) {
		if ((jj < 0) || (jj > 99))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E, Short.toString(jj),
							"jj", "0", "99"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(jj,
				buffer_, 112, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="3" offset="114" size="3"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public short getDdd() {
		short ddd = 0;
		ddd = MarshallExternalDecimalUtils.unmarshallShortFromBuffer(buffer_,
				114, 3, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (ddd);
	}

	/**
	 * @generated
	 */
	public void setDdd(short ddd) {
		if ((ddd < 0) || (ddd > 999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E, Short.toString(ddd),
							"ddd", "0", "999"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(ddd,
				buffer_, 114, 3, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="99"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="117" size="2"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public short getHh() {
		short hh = 0;
		hh = MarshallExternalDecimalUtils.unmarshallShortFromBuffer(buffer_,
				117, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (hh);
	}

	/**
	 * @generated
	 */
	public void setHh(short hh) {
		if ((hh < 0) || (hh > 99))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E, Short.toString(hh),
							"hh", "0", "99"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(hh,
				buffer_, 117, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="99"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="119" size="2"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public short getMm() {
		short mm = 0;
		mm = MarshallExternalDecimalUtils.unmarshallShortFromBuffer(buffer_,
				119, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (mm);
	}

	/**
	 * @generated
	 */
	public void setMm(short mm) {
		if ((mm < 0) || (mm > 99))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E, Short.toString(mm),
							"mm", "0", "99"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(mm,
				buffer_, 119, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="99"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="121" size="2"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public short getSs() {
		short ss = 0;
		ss = MarshallExternalDecimalUtils.unmarshallShortFromBuffer(buffer_,
				121, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (ss);
	}

	/**
	 * @generated
	 */
	public void setSs(short ss) {
		if ((ss < 0) || (ss > 99))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E, Short.toString(ss),
							"ss", "0", "99"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(ss,
				buffer_, 121, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="9"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="1" offset="123" size="1"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public short getT() {
		short t = 0;
		t = MarshallExternalDecimalUtils.unmarshallShortFromBuffer(buffer_,
				123, 1, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (t);
	}

	/**
	 * @generated
	 */
	public void setT(short t) {
		if ((t < 0) || (t > 9))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E, Short.toString(t),
							"t", "0", "9"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(t,
				buffer_, 123, 1, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="1"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="1" offset="124" size="1"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getSoort_Bron() {
		String soort_Bron = null;
		soort_Bron = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 124, "ibm-037", 1);
		return (soort_Bron);
	}

	/**
	 * @generated
	 */
	public void setSoort_Bron(String soort_Bron) {
		if (soort_Bron != null) {
			if (soort_Bron.length() > 1)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, soort_Bron, "1",
								"soort_Bron"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(soort_Bron,
					buffer_, 124, "ibm-037", 1,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="6"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="6" offset="125" size="6"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBron_Ident() {
		String bron_Ident = null;
		bron_Ident = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 125, "ibm-037", 6);
		return (bron_Ident);
	}

	/**
	 * @generated
	 */
	public void setBron_Ident(String bron_Ident) {
		if (bron_Ident != null) {
			if (bron_Ident.length() > 6)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, bron_Ident, "6",
								"bron_Ident"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(bron_Ident,
					buffer_, 125, "ibm-037", 6,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="4"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="4" offset="131" size="4"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getMedewerker_Ident() {
		String medewerker_Ident = null;
		medewerker_Ident = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 131, "ibm-037",
						4);
		return (medewerker_Ident);
	}

	/**
	 * @generated
	 */
	public void setMedewerker_Ident(String medewerker_Ident) {
		if (medewerker_Ident != null) {
			if (medewerker_Ident.length() > 4)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								medewerker_Ident, "4", "medewerker_Ident"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					medewerker_Ident, buffer_, 131, "ibm-037", 4,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="6"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="6" offset="135" size="6"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getProgramma_Naam() {
		String programma_Naam = null;
		programma_Naam = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 135, "ibm-037",
						6);
		return (programma_Naam);
	}

	/**
	 * @generated
	 */
	public void setProgramma_Naam(String programma_Naam) {
		if (programma_Naam != null) {
			if (programma_Naam.length() > 6)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, programma_Naam,
								"6", "programma_Naam"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					programma_Naam, buffer_, 135, "ibm-037", 6,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="3"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="3" offset="141" size="3"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getKontraktsoort_Kode() {
		String kontraktsoort_Kode = null;
		kontraktsoort_Kode = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 141, "ibm-037",
						3);
		return (kontraktsoort_Kode);
	}

	/**
	 * @generated
	 */
	public void setKontraktsoort_Kode(String kontraktsoort_Kode) {
		if (kontraktsoort_Kode != null) {
			if (kontraktsoort_Kode.length() > 3)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								kontraktsoort_Kode, "3", "kontraktsoort_Kode"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					kontraktsoort_Kode, buffer_, 141, "ibm-037", 3,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="1"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="1" offset="144" size="1"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getFill_0() {
		String fill_0 = null;
		fill_0 = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 144, "ibm-037", 1);
		return (fill_0);
	}

	/**
	 * @generated
	 */
	public void setFill_0(String fill_0) {
		if (fill_0 != null) {
			if (fill_0.length() > 1)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, fill_0, "1",
								"fill_0"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(fill_0,
					buffer_, 144, "ibm-037", 1,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

}