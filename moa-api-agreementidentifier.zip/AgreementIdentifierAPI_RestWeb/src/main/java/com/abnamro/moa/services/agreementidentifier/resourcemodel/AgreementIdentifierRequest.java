/**
 * 
 */
package com.abnamro.moa.services.agreementidentifier.resourcemodel;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;

/**
 * The class is for Request of the operation
 */
@ApiModel(description = "The Agreement Identifier API facilitates the reserving of agreement IDs")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-10-17T11:21:31.987Z")

public class AgreementIdentifierRequest {
    

    @JsonProperty("agreementAdministrationCode")
    private String agreementAdministrationCode = null;


    public AgreementIdentifierRequest agreementAdministrationCode(String agreementAdministrationCode) {
        this.agreementAdministrationCode = agreementAdministrationCode;
        return this;
      }

    public String getAgreementAdministrationCode() {
        return agreementAdministrationCode;
    }

    public void setAgreementAdministrationCode(String agreementAdministrationCode) {
        this.agreementAdministrationCode = agreementAdministrationCode;
    }
    

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((agreementAdministrationCode == null) ? 0 : agreementAdministrationCode.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AgreementIdentifierRequest other = (AgreementIdentifierRequest) obj;
        if (agreementAdministrationCode == null) {
            if (other.agreementAdministrationCode != null)
                return false;
        } else if (!agreementAdministrationCode.equals(other.agreementAdministrationCode))
            return false;
        return true;
    }


}
