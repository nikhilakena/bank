/**
 * 
 */
package com.abnamro.moa.services.agreementidentifier.resourcemodel;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The class is for Response of the operation
 *
 */
public class AgreementIdentifierResponse {

    @JsonProperty("agreementId")
    private String agreementId = null;

    /**
     * @return the agreementId
     */
    public String getAgreementId() {
        return agreementId;
    }

    /**
     * @param agreementId the agreementId to set
     */
    public void setAgreementId(String agreementId) {
        this.agreementId = agreementId;
    }


}
