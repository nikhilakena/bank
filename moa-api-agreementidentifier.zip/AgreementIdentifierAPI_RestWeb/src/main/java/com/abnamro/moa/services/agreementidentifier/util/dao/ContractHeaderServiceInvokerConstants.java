package com.abnamro.moa.services.agreementidentifier.util.dao;

/**
* 
* <br>This is used to store log constants for ContractHeaderServiceInvoker<br>
* 
* @author TCS
*/
public class ContractHeaderServiceInvokerConstants {
	
	public static final String TRANSACTION_CODE_MO590T01 = "MO590T01";
	
	public static final String STRING_ZERO = "0";

	public static final String STRING_ONE = "1";

	public static final String STRING_SEVEN = "7";

	public static final String STRING_NINE = "9";
	
	public static final String CREATION_DATE_FORMAT = "yyDDDHHmmss";
	
	public static final int CREATION_DATE_FORMAT_LENGTH = 11;
	
	public static final String SYSTEM_IDENTIFIER_ONLINE = "1";
	
	public static final String SYSTEM_IDENTIFIER_BATCH = "2";
	
	public static final int BONUMBER_ALLOWED_LENGTH = 6;
	
	public static final int PROGRAMID_ALLOWED_LENGTH = 6;
	
	public static final int EMPLOYEEID_ALLOWED_LENGTH = 4;
	
	public static final int CONTRACTIDENTIFIER_ALLOWED_LENGTH = 3;
	
	public static final int BCNUMBER_ALLOWED_LENGTH = 12;

	
}
