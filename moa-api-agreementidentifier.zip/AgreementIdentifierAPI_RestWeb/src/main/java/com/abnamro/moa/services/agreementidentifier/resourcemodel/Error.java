package com.abnamro.moa.services.agreementidentifier.resourcemodel;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.constraints.*;

/**
 * Error
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-05-14T09:10:59.321Z")

public class Error   {
  @JsonProperty("code")
  private String code = null;

  @JsonProperty("message")
  private String message = null;

  @JsonProperty("traceId")
  private String traceId = null;

  @JsonProperty("status")
  private String status = null;
  
  public Error code(String code) {
    this.code = code;
    return this;
  }

  /**
   * The unique error code key which is used to lookup the message in the content management system
   * @return code
  **/
  @ApiModelProperty(required = true, value = "The unique error code key which is used to lookup the message in the content management system")
  @NotNull


  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public Error message(String message) {
    this.message = message;
    return this;
  }

  /**
   * The message text carries the more detailed and understandable description for the message
   * @return message
  **/
  @ApiModelProperty(required = true, value = "The message text carries the more detailed and understandable description for the message")
  @NotNull


  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public Error traceId(String traceId) {
    this.traceId = traceId;
    return this;
  }

  /**
   * The unique id present in the request header for end to end tracing of an API call in order to easily trace root cause in case of errors.  
   * @return traceId
  **/
  @ApiModelProperty(value = "The unique id present in the request header for end to end tracing of an API call in order to easily trace root cause in case of errors.  ")


  public String getTraceId() {
    return traceId;
  }

  public void setTraceId(String traceId) {
    this.traceId = traceId;
  }

  public Error status(String status) {
    this.status = status;
    return this;
  }

  /**
   * The HTTP status code where the code is categorized.
   * @return status
  **/
  @ApiModelProperty(required = true, value = "The HTTP status code where the code is categorized.")
  @NotNull


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Error error = (Error) o;
    return Objects.equals(this.code, error.code) &&
        Objects.equals(this.message, error.message) &&
        Objects.equals(this.traceId, error.traceId) &&
        Objects.equals(this.status, error.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, message, traceId, status);
  }


}

