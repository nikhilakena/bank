package com.abnamro.moa.services.agreementidentifier.util;

import org.apache.commons.lang.StringUtils;

import com.abnamro.moa.services.agreementidentifier.util.dao.ContractHeaderServiceInvokerConstants;
import com.abnamro.moa.services.agreementidentifier.util.dao.ContractHeaderServiceInvokerLogConstants;
import com.abnamro.moa.services.agreementidentifier.util.dao.ContractHeaderServiceInvokerMessageKeys;
import com.abnamro.moa.services.agreementidentifier.util.dao.ReserveCINIMSDAOImpl;
import com.abnamro.moa.services.agreementidentifier.util.dto.InputHeaderDTO;
import com.abnamro.moa.services.agreementidentifier.util.dto.ReserveCINInputDTO;
import com.abnamro.moa.services.agreementidentifier.util.dto.SystemIdentifier;
import com.abnamro.moa.services.agreementidentifier.util.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.messages.Message;
import com.abnamro.nl.messages.MessageType;
import com.abnamro.nl.messages.Messages;

/**
 * This class provides utility to reserve CIN for an agreement
 * @author c45158
 *
 */
public class ReserveCINUtil {

	private LogHelper logHelper = new LogHelper(ReserveCINUtil.class);
	/**
	 * This method reserves CIN(ContractIdentificationNumber) for an agreement of the business contact by calling MO590 service
	 * 
	 * @param inputHeaderDTO generic details which requires for IMS transaction call(MO590)
	 * @param reserveCINInputDTO input which requires for IMS transaction call(MO590)  
	 * @return long contract Identification Number
	 * @throws ContractHeaderServiceInvokerException Exception thrown if any issue in processing IMS transaction 
	 */
	public long reserveCIN(InputHeaderDTO inputHeaderDTO, ReserveCINInputDTO reserveCINInputDTO) throws ContractHeaderServiceInvokerException{
		final String logMethod = "reserveCIN(InputHeaderDTO, contractHeaderServiceInputDTO)";
		long cin = 0;
		// validate mandatory fields from input details
		// TIJDSTIP-AANLEVERING, BRON-IDENT, MEDEWERKER-IDENT, PROGRAMMA-NAAM, KONTRAKTSOORT-KODE
		if(reserveCINInputDTO != null){
			boolean mandatoryFieldsEmpty = isNullOrEmpty(reserveCINInputDTO.getBoNumber(),reserveCINInputDTO.getEmpolyeeIdentifier(),
										reserveCINInputDTO.getProgramIdentifier(), reserveCINInputDTO.getContractIdentifierCode());
			
			if(mandatoryFieldsEmpty){
				logHelper.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_MANDATORY_INPUT_PARAMETER_NOT_PRESENT_IN_RESERVE_CIN);
				Messages messages = new Messages();
				messages.addMessage(new Message(ContractHeaderServiceInvokerMessageKeys.MANDATORY_PARAMETERS_MISSING_WHILE_RESERVE_CIN),MessageType.getError());
				throw new ContractHeaderServiceInvokerException(messages);
			}
			
			// validate allowed length for input parameters
			validateInputParamLength(reserveCINInputDTO);
			
			// call IMS transaction MO590 for reserveCIN
			ReserveCINIMSDAOImpl daoImpl = new ReserveCINIMSDAOImpl();
			cin = daoImpl.reserveCIN(inputHeaderDTO, reserveCINInputDTO);
		}else{
			logHelper.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_NULL_INPUT_IN_RESERVE_CIN);
			Messages messages = new Messages();
			messages.addMessage(new Message(ContractHeaderServiceInvokerMessageKeys.NULL_INPUT_WHILE_RESERVE_CIN),MessageType.getError());
			throw new ContractHeaderServiceInvokerException(messages);
		}
		return cin;
		
	}

	private void validateInputParamLength(ReserveCINInputDTO reserveCINInputDTO) throws ContractHeaderServiceInvokerException {
		final String logMethod = "validateInputParamLength(ReserveCINInputDTO";
		
		// validate system identifier value
		validateSystemIdentifier(reserveCINInputDTO.getSystemIdentifier());
		
		// validate BO Number. Max Length : 6
		if(StringUtils.isNotBlank(reserveCINInputDTO.getBoNumber()) 
				&& reserveCINInputDTO.getBoNumber().length() > ContractHeaderServiceInvokerConstants.BONUMBER_ALLOWED_LENGTH){
			logHelper.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_INVALID_LENGTH_BONUMBER_IN_INPUT_RESERVECIN);
			Messages messages = new Messages();
			messages.addMessage(new Message(ContractHeaderServiceInvokerMessageKeys.INVALID_LENGTH_BONUMBER_IN_INPUT_RESERVECIN),MessageType.getError());
			throw new ContractHeaderServiceInvokerException(messages);
		}
		
		// validate Identification of the employee, usercode (gebruikercode). Max Length 4
		if(StringUtils.isNotBlank(reserveCINInputDTO.getEmpolyeeIdentifier()) 
				&& reserveCINInputDTO.getEmpolyeeIdentifier().length() > ContractHeaderServiceInvokerConstants.EMPLOYEEID_ALLOWED_LENGTH){
			logHelper.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_INVALID_LENGTH_EMPID_IN_INPUT_RESERVECIN);
			Messages messages = new Messages();
			messages.addMessage(new Message(ContractHeaderServiceInvokerMessageKeys.INVALID_LENGTH_EMPID_IN_INPUT_RESERVECIN),MessageType.getError());
			throw new ContractHeaderServiceInvokerException(messages);
		}
		
		// validate program identifier. Max Length : 6
		if(StringUtils.isNotBlank(reserveCINInputDTO.getProgramIdentifier()) 
				&& reserveCINInputDTO.getProgramIdentifier().length() > ContractHeaderServiceInvokerConstants.PROGRAMID_ALLOWED_LENGTH){
			logHelper.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_INVALID_LENGTH_PROGRAMID_IN_INPUT_RESERVECIN);
			Messages messages = new Messages();
			messages.addMessage(new Message(ContractHeaderServiceInvokerMessageKeys.INVALID_LENGTH_PROGRAMID_IN_INPUT_RESERVECIN),MessageType.getError());
			throw new ContractHeaderServiceInvokerException(messages);
		}
		
		// validate Identification (code)of the type of contract . Max Length : 3
		if(StringUtils.isNotBlank(reserveCINInputDTO.getContractIdentifierCode()) 
				&& reserveCINInputDTO.getContractIdentifierCode().length() > ContractHeaderServiceInvokerConstants.CONTRACTIDENTIFIER_ALLOWED_LENGTH){
			logHelper.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_INVALID_LENGTH_CONTRACTID_IN_INPUT_RESERVECIN);
			Messages messages = new Messages();
			messages.addMessage(new Message(ContractHeaderServiceInvokerMessageKeys.INVALID_LENGTH_CONTRACTID_IN_INPUT_RESERVECIN),MessageType.getError());
			throw new ContractHeaderServiceInvokerException(messages);
		}
	}

	private void validateSystemIdentifier(Enum systemIdentifier) throws ContractHeaderServiceInvokerException {
		final String logMethod = "validateSystemIdentifier(String)";
		// validate system identifier value
		// '1' = ONLINE
		// '2' = BATCH
		if(!(SystemIdentifier.ONLINE.equals(systemIdentifier) || SystemIdentifier.BATCH.equals(systemIdentifier))){
			logHelper.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_INVALID_SYSTEM_IDENTIFIER_IN_INPUT_RESERVECIN);
			Messages messages = new Messages();
			messages.addMessage(new Message(ContractHeaderServiceInvokerMessageKeys.INVALID_SYSTEM_IDENTIFIER_IN_INPUT_RESERVE_CIN),MessageType.getError());
			throw new ContractHeaderServiceInvokerException(messages);
		}
	}
	
	private boolean isNullOrEmpty(String... strArr) {
       for (String string : strArr) {
            if(StringUtils.isBlank(string)){
               return true;
            }
       } 
       return false;
	}

}
