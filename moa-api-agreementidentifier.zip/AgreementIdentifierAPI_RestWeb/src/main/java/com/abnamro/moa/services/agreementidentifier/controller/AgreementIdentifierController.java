package com.abnamro.moa.services.agreementidentifier.controller;

import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abnamro.moa.services.agreementidentifier.util.dao.ContractHeaderServiceInvokerConstants;
import com.abnamro.moa.services.agreementidentifier.util.dao.ContractHeaderServiceInvokerLogConstants;
import com.abnamro.moa.services.agreementidentifier.constants.AgreementIdentifierConstants;
import com.abnamro.moa.services.agreementidentifier.exception.AgreementIdentifierApplicationException;
import com.abnamro.moa.services.agreementidentifier.requestprocessor.AgreementIdentifierRequestProcessor;
import com.abnamro.moa.services.agreementidentifier.resourcemodel.AgreementIdentifierRequest;
import com.abnamro.moa.services.agreementidentifier.resourcemodel.AgreementIdentifierResponse;
import com.abnamro.moa.services.agreementidentifier.util.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.messages.MessageType;


/**
 * This is the controller class for the Agreement Identifier API.
 */
@Configuration
@RestController
@RequestMapping("/")
public class AgreementIdentifierController {
    
    private static LogHelper log = new LogHelper(AgreementIdentifierRequestProcessor.class);
    
    
    private AgreementIdentifierRequestProcessor agreementIdentifierRequestProcessor = new AgreementIdentifierRequestProcessor();
   
    /**
     * Method to reserve agreementID
     * @param consumerId is input consumer ID
     * @param traceId is trace ID in input
     * @param agreementIdentifierRequest is input DTO
     * @return response which contains agreement ID
     * @throws AgreementIdentifierApplicationException is exception for application
     */
    @PostMapping(value = "/v1/reservation", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AgreementIdentifierResponse> reserveCIN(
            @RequestHeader(name="Consumer-Id", required = false) String consumerId,
            @RequestHeader(name="Trace-Id", required = false) String traceId,
            @RequestBody(required = true) @Valid AgreementIdentifierRequest agreementIdentifierRequest) throws AgreementIdentifierApplicationException {
        
        final String logMethod = "reserveCIN(AgreementIdentifierRequest, String):String";
        
        
        ResponseEntity<AgreementIdentifierResponse> response = null;
        long agreementId = 0;
        
        validateAgreementAdmin(agreementIdentifierRequest.getAgreementAdministrationCode());
        
        try {
            agreementId = agreementIdentifierRequestProcessor.getReservedCIN(agreementIdentifierRequest.getAgreementAdministrationCode().trim(), consumerId);
        } catch (ContractHeaderServiceInvokerException e) {
            log.error(logMethod, AgreementIdentifierConstants.LOG_AGREEMENT_IDENTIFIER_EXCEPTION_IN_RESERVECIN_IN_CONTROLLER, e);
            httpErrorCodeMapper(e);
        }
        
        response = createSuccessFullResponse(Long.toString(agreementId));
        return response;
    } 
    
    
    @SuppressWarnings("unused")
    private void httpErrorCodeMapper(ContractHeaderServiceInvokerException e) throws AgreementIdentifierApplicationException {
        final String logMethod = "httpErrorCodeMapper(ContractHeaderServiceInvokerException, String):String";
        for (int i = 0; i < e.getMessages().getMessagesOfType(MessageType.getError()).size(); i++) {
            log.error(logMethod, e.getMessages().getMessagesOfType(MessageType.getError()).get(i).getMessageKey().getId());
            // this key check is applied in case agreementAdminCode does not exist or not allowed to reserve CIN
            if(("MESSAGE_RESCIN_FAIL_").equalsIgnoreCase(e.getMessages().getMessagesOfType(MessageType.getError()).get(i).getMessageKey().getId().trim())){
                throw new AgreementIdentifierApplicationException("4002", HttpStatus.BAD_REQUEST); 
            }else{
                throw new AgreementIdentifierApplicationException("500", HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        
    }


    private void validateAgreementAdmin(String agreementAdministrationCode) throws AgreementIdentifierApplicationException {
        final String logMethod = "validateAgreementAdmin(agreementAdministrationCode, String):String";
        if (agreementAdministrationCode == null || agreementAdministrationCode.isEmpty()){
            throw new AgreementIdentifierApplicationException("4001", HttpStatus.BAD_REQUEST);
            
        }
        // validate Identification (code)of the type of contract . Max Length : 3
        if(StringUtils.isNotBlank(agreementAdministrationCode) 
                && agreementAdministrationCode.trim().length() > ContractHeaderServiceInvokerConstants.CONTRACTIDENTIFIER_ALLOWED_LENGTH){
            log.error(logMethod, ContractHeaderServiceInvokerLogConstants.LOG_INVALID_LENGTH_CONTRACTID_IN_INPUT_RESERVECIN);
            throw new AgreementIdentifierApplicationException("4002", HttpStatus.BAD_REQUEST);
        }
    }

    private ResponseEntity<AgreementIdentifierResponse> createSuccessFullResponse(String agreementId) {
        ResponseEntity<AgreementIdentifierResponse> response = null;

        // add the id of the created agreement Id to the response
        AgreementIdentifierResponse body = new AgreementIdentifierResponse();
        body.setAgreementId(agreementId);

        // create the response
        response = new ResponseEntity<AgreementIdentifierResponse>(body, HttpStatus.OK);

        return response;
    }
    
    
}
