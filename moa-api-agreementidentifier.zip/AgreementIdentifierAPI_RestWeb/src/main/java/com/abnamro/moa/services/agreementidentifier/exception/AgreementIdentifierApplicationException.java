package com.abnamro.moa.services.agreementidentifier.exception;

import java.util.List;

import org.springframework.http.HttpStatus;


/**
 * This is the customised exception class for the Agreement Identifier API
 */
public class AgreementIdentifierApplicationException extends Exception {


    private final HttpStatus status;

    private List<String> params;

    /**
     * Public constructor with http status
     *
     * @param status http status of the error
     */
    public AgreementIdentifierApplicationException(HttpStatus status) {
        super();
        this.status = status;
    }

    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param cause cause of the error
     * @param status https status of the error
     */
    public AgreementIdentifierApplicationException(String message, Throwable cause, HttpStatus status) {
        super(message, cause);
        this.status = status;
    }

    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param status https status of the error
     */
    public AgreementIdentifierApplicationException(String message, HttpStatus status) {
        super(message);
        this.status = status;
    }
    
    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param status https status of the error
     */
    public AgreementIdentifierApplicationException(String message, int status) {
        super(message);
        this.status = HttpStatus.valueOf(status);
    }

    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param status https status of the error
     * @param params list of additional param information
     */
    public AgreementIdentifierApplicationException(String message, HttpStatus status,List<String> params) {
        super(message);
        this.params = params;
        this.status = status;
    }

    public HttpStatus getStatus() {
        return this.status;
    }

    public List<String> getParams() {
        return params;
    }
}
