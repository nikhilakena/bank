/**
 * 
 */
package com.abnamro.moa.services.agreementidentifier.requestprocessor;

import java.util.Date;

import com.abnamro.moa.services.agreementidentifier.constants.AgreementIdentifierConstants;
import com.abnamro.moa.services.agreementidentifier.util.ReserveCINUtil;
import com.abnamro.moa.services.agreementidentifier.util.dto.ReserveCINInputDTO;
import com.abnamro.moa.services.agreementidentifier.util.dto.SystemIdentifier;
import com.abnamro.moa.services.agreementidentifier.util.exceptions.ContractHeaderServiceInvokerException;

/**
 * This request processor is used to call reserve CIN util
 *
 */
public class AgreementIdentifierRequestProcessor {

    /**
     * This method will call to reserveCIN util and return agreeemntID
     * @param agreementAdminCode is agreement administration code as input
     * @param consumerId is consumer ID as input
     * @return cin as agreement ID
     * @throws ContractHeaderServiceInvokerException is thrown for this method
     */
    public long getReservedCIN(String agreementAdminCode, String consumerId) throws ContractHeaderServiceInvokerException {
        ReserveCINInputDTO inputDTO = new ReserveCINInputDTO();
        inputDTO.setCreatedTimestamp(new Date());
        inputDTO.setEmpolyeeIdentifier("APIC");
        inputDTO.setContractIdentifierCode(agreementAdminCode);
        inputDTO.setProgramIdentifier(AgreementIdentifierConstants.IDENTIFIER_API_CIN);
        inputDTO.setBoNumber(AgreementIdentifierConstants.IDENTIFIER_API_CIN);
        inputDTO.setSystemIdentifier(SystemIdentifier.ONLINE);
        ReserveCINUtil util = new ReserveCINUtil();
        long cin = util.reserveCIN(null, inputDTO);
        return cin;
    }
    

}
