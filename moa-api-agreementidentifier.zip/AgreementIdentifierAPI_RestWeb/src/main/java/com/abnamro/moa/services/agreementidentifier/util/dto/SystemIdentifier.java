package com.abnamro.moa.services.agreementidentifier.util.dto;

/**
 * Identification of the system,'1' = ONLINE, '2' = BATCH
	    Format: character.
	    Length: 1
 * @author c45158
 *
 */
public enum SystemIdentifier {
		ONLINE("1"),
		BATCH("2");
	
		private SystemIdentifier(String value) {
			this.value = value;
		}

		private String value;

		/**
		 * @return String
		 */
		public String getValue() {
			return value;
		}

		/**
		 * @param value String
		 */
		public void setValue(String value) {
			this.value = value;
		}

		/**
		 * It converts string value to corresponding SystemIdentifier Enum
		 * 
		 * @param value String
		 * @return SystemIdentifier
		 */
		public static SystemIdentifier findByValue(String value){
		    for(SystemIdentifier c : values()){
		        if(c.getValue().equals(value)){
		            return c;
		        }
		    }
		    return null;
		}
}
