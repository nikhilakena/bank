package com.abnamro.moa.services.agreementidentifier.util.dto;

import java.util.Date;

import com.abnamro.moa.services.agreementidentifier.util.dto.SystemIdentifier;

/**
 * This DTO contains input parameters required for MO590 IMS transaction call
 * @author c45158
 *
 */
public class ReserveCINInputDTO {

	/**
	 * Timestamp creation date (YYDDDHHMMSST) 	
	 */
	private Date createdTimestamp;
	
	/**
	 * Identification of the system,'1' = ONLINE, '2' = BATCH
	    Format: character.
	    Length: 1
	 */
	private SystemIdentifier systemIdentifier;
	
	/**
	 * Identification of the BO-NUMBER. 
		Format: character.
	    Length: 6.
	 */
	private String boNumber;
	
	/**
	 * identification of the employee,usercode (gebruikercode). 
	 * 	Format: character.
	    Length: 4.
	 */
	private String empolyeeIdentifier;
	
	/**
	 * Identification of the calling program
		Format: character
		Length: 6

	 */
	private String programIdentifier;
	
	/**
	 * Identification (code)of the type of contract this CIN will be part of. (For instance BSA or CRC). 
	 * It has to be taken into account that the code used must be present in module CL780 (table with codes for CDB clients) or CE780 (table for non CDB clients). 
		Format: character.
		Length: 3.
	 */
	private String contractIdentifierCode;

	
	

	public String getBoNumber() {
		return boNumber;
	}

	public void setBoNumber(String boNumber) {
		this.boNumber = boNumber;
	}

	public String getEmpolyeeIdentifier() {
		return empolyeeIdentifier;
	}

	public void setEmpolyeeIdentifier(String empolyeeIdentifier) {
		this.empolyeeIdentifier = empolyeeIdentifier;
	}

	public String getProgramIdentifier() {
		return programIdentifier;
	}

	public void setProgramIdentifier(String programIdentifier) {
		this.programIdentifier = programIdentifier;
	}

	public String getContractIdentifierCode() {
		return contractIdentifierCode;
	}

	public void setContractIdentifierCode(String contractIdentifierCode) {
		this.contractIdentifierCode = contractIdentifierCode;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public SystemIdentifier getSystemIdentifier() {
		return systemIdentifier;
	}

	public void setSystemIdentifier(SystemIdentifier systemIdentifier) {
		this.systemIdentifier = systemIdentifier;
	}

}
