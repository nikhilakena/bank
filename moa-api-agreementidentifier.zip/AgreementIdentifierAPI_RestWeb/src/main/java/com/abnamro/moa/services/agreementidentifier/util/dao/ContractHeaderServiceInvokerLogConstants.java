package com.abnamro.moa.services.agreementidentifier.util.dao;

/**
* 
* <br>This is used to store log constants for ContractHeaderServiceInvoker<br>
* 
* @author TCS
*/
public class ContractHeaderServiceInvokerLogConstants {

	public static final String LOG_MANDATORY_INPUT_PARAMETER_NOT_PRESENT_IN_RESERVE_CIN = "LOG_AGRID_0001";
	
	public static final String LOG_IMS_EXCEPTION_IN_RESERVE_CIN = "LOG_AGRID_0002";
	
	public static final String LOG_RSLT_CODE_FAILURE_OR_NO_RESULTS = "LOG_AGRID_0003";
	
	public static final String LOG_INVALID_SYSTEM_IDENTIFIER_IN_INPUT_RESERVECIN = "LOG_AGRID_0004";
	
	public static final String LOG_INVALID_LENGTH_BONUMBER_IN_INPUT_RESERVECIN = "LOG_AGRID_0005";
	
	public static final String LOG_INVALID_LENGTH_PROGRAMID_IN_INPUT_RESERVECIN = "LOG_AGRID_0006";
	
	public static final String LOG_INVALID_LENGTH_EMPID_IN_INPUT_RESERVECIN = "LOG_AGRID_0007";
	
	public static final String LOG_INVALID_LENGTH_CONTRACTID_IN_INPUT_RESERVECIN = "LOG_AGRID_0008";

	public static final String LOG_RSLT_CODE_FAILURE = "LOG_AGRID_0009";
	
	public static final String LOG_NULL_INPUT_IN_RESERVE_CIN = "LOG_AGRID_0010";
	
}
