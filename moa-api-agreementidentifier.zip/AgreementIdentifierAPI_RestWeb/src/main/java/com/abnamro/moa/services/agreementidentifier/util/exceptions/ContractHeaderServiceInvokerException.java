/**
 * 
 */
package com.abnamro.moa.services.agreementidentifier.util.exceptions;

import com.abnamro.nl.exceptions.AABException;
import com.abnamro.nl.exceptions.DAOException;
import com.abnamro.nl.messages.Messages;

/**
 * This is exception class for the ContractHeaderServiceInvoker.
 */
public class ContractHeaderServiceInvokerException extends DAOException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This is a default constructor
	 */
	public ContractHeaderServiceInvokerException() {
		super();
		
	}

	/**
	 * This is a parameterized constructor
	 * @param e is a AABException
	 */
	public ContractHeaderServiceInvokerException(AABException e) {
		super(e);
	}

	/**
	 * This is a parameterized constructor
	 * @param messages is a Messages
	 */
	public ContractHeaderServiceInvokerException(Messages messages) {
		super(messages);
	}

}
