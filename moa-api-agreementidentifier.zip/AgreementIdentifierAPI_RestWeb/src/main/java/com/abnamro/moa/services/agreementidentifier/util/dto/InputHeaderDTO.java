package com.abnamro.moa.services.agreementidentifier.util.dto;

/**
 * This DTO holds generic details which is required as an input for IMS transaction call
 * @author c45158
 *
 */
public class InputHeaderDTO {
	/**
	 *provides application ID 
	 */
	private String applicationId;

	/**
	 * proviides the channel ID
	 * */
	private String channelId;	
	
	/**
	 *provides the issue ID 
	 */
	private String  issueId;
	
	/**
	 * provides the language code
	 */
	private String languageCode;
	
	/**
	 *provides the process ID
	 */
	private String processId;
	
	/**
	 *provides the reserved.
	 */
	private String reserved;
	
	/**
	 *provides the session ID.
	 */
	private String sessionId;
	
	
	/**
	 *provides user ID.
	 */
	private String userId;
	
	/**
	 *provides view number.
	 */
	private String viewNumber;
	/**
	 *provides language Country Code
	 */
	private String languageCountryCode;
	
	/**
	 *provides transactin ID.
	 */
	private String transactionId;

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getIssueId() {
		return issueId;
	}

	public void setIssueId(String issueId) {
		this.issueId = issueId;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public String getReserved() {
		return reserved;
	}

	public void setReserved(String reserved) {
		this.reserved = reserved;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getViewNumber() {
		return viewNumber;
	}

	public void setViewNumber(String viewNumber) {
		this.viewNumber = viewNumber;
	}

	public String getLanguageCountryCode() {
		return languageCountryCode;
	}

	public void setLanguageCountryCode(String languageCountryCode) {
		this.languageCountryCode = languageCountryCode;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

}
