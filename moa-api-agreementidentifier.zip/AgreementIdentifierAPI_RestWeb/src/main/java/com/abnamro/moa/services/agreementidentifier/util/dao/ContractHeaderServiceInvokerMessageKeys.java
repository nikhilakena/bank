package com.abnamro.moa.services.agreementidentifier.util.dao;

import com.abnamro.nl.messages.MessageKey;
/**
* 
* <br>This is used to store message keys DAO layer of contract Header Invoker service.<br>
* 
* @author TCS
*/
public class ContractHeaderServiceInvokerMessageKeys {

	public static final MessageKey RSLT_CODE_FAILURE_OR_NO_RESULTS = new MessageKey("MESSAGE_AGRID_0001");
	
	public static final MessageKey IMS_EXCEPTION_WHILE_RESERVE_CIN = new MessageKey("MESSAGE_AGRID_0002");
	
	public static final MessageKey MANDATORY_PARAMETERS_MISSING_WHILE_RESERVE_CIN = new MessageKey("MESSAGE_AGRID_0003");
	
	public static final MessageKey INVALID_SYSTEM_IDENTIFIER_IN_INPUT_RESERVE_CIN = new MessageKey("MESSAGE_AGRID_0004");
	
	public static final MessageKey INVALID_LENGTH_BONUMBER_IN_INPUT_RESERVECIN = new MessageKey("MESSAGE_AGRID_0005");
	
	public static final MessageKey INVALID_LENGTH_PROGRAMID_IN_INPUT_RESERVECIN = new MessageKey("MESSAGE_AGRID_0006");
	
	public static final MessageKey INVALID_LENGTH_EMPID_IN_INPUT_RESERVECIN = new MessageKey("MESSAGE_AGRID_0007");

	public static final MessageKey INVALID_LENGTH_CONTRACTID_IN_INPUT_RESERVECIN = new MessageKey("MESSAGE_AGRID_0008");
	
	public static final MessageKey NULL_INPUT_WHILE_RESERVE_CIN = new MessageKey("MESSAGE_AGRID_0009");
	
	public static final MessageKey NULL_INPUT_WHILE_CREATE_CONTRACT_HEADER = new MessageKey("MESSAGE_AGRID_0010");
    
    public static final MessageKey MANDATORY_INPUT_MISSING_WHILE_CREATE_CONTRACTHEADER = new MessageKey("MESSAGE_AGRID_0011");
    
    public static final MessageKey INVALID_LENGTH_PRODUCTID_IN_INPUT_CREATE_CONTRACTHEADER = new MessageKey("MESSAGE_AGRID_0012");
    
    public static final MessageKey INVALID_CHIDPARENT_IN_INPUT_CREATE_CONTRACTHEADER = new MessageKey("MESSAGE_AGRID_0013");
    
    public static final MessageKey INVALID_CONTRACTNR_IN_INPUT_CREATE_CONTRACTHEADER = new MessageKey("MESSAGE_AGRID_0014");
    
    public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVING_BB_DETAILS = new MessageKey("MESSAGE_AGRID_0015");
    
    public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVING_BB_DETAILS = new MessageKey("MESSAGE_AGRID_0016");
    
    public static final MessageKey INVALID_LENGTH_PRODUCTID_IN_INPUT_UPDATE_CONTRACTHEADER = new MessageKey("MESSAGE_AGRID_0017");
    
    public static final MessageKey INVALID_CHIDPARENT_IN_INPUT_UPDATE_CONTRACTHEADER = new MessageKey("MESSAGE_AGRID_0018");
    
    public static final MessageKey INVALID_CONTRACTNR_IN_INPUT_UPDATE_CONTRACTHEADER = new MessageKey("MESSAGE_AGRID_0019");
    
    public static final MessageKey INVALID_LENGTH_CHID_IN_INPUT_UPDATE_CONTRACTHEADER = new MessageKey("MESSAGE_AGRID_0020");
    
    public static final MessageKey IMS_EXCEPTION_WHILE_RETRIEVE_BBDETAILS = new MessageKey("MESSAGE_AGRID_0021");
    
    public static final MessageKey NULL_INPUT_WHILE_UPDATE_CONTRACT_HEADER = new MessageKey("MESSAGE_AGRID_0022");

    public static final MessageKey RSLT_CODE_FAILURE = new MessageKey("MESSAGE_AGRID_0023");
	
	
}
