package com.abnamro.moa.services.agreementidentifier.configuration;


/**
 * This is a bean to store request scope objects
 */
public class RequestScopeBeans {
	
	private String traceId;

	public String getTraceId() {
		return traceId;
	}

	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}
	
	
}
