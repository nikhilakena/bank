package com.abnamro.moa.services.agreementidentifier.constants;

/**
 * 
 * This is the constant class for the AgreementIdentifier API
 */
public class AgreementIdentifierConstants {
	/**
	 * The type of the responsible party.
	 */

	/**
	 * The type of the bank of the responsible party.
	 */
	public static final String CODE_LABEL = "_code";
	
	public static final String MESSAGE_LABEL = "_message";

	public static final String CONNECT_URL = "url";
	
	public static final String INTERNAL_SERVER_ERRROR = "500";
	
	public static final int INTERNAL_SERVER_ERRROR_HTTP_STATUS = 500;

    public static final String LOG_AGREEMENT_IDENTIFIER_EXCEPTION_IN_RESERVECIN_IN_CONTROLLER = "LOG_AGIDAPI_001";
	
    public static final String IDENTIFIER_API_CIN = "APICIN";

}