package com.abnamro.pna.restservices.customeragreements.dao;

import java.util.HashMap;
import java.util.List;

import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsDB2DAO;
import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsView;
import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;

/**
 * @author C23597 This class modifies the product details for the retrieve
 *         customer agreements operation
 */
public class ProductDetailsEnricher {

	private ProductDetailsDB2DAO productDetailsDB2DAO = new ProductDetailsDB2DAO();

	/**
	 * This method retrieves the product details from dao layer then it populate the
	 * order and IBAN indicator for it.
	 * 
	 * @return hashmap of product id as key and Product details as value
	 * @throws CustomerAgreementsApplicationException in case of errors
	 * @throws ProductDetailsProviderException        in case of exception in
	 *                                                ProductDetailsProvider
	 */
	public HashMap<Integer, ProductDetailsView> getProductDetailsForCaching()
			throws CustomerAgreementsApplicationException, ProductDetailsProviderException {

		List<ProductDetailsView> productDetailsView = productDetailsDB2DAO.readProductDetails();
		HashMap<Integer, ProductDetailsView> productCache = populateOrderNo(productDetailsView);
		populateIBANIndicator(productDetailsView);
		return productCache;
	}

	/**
	 * This method set IBAN indicator true if the product group is 144.
	 */
	private void populateIBANIndicator(List<ProductDetailsView> productDetailsViewList) {
		for (ProductDetailsView productDetailsView : productDetailsViewList) {
			if (productDetailsView.getProductGroupList() != null && !productDetailsView.getProductGroupList().isEmpty()
					&& productDetailsView.getProductGroupList().contains(144)) {
				productDetailsView.setIbanIndicator(true);
			}
		}
	}

	/**
	 * This method populates the order no for based on product groups
	 */
	private HashMap<Integer, ProductDetailsView> populateOrderNo(List<ProductDetailsView> productDetailsView)
			throws CustomerAgreementsApplicationException {
		HashMap<Integer, ProductDetailsView> productCacheHashMap = new HashMap<Integer, ProductDetailsView>();
		ProductGroupPriorityLoader loader = ProductGroupPriorityLoader.getInstance();
		List<Integer> productGroupPriorityList = loader.getProductGroupPriorityList();
		for (ProductDetailsView productDetails : productDetailsView) {
			if (productDetails != null && productDetails.getProductId() > 0) {
				if (productDetails.getProductGroupList() != null && !productDetails.getProductGroupList().isEmpty()) {
					productDetails.setOrderId(getOrderIdFromProductGroup(productDetails, productGroupPriorityList));
				} else {
					productDetails.setOrderId(20);
				}
				productCacheHashMap.put(productDetails.getProductId(), productDetails);
			}
		}
		return productCacheHashMap;
	}

	private int getOrderIdFromProductGroup(ProductDetailsView productDetails, List<Integer> productGroupPriorityList)
			throws CustomerAgreementsApplicationException {

		for (int i = 0; i < productGroupPriorityList.size(); i++) {
			if (productDetails.getProductGroupList().contains(productGroupPriorityList.get(i))) {
				return i;
			}
		}

		return 20;
	}
}