package com.abnamro.pna.restservices.customeragreements.service;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.logging.log4j2.interceptors.LogInterceptorBinding;
import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;
import com.abnamro.pna.restservices.customeragreements.dtos.RetriveCustomerAgreementsOutput;
import com.abnamro.pna.restservices.customeragreements.dtos.v2.RetrieveCustomerAgreementsOutputV2;
import com.abnamro.pna.restservices.customeragreements.dtos.v3.RetrieveCustomerAgreementsOutputV3;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;
import com.abnamro.pna.restservices.customeragreements.exceptions.Error;
import com.abnamro.pna.restservices.customeragreements.exceptions.Errors;
import com.abnamro.pna.restservices.customeragreements.requestprocessor.RetrieveCustomerAgreementsRequestProcessor;
import com.abnamro.pna.restservices.customeragreements.requestprocessor.RetrieveCustomerAgreementsRequestProcessorV3;
import com.abnamro.pna.restservices.customeragreements.service.constants.CustomerAgreementsConstants;
import com.abnamro.pna.restservices.customeragreements.service.constants.CustomerAgreementsLogConstants;
import com.abnamro.pna.restservices.customeragreements.service.utils.CustomerAgreementsValidatorUtils;

/**
 * @author C23597 This is rest service class for the CustomerAgreements service.
 */
@LogInterceptorBinding
@Path("/")
public class CustomerAgreementsRestService {

	// @Inject
	private RetrieveCustomerAgreementsRequestProcessor requestProcessor = new RetrieveCustomerAgreementsRequestProcessor();
	
	// @Inject
    private RetrieveCustomerAgreementsRequestProcessorV3 requestProcessorV3 = new RetrieveCustomerAgreementsRequestProcessorV3();

	// @Inject
	private CustomerAgreementsValidatorUtils util = new CustomerAgreementsValidatorUtils();

	/**
	 * Log instance
	 */
	private static LogHelper logHelper = new LogHelper(CustomerAgreementsRestService.class);

	/**
	 * This method is used to retrieve the customer agreements for input
	 * customer id. It also filter output based on input productGroups
	 * 
	 * @param request
	 *            Http Servlet Request
	 * @param servletContext
	 *            Servle tContext
	 * @param consumerId
	 *            unique value for consumer application calling the API
	 * @param traceId
	 *            Unique end-2-end trace id received from the consumer
	 * @param customerId
	 *            String Business Contact Number
	 * @param productGroups
	 *            list of product groups To filter the customer agreements based
	 *            on the product groups . Can have upto 20 product groups.
	 * @param lastAgreementHeaderId
	 *            String The last(75th) agreement header id in the previous
	 *            response used for pagination purpose.
	 * @return RetriveCustomerAgreementsOutput populated list of customer
	 *         agreements
	 */
	@GET
	@Path("/v1/{customerId}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response getCustomerAgreementList(@Context HttpServletRequest request,
			@Context ServletContext servletContext, @HeaderParam("Consumer-Id") String consumerId,
			@HeaderParam("Trace-Id") String traceId, @PathParam("customerId") String customerId,
			@QueryParam("productGroupId") String[] productGroups,
			@QueryParam("nextPageKey") String lastAgreementHeaderId) {

		final String logMethod = "getCustomerAgreementList(HttpServletRequest, ServletContext, String, String, String, String[], String) :Response";
		RetriveCustomerAgreementsOutput output = null;

		try {
			util.validateConsumerId(consumerId, traceId);
			
			util.validateAuthrization(consumerId,"getCustomerAgreementList","V1",traceId);
			
			// validate customerId
			util.validateCustomerId(customerId, traceId);

			// validate productGroups
			util.validateProductGroups(productGroups, traceId);

			// validate last contract header id
			util.validateLastContractHeaderId(lastAgreementHeaderId, traceId);

			// Forwarding request to request processor
			output = requestProcessor.retriveCustomerAgreements(customerId, productGroups, lastAgreementHeaderId,
					traceId);

		} catch (CustomerAgreementsApplicationException | ProductDetailsProviderException applicationException) {
			logHelper.error(logMethod, CustomerAgreementsLogConstants.LOG_EXCEPTION_IN_GETCUSTOMERAGREEMENTLIST,
					applicationException);
			Errors errors = new Errors();
			Error error = new Error();
			error.setCode(CustomerAgreementsConstants.CODE_TECHNICAL_ERROR);
			error.setMessage(CustomerAgreementsConstants.DESC_TECHNICAL_ERROR);
			error.setStatus(CustomerAgreementsConstants.RESPONSE_STATUS_500);
			error.setTraceId(traceId);

			if (applicationException.getMessages() != null
					&& applicationException.getMessages().getMessages() != null) {
				String[] params = new String[applicationException.getMessages().getMessages().size()];
				for (int i = 0; i < applicationException.getMessages().getMessages().size(); i++) {
					params[i] = applicationException.getMessages().getMessages().get(i).getMessageKeyId();
				}
				error.setParams(params);
			}

			errors.getError().add(error);
			throw new WebApplicationException(Response.status(Status.INTERNAL_SERVER_ERROR)
					.type(CustomerAgreementsConstants.MEDIA_TYPE).entity(errors).build());
		}
		
		if(output==null){
			util.handleValidationError(CustomerAgreementsConstants.CODE_RESOURCE_NOT_FOUND, CustomerAgreementsConstants.DESC_RESOURCE_NOT_FOUND, traceId, null);
		}
		return Response.status(Status.OK).entity(output).build();
	}

	/**
	 * This method is used to retrieve the customer agreements for input
	 * customer id. It also filter output based on input productGroups
	 * 
	 * @param request
	 *            Http Servlet Request
	 * @param servletContext
	 *            Servle tContext
	 * @param consumerId
	 *            unique value for consumer application calling the API
	 * @param traceId
	 *            Unique end-2-end trace id received from the consumer
	 * @param customerId
	 *            String Business Contact Number
	 * @param productGroupParameters
	 *            list of product groups To filter the customer agreements based
	 *            on the product groups . Can have upto 20 product groups.
	 * @param lastAgreementHeaderId
	 *            String The last(75th) agreement header id in the previous
	 *            response used for pagination purpose.
	 * @return RetriveCustomerAgreementsOutput populated list of customer
	 *         agreements
	 */
	@GET
	@Path("/v2/{customerId}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response getCustomerAgreementListV2(@Context HttpServletRequest request,
			@Context ServletContext servletContext, @HeaderParam("Consumer-Id") String consumerId,
			@HeaderParam("Trace-Id") String traceId, @PathParam("customerId") String customerId,
			@QueryParam("productGroupIds") String[] productGroupParameters,
			@QueryParam("nextPageKey") String lastAgreementHeaderId) {

		final String logMethod = "getCustomerAgreementListV2(HttpServletRequest, ServletContext, String, String, String, String[], String) :Response";
		RetrieveCustomerAgreementsOutputV2 output = null;

		try {
			
			// validate customerId
			util.validateCustomerId(customerId, traceId);

			// validate productGroups
			util.validateProductGroupsV2(productGroupParameters, traceId);
			Integer[] productGroups = convertTextsToNumbers(productGroupParameters);

			// validate last contract header id
			util.validateLastContractHeaderId(lastAgreementHeaderId, traceId);

			// Forwarding request to request processor
			output = requestProcessor.retrieveCustomerAgreementsV2(customerId, productGroups, lastAgreementHeaderId,
					traceId);

		} catch (CustomerAgreementsApplicationException | ProductDetailsProviderException applicationException) {
			logHelper.error(logMethod, CustomerAgreementsLogConstants.LOG_EXCEPTION_IN_GETCUSTOMERAGREEMENTLIST,
					applicationException);
			Errors errors = new Errors();
			Error error = new Error();
			error.setCode(CustomerAgreementsConstants.CODE_INTERNAL_SERVER_ERROR);
			error.setMessage(CustomerAgreementsConstants.DESC_INTERNAL_SERVER_ERROR);
			error.setStatus(CustomerAgreementsConstants.RESPONSE_STATUS_500);
			error.setTraceId(traceId);

			if (applicationException.getMessages() != null
					&& applicationException.getMessages().getMessages() != null) {
				String[] params = new String[applicationException.getMessages().getMessages().size()];
				for (int i = 0; i < applicationException.getMessages().getMessages().size(); i++) {
					params[i] = applicationException.getMessages().getMessages().get(i).getMessageKeyId();
				}
				error.setParams(params);
			}

			errors.getError().add(error);
			throw new WebApplicationException(Response.status(Status.INTERNAL_SERVER_ERROR)
					.type(CustomerAgreementsConstants.MEDIA_TYPE).entity(errors).build());
		}

		return Response.status(Status.OK).entity(output).build();
	}

	/**
	 * Convert each text from the given array into a number and return it as an array of numbers.
	 * Assume the given array is validated.
	 */
	private Integer[] convertTextsToNumbers(String[] texts) {
		Integer[] numbers = null;
		String logMethod = "convertTextsToNumbers(String[]):Integer[]";
		if (texts != null) {
			numbers = new Integer[texts.length];

			for (int index = 0; index < texts.length; index++) {
				try {
					Integer number = Integer.parseInt(texts[index]);
					numbers[index] = number;
				} catch (NumberFormatException exception) {
				  logHelper.error(logMethod, CustomerAgreementsLogConstants.NON_NUMERIC_PRODUCT_GROUP, exception);
				}
			}
		}

		return numbers;
	}
	
	/**
     * This method is used to retrieve the customer agreements for input
     * customer id. It also filter output based on input productGroups
     * 
     * @param request
     *            Http Servlet Request
     * @param servletContext
     *            ServletContext
     * @param consumerId
     *            unique value for consumer application calling the API
     * @param traceId
     *            Unique end-2-end trace id received from the consumer
     * @param preferredLanguage
     *            that represents the preferred language of the returned values
     * @param customerId
     *            Integer Business Contact Number           
     * @param productGroupParameters
     *            list of product groups To filter the customer agreements based
     *            on the product groups . Can have upto 20 product groups.
     * @param lastAgreementHeaderId
     *            String The last(75th) agreement header id in the previous
     *            response used for pagination purpose.
     * @return RetriveCustomerAgreementsOutput populated list of customer
     *         agreements
     */
	@GET
    @Path("/v3/{customerId}")
    @Produces({ MediaType.APPLICATION_JSON })
    public Response getCustomerAgreementListV3(@Context HttpServletRequest request,
            @Context ServletContext servletContext, @HeaderParam("Consumer-Id") String consumerId,
            @HeaderParam("Trace-Id") String traceId, @HeaderParam("Accept-Language") String preferredLanguage, @PathParam("customerId") Integer customerId,
            @QueryParam("productGroupIds") String[] productGroupParameters,
            @QueryParam("nextPageKey") String lastAgreementHeaderId) {

        final String logMethod = "getCustomerAgreementListV3(HttpServletRequest, ServletContext, String, String, String, String[], String) :Response";
        RetrieveCustomerAgreementsOutputV3 output = null;

        try {
            
            // validate customerId
            util.validateCustomerIdFormat(customerId, traceId);
            
            // validate the requested language parameter
            String language = util.validateLanguageInput(preferredLanguage, traceId);
            
            // validate productGroups reused method for V3 version too since V3 is created only for language input.
            util.validateProductGroupsV2(productGroupParameters, traceId);
            Integer[] productGroups = convertTextsToNumbers(productGroupParameters);

            // validate last contract header id
            util.validateLastContractHeaderId(lastAgreementHeaderId, traceId);

            // Forwarding request to request processor
            output = requestProcessorV3.retrieveCustomerAgreementsV3(customerId.toString(), productGroups, lastAgreementHeaderId,
                    traceId, language);

        } catch (CustomerAgreementsApplicationException | ProductDetailsProviderException applicationException) {
            logHelper.error(logMethod, CustomerAgreementsLogConstants.LOG_EXCEPTION_IN_GETCUSTOMERAGREEMENTLIST,
                    applicationException);
            Errors errors = new Errors();
            Error error = new Error();
            error.setCode(CustomerAgreementsConstants.CODE_INTERNAL_SERVER_ERROR);
            error.setMessage(CustomerAgreementsConstants.DESC_INTERNAL_SERVER_ERROR);
            error.setStatus(CustomerAgreementsConstants.RESPONSE_STATUS_500);
            error.setTraceId(traceId);

            if (applicationException.getMessages() != null
                    && applicationException.getMessages().getMessages() != null) {
                String[] params = new String[applicationException.getMessages().getMessages().size()];
                for (int i = 0; i < applicationException.getMessages().getMessages().size(); i++) {
                    params[i] = applicationException.getMessages().getMessages().get(i).getMessageKeyId();
                }
                error.setParams(params);
            }

            errors.getError().add(error);
            throw new WebApplicationException(Response.status(Status.INTERNAL_SERVER_ERROR)
                    .type(CustomerAgreementsConstants.MEDIA_TYPE).entity(errors).build());
        }

        return Response.status(Status.OK).entity(output).build();
    }
}