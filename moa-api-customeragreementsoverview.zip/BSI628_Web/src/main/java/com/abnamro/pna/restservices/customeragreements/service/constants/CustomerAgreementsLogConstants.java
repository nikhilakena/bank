package com.abnamro.pna.restservices.customeragreements.service.constants;

/**
 * This class contains Log constants used for CustomerAgreements
 * @author C36098
 */
public final class CustomerAgreementsLogConstants {
	private CustomerAgreementsLogConstants() {
	}

  public static final String NON_NUMERIC_CUSTOMER_ID = "LOG_BS628RE_001";
  
  public static final String NON_NUMERIC_PRODUCT_GROUP = "LOG_BS628RE_002";

  public static final String NON_NUMERIC_VALUE = "LOG_BS628RE_003";
  
  public static final String LOG_EXCEPTION_IN_GETCUSTOMERAGREEMENTLIST= "LOG_BS628RE_004";
  
  public static final String LOG_EXCEPTION_IN_EXCEPTIONMAPPER= "LOG_BS628RE_005";

  public static final String MORE_THAN_20_PRODUCT_GROUPS_PROVIDED = "LOG_BS628RE_006";
  
  public static final String CONSUMERID_AUTHORIZATION_FAILURE = "LOG_BS628RE_007";

}
