package com.abnamro.pna.restservices.customeragreements.dtos;

import java.util.List;

import com.abnamro.nl.dto.util.AbstractDTO;

/**
 * @author C36098 This class contains the attributes of agreements of a customer.
 */
public class Agreement extends AbstractDTO {

  private static final long serialVersionUID = 1L;

  /**
   * Agreement identifier.Format: IBAN ex. NL07ABNA0246836431
   */
  private String agreementId;

  /**
   * It contains Commercial contract number
   */
  private String commercialContractNumber;


  /**
   * It contains specific state of existence for an agreement.EX. Active, InActive
   */
  private String agreementLifeCycleStatusType;

  /**
   * It contains nickname of an agreement.EX. PENSIOEN AANVULLING INBRENG
   */
  private String nickName;

  /**
   * It is a combination of building block Id and commercial contract number.
   */
  private List<String> agreementAdministrationKey;

  private ProductDetailsDTO product;

  public String getAgreementId() {
    return agreementId;
  }

  public void setAgreementId(String agreementId) {
    this.agreementId = agreementId;
  }

  public String getCommercialContractNumber() {
    return commercialContractNumber;
  }

  public void setCommercialContractNumber(String commercialContractNumber) {
    this.commercialContractNumber = commercialContractNumber;
  }

  public String getAgreementLifeCycleStatusType() {
    return agreementLifeCycleStatusType;
  }

  public void setAgreementLifeCycleStatusType(String agreementLifeCycleStatusType) {
    this.agreementLifeCycleStatusType = agreementLifeCycleStatusType;
  }

  public String getNickName() {
    return nickName;
  }

  public void setNickName(String nickName) {
    this.nickName = nickName;
  }

  public List<String> getAgreementAdministrationKey() {
    return agreementAdministrationKey;
  }

  public void setAgreementAdministrationKey(List<String> agreementAdministrationKey) {
    this.agreementAdministrationKey = agreementAdministrationKey;
  }

  public ProductDetailsDTO getProduct() {
    return product;
  }

  public void setProduct(ProductDetailsDTO product) {
    this.product = product;
  }



}
