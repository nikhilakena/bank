package com.abnamro.pna.restservices.customeragreements.health;

import com.abnamro.nl.health.AbstractHealthCheckServlet;
import com.abnamro.nl.health.exceptions.HealthCheckException;

/**
 * This servlet will be called by the load balancer to see whether the
 * connections to is healthy.
 * 
 * @author C23597
 */ 
public class HealthCheckServlet extends AbstractHealthCheckServlet {

	/**
	 * This used for serialization purpose
	 */
	private static final long serialVersionUID = 1L;
		

	@Override
	protected boolean isHealthy() throws HealthCheckException {		
		return true;
	}

}

