package com.abnamro.pna.restservices.customeragreements.service.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.pna.restservices.customeragreements.cachehandler.CacheCollector;
import com.abnamro.pna.restservices.customeragreements.dao.CustomerAgreementsDB2DAO;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;
import com.abnamro.pna.restservices.customeragreements.exceptions.Error;
import com.abnamro.pna.restservices.customeragreements.exceptions.Errors;
import com.abnamro.pna.restservices.customeragreements.service.constants.CustomerAgreementsConstants;
import com.abnamro.pna.restservices.customeragreements.service.constants.CustomerAgreementsLogConstants;

/**
 * This is validator class for retrieveCustomerAgreements service operation.
 */
public class CustomerAgreementsValidatorUtils {
	
	 private CustomerAgreementsDB2DAO customerAgreementsDB2DAO = new CustomerAgreementsDB2DAO();

	/**
	 * Log instance
	 */
	private static LogHelper logHelper = new LogHelper(CustomerAgreementsValidatorUtils.class);

	/**
	 * This method throws exception if customerId is empty customerId is having
	 * length greater than 12 customerId is non numeric
	 * 
	 * @param customerId
	 *            String customer id(BC Number)
	 * @param traceId
	 *            Unique end-2-end trace id received from the consumer
	 */
	public void validateCustomerId(String customerId, String traceId) {

		String logMethod = "validateCustomerId:customerId";

		boolean flag = false;
		if (customerId != null && !customerId.isEmpty() && customerId.length() <= 12) {
			try {
				Long.parseLong(customerId);
				flag = true;
			} catch (NumberFormatException nfe) {
				logHelper.error(logMethod, CustomerAgreementsLogConstants.NON_NUMERIC_CUSTOMER_ID, nfe);
			}
		}

		if (!flag) {
			handleValidationError(CustomerAgreementsConstants.CODE_CUSTOMER_ID_INVALID,
					CustomerAgreementsConstants.DESC_CUSTOMER_ID_INVALID, traceId,
					new String[] { CustomerAgreementsLogConstants.NON_NUMERIC_CUSTOMER_ID });
		}
	}
	
	
    /**
     * This method throws exception if customerId is invalid
     * @param customerId
                 String customer id(BC Number)
     * @param traceId
     *            Unique end-2-end trace id received from the consumer
     * @param traceId
     */
    public void validateCustomerIdFormat(Integer customerId, String traceId) {

        boolean flag = false;
        if (customerId >0 && customerId.toString().length() <=12) {
            flag = true;
        }
        if (!flag) {
            handleValidationError(CustomerAgreementsConstants.CODE_CUSTOMER_ID_INVALID,
                    CustomerAgreementsConstants.DESC_CUSTOMER_ID_INVALID, traceId,
                    new String[] { CustomerAgreementsLogConstants.NON_NUMERIC_CUSTOMER_ID });
        }
    }

	/**
	 * This method throws exception if non numeric data is present in product
	 * groups
	 * 
	 * @param productGroups
	 *            list of product groups
	 * @param traceId
	 *            Unique end-2-end trace id received from the consumer
	 */
	public void validateProductGroups(String[] productGroups, String traceId) {

		String logMethod = "validateProductGroups:productGroups";

		boolean flag = false;
		if (productGroups != null && productGroups.length > 0) {
			try {
				for (String productGroup : productGroups) {
					Integer.parseInt(productGroup);
				}
				flag = true;
			} catch (NumberFormatException nfe) {
				logHelper.error(logMethod, CustomerAgreementsLogConstants.NON_NUMERIC_PRODUCT_GROUP, nfe);
			}
		}
		if (productGroups == null || productGroups.length <= 0) {
			flag = true;
		}
		if (!flag) {
			logHelper.error(logMethod, CustomerAgreementsLogConstants.NON_NUMERIC_PRODUCT_GROUP);
			handleValidationError(CustomerAgreementsConstants.CODE_PRODUCT_GROUP_ID_INVALID,
					CustomerAgreementsConstants.DESC_PRODUCT_GROUP_ID_INVALID, traceId,
					new String[] { CustomerAgreementsLogConstants.NON_NUMERIC_PRODUCT_GROUP });
		}
		if(productGroups != null && productGroups.length > 20){
			logHelper.error(logMethod, CustomerAgreementsLogConstants.MORE_THAN_20_PRODUCT_GROUPS_PROVIDED);
			handleValidationError(CustomerAgreementsConstants.CODE_MORE_THAN_20_PRODUCT_GROUPS_PROVIDED,
					CustomerAgreementsConstants.DESC_MORE_THAN_20_PRODUCT_GROUPS_PROVIDED, traceId,
					new String[] { CustomerAgreementsLogConstants.MORE_THAN_20_PRODUCT_GROUPS_PROVIDED });
		}
	}

	/**
	 * This method throws exception if non numeric data is present in product
	 * groups
	 * 
	 * @param productGroups
	 *            list of product groups
	 * @param traceId
	 *            Unique end-2-end trace id received from the consumer
	 */
	public void validateProductGroupsV2(String[] productGroups, String traceId) {
		String logMethod = "validateProductGroupsV2:productGroups";

		List<String> invalidProductGroupIds = new ArrayList<>();
		if (productGroups != null && productGroups.length > 0) {

			// validate each product group id, save the invalid ids
			for (String productGroup : productGroups) {
				boolean validProductGroup = true;

				// check product group id to not exceed maximum length, max = 4 digits
				validProductGroup = productGroup.length() <= 4;

				// check the product group id is a number
				if (validProductGroup) {
					validProductGroup = isNumber(productGroup);
				}

				if (!validProductGroup) {
					invalidProductGroupIds.add(productGroup);
				}
			}
		}

		if (!invalidProductGroupIds.isEmpty()) {
			logHelper.error(logMethod, CustomerAgreementsLogConstants.NON_NUMERIC_PRODUCT_GROUP);

			// store invalid product group ids in array
			String[] invalidProductGroupIdParameters = new String[invalidProductGroupIds.size()];
			invalidProductGroupIds.toArray(invalidProductGroupIdParameters);

			handleValidationError(CustomerAgreementsConstants.CODE_PRODUCT_GROUP_IDS_INVALID,
					CustomerAgreementsConstants.DESC_PRODUCT_GROUP_IDS_INVALID, traceId,
					invalidProductGroupIdParameters);
		}

		if(productGroups != null && productGroups.length > 20){
			logHelper.error(logMethod, CustomerAgreementsLogConstants.MORE_THAN_20_PRODUCT_GROUPS_PROVIDED);
			handleValidationError(CustomerAgreementsConstants.CODE_MORE_THAN_20_PRODUCT_GROUPS_PROVIDED,
					CustomerAgreementsConstants.DESC_MORE_THAN_20_PRODUCT_GROUPS_PROVIDED, traceId,
					new String[] { CustomerAgreementsLogConstants.MORE_THAN_20_PRODUCT_GROUPS_PROVIDED });
		}
	}

	/**
	 * This method throws exception if invalid data format for contract header
	 * id(when filled must have format XXX999999)
	 * 
	 * 
	 * @param lastContractHeaderId
	 *            contract header id from which next set of records needs to be
	 *            returned
	 * @param traceId  Unique end-2-end trace id received from the consumer
	 */
	public void validateLastContractHeaderId(String lastContractHeaderId, String traceId) {
		String logMethod = "validateLastContractHeaderId:lastContractHeaderId";

		boolean flag = false;
		if (lastContractHeaderId != null && !lastContractHeaderId.isEmpty() && lastContractHeaderId.length() == 9) {
			String alphabeticHalf = lastContractHeaderId.substring(0, 2);
			String numericHalf = lastContractHeaderId.substring(3);
			try {
				Long.parseLong(numericHalf);
				flag = true;
			} catch (NumberFormatException nfe) {
				logHelper.error(logMethod, CustomerAgreementsLogConstants.NON_NUMERIC_VALUE, nfe);
			}
			if (flag && alphabeticHalf.matches("[a-zA-Z]+")) {
				flag = true;
			} else {
				flag = false;
			}

		}

		if (lastContractHeaderId != null && !flag) {
			logHelper.error(logMethod, CustomerAgreementsLogConstants.NON_NUMERIC_VALUE);
			handleValidationError(CustomerAgreementsConstants.CODE_LAST_AGREEMENT_HEADER_ID_INVALID,
					CustomerAgreementsConstants.DESC_LAST_AGREEMENT_HEADER_ID_INVALID, traceId,
					new String[] { CustomerAgreementsLogConstants.NON_NUMERIC_VALUE });
		}
	}

	/**
	 * This method is used to throw an exception in case of validation errors
	 *  
	 * @param code it is the error code to be returned
	 * @param message it is the error message to be returned
	 * @param traceId it is the unique id of the input request
	 * @param paramInfo additional parameters to be passed in case of exceptions
	 */
	public void handleValidationError(String code, String message, String traceId, String[] paramInfo) {
		Errors errors = new Errors();
		Error error = new Error();
		error.setCode(code);
		error.setTraceId(traceId);
		error.setMessage(message);
		if(CustomerAgreementsConstants.CODE_RESOURCE_NOT_FOUND.equals(code)){
			error.setStatus(CustomerAgreementsConstants.RESPONSE_STATUS_404);
		}else{
			error.setStatus(CustomerAgreementsConstants.RESPONSE_STATUS_400);
		}
		error.setParams(paramInfo);
		errors.getError().add(error);
		if(CustomerAgreementsConstants.CODE_RESOURCE_NOT_FOUND.equals(code)){
			throw new WebApplicationException(Response.status(Status.NOT_FOUND).type(CustomerAgreementsConstants.MEDIA_TYPE).entity(errors).build());
		}else{
			throw new WebApplicationException(Response.status(Status.BAD_REQUEST).type(CustomerAgreementsConstants.MEDIA_TYPE).entity(errors).build());
		}
	}

	/**
	 * This method is used to validate the input consumer id against the cache or database.
	 * 
	 * @param consumerId consumer Id of the input request
	 * @param operation operation Id of the service
	 * @param version version of the operation
	 * @param traceId Unique end-2-end trace id received from the consumer
	 * @return returns true if valid user
	 * @throws CustomerAgreementsApplicationException in case of database exception
	 */
	public boolean validateAuthrization(String consumerId, String operation, String version, String traceId) throws CustomerAgreementsApplicationException {
		String logMethod = "validateAuthrization(String,String,String,String):boolean";
		boolean validUser =false;
		if(StringUtils.isNotBlank(consumerId)){
			Date authDate = null;
			String authKey = consumerId + CustomerAgreementsConstants.UNDERSCORE + operation + CustomerAgreementsConstants.UNDERSCORE + version;
			if(CacheCollector.getAuthCache().get(authKey)!=null){
				authDate = CacheCollector.getAuthCache().get(authKey);
			}
			if(authDate==null || !DateUtils.isSameDay(authDate,new Date())){
				boolean isAuthorised = customerAgreementsDB2DAO.isAuthorizedConsumer(consumerId, operation, version);
				if(isAuthorised){
					validUser =true;
					CacheCollector.setAuthCache(authKey, new Date());
				}
			}else {
				validUser =true;
			}
		}
		if(!validUser){
			logHelper.error(logMethod, CustomerAgreementsLogConstants.CONSUMERID_AUTHORIZATION_FAILURE);
			throwUnauthorizationException(traceId,consumerId);
		}
		return validUser;
	}

	private void throwUnauthorizationException(String traceId, String consumerId) {
		Errors errors = new Errors();
		Error error = new Error();
		error.setCode(CustomerAgreementsConstants.CODE_AUTHORIZATION_FAILURE);
		error.setTraceId(traceId);
		error.setMessage(CustomerAgreementsConstants.DESC_AUTHORIZATION_FAILURE);
		error.setStatus(CustomerAgreementsConstants.RESPONSE_STATUS_401);
		error.setParams(new String[] {consumerId});
		errors.getError().add(error);
		throw new WebApplicationException(Response.status(Status.UNAUTHORIZED).type(CustomerAgreementsConstants.MEDIA_TYPE).entity(errors).build());		
	}

	/**
	 * This method is used to validate input consumer Id
	 * 
	 * @param consumerId consumer Id of the input request
	 * @param traceId Unique end-2-end trace id received from the consumer
	 */
	public void validateConsumerId(String consumerId, String traceId) {
		if ("".equals(consumerId)) {
			handleValidationError(CustomerAgreementsConstants.CODE_CONSUMER_ID_NOT_PROVIDED,
					CustomerAgreementsConstants.DESC_CONSUMER_ID_NOT_PROVIDED, traceId,
					null);
		}
		
		if(consumerId!=null && consumerId.length()>20){
			handleValidationError(CustomerAgreementsConstants.CODE_CONSUMER_ID_INVALID,
					CustomerAgreementsConstants.DESC_CONSUMER_ID_INVALID, traceId,
					new String[]{consumerId});
		}
	}

	/**
	 * Return true if the given text is a numeric value.
	 * @param text - the text to check for a numberic value.
	 * @return the result of the numeric check.
	 */
	private boolean isNumber(String text) {
    	boolean isNumber = true;

		try {
			Integer.parseInt(text);
		} catch(NumberFormatException exception) {
			isNumber = false;
		}

    	return isNumber;
	}
	
	/**
     * Validate the language code from the input. Supported values are 'NL' (Dutch) and 'EN' (English). The code 'NL' is the default value.
     * @param languageCode - a 2 character code that represents a language
     * @param traceId - an end to end identification of a call
     * @return the validated language code
     */
    public String validateLanguageInput(String languageCode, String traceId) {
        String validatedLanguageCode = "NL";

        if (languageCode != null) {
            if ("NL".equals(languageCode) || "EN".equals(languageCode)) {
                validatedLanguageCode = languageCode;
            } else {
                handleNotAcceptableError(traceId);
            }
        }

        return validatedLanguageCode;
    }
    
    /**
     * This method is used to throw an exception in case of unacceptable value in the request.
     * @param traceId - it is the unique id of the input request
     */
    
    public void handleNotAcceptableError(String traceId) {
        
        Errors errors = new Errors();
        Error error = new Error();
        error.setCode(CustomerAgreementsConstants.CODE_REQUESTED_LANGUAGE_NOT_SUPPORTED);
        error.setTraceId(traceId);
        error.setMessage(CustomerAgreementsConstants.DESC_REQUESTED_LANGUAGE_NOT_SUPPORTED);
        error.setStatus(CustomerAgreementsConstants.RESPONSE_STATUS_406);
        errors.getError().add(error);
        
        throw new WebApplicationException(Response.status(Status.NOT_ACCEPTABLE).type(CustomerAgreementsConstants.MEDIA_TYPE).entity(errors).build());
    }
}
