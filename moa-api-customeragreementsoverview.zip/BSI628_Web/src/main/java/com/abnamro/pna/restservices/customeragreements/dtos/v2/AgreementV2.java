package com.abnamro.pna.restservices.customeragreements.dtos.v2;

import java.util.List;
import com.abnamro.nl.dto.util.AbstractDTO;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 * @author PA2619
 * This class contains the attributes of agreements of a customer for customerAgreementAPI Version 2.
 */
public class AgreementV2 extends AbstractDTO {

  private static final long serialVersionUID = 1L;

  /**
   * Agreement identifier.Format: IBAN ex. NL07ABNA0246836431
   */
  private String iban;

  /**
   * It contains Commercial contract number
   */
  private String agreementId;


  /**
   * It contains specific state of existence for an agreement.EX. Active, InActive
   */
  private String lifecycleStatus;

  /**
   * It contains nickname of an agreement.EX. PENSIOEN AANVULLING INBRENG
   */
  private String nickName;

  /**
   * It is a combination of building block Id and commercial contract number.
   */
  private List<String> agreementAdministrationKeys;

  /**
   * Identifier of the product according to the centrally managed ABNAMRO product list.
   */
  private Integer productId;

  /**
   * Internal name of a product.ex. Toegangscontract
   */
  private String internalProductNameNL;

  /**
   * External name of a product.ex. Overeenkomst Toegang
   */
  private String commercialProductNameNL;

  /**
   * Identifies the product groups in AAB.e.g.1. Pakketten - productGroupId is 92. 2.
   * Betaalrekeningen - productGroupId is 93.
   */
  private List<Integer> productGroupIds;
  
  /**
   * AgreementId of the package which this agreement is part of.(chIdParent)
   * ex. HHI030210  
   */
  private String packageAgreementId;

  public String getAgreementId() {
    return agreementId;
  }

  public void setAgreementId(String agreementId) {
    this.agreementId = agreementId;
  }

  public String getLifecycleStatus() {
    return lifecycleStatus;
  }

  public void setLifecycleStatus(String lifecycleStatus) {
    this.lifecycleStatus = lifecycleStatus;
  }

  public String getNickName() {
    return nickName;
  }

  public void setNickName(String nickName) {
    this.nickName = nickName;
  }

  public List<String> getAgreementAdministrationKeys() {
    return agreementAdministrationKeys;
  }

  public void setAgreementAdministrationKeys(List<String> agreementAdministrationKeys) {
    this.agreementAdministrationKeys = agreementAdministrationKeys;
  }

  public Integer getProductId() {
    return productId;
  }

  public void setProductId(Integer productId) {
    this.productId = productId;
  }

  public List<Integer> getProductGroupIds() {
    return productGroupIds;
  }

  public void setProductGroupIds(List<Integer> productGroupId) {
    this.productGroupIds = productGroupId;
  }

  public String getCommercialProductNameNL() {
    return commercialProductNameNL;
  }

  public void setCommercialProductNameNL(String commercialProductNameNL) {
    this.commercialProductNameNL = commercialProductNameNL;
  }

  public String getInternalProductNameNL() {
    return internalProductNameNL;
  }

  public void setInternalProductNameNL(String internalProductNameNL) {
    this.internalProductNameNL = internalProductNameNL;
  }

  @JsonProperty("IBAN")
  public String getIban() {
    return iban;
  }

  public void setIban(String iban) {
    this.iban = iban;
  }

/**
 * @return the packageAgreementId
 */
public String getPackageAgreementId() {
	return packageAgreementId;
}

/**
 * @param packageAgreementId the packageAgreementId to set
 */
public void setPackageAgreementId(String packageAgreementId) {
	this.packageAgreementId = packageAgreementId;
}




}
