package com.abnamro.pna.restservices.customeragreements.dao;

/**
* 
* <br>This is used to store constants DAO layer of FAQ service.<br>
* 
* 
* <PRE>
* 
* Developer		Date				Change Reason		Change
* ---------		----				-------------		------
* TCS			APR 12 2017			Initial Version		PA
* </PRE>
* 
* @author TCS
*/
public final class CustomerAgreementsDAOConstants {
	private CustomerAgreementsDAOConstants() {
	}
	
	public static final String SCHEMA_DATABASE = "SCHEMA_MOA";
	public static final String DEFAULT_DB_SCHEMA = "UU01";
	
	public static final String DATASOURCE_NAME = "MOADATASOURCE";
	public static final String DEFAULT_DATASOURCE = "jdbc/MOA_DataSource";
	
}
