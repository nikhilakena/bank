package com.abnamro.pna.restservices.customeragreements.cachehandler;

import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.logging.log4j2.interceptors.LogInterceptorBinding;

import commonj.timers.Timer;
import commonj.timers.TimerListener;

/**
 * This class implements the TimerListener class of commonj.timers for caching product details.
 * 
 * @author PA2619
 *
 */
@LogInterceptorBinding
public class CacheHandlerPoller implements TimerListener {

  /**
   * Instantiate the Logger
   */
  private static LogHelper logHelper = new LogHelper(CacheHandlerPoller.class);

  /**
   * {@inheritDoc}
   * 
   * @see commonj.timers.TimerListener#timerExpired(commonj.timers.Timer)
   **/
  public void timerExpired(Timer arg0) {
    final String LOG_METHOD = "timerExpired(Timer): void";
    // Check if current time is more than refresh time
    try {
      CacheHandler cacheHandler = CacheHandler.getInstance();
      // Get reload after time
      cacheHandler.refreshCache();
      
    } catch (CacheHandlerException piAutoReInstantiationHandlerException) {
      logHelper.error(LOG_METHOD, CacheHandlerLogConstants.LOG_POLL_TIMEDOUT_REQUESTS_SERVICE_EXCEPTION,
          piAutoReInstantiationHandlerException);
    }


  }

}
