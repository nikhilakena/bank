package com.abnamro.pna.restservices.customeragreements.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.messages.Message;
import com.abnamro.nl.messages.MessageType;
import com.abnamro.nl.messages.Messages;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;
import com.abnamro.pna.restservices.customeragreements.service.constants.CustomerAgreementsMessageKeyConstants;

/**
 * This Class loads the static details of serviceIds and its related error codes from the property file. 
 * @author PA2619
 *
 */
public final class ProductGroupPriorityLoader {
	
	private static ProductGroupPriorityLoader implementationClass = null;
	/**
	 * This map contains the list of services ids with its related error codes
	 */
	private List<Integer> productGroupPriorityList = new ArrayList<>();
	
	/**
	 * Instantiate the Logger 
	 */
	private static LogHelper logger = new LogHelper(ProductGroupPriorityLoader.class);
	
	private void populateErrorCodesMap(Properties properties) {
	    HashMap<Integer,Integer> productGroupPriorityHashMap= new HashMap<>();
	    
		Enumeration<?> e = properties.propertyNames();
		  while (e.hasMoreElements()) {
		    String key = (String)e.nextElement();
            if(StringUtils.isNotBlank(key)){
              Integer productgroup= Integer.parseInt(properties.getProperty(key));
              productGroupPriorityHashMap.put(Integer.parseInt(key),productgroup);
            }
		  }
		  
		  for(int i=0; i<productGroupPriorityHashMap.size();i++){
		    productGroupPriorityList.add(i, productGroupPriorityHashMap.get(i+1));
		  }
	}
	
	/**
	 * Constructor which loads the property file and set the data into hashmap
	 * @throws CustomerAgreementsApplicationException
	 */
	private ProductGroupPriorityLoader() throws CustomerAgreementsApplicationException{
		  final String logMethod = "PIErrorCodesLoader()";
		  Properties properties= new Properties();
		  InputStream inputStream = null;
		  try {
			  inputStream = ProductGroupPriorityLoader.class.getResourceAsStream("/productgrouppriority.properties");
			  if(inputStream != null){
				  properties.load(inputStream);  
				  if(!properties.isEmpty()){
					  populateErrorCodesMap(properties);
				  }
			  }
			  safeClose(inputStream);
		  }catch (IOException e) {
		      safeClose(inputStream);
			  logger.error(logMethod, CustomerAgreementsDAOLogConstants.LOG_ERROR_WHILE_LOADING_STATIC_PRODUCT_GROUP_LIST, e);
			  Messages messages = new Messages();
			  messages.addMessage(new Message(CustomerAgreementsMessageKeyConstants.PRODUCT_GROUP_LOAD_ERROR), MessageType.getError());
			  throw new CustomerAgreementsApplicationException(messages);
		  }
	}
	
	/**
	 * getInstance method to always return single object
	 * @return the synchronized cache object
	 * @throws CustomerAgreementsApplicationException the CustomerAgreementsApplicationException
	 */
	public static synchronized ProductGroupPriorityLoader getInstance() throws CustomerAgreementsApplicationException{
			
		if(implementationClass == null){
				implementationClass = new ProductGroupPriorityLoader();
		}
		return implementationClass;
	}

	public List<Integer> getProductGroupPriorityList() {
		return productGroupPriorityList;
	}
	
	private static void safeClose(InputStream fis) {
	  String logMethod ="safeClose";
	  if (fis != null) {
    	  try {
    	    fis.close();
    	  } catch (IOException e) {
    	    logger.error(logMethod, CustomerAgreementsDAOLogConstants.LOG_ERROR_WHILE_LOADING_STATIC_PRODUCTGROUP_LIST, e);
    	  }
	  }
	}

}
