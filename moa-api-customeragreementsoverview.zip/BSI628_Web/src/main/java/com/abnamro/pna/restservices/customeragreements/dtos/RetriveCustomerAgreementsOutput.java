package com.abnamro.pna.restservices.customeragreements.dtos;

import java.util.List;

import com.abnamro.nl.dto.util.AbstractDTO;

/**
 * @author C36098 This class contains the output for Customer
 *         Agreement(Agreements that a customer possesses in the Bank.)
 */
public class RetriveCustomerAgreementsOutput extends AbstractDTO {

	private static final long serialVersionUID = 1L;

	/**
	 * Identifies a customer.
	 */
	private String customerId;

	private List<Agreement> agreements;

	/**
	 * Total number of agreements of a customer.
	 */
	private int numberOfAgreements;

	/**
	 * Populated with last agreement header ID. To be used in next query, to
	 * retrieve next page.
	 */
	private String nextPageKey;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public List<Agreement> getAgreements() {
		return agreements;
	}

	public void setAgreements(List<Agreement> agreements) {
		this.agreements = agreements;
	}

	public int getNumberOfAgreements() {
		return numberOfAgreements;
	}

	public void setNumberOfAgreements(int numberOfAgreements) {
		this.numberOfAgreements = numberOfAgreements;
	}

	public String getNextPageKey() {
		return nextPageKey;
	}

	public void setNextPageKey(String nextPageKey) {
		this.nextPageKey = nextPageKey;
	}

}
