package com.abnamro.pna.restservices.customeragreements.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsValidationExceptionMapper;
import com.abnamro.pna.restservices.customeragreements.service.CustomerAgreementsRestService;

/**
 * This class is Application class for
 *         CustomerAgreementsApplication and it extends
 *         AabRestApplication
 *         @author C36098
 */
public class CustomerAgreementsApplication extends Application{
  /**
   * @return - a Set that contains ProductConfigurationRestService
   */
	@Override
	public Set<Class<?>> getClasses()
	  {
	    Set classes = new HashSet();
	    classes.add(CustomerAgreementsValidationExceptionMapper.class);
	    return classes;
	  }
	
  @Override
  public Set<Object> getSingletons() {
      Set<Object> singletons = new HashSet<>();
      singletons.add(new CustomerAgreementsRestService());
      return singletons;
  }
}
