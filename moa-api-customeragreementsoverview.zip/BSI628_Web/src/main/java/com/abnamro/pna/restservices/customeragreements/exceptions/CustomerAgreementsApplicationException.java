package com.abnamro.pna.restservices.customeragreements.exceptions;

import com.abnamro.nl.exceptions.AABException;
import com.abnamro.nl.exceptions.BusinessApplicationException;
import com.abnamro.nl.messages.Messages;

/**
 * @author C36098
 * This class throws exception in case of any 
 * error occurring for CustomerAgreementsApplication
 */
public class CustomerAgreementsApplicationException extends BusinessApplicationException{
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
  /**
   * Default constructor
   */
  public CustomerAgreementsApplicationException(){
      super();
  }
  /**
   * Constructor that will also set messages on the exception. 
   * @param messages holds the message string on occurrence of corresponding exception
   */
  public CustomerAgreementsApplicationException(Messages messages) {
      super(messages);
  }

  /**
   * Constructor that takes an existing AABException. This will move any
   * messages into the new exception.
   * @param aabException on occurrence of any AABException
   */
  public CustomerAgreementsApplicationException(AABException aabException) {
      super(aabException);
  }
}
