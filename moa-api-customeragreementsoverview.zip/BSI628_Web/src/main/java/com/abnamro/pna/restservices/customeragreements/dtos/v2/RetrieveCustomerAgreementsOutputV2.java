package com.abnamro.pna.restservices.customeragreements.dtos.v2;

import java.util.ArrayList;
import java.util.List;

import com.abnamro.nl.dto.util.AbstractDTO;

/**
 * @author C36098 This class contains the output for Customer
 *         Agreement(Agreements that a customer possesses in the Bank.)
 */
public class RetrieveCustomerAgreementsOutputV2 extends AbstractDTO {
	private static final long serialVersionUID = 1L;

	private List<AgreementV2> agreements = new ArrayList<>();

	/**
	 * Total number of agreements of a customer.
	 */
	private int numberOfAgreements;

	/**
	 * Populated with last agreement header ID. To be used in next query, to
	 * retrieve next page.
	 */
	private String nextPageKey;

	public List<AgreementV2> getAgreements() {
		return agreements;
	}

	public void setAgreements(List<AgreementV2> agreements) {
		this.agreements = agreements;
	}

	public int getNumberOfAgreements() {
		return numberOfAgreements;
	}

	public void setNumberOfAgreements(int numberOfAgreements) {
		this.numberOfAgreements = numberOfAgreements;
	}

	public String getNextPageKey() {
		return nextPageKey;
	}

	public void setNextPageKey(String nextPageKey) {
		this.nextPageKey = nextPageKey;
	}

}
