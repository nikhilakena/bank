package com.abnamro.pna.restservices.customeragreements.exceptions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * @author PA2619
 * This class contains an array of error messages 
 */
public class Errors implements Serializable { 
	private static final long serialVersionUID = 1L;
	
	/**
	 * List of error messages
	 */
	private List<Error> errorMessages;
	
	public List<Error> getError() {
		if (errorMessages == null) {
			errorMessages = new ArrayList<>();
		}

		return errorMessages;
	}
}