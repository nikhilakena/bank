package com.abnamro.pna.restservices.customeragreements.dao;

import java.sql.Connection;
import java.util.List;

import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;

import com.abnamro.nl.channels.jndilookup.JndiConstants;
import com.abnamro.nl.channels.jndilookup.JndiLookup;
import com.abnamro.nl.dao.util.AbstractDAO;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.dao.util.mybatis.MyBatisConfigException;
import com.abnamro.nl.dao.util.mybatis.MyBatisConnectionFactory;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.messages.Message;
import com.abnamro.nl.messages.MessageType;
import com.abnamro.nl.messages.Messages;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;
import com.abnamro.pna.restservices.customeragreements.service.constants.CustomerAgreementsMessageKeyConstants;


/**
 * This is the DAO class for CustomerAgreements and it extends AbstractDAO
 * @author C36098
 */
public class CustomerAgreementsDB2DAO extends AbstractDAO {


  private static LogHelper logHelper = new LogHelper(CustomerAgreementsDB2DAO.class);

  private final String dbSchemaPrefix;
  private final String dataSourceName;
  private static final String CONFIG_FILE_PATH = "mybatis-config.xml";
  private static volatile MyBatisConnectionFactory connetionFactory;

  /**
   * This is the default constructor
   */
  public CustomerAgreementsDB2DAO() {
    super();
    dbSchemaPrefix = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT)
        .getString(CustomerAgreementsDAOConstants.SCHEMA_DATABASE, CustomerAgreementsDAOConstants.DEFAULT_DB_SCHEMA);
    dataSourceName = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT)
        .getString(CustomerAgreementsDAOConstants.DATASOURCE_NAME, CustomerAgreementsDAOConstants.DEFAULT_DATASOURCE);
    if (connetionFactory == null) {
    	setConnetionFactory(getConnectionFactoryInstance());
    }
  }
  
  private static synchronized void setConnetionFactory(MyBatisConnectionFactory myBatisConnectionFactory){
	  connetionFactory = myBatisConnectionFactory;
  }
  
  /**Parameterized constructor.
   * @param dbSchemaPrefix  String  :prefix of db schema
   * @param dataSourceName String:  datasource name
   * @param connectionFactory This constructor will only be used by the junit tests.
   */
  public CustomerAgreementsDB2DAO(String dbSchemaPrefix, String dataSourceName,
      MyBatisConnectionFactory connectionFactory) {
    this.dbSchemaPrefix = dbSchemaPrefix;
    this.dataSourceName = dataSourceName;
    setConnetionFactory(connectionFactory);
  }
 
  /**
   * @return returns an instance of MyBatisConnectionFactory class
   */
  private static synchronized MyBatisConnectionFactory getConnectionFactoryInstance() {

    final String logMethod = "getConnectionFactoryInstance():MyBatisConnectionFactory";

    try {
      // Creates new Instance for MyBatis Connection factory & loads the
      // Mybatis Configuration file
      return new MyBatisConnectionFactory(CONFIG_FILE_PATH);
    } catch (MyBatisConfigException e) {
      logHelper.error(logMethod, CustomerAgreementsDAOLogConstants.LOG_ERROR_IBATIS_INITIALIZATION, e);
    }
    return null;
  }

  /**
   * getDataSourceName - reads the data source name to be used by the DAO. Health-check will use this to check whether
   * the connection is healthy or not.
   * 
   * @return data source name
   */
  @Override
  protected String getDataSourceName() {
    return dataSourceName;
  }

  /** This method retrieves Customer Agreements
   * @param customerId String customer id(BC Number)
   * @return customerAgreements is list of contract headers 
   * @throws CustomerAgreementsApplicationException in case of errors
   */
  public List<ContractHeaderView> retrieveCustomerAgreements(String customerId)
      throws CustomerAgreementsApplicationException {

    Connection connection = null;
    String logMethod = "retrieveCustomerAgreements";
    List<ContractHeaderView> customerAgreements = null;
    try {
      connection = DAODatabaseUtil.openConnection(getDataSourceName());
      SqlSession sqlSession = connetionFactory.getSession(connection);
      customerAgreements = sqlSession.getMapper(CustomerAgreementsMybatisMapper.class)
          .retrieveContractHeaderDetails(dbSchemaPrefix, Long.valueOf(customerId));
      
    } catch (MyBatisConfigException | PersistenceException exception) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(CustomerAgreementsMessageKeyConstants.MYBATIS_EXCEPTION_WHILE_RETRIEVING_CUSTOMER_AGREEMENTS),
          MessageType.getError());
      logHelper.error(logMethod,
          CustomerAgreementsDAOLogConstants.LOG_ERROR_DATA_CREATE
              + " mybatis exception while retrieving details for the customer {0}",
              exception, new Object[] {customerId});
      throw new CustomerAgreementsApplicationException(messages);
    } catch (DAODatabaseException daoDatabaseException) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(CustomerAgreementsMessageKeyConstants.DATABASE_EXCEPTION_WHILE_RETRIEVING_CUSTOMER_AGREEMENTS),
          MessageType.getError());
      logHelper.error(logMethod, CustomerAgreementsDAOLogConstants.LOG_ERROR_DB_CONNECTION, daoDatabaseException);
      throw new CustomerAgreementsApplicationException(messages);
    } finally {
      DAODatabaseUtil.closeConnection(connection);
    }
    return customerAgreements;
  }

	/**
	 * This operation checks if the entry is present in authorization table for the input consumerId, operation and version.
	 * If entry is present in table it also updates last date used. 
	 * 
	 * @param consumerId unique value for consumer application calling the API
	 * @param operation name of the operation
	 * @param version of the operation
	 * @return indicator to indicate if user is authorized or not
	 * @throws CustomerAgreementsApplicationException in case of errors
	 */
	public boolean isAuthorizedConsumer(String consumerId, String operation, String version) throws CustomerAgreementsApplicationException {
		Connection connection = null;
	    String logMethod = "isAuthorizedConsumer";
	    boolean isAuthorized = false;
	    try {
	      int count = 0;
	      connection = DAODatabaseUtil.openConnection(getDataSourceName());
	      SqlSession sqlSession = connetionFactory.getSession(connection);
	      count = sqlSession.getMapper(CustomerAgreementsMybatisMapper.class).isAuthorizedConsumer(dbSchemaPrefix,consumerId,operation,version);
	      if(count > 0){
		    isAuthorized = true;
		    sqlSession.getMapper(CustomerAgreementsMybatisMapper.class).updateLastDateUsed(dbSchemaPrefix,consumerId,operation,version);
		  }
	    } catch (MyBatisConfigException | PersistenceException exception) {
	        Messages messages = new Messages();
	        messages.addMessage(
	            new Message(CustomerAgreementsMessageKeyConstants.MYBATIS_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION),
	            MessageType.getError());
	        logHelper.error(logMethod,
	            CustomerAgreementsDAOLogConstants.LOG_ERROR_WHILE_RETRIEVING_AUTHORIZATION
	                + " mybatis exception while checking authorization {0}",exception,
	            new Object[] {consumerId});
	        throw new CustomerAgreementsApplicationException(messages);
	      } catch (DAODatabaseException daoDatabaseException) {
	        Messages messages = new Messages();
	        messages.addMessage(
	            new Message(CustomerAgreementsMessageKeyConstants.DATABASE_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION),
	            MessageType.getError());
	        logHelper.error(logMethod, CustomerAgreementsDAOLogConstants.LOG_ERROR_DB_CONNECTION,
	            daoDatabaseException);
	        throw new CustomerAgreementsApplicationException(messages);
	      } finally {
	        DAODatabaseUtil.closeConnection(connection);
	      }
	    
		return isAuthorized;
	}

}
