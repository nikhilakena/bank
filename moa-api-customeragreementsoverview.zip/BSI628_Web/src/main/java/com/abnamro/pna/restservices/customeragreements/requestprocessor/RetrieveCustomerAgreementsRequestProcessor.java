package com.abnamro.pna.restservices.customeragreements.requestprocessor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsView;
import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;
import com.abnamro.pna.restservices.customeragreements.cachehandler.CacheCollector;
import com.abnamro.pna.restservices.customeragreements.dao.BuildingBlockReferenes;
import com.abnamro.pna.restservices.customeragreements.dao.ContractHeaderView;
import com.abnamro.pna.restservices.customeragreements.dao.CustomerAgreementsDB2DAO;
import com.abnamro.pna.restservices.customeragreements.dao.ProductDetailsEnricher;
import com.abnamro.pna.restservices.customeragreements.dtos.Agreement;
import com.abnamro.pna.restservices.customeragreements.dtos.ProductDetailsDTO;
import com.abnamro.pna.restservices.customeragreements.dtos.RetriveCustomerAgreementsOutput;
import com.abnamro.pna.restservices.customeragreements.dtos.v2.AgreementV2;
import com.abnamro.pna.restservices.customeragreements.dtos.v2.RetrieveCustomerAgreementsOutputV2;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;
import com.abnamro.pna.restservices.customeragreements.service.constants.CustomerAgreementsConstants;
import com.abnamro.pna.restservices.customeragreements.service.utils.CustomerAgreementsValidatorUtils;

/**
 * @author C23597 
 * This class is request processor class for the RetrieveCustomerAgreements service operation
 */
public class RetrieveCustomerAgreementsRequestProcessor {

	private CustomerAgreementsDB2DAO customerAgreementsDB2DAO = new CustomerAgreementsDB2DAO();

	private CustomerAgreementsComparator comparator = new CustomerAgreementsComparator();

	// @Inject
	private ProductDetailsEnricher productDetailsEnricher = new ProductDetailsEnricher();

	// @inject
	private CustomerAgreementsValidatorUtils util = new CustomerAgreementsValidatorUtils();

	/**
	 * This method performs below activities retrieve customer agreements from dao
	 * layer filer customer agreements based on input product group populate order
	 * no sort the customer agreements based on order no populate product details
	 * 
	 * @param customerId           String customer id(BC Number)
	 * @param productGroups        list of product groups
	 * @param lastContractHeaderId contract header id from which next set of records
	 *                             needs to be returned
	 * @param traceId              Unique end-2-end trace id received from the
	 *                             consumer
	 * @return populated list of customer agreements
	 * @throws CustomerAgreementsApplicationException with proper message keys
	 * @throws ProductDetailsProviderException        in case of exception in
	 *                                                ProductDetailsProvider
	 */
	public RetriveCustomerAgreementsOutput retriveCustomerAgreements(String customerId, String[] productGroups,
			String lastContractHeaderId, String traceId)
			throws CustomerAgreementsApplicationException, ProductDetailsProviderException {
		RetriveCustomerAgreementsOutput output = null;
		if (CacheCollector.getProductCache() == null) {
			HashMap<Integer, ProductDetailsView> productHashMap = productDetailsEnricher.getProductDetailsForCaching();
			CacheCollector.setProductCache(productHashMap);
		}

		// retrieve customer agreements from tables
		List<ContractHeaderView> contractHeaderView = customerAgreementsDB2DAO.retrieveCustomerAgreements(customerId);
		if (contractHeaderView != null && !contractHeaderView.isEmpty()) {
			int totalProducts = contractHeaderView.size();

			// filer list based on input product group
			List<ContractHeaderView> contractHeaderFilteredList = populateOrderAndFilterProductGroup(contractHeaderView,
					productGroups);

			// sort the product based on order id of the product
			Collections.sort(contractHeaderFilteredList, comparator);

			// filter list based on size & last record details in input
			List<ContractHeaderView> filteredCustomerAgreements = filterCustomerAgreementsOnSize(
					contractHeaderFilteredList, lastContractHeaderId);

			// populate details
			output = populateResponseDetails(customerId, contractHeaderFilteredList, filteredCustomerAgreements,
					totalProducts, traceId);
		}

		return output;
	}

	/**
	 * This method filters the customer agreements based on size. if total records
	 * are more than 75 then return 75 records first time & return next set of
	 * records based on last product group & last contract header id received from
	 * input
	 * 
	 * @param contractHeaderView
	 * @param lastProductGroup
	 * @param lastContractHeaderId
	 * @return
	 */
	/**
	 * @param contractHeaderView
	 * @param lastContractHeaderId
	 * @return
	 */
	private List<ContractHeaderView> filterCustomerAgreementsOnSize(List<ContractHeaderView> contractHeaderView,
			String lastContractHeaderId) {
		List<ContractHeaderView> filteredContractHeaderViewList = null;
		// Get total no of records
		int totalProducts = contractHeaderView.size();

		// if lastProductGroup & lastContractHeaderId are blank then send 75 records in
		// return
		if (StringUtils.isBlank(lastContractHeaderId)) {
			filteredContractHeaderViewList = filterListWithEmptyLastProductGroupAndContractId(contractHeaderView,
					totalProducts);
		} else {
			// if lastProductGroup & lastContractHeaderId are not blank then iterate over
			// the list of
			// records and compare the productGroup & contractHeaderId.
			// Set 75 records after the entry matches with details of input for last record
			filteredContractHeaderViewList = filterListWithLastProductGroupAndContractId(contractHeaderView,
					lastContractHeaderId);
		}

		return filteredContractHeaderViewList;
	}

	/**
	 * @param contractHeaderView   Contract Header View
	 * @param lastContractHeaderId last contract header id
	 * @return List<ContractHeaderView> List of filtered contract header view
	 */
	private List<ContractHeaderView> filterListWithLastProductGroupAndContractId(
			List<ContractHeaderView> contractHeaderView, String lastContractHeaderId) {
		List<ContractHeaderView> filteredContractHeaderViewList;

		filteredContractHeaderViewList = new ArrayList<>();
		int indexForNextSet = -1;
		for (int i = 0; i < contractHeaderView.size(); i++) {
			if (lastContractHeaderId.equals(contractHeaderView.get(i).getChId())) {
				indexForNextSet = i;
				break;
			}
		}
		if (indexForNextSet != -1) {
			for (int i = indexForNextSet + 1; i < contractHeaderView.size(); i++) {
				filteredContractHeaderViewList.add(contractHeaderView.get(i));
				if (filteredContractHeaderViewList.size() >= 75) {
					break;
				}
			}
		}
		return filteredContractHeaderViewList;
	}

	/**
	 * @param contractHeaderView
	 * @param totalProducts
	 * @return
	 */
	private List<ContractHeaderView> filterListWithEmptyLastProductGroupAndContractId(
			List<ContractHeaderView> contractHeaderView, int totalProducts) {
		List<ContractHeaderView> filteredContractHeaderViewList = null;
		if (totalProducts <= 75) {
			return contractHeaderView;
		} else {
			filteredContractHeaderViewList = new ArrayList<>();
			for (int i = 0; i < 75; i++) {
				filteredContractHeaderViewList.add(contractHeaderView.get(i));
			}
		}
		return filteredContractHeaderViewList;
	}

	/**
	 * @param customerId                 String customer id(BC Number)
	 * @param filteredCustomerAgreements
	 * @param filteredCustomerAgreements
	 * @param totalProducts              no of products
	 * @param traceId
	 * @return populated list of customer agreements
	 */
	private RetriveCustomerAgreementsOutput populateResponseDetails(String customerId,
			List<ContractHeaderView> contractHeaderFilteredList, List<ContractHeaderView> filteredCustomerAgreements,
			int totalProducts, String traceId) {
		RetriveCustomerAgreementsOutput output = new RetriveCustomerAgreementsOutput();
		output.setCustomerId(customerId);
		List<Agreement> contractHeaderBOList = new ArrayList<>();
		if (filteredCustomerAgreements != null) {
			for (ContractHeaderView contractHeaderView : filteredCustomerAgreements) {
				setContractHeaderBOList(contractHeaderBOList, contractHeaderView, traceId);
			}
		}
		if (contractHeaderFilteredList != null && !contractHeaderFilteredList.isEmpty()
				&& filteredCustomerAgreements != null && !filteredCustomerAgreements.isEmpty()) {
			ContractHeaderView lastSortedContractHeader = contractHeaderFilteredList
					.get(contractHeaderFilteredList.size() - 1);
			ContractHeaderView lastFiltredContractHeader = filteredCustomerAgreements
					.get(filteredCustomerAgreements.size() - 1);

			if (!lastSortedContractHeader.getChId().equals(lastFiltredContractHeader.getChId())) {
				output.setNextPageKey(lastFiltredContractHeader.getChId());
			}
		}

		output.setAgreements(contractHeaderBOList);
		output.setNumberOfAgreements(totalProducts);
		return output;
	}

	/**
	 * @param contractHeaderBOList
	 * @param contractHeaderView
	 * @param traceId
	 */
	private void setContractHeaderBOList(List<Agreement> contractHeaderBOList, ContractHeaderView contractHeaderView,
			String traceId) {
		Agreement contractHeader = new Agreement();
		String agreementID = contractHeaderView.getAgreementId();
		if (agreementID != null && StringUtils.isNotBlank(agreementID)) {
			contractHeader.setCommercialContractNumber(agreementID.trim());

			if (CacheCollector.getProductCache().get(contractHeaderView.getProductId()).isIbanIndicator()
					&& agreementID.trim().length() <= 12) {
				agreementID = (agreementID.trim().length() > 10) ? agreementID.trim().substring(0, 10)
						: agreementID.trim();
				contractHeader.setAgreementId(convertToIBAN(agreementID));
			}
		}

		if (contractHeaderView.getBbDetails() != null && !contractHeaderView.getBbDetails().isEmpty()) {
			contractHeader.setAgreementAdministrationKey(getMsecKeys(contractHeaderView));
		}
		if (contractHeaderView.getNickname() != null && StringUtils.isNotBlank(contractHeaderView.getNickname())) {
			contractHeader.setNickName(contractHeaderView.getNickname().trim());
		}

		setAgreementStatus(contractHeaderView.getStatus(), traceId, contractHeader);
		contractHeader.setProduct(populateProductDetails(contractHeaderView.getProductId()));
		contractHeaderBOList.add(contractHeader);
	}

	private void setAgreementStatus(String status, String traceId, Agreement contractHeader) {
		boolean invalidStatus = true;
		if (status != null && StringUtils.isNotBlank(status)) {
			if (CustomerAgreementsConstants.STATUS_ACTIVE.equals(status.trim())) {
				contractHeader.setAgreementLifeCycleStatusType(CustomerAgreementsConstants.DESCRIPTION_STATUS_ACTIVE);
				invalidStatus = false;
			} else if (CustomerAgreementsConstants.STATUS_INACTIVE.equals(status.trim())) {
				invalidStatus = false;
				contractHeader.setAgreementLifeCycleStatusType(CustomerAgreementsConstants.DESCRIPTION_STATUS_INACTIVE);
			}
		}
		if (invalidStatus) {
			util.handleValidationError(CustomerAgreementsConstants.INVALID_STATUS_IN_CONTRACT_HEADER,
					CustomerAgreementsConstants.DESC_INVALID_STATUS_IN_CONTRACT_HEADER, traceId, null);
		}
	}

	/**
	 * This method performs below activities retrieve customer agreements from dao
	 * layer filer customer agreements based on input product group populate order
	 * no sort the customer agreements based on order no populate product details
	 * 
	 * @param customerId           String customer id(BC Number)
	 * @param productGroups        list of product groups
	 * @param lastContractHeaderId contract header id from which next set of records
	 *                             needs to be returned
	 * @param traceId              Unique end-2-end trace id received from the
	 *                             consumer
	 * @return populated list of customer agreements
	 * @throws CustomerAgreementsApplicationException with proper message keys
	 * @throws ProductDetailsProviderException        in case of exception in
	 *                                                ProductDetailsProvider
	 */
	public RetrieveCustomerAgreementsOutputV2 retrieveCustomerAgreementsV2(String customerId, Integer[] productGroups,
			String lastContractHeaderId, String traceId)
			throws CustomerAgreementsApplicationException, ProductDetailsProviderException {
		RetrieveCustomerAgreementsOutputV2 output = new RetrieveCustomerAgreementsOutputV2();

		if (CacheCollector.getProductCache() == null) {
			HashMap<Integer, ProductDetailsView> productHashMap = productDetailsEnricher.getProductDetailsForCaching();
			CacheCollector.setProductCache(productHashMap);
		}

		// retrieve customer agreements from tables
		List<ContractHeaderView> contractHeaderView = customerAgreementsDB2DAO.retrieveCustomerAgreements(customerId);
		if (contractHeaderView != null && !contractHeaderView.isEmpty()) {
			int totalProducts = contractHeaderView.size();

			// filer list based on input product group
			String[] productGroupIdsAsText = null;
			if (productGroups != null && productGroups.length > 0) {
				productGroupIdsAsText = new String[productGroups.length];
				for (int index = 0; index < productGroups.length; index++) {
					productGroupIdsAsText[index] = productGroups[index].toString();
				}
			}
			List<ContractHeaderView> contractHeaderFilteredList = populateOrderAndFilterProductGroup(contractHeaderView,
					productGroupIdsAsText);

			// sort the product based on order id of the product
			Collections.sort(contractHeaderFilteredList, comparator);

			// filter list based on size & last record details in input
			List<ContractHeaderView> filteredCustomerAgreements = filterCustomerAgreementsOnSize(
					contractHeaderFilteredList, lastContractHeaderId);

			// populate details
			output = populateResponseDetailsV2(customerId, contractHeaderFilteredList, filteredCustomerAgreements,
					totalProducts, traceId);
		}

		return output;
	}

	/**
	 * @param customerId                 String customer id(BC Number)
	 * @param filteredCustomerAgreements
	 * @param filteredCustomerAgreements
	 * @param totalProducts              no of products
	 * @param traceId
	 * @return populated list of customer agreements
	 */
	private RetrieveCustomerAgreementsOutputV2 populateResponseDetailsV2(String customerId,
			List<ContractHeaderView> contractHeaderFilteredList, List<ContractHeaderView> filteredCustomerAgreements,
			int totalProducts, String traceId) {
		RetrieveCustomerAgreementsOutputV2 output = new RetrieveCustomerAgreementsOutputV2();

		List<AgreementV2> contractHeaderBOList = new ArrayList<>();
		if (filteredCustomerAgreements != null) {
			for (ContractHeaderView contractHeaderView : filteredCustomerAgreements) {
				setContractHeaderBOListV2(contractHeaderBOList, contractHeaderView, traceId);
			}
		}

		if (contractHeaderFilteredList != null && !contractHeaderFilteredList.isEmpty()
				&& filteredCustomerAgreements != null && !filteredCustomerAgreements.isEmpty()) {
			ContractHeaderView lastSortedContractHeader = contractHeaderFilteredList
					.get(contractHeaderFilteredList.size() - 1);
			ContractHeaderView lastFiltredContractHeader = filteredCustomerAgreements
					.get(filteredCustomerAgreements.size() - 1);

			if (!lastSortedContractHeader.getChId().equals(lastFiltredContractHeader.getChId())) {
				output.setNextPageKey(lastFiltredContractHeader.getChId());
			}
		}

		output.setAgreements(contractHeaderBOList);
		output.setNumberOfAgreements(totalProducts);

		return output;
	}

	/**
	 * @param contractHeaderBOList
	 * @param contractHeaderView
	 * @param traceId
	 */
	private void setContractHeaderBOListV2(List<AgreementV2> contractHeaderBOList,
			ContractHeaderView contractHeaderView, String traceId) {
		AgreementV2 contractHeader = new AgreementV2();
		populateIBAN(contractHeaderView.getAgreementId(), contractHeaderView.getProductId(), contractHeader);

		if (contractHeaderView.getBbDetails() != null && !contractHeaderView.getBbDetails().isEmpty()) {
			contractHeader.setAgreementAdministrationKeys(getMsecKeys(contractHeaderView));
		}
		if (StringUtils.isNotBlank(contractHeaderView.getNickname())) {
			contractHeader.setNickName(contractHeaderView.getNickname().trim());
		}
		if (StringUtils.isNotBlank(contractHeaderView.getChIdParent())) {
			contractHeader.setPackageAgreementId(contractHeaderView.getChIdParent().trim());
		}
			
		setAgreementStatusV2(contractHeaderView.getStatus(), traceId, contractHeader);
		contractHeader = addProductDetailsV2(contractHeader, contractHeaderView.getProductId());
		contractHeaderBOList.add(contractHeader);
	}

	/**
	 * This method populates the value of IBAN
	 * @param agreementId Agreement identifier
	 * @param productId product identifier
	 * @param contractHeader It contains agreement details to be populated for the response  
	 */
	private void populateIBAN(String agreementId,int productId, AgreementV2 contractHeader) {
		if (agreementId != null && StringUtils.isNotBlank(agreementId)) {
			contractHeader.setAgreementId(agreementId.trim());
			if (CacheCollector.getProductCache().get(productId).isIbanIndicator()
					&& agreementId.trim().length() <= 12) {
				agreementId = (agreementId.trim().length() > 10) ? agreementId.trim().substring(0, 10)
						: agreementId.trim();
				contractHeader.setIban(convertToIBAN(agreementId));
			}
		}
	}

	private void setAgreementStatusV2(String status, String traceId, AgreementV2 contractHeader) {
		boolean invalidStatus = true;
		if (status != null && StringUtils.isNotBlank(status)) {
			if (CustomerAgreementsConstants.STATUS_ACTIVE.equals(status.trim())) {
				contractHeader.setLifecycleStatus(CustomerAgreementsConstants.DESCRIPTION_STATUS_ACTIVE);
				invalidStatus = false;
			} else if (CustomerAgreementsConstants.STATUS_INACTIVE.equals(status.trim())) {
				invalidStatus = false;
				contractHeader.setLifecycleStatus(CustomerAgreementsConstants.DESCRIPTION_STATUS_INACTIVE);
			}
		}
		if (invalidStatus) {
			util.handleValidationError(CustomerAgreementsConstants.INVALID_STATUS_IN_CONTRACT_HEADER,
					CustomerAgreementsConstants.DESC_INVALID_STATUS_IN_CONTRACT_HEADER, traceId, null);
		}
	}

	private AgreementV2 addProductDetailsV2(AgreementV2 contractHeader, int productId) {
		ProductDetailsView productDetailsView = CacheCollector.getProductCache().get(productId);

		List<Integer> productGroupList = new ArrayList<>();
		contractHeader.setProductId(productId);
		if (productDetailsView.getProductGroupList() != null) {
			for (Integer productGroup : productDetailsView.getProductGroupList()) {
				productGroupList.add(productGroup);
			}
			contractHeader.setProductGroupIds(productGroupList);
		}

		if (StringUtils.isNotBlank(productDetailsView.getInternalName())){
			contractHeader.setInternalProductNameNL(productDetailsView.getInternalName().trim());
		}

		if (StringUtils.isNotBlank(productDetailsView.getExternalName())) {
			contractHeader.setCommercialProductNameNL(productDetailsView.getExternalName().trim());
		}

		return contractHeader;
	}

	/**
	 * It generates the msec keys by attaching the contract id to the building block
	 * no after truncating the leading zeros
	 * 
	 * @param contractHeaderView
	 * @return
	 */
	List<String> getMsecKeys(ContractHeaderView contractHeaderView) {
		List<String> msecKeys = new ArrayList<>();
		for (BuildingBlockReferenes bbReferences : contractHeaderView.getBbDetails()) {
			if (StringUtils.isNotBlank(bbReferences.getBbRefContractId())) {
				msecKeys.add(bbReferences.getBbId() + "_" + bbReferences.getBbRefContractId().trim());
			}
		}
		return msecKeys;
	}

	/**
	 * This returns the IBAN number for input BBAN number using standard algorithm
	 * 
	 * @param agreementId BBAN number
	 * @return IBAN number
	 */
	private String convertToIBAN(String agreementId) {
		String iban = "";
		String abna = "10112310";
		String nl = "2321";
		String temp = abna + agreementId + nl + "00";
		String temp9 = "";
		int rem = 0;
		String remString;
		int finalCheckDigit;
		String finalCheckDigitString;

		temp9 = temp.substring(0, 9);
		rem = Integer.valueOf(temp9) % 97;
		remString = convertTheReminder(rem);

		temp9 = remString + temp.substring(9, 16);
		rem = Integer.valueOf(temp9) % 97;
		remString = convertTheReminder(rem);

		temp9 = remString + temp.substring(16, 23);
		rem = Integer.valueOf(temp9) % 97;
		remString = convertTheReminder(rem);

		temp9 = "000000" + remString + "0";
		rem = Integer.valueOf(temp9) % 97;
		finalCheckDigit = 98 - rem;
		finalCheckDigitString = convertTheReminder(finalCheckDigit);

		iban = "NL" + finalCheckDigitString + "ABNA" + agreementId;

		return iban;
	}

	private String convertTheReminder(int rem) {
		String remString;
		if (rem < 10) {
			remString = "0" + String.valueOf(rem);
		} else {
			remString = String.valueOf(rem);
		}
		return remString;
	}

	private ProductDetailsDTO populateProductDetails(int productId) {
		ProductDetailsView productDetailsView = CacheCollector.getProductCache().get(productId);
		ProductDetailsDTO productDetailsDTO = new ProductDetailsDTO();
		List<String> productGroupList = new ArrayList<>();
		productDetailsDTO.setProductId(StringUtils.leftPad(String.valueOf(productId), 6, '0'));
		if (productDetailsView.getProductGroupList() != null) {
			for (Integer productGroup : productDetailsView.getProductGroupList()) {
				productGroupList.add(StringUtils.leftPad(String.valueOf(productGroup), 4, '0'));
			}
			productDetailsDTO.setProductGroupId(productGroupList);
		}
		if (productDetailsView.getInternalName() != null
				&& StringUtils.isNotBlank(productDetailsView.getInternalName())) {
			productDetailsDTO.setProductInternalName(productDetailsView.getInternalName().trim());
		}
		if (productDetailsView.getExternalName() != null
				&& StringUtils.isNotBlank(productDetailsView.getExternalName())) {
			productDetailsDTO.setProductExternalName(productDetailsView.getExternalName().trim());
		}
		return productDetailsDTO;
	}

	/**
	 * This method filters the customer agreements based on input product groups. It
	 * also populates the order no required for sorting
	 * 
	 * @param contractHeaderViewList list of ContractHeaderView
	 * @param productGroups          input product groups for filtering
	 * @return filtered and populated List<ContractHeaderView>
	 */
	private List<ContractHeaderView> populateOrderAndFilterProductGroup(List<ContractHeaderView> contractHeaderViewList,
			String[] productGroups) {

		List<ContractHeaderView> contractHeaderFileterdViewList = null;

		if (productGroups == null || productGroups.length <= 0) {
			for (ContractHeaderView contractHeaderView : contractHeaderViewList) {
				contractHeaderView.setOrderId(
						CacheCollector.getProductCache().get(contractHeaderView.getProductId()).getOrderId());
			}
			contractHeaderFileterdViewList = contractHeaderViewList;
		} else {
			contractHeaderFileterdViewList = new ArrayList<>();
			setOrderForInputProductGroups(contractHeaderViewList, productGroups, contractHeaderFileterdViewList);

		}
		return contractHeaderFileterdViewList;
	}

	private void setOrderForInputProductGroups(List<ContractHeaderView> contractHeaderViewList, String[] productGroups,
			List<ContractHeaderView> contractHeaderFileterdViewList) {
		for (ContractHeaderView contractHeaderView : contractHeaderViewList) {
			for (int i = 0; i < productGroups.length; i++) {
				ProductDetailsView productDetailsView = CacheCollector.getProductCache()
						.get(contractHeaderView.getProductId());
				if (productDetailsView.getProductGroupList() != null
						&& productDetailsView.getProductGroupList().contains(Integer.parseInt(productGroups[i]))) {
					contractHeaderView.setOrderId(i);
					contractHeaderFileterdViewList.add(contractHeaderView);
					break;
				}
			}
		}

	}

}
