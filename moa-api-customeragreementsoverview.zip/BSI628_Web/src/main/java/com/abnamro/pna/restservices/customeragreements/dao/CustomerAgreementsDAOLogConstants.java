package com.abnamro.pna.restservices.customeragreements.dao;

/**
 * @author C36098
 * This class contains Log Constants used for CustomerAgreementsDAO.
 */
public final class CustomerAgreementsDAOLogConstants {
	private CustomerAgreementsDAOLogConstants() {
	}

  public static final String LOG_ERROR_IBATIS_INITIALIZATION = "LOG_DAO628_001";
  
  public static final String LOG_ERROR_DATA_CREATE = "LOG_DAO628_002";

  public static final String LOG_ERROR_DB_CONNECTION = "LOG_DAO628_003";

  public static final String LOG_ERROR_SQL_ERROR = "LOG_DAO628_004";

  public static final String LOG_ERROR_WHILE_LOADING_STATIC_PRODUCT_GROUP_LIST = "LOG_DAO628_005";

  public static final String LOG_ERROR_WHILE_LOADING_STATIC_PRODUCTGROUP_LIST = "LOG_DAO628_006";

public static final String LOG_ERROR_WHILE_RETRIEVING_AUTHORIZATION = "LOG_DAO628_007";

}
