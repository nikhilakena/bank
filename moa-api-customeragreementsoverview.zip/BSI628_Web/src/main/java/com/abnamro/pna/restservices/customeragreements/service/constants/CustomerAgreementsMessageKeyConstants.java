package com.abnamro.pna.restservices.customeragreements.service.constants;

import com.abnamro.nl.messages.MessageKey;

/**
 * @author C36098
 * This class contains Message Key constants used for CustomerAgreements.
 */
public final class CustomerAgreementsMessageKeyConstants {
	private CustomerAgreementsMessageKeyConstants() {
	}

  public static final MessageKey INVALID_CUSTOMER_ID = new MessageKey("MESSAGE_BS628_001");
  
  public static final MessageKey INVALID_PRODUCT_GROUP = new MessageKey("MESSAGE_BS628_002");

  public static final MessageKey MYBATIS_EXCEPTION_WHILE_READING_PRODUCT_GROUP_DETAILS = new MessageKey("MESSAGE_BS628_003");

  public static final MessageKey DATABASE_EXCEPTION_WHILE_READING_PRODUCT_GROUP_DETAILS = new MessageKey("MESSAGE_BS628_004");

  public static final MessageKey MYBATIS_EXCEPTION_WHILE_READING_PRODUCT_NAME_DETAILS = new MessageKey("MESSAGE_BS628_005");

  public static final MessageKey DATABASE_EXCEPTION_WHILE_READING_PRODUCT_NAME_DETAILS = new MessageKey("MESSAGE_BS628_006");

  public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVING_CUSTOMER_AGREEMENTS = new MessageKey("MESSAGE_BS628_007");

  public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVING_CUSTOMER_AGREEMENTS = new MessageKey("MESSAGE_BS628_008");

  public static final MessageKey PRODUCT_GROUP_LOAD_ERROR = new MessageKey("MESSAGE_BS628_009");

public static final MessageKey INVALID_LAST_CONTRACT_HEADER_ID = new MessageKey("MESSAGE_BS628_010");

public static final MessageKey INVALID_LAST_PRODUCT_GROUP_LAST_CONTRACT_HEADER_ID = new MessageKey("MESSAGE_BS628_011");

public static final MessageKey MORE_CONTRACTHEADERS_ARE_PRESENT_FOR_THIS_INPUT = new MessageKey("MESSAGE_BS628_012");

public static final MessageKey INVALID_LAST_PRODUCT_GROUP_LAST_CONTRACT_HEADER_ID_NOT_PRESENT_IN_DATABSE = new MessageKey("MESSAGE_BS628_013");

public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION = new MessageKey("MESSAGE_BS628_014");

public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION = new MessageKey("MESSAGE_BS628_015");

  

}
