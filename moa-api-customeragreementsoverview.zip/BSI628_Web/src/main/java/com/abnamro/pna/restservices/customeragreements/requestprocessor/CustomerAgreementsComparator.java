package com.abnamro.pna.restservices.customeragreements.requestprocessor;

import java.util.Comparator;

import com.abnamro.pna.restservices.customeragreements.dao.ContractHeaderView;

/**
 * @author C36098
 * This class performs comparison for ContractHeaderView
 */
public class CustomerAgreementsComparator implements Comparator<ContractHeaderView>{
  
  @Override
  public int compare(ContractHeaderView ch1, ContractHeaderView ch2)
  {
      return ch1.getOrderId()-ch2.getOrderId();
  }  

}
