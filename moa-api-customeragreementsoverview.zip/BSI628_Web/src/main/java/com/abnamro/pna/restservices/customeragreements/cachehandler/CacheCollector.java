package com.abnamro.pna.restservices.customeragreements.cachehandler;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsView;

/**
 * This class sets the Product cache
 * @author C36098
 */
public final class CacheCollector {
  
  private static Map<Integer,ProductDetailsView> productCache =null;

  private CacheCollector() {	  
  }

  /**
   * This method sets product cache. This method is synchronized to avoid concurrent update.
   * 
   * @param productHashMap input productHashMap to be set
  */
  public static synchronized void setProductCache(Map<Integer, ProductDetailsView> productHashMap){
    productCache = productHashMap;
  }
  
  /**
   * This method returns product cache.
   * 
   * @return product cache hash map
  */
  public static synchronized Map<Integer,ProductDetailsView> getProductCache(){
	    return productCache;
  }
  
  
  private static HashMap<String,Date> authCache =new HashMap<>();
  
  /**
   * This method sets authorization cache. This method is synchronized to avoid concurrent update.
   * @param key key of the hashmap.
   * @param value value to be updated
   */
  public static synchronized void setAuthCache(String key, Date value){
	  authCache.put(key, value);
  }
  
  /**
   * This method returns authorization cache.
   * @return authorization cache in hashmap
   */
  public static Map<String, Date> getAuthCache(){
	  return authCache;
  }

}
