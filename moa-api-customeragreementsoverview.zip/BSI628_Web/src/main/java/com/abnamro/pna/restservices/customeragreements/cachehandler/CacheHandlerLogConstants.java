package com.abnamro.pna.restservices.customeragreements.cachehandler;


/**
 * This class contains constants used for Cache Handler.
 * @author C36098
 */
public final class CacheHandlerLogConstants {

	private CacheHandlerLogConstants() {	
	}

  public static final String LOG_CACHE_HANDLER_EXCEPTION_IN_SERVLET = "LOG_BS628CA_001";
  
  public static final String LOG_INVALID_HOURTORELOAD_WHILE_AUTO_REINSTANTIATION = "LOG_BS628CA_002";

  public static final String LOG_CONSTRUCTOR_NAMING_EXCEPTION_LOOKUP_TIMERMANAGER = "LOG_BS628CA_003";

  public static final String LOG_CONSTRUCTOR_CONFIG_EXCEPTION_LOOKUP_TIMERMANAGER = "LOG_BS628CA_004";

  public static final String LOG_POLL_TIMEDOUT_REQUESTS_SERVICE_EXCEPTION = "LOG_BS628CA_005";

  public static final String LOG_FETCH_PRODUCT_DETAILS_CACHING_EXCEPTION = "LOG_BS628CA_006";
  
  public static final String LOG_FETCH_PRODUCT_DETAILS_CACHING_EXCEPTION_FROM_PROVIDER = "LOG_BS628CA_007";

}
