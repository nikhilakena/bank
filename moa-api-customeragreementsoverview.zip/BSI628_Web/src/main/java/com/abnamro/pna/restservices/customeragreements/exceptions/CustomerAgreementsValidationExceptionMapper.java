package com.abnamro.pna.restservices.customeragreements.exceptions;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.pna.restservices.customeragreements.service.constants.CustomerAgreementsConstants;
import com.abnamro.pna.restservices.customeragreements.service.constants.CustomerAgreementsLogConstants;
import com.abnamro.pna.restservices.customeragreements.service.utils.CustomerAgreementsValidatorUtils;

/**
 * This class throws exception in case of any validation error occurs.
 * @author Pa2619
 */
@Provider
public class CustomerAgreementsValidationExceptionMapper implements ExceptionMapper<Throwable> {

	/**
	   * Log instance
	   */
	  private static LogHelper logHelper = new LogHelper(CustomerAgreementsValidatorUtils.class);

	@Override
	public Response toResponse(Throwable throwable) {
		return handleException(throwable);
	}

	private boolean isWebApplicationException(Throwable throwable) {
		return isObjectOfType(throwable, WebApplicationException.class);
	}

	private boolean isObjectOfType(Object obj, Class<?> clazz) {
		return clazz.isInstance(obj);
	}

	private Response handleException(Throwable throwable) {
		String logMethod = "handleException(Throwable):Response";

		if (isWebApplicationException(throwable)) {
			return processWebApplicationException((WebApplicationException) throwable);
		}

		return Response.status(Response.Status.INTERNAL_SERVER_ERROR).type(CustomerAgreementsConstants.MEDIA_TYPE).entity(null).build();
	}

	private Response processWebApplicationException(WebApplicationException webApplicationException) {
		Errors errors = (Errors)webApplicationException.getResponse().getEntity(); 
		return Response.status(webApplicationException.getResponse().getStatus()).type(CustomerAgreementsConstants.MEDIA_TYPE).entity(errors).build();
	}

}
