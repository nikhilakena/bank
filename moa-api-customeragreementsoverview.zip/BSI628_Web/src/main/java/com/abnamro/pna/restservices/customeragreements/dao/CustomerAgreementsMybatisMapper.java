package com.abnamro.pna.restservices.customeragreements.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

/**
 * @author C36098
 * This class is the mapper class for CustomerAgreementsDB2DAO with the database
 */
public interface CustomerAgreementsMybatisMapper {

	/** This method retrieves all ContractHeader details from table
	 * 
	 * @param schemaName String value for schemaName of database
	 * @param customerId long value of customer Id
	 * @return List of ContractHeaderView list of contract headers 
	 */
	public List<ContractHeaderView> retrieveContractHeaderDetails(@Param("schemaName") final String schemaName, @Param("customerId") final long customerId);

	/**
	 * This method retrieve count of the entries for input consumerId, operation and version.
	 * 
	 * 
	 * @param schemaName String value for schemaName of database
	 * @param consumerId unique value for consumer application calling the API
	 * @param operation name of the operation
	 * @param version of the operation
	 * @return count of entries
	 */
	public int isAuthorizedConsumer(@Param("schemaName") final String schemaName,@Param("consumerId") final String consumerId, 
		@Param("operation") final  String operation, @Param("version") final  String version);

	/**
	 * This method updates last date used
	 * 
	 * @param schemaName String value for schemaName of database
	 * @param consumerId unique value for consumer application calling the API
	 * @param operation name of the operation
	 * @param version of the operation
	 */
	public void updateLastDateUsed(@Param("schemaName") final String schemaName,@Param("consumerId") final String consumerId, 
		@Param("operation") final  String operation, @Param("version") final  String version);

}
