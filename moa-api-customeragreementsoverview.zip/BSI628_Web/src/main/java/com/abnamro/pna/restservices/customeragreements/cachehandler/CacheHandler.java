package com.abnamro.pna.restservices.customeragreements.cachehandler;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.abnamro.nl.configurationservice.ConfigurationService;
import com.abnamro.nl.configurationservice.ConfigurationServiceException;
import com.abnamro.nl.configurationservice.TechnicalConfigurationServiceFactory;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.messages.Message;
import com.abnamro.nl.messages.MessageType;
import com.abnamro.nl.messages.Messages;
import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsView;
import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;
import com.abnamro.pna.restservices.customeragreements.dao.ProductDetailsEnricher;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;

import commonj.timers.TimerManager;


/**
 * This class is used for caching the product details. It uses timer manager for the caching purpose.
 * 
 * @author PA2619
 *
 */
public final class CacheHandler {
  
  //@Inject 
  private ProductDetailsEnricher productDetailsEnricher = new ProductDetailsEnricher();

  /**
   * Instantiate the Logger
   */
  private static LogHelper logHelper = new LogHelper(CacheHandler.class);

  private static CacheHandler implementationClass = null;

  private static final ConfigurationService configurationService =
      TechnicalConfigurationServiceFactory.createInstanceForService(
          CacheHandlerConstants.SERVICE_NAME, CacheHandler.class.getName());

  // Reload time will be stored in this
  private Calendar reloadAfter = null;

  /**
   * Private Constructor It will instantiate timer listener and and schedule time will be picked from JNDI to set the listener.
   * 
   * @throws CacheHandlerException on occurrence of any exception
   */
  private CacheHandler() throws CacheHandlerException {
    final String LOG_METHOD = "CacheHandler()";
    try {
      // set reload after time. This is the time of day after which data should get refreshed
      String hourToReload = configurationService.getString(CacheHandlerConstants.TIME_OF_DAY_TO_RELOAD);
      

      if (hourToReload == null ) {
        logHelper.error(LOG_METHOD, CacheHandlerLogConstants.LOG_INVALID_HOURTORELOAD_WHILE_AUTO_REINSTANTIATION);
        Messages messages = new Messages();
        messages.addMessage(new Message(CacheHandlerMessageKeys.INVALID_HOURTORELOAD_ERROR), MessageType.getError());
        throw new CacheHandlerException(messages);
      }
      scheduleTimer(hourToReload);

    } catch (NamingException e) {
      logHelper.error(LOG_METHOD, CacheHandlerLogConstants.LOG_CONSTRUCTOR_NAMING_EXCEPTION_LOOKUP_TIMERMANAGER,
          e);
      Messages messages = new Messages();
      messages.addMessage(new Message(CacheHandlerMessageKeys.TIMERMANAGER_LOOKUP_ERROR), MessageType.getError());
      throw new CacheHandlerException(messages);
    } catch (ConfigurationServiceException e) {
      logHelper.error(LOG_METHOD, CacheHandlerLogConstants.LOG_CONSTRUCTOR_CONFIG_EXCEPTION_LOOKUP_TIMERMANAGER, 
          e);
      Messages messages = new Messages();
      messages.addMessage(new Message(CacheHandlerMessageKeys.CONFIGURATION_SERVICE_ERROR), MessageType.getError());
      throw new CacheHandlerException(messages);
    }
  }

/**
 * This method schedules timer for cache refresh
 * @param hourToReload time with which reloadAfter time calculated
 * @throws NamingException  on occurrence of NamingException
 * @throws CacheHandlerException 
 */
private void scheduleTimer(String hourToReload) throws NamingException, CacheHandlerException {
  
      calculateReloadAfterTime(hourToReload);
      // Initialize timer manager
      InitialContext initialContext = new InitialContext();
      String timerManagerName = configurationService.getString(CacheHandlerConstants.TIMER_MANAGER,
          CacheHandlerConstants.DEFAULT_TIMER_MANAGER);
      TimerManager timerManager = (TimerManager) initialContext.lookup(timerManagerName);

      CacheHandlerPoller piAutomaticPoller = new CacheHandlerPoller();

      if(reloadAfter != null){
    	  timerManager.schedule(piAutomaticPoller, new Date(reloadAfter.getTimeInMillis()),
    			  CacheHandlerConstants.SIXTY * CacheHandlerConstants.THOUSAND * CacheHandlerConstants.THOUSAND);
    	  
    	  if(reloadAfter.getTimeInMillis()>System.currentTimeMillis()){
            refreshCache();
          }
      }
      
}

  private void calculateReloadAfterTime(String hourToReload) {
    reloadAfter = Calendar.getInstance();
    reloadAfter.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hourToReload.substring(0, 2)));
    reloadAfter.set(Calendar.MINUTE, Integer.parseInt(hourToReload.substring(2)));
  }

  /**
   * This method fetches product details from ME database and set this to the request Processor
   * 
   * @throws CacheHandlerException on occurrence of any exception
   */
  public void refreshCache() throws CacheHandlerException {
    final String LOG_METHOD = "refreshCache()";
    try{
     HashMap<Integer,ProductDetailsView> productCache= productDetailsEnricher.getProductDetailsForCaching();
     CacheCollector.setProductCache(productCache);
      
    }catch(CustomerAgreementsApplicationException e){
      logHelper.error(LOG_METHOD, CacheHandlerLogConstants.LOG_FETCH_PRODUCT_DETAILS_CACHING_EXCEPTION, 
          e);
      throw new CacheHandlerException(e);
    } catch (ProductDetailsProviderException e) {
      logHelper.error(LOG_METHOD, CacheHandlerLogConstants.LOG_FETCH_PRODUCT_DETAILS_CACHING_EXCEPTION_FROM_PROVIDER, 
    	          e);
      throw new CacheHandlerException(e);
	}
  }
  

  /**
   * getInstance method to always return single object
   * 
   * @return the synchronized cache object
   * @throws CacheHandlerException the CacheHandlerException
   */
  public static synchronized CacheHandler getInstance() throws CacheHandlerException {

    if (implementationClass == null) {
      implementationClass = new CacheHandler();
    }
    return implementationClass;
  }

  /**
   * @return the reloadAfter
   */
  public Calendar getReloadAfter() {
    return reloadAfter;
  }

}
