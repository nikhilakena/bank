package com.abnamro.pna.restservices.customeragreements.service.constants;

/**
 * This class contains constants which are used in this application
 * @author C23597
 */
public final class CustomerAgreementsConstants {
	private CustomerAgreementsConstants() {
	}

	public static final String RESPONSE_STATUS_400 = "400";
	
	public static final String RESPONSE_STATUS_404 = "404";
	
	public static final String RESPONSE_STATUS_500 = "500";
	
	public static final String CODE_CUSTOMER_ID_INVALID = "CUSTOMER_ID_INVALID";
	
	public static final String CODE_PRODUCT_GROUP_ID_INVALID = "PRODUCT_GROUP_ID_INVALID";
	
	public static final String CODE_PRODUCT_GROUP_IDS_INVALID = "PRODUCT_GROUP_IDS_INVALID";

	public static final String CODE_LAST_AGREEMENT_HEADER_ID_INVALID = "NEXTPAGEKEY_INVALID";
	
	public static final String CODE_INTERNAL_ERROR = "INTERNAL_ERROR";
	
	public static final String CODE_TECHNICAL_ERROR = "TECHNICAL_ERROR";
	
	public static final String DESC_CUSTOMER_ID_INVALID = "CustomerId provided in the input is not valid";
	
	public static final String DESC_PRODUCT_GROUP_ID_INVALID = "ProductGroupId provided in the input is not valid";

	public static final String DESC_PRODUCT_GROUP_IDS_INVALID = "ProductGroupIds provided in the input is not valid";

	public static final String DESC_LAST_AGREEMENT_HEADER_ID_INVALID = "NextPageKey provided in the input is not valid";
	
	public static final String DESC_INTERNAL_ERROR = "Internal error occurred";
	
	public static final String DESC_TECHNICAL_ERROR = "Technical error occurred";
	
	public static final String ERRORS_TAG = "errors";
	
	public static final String MEDIA_TYPE = "application/json";

	public static final String INVALID_STATUS_IN_CONTRACT_HEADER = "INVALID_STATUS_IN_CONTRACT_HEADER";

	public static final String DESC_INVALID_STATUS_IN_CONTRACT_HEADER = "One or more commercial contract(s) have invalid status in contractheader.";
	
	public static final String STATUS_ACTIVE = "2";
	
	public static final String STATUS_INACTIVE = "3";
	
	public static final String DESCRIPTION_STATUS_ACTIVE = "ACTIVE";
	
	public static final String DESCRIPTION_STATUS_INACTIVE = "INACTIVE";

	public static final String CODE_MORE_THAN_20_PRODUCT_GROUPS_PROVIDED = "MORE_THAN_20_PRODUCT_GROUPS_PROVIDED";

	public static final String DESC_MORE_THAN_20_PRODUCT_GROUPS_PROVIDED = "More than 20 product groups are provided in input";

	public static final String RESPONSE_STATUS_401 = "401";

	public static final String CODE_AUTHORIZATION_FAILURE = "AUTHORIZATION_FAILURE";

	public static final String DESC_AUTHORIZATION_FAILURE = "Input consumer Id is not authorized for this operation";
	
	public static final String UNDERSCORE ="_";

	public static final String CODE_CONSUMER_ID_NOT_PROVIDED = "CONSUMER_ID_IS_MANDATORY";

	public static final String DESC_CONSUMER_ID_NOT_PROVIDED = "ConsumerId is mandatory";

	public static final String CODE_CONSUMER_ID_INVALID = "CONSUMER_ID_INVALID";

	public static final String DESC_CONSUMER_ID_INVALID = "Consumer Id provided in the input is not valid";

	public static final String DESC_RESOURCE_NOT_FOUND = "No contracts are present for input customer Id";

	public static final String CODE_RESOURCE_NOT_FOUND = "RESOURCE_NOT_FOUND";

	public static final String CODE_INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";

	public static final String DESC_INTERNAL_SERVER_ERROR = "Internal server error occurred";
	
	public static final String CODE_REQUESTED_LANGUAGE_NOT_SUPPORTED = "ACCEPT_HEADER_INVALID";
	
	public static final String DESC_REQUESTED_LANGUAGE_NOT_SUPPORTED = "Accept-Language is invalid";
    
    public static final String AGREEMENT_IDS_NOT_PRESENT = "agreementIds.not_present";

    public static final String RESPONSE_STATUS_406 = "406";
}
