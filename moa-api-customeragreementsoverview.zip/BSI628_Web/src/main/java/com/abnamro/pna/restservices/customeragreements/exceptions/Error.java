package com.abnamro.pna.restservices.customeragreements.exceptions;

import java.io.Serializable;

/**
 * @author PA2619
 * This class contains an error related information
 */
public class Error implements Serializable{
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Combined fields operationId, backEndId and  message as a key
	 */
	private String code;
	
	/**
	 * Value from field message
	 */
	private String message;
	
	/**
	 * Unique end-2-end trace id received from the consumer
	 */
	private String traceId;
	
	/**
	 * Value from field HTTP-status
	 */
	private String status;
	
	/**
	 * Handle multiple errors for a single request
	 */
	private String[] params;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTraceId() {
		return traceId;
	}

	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String[] getParams() {
		return params;
	}

	public void setParams(String[] params) {
		this.params = params;
	}
}
