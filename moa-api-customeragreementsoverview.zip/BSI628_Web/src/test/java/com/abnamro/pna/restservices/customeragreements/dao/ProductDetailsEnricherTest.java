package com.abnamro.pna.restservices.customeragreements.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsDB2DAO;
import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsView;
import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;
import com.abnamro.pna.restservices.customeragreements.dao.ProductDetailsEnricher;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ProductDetailsEnricher.class})
@PowerMockIgnore({"javax.security.auth.*", "com.sun.jmx.*", "javax.management.*"})
public class ProductDetailsEnricherTest {
  @InjectMocks
  private ProductDetailsEnricher underTest;
  @Mock
  private ProductDetailsDB2DAO mockDAO;

  @Test
  public void getProductDetailsForCachingTest() {
    List<ProductDetailsView> productDetailsViewList = new ArrayList<>();
    ProductDetailsView productDetailsView = new ProductDetailsView();
    productDetailsView.setOrderId(12);
    productDetailsView.setProductId(123);
    List<Integer> productGroupList = new ArrayList<>();
    productGroupList.add(1);
    productGroupList.add(2);
    productDetailsView.setProductGroupList(productGroupList);
    productDetailsViewList.add(productDetailsView);
    try {
      Mockito.when(mockDAO.readProductDetails()).thenReturn(productDetailsViewList);
      underTest.getProductDetailsForCaching();
    } catch (ProductDetailsProviderException e) {
      Assert.fail("No Exception expected");
    } catch (CustomerAgreementsApplicationException e) {
      Assert.fail("No Exception expected");
    }
  }

}
