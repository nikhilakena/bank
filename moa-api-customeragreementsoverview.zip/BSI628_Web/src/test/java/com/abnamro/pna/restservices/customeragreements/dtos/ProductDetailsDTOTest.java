package com.abnamro.pna.restservices.customeragreements.dtos;

import org.junit.Test;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertEquals;

public class ProductDetailsDTOTest {

    ProductDetailsDTO productDetailsDTO = new ProductDetailsDTO();

    @Test
    public void test_getProductId() {
        productDetailsDTO.setProductId("test");
        assertEquals("test", productDetailsDTO.getProductId());
    }


    @Test
    public void test_getProductInternalName() {
        productDetailsDTO.setProductInternalName("test");
        assertEquals("test", productDetailsDTO.getProductInternalName());
    }

    @Test
    public void test_getProductExternalName() {
        productDetailsDTO.setProductExternalName("test");
        assertEquals("test", productDetailsDTO.getProductExternalName());
    }


    @Test
    public void test_getProductGroupId() {
        List<String> list = new ArrayList<>();
        list.add("test");
        productDetailsDTO.setProductGroupId(list);
        assertEquals(list, productDetailsDTO.getProductGroupId());
    }


    @Test
    public void test_getLeadingProductGroupId() {
        productDetailsDTO.setLeadingProductGroupId("test");
        assertEquals("test", productDetailsDTO.getLeadingProductGroupId());
    }

    @Test
    public void test_getLeadingProductGroupInternalName() {
        productDetailsDTO.setLeadingProductGroupInternalName("test");
        assertEquals("test", productDetailsDTO.getLeadingProductGroupInternalName());
    }

    @Test
    public void test_getLeadingProductGroupExternalName() {
        productDetailsDTO.setLeadingProductGroupExternalName("test");
        assertEquals("test", productDetailsDTO.getLeadingProductGroupExternalName());
    }

}
