package com.abnamro.pna.restservices.customeragreements.service.utils;

import java.util.Date;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import com.abnamro.pna.restservices.customeragreements.exceptions.Errors;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.abnamro.pna.restservices.customeragreements.cachehandler.CacheCollector;
import com.abnamro.pna.restservices.customeragreements.dao.CustomerAgreementsDB2DAO;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;
import com.abnamro.pna.restservices.customeragreements.service.constants.CustomerAgreementsConstants;
import com.abnamro.pna.restservices.customeragreements.service.utils.CustomerAgreementsValidatorUtils;


@RunWith(PowerMockRunner.class)
@PrepareForTest(CustomerAgreementsValidatorUtils.class)
@PowerMockIgnore({"javax.security.auth.*", "com.sun.jmx.*", "javax.management.*"})
public class CustomerAgreementsValidatorUtilsTest {

  @InjectMocks
  private CustomerAgreementsValidatorUtils utils;

  @Mock
  private CustomerAgreementsDB2DAO mockDAO;

  @Test
  public void testValidateCustomerIdNull() {
    try {
      utils.validateCustomerId(null, "Trace123");
    } catch (WebApplicationException e) {
      Assert.assertEquals("Customer Id Not Valid", 400, e.getResponse().getStatus());
    }
  }

  @Test
  public void testValidateCustomerIdNotNull() {
    try {
      utils.validateCustomerId("123", "Trace123");
    } catch (WebApplicationException e) {
      Assert.fail("No Exception expected");
    }
  }

  @Test
  public void testValidateProductGroupsIfNull() {
    try {
      utils.validateProductGroups(null, "Trace123");
    } catch (WebApplicationException e) {
      Assert.fail("No Exception expected");
    }
  }

  @Test
  public void testValidateProductGroupsNotNull() {
    String[] productGroups = {"110", "117"};
    try {
      utils.validateProductGroups(productGroups, "Trace123");
    } catch (WebApplicationException e) {
      Assert.fail("No Exception expected");
    }
  }

  @Test
  public void testValidateProductGroupsIfSizeExceeds() {
    String[] productGroups = {"110", "117", "92", "93", "94", "95", "96", "97", "98", "99", "101", "102", "103", "104",
        "105", "106", "108", "111", "156", "154", "134", "160", "171"};
    try {
      utils.validateProductGroups(productGroups, "Trace123");
    } catch (WebApplicationException e) {
      Assert.assertEquals("ProductGroup Not Valid", 400, e.getResponse().getStatus());
    }
  }

  @Test
  public void testValidateProductGroupsNonNumeric() {
    String[] productGroups = {"abc23", "gj234"};
    try {
      utils.validateProductGroups(productGroups, "Trace123");
      Assert.fail("exception expected");
    } catch (WebApplicationException e) {
      Assert.assertEquals("ProductGroup Id Not Valid", 400, e.getResponse().getStatus());
      Response response = e.getResponse();
      Assert.assertNotNull(response);
      Object responseEntity = response.getEntity();
      Assert.assertNotNull(responseEntity);
      Assert.assertTrue(responseEntity instanceof Errors);
      Errors errors = (Errors) responseEntity;
      Assert.assertNotNull(errors.getError());
      Assert.assertEquals(1, errors.getError().size());
      Assert.assertNotNull(errors.getError().get(0).getParams());
      String[] invalidParameters = errors.getError().get(0).getParams();
      Assert.assertEquals(1, invalidParameters.length);
      Assert.assertEquals("LOG_BS628RE_002", invalidParameters[0]);
    }
  }

  @Test
  public void testValidateLastContractHeaderIdIfValid() {
    try {
      utils.validateLastContractHeaderId("AAB000997", "Trace123");
    } catch (WebApplicationException e) {
      Assert.fail("No Exception expected");
    }
  }

  @Test
  public void testValidateLastContractHeaderIdIfInvalid() {
    try {
      utils.validateLastContractHeaderId("AA$000997", "Trace123");
    } catch (WebApplicationException e) {
      Assert.assertEquals("Last ContractHeader Id Not Valid", 400, e.getResponse().getStatus());
    }
  }

  @Test
  public void testvalidateAuthrizationSuccessiveCall() throws CustomerAgreementsApplicationException {

    String consumerId = "CID0004";
    String operation = "retrieveCustomerAgreements";
    String version = "V1";

    String key = consumerId + CustomerAgreementsConstants.UNDERSCORE + operation
        + CustomerAgreementsConstants.UNDERSCORE + version;
    CacheCollector.getAuthCache().put(key, new Date());

    boolean flag = utils.validateAuthrization(consumerId, operation, version, "abc001");
    Assert.assertEquals("Authrization for Successive Call", true, flag);

  }

  @Test
  public void testvalidateAuthrizationFirstCallSuccess() throws CustomerAgreementsApplicationException {

    String consumerId = "CID0005";
    String operation = "retrieveCustomerAgreements";
    String version = "V1";

    Mockito.when(mockDAO.isAuthorizedConsumer(consumerId, operation, version)).thenReturn(true);
    boolean flag = utils.validateAuthrization(consumerId, operation, version, "abc001");
    Assert.assertEquals("Authrization for Successive Call", true, flag);

  }

  @Test
  public void testvalidateAuthrizationFirstCallFailure() throws CustomerAgreementsApplicationException {
    try {
      String consumerId = "CID0006";
      String operation = "retrieveCustomerAgreements";
      String version = "V1";

      Mockito.when(mockDAO.isAuthorizedConsumer(consumerId, operation, version)).thenReturn(false);
      boolean flag = utils.validateAuthrization(consumerId, operation, version, "abc001");
      Assert.assertEquals("Authrization for Successive Call", true, flag);
    } catch (WebApplicationException e) {
      Assert.assertEquals("Authorization Not Valid", 401, e.getResponse().getStatus());
    }
  }

  @Test
  public void testValidateProductGroupsV2TooLong() {
	  String[] productGroups = {"2344322", "1678765"};
    try {
      utils.validateProductGroupsV2(productGroups, "Trace123");
      Assert.fail("exception expected");
    } catch (WebApplicationException e) {
      Assert.assertEquals("ProductGroup Id Not Valid", 400, e.getResponse().getStatus());
      Response response = e.getResponse();
      Assert.assertNotNull(response);
      Object responseEntity = response.getEntity();
      Assert.assertNotNull(responseEntity);
      Assert.assertTrue(responseEntity instanceof Errors);
      Errors errors = (Errors) responseEntity;
      Assert.assertNotNull(errors.getError());
      Assert.assertEquals(1, errors.getError().size());
      Assert.assertNotNull(errors.getError().get(0).getParams());
      String[] invalidParameters = errors.getError().get(0).getParams();
      Assert.assertEquals(2, invalidParameters.length);
      Assert.assertEquals("2344322", invalidParameters[0]);
      Assert.assertEquals("1678765", invalidParameters[1]);
    }
  }


  @Test
  public void testValidateProductGroupsV2NoNumbers() {
    String[] productGroups = {"243X", "1685"};
    try {
      utils.validateProductGroupsV2(productGroups, "Trace123");
      Assert.fail("exception expected");
    } catch (WebApplicationException e) {
      Assert.assertEquals("ProductGroup Id Not Valid", 400, e.getResponse().getStatus());
      Response response = e.getResponse();
      Assert.assertNotNull(response);
      Object responseEntity = response.getEntity();
      Assert.assertNotNull(responseEntity);
      Assert.assertTrue(responseEntity instanceof Errors);
      Errors errors = (Errors) responseEntity;
      Assert.assertNotNull(errors.getError());
      Assert.assertEquals(1, errors.getError().size());
      Assert.assertNotNull(errors.getError().get(0).getParams());
      String[] invalidParameters = errors.getError().get(0).getParams();
      Assert.assertEquals(1, invalidParameters.length);
      Assert.assertEquals("243X", invalidParameters[0]);
    }
  }

  @Test
  public void testValidateProductGroupsV2ValidParamaters() {
	  String[] productGroups = {"2432", "1685"};
    try {
      utils.validateProductGroupsV2(productGroups, "Trace123");
    } catch (WebApplicationException e) {
        Assert.fail("no exception expected");
    }
  }
}