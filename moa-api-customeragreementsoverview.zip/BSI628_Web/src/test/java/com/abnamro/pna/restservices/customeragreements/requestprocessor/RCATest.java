package com.abnamro.pna.restservices.customeragreements.requestprocessor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.abnamro.pna.restservices.customeragreements.dao.BuildingBlockReferenes;
import com.abnamro.pna.restservices.customeragreements.dao.ContractHeaderView;


public class RCATest {

  @Test
  public void getMsecKeysEmpty() {
    RetrieveCustomerAgreementsRequestProcessor underTest = new RetrieveCustomerAgreementsRequestProcessor();
    assertNotNull(underTest);
    ContractHeaderView view = new ContractHeaderView();

    view.setBbDetails(new ArrayList<BuildingBlockReferenes>());
    assertNotNull(view);

    List<String> keys = underTest.getMsecKeys(view);
    assertNotNull(keys);
    assertEquals(0, keys.size());
  }

  @Test
  public void getMsecKeysNotEmpty() {
    RetrieveCustomerAgreementsRequestProcessor underTest = new RetrieveCustomerAgreementsRequestProcessor();
    assertNotNull(underTest);
    ContractHeaderView view = new ContractHeaderView();

    List<BuildingBlockReferenes> bbRefs = new ArrayList<>();
    BuildingBlockReferenes reference1 = new BuildingBlockReferenes();
    reference1.setBbId(1);
    reference1.setBbRefContractId("7777C");
    bbRefs.add(reference1);

    BuildingBlockReferenes reference2 = new BuildingBlockReferenes();
    reference2.setBbId(2);
    reference2.setBbRefContractId("8888D");
    bbRefs.add(reference2);

    view.setBbDetails(bbRefs);

    List<String> keys = underTest.getMsecKeys(view);
    assertNotNull(keys);
    assertEquals(2, keys.size());

    assertEquals("1_7777C", keys.get(0));
    assertEquals("2_8888D", keys.get(1));
  }
}
