package com.abnamro.pna.restservices.customeragreements.service;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;
import com.abnamro.pna.restservices.customeragreements.dtos.RetriveCustomerAgreementsOutput;
import com.abnamro.pna.restservices.customeragreements.dtos.v2.RetrieveCustomerAgreementsOutputV2;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;
import com.abnamro.pna.restservices.customeragreements.requestprocessor.RetrieveCustomerAgreementsRequestProcessor;
import com.abnamro.pna.restservices.customeragreements.service.CustomerAgreementsRestService;

@RunWith(PowerMockRunner.class)
@PrepareForTest(CustomerAgreementsRestService.class)
@PowerMockIgnore({ "javax.security.auth.*", "com.sun.jmx.*", "javax.management.*" })
public class CustomerAgreementsRestServiceTest {

	@InjectMocks
	private CustomerAgreementsRestService underTest;

	@Mock
	private RetrieveCustomerAgreementsRequestProcessor requestProcessor;

	@Test
	public void testRetriveCustomerAgreements() {
		String productGroups[] = { "110", "93" };
		String lastContractHeaderId = "DFG009088";
		String traceId = "TRACE123";
		RetriveCustomerAgreementsOutput output = new RetriveCustomerAgreementsOutput();
		try {
			Mockito.when(requestProcessor.retriveCustomerAgreements("205", productGroups, lastContractHeaderId, traceId))
					.thenReturn(output);
			// Mockito.when(customerAgreementsDB2DAO.isAuthorizedConsumer(consumerId,
			// operation, version);

			Response response = underTest.getCustomerAgreementList(null, null, "MOCONSUMER1", traceId, "205",
					productGroups, lastContractHeaderId);
			Assert.assertEquals("Successful operation", 204, response.getStatus());
		} catch (WebApplicationException e) {
			Assert.assertEquals("Internal Server Error", 500, e.getResponse().getStatus());
		} catch (CustomerAgreementsApplicationException e) {
			Assert.fail("No Exception expected");
		} catch (ProductDetailsProviderException e) {
			Assert.fail("No Exception expected");
		}
	}

	@Test
	public void testRetriveCustomerAgreementsWithInternalError() {
		String[] productGroups = { "110", "93" };
		String lastContractHeaderId = "DFG009088";
		String traceId = "TRACE123";
		try {
			Mockito.when(requestProcessor.retriveCustomerAgreements("205", productGroups, lastContractHeaderId, traceId))
					.thenThrow(new CustomerAgreementsApplicationException());
			underTest.getCustomerAgreementList(null, null, "MOCONSUMER1", traceId, "205", productGroups,
					lastContractHeaderId);
		} catch (WebApplicationException e) {
			Assert.assertEquals("Internal Server Error", 500, e.getResponse().getStatus());
		} catch (CustomerAgreementsApplicationException e) {
			Assert.fail("No CustomerAgreementsApplicationException expected");
		} catch (ProductDetailsProviderException e) {
			Assert.fail("No ProductDetailsProviderException expected");
		}
	}

	@Test
	public void testRetrieveCustomerAgreementsV2() {
		String customerId = "205";
		Integer productGroupIds[] = null;
		String[] productGroupIdParameters = null;
		String lastAgreementHeaderId = "AAA666666";
		String traceId = "trace1";
		String consumerId = "consumer1";
		RetrieveCustomerAgreementsOutputV2 output = new RetrieveCustomerAgreementsOutputV2();

		try {
			Mockito.when(requestProcessor.retrieveCustomerAgreementsV2(customerId, productGroupIds, lastAgreementHeaderId, traceId))
				.thenReturn(output);

			Response response = underTest.getCustomerAgreementListV2(null, null, consumerId, traceId, customerId, productGroupIdParameters, lastAgreementHeaderId);
			Assert.assertEquals(200, response.getStatus());
			Assert.assertNotNull(response.getEntity());
			Assert.assertTrue(response.getEntity() instanceof RetrieveCustomerAgreementsOutputV2);
			RetrieveCustomerAgreementsOutputV2 responseEntity = (RetrieveCustomerAgreementsOutputV2) response.getEntity();
			Assert.assertNotNull(responseEntity.getAgreements());
			Assert.assertEquals(0, responseEntity.getAgreements().size());
			Assert.assertEquals(0, responseEntity.getNumberOfAgreements());
		} catch (CustomerAgreementsApplicationException | ProductDetailsProviderException e) {
			Assert.fail("No Exception expected");
		}
	}
}