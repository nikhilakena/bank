package com.abnamro.pna.restservices.customeragreements.dtos.v3;

import com.abnamro.pna.restservices.customeragreements.dtos.Agreement;
import com.abnamro.pna.restservices.customeragreements.dtos.RetriveCustomerAgreementsOutput;
import org.junit.Test;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class RetrieveCustomerAgreementsOutputV3Test {

    RetriveCustomerAgreementsOutput retriveCustomerAgreementsOutput = new RetriveCustomerAgreementsOutput();
    Agreement agreement = new Agreement();

    @Test
    public void test_getCustomerId() {
        retriveCustomerAgreementsOutput.setCustomerId("Test");
        assertEquals("Test", retriveCustomerAgreementsOutput.getCustomerId());
    }

    @Test
    public void test_getNumberOfAgreements() {
        retriveCustomerAgreementsOutput.setNumberOfAgreements(1);
        assertEquals(1, retriveCustomerAgreementsOutput.getNumberOfAgreements());
    }

    @Test
    public void test_getAgreements() {
        agreement.setAgreementId("test");
        List<Agreement> agreements = Collections.singletonList(agreement);
        retriveCustomerAgreementsOutput.setAgreements(agreements);
        assertEquals(agreements, retriveCustomerAgreementsOutput.getAgreements());
    }

    @Test
    public void test_getnextPageKey() {
        retriveCustomerAgreementsOutput.setNextPageKey("Test");
        assertEquals("Test", retriveCustomerAgreementsOutput.getNextPageKey());
    }

}
