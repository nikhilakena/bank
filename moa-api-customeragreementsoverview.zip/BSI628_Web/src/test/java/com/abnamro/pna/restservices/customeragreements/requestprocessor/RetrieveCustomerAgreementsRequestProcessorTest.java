package com.abnamro.pna.restservices.customeragreements.requestprocessor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.abnamro.pna.restservices.customeragreements.dtos.v2.AgreementV2;
import com.abnamro.pna.restservices.customeragreements.dtos.v2.RetrieveCustomerAgreementsOutputV2;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsView;
import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;
import com.abnamro.pna.restservices.customeragreements.cachehandler.CacheCollector;
import com.abnamro.pna.restservices.customeragreements.dao.ContractHeaderView;
import com.abnamro.pna.restservices.customeragreements.dao.CustomerAgreementsDB2DAO;
import com.abnamro.pna.restservices.customeragreements.dao.ProductDetailsEnricher;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;
import com.abnamro.pna.restservices.customeragreements.requestprocessor.RetrieveCustomerAgreementsRequestProcessor;


@RunWith(PowerMockRunner.class)
@PrepareForTest({RetrieveCustomerAgreementsRequestProcessor.class})
@PowerMockIgnore({"javax.security.auth.*", "com.sun.jmx.*", "javax.management.*"})
public class RetrieveCustomerAgreementsRequestProcessorTest {

  @InjectMocks
  private RetrieveCustomerAgreementsRequestProcessor underTest;
  @Mock
  private ProductDetailsEnricher enricher;
  @Mock
  private CustomerAgreementsDB2DAO mockDAO;

  @Test
  public void testRetriveCustomerAgreementsNullCache() {

    HashMap<Integer, ProductDetailsView> productHashMap = new HashMap<>();
    List<ContractHeaderView> contractHeaderViewList = new ArrayList<>();
    String productGroups[] = {"1104", "1102"};
    try {
      Mockito.when(enricher.getProductDetailsForCaching()).thenReturn(productHashMap);
      Mockito.when(mockDAO.retrieveCustomerAgreements("123")).thenReturn(contractHeaderViewList);
      underTest.retriveCustomerAgreements("123", productGroups, "ABC000909", "123");
    } catch (CustomerAgreementsApplicationException e) {
      Assert.fail("No Exception expected");
    } catch (ProductDetailsProviderException e) {
      Assert.fail("No Exception expected");
    }
  }

  @Test
  public void testRetriveCustomerAgreementsNotNullCache() {
    HashMap<Integer, ProductDetailsView> productHashMap = new HashMap<>();
    CacheCollector.setProductCache(productHashMap);
    List<ContractHeaderView> contractHeaderViewList = new ArrayList<>();
    String[] productGroups = {"1104", "1102"};
    try {
      Mockito.when(enricher.getProductDetailsForCaching()).thenReturn(productHashMap);
      Mockito.when(mockDAO.retrieveCustomerAgreements("123")).thenReturn(contractHeaderViewList);
      underTest.retriveCustomerAgreements("123", productGroups, "ABC000909", "123");
    } catch (CustomerAgreementsApplicationException e) {
      Assert.fail("No Exception expected");
    } catch (ProductDetailsProviderException e) {
      Assert.fail("No Exception expected");
    }
  }

  @Test
  public void retrieveAgreementsV2Empty() {
    String customerId = "123";
    List<ContractHeaderView> contractHeaderViewList = new ArrayList<>();
    Integer[] productGroups = {93, 95};
    try {
      Mockito.when(mockDAO.retrieveCustomerAgreements(customerId)).thenReturn(contractHeaderViewList);
      RetrieveCustomerAgreementsOutputV2 output = underTest.retrieveCustomerAgreementsV2(customerId, productGroups, "ABC000909", "123");
      Assert.assertNotNull(output);
      Assert.assertNotNull(output.getAgreements());
      Assert.assertEquals(0, output.getAgreements().size());
      Assert.assertEquals(0, output.getNumberOfAgreements());
    } catch (Exception e) {
      Assert.fail("No Exception expected");
    }
  }
  
  @Test
  public void retrieveAgreementsV2WithPackageAgreementId() {
    String customerId = "123";
    List<ContractHeaderView> contractHeaderViewList = new ArrayList<>();
    ContractHeaderView contractHeaderView = new ContractHeaderView();
    contractHeaderView.setChIdParent("IGD476783");
    contractHeaderView.setChId("ABC000910");
    contractHeaderView.setProductId(1249);
    Integer[] productGroups = {93, 95};
    try {
      Mockito.when(mockDAO.retrieveCustomerAgreements(customerId)).thenReturn(contractHeaderViewList);
      RetrieveCustomerAgreementsOutputV2 output = underTest.retrieveCustomerAgreementsV2(customerId, productGroups, "ABC000909", "123");
      Assert.assertNotNull(output);
      Assert.assertNotNull(output.getAgreements());
      for (int i = 0; i < output.getAgreements().size(); i++) {
    	  AgreementV2 agreement = output.getAgreements().get(i);
    	  Assert.assertEquals("IGD476783", agreement.getPackageAgreementId());
    	  Assert.assertEquals("1249", agreement.getProductId());
      }
    } catch (Exception e) {
      Assert.fail("No Exception expected");
    }
  }
}
