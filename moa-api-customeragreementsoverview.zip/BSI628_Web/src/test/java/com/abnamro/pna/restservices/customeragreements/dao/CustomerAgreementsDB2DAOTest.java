package com.abnamro.pna.restservices.customeragreements.dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.dao.util.mybatis.MyBatisConnectionFactory;
import com.abnamro.pna.restservices.customeragreements.dao.ContractHeaderView;
import com.abnamro.pna.restservices.customeragreements.dao.CustomerAgreementsDB2DAO;
import com.abnamro.pna.restservices.customeragreements.dao.CustomerAgreementsMybatisMapper;
import com.abnamro.pna.restservices.customeragreements.exceptions.CustomerAgreementsApplicationException;

@PowerMockIgnore("javax.management.*")
@RunWith(PowerMockRunner.class)
@PrepareForTest({DAODatabaseUtil.class, MyBatisConnectionFactory.class})
public class CustomerAgreementsDB2DAOTest {
  @Mock
  private Connection connection;

  @Mock
  private MyBatisConnectionFactory connectionFactory;

  @Mock
  private SqlSession sqlSession;

  @Mock
  private CustomerAgreementsMybatisMapper mapper;

  private CustomerAgreementsDB2DAO underTest;

  @Before
  public void startUp() throws Exception {
    PowerMockito.mockStatic(DAODatabaseUtil.class);
    PowerMockito.when(DAODatabaseUtil.openConnection("test")).thenReturn(connection);
    connectionFactory = PowerMockito.mock(MyBatisConnectionFactory.class);
    PowerMockito.when(connectionFactory.getSession(connection)).thenReturn(sqlSession);
    PowerMockito.when(sqlSession.getMapper(CustomerAgreementsMybatisMapper.class)).thenReturn(mapper);
  }

  @Test
  public void testRetrieveCustomerAgreements() {
    List<ContractHeaderView> customerAgreements = new ArrayList<>();
    PowerMockito.when(mapper.retrieveContractHeaderDetails("test", 1)).thenReturn(customerAgreements);
    underTest = new CustomerAgreementsDB2DAO("test", "test", connectionFactory);
    try {
      underTest.retrieveCustomerAgreements("1");
    } catch (CustomerAgreementsApplicationException e) {
      Assert.fail("No Exception expected");
    }
  }

  @Test
  public void testIsAuthorizedConsumer() {

    String consumerId = "CID0007";
    String operation = "retrieveCustomerAgreements";
    String version = "V1";

    PowerMockito.when(mapper.isAuthorizedConsumer("test", consumerId, operation, version)).thenReturn(1);
    underTest = new CustomerAgreementsDB2DAO("test", "test", connectionFactory);
    try {
      boolean flag = underTest.isAuthorizedConsumer(consumerId, operation, version);
      Assert.assertEquals("Authrization for Successive Call", true, flag);
    } catch (CustomerAgreementsApplicationException e) {
      Assert.fail("No Exception expected");
    }
  }

}
