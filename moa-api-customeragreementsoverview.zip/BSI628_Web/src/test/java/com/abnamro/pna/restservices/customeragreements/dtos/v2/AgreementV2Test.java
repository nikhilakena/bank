package com.abnamro.pna.restservices.customeragreements.dtos.v2;


import com.abnamro.pna.restservices.customeragreements.dtos.ProductDetailsDTO;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertEquals;

public class AgreementV2Test {

    AgreementV2 agreement = new AgreementV2();
    ProductDetailsDTO productDetailsDTO = new ProductDetailsDTO();


    @Test
    public void test_getAgreementId() {
        agreement.setAgreementId("Test");
        assertEquals("Test", agreement.getAgreementId());
    }

    @Test
    public void test_getLifecycleStatus() {
        agreement.setLifecycleStatus("Test");
        assertEquals("Test", agreement.getLifecycleStatus());
    }


    @Test
    public void test_getNickName() {
        agreement.setNickName("Test");
        assertEquals("Test", agreement.getNickName());
    }


    @Test
    public void test_getAgreementAdministrationKey() {
        List<String> list = new ArrayList<>();
        list.add("Test");
        agreement.setAgreementAdministrationKeys(list);
        assertEquals(list, agreement.getAgreementAdministrationKeys());
    }

    @Test
    public void test_getProductId() {
        agreement.setProductId(1);
        assertEquals(Integer.valueOf(1), agreement.getProductId());
    }

    @Test
    public void test_getProductGroupIds() {
        List<Integer> list = new ArrayList<>();
        list.add(1);
        agreement.setProductGroupIds(list);
        assertEquals(list, agreement.getProductGroupIds());
    }


    @Test
    public void test_getCommercialProductNameNL() {
        agreement.setCommercialProductNameNL("Test");
        assertEquals("Test", agreement.getCommercialProductNameNL());

    }


    @Test
    public void test_getInternalProductNameNL() {
        agreement.setInternalProductNameNL("Test");
        assertEquals("Test", agreement.getInternalProductNameNL());

    }

    @Test
    public void test_getIban() {
        agreement.setIban("Test");
        assertEquals("Test", agreement.getIban());

    }

    @Test
    public void test_getPackageAgreementId() {
        agreement.setPackageAgreementId("Test");
        assertEquals("Test", agreement.getPackageAgreementId());

    }
}
