package com.abnamro.pna.restservices.customeragreements.dtos;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class AgreementTest {

    Agreement agreement = new Agreement();
    ProductDetailsDTO productDetailsDTO = new ProductDetailsDTO();


    @Test
    public void test_getAgreementId() {
        agreement.setAgreementId("Test");
        assertEquals("Test", agreement.getAgreementId());
    }

    @Test
    public void test_getCommercialContractNumber() {
        agreement.setCommercialContractNumber("Test");
        assertEquals("Test", agreement.getCommercialContractNumber());
    }


    @Test
    public void test_getAgreementLifeCycleStatusType() {
        agreement.setAgreementLifeCycleStatusType("Test");
        assertEquals("Test", agreement.getAgreementLifeCycleStatusType());
    }


    @Test
    public void test_getNickName() {
        agreement.setNickName("Test");
        assertEquals("Test", agreement.getNickName());
    }


    @Test
    public void test_getAgreementAdministrationKey() {
        List<String> list = new ArrayList<>();
        list.add("Test");
        agreement.setAgreementAdministrationKey(list);
        assertEquals(list, agreement.getAgreementAdministrationKey());
    }

    @Test
    public void test_getProduct() {
        agreement.setProduct(productDetailsDTO);
        assertEquals(productDetailsDTO, agreement.getProduct());
    }

}
