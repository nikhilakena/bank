# Introduction
This is scheduled batch application for updating the agreements based on the update timestamp. This runs automatically every morning.

# Local Build
To build the project locally, standard java17 and maven setup is required.
- Use command ```mvn clean install```

# Running locally
To run this application on your local machine you need to have the database connection, and also you should have the required certificates for OP-IAG

# Deployment
Standard Azure CD pipeline is configured which deploys the application on app-service.

# ref doc for webjob
https://learn.microsoft.com/en-us/azure/app-service/webjobs-create

# Team
PNC Core team (mail_pnc_core@nl.abnamro.com)