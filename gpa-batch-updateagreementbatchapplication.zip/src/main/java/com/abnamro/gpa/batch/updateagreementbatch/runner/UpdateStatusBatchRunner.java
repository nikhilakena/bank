/**
 *
 */
package com.abnamro.gpa.batch.updateagreementbatch.runner;

import com.abnamro.gpa.batch.updateagreementbatch.constant.GPAUpdateAgreementBatchConstants;
import com.abnamro.gpa.batch.updateagreementbatch.controller.ActivateAgreementController;
import com.abnamro.gpa.batch.updateagreementbatch.controller.DeActivateAgreementController;
import java.util.Calendar;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * This component provides the functionality to Activate/De-Activate agreement(s).
 */
@Component
@Slf4j
public class UpdateStatusBatchRunner implements CommandLineRunner {

  private ActivateAgreementController activateAgreementController;

  private DeActivateAgreementController deActivateAgreementController;

  @Value("${batchindicator:Y}")
  private String batchIndicator;

  @Autowired
  public UpdateStatusBatchRunner(ActivateAgreementController activateAgreementController,
      DeActivateAgreementController deActivateAgreementController) {
    this.activateAgreementController = activateAgreementController;
    this.deActivateAgreementController = deActivateAgreementController;
  }

  /**
   * This method is used to activate agreement based on start date
   * !ActivateAgreementController.batchTriggerDate.equals(todayDate())
   */
  public void activateAgreementBasedOnStartDate() {
    final String LOG_METHOD = "activateAgreementBasedOnStartDate";
    log.info(String.format("%s: %s", LOG_METHOD, "Start activateAgreementBasedOnStartDate"));
    if (GPAUpdateAgreementBatchConstants.DEFAULT_BATCH_INDICATOR.equals(batchIndicator)
        && ActivateAgreementController.batchTriggerDate == null
        || !isSimilarDate(ActivateAgreementController.batchTriggerDate, todayDate())) {
      activateAgreementController.activateAgreementBasedOnStartDate();
      log.info(String.format("%s: %s", LOG_METHOD, "Agreements activated"));
    }
  }

  /**
   * This method is used to update agreement to deactivate based on the end date
   */
  public void deActivateAgreementBasedOnEndDate() {
    final String LOG_METHOD = "deActivateAgreementBasedOnEndDate";
    log.info(String.format("%s: %s", LOG_METHOD, "Start deActivateAgreementBasedOnEndDate"));
    if (GPAUpdateAgreementBatchConstants.DEFAULT_BATCH_INDICATOR.equals(batchIndicator)
        && DeActivateAgreementController.batchTriggerDate == null
        || !isSimilarDate(DeActivateAgreementController.batchTriggerDate, todayDate())) {
      deActivateAgreementController.deActivateAgreementBasedOnEndDate();
      log.info(String.format("%s: %s", LOG_METHOD, "Agreements de-activated"));
    }
  }

  private Date todayDate() {
    final Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DATE, 0);
    return cal.getTime();
  }

  private boolean isSimilarDate(Date batchTriggeredDate, Date currentDate) {
    boolean flag = false;
    Calendar batchTriggeredDateCal = Calendar.getInstance();
    batchTriggeredDateCal.setTime(batchTriggeredDate);
    Calendar currentDateCal = Calendar.getInstance();
    currentDateCal.setTime(currentDate);

    if (batchTriggeredDateCal.get(Calendar.DAY_OF_YEAR) == currentDateCal.get(Calendar.DAY_OF_YEAR)
        && batchTriggeredDateCal.get(Calendar.MONTH) == currentDateCal.get(Calendar.MONTH)
        && batchTriggeredDateCal.get(Calendar.YEAR) == currentDateCal.get(Calendar.YEAR)) {
      flag = true;
    }
    return flag;
  }

  /**
   * This method will be called as soon as springboot application boots
   *
   * @param args String
   * @throws Exception
   */
  @Override
  public void run(String... args) throws Exception {
    log.debug("Start of execution");
    deActivateAgreementBasedOnEndDate();
    activateAgreementBasedOnStartDate();
  }
}
