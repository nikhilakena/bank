package com.abnamro.gpa.batch.updateagreementbatch.exceptions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * This class contains an array of Error messages
 */
public class Errors implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * List of errors to set
   *
   * @param errors
   */
  public void setErrors(List<Error> errors) {
    this.errors = errors;
  }

  /**
   * List of error messages
   */
  private List<Error> errors;

  /**
   * Get list of Errors
   *
   * @return errors
   */
  public List<Error> getErrors() {
    if (errors == null) {
      errors = new ArrayList<Error>();
    }
    return this.errors;
  }
}
