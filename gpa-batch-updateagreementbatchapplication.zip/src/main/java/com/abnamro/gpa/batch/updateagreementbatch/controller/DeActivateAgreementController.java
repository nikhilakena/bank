/**
 *
 */
package com.abnamro.gpa.batch.updateagreementbatch.controller;

import com.abnamro.gpa.batch.updateagreementbatch.constant.GPAUpdateAgreementBatchConstants;
import com.abnamro.gpa.batch.updateagreementbatch.constant.GPAUpdateAgreementBatchLogConstants;
import com.abnamro.gpa.batch.updateagreementbatch.dao.GPAUpdateAgreementBatchDAO;
import com.abnamro.gpa.batch.updateagreementbatch.dao.GPAUpdateAgreementBatchDAOException;
import com.abnamro.gpa.batch.updateagreementbatch.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.ContractHeaderStatusType;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.InputHeaderDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.UpdateContractHeaderInputDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.v2.ContractHeaderUtilV2;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This controller provides the functionality to deactivate an agreement
 */
@Component
@Slf4j
public class DeActivateAgreementController {

  @Autowired
  private GPAUpdateAgreementBatchDAO agreementDao;

  @Autowired
  private ContractHeaderUtilV2 contractHeaderUtil;

  public static Date batchTriggerDate = null;

  /**
   * This method sets the batch trigger date as current date
   *
   * @param currentDate it contains current date
   */
  public synchronized void setBatchTriggerDate(Date currentDate) {
    batchTriggerDate = currentDate;
  }

  /**
   * This method is used to retrieve Agreements in batch of 20 records and process deactivation
   */
  public void deActivateAgreementBasedOnEndDate() {
    final String LOG_METHOD = "deActivateAgreementBasedOnEndDate()";

    List<GPAAgreementDTO> gpaAgreementDTOList = new ArrayList<>();
    long lastAgreementId = 0;
    try {
      do {
        log.info(String.format("%s: %s", LOG_METHOD, "Retrieving the agreements which ended yesterday"));
        gpaAgreementDTOList = agreementDao.fetchAgreementsEndedYesterday(lastAgreementId);
        if (!gpaAgreementDTOList.isEmpty()) {
          updateContractHeader(gpaAgreementDTOList);
          lastAgreementId = gpaAgreementDTOList.get(gpaAgreementDTOList.size() - 1).getAgreementId();
          updateAgreementStatusInGPA(gpaAgreementDTOList, GPAUpdateAgreementBatchConstants.INACTIVE);
        }
      } while (gpaAgreementDTOList.size() == 20);

      setBatchTriggerDate(todayDate());
      log.info(String.format("%s: %s %s", LOG_METHOD,
          "agreements updated with status as INACTIVE in GPA and CH successfully on ",
          batchTriggerDate == null ? "" : batchTriggerDate.toString()));
    } catch (GPAUpdateAgreementBatchDAOException gpaUpdateAgreementBatchDAOException) {
      log.error(String.format("%s: %s", LOG_METHOD,
              GPAUpdateAgreementBatchLogConstants.LOG_EXCEPTION_IN_DAO_DEACTIVATE_AGREEMENT_CONTROLLER),
          gpaUpdateAgreementBatchDAOException);
      throw new WebApplicationException(gpaUpdateAgreementBatchDAOException, Response.Status.INTERNAL_SERVER_ERROR);
    }
  }

  private Date todayDate() {
    final Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DATE, 0);
    return cal.getTime();
  }

  private void updateContractHeader(List<GPAAgreementDTO> gpaAgreementDTOList) {
    final String LOG_METHOD = "updateContractHeader(gpaAgreementDTOList)";
    for (GPAAgreementDTO gpaAGreementDTO : gpaAgreementDTOList) {
      InputHeaderDTO inputHeaderDTO = null;
      UpdateContractHeaderInputDTO updateContractHeaderInputDTO = new UpdateContractHeaderInputDTO();
      updateContractHeaderInputDTO.setContractStatus(ContractHeaderStatusType.INACTIVE);
      updateContractHeaderInputDTO.setCommercialContractNumber(String.valueOf(gpaAGreementDTO.getAgreementId()));
      updateContractHeaderInputDTO.setBcNumber(gpaAGreementDTO.getCustomerId());
      updateContractHeaderInputDTO.setProductId(gpaAGreementDTO.getProductId());
      updateContractHeaderInputDTO.setUserId(GPAUpdateAgreementBatchConstants.USER_ID);

      try {
        log.debug("Calling CH application to update the agreement status");
        contractHeaderUtil.updateContractHeader(String.valueOf(inputHeaderDTO), updateContractHeaderInputDTO);
      } catch (ContractHeaderServiceInvokerException contractHeaderServiceInvokerException) {
        log.error(String.format("%s: %s", LOG_METHOD,
                GPAUpdateAgreementBatchLogConstants.LOG_EXCEPTION_IN_CONTRACTHEADER_ACTIVATE_AGREEMENT_CONTROLLER),
            contractHeaderServiceInvokerException);
        throw new WebApplicationException(contractHeaderServiceInvokerException, Response.Status.INTERNAL_SERVER_ERROR);
      }
    }
    log.info(String.format("%s: %d %s", LOG_METHOD, gpaAgreementDTOList == null ? 0 : gpaAgreementDTOList.size(),
        "Agreement(s) updated in CH."));
  }

  /**
   * This method is used to update status of agreement in GPA system after agreements are updated inactive in Contract
   * header
   *
   * @param gpaAgreementDTOList List of GPAAgreementDTO
   * @param status              Status of agreement
   */
  public void updateAgreementStatusInGPA(List<GPAAgreementDTO> gpaAgreementDTOList, String status) {

    final String LOG_METHOD = "updateAgreementStatusInGPA(gpaAgreementDTOList, status)";
    for (GPAAgreementDTO gpaAgreementDTO : gpaAgreementDTOList) {
      try {
        gpaAgreementDTO.setUpdatedBy(GPAUpdateAgreementBatchConstants.UPDATED_BY);
        gpaAgreementDTO.setStatus(status);
        gpaAgreementDTO.setUpdatedTimeStamp(new Timestamp(System.currentTimeMillis()));
        agreementDao.updateAgreementStatusInGPA(gpaAgreementDTO);
      } catch (GPAUpdateAgreementBatchDAOException gpaUpdateAgreementBatchDAOException) {
        log.error(String.format("%s: %s", LOG_METHOD,
                GPAUpdateAgreementBatchLogConstants.LOG_EXCEPTION_IN_UPDATING_AGREEMENT_IN_GPA_CONTROLLER),
            gpaUpdateAgreementBatchDAOException);
        throw new WebApplicationException(gpaUpdateAgreementBatchDAOException, Response.Status.INTERNAL_SERVER_ERROR);
      }
    }
    log.info(
        String.format("%s: %s %d agreements", LOG_METHOD, "Status updated in GPA for ", gpaAgreementDTOList.size()));
  }
}