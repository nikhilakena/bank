package com.abnamro.gpa.batch.updateagreementbatch.exceptions;

import java.io.Serializable;


/**
 * The type Error.
 * <p>
 * This class contains an error related information
 */
public class Error implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Combined fields operationId, backEndId and  message as a key
   */
  private String code;

  /**
   * Value from field message
   */
  private String message;

  /**
   * Unique end-2-end trace id received from the consumer
   */
  private String traceId;

  /**
   * Value from field HTTP-status
   */
  private String status;

  /**
   * Handle multiple errors for a single request
   */
  private String[] params;

  /**
   * Gets code.
   *
   * @return the code
   */
  public String getCode() {
    return code;
  }

  /**
   * Sets code.
   *
   * @param code the code
   */
  public void setCode(String code) {
    this.code = code;
  }

  /**
   * Gets message.
   *
   * @return the message
   */
  public String getMessage() {
    return message;
  }

  /**
   * Sets message.
   *
   * @param message the message
   */
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   * Gets trace id.
   *
   * @return the trace id
   */
  public String getTraceId() {
    return traceId;
  }

  /**
   * Sets trace id.
   *
   * @param traceId the trace id
   */
  public void setTraceId(String traceId) {
    this.traceId = traceId;
  }

  /**
   * Gets status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Sets status.
   *
   * @param status the status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Get params string [ ].
   *
   * @return the string [ ]
   */
  public String[] getParams() {
    return params;
  }

  /**
   * Sets params.
   *
   * @param params the params
   */
  public void setParams(String[] params) {
    this.params = params;
  }
}
