/**
 *
 */
package com.abnamro.gpa.batch.updateagreementbatch.dtos;

import java.io.Serializable;
import lombok.Data;


/**
 * Holds the details of term
 */
@Data
public class GPAAgreementTermDTO implements Serializable {

  /**
   * default value
   */
  private static final long serialVersionUID = 1L;

  private String termName;

  private String termValue;

}
