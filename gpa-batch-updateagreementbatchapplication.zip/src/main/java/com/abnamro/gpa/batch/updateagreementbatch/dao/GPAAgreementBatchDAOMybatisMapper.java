package com.abnamro.gpa.batch.updateagreementbatch.dao;


import com.abnamro.gpa.batch.updateagreementbatch.dtos.GPAAgreementDTO;
import java.time.LocalDateTime;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * This is the mybatis query mapper interface class for GPAAgreementDAO
 */
@Mapper
public interface GPAAgreementBatchDAOMybatisMapper {

  /**
   * This method is used to  agreement with details
   *
   * @param schemaName                is String
   * @param lastAgreementId           is long
   * @param agreementStartDate        is String
   * @param agreementStartDateEndTime is String
   * @return List<GPAAgreementDTO> is list of GPAAgreementDTO
   */
  public List<GPAAgreementDTO> fetchGPAAgreementsWithDetails(
      @Param("schemaName") final String schemaName,
      @Param("lastAgreementId") final Long lastAgreementId,
      @Param("agreementStartDate") final LocalDateTime agreementStartDate,
      @Param("agreementStartDateEndTime") final LocalDateTime agreementStartDateEndTime);

  /**
   * This method is used to  agreement with details
   *
   * @param schemaName              is String
   * @param lastAgreementId         is long
   * @param agreementEndDate        is String
   * @param agreementEndDateEndTime is String
   * @return List<GPAAgreementDTO> is list of GPAAgreementDTO
   */
  public List<GPAAgreementDTO> fetchGPAAgreementsEndedWithDetails(
      @Param("schemaName") final String schemaName,
      @Param("lastAgreementId") final Long lastAgreementId,
      @Param("agreementEndDate") final LocalDateTime agreementEndDate,
      @Param("agreementEndDateEndTime") final LocalDateTime agreementEndDateEndTime);

  /**
   * This method updates the agreement status in GPA database
   *
   * @param schemaName      database schema name
   * @param gpaAgreementDTO GPAAgreement DTO details
   */
  public void updateAgreementStatusInGPA(@Param("schemaName") final String schemaName,
      @Param("gpaAgreementDTO") final GPAAgreementDTO gpaAgreementDTO);

}
