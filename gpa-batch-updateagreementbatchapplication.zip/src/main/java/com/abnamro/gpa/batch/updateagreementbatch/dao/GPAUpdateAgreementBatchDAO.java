package com.abnamro.gpa.batch.updateagreementbatch.dao;

import com.abnamro.gpa.batch.updateagreementbatch.constant.GPAUpdateAgreementBatchLogConstants;
import com.abnamro.gpa.batch.updateagreementbatch.constant.GPAUpdateAgreementBatchMessageKeys;
import com.abnamro.gpa.batch.updateagreementbatch.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.Message;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.MessageType;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.Messages;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * DAO class for retrieving and updating the agreement in GPA
 */
@Component
@Slf4j
public class GPAUpdateAgreementBatchDAO {

  @Value("${schemaName:dbo}")
  private String dbSchemaPrefix;

  @Autowired
  private SqlSessionFactory sqlSessionFactory;

  /**
   * This Method is used to retrieve agreements which have start date as today and active in GPA system
   *
   * @param lastAgreementId is long
   * @return gpaAgreementDTOList list of GPAAgreementDTO
   * @throws GPAUpdateAgreementBatchDAOException is an exception
   */
  public List<GPAAgreementDTO> fetchAgreementsStartedToday(long lastAgreementId)
      throws GPAUpdateAgreementBatchDAOException {
    String logMethod = "fetchAgreementsStartedToday(lastAgreementId)";
    log.info(String.format("%s: %s", logMethod, "Retrieving the records from the database"));
    List<GPAAgreementDTO> gpaAgreementDTOList = new ArrayList<GPAAgreementDTO>();

    try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
      LocalDateTime agreementStartDate = LocalDateTime.now().withHour(0)
          .withMinute(0).withSecond(0).withNano(0);
      Timestamp.valueOf(agreementStartDate);

      LocalDateTime agreementStartDateEndTime = LocalDateTime.now().withHour(23)
          .withMinute(59).withSecond(59).withNano(999999999);
      Timestamp.valueOf(agreementStartDateEndTime);

      gpaAgreementDTOList = sqlSession.getMapper(GPAAgreementBatchDAOMybatisMapper.class)
          .fetchGPAAgreementsWithDetails(dbSchemaPrefix, lastAgreementId, agreementStartDate,
              agreementStartDateEndTime);
      log.info(
          String.format("%s: %s %d", logMethod, "Number of records fetched from the database:",
              gpaAgreementDTOList.size()));
    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAUpdateAgreementBatchMessageKeys.MYBATIS_EXCEPTION_WHILE_FETCHING_AGREEMENTS),
          MessageType.getError());
      log.error(String.format("%s: %s", logMethod,
          GPAUpdateAgreementBatchLogConstants.LOG_ERROR_DATA_FETCH_AGREEMENTS), exception);
      throw new GPAUpdateAgreementBatchDAOException(messages);
    }
    return gpaAgreementDTOList;
  }

  /**
   * This Method is used to retrieve agreements which have end date as today and active in GPA system
   *
   * @param lastAgreementId is long
   * @return gpaAgreementDTOList is Long list
   * @throws GPAUpdateAgreementBatchDAOException is an exception
   */
  public List<GPAAgreementDTO> fetchAgreementsEndedYesterday(long lastAgreementId)
      throws GPAUpdateAgreementBatchDAOException {
    String logMethod = "fetchAgreementsEndedYesterday(lastAgreementId)";
    log.info(String.format("%s: %s", logMethod, "Retrieving the records from the database"));
    List<GPAAgreementDTO> gpaAgreementDTOList = new ArrayList<>();
    try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
      LocalDateTime now = LocalDateTime.now();
      LocalDateTime agreementEndDate = now.minusDays(1).withHour(0).withMinute(0).withSecond(0)
          .withNano(0);
      Timestamp.valueOf(agreementEndDate);

      LocalDateTime agreementEndDateEndTime = now.minusDays(1).withHour(23).withMinute(59)
          .withSecond(59).withNano(999999999);
      Timestamp.valueOf(agreementEndDateEndTime);

      gpaAgreementDTOList = sqlSession.getMapper(GPAAgreementBatchDAOMybatisMapper.class)
          .fetchGPAAgreementsEndedWithDetails(dbSchemaPrefix, lastAgreementId, agreementEndDate,
              agreementEndDateEndTime);
      log.info(String.format("%s: %s %d", logMethod, "Number of records fetched from the database: ",
          gpaAgreementDTOList.size()));
    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      messages.addMessage(new Message(
          GPAUpdateAgreementBatchMessageKeys.MYBATIS_EXCEPTION_WHILE_FETCHING_AGREEMENTS), MessageType.getError());
      log.error(String.format("%s: %s", logMethod, GPAUpdateAgreementBatchLogConstants.LOG_ERROR_DATA_FETCH_AGREEMENTS),
          exception);
      throw new GPAUpdateAgreementBatchDAOException(messages);
    }
    return gpaAgreementDTOList;
  }

  /**
   * This method is used to update agreements in GPA after it is inactive in contract header
   *
   * @param gpaAgreementDTO is GPAAgreementDTO
   * @throws GPAUpdateAgreementBatchDAOException is an exception
   */
  public void updateAgreementStatusInGPA(GPAAgreementDTO gpaAgreementDTO)
      throws GPAUpdateAgreementBatchDAOException {
    String logMethod = "updateAgreementStatusInGPA(gpaAgreementDTO)";
    try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
      sqlSession.getMapper(GPAAgreementBatchDAOMybatisMapper.class).updateAgreementStatusInGPA(dbSchemaPrefix,
          gpaAgreementDTO);
      log.info(String.format("%s: %s %d  is updated in the database", logMethod,
          "Agreement status for agreement ", gpaAgreementDTO.getAgreementId()));
    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAUpdateAgreementBatchMessageKeys.MYBATIS_EXCEPTION_WHILE_UPDATING_AGREEMENT_STATUS),
          MessageType.getError());
      log.error(
          String.format("%s: %s", logMethod, GPAUpdateAgreementBatchLogConstants.LOG_ERROR_UPDATING_AGREEMENT_STATUS),
          exception);
      throw new GPAUpdateAgreementBatchDAOException(messages);
    }
  }
}
