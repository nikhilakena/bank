/**
 *
 */
package com.abnamro.gpa.batch.updateagreementbatch.dtos;


import java.sql.Timestamp;
import java.util.List;
import lombok.Data;

/**
 * This is a view class which holds the details of agreement
 */
@Data
public class GPAAgreementDTO {

  /**
   * default value
   */
  private static final long serialVersionUID = 1L;

  private long agreementId;

  private int productId;

  private long customerId;

  private String status;

  private Timestamp startDate;

  private Timestamp endDate;

  private String createdBy;

  private Timestamp createdTimeStamp;

  private String updatedBy;

  private Timestamp updatedTimeStamp;

  private List<GPAAgreementTermDTO> terms;
}
