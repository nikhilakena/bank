/**
 *
 */
package com.abnamro.gpa.batch.updateagreementbatch.controller;

import com.abnamro.gpa.batch.updateagreementbatch.constant.GPAUpdateAgreementBatchConstants;
import com.abnamro.gpa.batch.updateagreementbatch.constant.GPAUpdateAgreementBatchLogConstants;
import com.abnamro.gpa.batch.updateagreementbatch.dao.GPAUpdateAgreementBatchDAO;
import com.abnamro.gpa.batch.updateagreementbatch.dao.GPAUpdateAgreementBatchDAOException;
import com.abnamro.gpa.batch.updateagreementbatch.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.ContractHeaderStatusType;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.InputHeaderDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.UpdateContractHeaderInputDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.v2.ContractHeaderUtilV2;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This controller provides the functionality to activate an agreement
 */
@Component
@Slf4j
public class ActivateAgreementController {

  @Autowired
  private GPAUpdateAgreementBatchDAO agreementDao;

  @Autowired
  private ContractHeaderUtilV2 contractHeaderUtil;

  /**
   * The constant batchTriggerDate.
   */
  public static Date batchTriggerDate = null;

  /**
   * This method sets the batch trigger date as current date
   *
   * @param currentDate it contains current date
   */
  public synchronized void setBatchTriggerDate(Date currentDate) {
    batchTriggerDate = currentDate;
  }

  /**
   * This method is used to activate agreements, and it iterates agreements in patch 20 records
   */
  public void activateAgreementBasedOnStartDate() {
    final String LOG_METHOD = "activateAgreementBasedOnStartDate()";
    List<GPAAgreementDTO> gpaAgreementDTOList = new ArrayList<>();
    long lastAgreementId = 0;
    try {
      do {
        log.info(String.format("%s: %s", LOG_METHOD, "Retrieving the agreements which is starting today"));
        gpaAgreementDTOList = agreementDao.fetchAgreementsStartedToday(lastAgreementId);
        if (gpaAgreementDTOList != null && !gpaAgreementDTOList.isEmpty()) {
          updateContractHeader(gpaAgreementDTOList);
          lastAgreementId = gpaAgreementDTOList.get(gpaAgreementDTOList.size() - 1)
              .getAgreementId();
        }
      } while (gpaAgreementDTOList != null && gpaAgreementDTOList.size() == 20);

      setBatchTriggerDate(todayDate());
      log.info(String.format("%s: %s %s", LOG_METHOD,
          "agreements updated with status as ACTIVE in GPA and CH successfully on ",
          batchTriggerDate == null ? "" : batchTriggerDate.toString()));
    } catch (GPAUpdateAgreementBatchDAOException gpaUpdateAgreementBatchDAOException) {
      log.error(String.format("%s: %s", LOG_METHOD,
              GPAUpdateAgreementBatchLogConstants.LOG_EXCEPTION_IN_DAO_ACTIVATE_AGREEMENT_CONTROLLER),
          gpaUpdateAgreementBatchDAOException);
      throw new WebApplicationException(gpaUpdateAgreementBatchDAOException,
          Response.Status.INTERNAL_SERVER_ERROR);
    }
  }

  private Date todayDate() {
    final Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DATE, 0);
    return cal.getTime();
  }

  private void updateContractHeader(List<GPAAgreementDTO> gpaAgreementDTOList)
      throws WebApplicationException {
    final String LOG_METHOD = "updateContractHeader(gpaAgreementDTOList)";
    try {
      for (GPAAgreementDTO gpaAGreementDTO : gpaAgreementDTOList) {
        InputHeaderDTO inputHeaderDTO = null;
        UpdateContractHeaderInputDTO updateContractHeaderInputDTO = new UpdateContractHeaderInputDTO();
        updateContractHeaderInputDTO.setContractStatus(ContractHeaderStatusType.ACTIVE);
        updateContractHeaderInputDTO.setCommercialContractNumber(
            String.valueOf(gpaAGreementDTO.getAgreementId()));
        updateContractHeaderInputDTO.setBcNumber(gpaAGreementDTO.getCustomerId());
        updateContractHeaderInputDTO.setProductId(gpaAGreementDTO.getProductId());

        updateContractHeaderInputDTO.setUserId(GPAUpdateAgreementBatchConstants.USER_ID);
        log.debug("Calling CH application to update the agreement status");
        contractHeaderUtil.updateContractHeader(String.valueOf(inputHeaderDTO),
            updateContractHeaderInputDTO);
      }
    } catch (ContractHeaderServiceInvokerException contractHeaderServiceInvokerException) {
      log.error(String.format("%s: %s", LOG_METHOD,
              GPAUpdateAgreementBatchLogConstants.LOG_EXCEPTION_IN_CONTRACTHEADER_ACTIVATE_AGREEMENT_CONTROLLER),
          contractHeaderServiceInvokerException);
      throw new WebApplicationException(contractHeaderServiceInvokerException,
          Response.Status.INTERNAL_SERVER_ERROR);
    }
    log.info(String.format("%s: %d %s", LOG_METHOD, gpaAgreementDTOList == null ? 0 : gpaAgreementDTOList.size(),
        "Agreement(s) updated in CH."));
  }
}
