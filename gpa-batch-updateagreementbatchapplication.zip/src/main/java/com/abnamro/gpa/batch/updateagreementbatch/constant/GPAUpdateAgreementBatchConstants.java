package com.abnamro.gpa.batch.updateagreementbatch.constant;

/**
 * This is the constant file
 */
public class GPAUpdateAgreementBatchConstants {

  public static final String TERM_MANDATORY_YES = "Y";
  public static final String TERM_MANDATORY_NO = "N";
  public static final String BATCH_INDICATOR = "batchindicator";
  public static final String DEFAULT_BATCH_INDICATOR = "Y";
  public static final String UPDATED_BY = "GPAA";
  public static final String USER_ID = "GPAA_Batch";
  public static final String INACTIVE = "INACTIVE";
}
