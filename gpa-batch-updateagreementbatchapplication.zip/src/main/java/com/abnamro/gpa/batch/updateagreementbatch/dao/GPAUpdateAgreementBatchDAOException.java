/**
 *
 */
package com.abnamro.gpa.batch.updateagreementbatch.dao;

import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.DAOException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.Messages;

/**
 * This is DAO layer exception class for the GPAUpdateAgreementDAO.
 */
public class GPAUpdateAgreementBatchDAOException extends DAOException {

  /**
   * This is a default constructor
   */
  public GPAUpdateAgreementBatchDAOException() {
    super();

  }

  /**
   * This is a parameterized constructor
   *
   * @param messages is a Messages
   */
  public GPAUpdateAgreementBatchDAOException(Messages messages) {
    super(messages);
  }

}
