package com.abnamro.gpa.batch.updateagreementbatch.exceptions;

import com.abnamro.gpa.batch.updateagreementbatch.dao.GPAUpdateAgreementBatchDAOException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.apiconnectors.agreementcustomerrefapi.Errors;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.BusinessApplicationException;
import java.io.Serializable;
import org.springframework.http.HttpStatus;


/**
 * The type GPA agreement web app exception.
 */
public class GPAAgreementWebAppException extends BusinessApplicationException implements
    Serializable {

  private static final long serialVersionUID = 1L;

  private transient Errors error;
  private transient Object response;
  private HttpStatus status;

  /**
   * Instantiates a new Gpa agreement web app exception.
   *
   * @param status the status
   * @param errors the errors
   */
  public GPAAgreementWebAppException(HttpStatus status, Errors errors) {
    this.error = errors;
    this.status = status;
  }

  /**
   * Instantiates a new Gpa agreement web app exception.
   *
   * @param status   the status
   * @param response the response
   */
  public GPAAgreementWebAppException(HttpStatus status, Object response) {
    this.status = status;
    this.response = response;
  }

  /**
   * Gets error.
   *
   * @return the error
   */
  public Errors getError() {
    return error;
  }

  /**
   * Sets error.
   *
   * @param error the error
   */
  public void setError(Errors error) {
    this.error = error;
  }

  /**
   * Gets status.
   *
   * @return the status
   */
  public HttpStatus getStatus() {
    return status;
  }

  /**
   * Sets status.
   *
   * @param status the status
   */
  public void setStatus(HttpStatus status) {
    this.status = status;
  }

  /**
   * Gets response.
   *
   * @return the response
   */
  public Object getResponse() {
    return response;
  }

  /**
   * Sets response.
   *
   * @param response the response
   */
  public void setResponse(Object response) {
    this.response = response;
  }

  /**
   * Default Constructor to set the value to null
   */
  public GPAAgreementWebAppException() {
    super();
  }

  /**
   * Instantiates a new Gpa agreement web app exception.
   *
   * @param e    the e
   * @param http the http
   */
  public GPAAgreementWebAppException(GPAUpdateAgreementBatchDAOException e, HttpStatus http) {
    this.status = http;
    this.response = e;
  }
}
