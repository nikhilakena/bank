package com.abnamro.gpa.batch.updateagreementbatch.constant;

/**
 * This is the DAO layer log constant file for GPAUpdateAgreementBatch
 */
public class GPAUpdateAgreementBatchLogConstants {

  public static final String LOG_ERROR_IBATIS_INITIALIZATION = "LOG_GPAUAB_001";
  public static final String LOG_ERROR_DATA_UPDATE_STATUS = "LOG_GPAUAB_002";
  public static final String LOG_ERROR_DB_CONNECTION = "LOG_GPAUAB_003";
  public static final String LOG_ERROR_DB_CONNECTION_READ_AGREEMENT = "LOG_GPAUAB_007";
  public static final String LOG_ERROR_DATA_READ = "LOG_GPAUAB_008";
  public static final String LOG_ERROR_DB_CONNECTION_FETCH = "LOG_GPAUAB_009";
  public static final String LOG_ERROR_OBJECT_TO_STRING_MAPPING = "LOG_GPAUAB_110";
  public static final String LOG_ERROR_DATA_FETCH_AGREEMENTS = "LOG_GPAUAB_011";
  public static final String LOG_EXCEPTION_IN_DAO_ACTIVATE_AGREEMENT_CONTROLLER = "LOG_GPAUAB_012";
  public static final String LOG_EXCEPTION_IN_CONTRACTHEADER_ACTIVATE_AGREEMENT_CONTROLLER = "LOG_GPAUAB_013";
  public static final String LOG_EXCEPTION_IN_DAO_DEACTIVATE_AGREEMENT_CONTROLLER = "LOG_GPAUAB_014";
  public static final String LOG_EXCEPTION_IN_UPDATING_AGREEMENT_IN_GPA_CONTROLLER = "LOG_GPAUAB_015";
  public static final String LOG_ERROR_UPDATING_AGREEMENT_STATUS = "LOG_GPAUAB_016";
  public static final String LOG_ERROR_DB_CONNECTION_UPDATING_AGREEMENT_STATUS = "LOG_GPAUAB_017";


}
