package com.abnamro.gpa.batch.updateagreementbatch.constant;

import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.MessageKey;

/**
 * This is the DAO layer Message key constant file for GPAUpdateAgreementBatch
 */
public class GPAUpdateAgreementBatchMessageKeys {

  public static final MessageKey MYBATIS_EXCEPTION_WHILE_FETCHING_AGREEMENTS = new MessageKey(
      "MESSAGE_GPAG_003");

  public static final MessageKey MYBATIS_EXCEPTION_WHILE_UPDATING_AGREEMENT_STATUS = new MessageKey(
      "MESSAGE_GPAG_006");

}
