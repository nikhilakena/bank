package com.abnamro.gpa.batch.updateagreementbatch;

import jakarta.annotation.PostConstruct;
import java.util.TimeZone;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.abnamro.gpa.batch.updateagreementbatch",
    "com.abnamro.gpa.generic.contractheaderserviceinvoker"})
@MapperScan({"com.abnamro.gpa.batch.updateagreementbatch.dao"})
public class UpdateStatusBatchApplication {

  /**
   * It will boot the application
   *
   * @param args parameter
   */
  public static void main(String[] args) {
    ConfigurableApplicationContext configurableContext = SpringApplication.run(
        UpdateStatusBatchApplication.class, args);
    configurableContext.close();
  }

  /**
   * Set the timezone to Europe/Amsterdam
   */
  @PostConstruct
  public void setTimeZoneToDutch() {
    TimeZone.setDefault(TimeZone.getTimeZone("Europe/Amsterdam"));
  }
}
