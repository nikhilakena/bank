package com.abnamro.gpa.batch.updateagreementbatch.dtos;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.abnamro.gpa.batch.updateagreementbatch.constant.GPAUpdateAgreementBatchConstants;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class GPAAgreementDTOTest {

  @Test
  void testConstructor() {
    GPAAgreementDTO testSubject = new GPAAgreementDTO();
    testSubject.setAgreementId(123456789L);
    testSubject.setCustomerId(12345678L);
    testSubject.setProductId(1234);
    testSubject.setUpdatedBy("GPAA");
    testSubject.setCreatedBy("batch");
    testSubject.setStatus("ACTIVE");
    testSubject.setStartDate(Timestamp.valueOf("2023-12-11 00:00:00"));
    testSubject.setEndDate(Timestamp.valueOf("9999-12-11 00:00:00"));
    testSubject.setCreatedTimeStamp(Timestamp.valueOf("2023-12-11 11:11:11"));
    testSubject.setUpdatedTimeStamp(Timestamp.valueOf("2023-12-12 12:12:12"));
    Assertions.assertEquals(123456789L, testSubject.getAgreementId());
    Assertions.assertEquals(12345678L, testSubject.getCustomerId());
    Assertions.assertEquals(1234, testSubject.getProductId());
    Assertions.assertEquals(GPAUpdateAgreementBatchConstants.UPDATED_BY,
        testSubject.getUpdatedBy());
    Assertions.assertEquals("batch", testSubject.getCreatedBy());
    Assertions.assertEquals("ACTIVE", testSubject.getStatus());
    Assertions.assertEquals(Timestamp.valueOf("2023-12-11 11:11:11"), testSubject.getCreatedTimeStamp());
    Assertions.assertEquals(Timestamp.valueOf("2023-12-12 12:12:12"), testSubject.getUpdatedTimeStamp());
    Assertions.assertEquals(Timestamp.valueOf("2023-12-11 00:00:00"), testSubject.getStartDate());
    Assertions.assertEquals(Timestamp.valueOf("9999-12-11 00:00:00"), testSubject.getEndDate());

    GPAAgreementTermDTO actualGpaAgreementTermDTO = new GPAAgreementTermDTO();
    actualGpaAgreementTermDTO.setTermName("Term Name");
    actualGpaAgreementTermDTO.setTermValue("42");
    List<GPAAgreementTermDTO> terms = new ArrayList<>();
    terms.add(actualGpaAgreementTermDTO);
    testSubject.setTerms(terms);
    assertEquals("Term Name", testSubject.getTerms().get(0).getTermName());
    assertEquals("42", testSubject.getTerms().get(0).getTermValue());
  }
}