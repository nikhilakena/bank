/**
 *
 */
package com.abnamro.gpa.batch.updateagreementbatch.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import com.abnamro.gpa.batch.updateagreementbatch.dao.GPAUpdateAgreementBatchDAO;
import com.abnamro.gpa.batch.updateagreementbatch.dao.GPAUpdateAgreementBatchDAOException;
import com.abnamro.gpa.batch.updateagreementbatch.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.InputHeaderDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.UpdateContractHeaderInputDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.v2.ContractHeaderUtilV2;
import jakarta.ws.rs.WebApplicationException;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ActivateAgreementControllerTest {

	@Mock
	private GPAUpdateAgreementBatchDAO agreementDao;

	@Mock
	private ContractHeaderUtilV2 contractHeaderUtil;

	@InjectMocks
	private ActivateAgreementController underTest;

	@Test
	void testActivateAgreementBasedOnStartDateWithNoRecords() {

		List<GPAAgreementDTO> gpaAgreementDTOList = new ArrayList<>();
		long lastAgreementId=0;

		try {
			Mockito.lenient().when(agreementDao.fetchAgreementsStartedToday(lastAgreementId)).thenReturn(gpaAgreementDTOList);
			underTest.activateAgreementBasedOnStartDate();
		} catch (GPAUpdateAgreementBatchDAOException | WebApplicationException e) {
			fail("No Exception expected");
		}
	}

	@Test
	void testActivateAgreementBasedOnStartDateWithOneRecord()
			throws ContractHeaderServiceInvokerException {

		List<GPAAgreementDTO> gpaAgreementDTOList = new ArrayList<>();
		GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
		gpaAgreementDTOList.add(agreementDTO);

		try {
			Mockito.lenient().when(agreementDao.fetchAgreementsStartedToday(Mockito.anyLong())).thenReturn(gpaAgreementDTOList);
			Mockito.lenient().when(contractHeaderUtil.updateContractHeader(String.valueOf(Mockito.any(
					InputHeaderDTO.class)), Mockito.any(UpdateContractHeaderInputDTO.class))).thenReturn(true);
			underTest.activateAgreementBasedOnStartDate();
		} catch (GPAUpdateAgreementBatchDAOException | WebApplicationException e) {
			fail("No Exception expected");
		}
	}

	@Test
	@Disabled
	void testActivateAgreementBasedOnStartDateWithException()
			throws ContractHeaderServiceInvokerException {

		List<GPAAgreementDTO> gpaAgreementDTOList = new ArrayList<>();
		GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
		gpaAgreementDTOList.add(agreementDTO);

		try {
			when(agreementDao.fetchAgreementsStartedToday(Mockito.anyLong())).thenReturn(gpaAgreementDTOList);
			when(contractHeaderUtil.updateContractHeader(String.valueOf(Mockito.any(
					InputHeaderDTO.class)), Mockito.any(UpdateContractHeaderInputDTO.class))).thenThrow(new ContractHeaderServiceInvokerException());
			assertThrows(ContractHeaderServiceInvokerException.class,
					() -> underTest.activateAgreementBasedOnStartDate());
		} catch (GPAUpdateAgreementBatchDAOException | WebApplicationException e) {
			fail("No Exception expected");
		}
	}

	@Test
	void testActivateAgreementBasedOnStartDateWithDAOException() throws Exception {

		List<GPAAgreementDTO> gpaAgreementDTOList = new ArrayList<>();
		GPAAgreementDTO gpaAgreementDTO= new GPAAgreementDTO();
		gpaAgreementDTO.setAgreementId(1343757257);
		gpaAgreementDTO.setCustomerId(353);
		gpaAgreementDTO.setProductId(4261);
		gpaAgreementDTOList.add(gpaAgreementDTO);
		long lastAgreementId=0;

		try {
			Mockito.lenient().when(agreementDao.fetchAgreementsStartedToday(lastAgreementId)).thenThrow(new GPAUpdateAgreementBatchDAOException());
			underTest.activateAgreementBasedOnStartDate();
		} catch (WebApplicationException e) {
			assertEquals(500, e.getResponse().getStatus());
		}
	}

}
