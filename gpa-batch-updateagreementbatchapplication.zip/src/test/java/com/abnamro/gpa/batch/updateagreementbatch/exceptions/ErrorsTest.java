package com.abnamro.gpa.batch.updateagreementbatch.exceptions;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class ErrorsTest {

    @Test
    void testGetErrors() {
        assertTrue((new Errors()).getErrors().isEmpty());
    }

    @Test
    void testGetErrors2() {
        Errors errors = new Errors();
        ArrayList<Error> errorList = new ArrayList<>();
        errors.setErrors(errorList);
        List<Error> actualErrors = errors.getErrors();
        assertSame(errorList, actualErrors);
        assertTrue(actualErrors.isEmpty());
    }

    @Test
    void testConstructor() {
        Errors actualErrors = new Errors();
        ArrayList<Error> errorList = new ArrayList<>();
        actualErrors.setErrors(errorList);
        assertSame(errorList, actualErrors.getErrors());
    }
}

