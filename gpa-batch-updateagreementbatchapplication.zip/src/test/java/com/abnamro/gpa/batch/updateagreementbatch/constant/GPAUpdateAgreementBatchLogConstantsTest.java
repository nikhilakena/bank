package com.abnamro.gpa.batch.updateagreementbatch.constant;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GPAUpdateAgreementBatchLogConstantsTest {

	@Test
	void test() {
		assertEquals("LOG_GPAUAB_001",GPAUpdateAgreementBatchLogConstants.LOG_ERROR_IBATIS_INITIALIZATION );
		assertEquals("LOG_GPAUAB_002",GPAUpdateAgreementBatchLogConstants.LOG_ERROR_DATA_UPDATE_STATUS );
		assertEquals("LOG_GPAUAB_003",GPAUpdateAgreementBatchLogConstants.LOG_ERROR_DB_CONNECTION );
		assertEquals("LOG_GPAUAB_007",GPAUpdateAgreementBatchLogConstants.LOG_ERROR_DB_CONNECTION_READ_AGREEMENT );
		assertEquals("LOG_GPAUAB_008",GPAUpdateAgreementBatchLogConstants.LOG_ERROR_DATA_READ );
		assertEquals("LOG_GPAUAB_009",GPAUpdateAgreementBatchLogConstants.LOG_ERROR_DB_CONNECTION_FETCH );
		assertEquals("LOG_GPAUAB_110",GPAUpdateAgreementBatchLogConstants.LOG_ERROR_OBJECT_TO_STRING_MAPPING );
		assertEquals("LOG_GPAUAB_011",GPAUpdateAgreementBatchLogConstants.LOG_ERROR_DATA_FETCH_AGREEMENTS );
		assertEquals("LOG_GPAUAB_012",GPAUpdateAgreementBatchLogConstants.LOG_EXCEPTION_IN_DAO_ACTIVATE_AGREEMENT_CONTROLLER );
		assertEquals("LOG_GPAUAB_013",GPAUpdateAgreementBatchLogConstants.LOG_EXCEPTION_IN_CONTRACTHEADER_ACTIVATE_AGREEMENT_CONTROLLER );
		assertEquals("LOG_GPAUAB_014",GPAUpdateAgreementBatchLogConstants.LOG_EXCEPTION_IN_DAO_DEACTIVATE_AGREEMENT_CONTROLLER );
		assertEquals("LOG_GPAUAB_015",GPAUpdateAgreementBatchLogConstants.LOG_EXCEPTION_IN_UPDATING_AGREEMENT_IN_GPA_CONTROLLER );
		assertEquals("LOG_GPAUAB_016",GPAUpdateAgreementBatchLogConstants.LOG_ERROR_UPDATING_AGREEMENT_STATUS );
		assertEquals("LOG_GPAUAB_017",GPAUpdateAgreementBatchLogConstants.LOG_ERROR_DB_CONNECTION_UPDATING_AGREEMENT_STATUS );


	}

}
