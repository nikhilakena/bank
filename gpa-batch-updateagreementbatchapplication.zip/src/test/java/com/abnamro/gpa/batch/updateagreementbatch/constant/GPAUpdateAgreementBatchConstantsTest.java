package com.abnamro.gpa.batch.updateagreementbatch.constant;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class GPAUpdateAgreementBatchConstantsTest {

	@Test
	void test() {
		assertEquals("batchindicator",GPAUpdateAgreementBatchConstants.BATCH_INDICATOR );
		assertEquals("Y",GPAUpdateAgreementBatchConstants.DEFAULT_BATCH_INDICATOR );
		assertEquals("N",GPAUpdateAgreementBatchConstants.TERM_MANDATORY_NO );
		assertEquals("Y",GPAUpdateAgreementBatchConstants.TERM_MANDATORY_YES );
		
	}

}
