package com.abnamro.gpa.batch.updateagreementbatch.exceptions;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import com.abnamro.gpa.generic.contractheaderserviceinvoker.apiconnectors.agreementcustomerrefapi.Errors;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

@ExtendWith(MockitoExtension.class)
class GPAAgreementWebAppExceptionTest {

  @InjectMocks
  private GPAAgreementWebAppException actualGpaAgreementWebAppException;

  @Test
  void testConstructor() {
    Errors errors = new Errors();
    errors.setErrors(new ArrayList<>());
    actualGpaAgreementWebAppException.setError(errors);
    actualGpaAgreementWebAppException.setResponse("Response");
    actualGpaAgreementWebAppException.setStatus(HttpStatus.CONTINUE);
    assertSame(errors, actualGpaAgreementWebAppException.getError());
    assertEquals(HttpStatus.CONTINUE, actualGpaAgreementWebAppException.getStatus());
  }

}

