package com.abnamro.gpa.batch.updateagreementbatch.constants.v2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GPAAgreementConstantsV2Test {

	@Test
	void test() {
//		assertEquals("AGREEMENT_ID_ALREADY_PRESENT",GPAAgreementConstantsV2.CODE_AGREEMENT_ID_ALREADY_PRESENT);
	}

}
