package com.abnamro.gpa.batch.updateagreementbatch.dtos;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class GPAAgreementTermDTOTest {

  @Test
  void testConstructor() {
    GPAAgreementTermDTO actualGpaAgreementTermDTO = new GPAAgreementTermDTO();
    actualGpaAgreementTermDTO.setTermName("Term Name");
    actualGpaAgreementTermDTO.setTermValue("42");
    assertEquals("Term Name", actualGpaAgreementTermDTO.getTermName());
    assertEquals("42", actualGpaAgreementTermDTO.getTermValue());
  }
}

