package com.abnamro.gpa.batch.updateagreementbatch.runner;

import com.abnamro.gpa.batch.updateagreementbatch.controller.ActivateAgreementController;
import com.abnamro.gpa.batch.updateagreementbatch.controller.DeActivateAgreementController;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UpdateStatusBatchRunnerTest {

  @Mock
  private ActivateAgreementController activateAgreementController;
  @Mock
  private DeActivateAgreementController deActivateAgreementController;

  @InjectMocks
  private UpdateStatusBatchRunner runner;

  private Date todayDate() {
    final Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DATE, 0);
    return cal.getTime();
  }

  void testActivateAgreementBasedOnStartDate() {
    Mockito.doNothing().when(activateAgreementController).activateAgreementBasedOnStartDate();
    runner.activateAgreementBasedOnStartDate();
  }

  void testDeActivateAgreementBasedOnStartDate() {
    Mockito.doNothing().when(deActivateAgreementController).deActivateAgreementBasedOnEndDate();
    runner.deActivateAgreementBasedOnEndDate();
  }
}