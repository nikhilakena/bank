package com.abnamro.gpa.batch.updateagreementbatch.exceptions;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class ErrorTest {
    @InjectMocks
    Error error;

    @Test
    void test_getCode() {
        error.setCode("test");
        assertEquals("test", error.getCode(), "Code is not matched with the expected value");
    }

    @Test
    void test_getMessage() {
        error.setMessage("test");
        assertEquals("test", error.getMessage(), "Message is not matched with the expected value");
    }

    @Test
    void test_getTraceId() {
        error.setTraceId("test");
        assertEquals("test", error.getTraceId(), "Trace Id is not matched with the expected value");
    }

    @Test
    void test_getStatus() {
        error.setStatus("test");
        assertEquals("test", error.getStatus(), "Status is not matched with the expected value");
    }


}

