package com.abnamro.gpa.batch.updateagreementbatch.dao;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.abnamro.gpa.batch.updateagreementbatch.constant.GPAUpdateAgreementBatchConstants;
import com.abnamro.gpa.batch.updateagreementbatch.dtos.GPAAgreementDTO;
import java.sql.Timestamp;
import java.util.ArrayList;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GPAUpdateAgreementBatchDAOTest {

  @InjectMocks
  private GPAUpdateAgreementBatchDAO testSubject;
  @Mock
  private SqlSession sqlSession;
  @Mock
  private SqlSessionFactory sqlSessionFactory;
  @Mock
  private GPAAgreementBatchDAOMybatisMapper mapper;

  @Test
  void testFetchAgreementsStartedToday() {
    when(sqlSessionFactory.openSession()).thenReturn(sqlSession);
    when(sqlSession.getMapper(GPAAgreementBatchDAOMybatisMapper.class)).thenThrow(
        new PersistenceException());
    assertThrows(GPAUpdateAgreementBatchDAOException.class,
        () -> testSubject.fetchAgreementsStartedToday(123L));
  }

  @Test
  void testFetchAgreementsEndedYesterday() {
    when(sqlSessionFactory.openSession()).thenReturn(sqlSession);
    when(sqlSession.getMapper(GPAAgreementBatchDAOMybatisMapper.class)).thenThrow(
        new PersistenceException());
    assertThrows(GPAUpdateAgreementBatchDAOException.class,
        () -> testSubject.fetchAgreementsEndedYesterday(123L));
  }

  @Test
  void testUpdateAgreementStatusInGPA_exception() throws GPAUpdateAgreementBatchDAOException {
    GPAAgreementDTO gpaAgreementDTO = new GPAAgreementDTO();
    gpaAgreementDTO.setAgreementId(123L);
    gpaAgreementDTO.setCreatedBy("Jan 1, 2020 8:00am GMT+0100");
    gpaAgreementDTO.setCreatedTimeStamp(mock(Timestamp.class));
    gpaAgreementDTO.setCustomerId(123L);
    gpaAgreementDTO.setEndDate(mock(Timestamp.class));
    gpaAgreementDTO.setProductId(123);
    gpaAgreementDTO.setStartDate(mock(Timestamp.class));
    gpaAgreementDTO.setStatus("Status");
    gpaAgreementDTO.setTerms(new ArrayList<>());
    gpaAgreementDTO.setUpdatedBy(GPAUpdateAgreementBatchConstants.UPDATED_BY);
    gpaAgreementDTO.setUpdatedTimeStamp(mock(Timestamp.class));
    when(sqlSessionFactory.openSession()).thenReturn(sqlSession);
    when(sqlSession.getMapper(GPAAgreementBatchDAOMybatisMapper.class)).thenThrow(
        new PersistenceException());
    assertThrows(GPAUpdateAgreementBatchDAOException.class,
        () -> testSubject.updateAgreementStatusInGPA(gpaAgreementDTO));
  }
}