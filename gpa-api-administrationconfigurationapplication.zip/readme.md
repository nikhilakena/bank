# Introduction

This application maintains the administrations in generic product agreement administration.

# Build

To build the project locally, standard java17 and maven setup is required.

- Use command ```mvn clean install```

# Deployment

Standard CD pipeline is configured, and it is based on the PITA template.

# Team

PNC Core team (mail_pnc_core@nl.abnamro.com)
