package com.abnamro.gpa.generic.security;

import com.abnamro.gpa.generic.security.JwtAuthHelper;
import com.abnamro.gpa.generic.security.PingFederateValidateUserInfo;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class JwtAuthHelperTest {

    @Spy
    JwtAuthHelper jwtAuthHelper;

    String idTokenWithListRoles;

    String idTokenWithStringRoles;

    String userJwtSession;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(jwtAuthHelper,"secretKey","secret_key");
        ReflectionTestUtils.setField(jwtAuthHelper,"sessionExpirationInHrs",1);
        this.idTokenWithListRoles = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjJnb2ZNS1I0Q195WXp4TkJ4cDFvelJNa0hlbyJ9.eyJzdWIiOiJTRjIwMDEiLCJhdWQiOiJPRUlPIiwianRpIjoiZ0V2VTE1S2FxVTI4a2ZiSnFPVjU5VSIsImlzcyI6Imh0dHBzOi8vc2VjdXJpdHktaWZzLXRlc3QuY29ubmVjdC5hYm5hbXJvLmNvbTo5MDMxIiwiaWF0IjoxNjY1ODE5NjE5LCJleHAiOjE2NjU4MjMyMTksImF1dGhfdGltZSI6MTY2NTgxOTYxOSwicm9sZXMiOlsiU0dfQVBQX09FSU9fQUJSIiwiU0dfQVBQX09FSU9fQ29uc3VsdF9Qb3J0Zm9saW8iLCJTR19BUFBfT0VJT19QdXNoX1Bvc2l0aW9uIiwiU0dfQVBQX09FSU9fU3RvY2tzYW5kQm9uZHMiLCJTR19BUFBfT0VJT19QbGFjZW1lbnQiLCJTR19BUFBfT0VJT19QdXNoX1RhcmdldF9NYXJrZXQiLCJTR19BUFBfT0VJT19EaXNjb3VudCIsIlNHX0FQUF9PRUlPX1B1c2hfTW9uZXkiLCJTR19BUFBfT0VJT19QdXNoX0Fzc29ydG1lbnQiLCJTR19BUFBfT0VJT19Jbml0aWF0b3IiLCJTR19BUFBfT0VJT19DaGFubmVsX1NlbGVjdGlvbiIsIlNHX0FQUF9PRUlPX1B1c2hfQUJSX0J1eWFuZFNlbGwiLCJTR19BUFBfT0VJT19PcHRpb25zIl0sImF0bSI6Ik1TZWNFbXBsb3llZU9JREMiLCJ1c2VyaWQiOiJTRjIwMDEiLCJhdXRodHlwZSI6ImtlcmIifQ.BqclE4GC51wJK86c_XYs61XKYmrrYFsRUuLExas7yceg_do1KB5HFybcjUKgE7KbW7WWxohMkw6ELP7EvstP3QUpT9HifsXsAHPdXi4l50aMRvyAwE9z6Sxz4_tPMk6SwN2oBiN3-ZvGLo1X0MBzVrW2gYWfyIAhAB1sAx4tG9SoHUmvZ9wEAC-nBZ6PDsxZuukN9CHl_zs-JwYIUFKrKNZAdJ_3UFhXs6TUUZ8MYgQQWrGKBcPoPMXUuw9SErlUdLolwonQGWoRzcqNxTK6pC1c9_GcKcP-nHU7TpSibiVckFG4KNKvGhq_Yd1inJie7I7w8o888BhZ83b6sRP6Ng";
        this.idTokenWithStringRoles = "eyJhbGciOiJIUzI1NiIsImtpZCI6IjJnb2ZNS1I0Q195WXp4TkJ4cDFvelJNa0hlbyJ9.eyJzdWIiOiJTRjIwMDEiLCJhdWQiOiJPRUlPIiwianRpIjoiZ0V2VTE1S2FxVTI4a2ZiSnFPVjU5VSIsImlzcyI6Imh0dHBzOi8vc2VjdXJpdHktaWZzLXRlc3QuY29ubmVjdC5hYm5hbXJvLmNvbTo5MDMxIiwiaWF0IjoxNjY1ODE5NjE5LCJleHAiOjE2NjU4MjMyMTksImF1dGhfdGltZSI6MTY2NTgxOTYxOSwicm9sZXMiOiJTR19BUFBfT0VJT19BQlIiLCJhdG0iOiJNU2VjRW1wbG95ZWVPSURDIiwidXNlcmlkIjoiU0YyMDAxIiwiYXV0aHR5cGUiOiJrZXJiIn0.4ItcdTk1gFjXjrZccWSjgpDQL9u6zd63a7A-xT435zk";
    }

    @Test
    void testCreateUserSession() {
        String token = jwtAuthHelper.createUserJwtSession(this.idTokenWithStringRoles);
        this.userJwtSession = token;
        DecodedJWT jwt = jwtAuthHelper.decodeJWTWithoutVerifying(token);
        PingFederateValidateUserInfo pingFederateUserInfoDTO = jwtAuthHelper.verifyUserJwtSession(this.userJwtSession);
        Assertions.assertNotNull(jwt.getExpiresAt());
        Assertions.assertNotNull(jwt.getClaims().get("userid"));
        Assertions.assertTrue(pingFederateUserInfoDTO.isActive());
    }

    @Test
    void testCreateUserSessionWithListRoles() {
        String token = jwtAuthHelper.createUserJwtSession(this.idTokenWithListRoles);
        this.userJwtSession = token;
        DecodedJWT jwt = jwtAuthHelper.decodeJWTWithoutVerifying(token);
        PingFederateValidateUserInfo pingFederateUserInfoDTO = jwtAuthHelper.verifyUserJwtSession(this.userJwtSession);
        Assertions.assertNotNull(jwt.getExpiresAt());
        Assertions.assertNotNull(jwt.getClaims().get("userid"));
        Assertions.assertTrue(pingFederateUserInfoDTO.isActive());
    }

}
