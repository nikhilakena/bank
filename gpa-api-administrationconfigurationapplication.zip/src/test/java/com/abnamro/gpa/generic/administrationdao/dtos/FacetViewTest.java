package com.abnamro.gpa.generic.administrationdao.dtos;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class FacetViewTest {
    @Test
    public void createFacet() {
        FacetView facet = new FacetView();
        Assertions.assertNotNull(facet);
        Assertions.assertNull(facet.getType());
        Assertions.assertNull(facet.getValue());
        Assertions.assertNull(facet.getCreatedBy());
        Assertions.assertNull(facet.getCreatedTimeStamp());
        Assertions.assertNull(facet.getModifiedBy());
        Assertions.assertNull(facet.getModifiedTimeStamp());
    }

    @Test
    public void setFacet() {
        LocalDateTime creationatDeTime = LocalDateTime.of(2020, 3, 12, 18, 21, 58);
        Timestamp creationTimestamp = Timestamp.valueOf(creationatDeTime);

        LocalDateTime modificationDateTime = LocalDateTime.of(2020, 3, 12, 18, 21, 58);
        Timestamp modificationTimestamp = Timestamp.valueOf(modificationDateTime);

        FacetView facet = new FacetView();
        facet.setType("type 1");
        facet.setValue("value 1");
        facet.setCreatedBy("unit test create");
        facet.setCreatedTimeStamp(creationTimestamp);
        facet.setModifiedBy("unit test modify");
        facet.setModifiedTimeStamp(modificationTimestamp);
    }
}
