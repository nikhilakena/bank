package com.abnamro.gpa.generic.administrationdao.dtos;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class ProductAdminMapViewTest {
    @Test
    public void createProductAdminMap() {
        ProductAdminMapView productAdminMap = new ProductAdminMapView();
        Assertions.assertNotNull(productAdminMap);
        Assertions.assertEquals(0, productAdminMap.getProductId());
        Assertions.assertNull(productAdminMap.getCreatedBy());
        Assertions.assertNull(productAdminMap.getCreatedTimeStamp());
        Assertions.assertNull(productAdminMap.getModifiedBy());
        Assertions.assertNull(productAdminMap.getModifiedTimeStamp());
    }

    @Test
    public void setProductAdminMap() {
        LocalDateTime creationatDeTime = LocalDateTime.of(2020, 3, 12, 18, 21, 58);
        Timestamp creationTimestamp = Timestamp.valueOf(creationatDeTime);

        LocalDateTime modificationDateTime = LocalDateTime.of(2020, 3, 12, 18, 21, 58);
        Timestamp modificationTimestamp = Timestamp.valueOf(modificationDateTime);

        ProductAdminMapView productAdminMap = new ProductAdminMapView();
        productAdminMap.setProductId(54);
        productAdminMap.setCreatedBy("unit test create");
        productAdminMap.setCreatedTimeStamp(creationTimestamp);
        productAdminMap.setModifiedBy("unit test modify");
        productAdminMap.setModifiedTimeStamp(modificationTimestamp);

        Assertions.assertEquals(54, productAdminMap.getProductId());
        Assertions.assertEquals("unit test create", productAdminMap.getCreatedBy());
        Assertions.assertEquals(creationTimestamp, productAdminMap.getCreatedTimeStamp());
        Assertions.assertEquals("unit test modify", productAdminMap.getModifiedBy());
        Assertions.assertEquals(modificationTimestamp, productAdminMap.getModifiedTimeStamp());
    }
}
