package com.abnamro.gpa.generic.administrationdao.dtos;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AdministrationViewTest {
    @Test
    public void createAdministration() {
        AdministrationView administration = new AdministrationView();
        Assertions.assertEquals(0, administration.getId());
        Assertions.assertNull(administration.getName());
        Assertions.assertNull(administration.getOarId());
        Assertions.assertNull(administration.getDescription());
        Assertions.assertNull(administration.getCreatedBy());
        Assertions.assertNull(administration.getCreatedTimeStamp());
        Assertions.assertNull(administration.getModifiedBy());
        Assertions.assertNull(administration.getModifiedTimeStamp());
        Assertions.assertNull(administration.getProductAdminMapViews());
        Assertions.assertNull(administration.getAdminTermViews());
    }

    @Test
    public void setAdministrationValues() {
        LocalDateTime creationatDeTime = LocalDateTime.of(2020, 3, 12, 18, 21, 58);
        Timestamp creationTimestamp = Timestamp.valueOf(creationatDeTime);

        LocalDateTime modificationDateTime = LocalDateTime.of(2020, 3, 12, 18, 21, 58);
        Timestamp modificationTimestamp = Timestamp.valueOf(modificationDateTime);

        AdministrationView administration = new AdministrationView();
        administration.setId(3);
        administration.setName("administration name");
        administration.setOarId("AAB.SYS.89723");
        administration.setDescription("administration description");
        administration.setCreatedBy("unit test");
        administration.setCreatedTimeStamp(creationTimestamp);
        administration.setModifiedBy("unit test modifier");
        administration.setModifiedTimeStamp(modificationTimestamp);

        Assertions.assertEquals(3, administration.getId());
        Assertions.assertEquals("administration name", administration.getName());
        Assertions.assertEquals("AAB.SYS.89723", administration.getOarId());
        Assertions.assertEquals("administration description", administration.getDescription());
        Assertions.assertEquals("unit test", administration.getCreatedBy());
        Assertions.assertEquals(creationTimestamp, administration.getCreatedTimeStamp());
        Assertions.assertEquals("unit test modifier", administration.getModifiedBy());
        Assertions.assertEquals(modificationTimestamp, administration.getModifiedTimeStamp());
    }

    @Test
    public void setProductAdminMaps() {
        List<ProductAdminMapView> productAdminMaps = new ArrayList<>();
        ProductAdminMapView map1 = new ProductAdminMapView();
        map1.setProductId(101);
        map1.setCreatedBy("unit test 1");
        map1.setModifiedBy("unit test modification 1");
        productAdminMaps.add(map1);

        ProductAdminMapView map2 = new ProductAdminMapView();
        map2.setProductId(102);
        map2.setCreatedBy("unit test 2");
        map2.setModifiedBy("unit test modification 2");
        productAdminMaps.add(map2);

        ProductAdminMapView map3 = new ProductAdminMapView();
        map3.setProductId(103);
        map3.setCreatedBy("unit test 3");
        map3.setModifiedBy("unit test modification 3");
        productAdminMaps.add(map3);

        ProductAdminMapView map4 = new ProductAdminMapView();
        map4.setProductId(104);
        map4.setCreatedBy("unit test 4");
        map4.setModifiedBy("unit test modification 4");
        productAdminMaps.add(map4);

        AdministrationView administration = new AdministrationView();
        administration.setId(100);
        administration.setProductAdminMapViews(productAdminMaps);

        Assertions.assertNotNull(administration.getProductAdminMapViews());
        Assertions.assertEquals(4, administration.getProductAdminMapViews().size());

        Assertions.assertNotNull(administration.getProductAdminMapViews().get(2));
        Assertions.assertEquals(103, administration.getProductAdminMapViews().get(2).getProductId());
        Assertions.assertEquals("unit test modification 3", administration.getProductAdminMapViews().get(2).getModifiedBy());
        Assertions.assertNotNull(administration.getProductAdminMapViews().get(3));
        Assertions.assertEquals("unit test 4", administration.getProductAdminMapViews().get(3).getCreatedBy());
        Assertions.assertEquals(104, administration.getProductAdminMapViews().get(3).getProductId());
    }

    @Test
    public void setAdminTerms() {
        List<AdminTermView> adminTerms = new ArrayList<>();
        AdminTermView adminTerm1 = new AdminTermView();
        adminTerm1.setTermId(201);
        adminTerm1.setName("admin term 1");
        adminTerm1.setDescription("description 1");
        adminTerms.add(adminTerm1);

        AdminTermView adminTerm2 = new AdminTermView();
        adminTerm2.setTermId(202);
        adminTerm2.setName("admin term 2");
        adminTerm2.setDescription("description 2");
        adminTerms.add(adminTerm2);

        AdminTermView adminTerm3 = new AdminTermView();
        adminTerm3.setTermId(203);
        adminTerm3.setName("admin term 3");
        adminTerm3.setDescription("description 3");
        adminTerms.add(adminTerm3);

        AdministrationView administration = new AdministrationView();
        administration.setId(200);
        administration.setAdminTermViews(adminTerms);

        Assertions.assertNotNull(administration.getAdminTermViews());
        Assertions.assertEquals(3, administration.getAdminTermViews().size());

        Assertions.assertNotNull(administration.getAdminTermViews().get(0));
        Assertions.assertEquals(201, administration.getAdminTermViews().get(0).getTermId());
        Assertions.assertEquals("description 1", administration.getAdminTermViews().get(0).getDescription());

        Assertions.assertNotNull(administration.getAdminTermViews().get(2));
        Assertions.assertEquals(203, administration.getAdminTermViews().get(2).getTermId());
        Assertions.assertEquals("description 3", administration.getAdminTermViews().get(2).getDescription());
    }
}
