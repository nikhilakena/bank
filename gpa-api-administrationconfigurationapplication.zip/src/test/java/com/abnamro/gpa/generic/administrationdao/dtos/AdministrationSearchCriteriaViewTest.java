package com.abnamro.gpa.generic.administrationdao.dtos;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Date;

public class AdministrationSearchCriteriaViewTest {
    @Test
    public void createAdministrationSearchCriteriaView() {
        AdministrationSearchCriteriaView administration = new AdministrationSearchCriteriaView();
        Assertions.assertNotNull(administration);
        Assertions.assertEquals(0, administration.getAdministrationId());
        Assertions.assertNull(administration.getAdministrationName());
        Assertions.assertNull(administration.getOarId());
        Assertions.assertNull(administration.getCreatedBy());
        Assertions.assertNull(administration.getCreatedTimestampFrom());
        Assertions.assertNull(administration.getCreatedTimestampTo());
    }

    @Test
    public void checkGettersAndSetters() {
        LocalDateTime startDateTime = LocalDateTime.of(2020, 3, 12, 18, 21, 58);
        Timestamp startTimestamp = Timestamp.valueOf(startDateTime);

        LocalDateTime endDateTime = LocalDateTime.of(2021, 5, 8, 21, 3, 2);
        Timestamp endTimestamp = Timestamp.valueOf(endDateTime);

        AdministrationSearchCriteriaView administration = new AdministrationSearchCriteriaView();
        administration.setAdministrationId(14);
        administration.setAdministrationName("unit test administration name");
        administration.setOarId("AAB.SYS.2342");
        administration.setCreatedBy("unit test");
        administration.setCreatedTimestampFrom(startTimestamp);
        administration.setCreatedTimestampTo(endTimestamp);

        Assertions.assertEquals(14, administration.getAdministrationId());
        Assertions.assertEquals("unit test administration name", administration.getAdministrationName());
        Assertions.assertEquals("AAB.SYS.2342", administration.getOarId());
        Assertions.assertEquals("unit test", administration.getCreatedBy());
        Assertions.assertEquals(startTimestamp, administration.getCreatedTimestampFrom());
        Assertions.assertEquals(endTimestamp, administration.getCreatedTimestampTo());
    }
}
