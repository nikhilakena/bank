package com.abnamro.gpa.generic.administrationdao.test;

import com.abnamro.gpa.generic.administrationdao.constants.GPAAdministrationDAOMessageKeys;
import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAOHelper;
import com.abnamro.gpa.generic.administrationdao.dtos.AdminTermView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationSearchCriteriaView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.Message;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@ExtendWith(SpringExtension.class)
public class GPAAdministrationDAOHelperTest {
    @Test
    public void validateSearchAdministrationIdCorrect() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(0);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchAdministrationIdCorrectToo() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchAdministrationIdCorrectVeryHigh() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(999999);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchAdministrationIdTooHigh() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(1000000);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_SEARCHING_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_003", errorMessage.getMessageKeyId());
        }
    }

    @Test
    public void validateSearchAdministrationNameNull() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName(null);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchAdministrationNameEmpty() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName("");
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchAdministrationNameShort() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName("administration name");
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchAdministrationNameLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        String length10 = "0123456789";
        String length150 = length10.repeat(15);
        searchCriteria.setAdministrationName(length150);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchAdministrationNameTooLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        String length10 = "0123456789";
        String length151 = length10.repeat(15) + "1";
        searchCriteria.setAdministrationName(length151);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_SEARCHING_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_003", errorMessage.getMessageKeyId());
        }
    }

    @Test
    public void validateSearchOarIdNull() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName("0123456789");
        searchCriteria.setOarId(null);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchOarIdEmpty() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName("0123456789");
        searchCriteria.setOarId("");
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchOarIdLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName("0123456789");
        String oarId10 = "1234567890";
        String oarId50 = oarId10.repeat(5);
        searchCriteria.setOarId(oarId50);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchOarIdTooLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName("0123456789");
        String oarId10 = "1234567890";
        String oarId51 = oarId10.repeat(5) + "1";
        searchCriteria.setOarId(oarId51);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_SEARCHING_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_003", errorMessage.getMessageKeyId());
        }
    }

    @Test
    public void validateSearchCreatedByNull() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName("0123456789");
        searchCriteria.setOarId("1234567890");
        searchCriteria.setCreatedBy(null);
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchCreatedByEmpty() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName("0123456789");
        searchCriteria.setOarId("1234567890");
        searchCriteria.setCreatedBy("");
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchCreatedByLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName("0123456789");
        searchCriteria.setOarId("1234567890");
        searchCriteria.setCreatedBy("12345678");
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateSearchCreatedByTooLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationSearchCriteriaView searchCriteria = new AdministrationSearchCriteriaView();
        searchCriteria.setAdministrationId(10);
        searchCriteria.setAdministrationName("0123456789");
        searchCriteria.setOarId("1234567890");
        searchCriteria.setCreatedBy("1234567890");
        try {
            daoHelper.validateSearchAdministrationRequest(searchCriteria);
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_SEARCHING_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_003", errorMessage.getMessageKeyId());
        }
    }

    @Test
    public void validateCreateAdministrationIdCorrect() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(0);
        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationIdCorrectToo() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }


    @Test
    public void validateCreateAdministrationIdCorrectVeryHigh() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(999999);
        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationIdTooHigh() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(1000000);
        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_CREATING_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_006", errorMessage.getMessageKeyId());
        }
    }
    @Test
    public void validateCreateAdministrationNameNull() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName(null);

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationNameEmpty() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("");

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationNameShort() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("administration name");

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationNameLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        String length10 = "0123456789";
        String length150 = length10.repeat(15);
        administrationView.setName(length150);

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationNameTooLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        String length10 = "0123456789";
        String length151 = length10.repeat(15) + "1";
        administrationView.setName(length151);

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
            Assertions.fail("exception expected");

        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_CREATING_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_006", errorMessage.getMessageKeyId());
        }
    }
    @Test
    public void validateCreateAdministrationDescriptionNull() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription(null);

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationDescriptionEmpty() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription("");

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationDescriptionShort() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription("description name");

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationDescriptionLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        String length10 = "0123456789";
        String length300 = length10.repeat(30);
        administrationView.setDescription(length300);

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationDescriptionTooLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        String length10 = "0123456789";
        String length301 = length10.repeat(30)+ "1";
        administrationView.setDescription(length301);

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
            Assertions.fail("exception expected");

        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_CREATING_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_006", errorMessage.getMessageKeyId());
        }
    }
    @Test
    public void validateCreateAdministrationOarIdNull() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription("9876543210");
        administrationView.setOarId(null);

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationOarIdEmpty() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription("9876543210");
        administrationView.setOarId("");

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }



    @Test
    public void validateCreateAdministrationOarIdLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription("9876543210");
        String oarId10 = "1234567890";
        String oarId50 = oarId10.repeat(5);
        administrationView.setOarId(oarId50);

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationOarIdTooLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription("9876543210");
        String oarId10 = "1234567890";
        String oarId51 = oarId10.repeat(5) + "1";
        administrationView.setOarId(oarId51);

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
            Assertions.fail("exception expected");

        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_CREATING_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_006", errorMessage.getMessageKeyId());
        }
    }

    @Test
    public void validateCreateAdministrationCreatedByNull() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription("9876543210");
        administrationView.setOarId("1234567890");
        administrationView.setCreatedBy(null);

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationCreatedByEmpty() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription("9876543210");
        administrationView.setOarId("1234567890");
        administrationView.setCreatedBy("");

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }



    @Test
    public void validateCreateAdministrationCreatedByLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription("9876543210");
        administrationView.setOarId("1234567890");
        administrationView.setCreatedBy("12345678");

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateCreateAdministrationCreatedByTooLong() {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(10);
        administrationView.setName("0123456789");
        administrationView.setDescription("9876543210");
        administrationView.setOarId("1234567890");
        administrationView.setCreatedBy("1234567890");

        try {
            daoHelper.validateCreateAdministrationRequest(administrationView);
            Assertions.fail("exception expected");

        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_CREATING_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_006", errorMessage.getMessageKeyId());
        }
    }

    @Test
    public void validateReadAdministrationInputCorrect(){
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        int administrationId=10;
        int productId=10;
        try {
            daoHelper.validateReadAdministrationInput(administrationId,productId);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateReadAdministrationInputCorrectToo(){
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        int administrationId=0;
        int productId=0;
        try {
            daoHelper.validateReadAdministrationInput(administrationId,productId);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateReadAdministrationInputAdministrationIdHigh(){
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        int administrationId=999999;
        int productId=0;
        try {
            daoHelper.validateReadAdministrationInput(administrationId,productId);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }
    @Test
    public void validateReadAdministrationInputAdministrationIdTooHigh(){
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        int administrationId=1000000;
        int productId=0;
        try {
            daoHelper.validateReadAdministrationInput(administrationId,productId);
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_READ_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_010", errorMessage.getMessageKeyId());
        }
    }

    @Test
    public void validateReadAdministrationInputProductIdHigh(){
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        int administrationId=0;
        int productId=999999;
        try {
            daoHelper.validateReadAdministrationInput(administrationId,productId);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }
    @Test
    public void validateReadAdministrationInputProductIdTooHigh(){
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        int administrationId=0;
        int productId=1000000;
        try {
            daoHelper.validateReadAdministrationInput(administrationId,productId);
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_READ_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_010", errorMessage.getMessageKeyId());
        }
    }
    @Test
    public void validateReadAdministrationInputAdministrationIdProductIdHigh(){
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        int administrationId=999999;
        int productId=999999;
        try {
            daoHelper.validateReadAdministrationInput(administrationId,productId);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }
    @Test
    public void validateReadAdministrationInputAdministrationIdAndProductIdTooHigh(){
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        int administrationId=1000000;
        int productId=1000000;
        try {
            daoHelper.validateReadAdministrationInput(administrationId,productId);
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_READ_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_010", errorMessage.getMessageKeyId());
        }
    }

    @Test
    public void errorInAdminDeletion()
    {
        GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        try {
            daoHelper.errorInAdminDeletion();
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.VALIDATION_EXCEPTION_NO_DATA_FOUND_IN_DELETE_ADMINISTRATION, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_020", errorMessage.getMessageKeyId());
        }

    }
/*
    @Test
    public void productInsertNotAllowed()
    {
        List<Integer> productList = new ArrayList<>();
        productList.add(1);
        productList.add(2);
        boolean lastIndex=true;

       GPAAdministrationDAOHelper daoHelper = new GPAAdministrationDAOHelper();
        try {
            daoHelper.productInsertNotAllowed(productList,lastIndex);
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.assertNotNull(exception.getMessages());
            Message errorMessage = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(errorMessage);
            Assertions.assertEquals(GPAAdministrationDAOMessageKeys.VALIDATION_EXCEPTION_IN_ADMIN_EXISTING_PROD_INSERT_NOT_ALLOWED, errorMessage.getMessageKey());
            Assertions.assertEquals("MESSAGE_ADDA_021", errorMessage.getMessageKeyId());
        }

    }*/

}
