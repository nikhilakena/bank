package com.abnamro.gpa.generic.administrationdao.dtos;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AdminTermViewTest {
    @Test
    public void createAdminTerm() {
        AdminTermView adminTerm = new AdminTermView();
        Assertions.assertEquals(0, adminTerm.getTermId());
        Assertions.assertNull(adminTerm.getName());
        Assertions.assertNull(adminTerm.getDataType());
        Assertions.assertNull(adminTerm.getDescription());
        Assertions.assertNull(adminTerm.getMandatoryIndicator());
        Assertions.assertNull(adminTerm.getCreatedBy());
        Assertions.assertNull(adminTerm.getCreatedTimeStamp());
        Assertions.assertNull(adminTerm.getModifiedBy());
        Assertions.assertNull(adminTerm.getModifiedTimeStamp());
        Assertions.assertNull(adminTerm.getFacetView());
    }

    @Test
    public void setAdminTerm() {
        LocalDateTime creationatDeTime = LocalDateTime.of(2020, 3, 12, 18, 21, 58);
        Timestamp creationTimestamp = Timestamp.valueOf(creationatDeTime);

        LocalDateTime modificationDateTime = LocalDateTime.of(2020, 3, 12, 18, 21, 58);
        Timestamp modificationTimestamp = Timestamp.valueOf(modificationDateTime);

        AdminTermView adminTerm = new AdminTermView();
        adminTerm.setTermId(43);
        adminTerm.setName("admin term 1");
        adminTerm.setDataType("text");
        adminTerm.setDescription("description admin term 1");
        adminTerm.setMandatoryIndicator("true");
        adminTerm.setCreatedBy("unit test create");
        adminTerm.setCreatedTimeStamp(creationTimestamp);
        adminTerm.setModifiedBy("unit test modify");
        adminTerm.setModifiedTimeStamp(modificationTimestamp);

        Assertions.assertEquals(43, adminTerm.getTermId());
        Assertions.assertEquals("admin term 1", adminTerm.getName());
        Assertions.assertEquals("text", adminTerm.getDataType());
        Assertions.assertEquals("description admin term 1", adminTerm.getDescription());
        Assertions.assertEquals("true", adminTerm.getMandatoryIndicator());
        Assertions.assertEquals("unit test create", adminTerm.getCreatedBy());
        Assertions.assertEquals(creationTimestamp, adminTerm.getCreatedTimeStamp());
        Assertions.assertEquals("unit test modify", adminTerm.getModifiedBy());
        Assertions.assertEquals(modificationTimestamp, adminTerm.getModifiedTimeStamp());
        Assertions.assertNull(adminTerm.getFacetView());
    }

    @Test
    public void addFacets() {
        List<FacetView> facets = new ArrayList<>();
        FacetView facet1 = new FacetView();
        facet1.setType("type 1");
        facet1.setValue("value 1");
        facet1.setCreatedBy("unit test create 1");
        facet1.setModifiedBy("unit test modify 1");
        facets.add(facet1);

        FacetView facet2 = new FacetView();
        facet2.setType("type 2");
        facet2.setValue("value 2");
        facet2.setCreatedBy("unit test create 2");
        facet2.setModifiedBy("unit test modify 2");
        facets.add(facet2);

        FacetView facet3 = new FacetView();
        facet3.setType("type 3");
        facet3.setValue("value 3");
        facet3.setCreatedBy("unit test create 3");
        facet3.setModifiedBy("unit test modify 3");
        facets.add(facet3);

        AdminTermView adminTerm = new AdminTermView();
        adminTerm.setFacetView(facets);

        Assertions.assertNotNull(adminTerm.getFacetView());
        Assertions.assertEquals(3, adminTerm.getFacetView().size());
        Assertions.assertNotNull(adminTerm.getFacetView().get(1));
        Assertions.assertEquals("type 2", adminTerm.getFacetView().get(1).getType());
        Assertions.assertEquals("value 2", adminTerm.getFacetView().get(1).getValue());
        Assertions.assertNotNull(adminTerm.getFacetView().get(2));
        Assertions.assertEquals("unit test create 3", adminTerm.getFacetView().get(2).getCreatedBy());
        Assertions.assertEquals("unit test modify 3", adminTerm.getFacetView().get(2).getModifiedBy());
    }
}