package com.abnamro.gpa.generic.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class ErrorsTest {
    @InjectMocks
    Errors errors;

    @Test
    void test_getErrors() {
        List<Error> error = null;
        Error error1 = new Error();
        error1.setCode("test");
        error1.setStatus("test");
        error = Collections.singletonList(error1);
        errors.setErrors(error);
        assertEquals(error, errors.getErrors(), "Errors are not matched with the expected value");
    }

    @Test
    void test_equals() {
        List<Error> error = null;
        Error error1 = new Error();
        error1.setCode("test");
        error1.setStatus("test");
        error = Collections.singletonList(error1);
        boolean test = errors.equals(null);
        boolean test2 = errors.equals(0);
        assertEquals(false, test);
    }

    @Test
    void test_addErrorsItem() {
        Error error = new Error();
        error.setCode("test");
        error.setStatus("test");

        assertNotNull(errors.addErrorsItem(error));

    }
}

