package com.abnamro.gpa.generic.security;


import org.apache.log4j.Logger;


import org.junit.jupiter.api.*;

public class AuthenticationTokenTest {

    private Logger log = Logger.getLogger(this.getClass());

    @BeforeAll
    static void initAll() {
    }

    @AfterAll
    static void tearDownAll() {
    }

    @BeforeEach
    void init() {
    }

    @Test
    @DisplayName("get Credentials")
    public void getCredentials() {
        try {

            Object expectedValue = null;

            String accessTokenc = "";
            PingFederateValidateUserInfo userInfoc = null;

            AuthenticationToken authenticationtoken = new AuthenticationToken(accessTokenc, userInfoc);
            Object actualValue = authenticationtoken.getCredentials();

            Assertions.assertEquals(expectedValue, actualValue);
        } catch (Exception exception) {
            log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
            exception.printStackTrace();
            Assertions.assertFalse(false);
        }
    }

    @Test
    @DisplayName("get Principal")
    public void getPrincipal() {
        try {

            Object expectedValue = null;

            String accessTokenc = "";
            PingFederateValidateUserInfo userInfoc = null;

            AuthenticationToken authenticationtoken = new AuthenticationToken(accessTokenc, userInfoc);
            Object actualValue = authenticationtoken.getPrincipal();


            Assertions.assertEquals(expectedValue, actualValue);
        } catch (Exception exception) {
            log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
            exception.printStackTrace();
            Assertions.assertFalse(false);
        }
    }

    @Test
    @DisplayName("get Access Token")
    public void getAccessToken() {
        try {
            log.info("Starting execution of getAccessToken");
            String expectedValue = "";

            String accessTokenc = "";
            PingFederateValidateUserInfo userInfoc = null;

            AuthenticationToken authenticationtoken = new AuthenticationToken(accessTokenc, userInfoc);
            String actualValue = authenticationtoken.getAccessToken();
            log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);

            Assertions.assertEquals(expectedValue, actualValue);
        } catch (Exception exception) {
            log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
            exception.printStackTrace();
            Assertions.assertFalse(false);
        }
    }

    @Test
    @DisplayName("get User Info")
    public void getUserInfo() {
        try {
            log.info("Starting execution of getUserInfo");
            PingFederateValidateUserInfo expectedValue = null;

            String accessTokenc = "";
            PingFederateValidateUserInfo userInfoc = null;

            AuthenticationToken authenticationtoken = new AuthenticationToken(accessTokenc, userInfoc);
            PingFederateValidateUserInfo actualValue = authenticationtoken.getUserInfo();
            log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);

            Assertions.assertEquals(expectedValue, actualValue);
        } catch (Exception exception) {
            log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
            exception.printStackTrace();
            Assertions.assertFalse(false);
        }
    }

    @AfterEach
    void tearDown() {
    }
}

