package com.abnamro.gpa.generic.administrationdao.exception;

import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageKey;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class GPAAdministrationDAOExceptionTest {
    @Test
    public void createException() {
        GPAAdministrationDAOException exception = new GPAAdministrationDAOException();
        Assertions.assertNotNull(exception);
        Assertions.assertNotNull(exception.getMessages());
        Assertions.assertNotNull(exception.getMessages().getMessages());
    }

    @Test
    public void createExceptionWithBusinessApplicationException() {
        DAOException daoException = createDAOException();
        GPAAdministrationDAOException exception = new GPAAdministrationDAOException(daoException);
        Assertions.assertNotNull(exception);
        Assertions.assertNotNull(exception.getMessages());
        Assertions.assertNotNull(exception.getMessages().getMessages());
    }

    @Test
    public void createExceptionWithMessages() {
        Messages messages = new Messages();
        Message message1 = new Message(new MessageKey("message-key-1"));
        messages.addMessage(message1, MessageType.ERROR);
        Message message2 = new Message(new MessageKey("message-key-2"));
        messages.addMessage(message2, MessageType.INFO);
        Message message3 = new Message(new MessageKey("message-key-3"));
        messages.addMessage(message3, MessageType.INFO);
        GPAAdministrationApplicationException exception = new GPAAdministrationApplicationException(messages);

        Assertions.assertNotNull(exception);
        Assertions.assertNotNull(exception.getMessages());
        Assertions.assertNotNull(exception.getMessages().getMessages());
        Assertions.assertEquals(3, exception.getMessages().getMessages().size());
        Assertions.assertEquals("message-key-1", exception.getMessages().getMessages().get(0).getMessageKeyId());
        Assertions.assertEquals("message-key-2", exception.getMessages().getMessages().get(1).getMessageKeyId());
        Assertions.assertEquals("message-key-3", exception.getMessages().getMessages().get(2).getMessageKeyId());
    }

    private DAOException createDAOException() {
        DAOException exception = new DAOException() {
            @Override
            public Messages getMessages() {
                return super.getMessages();
            }
        };

        return exception;
    }
}
