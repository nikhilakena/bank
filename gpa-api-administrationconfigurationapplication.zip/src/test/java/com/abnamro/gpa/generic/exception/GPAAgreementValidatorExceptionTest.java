package com.abnamro.gpa.generic.exception;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertNotNull;


@ExtendWith(MockitoExtension.class)
public class GPAAgreementValidatorExceptionTest {
    @InjectMocks
    GPAAgreementValidatorException gpaAgreementValidatorException;

    @Test
    void test_getMessages() {
        Message message = new Message(null);
        message.setTraceId("test");
        Messages messages = new Messages();
        messages.setMessages(Collections.singletonList(message));
        gpaAgreementValidatorException.setMessages(messages);
        assertNotNull(gpaAgreementValidatorException.getMessages());

    }

    @Test
    void test_toString() {
        gpaAgreementValidatorException.toString();
        assertNotNull(gpaAgreementValidatorException.toString());
    }
    @Test
    void test_constructor() {
        new GPAAgreementValidatorException();
        assertNotNull(new GPAAgreementValidatorException());
    }

}
