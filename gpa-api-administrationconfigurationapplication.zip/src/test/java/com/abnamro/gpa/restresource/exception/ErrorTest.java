package com.abnamro.gpa.restresource.exception;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ErrorTest {

    Error underTest;
    @Mock
    Error testError;

    String code = "INTERNAL_SERVER_ERROR";
    String message = "Internal Server Error occured";
    String traceId = "NA";
    String status = "NA";
    List<String> params;

    @BeforeEach
    public void startUp() {
        underTest = new Error();

        //set default
        testError = new Error();
        testError.setCode(code);
        testError.setMessage(message);
        testError.setTraceId(traceId);
        testError.setStatus(status);

        params = paramsSetter();
        testError.setParams(params);
    }

    @Test
    void testGettersSetterError() {

        underTest = new Error();
        underTest.setCode(code);
        underTest.setMessage(message);
        underTest.setTraceId(traceId);
        underTest.setStatus(status);

        params = paramsSetter();
        underTest.setParams(params);

        Assertions.assertSame(underTest.getCode(),testError.getCode());
        Assertions.assertSame(underTest.getMessage(),testError.getMessage());
        Assertions.assertSame(underTest.getTraceId(),testError.getTraceId());
        Assertions.assertSame(underTest.getStatus(),testError.getStatus());
        Assertions.assertSame(underTest.getParams().get(0).toString(),testError.getParams().get(0).toString());
    }

    private List paramsSetter() {
        params = new ArrayList<>();

        String param = "1";
        params.add(param);
        return params;
    }

    @Test
    void testEquals() {

        // Initialize objects
        underTest = new Error();
        underTest.setCode(code);
        underTest.setMessage(message);
        underTest.setTraceId(traceId);
        underTest.setStatus(status);

        params = paramsSetter();
        underTest.setParams(params);

        // Change value of var and test equal
        underTest.code("INTERNAL_SERVER_ERROR!");
        Assertions.assertFalse(testError.equals(underTest));
        underTest.code("INTERNAL_SERVER_ERROR");

        // same
        underTest.setMessage("Internal Server Error occured!");
        Assertions.assertFalse(testError.equals(underTest));
        underTest.setMessage("Internal Server Error occured");

        // Same
        underTest.setStatus("NA!");
        Assertions.assertFalse(testError.equals(underTest));
        underTest.setStatus("NA");

        // Then at the end perform the other tests
        Assertions.assertTrue(testError.equals(testError));
        Assertions.assertTrue(testError.equals(underTest));
        Assertions.assertFalse(testError.equals(null));
        Assertions.assertFalse(testError.equals(42));

        Assertions.assertFalse(underTest.equals(code) &&
                underTest.equals(message) &&
                underTest.equals(traceId) &&
                underTest.equals(status) &&
                underTest.equals(paramsSetter()), String.valueOf(false));
    }

    @Test
    void testHashCode() {
        underTest = new Error();
        underTest.setCode(code);
        underTest.setMessage(message);
        underTest.setTraceId(traceId);
        underTest.setStatus(status);

        params = paramsSetter();
        underTest.setParams(params);

        Assertions.assertNotSame(underTest.hashCode(),testError.hashCode());
    }

    @Test
    void testToAddErrorItem() {
        Assertions.assertSame(underTest.addParamsItem(paramsSetter().get(0).toString()).getParams().get(0),testError.getParams().get(0));
    }

    @Test
    void testAllErrorVariablesParameters() {
        Assertions.assertSame(underTest.code(code).getCode(),testError.getCode());
        Assertions.assertSame(underTest.traceId(traceId).getTraceId(),testError.getTraceId());
        Assertions.assertSame(underTest.message(message).getMessage(),testError.getMessage());
        Assertions.assertSame(underTest.status(status).getStatus(),testError.getStatus());
        Assertions.assertSame(underTest.params(paramsSetter()).getParams().get(0).toString(),testError.getParams().get(0).toString());
    }
}
