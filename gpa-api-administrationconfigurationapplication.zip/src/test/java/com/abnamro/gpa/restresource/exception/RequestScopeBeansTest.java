package com.abnamro.gpa.restresource.exception;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class RequestScopeBeansTest {

    RequestScopeBeans underTest;
    RequestScopeBeans testRequestScopeBeans;

    String traceId = "NA";
    String consumerId = "GPAUSER";
    String tokenType = "NA";
    String token = "ABC_TOKEN";

    @BeforeEach
    public void startUp() {
        underTest = new RequestScopeBeans();

        //set default
        testRequestScopeBeans = new RequestScopeBeans();
        testRequestScopeBeans.setTraceId(traceId);
        testRequestScopeBeans.setConsumerId(consumerId);
        testRequestScopeBeans.setTokenType(tokenType);
        testRequestScopeBeans.setToken(token);
    }

    @Test
    void testGettersSetterRequestScopeBeans() {

        underTest = new RequestScopeBeans();
        underTest.setTraceId(traceId);
        underTest.setConsumerId(consumerId);
        underTest.setTokenType(tokenType);
        underTest.setToken(token);

        Assertions.assertSame(underTest.getTraceId(),testRequestScopeBeans.getTraceId());
        Assertions.assertSame(underTest.getConsumerId(),testRequestScopeBeans.getConsumerId());
        Assertions.assertSame(underTest.getTokenType(),testRequestScopeBeans.getTokenType());
        Assertions.assertSame(underTest.getToken(),testRequestScopeBeans.getToken());
    }

}
