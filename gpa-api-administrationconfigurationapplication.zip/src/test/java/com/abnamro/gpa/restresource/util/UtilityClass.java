package com.abnamro.gpa.restresource.util;

import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermFacetRestResource;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class UtilityClass {

  public AuditDetails setterAuditDetails() {
    String createdBy = "GPAA";
    Date createdTimeStamp = new Date();
    String modifiedBy = "GPAA update";
    Date modifiedTimeStamp = new Date();

    AuditDetails auditDetails = new AuditDetails();
    auditDetails.setCreatedBy(createdBy);
    auditDetails.setCreatedTimeStamp(createdTimeStamp);
    auditDetails.setModifiedBy(modifiedBy);
    auditDetails.setModifiedTimeStamp(modifiedTimeStamp);
    return auditDetails;
  }

  public TermRestResource setterTermRestResource(){
    int id = 1;
    String name = "test";
    TermDataType dataType;
    String description = "testDesc";
    boolean isMandatory = true;
    List<TermFacetRestResource> facets;

    TermRestResource termRestResource = new TermRestResource();
    termRestResource.setId(id);
    termRestResource.setName(name);
    termRestResource.setDataType(TermDataType.STRING);
    termRestResource.setDescription(description);
    termRestResource.setMandatory(isMandatory);

    facets = setterFacetRestResources();

    termRestResource.setFacets(facets);

    termRestResource.setAuditDetails(setterAuditDetails());

    return termRestResource;
  }

  public List<TermFacetRestResource> setterFacetRestResources() {
    List<TermFacetRestResource> facets;
    TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
    termFacetRestResource.setFacetType(FacetTypes.LENGTH);
    termFacetRestResource.setFacetValue("5");
    termFacetRestResource.setAuditDetails(setterAuditDetails());
    facets = new ArrayList<>();
    facets.add(termFacetRestResource);
    return facets;
  }


  public AdministrationRestResource setterAdministrationRestResource() {
    AdministrationRestResource administrationRestResource = new AdministrationRestResource();

    administrationRestResource.setId(1);
    administrationRestResource.setName("testAdmin");
    administrationRestResource.setDescription("testAdminDesc");
    administrationRestResource.setOarId("AAB.AAB.12345");
    administrationRestResource.setAuditDetails(setterAuditDetails());

    List<TermRestResource> terms =new ArrayList<>();
    TermRestResource termRestResource =  setterTermRestResource();
    terms.add(termRestResource);

    administrationRestResource.setTerms(terms);

    // create an arraylist
    ArrayList<Integer> productList = new ArrayList<>();
    productList.add(67);
    productList.add(87);
    productList.add(56);

    // passing arraylist as function parameter
    administrationRestResource.setProducts(Arrays.asList(new Integer[productList.size()]));

    return administrationRestResource;
  }
}
