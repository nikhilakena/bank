package com.abnamro.gpa.restservices.administrationconfiguration.requestprocessor;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationSearchCriteriaView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.dtos.ProductAdminMapView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.dtos.AdministrationConfigurationResultDTO;
import com.abnamro.gpa.restservices.administrationconfiguration.dtos.AdministrationSearchCriteriaDTO;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import com.abnamro.gpa.restservices.administrationconfiguration.helper.GPAAdministrationMapper;
import com.abnamro.gpa.generic.exception.Message;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

public class GPAAAdministrationConfigurationRequestProcessorTest {
    @Test
    public void searchAdministration() {
        GPAAAdministrationConfigurationRequestProcessor processor = new GPAAAdministrationConfigurationRequestProcessor();

        GPAAdministrationMapper mapper = Mockito.mock(GPAAdministrationMapper.class);
        ReflectionTestUtils.setField(processor, "mapper", mapper);

        GPAAdministrationDAO dao = Mockito.mock(GPAAdministrationDAO.class);
        ReflectionTestUtils.setField(processor, "administrationdao", dao);

        AdministrationSearchCriteriaDTO searchCriteriaDto = new AdministrationSearchCriteriaDTO();
        searchCriteriaDto.setAdministrationId(1);
        searchCriteriaDto.setAdministrationName("unit test 1");
        searchCriteriaDto.setOarId("AAB.SYS.1001");

        AdministrationSearchCriteriaView searchCriteriaView = new AdministrationSearchCriteriaView();
        searchCriteriaView.setAdministrationId(1);
        searchCriteriaView.setAdministrationName("unit test 1");
        searchCriteriaView.setOarId("AAB.SYS.1001");

        List<AdministrationView> persistentAdministrations = new ArrayList<>();
        AdministrationView administration1 = new AdministrationView();
        administration1.setId(11);
        administration1.setName("administration 1");
        persistentAdministrations.add(administration1);
        AdministrationView administration2 = new AdministrationView();
        administration2.setId(12);
        administration2.setName("administration 2");
        persistentAdministrations.add(administration2);
        AdministrationView administration3 = new AdministrationView();
        administration3.setId(13);
        administration3.setName("administration 3");
        persistentAdministrations.add(administration3);

        try {
            Mockito.when(mapper.convertToSearchCriteriaView(searchCriteriaDto)).thenReturn(searchCriteriaView);
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }

        try {
            Mockito.when(dao.searchAdministration(searchCriteriaView)).thenReturn(persistentAdministrations);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        List<AdministrationRestResource> administrationResources = new ArrayList<>();
        AdministrationRestResource administrationRestResource1 = new AdministrationRestResource();
        administrationRestResource1.setId(31);
        administrationRestResource1.setName("administration rest resource 31");
        administrationResources.add(administrationRestResource1);
        AdministrationRestResource administrationRestResource2 = new AdministrationRestResource();
        administrationRestResource2.setId(32);
        administrationRestResource2.setName("administration rest resource 32");
        administrationResources.add(administrationRestResource2);

        Mockito.when(mapper.convertToAdministrationRestResourceList(persistentAdministrations)).thenReturn(administrationResources);

        List<AdministrationRestResource> administrations = null;
        try {
            administrations = processor.searchAdministration(searchCriteriaDto);
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }
        Assertions.assertNotNull(administrations);
        Assertions.assertEquals(2, administrations.size());
        Assertions.assertNotNull(administrations.get(0));
        Assertions.assertEquals(31, administrations.get(0).getId());
        Assertions.assertEquals("administration rest resource 31", administrations.get(0).getName());
        Assertions.assertNotNull(administrations.get(1));
        Assertions.assertEquals(32, administrations.get(1).getId());
        Assertions.assertEquals("administration rest resource 32", administrations.get(1).getName());
    }

    @Test
    public void createAdministration() {
        GPAAAdministrationConfigurationRequestProcessor processor = new GPAAAdministrationConfigurationRequestProcessor();

        GPAAdministrationMapper mapper = Mockito.mock(GPAAdministrationMapper.class);
        ReflectionTestUtils.setField(processor, "mapper", mapper);

        GPAAdministrationDAO dao = Mockito.mock(GPAAdministrationDAO.class);
        ReflectionTestUtils.setField(processor, "administrationdao", dao);

        AdministrationRestResource administrationResource = new AdministrationRestResource();
        administrationResource.setId(1);
        administrationResource.setName("administration 1");
        administrationResource.setDescription("description for administration 1");

        AdministrationView administrationView = new AdministrationView();
        administrationView.setName("administration view 11");
        administrationView.setOarId("AAB.SYS.2001");
        try {
            Mockito.when(mapper.convertAdminRestResourceToAdminView(administrationResource)).thenReturn(administrationView);
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }

        try {
            Mockito.when(dao.createAdministration(administrationView)).thenReturn(5);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        AdministrationConfigurationResultDTO result = null;
        try {
            result = processor.createAdministration(administrationResource);
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }
        Assertions.assertNotNull(result);
        Assertions.assertEquals(5, result.getIdentifier());
        Assertions.assertTrue(result.isIndicatorSuccess());
    }

    @Test
    public void readAdministration() {
        GPAAAdministrationConfigurationRequestProcessor processor = new GPAAAdministrationConfigurationRequestProcessor();

        GPAAdministrationMapper mapper = Mockito.mock(GPAAdministrationMapper.class);
        ReflectionTestUtils.setField(processor, "mapper", mapper);

        GPAAdministrationDAO dao = Mockito.mock(GPAAdministrationDAO.class);
        ReflectionTestUtils.setField(processor, "administrationdao", dao);

        AdministrationView administration = new AdministrationView();
        administration.setId(1);
        administration.setName("administration 1");
        administration.setOarId("AAB.SYS.1010");

        try {
            Mockito.when(dao.readAdministration(1, 0)).thenReturn(administration);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        AdministrationRestResource administrationResource = new AdministrationRestResource();
        administrationResource.setId(41);
        administrationResource.setName("resource administration 41");
        Mockito.when(mapper.convertToAdministrationRestResource(administration)).thenReturn(administrationResource);

        AdministrationRestResource result = null;
        try {
            result = processor.readAdministration(1);
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }

        Assertions.assertNotNull(result);
        Assertions.assertEquals(41, result.getId());
        Assertions.assertEquals("resource administration 41", result.getName());
        Assertions.assertNull(result.getOarId());
    }

    @Test
    public void deleteAdministrationWithLinkedProducts() {
        GPAAAdministrationConfigurationRequestProcessor processor = new GPAAAdministrationConfigurationRequestProcessor();

        GPAAdministrationMapper mapper = Mockito.mock(GPAAdministrationMapper.class);
        ReflectionTestUtils.setField(processor, "mapper", mapper);

        GPAAdministrationDAO dao = Mockito.mock(GPAAdministrationDAO.class);
        ReflectionTestUtils.setField(processor, "administrationdao", dao);

        try {
            AdministrationView administrationView = new AdministrationView();
            List<ProductAdminMapView> productAdmins = new ArrayList<>();
            ProductAdminMapView productAdmin1 = new ProductAdminMapView();
            productAdmin1.setProductId(31);
            productAdmins.add(productAdmin1);
            ProductAdminMapView productAdmin2 = new ProductAdminMapView();
            productAdmin2.setProductId(32);
            productAdmins.add(productAdmin2);
            ProductAdminMapView productAdmin3 = new ProductAdminMapView();
            productAdmin3.setProductId(33);
            productAdmins.add(productAdmin3);
            administrationView.setProductAdminMapViews(productAdmins);

            Mockito.when(dao.readAdministration(51, 0)).thenReturn(administrationView);
            Mockito.when(dao.retreiveAgreementCountForProduct(31)).thenReturn(true);
            Mockito.when(dao.retreiveAgreementCountForProduct(32)).thenReturn(true);
            Mockito.when(dao.retreiveAgreementCountForProduct(33)).thenReturn(false);

        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        AdministrationConfigurationResultDTO result = null;
        try {
            result = processor.deleteAdministration(51);
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.assertNotNull(exception);
            Assertions.assertNotNull(exception.getMessages());
            Assertions.assertNotNull(exception.getMessages().getMessages());
            Assertions.assertEquals(1, exception.getMessages().getMessages().size());
            Assertions.assertNotNull(exception.getMessages().getMessages().get(0));
            Message message = exception.getMessages().getMessages().get(0);
            Assertions.assertEquals(GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_DELETE_ADMIN_NOT_ALLOWED, message.getMessageKey());
            Assertions.assertNull(message.getTraceId());
        }
    }

    @Test
    public void deleteAdministrationWithOutLinkedProducts() {
        GPAAAdministrationConfigurationRequestProcessor processor = new GPAAAdministrationConfigurationRequestProcessor();

        GPAAdministrationMapper mapper = Mockito.mock(GPAAdministrationMapper.class);
        ReflectionTestUtils.setField(processor, "mapper", mapper);

        GPAAdministrationDAO dao = Mockito.mock(GPAAdministrationDAO.class);
        ReflectionTestUtils.setField(processor, "administrationdao", dao);

        try {
            AdministrationView administrationView = new AdministrationView();
            List<ProductAdminMapView> productAdmins = new ArrayList<>();
            ProductAdminMapView productAdmin1 = new ProductAdminMapView();
            productAdmin1.setProductId(31);
            productAdmins.add(productAdmin1);
            ProductAdminMapView productAdmin2 = new ProductAdminMapView();
            productAdmin2.setProductId(32);
            productAdmins.add(productAdmin2);
            ProductAdminMapView productAdmin3 = new ProductAdminMapView();
            productAdmin3.setProductId(33);
            productAdmins.add(productAdmin3);
            administrationView.setProductAdminMapViews(productAdmins);

            Mockito.when(dao.readAdministration(51, 0)).thenReturn(administrationView);
            Mockito.when(dao.retreiveAgreementCountForProduct(31)).thenReturn(false);
            Mockito.when(dao.retreiveAgreementCountForProduct(32)).thenReturn(false);
            Mockito.when(dao.retreiveAgreementCountForProduct(33)).thenReturn(false);

            Mockito.when(dao.deleteAdministration(51)).thenReturn(true);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        AdministrationConfigurationResultDTO result = null;
        try {
            result = processor.deleteAdministration(51);
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }

        Assertions.assertNotNull(result);
        Assertions.assertEquals(0, result.getIdentifier());
        Assertions.assertTrue(result.isIndicatorSuccess());
    }
}
