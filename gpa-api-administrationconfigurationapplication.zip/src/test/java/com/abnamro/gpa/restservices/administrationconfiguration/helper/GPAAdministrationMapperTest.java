package com.abnamro.gpa.restservices.administrationconfiguration.helper;

import com.abnamro.gpa.generic.administrationdao.dtos.*;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermFacetRestResource;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import com.abnamro.gpa.restservices.administrationconfiguration.dtos.AdministrationSearchCriteriaDTO;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import com.abnamro.gpa.restservices.administrationconfiguration.restservice.GPAAdministrationConfigurationRestService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
//import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

//@ExtendWith(SpringExtension.class)
//@PrepareForTest(GPAAdministrationConfigurationRestService.class)
//@PowerMockIgnore({ "javax.security.auth.*", "com.sun.jmx.*", "javax.management.*", "javax.xml", "org.xml", "org.w3c.dom", "com.sun.org.apache.xalan.", "javax.activation.*", "jdk.internal.reflect.*" })
public class GPAAdministrationMapperTest {

	
	private final GPAAdministrationMapper mapper = new GPAAdministrationMapper();

	@Test
	public void populateSearchCriteriaDTOTestSuccess() {
		AdministrationSearchCriteriaDTO searchDTO = mapper.populateSearchCriteriaDTO("1", "adminName", "oarId",
				"createdBy", "01-08-2014", "01-08-2018");
		Assertions.assertEquals(1, searchDTO.getAdministrationId());
		Assertions.assertEquals("adminName", searchDTO.getAdministrationName());
		Assertions.assertEquals("oarId", searchDTO.getOarId());
		Assertions.assertEquals("createdBy", searchDTO.getCreatedBy());
		Assertions.assertEquals("01-08-2014", searchDTO.getCreatedTimestampFrom());
		Assertions.assertEquals("01-08-2018", searchDTO.getCreatedTimestampTo());
	}

	@Test
	public void convertToSearchCriteriaViewTestSuccess() throws GPAAdministrationApplicationException {
		AdministrationSearchCriteriaDTO searchCriteriaRestDTO = new AdministrationSearchCriteriaDTO();
		searchCriteriaRestDTO.setAdministrationId(1);
		searchCriteriaRestDTO.setAdministrationName("adminName");
		searchCriteriaRestDTO.setCreatedBy("createdBy");
		searchCriteriaRestDTO.setOarId("oarId");
		searchCriteriaRestDTO.setCreatedTimestampFrom("01-08-2014");
		searchCriteriaRestDTO.setCreatedTimestampTo("01-08-2018");
		AdministrationSearchCriteriaView searchCriteriaViewDTO = mapper
				.convertToSearchCriteriaView(searchCriteriaRestDTO);
		Assertions.assertEquals(1, searchCriteriaViewDTO.getAdministrationId());
		Assertions.assertEquals("adminName", searchCriteriaViewDTO.getAdministrationName());
		Assertions.assertEquals("oarId", searchCriteriaViewDTO.getOarId());
		Assertions.assertEquals("createdBy", searchCriteriaViewDTO.getCreatedBy());
		Assertions.assertEquals("2014-08-01 00:00:00.0", searchCriteriaViewDTO.getCreatedTimestampFrom().toString());
		Assertions.assertEquals("2018-08-01 23:59:59.059", searchCriteriaViewDTO.getCreatedTimestampTo().toString());
	}

	@Test
	public void convertToSearchCriteriaViewTestErrorCreatedFrom() throws GPAAdministrationApplicationException {
		AdministrationSearchCriteriaDTO searchCriteriaRestDTO = new AdministrationSearchCriteriaDTO();
		searchCriteriaRestDTO.setAdministrationId(1);
		searchCriteriaRestDTO.setAdministrationName("adminName");
		searchCriteriaRestDTO.setCreatedBy("createdBy");
		searchCriteriaRestDTO.setOarId("oarId");
		searchCriteriaRestDTO.setCreatedTimestampFrom("ab-08-2014");
		searchCriteriaRestDTO.setCreatedTimestampTo("01-08-2018");
		try {
			mapper.convertToSearchCriteriaView(searchCriteriaRestDTO);
			Assertions.fail("expected exception");
		} catch(GPAAdministrationApplicationException exception) {
		}
	}

	@Test
	public void convertToSearchCriteriaViewTestErrorCreatedTo() throws GPAAdministrationApplicationException {
		AdministrationSearchCriteriaDTO searchCriteriaRestDTO = new AdministrationSearchCriteriaDTO();
		searchCriteriaRestDTO.setAdministrationId(1);
		searchCriteriaRestDTO.setAdministrationName("adminName");
		searchCriteriaRestDTO.setCreatedBy("createdBy");
		searchCriteriaRestDTO.setOarId("oarId");
		searchCriteriaRestDTO.setCreatedTimestampFrom("01-08-2014");
		searchCriteriaRestDTO.setCreatedTimestampTo("ab-08-2018");
		try {
			mapper.convertToSearchCriteriaView(searchCriteriaRestDTO);
			Assertions.fail("expected exception");
		} catch(GPAAdministrationApplicationException exception) {
		}
	}

	@Test
	public void convertToAdministrationRestResourceTestSuccess() {
		AdministrationView administrationView = new AdministrationView();
		administrationView.setId(1);
		administrationView.setName("adminName");
		administrationView.setDescription("description");
		administrationView.setCreatedBy("createdBy");
		administrationView.setModifiedBy("modifiedBy");
		administrationView.setOarId("oarId");
		List<AdministrationView> administrationViewlist = new ArrayList<>();
		administrationViewlist.add(administrationView);

		List<ProductAdminMapView> productAdminMapViews = new ArrayList<ProductAdminMapView>();
		ProductAdminMapView prodadminView = new ProductAdminMapView();
		prodadminView.setProductId(1621);
		prodadminView.setCreatedBy("createdBy");
		prodadminView.setModifiedBy("modifiedBy");
		productAdminMapViews.add(prodadminView);

		List<AdminTermView> adminTermViews = new ArrayList<AdminTermView>();
		AdminTermView adminTermView = new AdminTermView();
		adminTermView.setTermId(101);
		adminTermView.setDataType("STRING");
		adminTermView.setMandatoryIndicator("Y");
		adminTermView.setCreatedBy("createdBy");
		adminTermView.setCreatedTimeStamp(Timestamp.valueOf(("2014-08-01 00:00:00.0")));
		adminTermView.setModifiedBy("modifiedBy");
		adminTermView.setModifiedTimeStamp(Timestamp.valueOf(("2014-08-01 00:00:00.0")));

		List<FacetView> facetViews = new ArrayList<FacetView>();
		FacetView facetView = new FacetView();
		facetView.setType("MAXLENGTH");
		facetView.setValue("10");
		facetView.setCreatedBy("createdBy");
		facetView.setCreatedTimeStamp(Timestamp.valueOf(("2014-08-01 00:00:00.0")));
		facetView.setModifiedBy("modifiedBy");
		facetView.setModifiedTimeStamp(Timestamp.valueOf(("2014-08-01 00:00:00.0")));
		facetViews.add(facetView);

		adminTermView.setFacetView(facetViews);
		adminTermViews.add(adminTermView);

		administrationView.setAdminTermViews(adminTermViews);
		administrationView.setProductAdminMapViews(productAdminMapViews);

		List<AdministrationRestResource> administrationResourceList = mapper
				.convertToAdministrationRestResourceList(administrationViewlist);

		Assertions.assertEquals(1, administrationResourceList.get(0).getId());
		Assertions.assertEquals("adminName", administrationResourceList.get(0).getName());
		Assertions.assertEquals("description", administrationResourceList.get(0).getDescription());
		Assertions.assertEquals("oarId", administrationResourceList.get(0).getOarId());
		Assertions.assertEquals("createdBy", administrationResourceList.get(0).getAuditDetails().getCreatedBy());
		Assertions.assertEquals("modifiedBy", administrationResourceList.get(0).getAuditDetails().getModifiedBy());

		Assertions.assertEquals(1621, administrationResourceList.get(0).getProducts().get(0).intValue());
		Assertions.assertEquals(101, administrationResourceList.get(0).getTerms().get(0).getId());
		Assertions.assertEquals(TermDataType.STRING, administrationResourceList.get(0).getTerms().get(0).getDataType());
		Assertions.assertTrue(administrationResourceList.get(0).getTerms().get(0).isMandatory());
		Assertions.assertEquals(FacetTypes.MAXLENGTH, administrationResourceList.get(0).getTerms().get(0).getFacets().get(0).getFacetType());
		Assertions.assertEquals("10", administrationResourceList.get(0).getTerms().get(0).getFacets().get(0).getFacetValue());
	}

	@Test
	public void populateConsolidatedTermAuditDetailsFacetUpdatedTest() {

		TermRestResource termRestResource = new TermRestResource();
		List<TermFacetRestResource> termFacetRestResources = new ArrayList<TermFacetRestResource>();
		TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
		AuditDetails auditDetails = new AuditDetails();
		auditDetails.setCreatedBy("createdBy1");
		auditDetails.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-15 00:00:00.0")));
		auditDetails.setModifiedBy("modifiedBy1");
		auditDetails.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-15 00:00:00.0")));
		termFacetRestResource.setAuditDetails(auditDetails);
		termFacetRestResources.add(termFacetRestResource);
		termRestResource.setFacets(termFacetRestResources);

		AdminTermView adminTermView = new AdminTermView();
		adminTermView.setCreatedBy("createdBy2");
		adminTermView.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		adminTermView.setModifiedBy("modifiedBy2");
		adminTermView.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));

		mapper.populateConsolidatedTermAuditDetails(termRestResource, adminTermView);

		Assertions.assertEquals(termRestResource.getAuditDetails().getModifiedTimeStamp().toString(),"2019-08-15 00:00:00.0");
		Assertions.assertEquals(termRestResource.getAuditDetails().getModifiedBy(), "createdBy1");
	}

	@Test
	public void populateConsolidatedTermAuditDetailsFacetAddedTest() {

		TermRestResource termRestResource = new TermRestResource();
		List<TermFacetRestResource> termFacetRestResources = new ArrayList<TermFacetRestResource>();
		TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
		AuditDetails auditDetails = new AuditDetails();
		auditDetails.setCreatedBy("createdBy1");
		auditDetails.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-15 00:00:00.0")));
		auditDetails.setModifiedBy("modifiedBy1");
		auditDetails.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-15 00:00:00.0")));
		termFacetRestResource.setAuditDetails(auditDetails);
		termFacetRestResources.add(termFacetRestResource);
		termRestResource.setFacets(termFacetRestResources);

		AdminTermView adminTermView = new AdminTermView();
		adminTermView.setCreatedBy("createdBy2");
		adminTermView.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		adminTermView.setModifiedBy("modifiedBy2");
		adminTermView.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));

		mapper.populateConsolidatedTermAuditDetails(termRestResource, adminTermView);

		Assertions.assertEquals(termRestResource.getAuditDetails().getModifiedTimeStamp().toString(),"2019-08-15 00:00:00.0");
		Assertions.assertEquals(termRestResource.getAuditDetails().getModifiedBy(), "createdBy1");
	}

	@Test
	public void populateConsolidatedTermAuditDetailsTermUpdatedTest() {

		TermRestResource termRestResource = new TermRestResource();
		List<TermFacetRestResource> termFacetRestResources = new ArrayList<TermFacetRestResource>();
		TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
		AuditDetails auditDetails = new AuditDetails();
		auditDetails.setCreatedBy("createdBy1");
		auditDetails.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		auditDetails.setModifiedBy("modifiedBy1");
		auditDetails.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		termFacetRestResource.setAuditDetails(auditDetails);
		termFacetRestResources.add(termFacetRestResource);
		termRestResource.setFacets(termFacetRestResources);

		AdminTermView adminTermView = new AdminTermView();
		adminTermView.setCreatedBy("createdBy2");
		adminTermView.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		adminTermView.setModifiedBy("modifiedBy2");
		adminTermView.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-15 00:00:00.0")));

		mapper.populateConsolidatedTermAuditDetails(termRestResource, adminTermView);

		Assertions.assertEquals(termRestResource.getAuditDetails().getModifiedTimeStamp().toString(),"2019-08-15 00:00:00.0");
		Assertions.assertEquals(termRestResource.getAuditDetails().getModifiedBy(), "modifiedBy2");
	}

	@Test
	public void populateConsolidatedTermAuditDetailsTermCreatedTest() {

		TermRestResource termRestResource = new TermRestResource();
		List<TermFacetRestResource> termFacetRestResources = new ArrayList<TermFacetRestResource>();
		TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
		AuditDetails auditDetails = new AuditDetails();
		auditDetails.setCreatedBy("createdBy1");
		auditDetails.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		auditDetails.setModifiedBy("modifiedBy1");
		auditDetails.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		termFacetRestResource.setAuditDetails(auditDetails);
		termFacetRestResources.add(termFacetRestResource);
		termRestResource.setFacets(termFacetRestResources);

		AdminTermView adminTermView = new AdminTermView();
		adminTermView.setCreatedBy("createdBy2");
		adminTermView.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		adminTermView.setModifiedBy("modifiedBy2");
		adminTermView.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));

		mapper.populateConsolidatedTermAuditDetails(termRestResource, adminTermView);

		Assertions.assertEquals(termRestResource.getAuditDetails().getModifiedTimeStamp().toString(),"2019-08-01 00:00:00.0");
		Assertions.assertEquals(termRestResource.getAuditDetails().getModifiedBy(), "modifiedBy2");
	}

	@Test
	public void populateConsolidatedTermAuditDetailsMultipleFacetUpdatedTest() {

		TermRestResource termRestResource = new TermRestResource();
		List<TermFacetRestResource> termFacetRestResources = new ArrayList<TermFacetRestResource>();
		TermFacetRestResource termFacetRestResource1 = new TermFacetRestResource();
		AuditDetails auditDetails1 = new AuditDetails();
		auditDetails1.setCreatedBy("createdBy1");
		auditDetails1.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		auditDetails1.setModifiedBy("modifiedBy1");
		auditDetails1.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-15 00:00:00.0")));
		termFacetRestResource1.setAuditDetails(auditDetails1);
		termFacetRestResources.add(termFacetRestResource1);
		TermFacetRestResource termFacetRestResource2 = new TermFacetRestResource();
		AuditDetails auditDetails2 = new AuditDetails();
		auditDetails2.setCreatedBy("createdBy2");
		auditDetails2.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		auditDetails2.setModifiedBy("modifiedBy2");
		auditDetails2.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-15 05:00:00.0")));
		termFacetRestResource2.setAuditDetails(auditDetails2);
		termFacetRestResources.add(termFacetRestResource2);
		termRestResource.setFacets(termFacetRestResources);

		AdminTermView adminTermView = new AdminTermView();
		adminTermView.setCreatedBy("createdBy3");
		adminTermView.setCreatedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));
		adminTermView.setModifiedBy("modifiedBy3");
		adminTermView.setModifiedTimeStamp(Timestamp.valueOf(("2019-08-01 00:00:00.0")));

		mapper.populateConsolidatedTermAuditDetails(termRestResource, adminTermView);

		Assertions.assertEquals(termRestResource.getAuditDetails().getModifiedTimeStamp().toString(),"2019-08-15 05:00:00.0");
		Assertions.assertEquals(termRestResource.getAuditDetails().getModifiedBy(), "modifiedBy2");
	}
}