package com.abnamro.gpa.restservices.administrationconfiguration.config;

import com.abnamro.gpa.generic.security.PingFederateValidateUserInfo;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.AuthenticationException;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.oauth2.sdk.ParseException;
import com.nimbusds.oauth2.sdk.util.JSONUtils;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.security.Provider;
import java.util.Map;
import javax.net.ssl.SSLContext;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

class PingClientConfigTest {

  @Mock
  HttpClient httpClient;
  @Mock
  ObjectMapper mapper;
  @Mock
  private Provider provider;
  @Mock
  private SSLContext sslContext;
  @Mock
  HttpResponse<Object> httpResponse;
  @InjectMocks
  PingClientConfig pingClientConfig;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    ReflectionTestUtils.setField(pingClientConfig, "httpClient", httpClient);
    ReflectionTestUtils.setField(pingClientConfig, "mapper", mapper);
    ReflectionTestUtils.setField(pingClientConfig, "pingURL",
        "https://security-ifs-test.connect.abnamro.com:9031");
    ReflectionTestUtils.setField(pingClientConfig, "pingToken", "/as/token.oauth2");
    ReflectionTestUtils.setField(pingClientConfig, "pingIntrospectURL", "/as/introspect.oauth2");
    ReflectionTestUtils.setField(pingClientConfig, "pingIntrospectClientId",
        "OEIO");
    ReflectionTestUtils.setField(pingClientConfig, "pingIntrospectClientSecret",
        "zoPOE2ZzvJu7ixTycafNmrgcy9MN9BNWqrInlrBj1drTblQkjbXrztK4a9hE1tJl");
  }

  @Test
  void testGetAccessToken()
      throws IOException, InterruptedException, AuthenticationException {
    PingFederateValidateUserInfo expectedResult = new PingFederateValidateUserInfo();
    expectedResult.setUserId("test1");
    expectedResult.setDepartmentNumber("test2");
    expectedResult.setRoles("");
    String initialString = "{\"userid\":\"test1\",\"department_number\":\"test2\",\"roles\":\"\"}";

    Mockito.lenient().when(httpClient.send(Mockito.any(), Mockito.any())).thenReturn(httpResponse);
    Mockito.lenient().when(httpResponse.body()).thenReturn(initialString);

    Mockito.lenient().when(httpResponse.statusCode()).thenReturn(200);
    PingFederateValidateUserInfo result = pingClientConfig.getAccessToken("token");
    Assertions.assertEquals(expectedResult, result);

  }

  @Test
  void testCallPingAPIWithValidTokens()
      throws AuthenticationException, IOException, InterruptedException, ParseException, GPAAdministrationApplicationException {
    String initialString = "{\"access_token\":\"test1\",\"id_token\":\"test2\",\"issued_at\":\"\"}";
    InputStream targetStream = new ByteArrayInputStream(initialString.getBytes());
    Mockito.lenient().when(httpClient.sslContext()).thenReturn(sslContext);
    Mockito.lenient().when(httpClient.sslContext().getProvider()).thenReturn(provider);
    Mockito.lenient().when(httpClient.send(Mockito.any(), Mockito.any())).thenReturn(httpResponse);
    Mockito.lenient().when(httpResponse.body()).thenReturn(initialString);

    Mockito.lenient().when(httpResponse.statusCode()).thenReturn(200);
    JSONObject jsonObject = (JSONObject) JSONUtils.parseJSON(initialString);
    Mockito.lenient().when(mapper.readValue(initialString, JSONObject.class)).thenReturn(jsonObject);
    Map<String, String> result1 = pingClientConfig.callPingAPI("code", "authorization_code", "");
    Assertions.assertEquals(Map.of("access_token", "test1", "id_token", "test2"), result1);
    Mockito.lenient().when(httpResponse.statusCode()).thenReturn(401);
    Assertions.assertThrows(AuthenticationException.class,
        () -> pingClientConfig.callPingAPI("code", "authorization_code", ""));
  }


}

