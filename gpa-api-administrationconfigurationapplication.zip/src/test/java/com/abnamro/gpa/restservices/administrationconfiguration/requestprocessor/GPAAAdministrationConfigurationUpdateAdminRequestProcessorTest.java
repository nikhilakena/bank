package com.abnamro.gpa.restservices.administrationconfiguration.requestprocessor;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.dtos.AdministrationConfigurationResultDTO;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import com.abnamro.gpa.restservices.administrationconfiguration.helper.GPAAdministrationMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

public class GPAAAdministrationConfigurationUpdateAdminRequestProcessorTest {
    @Test
    public void updateAdministrationAdministrationUpdate() {
        GPAAAdministrationConfigurationUpdateAdminRequestProcessor processor = new GPAAAdministrationConfigurationUpdateAdminRequestProcessor();
        GPAAdministrationMapper mapper = Mockito.mock(GPAAdministrationMapper.class);
        ReflectionTestUtils.setField(processor,"mapper", mapper);
        GPAAdministrationDAO dao = Mockito.mock(GPAAdministrationDAO.class);
        ReflectionTestUtils.setField(processor, "administrationdao", dao);

        AdministrationRestResource administrationResource = new AdministrationRestResource();
        administrationResource.setId(1);
        administrationResource.setName("unit test administration rest resource 1");

        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(1);
        administrationView.setName("unit test administration view 1");
        administrationView.setDescription("unit test description 1");
        administrationView.setOarId("AAB.SYS.0101");
        administrationView.setProductAdminMapViews(new ArrayList<>());

        try {
            Mockito.when(mapper.convertAdminRestResourceToAdminView(administrationResource)).thenReturn(administrationView);
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }

        AdministrationView persistentAdministrationView = new AdministrationView();
        persistentAdministrationView.setId(1);
        persistentAdministrationView.setName("unit test persistent administration view 1");
        persistentAdministrationView.setDescription("unit test description 1");
        persistentAdministrationView.setOarId("AAB.SYS.0101");
        persistentAdministrationView.setAdminTermViews(new ArrayList<>());
        persistentAdministrationView.setProductAdminMapViews(new ArrayList<>());

        try {
            Mockito.when(dao.readAdministration(administrationResource.getId(), 0)).thenReturn(persistentAdministrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        try {
            Mockito.when(dao.retreiveAgreementCountForAdmin(administrationView)).thenReturn(true);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        try {
            Mockito.when(dao.updateAdministration(administrationView, persistentAdministrationView)).thenReturn(19);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        AdministrationConfigurationResultDTO result = null;
        try {
            result = processor.updateAdministration(administrationResource);
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }

        Assertions.assertNotNull(result);
        Assertions.assertEquals(19, result.getIdentifier());
        Assertions.assertTrue(result.isIndicatorSuccess());
    }

    @Test
    public void updateAdministrationNoUpdate() {
        GPAAAdministrationConfigurationUpdateAdminRequestProcessor processor = new GPAAAdministrationConfigurationUpdateAdminRequestProcessor();
        GPAAdministrationMapper mapper = Mockito.mock(GPAAdministrationMapper.class);
        ReflectionTestUtils.setField(processor,"mapper", mapper);
        GPAAdministrationDAO dao = Mockito.mock(GPAAdministrationDAO.class);
        ReflectionTestUtils.setField(processor, "administrationdao", dao);

        AdministrationRestResource administrationResource = new AdministrationRestResource();
        administrationResource.setId(1);
        administrationResource.setName("unit test administration rest resource 1");

        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(1);
        administrationView.setName("unit test administration view 1");
        administrationView.setDescription("unit test description 1");
        administrationView.setOarId("AAB.SYS.0101");
        administrationView.setProductAdminMapViews(new ArrayList<>());

        try {
            Mockito.when(mapper.convertAdminRestResourceToAdminView(administrationResource)).thenReturn(administrationView);
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }

        AdministrationView persistentAdministrationView = new AdministrationView();
        persistentAdministrationView.setId(1);
        persistentAdministrationView.setName("unit test administration view 1");
        persistentAdministrationView.setDescription("unit test description 1");
        persistentAdministrationView.setOarId("AAB.SYS.0101");
        persistentAdministrationView.setAdminTermViews(new ArrayList<>());
        persistentAdministrationView.setProductAdminMapViews(new ArrayList<>());

        try {
            Mockito.when(dao.readAdministration(administrationResource.getId(), 0)).thenReturn(persistentAdministrationView);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        try {
            Mockito.when(dao.retreiveAgreementCountForAdmin(administrationView)).thenReturn(true);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        try {
            Mockito.when(dao.updateAdministration(administrationView, persistentAdministrationView)).thenReturn(19);
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }

        AdministrationConfigurationResultDTO result = null;
        try {
            result = processor.updateAdministration(administrationResource);
            Assertions.fail("exception expected");
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.assertNotNull(exception);
            Assertions.assertNotNull(exception.getMessages());
            Assertions.assertNotNull(exception.getMessages().getMessages());
            Assertions.assertFalse(exception.getMessages().getMessages().isEmpty());
            Assertions.assertEquals(1, exception.getMessages().getMessages().size());
            Message message = exception.getMessages().getMessages().get(0);
            Assertions.assertNotNull(message);
            Assertions.assertEquals(GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_NO_UPDATE, message.getMessageKey());
        }
    }

    @Test
    public void validateProductUpdatesInAdminWithAgreementWithoutAgreement() {
        GPAAAdministrationConfigurationUpdateAdminRequestProcessor processor = new GPAAAdministrationConfigurationUpdateAdminRequestProcessor();
        try {
            Assertions.assertFalse(processor.validateProductUpdatesInAdminWithAgreement(List.of(11, 12, 13), List.of(25, 26), false));
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void retreiveAgreementCountForProductForNoNewProducts() {
        GPAAAdministrationConfigurationUpdateAdminRequestProcessor processor = new GPAAAdministrationConfigurationUpdateAdminRequestProcessor();
        GPAAdministrationDAO dao = Mockito.mock(GPAAdministrationDAO.class);
        ReflectionTestUtils.setField(processor, "administrationdao", dao);

        try {
            processor.retreiveAgreementCountForProduct(List.of(11, 12, 14), List.of(11, 12, 14));
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void retreiveAgreementCountForProductForNewProductsWithAgreement() {
        GPAAAdministrationConfigurationUpdateAdminRequestProcessor processor = new GPAAAdministrationConfigurationUpdateAdminRequestProcessor();
        GPAAdministrationDAO dao = Mockito.mock(GPAAdministrationDAO.class);
        ReflectionTestUtils.setField(processor, "administrationdao", dao);

        try {
            Mockito.when(dao.retreiveAgreementCountForProduct(13)).thenReturn(true);
            Mockito.when(dao.retreiveAgreementCountForProduct(15)).thenReturn(true);
            processor.retreiveAgreementCountForProduct(List.of(11, 12, 14), List.of(13, 14, 15));
            Assertions.fail("exception expected");
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.assertNotNull(exception);
            Assertions.assertNotNull(exception.getMessages());
            Assertions.assertNotNull(exception.getMessages().getMessages());
            Assertions.assertEquals(1, exception.getMessages().getMessages().size());
            Assertions.assertEquals(GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_PRODUCTS_UPDATE_NOT_ALLOWED, exception.getMessages().getMessages().get(0).getMessageKey());
        }
    }

    @Test
    public void retreiveAgreementCountForProductForNewProductsWithoutAgreement() {
        GPAAAdministrationConfigurationUpdateAdminRequestProcessor processor = new GPAAAdministrationConfigurationUpdateAdminRequestProcessor();
        GPAAdministrationDAO dao = Mockito.mock(GPAAdministrationDAO.class);
        ReflectionTestUtils.setField(processor, "administrationdao", dao);

        try {
            Mockito.when(dao.retreiveAgreementCountForProduct(13)).thenReturn(false);
            Mockito.when(dao.retreiveAgreementCountForProduct(14)).thenReturn(false);
            processor.retreiveAgreementCountForProduct(List.of(11, 12, 14), List.of(13, 14, 15));
        } catch (GPAAdministrationDAOException exception) {
            Assertions.fail("no exception expected");
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void checkAgreementCountForProductWithAgreement() {
        GPAAAdministrationConfigurationUpdateAdminRequestProcessor processor = new GPAAAdministrationConfigurationUpdateAdminRequestProcessor();
        try {
            processor.checkAgreementCountForProduct(true, List.of(11, 12, 14));
            Assertions.fail("exception expected");
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.assertNotNull(exception);
//            Assertions.assertNotNull(exception.getMessages().getMessages());
//            String excpetionMessage = exception.getMessage();
            Messages exceptionMessages = exception.getMessages();
            Assertions.assertEquals(1, exception.getMessages().getMessages().size());
            List<Message> messages = exception.getMessages().getMessages();
            Assertions.assertNotNull(messages);
            Assertions.assertEquals(1, messages.size());
            Message message = messages.get(0);
            Assertions.assertNotNull(message);
            Assertions.assertEquals(GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_PRODUCTS_UPDATE_NOT_ALLOWED, message.getMessageKey());
            Assertions.assertNull(message.getTraceId());
//            Assertions.assertNotNull(message.getParams());
//            Object[] parameterObjects = message.getParams();
//            Assertions.assertEquals(1, parameterObjects.length);
//            List<Integer> parameters = (List<Integer>) parameterObjects[0];
//            Assertions.assertNotNull(parameters);
//            Assertions.assertEquals(3, parameters.size());
//            Assertions.assertTrue(parameters.containsAll(List.of(11, 12, 14)));
        }
    }

    @Test
    public void checkAgreementCountForProductWithoutAgreement() {
        GPAAAdministrationConfigurationUpdateAdminRequestProcessor processor = new GPAAAdministrationConfigurationUpdateAdminRequestProcessor();
        try {
            processor.checkAgreementCountForProduct(false, List.of(11, 12, 14));
        } catch (GPAAdministrationApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void compareProductFromList() {
        GPAAAdministrationConfigurationUpdateAdminRequestProcessor processor = new GPAAAdministrationConfigurationUpdateAdminRequestProcessor();
        List<Integer> newProductIds = List.of(11, 12, 13);

        Assertions.assertFalse(processor.compareProductFromList(newProductIds, List.of(11, 12, 13)));
        Assertions.assertTrue(processor.compareProductFromList(newProductIds, List.of(10, 11, 12, 13, 14)));
        Assertions.assertTrue(processor.compareProductFromList(newProductIds, List.of(10, 11, 12, 14)));
        Assertions.assertFalse(processor.compareProductFromList(newProductIds, List.of(11, 12)));
        Assertions.assertTrue(processor.compareProductFromList(newProductIds, List.of(15)));
    }
}