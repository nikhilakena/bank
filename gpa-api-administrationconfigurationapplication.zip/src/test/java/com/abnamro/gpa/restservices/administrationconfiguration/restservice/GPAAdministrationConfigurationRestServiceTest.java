package com.abnamro.gpa.restservices.administrationconfiguration.restservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

//@WebMvcTest(GPAAdministrationConfigurationRestService.class)
@SpringBootTest(classes = GPAAdministrationConfigurationRestService.class)
@ComponentScan({"com.abnamro.gpa.restservices.administrationconfiguration", "com.abnamro.gpa.generic.administrationdao.dao"})
@AutoConfigureMockMvc
public class GPAAdministrationConfigurationRestServiceTest {
    @Autowired
    private MockMvc mvc;

//    @Test
    public void searchAdministrations() {
        try {
            mvc.perform(MockMvcRequestBuilders
//                    .get("/administrations/retrieve?id=&name=&oarid=&createdBy=&createdFrom=&createdTo=")
                    .get("/administrations/retrieve?id=12")
                    .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(MockMvcResultMatchers.status().isOk());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
