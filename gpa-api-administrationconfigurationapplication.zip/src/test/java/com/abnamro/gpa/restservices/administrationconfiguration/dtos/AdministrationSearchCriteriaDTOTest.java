package com.abnamro.gpa.restservices.administrationconfiguration.dtos;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AdministrationSearchCriteriaDTOTest {
    @Test
    public void createAdministrationCriteriaDTO() {
        AdministrationSearchCriteriaDTO dto = new AdministrationSearchCriteriaDTO();
        Assertions.assertEquals(0, dto.getAdministrationId());
        Assertions.assertNull(dto.getAdministrationName());
        Assertions.assertNull(dto.getOarId());
        Assertions.assertNull(dto.getCreatedBy());
        Assertions.assertNull(dto.getCreatedTimestampFrom());
        Assertions.assertNull(dto.getCreatedTimestampTo());
    }
}
