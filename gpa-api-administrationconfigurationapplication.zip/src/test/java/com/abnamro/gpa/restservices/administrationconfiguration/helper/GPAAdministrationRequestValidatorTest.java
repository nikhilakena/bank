package com.abnamro.gpa.restservices.administrationconfiguration.helper;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.glossary.TermFacetRestResource;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import com.abnamro.gpa.restservices.administrationconfiguration.helper.GPAAdministrationRequestValidator;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
//@PrepareForTest(GPAAdministrationConfigurationRestService.class)
//@PowerMockIgnore({"javax.security.auth.*","com.sun.jmx.*","javax.management.*"})
public class GPAAdministrationRequestValidatorTest {
	
	private GPAAdministrationRequestValidator validator = new GPAAdministrationRequestValidator();
	
//	@Mock
//	private LogHelper logHelper;
	 
	/*@Test
	public void validateSearchAdministrationTestSucess() throws GPAAdministrationApplicationException {
		validator.validateAdministrationSearchCriteria("1", "name", "oarId", "createdBy", "18-08-2017", "18-09-2017");
	}*/
	
	@Test
	public void validateSearchAdministrationTestInvalidId() throws GPAAdministrationApplicationException {
//		Whitebox.setInternalState(GPAAdministrationDAOHelper.class, logHelper);
		try {
			validator.validateAdministrationSearchCriteria("abc", "name", "oarId", "createdBy", "17-08-2017", "18-09-2017");
			Assertions.fail("exception expected");
		} catch (GPAAdministrationApplicationException exception) {
		}
	}
	
	@Test
	public void validateSearchAdministrationTestInvalidFromDate() throws GPAAdministrationApplicationException {
//		Whitebox.setInternalState(GPAAdministrationDAOHelper.class, logHelper);
		try {
			validator.validateAdministrationSearchCriteria("1", "name", "oarId", "createdBy", "ab-08-2017", "18-09-2017");
			Assertions.fail("exception expected");
		} catch (GPAAdministrationApplicationException exception) {
		}
	}
	
	@Test
	public void validateSearchAdministrationTestInvalidToDate() throws GPAAdministrationApplicationException {
//		Whitebox.setInternalState(GPAAdministrationDAOHelper.class, logHelper);
		try {
			validator.validateAdministrationSearchCriteria("1", "name", "oarId", "createdBy", "18-08-2017", "ab-09-2017");
			Assertions.fail("exception expected");
		} catch (GPAAdministrationApplicationException exception) {
		}
	}
	
	@Test
	public void validateSearchAdministrationTestInvalidRange() throws GPAAdministrationApplicationException {
//		Whitebox.setInternalState(GPAAdministrationDAOHelper.class, logHelper);
		try {
			validator.validateAdministrationSearchCriteria("1", "name", "oarId", "createdBy", "18-09-2017", "18-08-2017");
			Assertions.fail("exception expected");
		} catch (GPAAdministrationApplicationException exception) {
		}
	}
	
	@Test
	public void validateSearchAdministrationTestNoInput() throws GPAAdministrationApplicationException {
//		Whitebox.setInternalState(GPAAdministrationDAOHelper.class, logHelper);
		try {
			validator.validateAdministrationSearchCriteria("", "", "", "", "", "");
			Assertions.fail("exception expected");
		} catch (GPAAdministrationApplicationException exception) {
		}
	}
	
	@Test
	public void validateMandatoryFieldsForCreateWithBlankOarId() throws GPAAdministrationApplicationException {
//		Whitebox.setInternalState(GPAAdministrationDAOHelper.class, logHelper);
		AdministrationRestResource restResource = new AdministrationRestResource();
		restResource.setName("Admin1");
		restResource.setOarId("");
		try {
			validator.validateMandatoryFieldsForCreate(restResource);
			Assertions.fail("exception expected");
		} catch (GPAAdministrationApplicationException exception) {
		}
	}
	
	@Test
	public void validateMandatoryFieldsForCreateWithNoInput() throws GPAAdministrationApplicationException {
//		Whitebox.setInternalState(GPAAdministrationDAOHelper.class, logHelper);
		try {
			validator.validateMandatoryFieldsForCreate(null);
			Assertions.fail("exception expected");
		} catch (GPAAdministrationApplicationException exception) {
		}
	}
	
	@Test
	public void validateMandatoryFieldsForCreateWithBlankName() throws GPAAdministrationApplicationException {
//		Whitebox.setInternalState(GPAAdministrationDAOHelper.class, logHelper);
		AdministrationRestResource restResource = new AdministrationRestResource();
		restResource.setName("");
		restResource.setOarId("AAB.SYS.1480");
		try {
			validator.validateMandatoryFieldsForCreate(restResource);
			Assertions.fail("exception expected");
		} catch (GPAAdministrationApplicationException exception) {
		}
	}
	
	@Test
	public void validateMandatoryFieldsForCreateWithBlankFacetValue() throws GPAAdministrationApplicationException {
//		Whitebox.setInternalState(GPAAdministrationDAOHelper.class, logHelper);
		AdministrationRestResource restResource = new AdministrationRestResource();
		restResource.setName("Admin1");
		restResource.setDescription("Admin1 Description");
		restResource.setOarId("AAB.SYS.1480");
		List<Integer> products = new ArrayList<>();
		products.add(1202);
		products.add(1693);
		restResource.setProducts(products);
		List<TermRestResource> termRestResources = new ArrayList<>();
		TermRestResource termRestResource = new TermRestResource();
		termRestResource.setId(1);
		TermFacetRestResource facetRestResource = new TermFacetRestResource();
		facetRestResource.setFacetType(FacetTypes.MAXLENGTH);
		facetRestResource.setFacetValue("");
		List<TermFacetRestResource> facets = new ArrayList<>();
		facets.add(facetRestResource);
		termRestResource.setFacets(facets);
		termRestResources.add(termRestResource);
		restResource.setTerms(termRestResources);
		try {
			validator.validateMandatoryFieldsForCreate(restResource);
			Assertions.fail("exception expected");
		} catch (GPAAdministrationApplicationException exception) {
		}
	}
	
	@Test
	public void validateMandatoryFieldsForCreateWithAllInputs() throws GPAAdministrationApplicationException {
		
		AdministrationRestResource restResource = new AdministrationRestResource();
		restResource.setName("Admin1");
		restResource.setDescription("Admin1 Description");
		restResource.setOarId("AAB.SYS.1480");
		List<Integer> products = new ArrayList<>();
		products.add(1202);
		products.add(1693);
		restResource.setProducts(products);
		List<TermRestResource> termRestResources = new ArrayList<>();
		TermRestResource termRestResource = new TermRestResource();
		termRestResource.setId(1);
		TermFacetRestResource facetRestResource = new TermFacetRestResource();
		facetRestResource.setFacetType(FacetTypes.MAXLENGTH);
		facetRestResource.setFacetValue("10");
		List<TermFacetRestResource> facets = new ArrayList<>();
		facets.add(facetRestResource);
		termRestResource.setFacets(facets);
		termRestResources.add(termRestResource);
		restResource.setTerms(termRestResources);
		validator.validateMandatoryFieldsForCreate(restResource);
	}
	
	@Test
	public void validateAdministrationIdForReadTest() throws GPAAdministrationApplicationException{
		try {
			validator.validateAdministrationIdForRead("abc");
			Assertions.fail("exception expected");
		} catch (GPAAdministrationApplicationException exception) {
		}
	}
}