package com.abnamro.gpa.restservices.administrationconfiguration.exception;

import com.abnamro.gpa.restresource.exception.Errors;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

class AuthenticationExceptionTest {

    @InjectMocks
    AuthenticationException authenticationException;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void TestGetErrorMessageWrapper(){
        authenticationException = new AuthenticationException(new Errors());
        Assertions.assertNotNull(authenticationException.getErrorMessageWrapper());
    }
}
