package com.abnamro.gpa.restservices.administrationconfiguration.dtos;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class AdministrationConfigurationResultDTOTest {
    @Test
    public void defaultConstructor() {
        AdministrationConfigurationResultDTO result = new AdministrationConfigurationResultDTO();
        Assertions.assertEquals(0, result.getIdentifier());
        Assertions.assertFalse(result.isIndicatorSuccess());
    }

    @Test
    public void gettersAndSetters() {
        AdministrationConfigurationResultDTO result = new AdministrationConfigurationResultDTO();
        result.setIdentifier(14);
        result.setIndicatorSuccess(true);
        Assertions.assertEquals(14, result.getIdentifier());
        Assertions.assertTrue(result.isIndicatorSuccess());

        result.setIdentifier(3);
        result.setIndicatorSuccess(false);
        Assertions.assertEquals(3, result.getIdentifier());
        Assertions.assertFalse(result.isIndicatorSuccess());
    }
}
