package com.abnamro.gpa.restservices.administrationconfiguration.exception;

import com.abnamro.gpa.generic.exception.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class GPAAdministrationApplicationExceptionTest {
    @Test
    public void createDefault() {
        GPAAdministrationApplicationException exception = new GPAAdministrationApplicationException();
        Assertions.assertNotNull(exception.getMessages());
        Assertions.assertNotNull(exception.getMessages().getMessages());
        Assertions.assertNull(exception.getMessage());
        Assertions.assertNull(exception.getCause());
    }

    @Test
    public void createWithAABException() {
        BusinessApplicationException businessApplicationException = initializeBAException();
        GPAAdministrationApplicationException exception = new GPAAdministrationApplicationException(businessApplicationException);

        Assertions.assertNotNull(exception.getMessages());
        Assertions.assertNotNull(exception.getMessages().getMessages());
        Assertions.assertEquals(1, exception.getMessages().getMessages().size());
        Message message = exception.getMessages().getMessages().get(0);
        Assertions.assertNotNull(message);
        Assertions.assertEquals("unittestmessagekey", message.getMessageKeyId());
    }

    @Test
    public void createExceptionWithMessages() {
        GPAAdministrationApplicationException exception = new GPAAdministrationApplicationException(initializeMessages());

        Assertions.assertNotNull(exception);
        Assertions.assertNotNull(exception.getMessages());
        Assertions.assertNotNull(exception.getMessages().getMessages());
        Assertions.assertEquals(3, exception.getMessages().getMessages().size());
        Assertions.assertEquals("message_key_1", exception.getMessages().getMessages().get(0).getMessageKeyId());
        Assertions.assertEquals("message_key_3", exception.getMessages().getMessages().get(2).getMessageKeyId());
    }

/*
    private AABException initializeAABException() {
        AABException exception = new AABException() {
            @Override
            public Messages getMessages() {
                Messages messages = new Messages();

                MessageKey messageKey = new MessageKey("unittestmessagekey");
                Message message = new Message(messageKey);

                MessageType messageType = null;
                try {
                    messageType = MessageType.getByCode(1);
                } catch (EnumException e) {
                    Assertions.fail("no exception expected");
                }

                messages.addMessage(message, messageType);

                return messages;
            }
        };

        return exception;
    }
*/

    private BusinessApplicationException initializeBAException() {
        BusinessApplicationException exception = new BusinessApplicationException() {
            @Override
            public Messages getMessages() {
                Messages messages = new Messages();

                MessageKey messageKey = new MessageKey("unittestmessagekey");
                Message message = new Message(messageKey);

                messages.addMessage(message, MessageType.ERROR);

                return messages;
            }
        };

        return exception;
    }

    private Messages initializeMessages() {
        Messages messages = new Messages();

        MessageType messageType = MessageType.ERROR;

        MessageKey messageKey1 = new MessageKey("message_key_1");
        Message message1 = new Message(messageKey1);
        messages.addMessage(message1, messageType);
        MessageKey messageKey2 = new MessageKey("message_key_2");
        Message message2 = new Message(messageKey2);
        messages.addMessage(message2, messageType);
        MessageKey messageKey3 = new MessageKey("message_key_3");
        Message message3 = new Message(messageKey3);
        messages.addMessage(message3, messageType);

        return messages;
    }
}
