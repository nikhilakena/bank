package com.abnamro.gpa.generic.exception;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.springframework.validation.annotation.Validated;

/**
 * Error
 */
@Validated
public class Error {

  @JsonProperty("code")
  private String code = null;

  @JsonProperty("message")
  private String message = null;

  @JsonProperty("traceId")
  private String traceId = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("params")
  @Valid
  private List<String> params = null;

  /**
   * Code error.
   *
   * @param code the code
   * @return the error
   */
  public Error code(String code) {
    this.code = code;
    return this;
  }

  /**
   * Combined fields operationId, backEndId and  message as a key
   *
   * @return code code
   */
  public String getCode() {
    return code;
  }

  /**
   * Sets code.
   *
   * @param code the code
   */
  public void setCode(String code) {
    this.code = code;
  }

  /**
   * Message error.
   *
   * @param message the message
   * @return the error
   */
  public Error message(String message) {
    this.message = message;
    return this;
  }

  /**
   * Value from field message
   *
   * @return message message
   */
  public String getMessage() {
    return message;
  }

  /**
   * Sets message.
   *
   * @param message the message
   */
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   * Trace id error.
   *
   * @param traceId the trace id
   * @return the error
   */
  public Error traceId(String traceId) {
    this.traceId = traceId;
    return this;
  }

  /**
   * Unique end-2-end trace id received from the consumer
   *
   * @return traceId trace id
   */
  public String getTraceId() {
    return traceId;
  }

  /**
   * Sets trace id.
   *
   * @param traceId the trace id
   */
  public void setTraceId(String traceId) {
    this.traceId = traceId;
  }

  /**
   * Status error.
   *
   * @param status the status
   * @return the error
   */
  public Error status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Value from field HTTP-status
   *
   * @return status status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Sets status.
   *
   * @param status the status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Params error.
   *
   * @param params the params
   * @return the error
   */
  public Error params(List<String> params) {
    this.params = params;
    return this;
  }

  /**
   * Add params item error.
   *
   * @param paramsItem the params item
   * @return the error
   */
  public Error addParamsItem(String paramsItem) {
    if (this.params == null) {
      this.params = new ArrayList<String>();
    }
    this.params.add(paramsItem);
    return this;
  }

  /**
   * Handle multiple errors for a single request
   *
   * @return params params
   */
  public List<String> getParams() {
    return params;
  }

  /**
   * Sets params.
   *
   * @param params the params
   */
  public void setParams(List<String> params) {
    this.params = params;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Error error = (Error) o;
    return Objects.equals(this.code, error.code) &&
        Objects.equals(this.message, error.message) &&
        Objects.equals(this.traceId, error.traceId) &&
        Objects.equals(this.status, error.status) &&
        Objects.equals(this.params, error.params);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, message, traceId, status, params);
  }
}