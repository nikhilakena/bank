/**
 *
 */
package com.abnamro.gpa.generic.administrationdao.dtos;


import java.sql.Timestamp;
import java.util.List;
import lombok.Data;

/**
 * This is a view class which holds the details of administration
 *
 */
@Data
public class AdministrationView {

  /**
   * This is default serialVersionID
   */
  private static final long serialVersionUID = 1L;

  private int id;
  private String name;
  private String oarId;
  private String description;
  private String createdBy;
  private Timestamp createdTimeStamp;
  private String modifiedBy;
  private Timestamp modifiedTimeStamp;

  private List<ProductAdminMapView> ProductAdminMapViews;

  private List<AdminTermView> adminTermViews;



}
