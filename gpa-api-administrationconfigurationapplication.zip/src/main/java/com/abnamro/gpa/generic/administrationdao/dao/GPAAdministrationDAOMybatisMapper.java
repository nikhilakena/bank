package com.abnamro.gpa.generic.administrationdao.dao;

import com.abnamro.gpa.generic.administrationdao.dtos.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * This is the mybatis query mapper interface class for GPAAdministrationDAO
 */
@Mapper
public interface GPAAdministrationDAOMybatisMapper {

  /**
   * This is the mapper class for the GPAAdministrationDAO
   *
   * @param searchCriteriaView search criteria DTO
   * @return list of administrations
   */
  public List<AdministrationView> searchAdministration(
      @Param("searchCriteriaView") final AdministrationSearchCriteriaView searchCriteriaView);

  /**
   * This is method is used to create the administration
   *
   * @param administrationView view for Administration
   */
  public void insertAdministration(@Param("administrationView") final AdministrationView administrationView);

  /**
   * This is method is used to get max administration Id
   *
   * @return int Administration ID
   */
  public int getMaxAdministrationId();


  /**
   * This method is used to insert ProductID mapping with Administration id in table  TPS_PROD_ADMIN_MAP
   *
   * @param adminId             an unique identifier(technical) for each Administration
   * @param productAdminMapView product admin mapping details
   */
  public void insertProductAdminMapping(@Param("administrationId") final int adminId,
      @Param("productAdminView") final ProductAdminMapView productAdminMapView);


  /**
   * This method is used to insert facets in TPS_ADM_TRM_FACETS table
   *
   * @param administrationId This is an unique identifier(technical) for each Administration of GPA
   * @param termId           unique identifier(technical) for each term
   * @param facetView        facet details
   */
  public void insertFacets(@Param("administrationId") final int administrationId, @Param("termId") final int termId,
      @Param("facetView") final FacetView facetView);

  /**
   * This method is used to insert Term mapping with Administration id in table TPS_ADM_TRM_FACETS
   *
   * @param adminId       This is an unique identifier(technical) for each Administration of GPA
   * @param adminTermView administration term mapping
   */
  public void insertTermAdminMapping(@Param("administrationId") final int adminId,
      @Param("adminTermView") final AdminTermView adminTermView);


  /**
   * This method is used read administration from 5 tables TPS_ADMINISTRATION TPS_ADMIN_TERMS TPS_GLOSSARY
   * TPS_ADM_TRM_FACETS TPS_PROD_ADMIN_MAP
   *
   * @param administrationId This is an unique identifier(technical) for each Administration of GPA
   * @param productId        This indicates the identification of the Product of the Agreement. From ME
   * @return administration details
   */
  public AdministrationView readAdministration(@Param("administrationId") final int administrationId,
      @Param("productId") final int productId);

  /**
   * This method returns the count of administration for the input termid
   *
   * @param termId unique identifier of the term
   * @return count of no of administration for the input termId
   */
  public int administrationCountForTerms(@Param("termId") final int termId);

  /**
   * This is method is used to update the administration
   *
   * @param administrationView view for Administration
   * @return result of update operation
   */
  public int updateAdministration(@Param("administrationView") final AdministrationView administrationView);


  /**
   * This method is used to update ProductID mapping with Administration id in table  TPS_PROD_ADMIN_MAP
   *
   * @param adminId             an unique identifier(technical) for each Administration
   * @param productAdminMapView product admin mapping details
   */
  public void updateProductAdminMapping(@Param("administrationId") final int adminId,
      @Param("productAdminView") final ProductAdminMapView productAdminMapView);

  /**
   * This method is used to update facets in TPS_ADM_TRM_FACETS table
   *
   * @param administrationId This is an unique identifier(technical) for each Administration of GPA
   * @param termId           unique identifier(technical) for each term
   * @param facetView        facet details
   */
  public void updateFacets(@Param("administrationId") final int administrationId, @Param("termId") final int termId,
      @Param("facetView") final FacetView facetView);

  /**
   * This method is used to update Term mapping with Administration id in table TPS_ADM_TRM_FACETS
   *
   * @param adminId       This is an unique identifier(technical) for each Administration of GPA
   * @param adminTermView administration term mapping
   */
  public void updateTermAdminMapping(@Param("administrationId") final int adminId,
      @Param("adminTermView") final AdminTermView adminTermView);


  /**
   * This method returns the count of agreement for the input administration
   *
   * @param administrationId is an unique identifier
   * @return count of no of administration for the input termId
   */
  public int agreementCountForAdmin(@Param("administrationId") final int administrationId);

  /**
   * This method is used to delete ProductID mapping with Administration id in table  TPS_PROD_ADMIN_MAP
   *
   * @param adminId             an unique identifier(technical) for each Administration
   * @param productAdminMapView product admin mapping details
   */
  public void deleteProductAdminMapping(@Param("administrationId") final int adminId,
      @Param("productAdminView") final ProductAdminMapView productAdminMapView);

  /**
   * This method is used to delete facets in TPS_ADM_TRM_FACETS table
   *
   * @param administrationId is an unique identifier(technical) for each Administration of GPA
   * @param termId           unique identifier(technical) for each term
   */
  public void deleteTermAdminMapping(@Param("administrationId") final int administrationId,
      @Param("termId") final int termId);

  /**
   * This method is used to delete facets from TPS_ADM_TRM_FACETS table
   *
   * @param administrationId is an unique identifier(technical) for each Administration of GPA
   * @param termId           unique identifier(technical) for each term
   * @param facetView        is facet details
   */
  public void deleteFacets(@Param("administrationId") final int administrationId, @Param("termId") final int termId,
      @Param("facetView") final FacetView facetView);

  /**
   * This method returns the count of agreement for the input product
   *
   * @param productId is an unique identifier
   * @return count of no of agreement for the input productId
   */
  public int agreementCountForProduct(@Param("productId") final int productId);

  /**
   * This method is used to delete administration from TPS_ADMINISTRATION table
   *
   * @param administrationId is an unique identifier(technical) for each Administration of GPA
   * @return number of rows affected
   */
  public int deleteAdministration(@Param("administrationId") final int administrationId);

  /**
   * This method is used to get count of admin present with input product id
   *
   * @param productId is input productId
   * @return number of admin present
   */
  public int adminCount(@Param("productId") final int productId);
}
