package com.abnamro.gpa.generic.exception;

import java.io.Serializable;

public final class MessageKey implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = -5520590912146264764L;
  private final String id;

  public String getId() {
    return id;
  }

  /**
   * MessageKey(String aId) : Constructor with id
   *
   * @param aId : Id of the message key
   */
  public MessageKey(String aId) {
    this.id = aId;
  }

  public String toString() {
    return getClass().getName() + "[" + this.id + "]";
  }
}
