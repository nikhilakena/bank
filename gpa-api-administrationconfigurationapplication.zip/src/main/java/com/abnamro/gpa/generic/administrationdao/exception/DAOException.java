package com.abnamro.gpa.generic.administrationdao.exception;

import com.abnamro.gpa.generic.exception.BusinessApplicationException;
import com.abnamro.gpa.generic.exception.Messages;

public class DAOException extends BusinessApplicationException {

  private Messages messages;

  public DAOException() {
    this.messages = new Messages();
  }

  /**
   * Constructor that will also set messages on the exception.
   *
   * @param messages it takes messages of Message type
   */
  public DAOException(Messages messages) {
    this.messages = messages;
  }

  /**
   * Constructor that takes an existing AABException. This will move any messages into the new exception. <br>
   *
   * @param e accepts type of AABException
   */
  public DAOException(DAOException e) {
    if (e != null) {
      this.messages = e.getMessages();
    } else {
      this.messages = new Messages();
    }
  }

  @Override
  public String toString() {
    return getClass().getName() + " : " + this.messages.toString();
  }

  public Messages getMessages() {
    return messages;
  }

  public void setMessages(Messages messages) {
    this.messages = messages;
  }
}
