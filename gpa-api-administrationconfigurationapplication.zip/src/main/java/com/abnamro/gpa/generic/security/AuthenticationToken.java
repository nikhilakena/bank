package com.abnamro.gpa.generic.security;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

/**
 * The type Authentication token.
 */
public class AuthenticationToken extends AbstractAuthenticationToken implements Serializable {

  private static final long serialVersionUID = 1L;

  private final String accessToken;
  private final PingFederateValidateUserInfo userInfo;

  /**
   * Instantiates a new Authentication token.
   *
   * @param accessToken the access token
   */
  public AuthenticationToken(String accessToken) {
    super(null);

    this.accessToken = accessToken;
    this.userInfo = null;
    super.setAuthenticated(false);
  }

  /**
   * Instantiates a new Authentication token.
   *
   * @param accessToken the access token
   * @param userInfo    the user info
   */
  public AuthenticationToken(String accessToken, PingFederateValidateUserInfo userInfo) {
    super(getUserRoles(userInfo.getRoles()));
    this.accessToken = accessToken;
    this.userInfo = userInfo;
    super.setAuthenticated(true);
  }

  @Override
  public Object getCredentials() {
    return getAccessToken();
  }

  @Override
  public Object getPrincipal() {
    return getUserInfo();
  }

  /**
   * Gets access token.
   *
   * @return the access token
   */
  public String getAccessToken() {
    return accessToken;
  }

  /**
   * Gets user info.
   *
   * @return the user info
   */
  public PingFederateValidateUserInfo getUserInfo() {
    return userInfo;
  }

  private static List<SimpleGrantedAuthority> getUserRoles(Object roles) {
    return roles == null || roles.toString() == null ? new ArrayList<>() :
        Arrays.stream(roles.toString().replaceAll("\\[|\\]", "")

                .split(","))
            .map(String::trim)
            .map(SimpleGrantedAuthority::new)
            .collect(Collectors.toList());
  }
}
