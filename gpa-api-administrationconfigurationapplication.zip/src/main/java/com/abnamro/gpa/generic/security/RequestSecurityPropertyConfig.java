package com.abnamro.gpa.generic.security;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * The type Request security property config.
 */
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties("gpa.security")
@Data
public class RequestSecurityPropertyConfig {

  private String[] getrequests;
  private String postrequests;
  private String deleterequests;
  private String putrequests;

  private String[] readRoles;
  private String[] manageRoles;
}
