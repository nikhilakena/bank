package com.abnamro.gpa.generic.security;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.AuthenticatedPrincipal;

/**
 * The type Ping federate validate user info.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class PingFederateValidateUserInfo implements AuthenticatedPrincipal, Serializable {

  private static final long serialVersionUID = 1L;

  @JsonProperty("userid")
  private String userId;

  @JsonProperty("department_number")
  private transient Object departmentNumber;

  @JsonProperty("roles")
  private transient Object roles;

  private boolean active;

  @Override
  public String getName() {
    return userId;
  }
}
