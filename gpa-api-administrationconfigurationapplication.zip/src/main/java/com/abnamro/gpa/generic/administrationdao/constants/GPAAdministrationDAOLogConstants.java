package com.abnamro.gpa.generic.administrationdao.constants;

/**
 * This is the DAO layer log constant file for GPAAdministrationDAO
 */
public class GPAAdministrationDAOLogConstants {

  public static final String LOG_ERROR_IBATIS_INITIALIZATION = "LOG_GPADDA_001";

  public static final String LOG_ERROR_SEARCH_ADMINISTRATION = "LOG_GPADDA_002";

  public static final String LOG_ERROR_DB_CONNECTION = "LOG_GPADDA_003";

  public static final String LOG_INVALID_LENGTH_ERROR_SEARCH_ADMINISTRATION = "LOG_GPADDA_004";

  public static final String LOG_ERROR_DATA_RETRIEVE_MAX_ADMINISTRATION_ID = "LOG_GPADDA_005";

  public static final String DATABASE_EXCEPTION_WHILE_RETRIEVE_MAX_TERM_ID = "LOG_GPADDA_006";

  public static final String LOG_INVALID_LENGTH_ERROR_CREATE_ADMINISTRATION = "LOG_GPADDA_007";

  public static final String LOG_ERROR_DUPLICATE_PRODUCTID_CREATE_ADMINISTRATION = "LOG_GPADDA_008";

  public static final String LOG_ERROR_DATA_READ_ADMINISTRATION = "LOG_GPADDA_009";

  public static final String LOG_INVALID_LENGTH_ERROR_READ_ADMINISTRATION = "LOG_GPADDA_010";

  public static final String LOG_ERROR_DATA_READ_ADMINISTRATION_COUNT_FOR_TERM = "LOG_GPADDA_011";

  public static final String LOG_ERROR_DB_CONNECTION_COUNT_FOR_TERM = "LOG_GPADDA_012";

  public static final String LOG_ERROR_DUPLICATE_PRODUCTID_UPDATE_ADMINISTRATION = "LOG_GPADDA_013";

  public static final String LOG_ERROR_DATA_READ_AGREEMENT_COUNT_FOR_ADMIN = "LOG_GPADDA_014";

  public static final String LOG_ERROR_DB_CONNECTION_COUNT_FOR_AGREEEMENT = "LOG_GPADDA_015";

  public static final String LOG_ERROR_DATA_READ_AGREEMENT_COUNT_FOR_PRODUCT = "LOG_GPADDA_016";

  public static final String LOG_ERROR_DELETE_ADMINISTRATION = "LOG_GPADDA_017";

  public static final String LOG_ERROR_DATA_DELETION = "LOG_GPADDA_018";
}
