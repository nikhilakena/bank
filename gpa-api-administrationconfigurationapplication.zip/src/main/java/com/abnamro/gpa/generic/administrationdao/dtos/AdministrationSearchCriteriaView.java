package com.abnamro.gpa.generic.administrationdao.dtos;

import java.sql.Timestamp;
import lombok.Data;

/**
 * This is a Search Criteria DTO class used as input in administration Search
 */
@Data
public class AdministrationSearchCriteriaView {

  private int administrationId;

  private String administrationName;

  private String oarId;

  private String createdBy;

  private Timestamp createdTimestampFrom;

  private Timestamp createdTimestampTo;



}
