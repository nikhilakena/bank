package com.abnamro.gpa.generic.security;

import java.io.IOException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * The type Pre authentication filter.
 */
@Component
public class PreAuthenticationFilter extends OncePerRequestFilter {

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
      FilterChain filterChain) throws ServletException, IOException {
    String logMethod = "doFilterInternal():";
    String authHeaderValue;
    authHeaderValue = request.getHeader(HttpHeaders.AUTHORIZATION);
    logger.info(logMethod + " -Ping  Authorization Header-" + authHeaderValue);

    if (authHeaderValue != null &&
        (authHeaderValue.startsWith("Bearer"))
    ) {
      authHeaderValue = authHeaderValue.substring(7);
      AuthenticationToken token = new AuthenticationToken(authHeaderValue);
      token.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
      SecurityContextHolder.getContext().setAuthentication(token);
    }
    filterChain.doFilter(request, response);
  }
}
