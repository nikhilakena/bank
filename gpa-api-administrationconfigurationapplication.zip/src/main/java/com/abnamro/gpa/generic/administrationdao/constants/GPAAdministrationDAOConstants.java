package com.abnamro.gpa.generic.administrationdao.constants;

/**
 * This is the DAO layer constant file for GPAAdministrationDAO
 */
public class GPAAdministrationDAOConstants {

  public static final String SCHEMA_DATABASE = "SCHEMA_GPA";
  public static final String DEFAULT_DB_SCHEMA = "UU01";

  public static final String DATASOURCE_NAME = "GPADATASOURCE";
  public static final String DEFAULT_DATASOURCE = "jdbc/GPA_DataSource";

  public static final String TERM_MANDATORY_YES = "Y";
  public static final String TERM_MANDATORY_NO = "N";


}
