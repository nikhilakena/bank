package com.abnamro.gpa.generic.administrationdao.dao;

import com.abnamro.gpa.generic.administrationdao.constants.GPAAdministrationDAOLogConstants;
import com.abnamro.gpa.generic.administrationdao.constants.GPAAdministrationDAOMessageKeys;
import com.abnamro.gpa.generic.administrationdao.dtos.AdminTermView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationSearchCriteriaView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.dtos.FacetView;
import com.abnamro.gpa.generic.administrationdao.dtos.ProductAdminMapView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import java.sql.Timestamp;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * This is the DAO layer helper class for GPAAdministrationDAO
 */
@Slf4j
@Component
public class GPAAdministrationDAOHelper {

  /**
   * This method is used to validate the input AdministrationSearchCriteriaView
   *
   * @param searchCriteriaView search criteria DTO
   * @throws GPAAdministrationDAOException in case of invalid length
   */
  public void validateSearchAdministrationRequest(AdministrationSearchCriteriaView searchCriteriaView)
      throws GPAAdministrationDAOException {

    final String logMethod = "validateSearchAdministrationRequest():: ";

    boolean flag = true;
    if (searchCriteriaView.getAdministrationId() > 999999) {
      flag = false;
    }

    if (StringUtils.isNotEmpty(searchCriteriaView.getAdministrationName())
        && searchCriteriaView.getAdministrationName().length() > 150) {
      flag = false;
    }

    if (StringUtils.isNotEmpty(searchCriteriaView.getOarId()) && searchCriteriaView.getOarId().length() > 50) {
      flag = false;
    }

    if (StringUtils.isNotEmpty(searchCriteriaView.getCreatedBy()) && searchCriteriaView.getCreatedBy().length() > 8) {
      flag = false;
    }

    if (!flag) {
      log.error("{} Exception occurred when invalid length in searching administration={} ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_INVALID_LENGTH_ERROR_SEARCH_ADMINISTRATION);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_SEARCHING_ADMINISTRATION),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }

  }


  /**
   * This method is used to validate the input AdministrationSearchCriteriaView
   *
   * @param administrationView search criteria DTO
   * @throws GPAAdministrationDAOException in case of invalid length
   */
  public void validateCreateAdministrationRequest(AdministrationView administrationView)
      throws GPAAdministrationDAOException {
    final String logMethod = "validateCreateAdministrationRequest():: ";

    boolean flag = true;
    if (administrationView.getId() > 999999) {
      flag = false;
    }
    if (StringUtils.isNotEmpty(administrationView.getName()) && administrationView.getName().length() > 150) {
      flag = false;
    }
    if (StringUtils.isNotEmpty(administrationView.getDescription())
        && administrationView.getDescription().length() > 300) {
      flag = false;
    }
    if (StringUtils.isNotEmpty(administrationView.getOarId()) && administrationView.getOarId().length() > 50) {
      flag = false;
    }
    if (StringUtils.isNotEmpty(administrationView.getCreatedBy()) && administrationView.getCreatedBy().length() > 8) {
      flag = false;
    }

    flag = validateTermAndFacetDetails(administrationView.getAdminTermViews(), flag);

    if (!flag) {
      log.error("{} Exception occurred when invalid length in create administration={} ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_INVALID_LENGTH_ERROR_CREATE_ADMINISTRATION);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_CREATING_ADMINISTRATION),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }

  }


  private boolean validateTermAndFacetDetails(List<AdminTermView> adminTermViews, boolean flag) {
    if (adminTermViews != null) {
      for (AdminTermView adminTermView : adminTermViews) {
        if (adminTermView.getTermId() > 999999) {
          flag = false;
          break;
        }
        flag = validateFacetDetails(flag, adminTermView);
      }
    }
    return flag;
  }


  private boolean validateFacetDetails(boolean flag, AdminTermView adminTermView) {
    if (adminTermView.getFacetView() != null) {
      for (FacetView facetView : adminTermView.getFacetView()) {
        if (StringUtils.isNotEmpty(facetView.getType()) && facetView.getType().length() > 20) {
          flag = false;
        }
        if (StringUtils.isNotEmpty(facetView.getValue()) && facetView.getValue().length() > 3000) {
          flag = false;
        }
      }
    }
    return flag;
  }


  /**
   * This method is to validate read admin input provided
   *
   * @param administrationId is admin id provided in input
   * @param productId        is product Id
   * @throws GPAAdministrationDAOException in case of invalid admin id or invalid product id
   */
  public void validateReadAdministrationInput(int administrationId, int productId)
      throws GPAAdministrationDAOException {
    final String logMethod = "validateReadAdministrationInput():: ";

    if (administrationId > 999999 || productId > 999999) {
      log.error("{} Exception occurred when invalid length in read administration={} ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_INVALID_LENGTH_ERROR_READ_ADMINISTRATION);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAdministrationDAOMessageKeys.INVALID_LENGTH_WHILE_READ_ADMINISTRATION),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }
  }

  /**
   * This method is used for error in delete administation
   *
   * @throws GPAAdministrationDAOException is Exception thrown from database layer
   */
  public void errorInAdminDeletion() throws GPAAdministrationDAOException {
    final String logMethod = "errorInAdminDeletion():: ";
    log.error("{} Exception occurred when admin data deletion={} ", logMethod,
        GPAAdministrationDAOLogConstants.LOG_ERROR_DATA_DELETION);
    Messages messages = new Messages();
    messages.addMessage(
        new Message(
            GPAAdministrationDAOMessageKeys.VALIDATION_EXCEPTION_NO_DATA_FOUND_IN_DELETE_ADMINISTRATION),
        MessageType.getError());
    throw new GPAAdministrationDAOException(messages);

  }

  /**
   * This method is used to throw exception in case product is already present in PROD_ADMIN table
   *
   * @param productList is input list of products with admin
   * @param lastIndex   is input as last index of list item
   * @throws GPAAdministrationDAOException is an exception
   */
  public void productInsertNotAllowed(List<Integer> productList, boolean lastIndex)
      throws GPAAdministrationDAOException {
    final String logMethod = "productInsertNotAllowed():: ";
    Messages messages = new Messages();
    Object[] objects = {productList};

    if (lastIndex) {
      log.error("{} Exception deletion occurred when product insert not allowed={} ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_ERROR_DATA_DELETION);
      messages.addMessage(
          new Message(
              GPAAdministrationDAOMessageKeys.VALIDATION_EXCEPTION_IN_ADMIN_EXISTING_PROD_INSERT_NOT_ALLOWED, objects),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }
  }

  /**
   * This method is used to set audit details
   *
   * @param administrationView is input DTO
   */
  public void setProdAdminAuditDetails(AdministrationView administrationView) {
    Timestamp currentTime = new Timestamp(System.currentTimeMillis());

    for (ProductAdminMapView inputProdAdminView : administrationView.getProductAdminMapViews()) {
      inputProdAdminView.setCreatedBy(administrationView.getModifiedBy());
      inputProdAdminView.setCreatedTimeStamp(currentTime);
    }

  }

  /**
   * This method is used to set audit details
   *
   * @param administrationView is input DTO
   * @param insertFlag         is flag to set created by/time details
   */
  public void setTermAdminAuditDetails(AdministrationView administrationView, boolean insertFlag) {
    Timestamp currentTime = new Timestamp(System.currentTimeMillis());

    if (insertFlag) {
      for (AdminTermView inputAdminTermView : administrationView.getAdminTermViews()) {
        inputAdminTermView.setCreatedBy(administrationView.getModifiedBy());
        inputAdminTermView.setCreatedTimeStamp(currentTime);
      }

    } else {
      for (AdminTermView inputAdminTermView : administrationView.getAdminTermViews()) {
        inputAdminTermView.setModifiedBy(administrationView.getModifiedBy());
      }
    }

  }


}
