package com.abnamro.gpa.generic.administrationdao.dao;

import com.abnamro.gpa.generic.administrationdao.constants.GPAAdministrationDAOLogConstants;
import com.abnamro.gpa.generic.administrationdao.constants.GPAAdministrationDAOMessageKeys;
import com.abnamro.gpa.generic.administrationdao.dtos.AdminTermView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationSearchCriteriaView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.dtos.FacetView;
import com.abnamro.gpa.generic.administrationdao.dtos.ProductAdminMapView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;

/**
 * This is dao layer class for GPA Administration and has operation related to maintenance of Administration.
 *
 */
@Slf4j
@Component
public class GPAAdministrationDAO {

  @Autowired
  private GPAAdministrationDAOHelper daoHelper;

  @Autowired
  private SqlSessionFactory sessionFactory;


  /**
   * This operation is used to retrieve the list of administration based on input search criteria.
   *
   * @param searchCriteriaView search criteria DTO
   * @return list of administrations
   * @throws GPAAdministrationDAOException in case of errors
   */
  public List<AdministrationView> searchAdministration(AdministrationSearchCriteriaView searchCriteriaView)
      throws GPAAdministrationDAOException {
    final String logMethod = "searchAdministration():: ";
    List<AdministrationView> administrationViewList = null;
    try (SqlSession sqlSession = sessionFactory.openSession()) {
      daoHelper.validateSearchAdministrationRequest(searchCriteriaView);
      if (null != searchCriteriaView && StringUtils.isNotEmpty(searchCriteriaView.getAdministrationName())) {
        searchCriteriaView.setAdministrationName(searchCriteriaView.getAdministrationName().toLowerCase());
      }
      if (null != searchCriteriaView && StringUtils.isNotEmpty(searchCriteriaView.getOarId())) {
        searchCriteriaView.setOarId(searchCriteriaView.getOarId().toLowerCase());
      }
      if (null != searchCriteriaView && StringUtils.isNotEmpty(searchCriteriaView.getCreatedBy())) {
        searchCriteriaView.setCreatedBy(searchCriteriaView.getCreatedBy().toLowerCase());
      }
      administrationViewList = sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
          .searchAdministration(searchCriteriaView);
    } catch (PersistenceException exception) {
      log.error("{} Exception occurred in dao searching administration={} | exception={}  ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_ERROR_SEARCH_ADMINISTRATION, exception);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_SEARCHING_ADMINISTRATION_DETAILS),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }
    return administrationViewList;
  }

  /**
   * This operation is used to retrieve the list of administration based on input search criteria.
   *
   * @param administrationView Administration View
   * @return int
   * @throws GPAAdministrationDAOException in case of errors
   */
  public int createAdministration(AdministrationView administrationView) throws GPAAdministrationDAOException {

    final String logMethod = "createAdministration():: ";

    int administrationId = 0;
    try (SqlSession sqlSession = sessionFactory.openSession()) {
      daoHelper.validateCreateAdministrationRequest(administrationView);

      // call for retrieving max termId
      administrationId = getMaxAdministrationId();
      administrationId++;
      administrationView.setId(administrationId);

      sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).insertAdministration(administrationView);
      List<Integer> productListWithAdmin = new ArrayList<>();
      if (administrationView.getProductAdminMapViews() != null
          && !administrationView.getProductAdminMapViews().isEmpty()) {
        Integer counter = 0;
        // Iterate through ProductAdminMapViews
        for (ProductAdminMapView productAdminMapView : administrationView.getProductAdminMapViews()) {
          counter++;
          findProductToInsert(productAdminMapView, sqlSession, counter, productListWithAdmin, administrationId,
              administrationView);

        }

      }
      if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
        insertTermAndFacetDetails(administrationView.getAdminTermViews(), administrationId, sqlSession);
      }
    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      // Duplicate product id check based on SQL error
      if (exception.getCause() instanceof DuplicateKeyException) {
        log.error("{} Exception occurred in dao create administration when duplicate product id={} | exception={} ",
            logMethod,
            GPAAdministrationDAOLogConstants.LOG_ERROR_DUPLICATE_PRODUCTID_CREATE_ADMINISTRATION, exception);
        messages.addMessage(
            new Message(
                GPAAdministrationDAOMessageKeys.DUPLICATE_KEY_EXCEPTION_WHILE_CREATING_ADMINISTRATION_DETAILS),
            MessageType.getError());
      } else {
        log.error("{} Exception occurred when mybatis searching administration details={} | exception={} ", logMethod,
            GPAAdministrationDAOLogConstants.LOG_ERROR_SEARCH_ADMINISTRATION, exception);
        messages.addMessage(
            new Message(
                GPAAdministrationDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_SEARCHING_ADMINISTRATION_DETAILS),
            MessageType.getError());
      }
      throw new GPAAdministrationDAOException(messages);
    }
    return administrationId;
  }


  private void findProductToInsert(ProductAdminMapView productAdminMapView, SqlSession sqlSession, Integer counter,
      List<Integer> productListWithAdmin, int administrationId, AdministrationView administrationView)
      throws GPAAdministrationDAOException {
    int count = sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
        .adminCount(productAdminMapView.getProductId());
    if (count > 0) {
      productListWithAdmin.add(productAdminMapView.getProductId());
    } else {
      // add entry into table TPS_PROD_ADMIN_MAP
      sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
          .insertProductAdminMapping(administrationId, productAdminMapView);
    }
    if (counter == administrationView.getProductAdminMapViews().size() && productListWithAdmin.size() > 0) {
      daoHelper.productInsertNotAllowed(productListWithAdmin, true);
    }

  }

  private void insertTermAndFacetDetails(List<AdminTermView> adminTermViews, int administrationId,
      SqlSession sqlSession) {
    // iterate through admin terms
    for (AdminTermView adminTermView : adminTermViews) {
      // add mapping entry into TPS_ADMIN_TERMS
      sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).insertTermAdminMapping(
          administrationId, adminTermView);

      if (adminTermView.getFacetView() != null && !adminTermView.getFacetView().isEmpty()) {
        // iterate all facets
        for (FacetView facetView : adminTermView.getFacetView()) {
          // add entry into table TPS_ADM_TRM_FACETS
          sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).insertFacets(
              administrationId, adminTermView.getTermId(), facetView);
        }

      }
    }
  }

  /**
   * This is method is used to get max term id
   *
   * @return max administration Id
   * @throws GPAAdministrationDAOException exception thrown at DAO layer
   */
  public int getMaxAdministrationId() throws GPAAdministrationDAOException {
    final String logMethod = "getMaxAdministrationId():: ";
    int administrationId = 0;

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      administrationId = sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
          .getMaxAdministrationId();
    } catch (PersistenceException exception) {
      log.error("{} Exception occurred when data retrieve max administration id={} | exception={} ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_ERROR_DATA_RETRIEVE_MAX_ADMINISTRATION_ID, exception);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAdministrationDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_RETRIEVE_MAX_ADMINISTRATION_ID),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }
    return administrationId;
  }

  /**
   * This method is used read administration for input administration Id
   *
   * @param administrationId unique Identifier of an administrations
   * @param productId        unique Identifier of the product
   * @return administration details
   * @throws GPAAdministrationDAOException in case of errors
   */
  public AdministrationView readAdministration(int administrationId, int productId)
      throws GPAAdministrationDAOException {

    final String logMethod = "readAdministration():: ";
    AdministrationView administrationView = null;

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      daoHelper.validateReadAdministrationInput(administrationId, productId);
      administrationView = sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
          .readAdministration(administrationId, productId);
    } catch (PersistenceException exception) {
      log.error("{} Exception occurred when data read administration id={} | exception={} ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_ERROR_DATA_READ_ADMINISTRATION, exception);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAdministrationDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_READ_ADMINISTRATION),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }
    return administrationView;
  }

  /**
   * This operation is used to check if Administrations are present for term
   *
   * @param termId unique identifier of the term
   * @return true if administration is present else false
   * @throws GPAAdministrationDAOException Exception thrown at DAO layer
   */
  public boolean isAdministrationPresentForTerm(int termId) throws GPAAdministrationDAOException {
    final String logMethod = "isAdministrationPresentForTerm():: ";
    boolean flag = false;

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      int count = sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
          .administrationCountForTerms(termId);
      if (count > 0) {
        flag = true;
      }
    } catch (PersistenceException exception) {
      log.error("{} Exception occurred when data read administration count for term={} | exception={} ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_ERROR_DATA_READ_ADMINISTRATION_COUNT_FOR_TERM, exception);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_READ_ADMINISTRATION_COUNT_FOR_TERM),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }
    return flag;
  }

  /**
   * This operation is used to update administration based on input
   *
   * @param administrationView is input view
   * @param currentAdminView   is current view
   * @return administrationId
   * @throws GPAAdministrationDAOException in case of errors
   */
  public int updateAdministration(AdministrationView administrationView, AdministrationView currentAdminView)
      throws GPAAdministrationDAOException {

    final String logMethod = "updateAdministration():: ";
    int administrationId = administrationView.getId();

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      // validateCreateAdministrationRequest is re -usable. either it
      // should be renamed or seperate copy of same code for update can be
      // written
      daoHelper.validateCreateAdministrationRequest(administrationView);

      sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).updateAdministration(
          administrationView);
      validateProdAdminMap(administrationView, currentAdminView, administrationId, sqlSession);
      validateTermAndFacets(administrationView, currentAdminView, administrationId, sqlSession);

    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      // Duplicate product id check based on SQL error
      if (exception.getCause() instanceof DuplicateKeyException) {
        log.error("{} Exception occurred when duplicate product id update administration={} | exception={} ", logMethod,
            GPAAdministrationDAOLogConstants.LOG_ERROR_DUPLICATE_PRODUCTID_UPDATE_ADMINISTRATION, exception);
        messages.addMessage(
            new Message(
                GPAAdministrationDAOMessageKeys.DUPLICATE_KEY_EXCEPTION_WHILE_UPDATING_ADMINISTRATION_DETAILS),
            MessageType.getError());
      } else {
        log.error("{} Exception occurred when search administration={} | exception={} ", logMethod,
            GPAAdministrationDAOLogConstants.LOG_ERROR_SEARCH_ADMINISTRATION, exception);
        messages.addMessage(
            new Message(
                GPAAdministrationDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_SEARCHING_ADMINISTRATION_DETAILS),
            MessageType.getError());
      }
      throw new GPAAdministrationDAOException(messages);
    }
    return administrationId;
  }

  private void validateTermAndFacets(AdministrationView administrationView, AdministrationView currentAdminView,
      int administrationId, SqlSession sqlSession) {
    if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
      // if terms are provided in input then all existing terms will
      // be updated/ added.
      updateTermAndFacetDetails(administrationView, currentAdminView, administrationId, sqlSession);
    }

    if (administrationView.getAdminTermViews() == null || administrationView.getAdminTermViews().isEmpty()) {
      // if no terms are provided in input then all existing terms
      // will be deleted.
      deleteTermAndFacetDetails(currentAdminView, administrationId, sqlSession);
    }

  }

  private void validateProdAdminMap(AdministrationView administrationView, AdministrationView currentAdminView,
      int administrationId, SqlSession sqlSession) throws GPAAdministrationDAOException {
    if (administrationView.getProductAdminMapViews() != null
        && !administrationView.getProductAdminMapViews().isEmpty()) {

      // set audit details in prodAdmin : table TPS_PROD_ADMIN_MAP
      daoHelper.setProdAdminAuditDetails(administrationView);

      // Iterate through input ProductAdminMapViews & compare with
      // current ProductAdminMapViews to make new entry in
      // TPS_PROD_ADMIN_MAP
      int counter = 0;
      List<Integer> productListWithAdmin = new ArrayList<>();
      for (ProductAdminMapView inputProductAdminMapView : administrationView.getProductAdminMapViews()) {
        counter++;
        boolean lastIndex = false;
        if (counter == administrationView.getProductAdminMapViews().size()) {
          lastIndex = true;
        }
        findProductsForInsert(administrationView, currentAdminView, inputProductAdminMapView, administrationId,
            sqlSession, lastIndex, productListWithAdmin);
      }

      // Iterate through input ProductAdminMapViews & compare with
      // current ProductAdminMapViews to delete entry from
      // TPS_PROD_ADMIN_MAP
      findProductForDeletion(administrationView, currentAdminView, administrationId, sqlSession);
    }
  }

  private void findProductForDeletion(AdministrationView administrationView, AdministrationView currentAdminView,
      int administrationId, SqlSession sqlSession) {

    if (currentAdminView.getProductAdminMapViews() != null
        && !currentAdminView.getProductAdminMapViews().isEmpty()) {
      for (ProductAdminMapView currentProductAdminMapView : currentAdminView.getProductAdminMapViews()) {
        deleteProductsForUpdateAdminFlow(administrationView, currentProductAdminMapView, administrationId,
            sqlSession);

      }
    }

  }

  private void deleteProductsForUpdateAdminFlow(AdministrationView administrationView,
      ProductAdminMapView currentProductAdminMapView, int administrationId, SqlSession sqlSession) {

    boolean matchingProduct = false;
    for (ProductAdminMapView inputProductAdminMapView : administrationView.getProductAdminMapViews()) {
      if (currentProductAdminMapView.getProductId() == inputProductAdminMapView.getProductId()) {
        matchingProduct = true;
      }
    }
    if (!matchingProduct) {
      // delete entry from table TPS_PROD_ADMIN_MAP
      sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).deleteProductAdminMapping(
          administrationId, currentProductAdminMapView);
    }

  }

  private void findProductsForInsert(AdministrationView administrationView, AdministrationView currentAdminView,
      ProductAdminMapView inputProductAdminMapView, int administrationId, SqlSession sqlSession, boolean lastIndex,
      List<Integer> productListWithAdmin) throws GPAAdministrationDAOException {

    boolean matchingProduct = false;
    if (currentAdminView.getProductAdminMapViews() != null
        && !currentAdminView.getProductAdminMapViews().isEmpty()) {
      for (ProductAdminMapView currentProductAdminMapView : currentAdminView.getProductAdminMapViews()) {
        if (inputProductAdminMapView.getProductId() == currentProductAdminMapView.getProductId()) {
          matchingProduct = true;
        }
      }
    }

    if (!matchingProduct) {
      // validate if any administration is present with this product in TPS_PROD_ADMIN_MAP
      boolean flag = isAdminPresentWithProduct(sqlSession, inputProductAdminMapView, lastIndex, productListWithAdmin);
      if (!flag) {
        sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
            .insertProductAdminMapping(administrationId, inputProductAdminMapView);
      }
    }
  }

  private boolean isAdminPresentWithProduct(SqlSession sqlSession, ProductAdminMapView inputProductAdminMapView,
      boolean lastIndex, List<Integer> productListWithAdmin) throws GPAAdministrationDAOException {
    boolean flag = false;
    int count = sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
        .adminCount(inputProductAdminMapView.getProductId());
    if (count > 0) {
      flag = true;
      productListWithAdmin.add(inputProductAdminMapView.getProductId());
    }
    if (lastIndex && productListWithAdmin.size() > 0) {
      daoHelper.productInsertNotAllowed(productListWithAdmin, lastIndex);
    }

    return flag;

  }

  private void deleteTermAndFacetDetails(AdministrationView currentAdminTermViews, int administrationId,
      SqlSession sqlSession) {

    // iterate currentAdminTermViews and find which term to be deleted from
    // table TPS_ADMIN_TERMS
    if (currentAdminTermViews.getAdminTermViews() != null && !currentAdminTermViews.getAdminTermViews().isEmpty()) {
      // Delete All query is not used to re use deleteTermAdminMapping
      // method of MybatisMapper
      for (AdminTermView currentAdminTermView : currentAdminTermViews.getAdminTermViews()) {
        // delete mapping entry from TPS_ADMIN_TERMS
        sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).deleteTermAdminMapping(
            administrationId, currentAdminTermView.getTermId());
      }
    }

  }

  private void updateTermAndFacetDetails(AdministrationView administrationView, AdministrationView currentAdminView,
      int administrationId, SqlSession sqlSession) {

    insertTermForUpdateFlow(administrationView, currentAdminView, administrationId, sqlSession);

    deleteTermForUpdateFlow(administrationView, currentAdminView, administrationId, sqlSession);

    updateTermMandatoryFlag(administrationView, currentAdminView, administrationId, sqlSession);

  }

  private void updateTermMandatoryFlag(AdministrationView administrationView, AdministrationView currentAdminView,
      int administrationId, SqlSession sqlSession) {
    // iterate currentAdminTermViews and find which term to be updated into
    // table TPS_ADMIN_TERMS, mandatory flag is updated
    if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
      for (AdminTermView inputAdminTermView : administrationView.getAdminTermViews()) {
        if (currentAdminView.getAdminTermViews() != null && !currentAdminView.getAdminTermViews().isEmpty()) {
          findTermWithUpdatedMandatoryFlag(currentAdminView, administrationView, administrationId,
              inputAdminTermView, sqlSession);
        }
      }

    }

  }

  private void deleteTermForUpdateFlow(AdministrationView administrationView, AdministrationView currentAdminView,
      int administrationId, SqlSession sqlSession) {
    // iterate currentAdminTermViews and find which term to be deleted from
    // table TPS_ADMIN_TERMS
    if (currentAdminView.getAdminTermViews() != null && !currentAdminView.getAdminTermViews().isEmpty()) {
      for (AdminTermView currentAdminTermView : currentAdminView.getAdminTermViews()) {
        findTermForDeletion(administrationView, currentAdminTermView, administrationId, sqlSession);

      }
    }

  }

  private void insertTermForUpdateFlow(AdministrationView administrationView, AdministrationView currentAdminView,
      int administrationId, SqlSession sqlSession) {
    // iterate currentAdminTermViews and find which term to be inserted into
    // table TPS_ADMIN_TERMS
    if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
      for (AdminTermView inputAdminTermView : administrationView.getAdminTermViews()) {
        findTermForInsert(administrationView, inputAdminTermView, currentAdminView, administrationId,
            sqlSession);
      }
    }
  }

  private void findTermWithUpdatedFacetType(AdminTermView currentAdminTermView, AdministrationView administrationView,
      int administrationId, AdminTermView inputAdminTermView, SqlSession sqlSession) {

    if (inputAdminTermView.getFacetView() != null && !inputAdminTermView.getFacetView().isEmpty()) {
      findAdditionalFacetTypeInInput(currentAdminTermView, inputAdminTermView, administrationView,
          administrationId, sqlSession);
      deleteAdditionalFacetTypeInCurrentData(currentAdminTermView, inputAdminTermView, administrationView,
          administrationId, sqlSession);
      findUpdatedFacetValueInInput(currentAdminTermView, inputAdminTermView, administrationView, administrationId,
          sqlSession);

    }

  }

  private void deleteAdditionalFacetTypeInCurrentData(AdminTermView currentAdminTermView,
      AdminTermView inputAdminTermView, AdministrationView administrationView, int administrationId,
      SqlSession sqlSession) {

    // iterate all facets , if there is additional facet type in term in
    // current DB data then it should be deleted from table
    // TPS_ADM_TRM_FACETS
    for (FacetView currentFacetView : currentAdminTermView.getFacetView()) {
      boolean matchingFlag = false;
      for (FacetView inputFacetView : inputAdminTermView.getFacetView()) {
        if (currentFacetView.getType().trim().equalsIgnoreCase(inputFacetView.getType().trim())) {
          matchingFlag = true;
        }

      }
      if (!matchingFlag) {
        // delete entry from table TPS_ADM_TRM_FACETS
        sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).deleteFacets(
            administrationId, inputAdminTermView.getTermId(), currentFacetView);
      }
    }

  }

  private void findUpdatedFacetValueInInput(AdminTermView currentAdminTermView, AdminTermView inputAdminTermView,
      AdministrationView administrationView, int administrationId, SqlSession sqlSession) {

    // iterate all facets , if there is updated facet value for facet type
    // then
    // it should be updated into table TPS_ADM_TRM_FACETS
    for (FacetView inputFacetView : inputAdminTermView.getFacetView()) {
      for (FacetView currentFacetView : currentAdminTermView.getFacetView()) {
        if (inputFacetView.getType().trim().equalsIgnoreCase(currentFacetView.getType().trim())
            && !inputFacetView.getValue().trim().equalsIgnoreCase(currentFacetView.getValue().trim())) {

          setTermFacetAuditDetails(administrationView, inputAdminTermView, true);
          // update entry into table TPS_ADM_TRM_FACETS
          sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).updateFacets(
              administrationId, inputAdminTermView.getTermId(), inputFacetView);

        }

      }
    }

  }

  private void findAdditionalFacetTypeInInput(AdminTermView currentAdminTermView, AdminTermView inputAdminTermView,
      AdministrationView administrationView, int administrationId, SqlSession sqlSession) {

    // iterate all facets , if there is additional facet type in term then
    // it should be inserted into table TPS_ADM_TRM_FACETS
    for (FacetView inputFacetView : inputAdminTermView.getFacetView()) {
      boolean matchingFlag = false;
      for (FacetView currentFacetView : currentAdminTermView.getFacetView()) {
        if (inputFacetView.getType().trim().equalsIgnoreCase(currentFacetView.getType().trim())) {
          matchingFlag = true;
        }

      }

      if (!matchingFlag) {
        setTermFacetAuditDetails(administrationView, inputAdminTermView, true);
        // insert entry into table TPS_ADM_TRM_FACETS
        sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).insertFacets(
            administrationId, inputAdminTermView.getTermId(), inputFacetView);
      }
    }

  }

  private void findTermWithUpdatedMandatoryFlag(AdministrationView currentAdminView,
      AdministrationView administrationView, int administrationId, AdminTermView inputAdminTermView,
      SqlSession sqlSession) {
    for (AdminTermView currentAdminTermView : currentAdminView.getAdminTermViews()) {
      if (inputAdminTermView.getTermId() == currentAdminTermView.getTermId() && !inputAdminTermView
          .getMandatoryIndicator().equalsIgnoreCase(currentAdminTermView.getMandatoryIndicator())) {
        boolean insertFlag = false;
        daoHelper.setTermAdminAuditDetails(administrationView, insertFlag);
        // update mapping entry into TPS_ADMIN_TERMS
        sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).updateTermAdminMapping(
            administrationId, inputAdminTermView);
        findTermWithUpdatedFacetType(currentAdminTermView, administrationView, administrationId,
            inputAdminTermView, sqlSession);
      }
      if (inputAdminTermView.getTermId() == currentAdminTermView.getTermId() && inputAdminTermView
          .getMandatoryIndicator().equalsIgnoreCase(currentAdminTermView.getMandatoryIndicator())) {
        daoHelper.setTermAdminAuditDetails(administrationView, false);
        findTermWithUpdatedFacetType(currentAdminTermView, administrationView, administrationId,
            inputAdminTermView, sqlSession);
      }
    }

  }

  private void findTermForDeletion(AdministrationView administrationView, AdminTermView currentAdminTermView,
      int administrationId, SqlSession sqlSession) {
    boolean matchingTerm = false;
    if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
      for (AdminTermView inputAdminTermView : administrationView.getAdminTermViews()) {
        if (currentAdminTermView.getTermId() == inputAdminTermView.getTermId()) {
          matchingTerm = true;
        }
      }
    }

    if (!matchingTerm) {
      // delete mapping entry from TPS_ADMIN_TERMS
      sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).deleteTermAdminMapping(
          administrationId, currentAdminTermView.getTermId());
    }

  }

  private void findTermForInsert(AdministrationView administrationView, AdminTermView inputAdminTermView,
      AdministrationView currentAdminView, int administrationId, SqlSession sqlSession) {
    boolean matchingTerm = false;
    for (AdminTermView currentAdminTermView : currentAdminView.getAdminTermViews()) {
      if (inputAdminTermView.getTermId() == currentAdminTermView.getTermId()) {
        matchingTerm = true;
      }
    }
    if (!matchingTerm) {
      boolean insertFlag = true;
      insertTermForUpdateAdminFlow(inputAdminTermView, administrationView, insertFlag, sqlSession,
          administrationId);

    }

  }

  private void insertTermForUpdateAdminFlow(AdminTermView inputAdminTermView, AdministrationView administrationView,
      boolean insertFlag, SqlSession sqlSession, int administrationId) {

    daoHelper.setTermAdminAuditDetails(administrationView, insertFlag);
    sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).insertTermAdminMapping(
        administrationId, inputAdminTermView);
    if (inputAdminTermView.getFacetView() != null && !inputAdminTermView.getFacetView().isEmpty()) {
      setTermFacetAuditDetails(administrationView, inputAdminTermView, insertFlag);
      // iterate all facets
      for (FacetView facetView : inputAdminTermView.getFacetView()) {
        // update entry into table TPS_ADM_TRM_FACETS
        sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class).insertFacets(
            administrationId, inputAdminTermView.getTermId(), facetView);
      }

    }

  }

  private void setTermFacetAuditDetails(AdministrationView administrationView, AdminTermView inputAdminTermView,
      boolean insertFlag) {
    Timestamp currentTime = new Timestamp(System.currentTimeMillis());

    if (insertFlag) {
      for (FacetView facetView : inputAdminTermView.getFacetView()) {
        facetView.setCreatedBy(administrationView.getModifiedBy());
        facetView.setCreatedTimeStamp(currentTime);
      }

    } else {
      for (FacetView facetView : inputAdminTermView.getFacetView()) {
        facetView.setModifiedBy(administrationView.getModifiedBy());
      }
    }

  }


  /**
   * This operation is used to check if Agreements are present for Administration
   *
   * @param administrationView is input AdministrationView
   * @return true if Agreement is present else false
   * @throws GPAAdministrationDAOException Exception thrown at DAO layer
   */

  public boolean retreiveAgreementCountForAdmin(AdministrationView administrationView)
      throws GPAAdministrationDAOException {
    final String logMethod = "retreiveAgreementCountForAdmin():: ";
    boolean flag = false;

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      int count = sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
          .agreementCountForAdmin(administrationView.getId());
      if (count > 0) {
        flag = true;
      }
    } catch (PersistenceException exception) {
      log.error("{} Exception occurred when data read agreement count for administration={} | exception={} ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_ERROR_DATA_READ_AGREEMENT_COUNT_FOR_ADMIN, exception);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAdministrationDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_READ_AGREEMENT_COUNT_FOR_ADMIN),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }
    return flag;
  }

  /**
   * This method is to get count of agreement for product given in input
   *
   * @param productId is input to get agreement
   * @return true if agreement is present else false
   * @throws GPAAdministrationDAOException Exception thrown from database layer
   */
  public boolean retreiveAgreementCountForProduct(int productId) throws GPAAdministrationDAOException {
    final String logMethod = "retreiveAgreementCountForProduct():: ";
    boolean flag = false;

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      int count = sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
          .agreementCountForProduct(productId);
      if (count > 0) {
        flag = true;
      }
    } catch (PersistenceException exception) {
      log.error("{} Exception occurred when data read agreement count for product={} | exception={} ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_ERROR_DATA_READ_AGREEMENT_COUNT_FOR_PRODUCT, exception);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_READ_AGREEMENT_COUNT_FOR_PRODUCT),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }
    return flag;
  }

  /**
   * This method is used to delete administration
   *
   * @param administrationId is a unique identifier(technical) for each Administration of GPA
   * @return boolean returns true if administration deleted, false otherwise
   * @throws GPAAdministrationDAOException Exception thrown from database layer
   */
  public boolean deleteAdministration(int administrationId) throws GPAAdministrationDAOException {

    final String logMethod = "deleteAdministration():: ";

    boolean result = false;
    try (SqlSession sqlSession = sessionFactory.openSession()) {
      int rowsAffected = sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
          .deleteAdministration(administrationId);

      if (rowsAffected == 0) {
        daoHelper.errorInAdminDeletion();
      }
      result = true;
      //connection.commit();
    } catch (PersistenceException exception) {
      log.error("{} Exception occurred in dao delete administration={} | exception={} ", logMethod,
          GPAAdministrationDAOLogConstants.LOG_ERROR_DELETE_ADMINISTRATION, exception);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_DELETING_ADMINISTRATION_DETAILS),
          MessageType.getError());
      throw new GPAAdministrationDAOException(messages);
    }
    return result;
  }
}
