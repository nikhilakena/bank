/**
 *
 */
package com.abnamro.gpa.generic.administrationdao.dtos;


import java.sql.Timestamp;
import lombok.Data;

/**
 * This is a view class which holds the details of Facet
 *
 */
@Data
public class ProductAdminMapView {

  /**
   * This is default serialVersionID
   */
  private static final long serialVersionUID = 1L;

  private int productId;
  private String createdBy;
  private Timestamp createdTimeStamp;
  private String modifiedBy;
  private Timestamp modifiedTimeStamp;



}
