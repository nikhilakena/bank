package com.abnamro.gpa.generic.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import java.util.Date;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * The type Jwt auth helper.
 */
@Slf4j
@Component
public class JwtAuthHelper {

  @Value("${session.sessionExpirationInHrs}")
  private Integer sessionExpirationInHrs;

  @Value("${ping.introspect.client.secret}")
  private String secretKey;

  private final String ISSUER = "GPA";

  /**
   * Create user jwt session string.
   *
   * @param pingIdToken the ping id token
   * @return the string
   */
  public String createUserJwtSession(String pingIdToken) {
    String token = null;
    try {

      Algorithm algorithm = Algorithm.HMAC256(secretKey);
      DecodedJWT decodedPingIdTokenJWT = decodeJWTWithoutVerifying(pingIdToken);

      Map<String, Claim> claimMap = decodedPingIdTokenJWT.getClaims();
      log.info("createUserJwtSession():: userid={} | roles={} | roles list={} ", claimMap.get("userid").asString(),
          claimMap.get("roles").asString(), claimMap.get("roles").asList(String.class));
      JWTCreator.Builder jwtBuilder = JWT.create()
          .withIssuer(ISSUER)
          .withSubject(decodedPingIdTokenJWT.getSubject())
          .withClaim("userid", claimMap.get("userid").asString());

      if (claimMap.get("roles").asList(String.class) != null) {
        jwtBuilder = jwtBuilder.withClaim("roles", claimMap.get("roles").asList(String.class));
      } else {
        jwtBuilder = jwtBuilder.withClaim("roles", claimMap.get("roles").asString());
      }

      long nowMillis = System.currentTimeMillis();
      Date curTimeStamp = new Date(nowMillis);
      Date expiryTimeStamp = new Date(nowMillis + sessionExpirationInHrs * 60 * 60 * 1000);

      jwtBuilder = jwtBuilder.withIssuedAt(curTimeStamp)
          .withNotBefore(curTimeStamp)
          .withExpiresAt(expiryTimeStamp);

      token = jwtBuilder.sign(algorithm);

    } catch (JWTCreationException exception) {
      log.error("Exception occurred in jwt token creation={} ", exception.getMessage());
    }
    log.debug("Final JWT token value={} ", token);
    return token;
  }

  /**
   * Verify user jwt session ping federate validate user info.
   *
   * @param token the token
   * @return the ping federate validate user info
   */
  public PingFederateValidateUserInfo verifyUserJwtSession(String token) {
    PingFederateValidateUserInfo pingFederateUserInfoDTO = new PingFederateValidateUserInfo();
    try {
      log.debug("Verify JWT token value={} ", token.trim());

      Algorithm algorithm = Algorithm.HMAC256(secretKey); //use more secure key
      JWTVerifier verifier = JWT.require(algorithm)
          .withIssuer(ISSUER)
          .build(); //Reusable verifier instance

      DecodedJWT jwt = verifier.verify(token.trim());

      pingFederateUserInfoDTO.setUserId(jwt.getClaim("userid").asString());
      pingFederateUserInfoDTO.setActive(true);

      if (jwt.getClaim("roles").asList(String.class) != null) {
        pingFederateUserInfoDTO.setRoles(jwt.getClaim("roles").asList(String.class));
      } else {
        pingFederateUserInfoDTO.setRoles(jwt.getClaim("roles").asString());
      }

    } catch (JWTVerificationException exception) {
      pingFederateUserInfoDTO.setActive(false);
      log.error("Exception occurred in jwt token verification={} ", exception.getMessage());
    }
    return pingFederateUserInfoDTO;
  }

  /**
   * Decode jwt without verifying decoded jwt.
   *
   * @param token the token
   * @return the decoded jwt
   */
  public DecodedJWT decodeJWTWithoutVerifying(String token) {
    return JWT.decode(token);
  }

}
