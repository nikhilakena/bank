package com.abnamro.gpa.generic.security;

import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

/**
 * The type Ping federate authentication provider.
 */
@Component
public class PingFederateAuthenticationProvider implements AuthenticationProvider {

  private final PingFederateAuthenticationService authenticationService;

  /**
   * Instantiates a new Ping federate authentication provider.
   *
   * @param authenticationService the authentication service
   */
  @Autowired
  PingFederateAuthenticationProvider(PingFederateAuthenticationService authenticationService) {
    this.authenticationService = authenticationService;
  }

  @SneakyThrows
  @Override
  public Authentication authenticate(Authentication authentication) throws AuthenticationException {
    String accessToken = ((AuthenticationToken) authentication).getAccessToken();

    PingFederateValidateUserInfo userInfo = authenticationService.validatePingAccessToken(
        accessToken);

    if (!userInfo.isActive()) {
      throw new BadCredentialsException("User Access Token Expired");
    }

    return new AuthenticationToken(null, userInfo);
  }

  @Override
  public boolean supports(Class<?> authentication) {
    return authentication.equals(AuthenticationToken.class);
  }
}
