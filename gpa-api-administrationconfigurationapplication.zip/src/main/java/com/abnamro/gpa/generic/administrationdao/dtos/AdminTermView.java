/**
 *
 */
package com.abnamro.gpa.generic.administrationdao.dtos;

import java.sql.Timestamp;
import java.util.List;
import lombok.Data;

/**
 * This is a view class which holds the details of Facet
 *
 */
@Data
public class AdminTermView {

  /**
   * This is default serialVersionID
   */
  private static final long serialVersionUID = 1L;

  private int termId;
  private String name;
  private String dataType;
  private String description;

  private String mandatoryIndicator;

  private String createdBy;
  private Timestamp createdTimeStamp;
  private String modifiedBy;
  private Timestamp modifiedTimeStamp;

  private List<FacetView> facetView;



}
