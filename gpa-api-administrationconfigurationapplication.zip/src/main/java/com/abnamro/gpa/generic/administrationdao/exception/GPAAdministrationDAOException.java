/**
 *
 */
package com.abnamro.gpa.generic.administrationdao.exception;


import com.abnamro.gpa.generic.exception.Messages;

/**
 * This is DAO layer exception class for the GPAAdministrationDAO.
 */
public class GPAAdministrationDAOException extends DAOException {

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  private Messages messages;

  /**
   * This is a default constructor
   */
  public GPAAdministrationDAOException() {
    this.messages = new Messages();
  }

  /**
   * This is a parameterized constructor
   * @param e is a AABException
   */
  public GPAAdministrationDAOException(DAOException e) {
    if (e != null) {
      this.messages = e.getMessages();
    } else {
      this.messages = new Messages();
    }
  }

  /**
   * This is a parameterized constructor
   * @param messages is a Messages
   */
  public GPAAdministrationDAOException(Messages messages) {
    this.messages = messages;
  }

  @Override
  public String toString() {
    return getClass().getName() + " : " + this.messages.toString();
  }

  public Messages getMessages() {
    return messages;
  }

  public void setMessages(Messages messages) {
    this.messages = messages;
  }

}
