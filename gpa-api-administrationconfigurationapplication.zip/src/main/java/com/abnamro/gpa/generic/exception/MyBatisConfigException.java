package com.abnamro.gpa.generic.exception;


public class MyBatisConfigException extends Exception {


  /**
   * this is defaultSerialVersion
   */
  private static final long serialVersionUID = 1L;

  private Messages messages;

  /**
   * Default constructor.
   */
  public MyBatisConfigException() {
    this.messages = new Messages();
  }

  /**
   * Constructor that will also set messages on the exception.
   *
   * @param messages it takes messages of Message type
   */
  public MyBatisConfigException(Messages messages) {
    this.messages = messages;
  }

  /**
   * Constructor that takes an existing AABException. This will move any messages into the new exception. <br>
   *
   * @param e accepts type of AABException
   */
  public MyBatisConfigException(GPAAgreementValidatorException e) {
    if (e != null) {
      this.messages = e.getMessages();
    } else {
      this.messages = new Messages();
    }
  }

  @Override
  public String toString() {
    return getClass().getName() + " : " + this.messages.toString();
  }

  public Messages getMessages() {
    return messages;
  }

  public void setMessages(Messages messages) {
    this.messages = messages;
  }


}

