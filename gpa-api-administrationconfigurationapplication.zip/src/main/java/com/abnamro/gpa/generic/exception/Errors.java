package com.abnamro.gpa.generic.exception;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.springframework.validation.annotation.Validated;

/**
 * an array of error messages
 */
@Validated
public class Errors {

  @JsonProperty("errors")
  @Valid
  private List<Error> errors = null;

  /**
   * Errors errors.
   *
   * @param errors the errors
   * @return the errors
   */
  public Errors errors(List<Error> errors) {
    this.errors = errors;
    return this;
  }

  /**
   * Add errors item errors.
   *
   * @param errorsItem the errors item
   * @return the errors
   */
  public Errors addErrorsItem(Error errorsItem) {
    if (this.errors == null) {
      this.errors = new ArrayList<Error>();
    }
    this.errors.add(errorsItem);
    return this;
  }

  /**
   * Get errors
   *
   * @return errors errors
   */
  @Valid
  @Size(min = 1, max = 5)
  public List<Error> getErrors() {
    return errors;
  }

  /**
   * Sets errors.
   *
   * @param errors the errors
   */
  public void setErrors(List<Error> errors) {
    this.errors = errors;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Errors errors = (Errors) o;
    return Objects.equals(this.errors, errors.errors);
  }

  @Override
  public int hashCode() {
    return Objects.hash(errors);
  }
}