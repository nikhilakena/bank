/**
 *
 */
package com.abnamro.gpa.restresource.agreement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * This is Term rest resource
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Term {//extends AbstractDTO

  /**
   * serialization applied
   */

  private static final long serialVersionUID = 1L;

  private String termId;

  private String attributeValue;

  private String attributeName;


  /**
   * @return the attributeValue
   */
  public String getAttributeValue() {
    return attributeValue;
  }

  /**
   * @param attributeValue the attributeValue to set
   */
  public void setAttributeValue(String attributeValue) {
    this.attributeValue = attributeValue;
  }

  /**
   * @return the attributeName
   */
  public String getAttributeName() {
    return attributeName;
  }

  /**
   * @param attributeName the attributeName to set
   */
  public void setAttributeName(String attributeName) {
    this.attributeName = attributeName;
  }

  /**
   * @return the termId
   */
  public String getTermId() {
    return termId;
  }

  /**
   * @param termId the termId to set
   */
  public void setTermId(String termId) {
    this.termId = termId;
  }


}
