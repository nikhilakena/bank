/**
 *
 */
package com.abnamro.gpa.restresource.administration;

import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;

import java.util.List;

/**
 * This is Administration Rest Resource
 *
 */
public class AdministrationRestResource {

  private int id;

  private String name;

  private String description;

  private String oarId;

  private List<TermRestResource> terms;

  private AuditDetails auditDetails;

  private List<Integer> products;

  /**
   * @return the id
   */
  public int getId() {
    return id;
  }

  /**
   * @param id the id to set
   */
  public void setId(int id) {
    this.id = id;
  }

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @param name the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * @param description the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * @return the oarId
   */
  public String getOarId() {
    return oarId;
  }

  /**
   * @param oarId the oarId to set
   */
  public void setOarId(String oarId) {
    this.oarId = oarId;
  }

  /**
   * @return the terms
   */
  public List<TermRestResource> getTerms() {
    return terms;
  }

  /**
   * @param terms the terms to set
   */
  public void setTerms(List<TermRestResource> terms) {
    this.terms = terms;
  }

  /**
   * @return the auditDetails
   */
  public AuditDetails getAuditDetails() {
    return auditDetails;
  }

  /**
   * @param auditDetails the auditDetails to set
   */
  public void setAuditDetails(AuditDetails auditDetails) {
    this.auditDetails = auditDetails;
  }

  /**
   * @return the products
   */
  public List<Integer> getProducts() {
    return products;
  }

  /**
   * @param products the products to set
   */
  public void setProducts(List<Integer> products) {
    this.products = products;
  }


}
