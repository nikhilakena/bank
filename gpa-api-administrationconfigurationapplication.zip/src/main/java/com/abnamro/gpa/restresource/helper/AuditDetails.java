/**
 *
 */
package com.abnamro.gpa.restresource.helper;

import java.util.Date;

/**
 * This is AuditDetails class
 *
 */
public class AuditDetails {

  private String createdBy;

  private Date createdTimeStamp;

  private String modifiedBy;

  private Date modifiedTimeStamp;

  /**
   * @return the createdBy
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * @param createdBy the createdBy to set
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  /**
   * @return the createdTimeStamp
   */
  public Date getCreatedTimeStamp() {
    return createdTimeStamp;
  }

  /**
   * @param createdTimeStamp the createdTimeStamp to set
   */
  public void setCreatedTimeStamp(Date createdTimeStamp) {
    this.createdTimeStamp = createdTimeStamp;
  }

  /**
   * @return the modifiedBy
   */
  public String getModifiedBy() {
    return modifiedBy;
  }

  /**
   * @param modifiedBy the modifiedBy to set
   */
  public void setModifiedBy(String modifiedBy) {
    this.modifiedBy = modifiedBy;
  }

  /**
   * @return the modifiedTimeStamp
   */
  public Date getModifiedTimeStamp() {
    return modifiedTimeStamp;
  }

  /**
   * @param modifiedTimeStamp the modifiedTimeStamp to set
   */
  public void setModifiedTimeStamp(Date modifiedTimeStamp) {
    this.modifiedTimeStamp = modifiedTimeStamp;
  }


}
