/**
 *
 */
package com.abnamro.gpa.restresource.enumeration;

/**
 * This is FacetType rest resource
 *
 */
public enum FacetTypes {
  ENUMERATION,
  LENGTH,
  PATTERN,
  MAXLENGTH,
  MINLENGTH,
  MININCLUSIVE,
  MAXINCLUSIVE,
  MINEXCLUSIVE,
  MAXEXCLUSIVE,
  TOTALDIGITS,
  FRACTIONS
}
