/**
 *
 */
package com.abnamro.gpa.restresource.enumeration;

/**
 * This is AgreementLifeCycleStatusType rest resource
 *
 */
public enum AgreementLifeCycleStatusType {
  ACTIVE,
  INACTIVE,
  DRAFT

}
