/**
 *
 */
package com.abnamro.gpa.restresource.agreement;

import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
//import com.abnamro.nl.dto.util.AbstractDTO;

import java.util.List;

/**
 * This is GeneralProductAgreement rest resource
 *
 */
public class GeneralProductAgreement {//extends AbstractDTO


  /**
   *
   */
  private static final long serialVersionUID = 1L;
  private String productId;
  private String customerId;
  private String agreementStartDate;
  private String agreementEndDate;
  private String createdBy;
  private String dateCreated;
  private String modifiedBy;
  private String dateModified;
  private AgreementLifeCycleStatusType agreementLifeCycleStatusType;
  private String agreementId;
  private List<Term> terms;

  public String getProductId() {
    return productId;
  }

  /**
   * @param productId the productId to set
   */
  public void setProductId(String productId) {
    this.productId = productId;
  }

  /**
   * @return the terms
   */
  public List<Term> getTerms() {
    return terms;
  }

  /**
   * @param terms the terms to set
   */
  public void setTerms(List<Term> terms) {
    this.terms = terms;
  }

  /**
   * @return the customerId
   */
  public String getCustomerId() {
    return customerId;
  }

  /**
   * @param customerId the customerId to set
   */
  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  /**
   * @return the agreementId
   */
  public String getAgreementId() {
    return agreementId;
  }

  /**
   * @param agreementId the agreementId to set
   */
  public void setAgreementId(String agreementId) {
    this.agreementId = agreementId;
  }

  /**
   * @return the agreementStartDate
   */
  public String getAgreementStartDate() {
    return agreementStartDate;
  }

  /**
   * @param agreementStartDate the agreementStartDate to set
   */
  public void setAgreementStartDate(String agreementStartDate) {
    this.agreementStartDate = agreementStartDate;
  }

  /**
   * @return the agreementEndDate
   */
  public String getAgreementEndDate() {
    return agreementEndDate;
  }

  /**
   * @param agreementEndDate the agreementEndDate to set
   */
  public void setAgreementEndDate(String agreementEndDate) {
    this.agreementEndDate = agreementEndDate;
  }

  /**
   * @return the createdBy
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * @param createdBy the createdBy to set
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  /**
   * @return the dateCreated
   */
  public String getDateCreated() {
    return dateCreated;
  }

  /**
   * @param dateCreated the dateCreated to set
   */
  public void setDateCreated(String dateCreated) {
    this.dateCreated = dateCreated;
  }

  /**
   * @return the modifiedBy
   */
  public String getModifiedBy() {
    return modifiedBy;
  }

  /**
   * @param modifiedBy the modifiedBy to set
   */
  public void setModifiedBy(String modifiedBy) {
    this.modifiedBy = modifiedBy;
  }

  /**
   * @return the dateModified
   */
  public String getDateModified() {
    return dateModified;
  }

  /**
   * @param dateModified the dateModified to set
   */
  public void setDateModified(String dateModified) {
    this.dateModified = dateModified;
  }

  /**
   * @return the agreementLifeCycleStatusType
   */
  public AgreementLifeCycleStatusType getAgreementLifeCycleStatusType() {
    return agreementLifeCycleStatusType;
  }

  /**
   * @param agreementLifeCycleStatusType the agreementLifeCycleStatusType to set
   */
  public void setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType agreementLifeCycleStatusType) {
    this.agreementLifeCycleStatusType = agreementLifeCycleStatusType;
  }
  /**
   * @return the productId
   */


}
