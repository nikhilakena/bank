/**
 *
 */
package com.abnamro.gpa.restresource.enumeration;

/**
 * This is TermDataType rest resource
 *
 */
public enum TermDataType {
  STRING,
  NUMERIC,
  BOOLEAN,
  DATE,
  TIME,
  DATETIME
}
