package com.abnamro.gpa.restservices.administrationconfiguration.restservice;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationLogConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.dtos.AdministrationConfigurationResultDTO;
import com.abnamro.gpa.restservices.administrationconfiguration.dtos.AdministrationSearchCriteriaDTO;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import com.abnamro.gpa.restservices.administrationconfiguration.helper.GPAAdministrationMapper;
import com.abnamro.gpa.restservices.administrationconfiguration.helper.GPAAdministrationRequestValidator;
import com.abnamro.gpa.restservices.administrationconfiguration.requestprocessor.GPAAAdministrationConfigurationRequestProcessor;
import com.abnamro.gpa.restservices.administrationconfiguration.requestprocessor.GPAAAdministrationConfigurationUpdateAdminRequestProcessor;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

/**
 * This is an application class for the GPAA Administration Configuration Application. This has operation related to the
 * maintains of the administrations in generic product agreement administration.
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/")
public class GPAAdministrationConfigurationRestService {

  private final GPAAdministrationRequestValidator validator;

  private final GPAAdministrationMapper mapper;

  private GPAAAdministrationConfigurationRequestProcessor requestProcessor;

  private GPAAAdministrationConfigurationUpdateAdminRequestProcessor updateRequestProcessor;

  @Autowired
  public GPAAdministrationConfigurationRestService(final GPAAdministrationRequestValidator validator,
      final GPAAdministrationMapper mapper,
      GPAAAdministrationConfigurationRequestProcessor requestProcessor,
      GPAAAdministrationConfigurationUpdateAdminRequestProcessor updateRequestProcessor) {
    this.validator = validator;
    this.mapper = mapper;
    this.requestProcessor = requestProcessor;
    this.updateRequestProcessor = updateRequestProcessor;
  }

  /**
   * This operation is used to retrieve the list of administration based on input search criteria. It calls validator to
   * perform input validation. After successful validation it calls request processor.
   *
   * @param request            is HttpServletRequest
   * @param administrationId   is String
   * @param administrationName is String
   * @param oarId              is String
   * @param createdBy          is String
   * @param createdDateFrom    is String
   * @param createdDateTo      is String
   * @return List of AdministrationRestResource
   */
  @GetMapping(value = "/administrations/retrieve",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<List<AdministrationRestResource>> searchAdministration(HttpServletRequest request,
      @RequestParam("id") String administrationId, @RequestParam("name") String administrationName,
      @RequestParam("oarid") String oarId,
      @RequestParam("createdBy") String createdBy, @RequestParam("createdFrom") String createdDateFrom,
      @RequestParam("createdTo") String createdDateTo) {

    final String logMethod = "searchAdministration():: ";
    List<AdministrationRestResource> administrationResourceList = null;

    try {
      //validate input request
      validator.validateAdministrationSearchCriteria(administrationId, administrationName, oarId, createdBy,
          createdDateFrom, createdDateTo);

      //populate Search Criteria DTO
      AdministrationSearchCriteriaDTO searchCriteriaDTO = mapper.populateSearchCriteriaDTO(administrationId,
          administrationName, oarId, createdBy, createdDateFrom, createdDateTo);

      //forword request to request processor
      administrationResourceList = requestProcessor.searchAdministration(searchCriteriaDTO);

    } catch (GPAAdministrationApplicationException e) {
      log.error("{} Exception occurred in search administration={} | exception={} ", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_EXCEPTION_IN_SEARCH_ADMINISTRATION, e);
      throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", e);
    }
    return new ResponseEntity<>(administrationResourceList, HttpStatus.OK);
  }

  /**
   * This method is used to create an administration
   *
   * @param request                    is HttpServletRequest
   * @param administrationRestResource is AdministrationRestResource
   * @return glossaryConfigurationResultDTO is GlossaryConfigurationResultDTO
   * @throws GPAAdministrationApplicationException Exception thrown at application layer
   */
  @PostMapping(value = "/administrations/create", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<AdministrationConfigurationResultDTO> createAdministration(HttpServletRequest request,
      @RequestBody AdministrationRestResource administrationRestResource)
      throws GPAAdministrationApplicationException {
    AdministrationConfigurationResultDTO administrationConfigResultDTO = null;
    final String logMethod = "createAdministration():: ";
    String createdBy = GPAAdministrationConfigurationConstants.CREATED_UPDATED_BY;
    try {

      // Mandatory fields related checks
      // Name, description, product id(atleast one) and oar id are mandatory
      // for each facet type facet value is mandatory
      validator.validateMandatoryFieldsForCreate(administrationRestResource);

      AuditDetails auditDtls = new AuditDetails();
      auditDtls.setCreatedBy(createdBy);
      auditDtls.setCreatedTimeStamp(new Date());
      administrationRestResource.setAuditDetails(auditDtls);

      // Forwarding request to request processor
      administrationConfigResultDTO = requestProcessor.createAdministration(administrationRestResource);

    } catch (GPAAdministrationApplicationException e) {
      if (e.getMessages() != null && e.getMessages().getMessages() != null) {
        for (int i = 0; i < e.getMessages().getMessages().size(); i++) {
          Message message = e.getMessages().getMessages().get(i);
          if (GPAAdministrationConfigurationConstants.PRODUCTID_ALREADY_EXIST_WHILE_CREATING_ADMINISTRATION.equalsIgnoreCase(
              message.getMessageKeyId())) {
            log.error("{} Exception occurred whe product already exist in create administration={} | exception={} ",
                logMethod,
                GPAAdministrationConfigurationLogConstants.LOG_PRODUCTID_ALREADY_EXIST_EXCEPTION_IN_CREATE_ADMINISTRATION,
                e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                GPAAdministrationConfigurationConstants.PRODUCTID_ALREADY_EXIST_WHILE_CREATING_ADMINISTRATION, e);
          }
        }
      }
      log.error("{} Exception occurred in create administration={} | exception={} ", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_EXCEPTION_IN_CREATE_ADMINISTRATION, e);
      throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", e);
    }
    return new ResponseEntity<>(administrationConfigResultDTO, HttpStatus.OK);
  }

  /**
   * This method is used read administration for input administration Id
   *
   * @param request          is HttpServletRequest
   * @param administrationId unique Identifier of an administrations
   * @return administration details
   */
  @GetMapping(value = "/administrations/read/{id}", produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<AdministrationRestResource> readAdministration(HttpServletRequest request,
      @PathVariable(name = "id") String administrationId) {

    final String logMethod = "readAdministration():: ";
    AdministrationRestResource administrationRestResource = null;

    try {
      validator.validateAdministrationIdForRead(administrationId);
      administrationRestResource = requestProcessor.readAdministration(Integer.parseInt(administrationId));

    } catch (GPAAdministrationApplicationException e) {
      log.error("{} Exception occurred in read administration={} | exception={}", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_EXCEPTION_IN_READ_ADMINISTRATION, e);
      throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", e);
    }
    return new ResponseEntity<>(administrationRestResource, HttpStatus.OK);
  }

  /**
   * This method is used to update an administration
   *
   * @param request                    is HttpServletRequest
   * @param administrationRestResource is AdministrationRestResource
   * @return Response   is success indicator
   * @throws GPAAdministrationApplicationException is an exception
   */
  @PutMapping(value = "/administrations/update", produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<AdministrationConfigurationResultDTO> updateAdministration(HttpServletRequest request,
      @RequestBody AdministrationRestResource administrationRestResource)
      throws GPAAdministrationApplicationException {
    AdministrationConfigurationResultDTO administrationConfigResultDTO = null;
    final String logMethod = "updateAdministration():: ";
    String modifiedBy = GPAAdministrationConfigurationConstants.CREATED_UPDATED_BY;
    try {
      // Mandatory fields related checks
      // Name, description, product id(atleast one) and oar id are mandatory
      // for each facet type facet value is mandatory
      validator.validateMandatoryFieldsForUpdate(administrationRestResource);
      AuditDetails auditDtls = new AuditDetails();
      auditDtls.setModifiedBy(modifiedBy);
      administrationRestResource.setAuditDetails(auditDtls);

      // Forwarding request to request processor
      administrationConfigResultDTO = updateRequestProcessor.updateAdministration(administrationRestResource);

    } catch (GPAAdministrationApplicationException e) {
      log.error("{} Exception occurred in update administration={} | exception={}", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_EXCEPTION_IN_UPDATE_ADMINISTRATION, e);
      throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", e);
    }
    return new ResponseEntity<>(administrationConfigResultDTO, HttpStatus.OK);
  }

  /**
   * This method is used to delete Administration from GPA
   *
   * @param request is HttpServletRequest
   * @param adminId is input administration ID
   * @return administrationConfigurationResultDTO is AdministrationConfigurationResultDTO
   */
  @DeleteMapping(value = "/administrations/delete/{id:[0-9]{1,6}}",
      produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<AdministrationConfigurationResultDTO> deleteAdministration(HttpServletRequest request,
      @RequestParam(name = "id") int adminId) {

    final String logMethod = "deleteAdministration():response:: ";
    AdministrationConfigurationResultDTO administrationConfigurationResultDTO = null;
    try {
      if (adminId > 0) {
        administrationConfigurationResultDTO = requestProcessor.deleteAdministration(adminId);
      } else {
        log.error("{} invalid admin id while delete admin={} ", logMethod,
            GPAAdministrationConfigurationLogConstants.LOG_INVALID_ADMIN_ID_DELETE_ADMIN);
        Messages messages = new Messages();
        messages.addMessage(
            new Message(
                GPAAdministrationConfigurationMessageKeyConstants.INVALID_INPUT_PARAMETER_ERROR_IN_DELETE_ADMIN),
            MessageType.getError());
        throw new GPAAdministrationApplicationException(messages);
      }

    } catch (GPAAdministrationApplicationException e) {
      log.error("{} Exception occurred in delete admin={} | exception={}", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_EXCEPTION_IN_DELETE_ADMIN, e);
      throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", e);
    }
    return new ResponseEntity<>(administrationConfigurationResultDTO, HttpStatus.OK);
  }
}
