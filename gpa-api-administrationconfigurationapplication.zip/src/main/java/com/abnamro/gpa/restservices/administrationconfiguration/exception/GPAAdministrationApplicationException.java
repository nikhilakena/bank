/**
 *
 */
package com.abnamro.gpa.restservices.administrationconfiguration.exception;

import com.abnamro.gpa.generic.exception.BusinessApplicationException;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.restresource.exception.Errors;
import java.util.List;
import org.springframework.http.HttpStatus;

/**
 * Exception class for GPA Administration
 */
public class GPAAdministrationApplicationException extends BusinessApplicationException {

  /**
   * this is defaultSerialVersion
   */
  private static final long serialVersionUID = 1L;

  private transient Errors errors = null;

  private HttpStatus status;

  private List<String> params;

  /**
   * This is default constructor
   */
  public GPAAdministrationApplicationException() {
    super();
  }

  /**
   * This is a parameterized constructor for BusinessApplicationException
   *
   * @param exception is BusinessApplicationException
   */
  public GPAAdministrationApplicationException(BusinessApplicationException exception) {
    super(exception);
  }


  /**
   * This is a parameterized constructor for messages
   *
   * @param messages is Messages
   */
  public GPAAdministrationApplicationException(Messages messages) {
    super(messages);
  }


  /**
   * Instantiates a new Gpa administration application exception.
   *
   * @param errors the errors
   */
  public GPAAdministrationApplicationException(Errors errors) {
    this.errors = errors;
  }

  /**
   * Gets error message wrapper.
   *
   * @return the error message wrapper
   */
  public Errors getErrorMessageWrapper() {
    return errors;
  }

  /**
   * Gets status.
   *
   * @return the status
   */
  public HttpStatus getStatus() {
    return this.status;
  }

  /**
   * Gets params.
   *
   * @return the params
   */
  public List<String> getParams() {
    return params;
  }

}
