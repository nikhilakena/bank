package com.abnamro.gpa.restservices.administrationconfiguration.dtos;

/**
 * This is a generic DTO to be used at the output of several rest service operations.
 */
public class AdministrationConfigurationResultDTO {

  private int identifier;
  private boolean indicatorSuccess;


  /**
   * @return the identifier
   */
  public int getIdentifier() {
    return identifier;
  }

  /**
   * @param identifier the identifier to set
   */
  public void setIdentifier(int identifier) {
    this.identifier = identifier;
  }

  /**
   * @return the indicatorSuccess
   */
  public boolean isIndicatorSuccess() {
    return indicatorSuccess;
  }

  /**
   * @param indicatorSuccess the indicatorSuccess to set
   */
  public void setIndicatorSuccess(boolean indicatorSuccess) {
    this.indicatorSuccess = indicatorSuccess;
  }


}
