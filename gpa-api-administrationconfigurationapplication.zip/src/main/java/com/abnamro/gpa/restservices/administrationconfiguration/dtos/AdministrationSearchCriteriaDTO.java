package com.abnamro.gpa.restservices.administrationconfiguration.dtos;

/**
 * This is search criteria DTO for the search administration operation.
 *
 */
public class AdministrationSearchCriteriaDTO {

  private int administrationId;

  private String administrationName;

  private String oarId;

  private String createdBy;

  private String createdTimestampFrom;

  private String createdTimestampTo;

  /**
   * @return administration Id
   */
  public int getAdministrationId() {
    return administrationId;
  }

  /**
   * @param administrationId int administration Id
   */
  public void setAdministrationId(int administrationId) {
    this.administrationId = administrationId;
  }

  /**
   * @return administration Name
   */
  public String getAdministrationName() {
    return administrationName;
  }

  /**
   * @param administrationName String administration Name
   */
  public void setAdministrationName(String administrationName) {
    this.administrationName = administrationName;
  }

  /**
   * @return oar id
   */
  public String getOarId() {
    return oarId;
  }

  /**
   * @param oarId string value of oar Id
   */
  public void setOarId(String oarId) {
    this.oarId = oarId;
  }

  /**
   * @return the createdBy
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * @param createdBy the createdBy to set
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  /**
   * @return the createdTimestampFrom
   */
  public String getCreatedTimestampFrom() {
    return createdTimestampFrom;
  }

  /**
   * @param createdTimestampFrom the createdTimestampFrom to set
   */
  public void setCreatedTimestampFrom(String createdTimestampFrom) {
    this.createdTimestampFrom = createdTimestampFrom;
  }

  /**
   * @return the createdTimestampTo
   */
  public String getCreatedTimestampTo() {
    return createdTimestampTo;
  }

  /**
   * @param createdTimestampTo the createdTimestampTo to set
   */
  public void setCreatedTimestampTo(String createdTimestampTo) {
    this.createdTimestampTo = createdTimestampTo;
  }


}
