package com.abnamro.gpa.restservices.administrationconfiguration.config;

import com.abnamro.gpa.restresource.exception.Errors;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.ErrorKeys;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import com.abnamro.gpa.restservices.administrationconfiguration.util.ErrorAndLogUtils;
import com.azure.identity.ManagedIdentityCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import jakarta.xml.bind.DatatypeConverter;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.http.HttpClient;
import java.security.GeneralSecurityException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * The type Http client config.
 */
@Configuration
@Slf4j
public class HttpClientConfig {

  @Value("${gpa.keystore.password}")
  private String keyStorePassword;

  @Value("${gpa.keyvault.certificate}")
  private String pingCertificateName;

  @Value("${gpa.keyStore.type}")
  private String keyStoreType;

  @Value("${gpa.keyvault.url}")
  private String keyVaultUri;

  private static final char[] EMPTY_PASSWORD = new char[0];

  /**
   * get HttpClient
   *
   * @return HttpClient HttpClient
   * @throws NoSuchAlgorithmException exception
   * @throws KeyManagementException   key mgmt exception
   */
  @Profile("local")
  @Bean(name = "pingHttpClient")
  public HttpClient getHttpClientLocal() throws NoSuchAlgorithmException, KeyManagementException {

    TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
      public X509Certificate[] getAcceptedIssuers() {
        return null;
      }

      @Override
      public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
        // Not implemented
      }

      @Override
      public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
        // Not implemented
      }
    }};

    SSLContext sc = SSLContext.getInstance("TLS");
    sc.init(null, trustAllCerts, new java.security.SecureRandom());
    return HttpClient.newBuilder()
        .sslContext(sc)
        .version(HttpClient.Version.HTTP_2)
        .build();
  }

  /**
   * This method creates httpclient
   *
   * @return HttpClient HttpClient
   * @throws GeneralSecurityException         exception
   * @throws IOException                      the io exception
   * @throws GPAAdministrationApplicationException the gpaa administration application exception
   */
  @Profile("!local")
  @Bean(name = "pingHttpClient")
  public HttpClient getHttpClient() throws GeneralSecurityException, IOException, GPAAdministrationApplicationException {

    try {
      KeyStore keyStore = KeyStore.getInstance(keyStoreType);
      keyStore.load(null, EMPTY_PASSWORD);
      SSLContext sslContext = SSLContext.getInstance("TLSv1.2");

      sslContext.init(getKeyManagers(keyStore, keyStorePassword), getTrustManager(keyStore), null);

      log.info("SSLContext initiated with certificate: {} and provider {}", pingCertificateName,
          sslContext.getProvider());

      return HttpClient.newBuilder().sslContext(sslContext).version(HttpClient.Version.HTTP_2).build();
    } catch (KeyStoreException e) {
      log.error("keystore exception occurred while creating HttpClient ", e);
      Errors errors = new Errors();
      ErrorAndLogUtils.setError(errors, ErrorKeys.KEYVAULT_EXCEPTION.getCode(),
          ErrorKeys.KEYVAULT_EXCEPTION.getMessage());
      throw new GPAAdministrationApplicationException(errors);
    }
  }

  private TrustManager[] getTrustManager(KeyStore keystore)
      throws NoSuchAlgorithmException, KeyStoreException, GPAAdministrationApplicationException {
    KeyStore trustStore = addTrustCertificate(keystore);
    TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance("PKIX");
    trustManagerFactory.init(trustStore);
    log.info("Initiated TrustManagerFactory ");
    return trustManagerFactory.getTrustManagers();
  }

  private KeyManager[] getKeyManagers(KeyStore keyStore, final String password)
      throws NoSuchAlgorithmException, UnrecoverableKeyException, KeyStoreException {

    KeyManagerFactory keyManagerFactory =
        KeyManagerFactory.getInstance("PKIX"); // earlier value SunX509
    keyManagerFactory.init(keyStore, password.toCharArray());
    log.info("Initiated KeyManagerFactory ");
    return keyManagerFactory.getKeyManagers();
  }

  /**
   * Add trust certificate key store.
   *
   * @param ks the ks
   * @return ks KeyStore
   * @throws GPAAdministrationApplicationException the gpaa administration application exception
   */
  public KeyStore addTrustCertificate(KeyStore ks) throws GPAAdministrationApplicationException {

    try {
      String pkcs12String =
          getKeyVaultCertificate(pingCertificateName, keyVaultUri);

      ks.load(null);
      final X509Certificate certificateFromPemFormat = createCertificateFromPemFormat(pkcs12String);
      log.info("certificate successfully parsed" + certificateFromPemFormat.getSigAlgName());
      ks.setCertificateEntry("gpa-pf-cert", certificateFromPemFormat);
      log.info("Trust certificate successfully parsed");
      return ks;

    } catch (CertificateException | KeyStoreException | IOException | NoSuchAlgorithmException e) {
      log.error("Error in adding Trust Certificate :: keystore issue ", e);
      Errors errors = new Errors();
      ErrorAndLogUtils.setError(errors, ErrorKeys.KEYVAULT_EXCEPTION.getCode(),
          ErrorKeys.KEYVAULT_EXCEPTION.getMessage());
      throw new GPAAdministrationApplicationException(
          errors);
    }
  }

  private static X509Certificate createCertificateFromPemFormat(final String certificateString)
      throws CertificateException {
    String certificate =
        StringUtils.deleteWhitespace(stripKeyFromBeginEndTags(certificateString, "CERTIFICATE"));

    byte[] decodedCert = DatatypeConverter.parseBase64Binary(certificate);

    ByteArrayInputStream inputStream = new ByteArrayInputStream(decodedCert);
    CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
    return (X509Certificate) certFactory.generateCertificate(inputStream);
  }

  private static String stripKeyFromBeginEndTags(final String key, final String tag) {
    return key.replaceAll("(-----(BEGIN|END) " + tag + "-----)?", StringUtils.EMPTY);
  }

  /**
   * add the trust certificate using the provided certificate data
   *
   * @param secretName  -
   * @param keyVaultUrl
   * @return String - String representation of the KeyVault Secret
   */
  private static String getKeyVaultCertificate(String secretName, String keyVaultUrl) {
    SecretClient secretClient =
        new SecretClientBuilder()
            .vaultUrl(keyVaultUrl)
            .credential(new ManagedIdentityCredentialBuilder().build())
            .buildClient();
    KeyVaultSecret trustedCerts = secretClient.getSecret(secretName);
    return trustedCerts.getValue();
  }
}

