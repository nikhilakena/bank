package com.abnamro.gpa.restservices.administrationconfiguration.requestprocessor;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationSearchCriteriaView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.dtos.ProductAdminMapView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationLogConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.dtos.AdministrationConfigurationResultDTO;
import com.abnamro.gpa.restservices.administrationconfiguration.dtos.AdministrationSearchCriteriaDTO;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import com.abnamro.gpa.restservices.administrationconfiguration.helper.GPAAdministrationMapper;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This is the request Processor class for the Administration Configuration Application. This has operations related to
 * maintains of Administration
 */
@Slf4j
@Component
public class GPAAAdministrationConfigurationRequestProcessor {

  //	@Inject
  private GPAAdministrationMapper mapper = new GPAAdministrationMapper();

  @Autowired
  private GPAAdministrationDAO administrationdao;

  /**
   * This operation is used to retrieve the list of administrations based on input search criteria. It calls mapper to
   * convert the rest DTO to the DAO layer view DTO and vice versa. It then calls DAO layer to retrieve
   * Administrations.
   *
   * @param searchCriteriaDTO rest layer search DTO
   * @return list of administration
   * @throws GPAAdministrationApplicationException of DAO layer exception is thrown
   */
  public List<AdministrationRestResource> searchAdministration(AdministrationSearchCriteriaDTO searchCriteriaDTO)
      throws GPAAdministrationApplicationException {

    final String LOG_METHOD = "searchAdministration(searchCriteriaDTO):List<AdministrationRestResource>";

    List<AdministrationRestResource> administrationResourceList = null;

    try {
      AdministrationSearchCriteriaView searchCriteriaView = mapper.convertToSearchCriteriaView(searchCriteriaDTO);

      List<AdministrationView> administrationViewList = administrationdao
          .searchAdministration(searchCriteriaView);

      administrationResourceList = mapper.convertToAdministrationRestResourceList(administrationViewList);

    } catch (GPAAdministrationDAOException daoException) {
      log.error("{} Exception occurred dao in search glossary request processor={} | exception={} ", LOG_METHOD,
          GPAAdministrationConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_SEARCH_GLOSSARY_REQUEST_PROCESSOR,
          daoException);
      throw new GPAAdministrationApplicationException(daoException);
    }
    return administrationResourceList;
  }

  /**
   * This method is used to create a administration
   *
   * @param administrationRestResource is rest input for create administration
   * @return AdministrationConfigurationResultDTO is ResultDTO which contains indicator for success
   * @throws GPAAdministrationApplicationException is used to throw the DAO layer exception
   */
  public AdministrationConfigurationResultDTO createAdministration(
      AdministrationRestResource administrationRestResource) throws GPAAdministrationApplicationException {
    final String LOG_METHOD = "createAdministration(AdministrationRestResource):AdministrationConfigurationResultDTO";
    AdministrationConfigurationResultDTO administrationConfigurationResultDTO = null;
    try {
      AdministrationView administrationView = mapper
          .convertAdminRestResourceToAdminView(administrationRestResource);
      int administrationId = administrationdao.createAdministration(administrationView);
      administrationConfigurationResultDTO = new AdministrationConfigurationResultDTO();
      administrationConfigurationResultDTO.setIdentifier(administrationId);
      administrationConfigurationResultDTO.setIndicatorSuccess(true);

    } catch (GPAAdministrationDAOException gpaAdministrationDAOException) {
      log.error("{} exception occurred dao in create administration request processor={} | exception={} ", LOG_METHOD,
          GPAAdministrationConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_CREATE_ADMINISTRATION_REQUEST_PROCESSOR,
          gpaAdministrationDAOException);
      throw new GPAAdministrationApplicationException(gpaAdministrationDAOException);
    }
    return administrationConfigurationResultDTO;

  }

  /**
   * This method is used read administration for input administration Id
   *
   * @param administrationId unique Identifier of an administrations
   * @return administration details
   * @throws GPAAdministrationApplicationException in case of errors
   */
  public AdministrationRestResource readAdministration(int administrationId)
      throws GPAAdministrationApplicationException {
    final String LOG_METHOD = "readAdministration():: ";
    AdministrationRestResource administrationRestResource = null;
    try {
      AdministrationView administrationView = administrationdao.readAdministration(administrationId, 0);
      administrationRestResource = mapper.convertToAdministrationRestResource(administrationView);
    } catch (GPAAdministrationDAOException gpaAdministrationDAOException) {
      log.error("{} Exception occurred dao in read administration request processor={} | exception={} ", LOG_METHOD,
          GPAAdministrationConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_READ_ADMINISTRATION_REQUEST_PROCESSOR,
          gpaAdministrationDAOException);
      throw new GPAAdministrationApplicationException(gpaAdministrationDAOException);
    }
    return administrationRestResource;
  }


  /**
   * This method is to validate administration deletion
   *
   * @param adminId is input Administration ID
   * @return administrationConfigurationResultDTO is AdministrationConfigurationResultDTO
   * @throws GPAAdministrationApplicationException is an exception
   */
  public AdministrationConfigurationResultDTO deleteAdministration(int adminId)
      throws GPAAdministrationApplicationException {
    final String LOG_METHOD = "deleteAdministration():: ";

    AdministrationConfigurationResultDTO administrationConfigurationResultDTO = null;
    try {
      administrationConfigurationResultDTO = validateAdministrationDeletion(adminId);
    } catch (GPAAdministrationDAOException gpaAdministrationDAOException) {
      log.error("{} Exception occurred dao in delete administration request processor={} | exception={}", LOG_METHOD,
          GPAAdministrationConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_DELETE_ADMINISTRATION_REQUEST_PROCESSOR,
          gpaAdministrationDAOException);
      throw new GPAAdministrationApplicationException(gpaAdministrationDAOException);
    }

    return administrationConfigurationResultDTO;
  }

  private AdministrationConfigurationResultDTO validateAdministrationDeletion(int adminId)
      throws GPAAdministrationDAOException, GPAAdministrationApplicationException {
    List<Integer> productListWithAgreement = new ArrayList<>();
    AdministrationConfigurationResultDTO administrationConfigurationResultDTO = new AdministrationConfigurationResultDTO();
    AdministrationView administrationView = administrationdao.readAdministration(adminId, 0);
    if (administrationView != null) {
      productListWithAgreement = getProductListWithAgreement(administrationView);
    }

    if (productListWithAgreement.size() > 0) {
      adminDeletionNotAllowed(productListWithAgreement);
    } else {
      administrationConfigurationResultDTO.setIndicatorSuccess(administrationdao.deleteAdministration(adminId));
    }

    return administrationConfigurationResultDTO;
  }

  private void adminDeletionNotAllowed(List<Integer> productListWithAgreement)
      throws GPAAdministrationApplicationException {
    Messages messages = new Messages();
    Object[] objects = {productListWithAgreement};
    messages.addMessage(
        new Message(
            GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_DELETE_ADMIN_NOT_ALLOWED,
            null, objects),
        MessageType.getError());
    throw new GPAAdministrationApplicationException(messages);

  }

  // if administration has agreement in GPA, this method will return true else false.
  private List<Integer> getProductListWithAgreement(AdministrationView administrationView)
      throws GPAAdministrationApplicationException, GPAAdministrationDAOException {

    List<Integer> productWithAgreement = new ArrayList<Integer>();

    for (ProductAdminMapView prodAdminView : administrationView.getProductAdminMapViews()) {
      boolean agreeementPresent = administrationdao.retreiveAgreementCountForProduct(prodAdminView.getProductId());

      if (agreeementPresent) {
        //maintain list of products which has agreement in GPA
        productWithAgreement.add(prodAdminView.getProductId());
      }
    }

    return productWithAgreement;

  }

}
