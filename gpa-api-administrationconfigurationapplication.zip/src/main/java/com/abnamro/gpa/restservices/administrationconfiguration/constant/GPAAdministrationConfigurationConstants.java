package com.abnamro.gpa.restservices.administrationconfiguration.constant;

/**
 * This is class contains the administration Configuration Constants
 *
 */
public class GPAAdministrationConfigurationConstants {

  public static final String PRODUCTID_ALREADY_EXIST_WHILE_CREATING_ADMINISTRATION = "MESSAGE_ADDA_007";
  public static final String PRODUCTID_ALREADY_EXIST_WHILE_UPDATING_ADMINISTRATION = "MESSAGE_ADDA_008";
  public static final String CREATED_UPDATED_BY = "GPAADMIN";


}
