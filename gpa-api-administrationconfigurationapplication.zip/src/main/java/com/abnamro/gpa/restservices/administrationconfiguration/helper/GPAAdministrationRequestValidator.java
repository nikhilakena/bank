package com.abnamro.gpa.restservices.administrationconfiguration.helper;

import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restresource.glossary.TermFacetRestResource;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationLogConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * This is a Validator class used to validate the input provided in rest service
 */
@Slf4j
@Component
public class GPAAdministrationRequestValidator {

  private static final String GLOSSARY_SEARCH_DATE_FORMAT = "dd-MM-yyyy";

  /**
   * This method validates the data provided in search administration of glossary
   *
   * @param administrationId   is String value of administration id
   * @param administrationName is String value of administration name
   * @param oarId              is String value of oarId
   * @param createdBy          is String value of createdBy
   * @param createdDateFrom    is String value of createdDateFrom
   * @param createdDateTo      is String value of createdDateTo
   * @throws GPAAdministrationApplicationException is a BusinessApplicationException
   */
  public void validateAdministrationSearchCriteria(String administrationId, String administrationName, String oarId,
      String createdBy, String createdDateFrom, String createdDateTo)
      throws GPAAdministrationApplicationException {

    validateMandatoryFieldsForSearch(administrationId, administrationName, oarId, createdBy, createdDateFrom,
        createdDateTo);

    validateSearchDateRange(createdDateFrom, createdDateTo);

    validateAdministrationId(administrationId);
  }

  private void validateAdministrationId(String administrationId) throws GPAAdministrationApplicationException {
    final String logMethod = "validateAdministrationId():: ";
    if (StringUtils.isNotEmpty(administrationId) && getIntFromString(administrationId) <= 0) {
      log.error("{} invalid administration ID in searching administration={} ", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_INVALID_ADMINISTRATION_ID_SEARCH_ADMINISTRATION);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_INVALID_ADMINISTRATION_ID),
          MessageType.getError());
      throw new GPAAdministrationApplicationException(messages);
    }

  }

  private int getIntFromString(String value) throws GPAAdministrationApplicationException {
    final String logMethod = "getIntFromString():: ";
    int intvalue;
    try {
      intvalue = Integer.parseInt(value);
    } catch (NumberFormatException e) {
      log.error("{} Exception occurred when invalid administration ID in searching administration={} | exception={} ",
          logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_INVALID_ADMINISTRATION_ID_SEARCH_ADMINISTRATION, e);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_ADMINISTRATION_ID_IS_NOT_NUMERIC),
          MessageType.getError());
      throw new GPAAdministrationApplicationException(messages);
    }
    return intvalue;
  }

  private void validateSearchDateRange(String createdDateFrom, String createdDateTo)
      throws GPAAdministrationApplicationException {
    Date createdFromDate = validateSearchDateFormat(createdDateFrom.trim());
    Date createdToDate = validateSearchDateFormat(createdDateTo.trim());
    if (createdFromDate != null && createdToDate != null && createdFromDate.after(createdToDate)) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_SEARCH_FROM_DATE_CAN_NOT_BE_GREATER_THAN_TO_DATE),
          MessageType.getError());
      throw new GPAAdministrationApplicationException(messages);
    }

  }

  private Date validateSearchDateFormat(String inputDate) throws GPAAdministrationApplicationException {
    final String logMethod = "validateSearchDateFormat():: ";
    DateFormat format = new SimpleDateFormat(GLOSSARY_SEARCH_DATE_FORMAT, Locale.getDefault());
    Date date = null;
    try {
      date = format.parse(inputDate);
    } catch (ParseException e) {
      log.error("{} Exception occurred when invalid date in searching glossary={} | exception={} ", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_INVALID_DATE_IN_SEARCH_GLOSSARY, e);
      Messages messages = new Messages();
      messages.addMessage(new Message(GPAAdministrationConfigurationMessageKeyConstants.PARSING_EXCEPTION),
          MessageType.getError());
      throw new GPAAdministrationApplicationException(messages);
    }
    return date;
  }

  private void validateMandatoryFieldsForSearch(String administrationId, String administrationName, String oarId,
      String createdBy, String createdDateFrom, String createdDateTo)
      throws GPAAdministrationApplicationException {
    if (StringUtils.isEmpty(administrationId) && StringUtils.isEmpty(administrationName)
        && StringUtils.isEmpty(oarId)) {
      if (StringUtils.isEmpty(createdBy) && StringUtils.isEmpty(createdDateFrom)
          && StringUtils.isEmpty(createdDateTo)) {
        Messages messages = new Messages();
        messages.addMessage(
            new Message(
                GPAAdministrationConfigurationMessageKeyConstants.ATLEAST_ONE_SEARCH_CRITERIA_IS_REQUIRED_IN_GLOSSARY_SEARCH),
            MessageType.getError());
        throw new GPAAdministrationApplicationException(messages);
      }
    }

  }

  /**
   * this method is used to validate mandatory fields for create admin
   *
   * @param administrationRestResource AdministrationRestResource Rest input resource for administration
   * @throws GPAAdministrationApplicationException GPAAdministrationApplicationException Exception thrown if validation
   *                                               fails
   */
  public void validateMandatoryFieldsForCreate(AdministrationRestResource administrationRestResource)
      throws GPAAdministrationApplicationException {
    final String logMethod = "validateMandatoryFieldsForCreate():: ";
    // Name, description, product id(atleast one) and oar id are mandatory
    if (null == administrationRestResource) {
      log.error("{} input null resource in create administration={} ", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_NULL_INPUT_RESOURCE_IN_CREATE_ADMINISTRATION);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMINISTRATION_CREATE),
          MessageType.getError());
      throw new GPAAdministrationApplicationException(messages);
    }

    boolean blankInputAdministrationDetails = StringUtils.isEmpty(administrationRestResource.getName())
        || StringUtils.isEmpty(administrationRestResource.getDescription())
        || StringUtils.isEmpty(administrationRestResource.getOarId())
        || administrationRestResource.getProducts().isEmpty();
    if (blankInputAdministrationDetails) {
      log.error("{} mandatory fields missing in create administration={} ", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_MANDATORY_FIELDS_MISSING_CREATE_ADMINISTRATION);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMINISTRATION_CREATE),
          MessageType.getError());
      throw new GPAAdministrationApplicationException(messages);
    }

    // for each facet type facet value is mandatory
    if (administrationRestResource.getTerms() != null && !administrationRestResource.getTerms().isEmpty()) {
      for (TermRestResource term : administrationRestResource.getTerms()) {
        validateFacetDetails(term);
      }
    }

  }

  private void validateFacetDetails(TermRestResource term) throws GPAAdministrationApplicationException {
    final String logMethod = "validateFacetDetails():: ";
    if (term.getFacets() != null && !term.getFacets().isEmpty()) {
      for (TermFacetRestResource facet : term.getFacets()) {
        if (facet.getFacetType() != null && StringUtils.isBlank(facet.getFacetValue())) {
          log.error("{} facet value missing in create administration={} ", logMethod,
              GPAAdministrationConfigurationLogConstants.LOG_FACET_VALUE_MISSING_CREATE_ADMINISTRATION);
          Messages messages = new Messages();
          messages.addMessage(
              new Message(
                  GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_CREATE_ADMIN_BLANK_FACET_VALUE),
              MessageType.getError());
          throw new GPAAdministrationApplicationException(messages);
        }
      }
    }
  }

  /**
   * This method validates the administration id for the readAdmin service
   *
   * @param administrationId unique Identifier of an administrations
   * @throws GPAAdministrationApplicationException in case validation fails
   */
  public void validateAdministrationIdForRead(String administrationId) throws GPAAdministrationApplicationException {
    final String logMethod = "validateAdministrationIdForRead():: ";
    if (StringUtils.isEmpty(administrationId) || getIntFromString(administrationId) <= 0) {
      log.error("{} invalid administration in read administration={} ", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_INVALID_ADMINISTRATION_ID_READ_ADMINISTRATION);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_INVALID_ADMINISTRATION_ID_READ),
          MessageType.getError());
      throw new GPAAdministrationApplicationException(messages);
    }

  }

  /**
   * This method is used to validate mandatory fields for update admin
   *
   * @param administrationRestResource AdministrationRestResource Rest input resource for administration
   * @throws GPAAdministrationApplicationException GPAAdministrationApplicationException Exception thrown if validation
   *                                               fails
   */
  public void validateMandatoryFieldsForUpdate(AdministrationRestResource administrationRestResource)
      throws GPAAdministrationApplicationException {
    final String logMethod = "validateMandatoryFieldsForUpdate():: ";
    // Name, description, product id(atleast one) and oar id are mandatory
    if (null == administrationRestResource) {
      log.error("{} null input resource in update administration={} ", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_NULL_INPUT_RESOURCE_IN_UPDATE_ADMINISTRATION);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMINISTRATION_UDPATE),
          MessageType.getError());
      throw new GPAAdministrationApplicationException(messages);
    }

    boolean blankInputAdministrationDetails = validateBlankGenericAdminDetails(administrationRestResource);
    if (blankInputAdministrationDetails) {
      log.error("{} mandatory fields missing in update administration={} ", logMethod,
          GPAAdministrationConfigurationLogConstants.LOG_MANDATORY_FIELDS_MISSING_UPDATE_ADMINISTRATION);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMINISTRATION_UPDATE),
          MessageType.getError());
      throw new GPAAdministrationApplicationException(messages);
    }

    // for each facet type facet value is mandatory
    if (administrationRestResource.getTerms() != null && !administrationRestResource.getTerms().isEmpty()) {
      for (TermRestResource term : administrationRestResource.getTerms()) {
        validateFacetDetails(term);
      }
    }

  }

  private boolean validateBlankGenericAdminDetails(AdministrationRestResource administrationRestResource) {
    boolean flag = false;
    if (StringUtils.isEmpty(administrationRestResource.getName())) {
      flag = true;
    }
    if (StringUtils.isEmpty(administrationRestResource.getDescription())) {
      flag = true;
    }
    if (StringUtils.isEmpty(administrationRestResource.getOarId())) {
      flag = true;
    }
    if (administrationRestResource.getProducts().isEmpty()) {
      flag = true;
    }
    if (administrationRestResource.getId() <= 0) {
      flag = true;
    }

    return flag;
  }

}
