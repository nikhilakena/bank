package com.abnamro.gpa.restservices.administrationconfiguration.health;

import static org.springframework.http.HttpStatus.OK;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * This controller will be called by the load balancer to see whether the connections are healthy.
 */
@RestController
public class HealthCheckController {

  /**
   * default value
   */
  private static final long serialVersionUID = 1L;


  @GetMapping(value = "/healthcheck")
  @ResponseStatus(OK)
  protected boolean isHealthy() {
    return true;
  }

}
