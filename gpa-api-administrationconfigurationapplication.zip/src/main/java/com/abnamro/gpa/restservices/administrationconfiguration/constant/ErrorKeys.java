package com.abnamro.gpa.restservices.administrationconfiguration.constant;


/**
 * Log / message keys Enumeration.
 */
public enum ErrorKeys {
  /**
   * The Authentication exception.
   */
  AUTHENTICATION_EXCEPTION("UNAUTHORIZED_USER",
      "Error in authentication"),
  /**
   * The Keyvault exception.
   */
  KEYVAULT_EXCEPTION("KEYVAULT_EXCEPTION",
      "Error in Keyvault Certificate"),
  /**
   * The Not found exception.
   */
  NOT_FOUND_EXCEPTION("NOT_FOUND", "Not found"),
  /**
   * Other exception error keys.
   */
  OTHER_EXCEPTION(ErrorConstants.TECHNICAL_EXCEPTION, ErrorConstants.TECHNICAL_ERROR),
  /**
   * Technical error from ims exception error keys.
   */
  TECHNICAL_ERROR_FROM_IMS_EXCEPTION(ErrorConstants.TECHNICAL_EXCEPTION, ErrorConstants.TECHNICAL_ERROR),
  /**
   * The Connection exception.
   */
  CONNECTION_EXCEPTION(ErrorConstants.TECHNICAL_EXCEPTION, "Technical error");

  private final String code;

  private final String message;

  /**
   * Constructor to assign the field value of the ErrorKeys enum values.
   *
   * @param errorCode
   * @param errorMessage
   */
  ErrorKeys(String errorCode, String errorMessage) {
    this.code = errorCode;
    this.message = errorMessage;
  }

  /**
   * Gets code.
   *
   * @return the code
   */
  public String getCode() {
    return code;
  }

  /**
   * Gets message.
   *
   * @return the message
   */
  public String getMessage() {
    return message;
  }


}

