package com.abnamro.gpa.restservices.administrationconfiguration.helper;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;

import com.abnamro.gpa.generic.administrationdao.dtos.AdminTermView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationSearchCriteriaView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.dtos.FacetView;
import com.abnamro.gpa.generic.administrationdao.dtos.ProductAdminMapView;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermFacetRestResource;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.dtos.AdministrationSearchCriteriaDTO;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * This class has operation for mapping data from Rest domain model DTOs to DAO Layer DTOs or vice versa.
 *
 */
@Component
public class GPAAdministrationMapper {

  public static final String SEARCH_DATE_FORMAT = "dd-MM-yyyy";

  /**
   * This method populates the SearchCriteriaDTO
   *
   * @param administrationId   is String value of administration id
   * @param administrationName is String value of administration name
   * @param oarId              is String value of oarId
   * @param createdBy          is String value of createdBy
   * @param createdDateFrom    is String value of createdDateFrom
   * @param createdDateTo      is String value of createdDateTo
   * @return Administration Search CriteriaDTO
   */
  public AdministrationSearchCriteriaDTO populateSearchCriteriaDTO(String administrationId, String administrationName,
      String oarId, String createdBy, String createdDateFrom, String createdDateTo) {

    AdministrationSearchCriteriaDTO searchCriteriaDTO = new AdministrationSearchCriteriaDTO();
    if (administrationId != null && StringUtils.isNotEmpty(administrationId)) {
      searchCriteriaDTO.setAdministrationId(Integer.parseInt(administrationId));
    }
    searchCriteriaDTO.setAdministrationName(administrationName);
    searchCriteriaDTO.setCreatedBy(createdBy);
    searchCriteriaDTO.setOarId(oarId);
    searchCriteriaDTO.setCreatedTimestampTo(createdDateTo);
    searchCriteriaDTO.setCreatedTimestampFrom(createdDateFrom);

    return searchCriteriaDTO;
  }

  /**
   * This operation is used to convert the rest layer Administration search criteria DTO to the Administration Search
   * Criteria View of the DAO Layer.
   *
   * @param searchCriteriaDTO rest layer DTO
   * @return DAO layer search DTO
   * @throws GPAAdministrationApplicationException a GPAAdministrationApplicationException for date conversion
   */
  public AdministrationSearchCriteriaView convertToSearchCriteriaView(
      AdministrationSearchCriteriaDTO searchCriteriaDTO) throws GPAAdministrationApplicationException {

    AdministrationSearchCriteriaView searchCriteriaView = new AdministrationSearchCriteriaView();

    searchCriteriaView.setAdministrationId(searchCriteriaDTO.getAdministrationId());
    searchCriteriaView.setAdministrationName(searchCriteriaDTO.getAdministrationName());
    searchCriteriaView.setOarId(searchCriteriaDTO.getOarId());
    searchCriteriaView.setCreatedBy(searchCriteriaDTO.getCreatedBy());
    if (searchCriteriaDTO.getCreatedTimestampFrom() != null) {
      Timestamp createFromTimeStamp = convertStringDatetoTimestamp(
          searchCriteriaDTO.getCreatedTimestampFrom().trim(), true);
      searchCriteriaView.setCreatedTimestampFrom(createFromTimeStamp);
    }
    if (searchCriteriaDTO.getCreatedTimestampTo() != null) {
      Timestamp createToTimeStamp = convertStringDatetoTimestamp(searchCriteriaDTO.getCreatedTimestampTo().trim(),
          false);
      searchCriteriaView.setCreatedTimestampTo(createToTimeStamp);
    }

    return searchCriteriaView;

  }

  private Timestamp convertStringDatetoTimestamp(String inputDate, boolean isFromDate)
      throws GPAAdministrationApplicationException {
    Date date = getDateFromString(inputDate);
    Timestamp ts = null;
    if (null != date) {
      if (!isFromDate) {
        ts = new Timestamp(setMaxTime(date).getTime());
      } else {
        ts = new Timestamp(date.getTime());
      }
    }
    return ts;
  }

  private Date getDateFromString(String sDate) throws GPAAdministrationApplicationException {
    DateFormat format = new SimpleDateFormat(SEARCH_DATE_FORMAT, Locale.getDefault());
    java.util.Date date = null;
    try {
      date = format.parse(sDate);
    } catch (ParseException e) {
      Messages messages = new Messages();
      messages.addMessage(new Message(GPAAdministrationConfigurationMessageKeyConstants.PARSING_EXCEPTION),
          MessageType.getError());
      throw new GPAAdministrationApplicationException(messages);
    }
    return date;
  }

  private static Date setMaxTime(Date date) {
    Calendar cal = Calendar.getInstance();
    cal.setTime(date);
    cal.set(Calendar.HOUR_OF_DAY, 23);
    cal.set(Calendar.MINUTE, 59);
    cal.set(Calendar.SECOND, 59);
    cal.set(Calendar.MILLISECOND, 59);
    return cal.getTime();
  }

  private Timestamp convertDatetoTimestamp(Date inputDate) throws GPAAdministrationApplicationException {
    Timestamp ts = null;
    if (null != inputDate) {
      ts = new Timestamp(inputDate.getTime());
    }
    return ts;
  }

  /**
   * This operation is used to convert the list of DAO Layer administration view DTO to the rest layer administration
   * resource.
   *
   * @param administrationViewList list of DAO Layer administration view DTO
   * @return rest layer administration resource
   */
  public List<AdministrationRestResource> convertToAdministrationRestResourceList(
      List<AdministrationView> administrationViewList) {
    List<AdministrationRestResource> administrationResourceList = null;
    if (administrationViewList != null && !administrationViewList.isEmpty()) {
      administrationResourceList = new ArrayList<AdministrationRestResource>();
      for (AdministrationView administrationView : administrationViewList) {
        AdministrationRestResource administrationRestResource = convertToAdministrationRestResource(
            administrationView);
        administrationResourceList.add(administrationRestResource);
      }
    }
    return administrationResourceList;
  }

  /**
   * This method is used to convert AdministrationView to the AdministrationRestResource
   *
   * @param administrationView retrieved from database
   * @return AdministrationRestResource details
   */
  public AdministrationRestResource convertToAdministrationRestResource(AdministrationView administrationView) {
    AdministrationRestResource administrationRestResource = null;
    if (administrationView != null) {
      administrationRestResource = new AdministrationRestResource();
      administrationRestResource.setId(administrationView.getId());
      if (administrationView.getName() != null && StringUtils.isNotEmpty(administrationView.getName())) {
        administrationRestResource.setName(administrationView.getName().trim());
      }
      if (administrationView.getDescription() != null
          && StringUtils.isNotEmpty(administrationView.getDescription())) {
        administrationRestResource.setDescription(administrationView.getDescription().trim());
      }
      if (administrationView.getOarId() != null && StringUtils.isNotEmpty(administrationView.getOarId())) {
        administrationRestResource.setOarId(administrationView.getOarId().trim());
      }
      if (administrationView.getName() != null && StringUtils.isNotEmpty(administrationView.getName())) {
        administrationRestResource.setName(administrationView.getName().trim());
      }
      administrationRestResource.setAuditDetails(getPopulatedAuditDetails(administrationView.getCreatedBy(),
          administrationView.getCreatedTimeStamp(), administrationView.getModifiedBy(),
          administrationView.getModifiedTimeStamp()));

      populateAdminProductMappingResource(administrationRestResource, administrationView);
      populateAdminTermResource(administrationRestResource, administrationView);
    }
    return administrationRestResource;
  }

  private void populateAdminTermResource(AdministrationRestResource administrationRestResource,
      AdministrationView administrationView) {
    List<TermRestResource> terms = null;
    if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
      terms = new ArrayList<TermRestResource>();
      for (AdminTermView adminTermView : administrationView.getAdminTermViews()) {
        TermRestResource termRestResource = convertToTermRestResource(adminTermView);
        terms.add(termRestResource);
      }
    }
    administrationRestResource.setTerms(terms);
  }

  private TermRestResource convertToTermRestResource(AdminTermView adminTermView) {
    TermRestResource termRestResource = new TermRestResource();
    termRestResource.setId(adminTermView.getTermId());
    if (adminTermView.getName() != null) {
      termRestResource.setName(adminTermView.getName().trim());
    }
    if (adminTermView.getDescription() != null) {
      termRestResource.setDescription(adminTermView.getDescription().trim());
    }
    if (adminTermView.getDataType() != null && !"".equals(adminTermView.getDataType())) {
      termRestResource.setDataType(TermDataType.valueOf(adminTermView.getDataType().trim()));
    }
    if (adminTermView.getMandatoryIndicator() != null && ("Y").equals(adminTermView.getMandatoryIndicator())) {
      termRestResource.setMandatory(true);
    }

    populateTermFacetResource(termRestResource, adminTermView);
    populateConsolidatedTermAuditDetails(termRestResource, adminTermView);
    return termRestResource;
  }

  private void populateTermFacetResource(TermRestResource termRestResource, AdminTermView adminTermView) {

    List<TermFacetRestResource> facets = null;
    if (adminTermView.getFacetView() != null && !adminTermView.getFacetView().isEmpty()) {
      facets = new ArrayList<TermFacetRestResource>();
      for (FacetView facetView : adminTermView.getFacetView()) {
        TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
        if (facetView.getType() != null && !("").equals(facetView.getType().trim())) {
          termFacetRestResource.setFacetType(FacetTypes.valueOf(facetView.getType().trim()));
        }
        termFacetRestResource.setFacetValue(facetView.getValue());
        AuditDetails auditDetails = getPopulatedAuditDetails(facetView.getCreatedBy(),
            facetView.getCreatedTimeStamp(), facetView.getModifiedBy(), facetView.getModifiedTimeStamp());
        termFacetRestResource.setAuditDetails(auditDetails);
        facets.add(termFacetRestResource);
      }
    }
    termRestResource.setFacets(facets);
  }

  /**
   * THis method populates consolidated audit details for terms
   *
   * @param termRestResource Term details
   * @param adminTermView    Administration term view
   */
  public void populateConsolidatedTermAuditDetails(TermRestResource termRestResource, AdminTermView adminTermView) {

    Timestamp consolidatedTermUpdatedDate = new Timestamp(0);
    String consolidatedTermUpdatedBy = null;
    AuditDetails termAuditDetails = null;
    if (termRestResource.getFacets() != null) {
      for (TermFacetRestResource termFacetRestResource : termRestResource.getFacets()) {
        AuditDetails auditDetails = termFacetRestResource.getAuditDetails();
        if (auditDetails.getModifiedTimeStamp().after(auditDetails.getCreatedTimeStamp())
            && StringUtils.isNotEmpty(auditDetails.getModifiedBy())) {
          if (auditDetails.getModifiedTimeStamp().after(consolidatedTermUpdatedDate)) {
            consolidatedTermUpdatedDate = (Timestamp) auditDetails.getModifiedTimeStamp();
            consolidatedTermUpdatedBy = auditDetails.getModifiedBy();
          }
        } else {
          if (auditDetails.getCreatedTimeStamp().after(consolidatedTermUpdatedDate)) {
            consolidatedTermUpdatedDate = (Timestamp) auditDetails.getCreatedTimeStamp();
            consolidatedTermUpdatedBy = auditDetails.getCreatedBy();
          }
        }
      }
    }
    if (consolidatedTermUpdatedDate.after(adminTermView.getModifiedTimeStamp())) {
      termAuditDetails = getPopulatedAuditDetails(adminTermView.getCreatedBy(),
          adminTermView.getCreatedTimeStamp(), consolidatedTermUpdatedBy, consolidatedTermUpdatedDate);
    } else {
      termAuditDetails = getPopulatedAuditDetails(adminTermView.getCreatedBy(),
          adminTermView.getCreatedTimeStamp(), adminTermView.getModifiedBy(),
          adminTermView.getModifiedTimeStamp());
    }
    termRestResource.setAuditDetails(termAuditDetails);
  }

  private void populateAdminProductMappingResource(AdministrationRestResource administrationRestResource,
      AdministrationView administrationView) {
    List<Integer> products = null;
    if (administrationView.getProductAdminMapViews() != null
        && !administrationView.getProductAdminMapViews().isEmpty()) {
      products = new ArrayList<Integer>();
      for (ProductAdminMapView productAdminMapView : administrationView.getProductAdminMapViews()) {
        products.add(productAdminMapView.getProductId());
      }
    }
    administrationRestResource.setProducts(products);
  }

  private AuditDetails getPopulatedAuditDetails(String createdBy, Timestamp createdTimeStamp, String modifiedBy,
      Timestamp modifiedTimeStamp) {
    AuditDetails auditDetails = new AuditDetails();
    if (createdBy != null && StringUtils.isNotEmpty(createdBy)) {
      auditDetails.setCreatedBy(createdBy.trim());
    }
    if (createdTimeStamp != null) {
      auditDetails.setCreatedTimeStamp(createdTimeStamp);
    }
    if (modifiedBy != null && StringUtils.isNotEmpty(modifiedBy)) {
      auditDetails.setModifiedBy(modifiedBy.trim());
    }
    if (modifiedTimeStamp != null) {
      auditDetails.setModifiedTimeStamp(modifiedTimeStamp);
    }
    return auditDetails;
  }

  /**
   * This operation is used to convert the rest layer Administration search criteria DTO to the Administration Search
   * Criteria View of the DAO Layer.
   *
   * @param administrationRestResource rest resource Administration
   * @return AdministrationView DAO layer createAdministration DTO
   * @throws GPAAdministrationApplicationException a GPAAdministrationApplicationException for date conversion
   */
  public AdministrationView convertAdminRestResourceToAdminView(AdministrationRestResource administrationRestResource)
      throws GPAAdministrationApplicationException {

    AdministrationView administrationView = new AdministrationView();
    administrationView.setId(administrationRestResource.getId());
    administrationView.setName(administrationRestResource.getName());
    administrationView.setOarId(administrationRestResource.getOarId());
    administrationView.setDescription(administrationRestResource.getDescription());

    AuditDetails auditDetails = administrationRestResource.getAuditDetails();

    if (administrationRestResource.getAuditDetails() != null) {
      administrationView.setCreatedBy(administrationRestResource.getAuditDetails().getCreatedBy());
      Timestamp createFromTimeStamp = convertDatetoTimestamp(
          administrationRestResource.getAuditDetails().getCreatedTimeStamp());
      administrationView.setCreatedTimeStamp(createFromTimeStamp);

      administrationView.setModifiedBy(administrationRestResource.getAuditDetails().getModifiedBy());
      Timestamp modifiedTimeStamp = convertDatetoTimestamp(
          administrationRestResource.getAuditDetails().getModifiedTimeStamp());
      administrationView.setModifiedTimeStamp(modifiedTimeStamp);
    }

    if (administrationRestResource.getTerms() != null && !administrationRestResource.getTerms().isEmpty()) {
      List<AdminTermView> adminTermViews = new ArrayList<AdminTermView>();
      for (TermRestResource termRestResource : administrationRestResource.getTerms()) {
        AdminTermView adminTermView = convertToAdminTermView(termRestResource, auditDetails);
        adminTermViews.add(adminTermView);
      }
      administrationView.setAdminTermViews(adminTermViews);
    }

    if (administrationRestResource.getProducts() != null && !administrationRestResource.getProducts().isEmpty()) {
      List<ProductAdminMapView> productAdminMapViews = new ArrayList<ProductAdminMapView>();
      for (int productId : administrationRestResource.getProducts()) {
        ProductAdminMapView productAdminMapView = convertToProductAdminMapView(productId, auditDetails);
        productAdminMapViews.add(productAdminMapView);
      }
      administrationView.setProductAdminMapViews(productAdminMapViews);
    }

    return administrationView;

  }

  private AdminTermView convertToAdminTermView(TermRestResource termRestResource, AuditDetails auditDetails)
      throws GPAAdministrationApplicationException {

    AdminTermView adminTermView = new AdminTermView();
    adminTermView.setTermId(termRestResource.getId());

    if (termRestResource.isMandatory()) {
      adminTermView.setMandatoryIndicator("Y");
    } else {
      adminTermView.setMandatoryIndicator("N");
    }

    if (auditDetails != null) {
      adminTermView.setCreatedBy(auditDetails.getCreatedBy());
      Timestamp createFromTimeStamp = convertDatetoTimestamp(auditDetails.getCreatedTimeStamp());
      adminTermView.setCreatedTimeStamp(createFromTimeStamp);

      adminTermView.setModifiedBy(auditDetails.getModifiedBy());
      Timestamp modifiedTimeStamp = convertDatetoTimestamp(auditDetails.getModifiedTimeStamp());
      adminTermView.setModifiedTimeStamp(modifiedTimeStamp);
    }

    if (termRestResource.getFacets() != null && !termRestResource.getFacets().isEmpty()) {
      List<FacetView> facetViews = new ArrayList<FacetView>();
      for (TermFacetRestResource termFacetRestResource : termRestResource.getFacets()) {
        FacetView facetView = convertToFacetView(termFacetRestResource, auditDetails);
        facetViews.add(facetView);
      }
      adminTermView.setFacetView(facetViews);
    }

    return adminTermView;
  }

  private FacetView convertToFacetView(TermFacetRestResource termFacetRestResource, AuditDetails auditDetails)
      throws GPAAdministrationApplicationException {
    FacetView facetView = new FacetView();
    facetView.setType(termFacetRestResource.getFacetType().name());
    facetView.setValue(termFacetRestResource.getFacetValue());

    if (auditDetails != null) {
      facetView.setCreatedBy(auditDetails.getCreatedBy());
      Timestamp createFromTimeStamp = convertDatetoTimestamp(auditDetails.getCreatedTimeStamp());
      facetView.setCreatedTimeStamp(createFromTimeStamp);

      facetView.setModifiedBy(auditDetails.getModifiedBy());
      Timestamp modifiedTimeStamp = convertDatetoTimestamp(auditDetails.getModifiedTimeStamp());
      facetView.setModifiedTimeStamp(modifiedTimeStamp);
    }

    return facetView;
  }

  private ProductAdminMapView convertToProductAdminMapView(int productId, AuditDetails auditDetails)
      throws GPAAdministrationApplicationException {
    ProductAdminMapView productAdminMapView = new ProductAdminMapView();
    productAdminMapView.setProductId(productId);
    if (auditDetails != null) {
      productAdminMapView.setCreatedBy(auditDetails.getCreatedBy());
      Timestamp createFromTimeStamp = convertDatetoTimestamp(auditDetails.getCreatedTimeStamp());
      productAdminMapView.setCreatedTimeStamp(createFromTimeStamp);

      productAdminMapView.setModifiedBy(auditDetails.getModifiedBy());
      Timestamp modifiedTimeStamp = convertDatetoTimestamp(auditDetails.getModifiedTimeStamp());
      productAdminMapView.setModifiedTimeStamp(modifiedTimeStamp);
    }
    return productAdminMapView;
  }
}
