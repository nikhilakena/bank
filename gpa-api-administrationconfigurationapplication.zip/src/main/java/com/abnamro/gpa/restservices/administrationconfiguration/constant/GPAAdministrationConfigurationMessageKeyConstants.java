package com.abnamro.gpa.restservices.administrationconfiguration.constant;

import com.abnamro.gpa.generic.exception.MessageKey;

/**
 * This class contains the administration Configuration MessageKey Constants
 *
 */
public class GPAAdministrationConfigurationMessageKeyConstants {

  public static final MessageKey ATLEAST_ONE_SEARCH_CRITERIA_IS_REQUIRED_IN_GLOSSARY_SEARCH = new MessageKey(
      "MESSAGE_BAI693_001");

  public static final MessageKey VALIDATION_EXCEPTION_IN_SEARCH_FROM_DATE_CAN_NOT_BE_GREATER_THAN_TO_DATE = new MessageKey(
      "MESSAGE_BAI693_002");

  public static final MessageKey PARSING_EXCEPTION = new MessageKey("MESSAGE_BAI693_003");

  public static final MessageKey VALIDATION_EXCEPTION_ADMINISTRATION_ID_IS_NOT_NUMERIC = new MessageKey(
      "MESSAGE_BAI693_004");

  public static final MessageKey VALIDATION_EXCEPTION_INVALID_ADMINISTRATION_ID = new MessageKey("MESSAGE_BAI693_005");

  public static final MessageKey VALIDATION_EXCEPTION_IN_ADMINISTRATION_CREATE = new MessageKey("MESSAGE_BAI693_006");

  public static final MessageKey VALIDATION_EXCEPTION_IN_CREATE_ADMIN_BLANK_FACET_VALUE = new MessageKey(
      "MESSAGE_BAI693_007");

  public static final MessageKey VALIDATION_EXCEPTION_INVALID_ADMINISTRATION_ID_READ = new MessageKey(
      "MESSAGE_BAI693_008");

  public static final MessageKey UNEXPECTED_RESPONSE_CODE_FROM_MSEC = new MessageKey("MESSAGE_BAI693_009");

  public static final MessageKey ERROR_IN_CALLING_MSEC = new MessageKey("MESSAGE_BAI693_010");

  public static final MessageKey VALIDATION_EXCEPTION_IN_ADMINISTRATION_UDPATE = new MessageKey("MESSAGE_BAI693_011");

  public static final MessageKey VALIDATION_EXCEPTION_IN_ADMINISTRATION_UPDATE = new MessageKey("MESSAGE_BAI693_012");

  public static final MessageKey VALIDATION_EXCEPTION_IN_ADMIN_NO_UPDATE = new MessageKey("MESSAGE_BAI693_013");

  public static final MessageKey VALIDATION_EXCEPTION_IN_ADMIN_PRODUCTS_UPDATE_NOT_ALLOWED = new MessageKey(
      "MESSAGE_BAI693_014");

  public static final MessageKey VALIDATION_EXCEPTION_IN_ADMIN_ADDING_MANDATORY_TERM_NOT_ALLOWED = new MessageKey(
      "MESSAGE_BAI693_015");

  public static final MessageKey VALIDATION_EXCEPTION_IN_ADMIN_TERM_FACET_UPDATE_NOT_ALLOWED = new MessageKey(
      "MESSAGE_BAI693_016");

  public static final MessageKey VALIDATION_EXCEPTION_IN_ADMIN_OPTIONAL_TO_MANDATE_TERM_UPDATE_NOT_ALLOWED = new MessageKey(
      "MESSAGE_BAI693_017");

  public static final MessageKey VALIDATION_EXCEPTION_IN_ADMIN_TERM_REMOVAL_NOT_ALLOWED = new MessageKey(
      "MESSAGE_BAI693_018");

  public static final MessageKey INVALID_INPUT_PARAMETER_ERROR_IN_DELETE_ADMIN = new MessageKey("MESSAGE_BAI693_019");

  public static final MessageKey VALIDATION_EXCEPTION_IN_ADMIN_DELETE_ADMIN_NOT_ALLOWED = new MessageKey(
      "MESSAGE_BAI693_020");

}
