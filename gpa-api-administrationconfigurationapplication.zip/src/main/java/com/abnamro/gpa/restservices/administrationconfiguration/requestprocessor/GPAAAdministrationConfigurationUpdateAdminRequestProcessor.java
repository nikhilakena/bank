/**
 *
 */
package com.abnamro.gpa.restservices.administrationconfiguration.requestprocessor;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dtos.AdminTermView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.dtos.FacetView;
import com.abnamro.gpa.generic.administrationdao.dtos.ProductAdminMapView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationLogConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.constant.GPAAdministrationConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.administrationconfiguration.dtos.AdministrationConfigurationResultDTO;
import com.abnamro.gpa.restservices.administrationconfiguration.exception.GPAAdministrationApplicationException;
import com.abnamro.gpa.restservices.administrationconfiguration.helper.GPAAdministrationMapper;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This is the request Processor class for the Administration Configuration
 * Application. This has operations related to Update of Administration
 *
 *
 */
@Slf4j
@Component
public class GPAAAdministrationConfigurationUpdateAdminRequestProcessor {

  private GPAAdministrationMapper mapper = new GPAAdministrationMapper();

  @Autowired
  private GPAAdministrationDAO administrationdao;

  /**
   * This method is used to update a administration
   *
   * @param administrationRestResource
   *            is rest input for create administration
   * @return AdministrationConfigurationResultDTO is ResultDTO which contains
   *         indicator for success
   * @throws GPAAdministrationApplicationException
   *             is used to throw the DAO layer exception
   */
  public AdministrationConfigurationResultDTO updateAdministration(
      AdministrationRestResource administrationRestResource) throws GPAAdministrationApplicationException {
    final String LOG_METHOD = "updateAdministration():: ";
    AdministrationConfigurationResultDTO administrationConfigurationResultDTO = null;
    int administrationId = 0;
    try {
      AdministrationView administrationView = mapper
          .convertAdminRestResourceToAdminView(administrationRestResource);
      AdministrationView currentAdminView = administrationdao
          .readAdministration(administrationRestResource.getId(), 0);

      boolean agreementPresent = isAgreementPresentWithAdmin(administrationView);
      boolean adminGenericDataUpdated = isAdminGenericDataUpdated(administrationView, currentAdminView,
          agreementPresent);
      boolean termDataUpdated = isTermDataUpdated(administrationView, currentAdminView, agreementPresent);

      // If any of the generic details are updated or any term is updated
      // then call to DAO
      if (adminGenericDataUpdated || termDataUpdated) {
        administrationId = administrationdao.updateAdministration(administrationView, currentAdminView);
      } else {
        Messages messages = new Messages();
        messages.addMessage(
            new Message(
                GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_NO_UPDATE),
            MessageType.getError());
        throw new GPAAdministrationApplicationException(messages);
      }

      administrationConfigurationResultDTO = new AdministrationConfigurationResultDTO();
      administrationConfigurationResultDTO.setIdentifier(administrationId);
      administrationConfigurationResultDTO.setIndicatorSuccess(true);

    } catch (GPAAdministrationDAOException gpaAdministrationDAOException) {
      log.error("{} Exception occurred dao in update administration request processor={} | exception={} ", LOG_METHOD,
          GPAAdministrationConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_UPDATE_ADMINISTRATION_REQUEST_PROCESSOR,
          gpaAdministrationDAOException);
      throw new GPAAdministrationApplicationException(gpaAdministrationDAOException);
    }
    return administrationConfigurationResultDTO;

  }

  // this method will return list of products which contains agreement in GPA
  private List<Integer> retreiveProductsWithAgreement(AdministrationView administrationView,
      AdministrationView currentAdminView) throws GPAAdministrationDAOException {
    boolean agreeementPresent = false;

    List<Integer> inputProducts = new ArrayList<Integer>();
    List<Integer> currentProducts = new ArrayList<Integer>();
    List<Integer> productWithAgreement = new ArrayList<Integer>();

    for (ProductAdminMapView inputProduct : administrationView.getProductAdminMapViews()) {
      inputProducts.add(inputProduct.getProductId());
    }

    for (ProductAdminMapView currentProduct : currentAdminView.getProductAdminMapViews()) {
      currentProducts.add(currentProduct.getProductId());
    }

    for (Integer currentProdId : currentProducts) {
      agreeementPresent = administrationdao.retreiveAgreementCountForProduct(currentProdId);

      if (agreeementPresent) {
        //maintain list of products which has agreement in GPA
        productWithAgreement.add(currentProdId);
      }
    }

    return productWithAgreement;

  }

  private boolean isTermDataUpdated(AdministrationView administrationView, AdministrationView currentAdminView,
      boolean agreementPresent) throws GPAAdministrationApplicationException, GPAAdministrationDAOException {
    boolean flag = false;
    boolean optionalTermAdded = false;
    if (administrationView.getAdminTermViews() == null
        && currentAdminView.getAdminTermViews().size() > 0) {
      flag = true;
    }
    if (currentAdminView.getAdminTermViews().size() == 0
        && administrationView.getAdminTermViews() != null
        && !administrationView.getAdminTermViews().isEmpty()
        && administrationView.getAdminTermViews().size() > 0) {
      flag = true;
    }

    List<Integer> productWithAgreement = retreiveProductsWithAgreement(administrationView, currentAdminView);

    // if agreement present then only addition of optional term & updating Mandatory Term to optional is allowed.
    checkDataForAdminWithAgreemnt(agreementPresent, administrationView, currentAdminView, productWithAgreement);
    optionalTermAdded = checkOptionalTermsAddedForAdminWithAgreement(agreementPresent, administrationView,
        currentAdminView);

    // Even if updates are performed, but Administration has any agreement. No Facet data updates are allowed.
    flag = isTermIdUpdated(administrationView, currentAdminView, agreementPresent, productWithAgreement);
    // this check is needed. in case no updates are performed in existing terms but added a new optional term.
    if (optionalTermAdded) {
      flag = true;
    }

    return flag;
  }

  private boolean checkOptionalTermsAddedForAdminWithAgreement(boolean agreementPresent,
      AdministrationView administrationView, AdministrationView currentAdminView) {
    boolean flag = false;
    if (agreementPresent && isNewTermAdded(administrationView, currentAdminView)) {
      flag = iterateInputAndCurrentAdminData(administrationView, currentAdminView);

    }
    return flag;
  }

  private boolean iterateInputAndCurrentAdminData(AdministrationView administrationView,
      AdministrationView currentAdminView) {
    boolean flag = false;
    for (AdminTermView inputAdminTermView : administrationView.getAdminTermViews()) {
      boolean matchingFlag = false;
      for (AdminTermView currentAdminTermView : currentAdminView.getAdminTermViews()) {
        if (inputAdminTermView.getTermId() != currentAdminTermView.getTermId()
            && ("N").equalsIgnoreCase(inputAdminTermView.getMandatoryIndicator())) {

          matchingFlag = true;
          break;
        }
      }

      if (matchingFlag || (("N").equalsIgnoreCase(inputAdminTermView.getMandatoryIndicator())
          && currentAdminView.getAdminTermViews().size() == 0)) {
        flag = true;
      }
    }
    return flag;
  }

  private boolean isNewTermAdded(AdministrationView administrationView, AdministrationView currentAdminView) {
    boolean flag = false;
    List<Integer> inputTermIds = new ArrayList<>();
    List<Integer> currentTermIds = new ArrayList<>();

    if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
      for (AdminTermView currentTerm : administrationView.getAdminTermViews()) {
        inputTermIds.add(currentTerm.getTermId());
      }
    }
    if (currentAdminView.getAdminTermViews() != null && !currentAdminView.getAdminTermViews().isEmpty()) {
      for (AdminTermView inputTerm : currentAdminView.getAdminTermViews()) {
        currentTermIds.add(inputTerm.getTermId());
      }
    }

    if (inputTermIds.size() > currentTermIds.size()
        && inputTermIds.containsAll(currentTermIds)) {
      flag = true;
    }

    return flag;
  }

  private boolean isTermIdUpdated(AdministrationView administrationView, AdministrationView currentAdminView,
      boolean agreementPresent, List<Integer> productWithAgreement) throws GPAAdministrationApplicationException {
    boolean flag = false;
    List<Integer> inputTermIds = new ArrayList<>();
    List<Integer> currentTermIds = new ArrayList<>();

    if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
      for (AdminTermView currentTerm : administrationView.getAdminTermViews()) {
        inputTermIds.add(currentTerm.getTermId());
      }
    }

    if (currentAdminView.getAdminTermViews() != null && !currentAdminView.getAdminTermViews().isEmpty()) {
      for (AdminTermView inputTerm : currentAdminView.getAdminTermViews()) {
        currentTermIds.add(inputTerm.getTermId());
      }
    }

    flag = compareTermIds(inputTermIds, currentTermIds);
    if (!flag) {
      // in case of equal size of list of input term & current terms, it will validate facet data updates.
      flag = isTermFacetDataUpdated(administrationView, currentAdminView, agreementPresent, productWithAgreement);
    }
    return flag;
  }

  private boolean compareTermIds(List<Integer> inputTermIds, List<Integer> currentTermIds) {
    boolean flag = false;
    if (inputTermIds.size() == currentTermIds.size()
        && !inputTermIds.containsAll(currentTermIds)) {
      flag = true;
    }
    if (inputTermIds.size() != currentTermIds.size()) {
      flag = true;
    }
    return flag;
  }

  private void checkDataForAdminWithAgreemnt(boolean agreementPresent, AdministrationView administrationView,
      AdministrationView currentAdminView, List<Integer> productWithAgreement)
      throws GPAAdministrationApplicationException {

    List<Integer> inputTerms = new ArrayList<Integer>();
    List<Integer> currentTerms = new ArrayList<Integer>();

    if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
      for (AdminTermView adminTermView : administrationView.getAdminTermViews()) {
        inputTerms.add(adminTermView.getTermId());
      }
    }

    if (currentAdminView.getAdminTermViews() != null && !currentAdminView.getAdminTermViews().isEmpty()) {
      for (AdminTermView adminTermView : currentAdminView.getAdminTermViews()) {
        currentTerms.add(adminTermView.getTermId());
      }
    }

    validateAdminWithAgreement(agreementPresent, administrationView, currentAdminView, productWithAgreement, inputTerms,
        currentTerms);


  }

  private void validateAdminWithAgreement(boolean agreementPresent, AdministrationView administrationView,
      AdministrationView currentAdminView, List<Integer> productWithAgreement, List<Integer> inputTerms,
      List<Integer> currentTerms) throws GPAAdministrationApplicationException {
    if (agreementPresent
        && inputTerms.size() == currentTerms.size()
        && inputTerms.containsAll(currentTerms)) {
      // in that case, check whether optional Term is updated. Its not allowed. only mandatory to optional is allowed.
      if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
        opionalTermUpdatedToMandatory(administrationView, currentAdminView, productWithAgreement);
      }

    }
    if (agreementPresent
        && inputTerms.size() > currentTerms.size()
        && inputTerms.containsAll(currentTerms)) {
      // in that case, check whether mandatory term is added. Adding optional term is allowed.
      mandatoryTermAdded(administrationView, currentAdminView, productWithAgreement);
    }
    if (agreementPresent
        && inputTerms.size() < currentTerms.size()) {
      termRemovalNotAllowed(productWithAgreement);
    }

  }

  private void termRemovalNotAllowed(List<Integer> productWithAgreement) throws GPAAdministrationApplicationException {
    Messages messages = new Messages();
    Object[] objects = {productWithAgreement};
    messages.addMessage(
        new Message(
            GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_TERM_REMOVAL_NOT_ALLOWED,
            null, objects),
        MessageType.getError());
    throw new GPAAdministrationApplicationException(messages);

  }

  // this method is to check term facets data updates.
  private boolean isTermFacetDataUpdated(AdministrationView administrationView, AdministrationView currentAdminView,
      boolean agreementPresent, List<Integer> productWithAgreement) throws GPAAdministrationApplicationException {
    boolean flag = false;
    if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
      // iteration of all facet of terms
      flag = iterateTermData(administrationView, currentAdminView, agreementPresent, productWithAgreement);
    }
    return flag;

  }

  private boolean iterateTermData(AdministrationView administrationView, AdministrationView currentAdminView,
      boolean agreementPresent, List<Integer> productWithAgreement) throws GPAAdministrationApplicationException {
    boolean flag = false;
    for (AdminTermView inputTermData : administrationView.getAdminTermViews()) {
      flag = isTermValidated(inputTermData, currentAdminView, agreementPresent, productWithAgreement);
      if (flag) {
        break;
      }
    }
    return flag;

  }

  // This method will iterate all input terms & current terms.
  private boolean isTermValidated(AdminTermView inputTermData, AdministrationView currentAdminView,
      boolean agreementPresent, List<Integer> productWithAgreement) throws GPAAdministrationApplicationException {
    boolean flag = false;
    if (currentAdminView.getAdminTermViews() != null && !currentAdminView.getAdminTermViews().isEmpty()) {
      for (AdminTermView currentTermData : currentAdminView.getAdminTermViews()) {
        flag = isTermIdMatched(inputTermData, currentTermData, agreementPresent, productWithAgreement);
        if (flag) {
          break;
        }

      }
    }
    return flag;
  }

  private boolean isTermIdMatched(AdminTermView inputTermData, AdminTermView currentTermData, boolean agreementPresent,
      List<Integer> productWithAgreement) throws GPAAdministrationApplicationException {
    boolean flag = false;
    if (inputTermData.getTermId() == currentTermData.getTermId()) {
      flag = isMandatoryIndicatorUpdated(inputTermData, currentTermData, agreementPresent, productWithAgreement);
      if (!flag && inputTermData.getFacetView() != null && !inputTermData.getFacetView().isEmpty()) {
        flag = validateFacetViewData(inputTermData, currentTermData);
        if (flag && agreementPresent) {
          termFacetUpdatesNotAllowed(productWithAgreement);
        }
      }
    }
    return flag;
  }

  private boolean isMandatoryIndicatorUpdated(AdminTermView inputTermData, AdminTermView currentTermData,
      boolean agreementPresent, List<Integer> productWithAgreement) throws GPAAdministrationApplicationException {
    boolean flag = false;
    if (!inputTermData.getMandatoryIndicator().equalsIgnoreCase(currentTermData.getMandatoryIndicator())) {
      flag = true;
    }
    if (agreementPresent && "N".equalsIgnoreCase(currentTermData.getMandatoryIndicator())
        && "Y".equalsIgnoreCase(inputTermData.getMandatoryIndicator())) {
      termFacetUpdatesNotAllowed(productWithAgreement);
    }
    return flag;
  }

  private boolean validateFacetViewData(AdminTermView inputTermData, AdminTermView currentTermData) {
    boolean flag = false;
    if (inputTermData.getFacetView().size() != currentTermData.getFacetView().size()) {
      flag = true;
    } else {
      flag = compareFacetViewData(inputTermData, currentTermData);
    }
    return flag;
  }

  private boolean compareFacetViewData(AdminTermView inputTermData, AdminTermView currentTermData) {
    boolean flag = false;
    for (FacetView inputFacetView : inputTermData.getFacetView()) {
      for (FacetView currentFacetView : currentTermData.getFacetView()) {
        // facet type updates also to be checked before checking facet value
        if (inputFacetView.getType().trim().equalsIgnoreCase(currentFacetView.getType().trim())) {
          flag = isFacetViewValueUpdated(inputFacetView, currentFacetView);
        }
        if (flag) {
          break;
        }
      }
      break;
    }
    return flag;
  }

  private boolean isFacetViewValueUpdated(FacetView inputFacetView, FacetView currentFacetView) {
    boolean flag = false;
    if (inputFacetView.getType().trim().equalsIgnoreCase(currentFacetView.getType().trim())) {
      if (!inputFacetView.getValue().equals(currentFacetView.getValue())) {
        flag = true;
      }
    } else { // in case of facet type is updated this condition will be true
      flag = true;
    }
    return flag;
  }

  // This method will throw exception for term facet data updates not allowed.
  private void termFacetUpdatesNotAllowed(List<Integer> productWithAgreement)
      throws GPAAdministrationApplicationException {
    Object[] objects = {productWithAgreement};
    Messages messages = new Messages();
    messages.addMessage(
        new Message(
            GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_TERM_FACET_UPDATE_NOT_ALLOWED,
            null, objects),
        MessageType.getError());
    throw new GPAAdministrationApplicationException(messages);

  }

  // This method will throw an exception, If optional term is updated to mandatory term.
  private void opionalTermUpdatedToMandatory(AdministrationView administrationView,
      AdministrationView currentAdminView, List<Integer> productWithAgreement)
      throws GPAAdministrationApplicationException {

    for (AdminTermView inputAdminTermView : administrationView.getAdminTermViews()) {
      boolean matchingFlag = false;
      if (currentAdminView.getAdminTermViews() != null && !currentAdminView.getAdminTermViews().isEmpty()) {
        for (AdminTermView currentAdminTermView : currentAdminView.getAdminTermViews()) {
          if (inputAdminTermView.getTermId() == currentAdminTermView.getTermId()
              && ("N").equalsIgnoreCase(currentAdminTermView.getMandatoryIndicator())
              && ("Y").equalsIgnoreCase(inputAdminTermView.getMandatoryIndicator())) {

            matchingFlag = true;
            break;
          }
        }
      }

      if (matchingFlag) {
        Messages messages = new Messages();
        Object[] objects = {productWithAgreement};
        messages.addMessage(
            new Message(
                GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_OPTIONAL_TO_MANDATE_TERM_UPDATE_NOT_ALLOWED,
                null, objects),
            MessageType.getError());
        throw new GPAAdministrationApplicationException(messages);
      }
    }

  }

  // This method will throw exception if mandatory term is added in administration, where Admin has agreement.
  private void mandatoryTermAdded(AdministrationView administrationView, AdministrationView currentAdminView,
      List<Integer> productWithAgreement)
      throws GPAAdministrationApplicationException {

    for (AdminTermView inputAdminTermView : administrationView.getAdminTermViews()) {
      boolean matchingFlag = false;
      for (AdminTermView currentAdminTermView : currentAdminView.getAdminTermViews()) {
        if (inputAdminTermView.getTermId() == currentAdminTermView.getTermId()) {
          matchingFlag = true;
        }
      }

      if (!matchingFlag && ("Y").equalsIgnoreCase(inputAdminTermView.getMandatoryIndicator())) {
        Messages messages = new Messages();
        Object[] objects = {productWithAgreement};
        messages.addMessage(
            new Message(
                GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_ADDING_MANDATORY_TERM_NOT_ALLOWED,
                null, objects),
            MessageType.getError());
        throw new GPAAdministrationApplicationException(messages);
      }
    }

  }

  // if administration has agreement in GPA, this method will return true else false.
  private boolean isAgreementPresentWithAdmin(AdministrationView administrationView)
      throws GPAAdministrationApplicationException, GPAAdministrationDAOException {
    boolean agreementPresent = administrationdao.retreiveAgreementCountForAdmin(administrationView);
    return agreementPresent;
  }


  // this method will check generic data updates like Admin-name, description, OAR id.
  // after validating all these fields, it will check updates in list of product ids
  private boolean isAdminGenericDataUpdated(AdministrationView administrationView,
      AdministrationView currentAdminView, boolean agreementPresent)
      throws GPAAdministrationApplicationException, GPAAdministrationDAOException {
    boolean flag = true;
    if (administrationView.getName().trim().equalsIgnoreCase(currentAdminView.getName().trim())
        && administrationView.getDescription().trim().equalsIgnoreCase(currentAdminView.getDescription().trim())
        && administrationView.getOarId().trim().equalsIgnoreCase(currentAdminView.getOarId().trim())
        && !isProductListUpdated(administrationView, currentAdminView, agreementPresent)) {
      flag = false;
    }

    return flag;

  }

  // This method check input product list & current/latest product list from DB.
  private boolean isProductListUpdated(AdministrationView administrationView, AdministrationView currentAdminView,
      boolean agreementPresent) throws GPAAdministrationApplicationException, GPAAdministrationDAOException {
    boolean productListUpdated = false;
    List<Integer> inputProducts = new ArrayList<Integer>();
    List<Integer> currentProducts = new ArrayList<Integer>();

    if (administrationView.getProductAdminMapViews() != null
        && !administrationView.getProductAdminMapViews().isEmpty()
        && currentAdminView.getProductAdminMapViews() != null
        && !currentAdminView.getProductAdminMapViews().isEmpty()) {

      for (ProductAdminMapView productAdminMapView : administrationView.getProductAdminMapViews()) {
        inputProducts.add(productAdminMapView.getProductId());
      }

      for (ProductAdminMapView productAdminMapView : currentAdminView.getProductAdminMapViews()) {
        currentProducts.add(productAdminMapView.getProductId());
      }

      productListUpdated = setProductUpdatedFlag(inputProducts, currentProducts, agreementPresent);


    }

    return productListUpdated;

  }


  private boolean setProductUpdatedFlag(List<Integer> inputProducts, List<Integer> currentProducts,
      boolean agreementPresent) throws GPAAdministrationApplicationException, GPAAdministrationDAOException {
    boolean productListUpdated = false;
    // additional validation for administration which is attached to an
    // agreement.
    // in that case, Only Addition of product is allowed. else this methid will throw exception
    productListUpdated = validateProductUpdatesInAdminWithAgreement(inputProducts, currentProducts, agreementPresent);

    // this call is to verify updates in case no agreement present for
    // admin
    if (!agreementPresent && !productListUpdated) {
      productListUpdated = isProductUpdatedInAdminWithoutAgreement(inputProducts, currentProducts,
          agreementPresent);
    }

    return productListUpdated;
  }

  // Compare input product list & current product list.
  private boolean isProductUpdatedInAdminWithoutAgreement(List<Integer> inputProducts, List<Integer> currentProducts,
      boolean agreementPresent) {
    boolean productListUpdated = false;
    if (!agreementPresent) {
      if (inputProducts.size() == currentProducts.size()) {
        // check each product id in input & current data.
        productListUpdated = compareProductFromList(inputProducts, currentProducts);
      } else {
        productListUpdated = true;
      }
    }
    return productListUpdated;
  }

  // Any update in existing product list is not allowed , except adding new product in list.
  boolean validateProductUpdatesInAdminWithAgreement(List<Integer> inputProducts, List<Integer> currentProducts,
      boolean agreementPresent) throws GPAAdministrationApplicationException, GPAAdministrationDAOException {
    boolean productListUpdated = false;
    if (agreementPresent) {
      if (inputProducts.size() == currentProducts.size()
          && !inputProducts.containsAll(currentProducts)) {
        productListUpdated = true;
      }
      if (inputProducts.size() < currentProducts.size() || inputProducts.size() > currentProducts.size()) {
        // Check whether deleted product has any agreement or not.
        productListUpdated = true;
      }
      // check if product has any agreement
      retreiveAgreementCountForProduct(inputProducts, currentProducts);

    }
    return productListUpdated;

  }

  void retreiveAgreementCountForProduct(List<Integer> inputProducts, List<Integer> currentProducts)
      throws GPAAdministrationDAOException, GPAAdministrationApplicationException {
    int count = 0;
    List<Integer> productWithAgreement = new ArrayList<Integer>();
    boolean agreeementPresent = false;
    for (Integer currentProdId : currentProducts) {
      boolean matchingFlag = false;
      count++;
      for (Integer inputProdId : inputProducts) {
        if (currentProdId.equals(inputProdId)) {
          matchingFlag = true;
        }
      }
      if (!matchingFlag) {
        agreeementPresent = administrationdao.retreiveAgreementCountForProduct(currentProdId);
        if (agreeementPresent) {
          //maintain list of products which has agreement in GPA
          productWithAgreement.add(currentProdId);
        }
      }
    }

    if (count == currentProducts.size()) {
      checkAgreementCountForProduct(agreeementPresent, productWithAgreement);
    }

  }

  void checkAgreementCountForProduct(boolean agreeementPresent, List<Integer> productWithAgreement)
      throws GPAAdministrationApplicationException {
    if (agreeementPresent) {
      productDeletionNotAllowed(productWithAgreement);
    }

  }

  private void productDeletionNotAllowed(List<Integer> productWithAgreement)
      throws GPAAdministrationApplicationException {
    Object[] objects = {productWithAgreement};
    Messages messages = new Messages();
    messages.addMessage(
        new Message(
            GPAAdministrationConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_ADMIN_PRODUCTS_UPDATE_NOT_ALLOWED,
            null, objects),
        MessageType.getError());
    throw new GPAAdministrationApplicationException(messages);

  }

  // If current products are not present in input product list, it will return false.
  boolean compareProductFromList(List<Integer> inputProducts, List<Integer> currentProducts) {
    boolean flag = false;

    if (!inputProducts.containsAll(currentProducts)) {
      flag = true;
    }

    return flag;
  }
}
