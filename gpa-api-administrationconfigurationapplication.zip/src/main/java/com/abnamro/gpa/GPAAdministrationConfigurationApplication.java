package com.abnamro.gpa;

import java.util.TimeZone;
import jakarta.annotation.PostConstruct;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * This class is used to load the GPAAAdministrationConfiguration rest service classes
 */
@SpringBootApplication(scanBasePackages = "com.abnamro.gpa")
@MapperScan({"com.abnamro.gpa.generic.administrationdao.dao"})
public class GPAAdministrationConfigurationApplication extends SpringBootServletInitializer {

  /**
   * The entry point of application.
   *
   * @param args the input arguments
   */
  public static void main(String[] args) {
    SpringApplication.run(GPAAdministrationConfigurationApplication.class, args);
  }

  /**
   * Set the timezone to Europe/Amsterdam
   */
  @PostConstruct
  public void setTimeZoneToDutch() {
    TimeZone.setDefault(TimeZone.getTimeZone("Europe/Amsterdam"));
  }


}
