package com.abnamro.moa.restservices.agreementoverview.dao;

import java.util.List;

/**
 * This class contains all the attributes of Contract Header
 * @author C36098
 */
public class ContractHeaderView {
	private String chId;
	private String agreementId;
	private String status;
	private String nickname;
	private int productId;
	private int orderId;
	private String iBAN;
	private String parentCHId;
	private long customerId;
	private String blockingCode;
	private List<BuildingBlockReference> buildingBlockReferences;

	/**
	 * @return the ContractHeader ID
	 */
	public String getChId() {
		return chId;
	}
	/**
	 * @param chId ContractHeader ID to set
	 */
	public void setChId(String chId) {
		this.chId = chId;
	}
	/**
	 * @return the agreementId
	 */
	public String getAgreementId() {
		return agreementId;
	}
	/**
	 * @param agreementId the agreementId to set
	 */
	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the nickname
	 */
	public String getNickname() {
		return nickname;
	}
	/**
	 * @param nickname the nickname to set
	 */
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	/**
	 * @return the productId
	 */
	public int getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(int productId) {
		this.productId = productId;
	}
	/**
	 * @return the orderId
	 */
	public int getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the iBAN
	 */
	public String getIBAN() {
		return iBAN;
	}

	/**
	 * @param iBAN the iBAN to set
	 */
	public void setIBAN(String iBAN) {
		this.iBAN = iBAN;
	}
	public String getParentCHId() {
		return parentCHId;
	}
	public void setParentCHId(String parentCHId) {
		this.parentCHId = parentCHId;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getBlockingCode() {
		return blockingCode;
	}
	public void setBlockingCode(String blockingCode) {
		this.blockingCode = blockingCode;
	}

	public List<BuildingBlockReference> getBuildingBlockReferences() {
		return buildingBlockReferences;
	}

	public void setBuildingBlockReferences(List<BuildingBlockReference> references) {
		buildingBlockReferences = references;
	}
}
