package com.abnamro.moa.restservices.agreementoverview.dao;

/**
 * This class contains building block id and bbRefContract id.
 * @author PA2619
 */
public class BuildingBlockReference {
	private int bbId;
	private String bbRefContractId;

	public int getBbId() {
	return bbId;
	}

	public void setBbId(int bbId) {
	this.bbId = bbId;
	}

	public String getBbRefContractId() {
	return bbRefContractId;
	}

	public void setBbRefContractId(String bbRefContractId) {
	this.bbRefContractId = bbRefContractId;
	}
}