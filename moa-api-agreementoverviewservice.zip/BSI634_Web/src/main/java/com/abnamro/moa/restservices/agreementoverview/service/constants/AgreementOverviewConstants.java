package com.abnamro.moa.restservices.agreementoverview.service.constants;

/**
 * This class contains constants which are used in this application
 * @author C23597
 */
public final class AgreementOverviewConstants {
	private AgreementOverviewConstants() {}

	public static final String RESPONSE_STATUS_400 = "400";
	public static final String RESPONSE_STATUS_406 = "406";

	public static final String RESPONSE_STATUS_500 = "500";

	public static final String CODE_INTERNAL_ERROR = "INTERNAL_SERVER_ERROR";
	
	public static final String DESC_INTERNAL_ERROR = "Internal error occurred";
	
	public static final String MEDIA_TYPE = "application/json";

	public static final String INVALID_STATUS_IN_CONTRACT_HEADER = "INVALID_STATUS_IN_CONTRACT_HEADER";

	public static final String DESC_INVALID_STATUS_IN_CONTRACT_HEADER = "One or more commercial contract(s) have invalid status in contractheader.";
	
	public static final String STATUS_ACTIVE = "2";
	
	public static final String STATUS_INACTIVE = "3";
	
	public static final String AGREEMENT_IDS_INVALID_ERROR = "agreementIds.invalid";

	public static final String AGREEMENT_IDS_MISSING_ERROR = "agreementIds.missing";

	public static final String INPUT_AGREEMENT_IDS_MAX_SIZE_ERROR = "agreementIds.too_many";

	public static final String AGREEMENT_ID_NOT_PRESENT_ERROR = "agreementid.not_present";

	public static final String AGREEMENT_ID_INVALID_ERROR = "agreementid.invalid";

	/**
	 * The maximum number of agreement ids present in the input of the request.
	 */
	public static final int INPUT_AGREEMENT_IDS_MAX_SIZE = 100;

	public static final String REQUESTED_LANGUAGE_NOT_SUPPORTED = "acceptLanguage.not_supported";
	public static final String AGREEMENT_IDS_NOT_PRESENT = "agreementIds.not_present";
}
