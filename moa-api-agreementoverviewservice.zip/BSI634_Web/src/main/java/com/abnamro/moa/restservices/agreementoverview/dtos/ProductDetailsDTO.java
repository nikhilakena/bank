package com.abnamro.moa.restservices.agreementoverview.dtos;

import java.util.List;

import com.abnamro.nl.dto.util.AbstractDTO;

/**
 * This class contains attributes related to a Product information
 * @author C36098
 */
public class ProductDetailsDTO extends AbstractDTO {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	/**
	 * Identifier of the product according to the centrally managed ABNAMRO product list. 
	 */
	private String productId;
	
	/**
	 * Internal name of a product.ex. Toegangscontract
	 */
	private String productInternalName;
	/**
	 * External name of a product.ex. Overeenkomst Toegang
	 */
	private String productExternalName;
	/**
	 * Identifies the product groups in AAB.e.g.1. Pakketten - productGroupId is 92. 2. Betaalrekeningen - productGroupId is 93.
	 */
	private List<String> productGroupId;
	
	/**
	 * Identifier of the leading product group.ex. 93
	 */
	private String leadingProductGroupId;
	
	/**
	 * Internal name of the leading product group.ex. Rekening-Courant Krediet
	 */
	private String leadingProductGroupInternalName;
	
	/**
	 * External name of the leading product group.ex. Zakelijk
	 */
	private String leadingProductGroupExternalName;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductInternalName() {
		return productInternalName;
	}

	public void setProductInternalName(String productInternalName) {
		this.productInternalName = productInternalName;
	}

	public String getProductExternalName() {
		return productExternalName;
	}

	public void setProductExternalName(String productExternalName) {
		this.productExternalName = productExternalName;
	}

	public List<String> getProductGroupId() {
		return productGroupId;
	}

	public void setProductGroupId(List<String> productGroupId) {
		this.productGroupId = productGroupId;
	}

	public String getLeadingProductGroupId() {
		return leadingProductGroupId;
	}

	public void setLeadingProductGroupId(String leadingProductGroupId) {
		this.leadingProductGroupId = leadingProductGroupId;
	}

	public String getLeadingProductGroupInternalName() {
		return leadingProductGroupInternalName;
	}

	public void setLeadingProductGroupInternalName(String leadingProductGroupInternalName) {
		this.leadingProductGroupInternalName = leadingProductGroupInternalName;
	}

	public String getLeadingProductGroupExternalName() {
		return leadingProductGroupExternalName;
	}

	public void setLeadingProductGroupExternalName(String leadingProductGroupExternalName) {
		this.leadingProductGroupExternalName = leadingProductGroupExternalName;
	}

	
}
