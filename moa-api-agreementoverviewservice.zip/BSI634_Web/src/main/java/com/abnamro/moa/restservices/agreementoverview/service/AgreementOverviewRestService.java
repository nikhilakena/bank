package com.abnamro.moa.restservices.agreementoverview.service;

import com.abnamro.moa.restservices.agreementoverview.exceptions.AgreementOverviewApplicationException;
import com.abnamro.moa.restservices.agreementoverview.requestprocessor.AgreementOverviewRequestProcessor;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Agreement;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.AgreementSearchRequest;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Error;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Errors;
import com.abnamro.moa.restservices.agreementoverview.service.constants.AgreementOverviewConstants;
import com.abnamro.moa.restservices.agreementoverview.service.constants.AgreementOverviewLogConstants;
import com.abnamro.moa.restservices.agreementoverview.service.utils.AgreementOverviewValidatorUtils;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.logging.log4j2.interceptors.LogInterceptorBinding;
import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is rest service class for the AgreementOverview service.
 * @author C23597
 */
@LogInterceptorBinding
@Path("/")
public class AgreementOverviewRestService {
	private static LogHelper logHelper = new LogHelper(AgreementOverviewRestService.class);

	private AgreementOverviewRequestProcessor requestProcessor = new AgreementOverviewRequestProcessor();
	private AgreementOverviewValidatorUtils validator = new AgreementOverviewValidatorUtils();
	private com.abnamro.moa.restservices.agreementoverview.requestprocessorv2.AgreementOverviewRequestProcessor requestProcessorv2
			= new com.abnamro.moa.restservices.agreementoverview.requestprocessorv2.AgreementOverviewRequestProcessor();

	/**
	 * This method is used to retrieve the agreement overview for input
	 * agreement id's. 
	 * @param traceId
	 *            Unique end-2-end trace id received from the consumer
	 * @param request
	 *            DTO containing list of agreement Id's and list of administration key i.e. Msec keys 
	 * @return RetrieveAgreementOverviewOutput
	 * 			  populated list of agreements
	 */
	@POST
	@Path("/v1")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Response searchAgreementOverview(@HeaderParam("Trace-Id") String traceId, AgreementSearchRequest request) {
		Response response = null;

		final String logMethod = "searchAgreementOverview(HttpServletRequest, ServletContext, String, String, String, String[], String) :Response";

		try {

			// validate the agreement ids in the input
			validator.validateInput(request, traceId);

			// the map to store a list of erroneous agreement ids mapped by its error
			Map<String, List<String>> errorMap = new HashMap<>();
			errorMap.put(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR, new ArrayList<String>());
			errorMap.put(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR, new ArrayList<String>());

			List<String> agreementIds = request.getAgreementIds();
			List<String> validatedAgreementIds = validator.validateAgreementIds(agreementIds, errorMap);

			// the list to store the agreement objects to return in the response
			List<Agreement> agreements =  new ArrayList<>();

			// retrieve the information for each agreement id from the database
			// store the results in the list of agreements or in the collection of errors
			response = requestProcessor.searchAgreements(validatedAgreementIds, agreements, errorMap, traceId);
		} catch (AgreementOverviewApplicationException | ProductDetailsProviderException exception) {
			logHelper.error(logMethod, AgreementOverviewLogConstants.LOG_EXCEPTION_IN_AGREEMENTOVERVIEW, exception);
			Errors errors = new Errors();
			Error error = new Error();
			error.setCode(AgreementOverviewConstants.CODE_INTERNAL_ERROR);
			error.setMessage(AgreementOverviewConstants.DESC_INTERNAL_ERROR);
			error.setStatus(AgreementOverviewConstants.RESPONSE_STATUS_500);
			error.setTraceId(traceId);

			if (exception.getMessages() != null
					&& exception.getMessages().getMessages() != null) {
				List<String> params = new ArrayList<>();
				for (int i = 0; i < exception.getMessages().getMessages().size(); i++) {
					params.add(exception.getMessages().getMessages().get(i).getMessageKeyId());
				}
				error.setParams(params);
			}
			errors.addErrorsItem(error);

			throw new WebApplicationException(Response.status(Status.INTERNAL_SERVER_ERROR)
					.type(AgreementOverviewConstants.MEDIA_TYPE).entity(errors).build());
		}

		return response;
	}

	/**
	 * This method is used to retrieve the agreement overview version
	 * @return version v1
	 * provided from responseEntity
	 */
	@GET
	@Path("/v1/version")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response searchAgreementVersionV1() {
		Object responseEntity = "version v1; 1.0.68";
		return Response.status(Status.OK).entity(responseEntity).build();
	}

	/**
	 * This method is used to retrieve the agreement overview for input
	 * agreement id's.
	 * @param traceId - Unique end-2-end trace id received from the consumer
	 * @param preferredLanguage - Code that represents the preferred language of the returned values
	 * @param request - DTO containing list of agreement Id's and list of administration key i.e. Msec keys
	 * @return RetrieveAgreementOverviewOutput
	 * 			  populated list of agreements
	 */
	@POST
	@Path("/v2")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Response searchAgreementOverview(@HeaderParam("Trace-Id") String traceId, @HeaderParam("Accept-Language") String preferredLanguage
		, com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest request) {
		Response response = null;

		final String logMethod = "searchAgreementOverview(String, String, AgreementSearchRequest) :Response";

		try {

			// validate the agreement ids in the input
			validator.validateInput(request, traceId);

			// validate the requested language parameter
			String language = validator.validateLanguageInput(preferredLanguage, traceId);

			// the map to store a list of erroneous agreement ids mapped by its error
			Map<String, List<String>> errorMap = new HashMap<>();
			errorMap.put(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR, new ArrayList<String>());
			errorMap.put(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR, new ArrayList<String>());

			List<String> agreementIds = request.getAgreementIds();
			List<String> validatedAgreementIds = validator.validateAgreementIds(agreementIds, errorMap);

			// retrieve the information for each agreement id from the database
			// store the results in the list of agreements or in the collection of errors
			response = requestProcessorv2.searchAgreements(validatedAgreementIds, errorMap, language, traceId);
		} catch (AgreementOverviewApplicationException | ProductDetailsProviderException exception) {
			logHelper.error(logMethod, AgreementOverviewLogConstants.LOG_EXCEPTION_IN_AGREEMENTOVERVIEW, exception);
			Errors errors = new Errors();
			Error error = new Error();
			error.setCode(AgreementOverviewConstants.CODE_INTERNAL_ERROR);
			error.setMessage(AgreementOverviewConstants.DESC_INTERNAL_ERROR);
			error.setStatus(AgreementOverviewConstants.RESPONSE_STATUS_500);
			error.setTraceId(traceId);

			if (exception.getMessages() != null
				&& exception.getMessages().getMessages() != null) {
				List<String> params = new ArrayList<>();
				for (int i = 0; i < exception.getMessages().getMessages().size(); i++) {
					params.add(exception.getMessages().getMessages().get(i).getMessageKeyId());
				}
				error.setParams(params);
			}
			errors.addErrorsItem(error);

			throw new WebApplicationException(Response.status(Status.INTERNAL_SERVER_ERROR)
				.type(AgreementOverviewConstants.MEDIA_TYPE).entity(errors).build());
		}

		return response;
	}

	/**
	 * This method is used to retrieve the agreement overview version
	 * @return version v2
	 * provided from responseEntity
	 */
	@GET
	@Path("/v2/version")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response searchAgreementVersionV2() {
		Object responseEntity = "version v2; 2.0.6";
		return Response.status(Status.OK).entity(responseEntity).build();
	}
}
