package com.abnamro.moa.restservices.agreementoverview.dao;

import com.abnamro.moa.restservices.agreementoverview.exceptions.AgreementOverviewApplicationException;
import com.abnamro.moa.restservices.agreementoverview.service.constants.AgreementOverviewMessageKeyConstants;
import com.abnamro.nl.channels.jndilookup.JndiConstants;
import com.abnamro.nl.channels.jndilookup.JndiLookup;
import com.abnamro.nl.dao.util.AbstractDAO;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.dao.util.mybatis.MyBatisConfigException;
import com.abnamro.nl.dao.util.mybatis.MyBatisConnectionFactory;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.messages.Message;
import com.abnamro.nl.messages.MessageType;
import com.abnamro.nl.messages.Messages;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;

import java.sql.Connection;
import java.util.List;

/**
 * This is the DAO class for AgreementOverview and it extends AbstractDAO
 *
 * @author C36098
 */
public class AgreementOverviewDB2DAO extends AbstractDAO {
	private static LogHelper logHelper = new LogHelper(AgreementOverviewDB2DAO.class);

	private final String dbSchemaPrefix;
	private final String dataSourceName;
	private static final String CONFIG_FILE_PATH = "agreement-overview-mybatis-config.xml";
	private static MyBatisConnectionFactory connetionFactory;

	/**
	 * This is the default constructor
	 */
	public AgreementOverviewDB2DAO() {
		super();
		dbSchemaPrefix = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT)
			.getString(AgreementOverviewDAOConstants.SCHEMA_DATABASE, AgreementOverviewDAOConstants.DEFAULT_DB_SCHEMA);
		dataSourceName = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT)
			.getString(AgreementOverviewDAOConstants.DATASOURCE_NAME, AgreementOverviewDAOConstants.DEFAULT_DATASOURCE);
		if (connetionFactory == null) {
			setConnetionFactory(getConnectionFactoryInstance());
		}
	}

	private static synchronized void setConnetionFactory(MyBatisConnectionFactory myBatisConnectionFactory) {
		connetionFactory = myBatisConnectionFactory;
	}

	/**
	 * Parameterized constructor.
	 *
	 * @param dbSchemaPrefix    String  :prefix of db schema
	 * @param dataSourceName    String:  datasource name
	 * @param connectionFactory This constructor will only be used by the junit tests.
	 */
	public AgreementOverviewDB2DAO(String dbSchemaPrefix, String dataSourceName,
		MyBatisConnectionFactory connectionFactory) {
		this.dbSchemaPrefix = dbSchemaPrefix;
		this.dataSourceName = dataSourceName;
		setConnetionFactory(connectionFactory);
	}

	/**
	 * @return returns an instance of MyBatisConnectionFactory class
	 */
	private static synchronized MyBatisConnectionFactory getConnectionFactoryInstance() {
		final String logMethod = "getConnectionFactoryInstance():MyBatisConnectionFactory";

		try {
			// Creates new Instance for MyBatis Connection factory & loads the
			// Mybatis Configuration file
			return new MyBatisConnectionFactory(CONFIG_FILE_PATH);
		} catch (MyBatisConfigException e) {
			logHelper.error(logMethod, AgreementOverviewDAOLogConstants.LOG_ERROR_IBATIS_INITIALIZATION, e);
		}

		return null;
	}

	/**
	 * getDataSourceName - reads the data source name to be used by the DAO. Health-check will use this to check whether
	 * the connection is healthy or not.
	 *
	 * @return data source name
	 */
	@Override protected String getDataSourceName() {
		return dataSourceName;
	}

	/**
	 * Retrieve all contract headers from the database that contain one of the given argument ids in the list.
	 *
	 * @param agreementIds - the list of agreement ids that are to be searched for
	 * @return the list of persistent contract headers that match the given agreement ids
	 * @throws AgreementOverviewApplicationException in case an error occurred
	 */
	public List<ContractHeaderView> retrieveAgreementOverview(List<String> agreementIds)
		throws AgreementOverviewApplicationException {
		List<ContractHeaderView> agreementViewList = null;

		Connection connection = null;
		String logMethod = "retriveAgreementOverview";
		try {
			connection = DAODatabaseUtil.openConnection(getDataSourceName());
			SqlSession sqlSession = connetionFactory.getSession(connection);

			agreementViewList = sqlSession.getMapper(AgreementOverviewMybatisMapper.class)
				.retriveAgreementOverview(dbSchemaPrefix, agreementIds);
		} catch (MyBatisConfigException | PersistenceException exception) {
			Messages messages = new Messages();
			messages.addMessage(
				new Message(AgreementOverviewMessageKeyConstants.MYBATIS_EXCEPTION_WHILE_RETRIEVING_AGREEMENTS),
				MessageType.getError());
			logHelper.error(logMethod, AgreementOverviewDAOLogConstants.LOG_ERROR_DATA_CREATE, exception);
			throw new AgreementOverviewApplicationException(messages);
		} catch (DAODatabaseException daoDatabaseException) {
			Messages messages = new Messages();
			messages.addMessage(
				new Message(AgreementOverviewMessageKeyConstants.DATABASE_EXCEPTION_WHILE_RETRIEVING_AGREEMENTS),
				MessageType.getError());
			logHelper.error(logMethod, AgreementOverviewDAOLogConstants.LOG_ERROR_DB_CONNECTION, daoDatabaseException);
			throw new AgreementOverviewApplicationException(messages);
		} finally {
			DAODatabaseUtil.closeConnection(connection);
		}

		return agreementViewList;
	}
}
