package com.abnamro.moa.restservices.agreementoverview.exceptions;

import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Errors;
import com.abnamro.moa.restservices.agreementoverview.service.constants.AgreementOverviewConstants;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 * This class throws exception in case of any validation error occurs.
 * @author Pa2619
 */
@Provider
public class AgreementOverviewValidationExceptionMapper implements ExceptionMapper<Throwable> {

	@Override
	public Response toResponse(Throwable throwable) {
		return handleException(throwable);
	}

	private boolean isWebApplicationException(Throwable throwable) {
		return isObjectOfType(throwable, WebApplicationException.class);
	}

	private boolean isObjectOfType(Object obj, Class<?> clazz) {
		return clazz.isInstance(obj);
	}

	private Response handleException(Throwable throwable) {
		if (isWebApplicationException(throwable)) {
			return processWebApplicationException((WebApplicationException) throwable);
		}

		return Response.status(Response.Status.INTERNAL_SERVER_ERROR).type(AgreementOverviewConstants.MEDIA_TYPE).entity(null).build();
	}

	private Response processWebApplicationException(WebApplicationException webApplicationException) {
		Errors errors = (Errors)webApplicationException.getResponse().getEntity(); 
		return Response.status(webApplicationException.getResponse().getStatus()).type(AgreementOverviewConstants.MEDIA_TYPE).entity(errors).build();
	}

}
