package com.abnamro.moa.restservices.agreementoverview.service.utils;

import com.abnamro.moa.restservices.agreementoverview.application.ApplicationMessages;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.AgreementSearchRequest;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Error;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Errors;
import com.abnamro.moa.restservices.agreementoverview.service.constants.AgreementOverviewConstants;
import org.apache.commons.lang.StringUtils;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * This is validator class for retrieveAgreementOverview service operation.
 * @author C23597
 */
public class AgreementOverviewValidatorUtils {
	/**
	 * This method is used to throw an exception in case of validation errors
	 * @param code it is the error code to be returned
	 * @param message it is the error message to be returned
	 * @param traceId it is the unique id of the input request
	 * @param paramInfo additional parameters to be passed in case of exceptions
	 */
	public void handleValidationError(String code, String message, String traceId, List<String> paramInfo) {
		Errors errors = new Errors();
		Error error = new Error();
		error.setCode(code);
		error.setTraceId(traceId);
		error.setMessage(message);
		error.setStatus(AgreementOverviewConstants.RESPONSE_STATUS_400);
		error.setParams(paramInfo);
		errors.addErrorsItem(error);
		throw new WebApplicationException(Response.status(Status.BAD_REQUEST).type(AgreementOverviewConstants.MEDIA_TYPE).entity(errors).build());
	}

	/**
	 * Validate collection of agreement ids in the input.
	 * @param input - the object from the body of the request
	 * @param traceId - an end to end identification of a call
	 */
	public void validateInput(AgreementSearchRequest input, String traceId) {

		// check for presence of agreement ids in the input
		if (input == null || input.getAgreementIds() == null || input.getAgreementIds().isEmpty()) {
			String errorCode = ApplicationMessages.getErrorCode(AgreementOverviewConstants.AGREEMENT_IDS_MISSING_ERROR);
			String errorMessage = ApplicationMessages.getErrorMessage(AgreementOverviewConstants.AGREEMENT_IDS_MISSING_ERROR);
			handleValidationError(errorCode, errorMessage, traceId, null);

			// validate the size of the collection of agreement ids
		} else if (input.getAgreementIds().size() > AgreementOverviewConstants.INPUT_AGREEMENT_IDS_MAX_SIZE) {
			String errorCode = ApplicationMessages.getErrorCode(AgreementOverviewConstants.INPUT_AGREEMENT_IDS_MAX_SIZE_ERROR);
			String errorMessage = ApplicationMessages.getErrorMessage(AgreementOverviewConstants.INPUT_AGREEMENT_IDS_MAX_SIZE_ERROR);
			handleValidationError(errorCode, errorMessage, traceId, null);
		}
	}

	/**
	 * Validate each agreement id in the given list of agreement ids.
	 * @param agreementIds - all agreement ids to validate
	 * @param errorMap - invalid agreement ids mapped to the kind of error
	 * @return the list of valid agreement ids
	 */
	public List<String> validateAgreementIds(List<String> agreementIds, Map<String, List<String>> errorMap) {
		List<String> validAgreementIds = new ArrayList<>();

		for (String agreementId : agreementIds) {
			if (isValidAgreementId(agreementId)) {
				validAgreementIds.add(agreementId);
			} else {
				errorMap.get(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR).add(agreementId);
			}
		}

		return validAgreementIds;
	}

	/**
	 * Validate collection of agreement ids in the input.
	 * @param input - the object from the body of the request
	 * @param traceId - an end to end identification of a call
	 */
	public void validateInput(com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest input, String traceId) {

		// check for presence of agreement ids in the input
		if (input == null || input.getAgreementIds().isEmpty()) {
			String errorCode = ApplicationMessages.getErrorCode(AgreementOverviewConstants.AGREEMENT_IDS_MISSING_ERROR);
			String errorMessage = ApplicationMessages.getErrorMessage(AgreementOverviewConstants.AGREEMENT_IDS_MISSING_ERROR);
			handleValidationErrorV2(errorCode, errorMessage, traceId, null);

			// validate the size of the collection of agreement ids
		} else if (input.getAgreementIds().size() > AgreementOverviewConstants.INPUT_AGREEMENT_IDS_MAX_SIZE) {
			String errorCode = ApplicationMessages.getErrorCode(AgreementOverviewConstants.INPUT_AGREEMENT_IDS_MAX_SIZE_ERROR);
			String errorMessage = ApplicationMessages.getErrorMessage(AgreementOverviewConstants.INPUT_AGREEMENT_IDS_MAX_SIZE_ERROR);
			handleValidationErrorV2(errorCode, errorMessage, traceId, null);
		}
	}

	/**
	 * Validate the language code from the input. Supported values are 'NL' (Dutch) and 'EN' (English). The code 'NL' is the default value.
	 * @param languageCode - a 2 character code that represents a language
	 * @param traceId - an end to end identification of a call
	 * @return the validated language code
	 */
	public String validateLanguageInput(String languageCode, String traceId) {
		String validatedLanguageCode = "NL";

		if (languageCode != null) {
			if ("NL".equals(languageCode) || "EN".equals(languageCode)) {
				validatedLanguageCode = languageCode;
			} else {

				// the language code has an unsupported value, return error
				String errorCode = ApplicationMessages.getErrorCode(AgreementOverviewConstants.REQUESTED_LANGUAGE_NOT_SUPPORTED);
				String errorMessage = ApplicationMessages.getErrorMessage(AgreementOverviewConstants.REQUESTED_LANGUAGE_NOT_SUPPORTED);
				handleNotAcceptableError(errorCode, errorMessage, traceId, languageCode);
			}
		}

		return validatedLanguageCode;
	}

	/**
	 * Validate the given agreement id, return true if it is valid.
	 * @param agreementId - the agreement id to test
	 * @return true if valid
	 */
	boolean isValidAgreementId(String agreementId) {
		boolean isValid = false;

		if (StringUtils.isNotBlank(agreementId)) {
			if (agreementId.length() == 18) {
				isValid = agreementId.matches("NL\\d{2}ABNA\\d{10}");
			} else if (agreementId.length() <= 16) {
				isValid = true;
			}
		}

		return isValid;
	}

	/**
	 * This method is used to throw an exception in case of validation errors.
	 * @param code it is the error code to be returned
	 * @param message it is the error message to be returned
	 * @param traceId it is the unique id of the input request
	 * @param paramInfo additional parameters to be passed in case of exceptions
	 */
	public void handleValidationErrorV2(String code, String message, String traceId, List<String> paramInfo) {
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors errors = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors();
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error error = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error();
		error.setCode(code);
		error.setTraceId(traceId);
		error.setMessage(message);
		error.setStatus(AgreementOverviewConstants.RESPONSE_STATUS_400);
		error.setParams(paramInfo);
		errors.addErrorsItem(error);
		throw new WebApplicationException(Response.status(Status.BAD_REQUEST).type(AgreementOverviewConstants.MEDIA_TYPE).entity(errors).build());
	}

	/**
	 * This method is used to throw an exception in case of unacceptable value in the request.
	 * @param code - it is the error code to be returned
	 * @param message - it is the error message to be returned
	 * @param traceId - it is the unique id of the input request
	 * @param inputParameter - additional parameters to be passed in case of exceptions
	 */
	public void handleNotAcceptableError(String code, String message, String traceId, String inputParameter) {
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors errors = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors();
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error error = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error();
		error.setCode(code);
		error.setTraceId(traceId);
		error.setMessage(message);
		error.setStatus(AgreementOverviewConstants.RESPONSE_STATUS_406);
		error.addParamsItem(inputParameter);
		errors.addErrorsItem(error);

		throw new WebApplicationException(Response.status(Status.NOT_ACCEPTABLE).type(AgreementOverviewConstants.MEDIA_TYPE).entity(errors).build());
	}

	/**
	 * This method is used to throw an exception in case of an internal server error.
	 * @param traceId - it is the unique id of the input request
	 */
	public void handleInternalServerError(String traceId) {
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors errors = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors();
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error error = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error();
		error.setCode(AgreementOverviewConstants.CODE_INTERNAL_ERROR);
		error.setMessage(AgreementOverviewConstants.DESC_INTERNAL_ERROR);
		error.setTraceId(traceId);
		error.setStatus(AgreementOverviewConstants.RESPONSE_STATUS_500);
		errors.addErrorsItem(error);

		throw new WebApplicationException(Response.status(Status.INTERNAL_SERVER_ERROR).type(AgreementOverviewConstants.MEDIA_TYPE).entity(errors).build());
	}
}
