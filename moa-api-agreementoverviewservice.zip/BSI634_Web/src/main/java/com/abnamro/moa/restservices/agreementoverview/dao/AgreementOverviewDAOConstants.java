package com.abnamro.moa.restservices.agreementoverview.dao;

/**
 * This is used to store constants DAO layer of FAQ service.
 * @author TCS
 */
public final class AgreementOverviewDAOConstants {
	private AgreementOverviewDAOConstants() {
	}

	public static final String SCHEMA_DATABASE = "SCHEMA_MOA";
	public static final String DEFAULT_DB_SCHEMA = "UU01";

	public static final String DATASOURCE_NAME = "MOADATASOURCE";
	public static final String DEFAULT_DATASOURCE = "jdbc/MOA_DataSource";
}
