package com.abnamro.moa.restservices.agreementoverview.dao;

import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * This class is the mapper class for AgreementOverviewDAO with the database
 * @author C36098
 */
public interface AgreementOverviewMybatisMapper {


	/**
	 * This method retrieve count of the entries for input consumerId, operation and version.
	 * 
	 * 
	 * @param schemaName String value for schemaName of database
	 * @param consumerId unique value for consumer application calling the API
	 * @param operation name of the operation
	 * @param version of the operation
	 * @return count of entries
	 */
	public int isAuthorizedConsumer(@Param("schemaName") final String schemaName,@Param("consumerId") final String consumerId, 
		@Param("operation") final  String operation, @Param("version") final  String version);

	/**
	 * This method updates last date used
	 * 
	 * @param schemaName String value for schemaName of database
	 * @param consumerId unique value for consumer application calling the API
	 * @param operation name of the operation
	 * @param version of the operation
	 */
	public void updateLastDateUsed(@Param("schemaName") final String schemaName,@Param("consumerId") final String consumerId, 
		@Param("operation") final  String operation, @Param("version") final  String version);

	/**
	 * This method retrieves all ContractHeader details from table
	 * 
	 * @param schemaName String value for schemaName of database
	 * @param agreements list of agreements
	 * @return List of ContractHeaderView list of contract headers 
	 */
	public List<ContractHeaderView> retriveAgreementOverview(@Param("schemaName") final String schemaName, @Param("agreements") final  List<String> agreements);

}
