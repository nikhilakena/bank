package com.abnamro.moa.restservices.agreementoverview.service.constants;

import com.abnamro.nl.messages.MessageKey;

/**
 * This class contains Message Key constants used for Agreement overview
 *
 * @author C36098
 */
public final class AgreementOverviewMessageKeyConstants {
	private AgreementOverviewMessageKeyConstants() {
	}

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_READING_PRODUCT_GROUP_DETAILS =
		new MessageKey("MESSAGE_BSxxx_001");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_READING_PRODUCT_GROUP_DETAILS =
		new MessageKey("MESSAGE_BSxxx_002");

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_READING_PRODUCT_NAME_DETAILS =
		new MessageKey("MESSAGE_BSxxx_003");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_READING_PRODUCT_NAME_DETAILS =
		new MessageKey("MESSAGE_BSxxx_004");

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVING_AGREEMENTS = new MessageKey("MESSAGE_BSxxx_005");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVING_AGREEMENTS = new MessageKey("MESSAGE_BSxxx_006");

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION =
		new MessageKey("MESSAGE_BSxxx_007");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION =
		new MessageKey("MESSAGE_BSxxx_008");
}
