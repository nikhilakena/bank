package com.abnamro.moa.restservices.agreementoverview.requestprocessor;

import com.abnamro.moa.restservices.agreementoverview.application.ApplicationMessages;
import com.abnamro.moa.restservices.agreementoverview.cachehandler.CacheCollector;
import com.abnamro.moa.restservices.agreementoverview.dao.AgreementOverviewDB2DAO;
import com.abnamro.moa.restservices.agreementoverview.dao.BuildingBlockReference;
import com.abnamro.moa.restservices.agreementoverview.dao.ContractHeaderView;
import com.abnamro.moa.restservices.agreementoverview.exceptions.AgreementOverviewApplicationException;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Error;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.*;
import com.abnamro.moa.restservices.agreementoverview.service.constants.AgreementOverviewConstants;
import com.abnamro.moa.restservices.agreementoverview.service.utils.AgreementOverviewValidatorUtils;
import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsView;
import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;
import com.abnamro.moa.restservices.agreementoverview.dao.ProductDetailsEnricher;
import org.apache.commons.lang.StringUtils;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class is request processor class for the RetrieveAgreementOverview service operation
 * @author C23597
 */
public class AgreementOverviewRequestProcessor {
	private AgreementOverviewDB2DAO agreementOverviewDB2DAO = new AgreementOverviewDB2DAO();

	private AgreementOverviewValidatorUtils validator = new AgreementOverviewValidatorUtils();

	private ProductDetailsEnricher productDetailsEnricher = new ProductDetailsEnricher();

	/**
	 * Search for information for the given agreement ids and return it in the list of agreements.
	 * Agreement ids that cannot be found will be stored in the map of errors.
	 * @param agreementIds - the list of agreement ids to search for
	 * @param agreements - the agreement information that is retrieved
	 * @param errors - the mappings to errors and its specific agreement id
	 * @param traceId - Unique end-2-end trace id received from the consumer
	 * @return the response to be returned
	 * @throws AgreementOverviewApplicationException in case of error with the database
	 * @throws ProductDetailsProviderException in case of error with the product cache
	 */
	public Response searchAgreements(List<String> agreementIds, List<Agreement> agreements, Map<String, List<String>> errors, String traceId)
			throws AgreementOverviewApplicationException, ProductDetailsProviderException {
		Response response = null;

		// fill the cache of products
		loadProductCache();

		if (!agreementIds.isEmpty()) {

			// convert the agreement ids that are an IBAN to BBAN
			Map<String, String> bbanIbanMap = mapBbanToIban(agreementIds);

			List<String> bbanAgreementIdsList = new ArrayList<>(bbanIbanMap.keySet());
			List<ContractHeaderView> persistentContractHeaders = agreementOverviewDB2DAO.retrieveAgreementOverview(bbanAgreementIdsList);

			// determine the agreement ids that do and does not exist in database
			List<String> existingBbanAgreementIds = separateExistingAgreementIds(bbanIbanMap, persistentContractHeaders, errors);

			// if none of the agreement ids is found return 400 with a general error, otherwise add validation errors for these agreement id(s)
			if (existingBbanAgreementIds.isEmpty()) {
				Errors responseErrors = createResponseErrors(errors, traceId);
				response = Response.status(Status.BAD_REQUEST).entity(responseErrors).build();
			} else {
				AgreementList responseAgreements = createSuccesfulResponse(agreementIds, bbanIbanMap, existingBbanAgreementIds, errors, persistentContractHeaders, traceId);
				response = Response.status(Status.OK).entity(responseAgreements).build();
			}
		} else {
			Errors responseErrors = createResponseErrors(errors, traceId);
			response = Response.status(Status.BAD_REQUEST).entity(responseErrors).build();
		}

		return response;
	}

	/**
	 * Check if the agreement ids from the input can be found in the database. If so, add the agreement id to a list to return.
	 * If not, add the agreement to the list of errors.
	 * @param bbanIbanMapping - mapping of agreement id from the input and its bban format
	 * @param persistentContractHeaders - the persistent contract headers for the agreement ids from the input
	 * @param errors - the agreement ids that can not be found in the database
	 * @return the list of agreement ids that exist in the database
	 */
	List<String> separateExistingAgreementIds(Map<String, String> bbanIbanMapping, List<ContractHeaderView> persistentContractHeaders, Map<String, List<String>> errors) {
		List<String> existingBbanAgreementIds = new ArrayList<>();

		// add the agreement id of each contract header in the database to the list of existing agreement ids
		if (persistentContractHeaders != null) {
			for (ContractHeaderView contractHeader : persistentContractHeaders) {
				if (bbanIbanMapping.containsKey(contractHeader.getAgreementId().trim())) {
					existingBbanAgreementIds.add(contractHeader.getAgreementId().trim());
				}
			}
		}

		// check which agreement ids are not found in the database and add the agreement id from the input to the list of errors
		for (Map.Entry<String, String> mapping : bbanIbanMapping.entrySet()) {
			if (!existingBbanAgreementIds.contains(mapping.getKey())) {
				String agreementIdInput = mapping.getValue();
				errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).add(agreementIdInput);
			}
		}

		return existingBbanAgreementIds;
	}

	/**
	 * Create an Error object to return in the response from the list of encountered errors.
	 * @param errorsMap - mapping of errors with the corresponding agreement ids
	 * @param traceId - Unique end-2-end trace id received from the consumer
	 * @return the Error object to add to the response
	 */
	Errors createResponseErrors(Map<String, List<String>> errorsMap, String traceId) {
		Errors errors = new Errors();

		for (Map.Entry<String, List<String>> errorEntry : errorsMap.entrySet()) {

			List<String> parameters = errorEntry.getValue();
			if (parameters != null && !parameters.isEmpty()) {

				// this specific error has occurred, add it to the response
				Error error = new Error();
				error.setStatus(AgreementOverviewConstants.RESPONSE_STATUS_400);
				String genericErrorKey = convertSingleAgreementErrorKeyToGenericErrorKey(errorEntry.getKey());
				error.setCode(ApplicationMessages.getErrorCode(genericErrorKey));
				error.setMessage(ApplicationMessages.getErrorMessage(genericErrorKey));
				error.setTraceId(traceId);

				// add the errorneous agreement ids to the list of parameters
				for (String parameter : parameters) {
					error.addParamsItem(parameter);
				}

				errors.addErrorsItem(error);
			}
		}

		return errors;
	}

	/**
	 * Create a response to return a successful operation.
	 * @param agreementIds - the list of agreements that come from the request
	 * @param bbanIbanMap - the mapping of agreement ids in the database and agreement ids from the request
	 * @param existingBbanAgreementIds - the list of agreement ids that are present in the database
	 * @param errors - the mapping of possible errors and the list of agreements that caused this error
	 * @param persistentContractHeaders - the list of contract headers in the database that have an agreement id from the request
	 * @param traceId - Unique end-2-end trace id received from the consumer
	 * @return the body of the response
	 */
	AgreementList createSuccesfulResponse(List<String> agreementIds, Map<String, String> bbanIbanMap,
			List<String> existingBbanAgreementIds, Map<String, List<String>> errors, List<ContractHeaderView> persistentContractHeaders, String traceId) {
		AgreementList output = new AgreementList();

		// add the agreement details in the order of input to the response
		for (String agreementId : agreementIds) {

			// find the agreement id in BBAN for the agreement id in IBAN from the input
			String bbanAgreementId = findBbanAgreement(bbanIbanMap, agreementId);

			// find the persistent contract header with the agreement id
			List<ContractHeaderView> contractHeaders = findContractHeaders(persistentContractHeaders, bbanAgreementId);

			// assemble the Agreement object for the output
			for (ContractHeaderView contractHeader : contractHeaders) {
				Agreement responseAgreement = createAgreement(contractHeader, traceId);
				output.addAgreementsItem(responseAgreement);
			}
		}

		// add the validation errors to the response
		for (Map.Entry<String, List<String>> errorMapping : errors.entrySet()) {
			if (!errorMapping.getValue().isEmpty()) {
				ValidationMessage validationMessage = createValidationMessage(errorMapping.getKey(), errorMapping.getValue());
				output.addMessagesItem(validationMessage);
			}
		}

		return output;
	}

	/**
	 * Find the agreement id in IBAN format in the values of the map and return the key that is the agreement id in BBAN format.
	 * @param bbanIbanMap - the map of agreement id in BBAN and IBAN format
	 * @param ibanAgreementId - the agreement id in IBAN format that is to be found
	 * @return the agreement id in BBAN format
	 */
	String findBbanAgreement(Map<String, String> bbanIbanMap, String ibanAgreementId) {
		String bbanAgreementId = null;

		if (bbanIbanMap != null && bbanIbanMap.containsValue(ibanAgreementId)) {
			for (Map.Entry<String, String> entry : bbanIbanMap.entrySet()) {
				if (ibanAgreementId.equals(entry.getValue())) {
					bbanAgreementId = entry.getKey();

					break;
				}
			}
		}

		return bbanAgreementId;
	}

	/**
	 * Find the contract headers with the given agreement id within the given list of contract headers and return it.
	 * @param persistentContractHeaders - the list of contract headers to search for the contract header with the given agreement id
	 * @param agreementId - the agreement id of the contract headers that is searched for
	 * @return the found contract headers
	 */
	List<ContractHeaderView> findContractHeaders(List<ContractHeaderView> persistentContractHeaders, String agreementId) {
		List<ContractHeaderView> foundContractHeaders = new ArrayList<>();

		if (persistentContractHeaders != null && !persistentContractHeaders.isEmpty() && agreementId != null) {
			for (ContractHeaderView contractHeaderItem : persistentContractHeaders) {
				if (contractHeaderItem.getAgreementId().trim().equals(agreementId)) {
					foundContractHeaders.add(contractHeaderItem);
				}
			}
		}

		return foundContractHeaders;
	}

	/**
	 * Create an agreement object for in the response, fill it with the details from the persistent contract header and return it.
	 * @param contractHeader - the persistent contract header that contains the details for the agreement object
	 * @return the agreement object for in the response
	 */
	Agreement createAgreement(ContractHeaderView contractHeader, String traceId) {
		Agreement agreement = new Agreement();

		// set the agreement id value
		populateIBANForAgreement(contractHeader, agreement);

		agreement.setAgreementAdministrationKeys(getMsecKeys(contractHeader.getBuildingBlockReferences()));

		if (StringUtils.isNotBlank(contractHeader.getNickname())) {
			agreement.setNickName(contractHeader.getNickname().trim());
		}

		if (contractHeader.getCustomerId() > 0) {
			String customerIdText = StringUtils.leftPad(String.valueOf(contractHeader.getCustomerId()), 12, '0');
			agreement.setAgreementPartyClusterId(Long.parseLong(customerIdText));
		}

		if (StringUtils.isNotBlank(contractHeader.getBlockingCode())
				&& "1".equals(contractHeader.getBlockingCode().trim())) {
			agreement.setBlockedStatus(Agreement.BlockedStatusEnum.BLOCKED);
		} else {
			agreement.setBlockedStatus(Agreement.BlockedStatusEnum.UNBLOCKED);
		}

		if (StringUtils.isNotBlank(contractHeader.getParentCHId())) {
			agreement.setParentAgreementCustomerReferenceId(contractHeader.getParentCHId().trim());
		}

		setAgreementStatus(contractHeader.getStatus(), traceId, agreement);

        ProductDetailsView product = CacheCollector.getProductCache().get(contractHeader.getProductId());

		return addProductDetailsToAgreement(agreement, product);
	}

	/**
	 * Create a validation message according to the given details. The validation message will be returned in the response.
	 * @param errorCode - the code of the error
	 * @param agreementIds - the agreement ids where the error applicable
	 * @return the validation message object
	 */
	ValidationMessage createValidationMessage(String errorCode, List<String> agreementIds) {
		ValidationMessage message = new ValidationMessage();

		message.setCode(ApplicationMessages.getErrorCode(errorCode));
		message.setText(ApplicationMessages.getErrorMessage(errorCode));

		if (agreementIds != null && !agreementIds.isEmpty()) {
			message.setParams(agreementIds);
		}

		return message;
	}

	/**
	 * Convert each agreement id from the list to BBAN format and store it in the map.
	 * @param agreementIds - the list of agreement ids that can be in IBAN format
	 * @return the mapping of original format of agreement id and its BBAN format
	 */
	Map<String, String> mapBbanToIban(List<String> agreementIds) {
		Map<String, String> mapping = new HashMap<>();

		for (String agreementId : agreementIds) {
			if (agreementId.length() == 18) {

				// agreement id is in IBAN format, convert it to BBAN format and store it
				mapping.put(agreementId.substring(8), agreementId);
			} else {

				// agreement id is in BBAN format, store it
				mapping.put(agreementId, agreementId);
			}
		}

		return mapping;
	}

    /**
     * Copy the details from the product to the agreement that is to be written into the response.
     * @param agreement - contains the details from the agreement
     * @param product - contains the details from the product
     * @return the agreement that contains both the details from the agreement and the product
     */
	private Agreement addProductDetailsToAgreement(Agreement agreement, ProductDetailsView product) {
	    if (product != null) {
            agreement.setProductId(product.getProductId());

	        if (StringUtils.isNotBlank(product.getInternalName())) {
	            agreement.setInternalProductNameNL(product.getInternalName().trim());
            }

	        if (StringUtils.isNotBlank(product.getExternalName())) {
	            agreement.setCommercialProductNameNL(product.getExternalName().trim());
            }

            List<Integer> productGroupIds = new ArrayList<>();
            if (product.getProductGroupList() != null) {
                for (Integer productGroupId : product.getProductGroupList()) {
                    productGroupIds.add(productGroupId);
                }
                agreement.setProductGroupIds(productGroupIds);
            }
        }

        return  agreement;
    }

	void populateIBANForAgreement(ContractHeaderView contractHeaderView, Agreement contractHeader) {
		if (StringUtils.isNotBlank(contractHeaderView.getAgreementId())) {
			if (CacheCollector.getProductCache().get(contractHeaderView.getProductId()).isIbanIndicator() && contractHeaderView.getAgreementId().trim().length() <= 12) {
				String agreementId = (contractHeaderView.getAgreementId().trim().length() > 10) ? contractHeaderView.getAgreementId().trim().substring(0, 10) : contractHeaderView.getAgreementId().trim();
				contractHeader.setAgreementId(convertToIBAN(agreementId));
			} else {
				contractHeader.setAgreementId(contractHeaderView.getAgreementId().trim());
			}
		}
	}

	/**
	 * Load the product cache if it is empty.
	 */
	private void loadProductCache() throws AgreementOverviewApplicationException, ProductDetailsProviderException {
		if (CacheCollector.getProductCache() == null) {
			Map<Integer, ProductDetailsView> productHashMap = productDetailsEnricher.getProductDetailsForCaching();
			CacheCollector.setProductCache(productHashMap);
		}
	}

	/**
	 * Convert the error on a single agreement to its error that counts for the complete collection.
	 * @param agreementErrorKey - error key for a single agreement id
	 * @return the error key for a collection of errors for the given specific error
	 */
	private String convertSingleAgreementErrorKeyToGenericErrorKey(String agreementErrorKey) {
		String genericErrorKey = "";

		if (AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR.equals(agreementErrorKey)) {
			genericErrorKey = AgreementOverviewConstants.AGREEMENT_IDS_MISSING_ERROR;
		} else if(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR.equals(agreementErrorKey)) {
			genericErrorKey = AgreementOverviewConstants.AGREEMENT_IDS_INVALID_ERROR;
		}

		return genericErrorKey;
	}

	private void setAgreementStatus(String status, String traceId, Agreement contractHeader) {
		boolean invalidStatus = true;
		if (StringUtils.isNotBlank(status)) {
			if (AgreementOverviewConstants.STATUS_ACTIVE.equals(status.trim())) {
				contractHeader.setLifecycleStatus(Agreement.LifecycleStatusEnum.ACTIVE);
				invalidStatus = false;
			} else if (AgreementOverviewConstants.STATUS_INACTIVE.equals(status.trim())) {
				invalidStatus = false;
				contractHeader.setLifecycleStatus(Agreement.LifecycleStatusEnum.INACTIVE);
			}
		}
		if (invalidStatus) {
			validator.handleValidationError(AgreementOverviewConstants.INVALID_STATUS_IN_CONTRACT_HEADER,
					AgreementOverviewConstants.DESC_INVALID_STATUS_IN_CONTRACT_HEADER, traceId, null);
		}
	}

	/**
	 * Create a msec key for each building block reference in the list and return it.
	 * @param buildingBlockReferences - the list of building block references to create the list of msec keys for
	 * @return the list of msec keys
	 */
	private List<String> getMsecKeys(List<BuildingBlockReference> buildingBlockReferences) {
		List<String> msecKeys = new ArrayList<>();

		if (buildingBlockReferences != null) {
			for (BuildingBlockReference reference : buildingBlockReferences) {
				if (StringUtils.isNotBlank(reference.getBbRefContractId())) {
					msecKeys.add(reference.getBbId() + "_" + reference.getBbRefContractId().trim());
				}
			}
		}

		return msecKeys;
	}

	/**
	 * This returns the IBAN number for input BBAN number using standard algorithm
	 *
	 * @param agreementId BBAN number
	 * @return IBAN number
	 */
	private String convertToIBAN(String agreementId) {
		String iban = "";
		String abna = "10112310";
		String nl = "2321";
		String temp = abna + agreementId + nl + "00";
		String temp9 = "";
		int rem = 0;
		String remString;
		int finalCheckDigit;
		String finalCheckDigitString;

		temp9 = temp.substring(0, 9);
		rem = Integer.valueOf(temp9) % 97;
		remString = convertTheReminder(rem);

		temp9 = remString + temp.substring(9, 16);
		rem = Integer.valueOf(temp9) % 97;
		remString = convertTheReminder(rem);

		temp9 = remString + temp.substring(16, 23);
		rem = Integer.valueOf(temp9) % 97;
		remString = convertTheReminder(rem);

		temp9 = "000000" + remString + "0";
		rem = Integer.valueOf(temp9) % 97;
		finalCheckDigit = 98 - rem;
		finalCheckDigitString = convertTheReminder(finalCheckDigit);

		iban = "NL" + finalCheckDigitString + "ABNA" + agreementId;

		return iban;
	}

	private String convertTheReminder(int rem) {
		String remString;

		if (rem < 10) {
			remString = "0" + rem;
		} else {
			remString = String.valueOf(rem);
		}

		return remString;
	}
}
