package com.abnamro.moa.restservices.agreementoverview.exceptions;

import com.abnamro.nl.exceptions.AABException;
import com.abnamro.nl.exceptions.BusinessApplicationException;
import com.abnamro.nl.messages.Messages;

/**
 * This class throws exception in case of any
 * error occurring for AgreementOverviewApplication
 * @author C36098
 */
public class AgreementOverviewApplicationException extends BusinessApplicationException{
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
  /**
   * Default constructor
   */
  public AgreementOverviewApplicationException(){
      super();
  }
  /**
   * Constructor that will also set messages on the exception. 
   * @param messages holds the message string on occurrence of corresponding exception
   */
  public AgreementOverviewApplicationException(Messages messages) {
      super(messages);
  }

  /**
   * Constructor that takes an existing AABException. This will move any
   * messages into the new exception.
   * @param aabException on occurrence of any AABException
   */
  public AgreementOverviewApplicationException(AABException aabException) {
      super(aabException);
  }
}
