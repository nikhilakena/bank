package com.abnamro.moa.restservices.agreementoverview.cachehandler;

import com.abnamro.nl.exceptions.AABException;
import com.abnamro.nl.exceptions.BusinessServiceException;
import com.abnamro.nl.messages.Messages;

/**
 * This is an exception needs to be thrown to the calling application in case of exception thrown.
 * @author PA2619
 *
 */
public class CacheHandlerException extends BusinessServiceException{
	/**
	 * Serial version UID for this serializable class
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Default Constructor
	 */
	public CacheHandlerException() {
		super();
	}

	/** This constructor sets the AABException
	 * @param aabException the aabException to set
	 */
	public CacheHandlerException(AABException aabException) {
		super(aabException);
	}

	
	/** This constructor sets associated Messages 
	 * @param messages the messages to set
	 */
	public CacheHandlerException(Messages messages) {
		super(messages);
	}

}
