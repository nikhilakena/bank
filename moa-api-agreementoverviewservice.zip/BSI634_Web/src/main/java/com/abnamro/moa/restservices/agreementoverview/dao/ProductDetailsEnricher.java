package com.abnamro.moa.restservices.agreementoverview.dao;

import com.abnamro.moa.restservices.agreementoverview.exceptions.AgreementOverviewApplicationException;
import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsDB2DAO;
import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsView;
import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class modifies the product details for the retrieve agreements overview operation
 * @author C23597
 */
public class ProductDetailsEnricher {
	private ProductDetailsDB2DAO productDetailsDB2DAO = new ProductDetailsDB2DAO();

	/**
	 * This method retrieves the product details from dao layer then it populate the order and IBAN indicator for it.
	 *
	 * @return hashmap of product id as key and Product details as value
	 * @throws AgreementOverviewApplicationException in case of errors
	 * @throws ProductDetailsProviderException       in case of exception in ProductDetailsProvider
	 */
	public Map<Integer, ProductDetailsView> getProductDetailsForCaching()
		throws AgreementOverviewApplicationException, ProductDetailsProviderException {

		List<ProductDetailsView> productDetailsView = productDetailsDB2DAO.readProductDetails();
		Map<Integer, ProductDetailsView> productCache = populateHashMap(productDetailsView);
		populateIBANIndicator(productDetailsView);
		return productCache;
	}

	/*
	 * This method set IBAN indicator true if the product group is 144.
	 */
	private void populateIBANIndicator(List<ProductDetailsView> productDetailsViewList) {
		for (ProductDetailsView productDetailsView : productDetailsViewList) {
			if (productDetailsView.getProductGroupList() != null && !productDetailsView.getProductGroupList().isEmpty()
				&& productDetailsView.getProductGroupList().contains(144)) {
				productDetailsView.setIbanIndicator(true);
			}
		}
	}

	/*
	 * This method populates the order no for based on product groups
	 */
	private Map<Integer, ProductDetailsView> populateHashMap(List<ProductDetailsView> productDetailsView) {
		Map<Integer, ProductDetailsView> productCacheHashMap = new HashMap<>();

		for (ProductDetailsView productDetails : productDetailsView) {
			productCacheHashMap.put(productDetails.getProductId(), productDetails);
		}

		return productCacheHashMap;
	}
}
