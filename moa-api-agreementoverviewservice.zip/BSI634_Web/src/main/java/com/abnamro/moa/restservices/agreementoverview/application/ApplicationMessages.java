package com.abnamro.moa.restservices.agreementoverview.application;

import com.abnamro.moa.restservices.agreementoverview.service.constants.AgreementOverviewLogConstants;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Load the messages from a file from the classpath into memory. A message contains both a code and a textual representation.
 */
public final class ApplicationMessages {
	private ApplicationMessages() {}

	private static LogHelper logHelper = new LogHelper(ApplicationMessages.class);
	private static Properties messages = initializeMessages();

	/**
	 * Return the properties of the errors.
	 */
	private static Properties initializeMessages() {
		Properties properties = new Properties();

		String logMethod = "initializeMessages";

		if (messages == null) {
			String propertyFileName = "errormessages.properties";
			InputStream propertiesFile = ApplicationMessages.class.getResourceAsStream(propertyFileName);
			if (propertiesFile != null) {
				try {
					properties.load(propertiesFile);
				} catch (IOException exception) {
					logHelper.error(logMethod, AgreementOverviewLogConstants.LOG_EXCEPTION_IN_EXCEPTIONMAPPER, exception);
				} finally {
					try {
						propertiesFile.close();
					} catch(IOException exception) {
						logHelper.error(logMethod, AgreementOverviewLogConstants.LOG_EXCEPTION_IN_EXCEPTIONMAPPER, exception);
					}
				}
			}
		}

		return properties;
	}

	/**
	 * Return the code of the message with the given key.
	 * @param errorKey - the key of the message
	 * @return the code of the message
	 */
	public static String getErrorCode(String errorKey) {
		String errorCode = "";

		if (messages != null) {
			String errorCodeKey = errorKey + ".code";
			errorCode = messages.getProperty(errorCodeKey);
		}

		return errorCode;
	}

	/**
	 * Return the message part of the message with the given key.
	 * @param errorKey - the key of the message
	 * @return the textual representation of the message
	 */
	public static String getErrorMessage(String errorKey) {
		String errorMessage = "";

		if (messages != null) {
			String errorMessageKey = errorKey + ".message";
			errorMessage = messages.getProperty(errorMessageKey);
		}

		return errorMessage;
	}
}
