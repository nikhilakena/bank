package com.abnamro.moa.restservices.agreementoverview.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import com.abnamro.moa.restservices.agreementoverview.exceptions.AgreementOverviewValidationExceptionMapper;
import com.abnamro.moa.restservices.agreementoverview.service.AgreementOverviewRestService;

/**
 * This class is Application class for
 *         AgreementOverviewApplication and it extends
 *         AabRestApplication
 * @author C36098
 */
public class AgreementOverviewApplication extends Application{
  /**
   * @return - a Set that contains ProductConfigurationRestService
   */
	@Override
	public Set<Class<?>> getClasses()
	  {
	    Set classes = new HashSet();
	    classes.add(AgreementOverviewValidationExceptionMapper.class);
	    return classes;
	  }
	
  @Override
  public Set<Object> getSingletons() {
      Set<Object> singletons = new HashSet<>();
      singletons.add(new AgreementOverviewRestService());

      return singletons;
  }
}
