package com.abnamro.moa.restservices.agreementoverview.cachehandler;

import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.logging.log4j2.interceptors.LogInterceptorBinding;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

/**
 * This is the servlet class for CacheHandlerServlet and
 * it extends HttpServlet
 * @author C36098
 */
@LogInterceptorBinding
public class CacheHandlerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	/**
	 * Instantiate the Logger
	 */
	private static LogHelper logHelper =  new LogHelper(CacheHandlerServlet.class);
	
    /**
	 * Create the servlet that is to handle the cache.
     * @see HttpServlet#HttpServlet()
     */
    public CacheHandlerServlet() {
        super();
    }

	/**  {@inheritDoc}
	 * @see javax.servlet.GenericServlet#init()
	 **/
	@Override
	public void init() throws ServletException {
		final String LOG_METHOD = "init()";
		try {
		    CacheHandler.getInstance();
		} catch (CacheHandlerException cacheHandlerException) {
			logHelper.error(LOG_METHOD, CacheHandlerLogConstants.LOG_CACHE_HANDLER_EXCEPTION_IN_SERVLET, cacheHandlerException);
			throw new ServletException();
		}
	}
	
}
