package com.abnamro.moa.restservices.agreementoverview.service.constants;

/**
 * This class contains Log constants used for Agreement overview
 *
 * @author C36098
 */
public final class AgreementOverviewLogConstants {
	private AgreementOverviewLogConstants() {
	}

	public static final String LOG_EXCEPTION_IN_EXCEPTIONMAPPER = "LOG_BSxxxRE_002";

	public static final String LOG_EXCEPTION_IN_AGREEMENTOVERVIEW = "LOG_BSxxxRE_003";

}
