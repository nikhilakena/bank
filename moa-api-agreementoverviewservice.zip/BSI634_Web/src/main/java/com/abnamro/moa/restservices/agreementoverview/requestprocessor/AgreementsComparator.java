package com.abnamro.moa.restservices.agreementoverview.requestprocessor;

import java.util.Comparator;

import com.abnamro.moa.restservices.agreementoverview.dao.ContractHeaderView;

/**
 * This class performs comparison for ContractHeaderView
 * @author C36098
 */
public class AgreementsComparator implements Comparator<ContractHeaderView>{
  
  @Override
  public int compare(ContractHeaderView ch1, ContractHeaderView ch2)
  {
      return ch1.getOrderId()-ch2.getOrderId();
  }
}
