package com.abnamro.moa.restservices.agreementoverview.cachehandler;

import com.abnamro.nl.messages.MessageKey;

/**
 * This class contains Message keys used for Cache Handler
 *
 * @author C36098
 */
public final class CacheHandlerMessageKeys {
	private CacheHandlerMessageKeys() {
	}

	public static final MessageKey INVALID_HOURTORELOAD_ERROR = new MessageKey("MESSAGE_CACHE_0001");

	public static final MessageKey TIMERMANAGER_LOOKUP_ERROR = new MessageKey("MESSAGE_CACHE_0002");

	public static final MessageKey CONFIGURATION_SERVICE_ERROR = new MessageKey("MESSAGE_CACHE_0003");

	public static final MessageKey ERROR_FETCH_PRODUCT_DETAILS_CACHING_EXCEPTION = new MessageKey("MESSAGE_CACHE_0004");
}
