package com.abnamro.moa.restservices.agreementoverview.cachehandler;




/**
 * This class contains constants used for PI Error Handler
 * @author PA2619
 *
 */
public final class CacheHandlerConstants {
	private CacheHandlerConstants() {}
	 
	public static final String TIME_OF_DAY_TO_RELOAD = "timeOfDayToReload";
	
	/*******************************TIMER CONSTANTS********************************/
	public static final String TIMER_MANAGER = "timerManager";
	
	public static final String DEFAULT_TIMER_MANAGER = "java:comp/env/tm/default";

	public static final String TIME_TO_CHECK_AFTER = "timeToCheckAfter";
	
	/******************************WORK MANAGER******************************/
	
	public static final String QUEUE_SIZE = "queueSize";
	public static final int DEFAULT_QUEUE_SIZE = 10;

	public static final String POOL_SIZE = "poolSize";
	public static final int DEFAULT_POOL_SIZE = 5;

	public static final String MAX_POOL_SIZE = "maxPoolSize";
	public static final int DEFAULT_MAX_POOL_SIZE = 5;

	public static final String ALIVE_TIME = "aliveTime";
	public static final int DEFAULT_ALIVE_TIME = 120000;
	
	public static final int THIRTY = 30;
	
	public static final int SIXTY = 60;
	
	public static final long THOUSAND = 1000;
	
	public static final int ZERO_INT = 0;
	public static final int ONE_INT = 1;
	
	
	
	public static final int DEFAULT_POLL_AFTER_TIME = 2;
	
	public static final String SERVICE_NAME = "cachehandler";

}
