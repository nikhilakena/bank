package com.abnamro.moa.restservices.agreementoverview.dao.test;

import com.abnamro.moa.restservices.agreementoverview.dao.AgreementOverviewDB2DAO;
import com.abnamro.moa.restservices.agreementoverview.dao.AgreementOverviewMybatisMapper;
import com.abnamro.moa.restservices.agreementoverview.dao.ContractHeaderView;
import com.abnamro.moa.restservices.agreementoverview.exceptions.AgreementOverviewApplicationException;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.dao.util.mybatis.MyBatisConfigException;
import com.abnamro.nl.dao.util.mybatis.MyBatisConnectionFactory;
import org.apache.ibatis.session.SqlSession;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

@PowerMockIgnore("javax.management.*")
@RunWith(PowerMockRunner.class)
@PrepareForTest({ DAODatabaseUtil.class, MyBatisConnectionFactory.class })
public class AgreementOverviewDB2DAOTest {
	  	@Mock
	    private Connection connection;

	    @Mock
	    private MyBatisConnectionFactory connectionFactory;

	    @Mock
	    private SqlSession sqlSession;

	    @Mock
	    private AgreementOverviewMybatisMapper mapper;
	    
	    private AgreementOverviewDB2DAO underTest;

    @Before
    public void startUp() throws DAODatabaseException, MyBatisConfigException {
        PowerMockito.mockStatic(DAODatabaseUtil.class); 
        PowerMockito.when(DAODatabaseUtil.openConnection("test")).thenReturn(connection);
        connectionFactory = PowerMockito.mock(MyBatisConnectionFactory.class);
        PowerMockito.when(connectionFactory.getSession(connection)).thenReturn(sqlSession);
        PowerMockito.when(sqlSession.getMapper(AgreementOverviewMybatisMapper.class)).thenReturn(mapper);
    }

	@Test
	public void testRetrieveAgreementOverview() {
		List<ContractHeaderView> agreementViews = new ArrayList<ContractHeaderView>();
		List<String> agreements = new ArrayList<>();
		PowerMockito.when(mapper.retriveAgreementOverview("test",agreements ))
        .thenReturn(agreementViews);
		underTest = new AgreementOverviewDB2DAO("test", "test", connectionFactory);
		try {
			underTest.retrieveAgreementOverview(agreements);
		} catch (AgreementOverviewApplicationException e) {
			Assert.fail("No Exception expected");
		}
	}
}
