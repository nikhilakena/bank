package com.abnamro.moa.restservices.agreementoverview.requestprocessorv2;

import com.abnamro.moa.restservices.agreementoverview.cachehandler.CacheCollector;
import com.abnamro.moa.restservices.agreementoverview.dao.BuildingBlockReference;
import com.abnamro.moa.restservices.agreementoverview.dao.ContractHeaderView;
import com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Agreement;
import com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementList;
import com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error;
import com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors;
import com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.ValidationMessage;
import com.abnamro.moa.restservices.agreementoverview.service.constants.AgreementOverviewConstants;
import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsView;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

@RunWith(PowerMockRunner.class)
public class RetrieveAgreementOverViewRequestProcessorTest {
	private AgreementOverviewRequestProcessor requestProcessor;

	@Before
	public void initialize() {
		requestProcessor = new AgreementOverviewRequestProcessor();
	}

	@Test
	public void mapBbanToIban() {
		List<String> agreementIds = new ArrayList<>();
		Map<String, String> bbanIbanMapping = requestProcessor.mapBbanToIban(agreementIds);
		assertNotNull(bbanIbanMapping);
		assertEquals(0, bbanIbanMapping.size());

		agreementIds.add("NL12ABNA1231212123");
		agreementIds.add("NL12ABNA123121212");
		agreementIds.add("L12ABNA1231212124");
		agreementIds.add("8231212123");
		agreementIds.add("NL12INGB9231212123");
		agreementIds.add("NL12ABNA1231212125");
		agreementIds.add("DE12ABNA231212123");
		agreementIds.add("NL12ABNA1231212126");
		agreementIds.add("0231212123");

		bbanIbanMapping = requestProcessor.mapBbanToIban(agreementIds);
		assertNotNull(bbanIbanMapping);
		assertEquals(9, bbanIbanMapping.size());
	}

	@Test
	public void separateExistingAgreementIds() {
		Map<String, String> bbanIbanMapping = new HashMap<>();
		List<ContractHeaderView> contractHeaders = new ArrayList<>();
		Map<String, List<String>> errors = new HashMap<>();
		errors.put(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR, new ArrayList<String>());
		errors.put(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR, new ArrayList<String>());
		List<String> existingAgreementIds = requestProcessor.separateExistingAgreementIds(bbanIbanMapping, contractHeaders, errors);
		assertNotNull(existingAgreementIds);
		assertEquals(0, existingAgreementIds.size());
		assertEquals(2, errors.size());
		assertEquals(0, errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).size());
		assertEquals(0, errors.get(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR).size());

		bbanIbanMapping.put("1234567890", "NL89ABNA1234567890");
		bbanIbanMapping.put("0987654321", "NL78ABNA0987654321");
		bbanIbanMapping.put("1231231231", "1231231231");
		bbanIbanMapping.put("3453453453", "3453453453");
		bbanIbanMapping.put("6666666666", "NL66ABNA6666666666");

		ContractHeaderView contractHeader1 = new ContractHeaderView();
		contractHeader1.setAgreementId("1234567890");
		contractHeaders.add(contractHeader1);
		ContractHeaderView contractHeader2 = new ContractHeaderView();
		contractHeader2.setAgreementId("3453453453   ");
		contractHeaders.add(contractHeader2);
		ContractHeaderView contractHeader3 = new ContractHeaderView();
		contractHeader3.setAgreementId("0987654321");
		contractHeaders.add(contractHeader3);
		ContractHeaderView contractHeader4 = new ContractHeaderView();
		contractHeader4.setAgreementId("8989898989");
		contractHeaders.add(contractHeader4);

		existingAgreementIds = requestProcessor.separateExistingAgreementIds(bbanIbanMapping, contractHeaders, errors);
		assertNotNull(existingAgreementIds);
		assertEquals(3, existingAgreementIds.size());
		assertTrue(existingAgreementIds.contains("1234567890"));
		assertTrue(existingAgreementIds.contains("0987654321"));
		assertTrue(existingAgreementIds.contains("3453453453"));
		assertEquals(2, errors.size());
		assertEquals(2, errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).size());
		assertTrue(errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).contains("NL66ABNA6666666666"));
		assertTrue(errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).contains("1231231231"));
		assertEquals(0, errors.get(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR).size());
	}

	@Test
	public void separateExistingAgreementIdsEmptyDatabase() {
		Map<String, String> bbanIbanMapping = new HashMap<>();
		List<ContractHeaderView> contractHeaders = new ArrayList<>();
		Map<String, List<String>> errors = new HashMap<>();
		errors.put(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR, new ArrayList<String>());
		errors.put(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR, new ArrayList<String>());

		bbanIbanMapping.put("1234567890", "NL89ABNA1234567890");
		bbanIbanMapping.put("0987654321", "NL78ABNA0987654321");
		bbanIbanMapping.put("1231231231", "1231231231");
		bbanIbanMapping.put("3453453453", "3453453453");
		bbanIbanMapping.put("6666666666", "NL66ABNA6666666666");

		List<String> existingAgreementIds = requestProcessor.separateExistingAgreementIds(bbanIbanMapping, contractHeaders, errors);
		assertNotNull(existingAgreementIds);
		assertEquals(0, existingAgreementIds.size());
		assertEquals(2, errors.size());
		assertEquals(5, errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).size());
		assertTrue(errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).contains("NL89ABNA1234567890"));
		assertTrue(errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).contains("NL78ABNA0987654321"));
		assertTrue(errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).contains("1231231231"));
		assertTrue(errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).contains("3453453453"));
		assertTrue(errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).contains("NL66ABNA6666666666"));
		assertEquals(0, errors.get(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR).size());
	}

	@Test
	public void findBbanAgreement() {
		Map<String, String> bbanIbanMapping = new HashMap<>();
		bbanIbanMapping.put("1234567890", "NL89ABNA1234567890");
		bbanIbanMapping.put("0987654321", "NL78ABNA0987654321");
		bbanIbanMapping.put("1231231231", "1231231231");
		bbanIbanMapping.put("3453453453", "3453453453");
		bbanIbanMapping.put("6666666666", "NL66ABNA6666666666");

		assertNull(requestProcessor.findBbanAgreement(null, "1231231231"));
		assertNull(requestProcessor.findBbanAgreement(bbanIbanMapping, null));
		assertNull(requestProcessor.findBbanAgreement(bbanIbanMapping, "NL89RABO1234567890"));
		assertEquals("1231231231", requestProcessor.findBbanAgreement(bbanIbanMapping, "1231231231"));
		assertEquals("0987654321", requestProcessor.findBbanAgreement(bbanIbanMapping, "NL78ABNA0987654321"));
	}

	@Test
	public void findContractHeaders() {
		assertNotNull(requestProcessor.findContractHeaders(null, null));
		assertEquals(0, requestProcessor.findContractHeaders(null, null).size());

		List<ContractHeaderView> contractHeaders = new ArrayList<>();
		ContractHeaderView contractHeader1 = new ContractHeaderView();
		contractHeader1.setAgreementId("123456");
		contractHeaders.add(contractHeader1);
		ContractHeaderView contractHeader2 = new ContractHeaderView();
		contractHeader2.setAgreementId("345345   ");
		contractHeaders.add(contractHeader2);
		ContractHeaderView contractHeader3 = new ContractHeaderView();
		contractHeader3.setAgreementId("678123");
		contractHeaders.add(contractHeader3);

		List<ContractHeaderView> contractHeaders1 = requestProcessor.findContractHeaders(contractHeaders, null);
		assertNotNull(contractHeaders1);
		assertEquals(0, contractHeaders1.size());

		List<ContractHeaderView> contractHeaders2 = requestProcessor.findContractHeaders(contractHeaders, "9090");
		assertNotNull(contractHeaders2);
		assertEquals(0, contractHeaders2.size());

		List<ContractHeaderView> contractHeaders3 = requestProcessor.findContractHeaders(contractHeaders, "345345");
		assertEquals(1, contractHeaders3.size());
		assertEquals(contractHeader2.getAgreementId(), contractHeaders3.get(0).getAgreementId());
		contractHeaders3 = requestProcessor.findContractHeaders(contractHeaders, "123456");
		assertEquals(1, contractHeaders3.size());
		assertEquals("123456", contractHeaders3.get(0).getAgreementId());

		ContractHeaderView contractHeader4 = new ContractHeaderView();
		contractHeader4.setAgreementId("123456");
		contractHeaders.add(contractHeader4);
		List<ContractHeaderView> contractHeaders4 = requestProcessor.findContractHeaders(contractHeaders, "123456");
		assertEquals(2, contractHeaders4.size());
		assertEquals("123456", contractHeaders4.get(0).getAgreementId());
		assertEquals("123456", contractHeaders4.get(1).getAgreementId());
	}

	@Test
	public void createResponseErrorsWithoutParametersV2() {
		String traceId = "XYZ001";
		Map<String, List<String>> errorMap = new HashMap<>();
		List<String> notPresentAgreementIds = new ArrayList<>();
		errorMap.put(AgreementOverviewConstants.AGREEMENT_IDS_INVALID_ERROR, notPresentAgreementIds);
		List<String> invalidAgreementIds = new ArrayList<>();
		errorMap.put(AgreementOverviewConstants.AGREEMENT_IDS_MISSING_ERROR, invalidAgreementIds);
		Errors errors = requestProcessor.createResponseErrors(errorMap, traceId);
		assertNotNull(errors);
		assertNotNull(errors.getErrors());
		assertEquals(0, errors.getErrors().size());
	}

	@Test
	public void createResponseErrorsWithParametersV2() {
		String traceId = "XYZ001";
		Map<String, List<String>> errorMap = new HashMap<>();
		List<String> notPresentAgreementIds = new ArrayList<>();
		notPresentAgreementIds.add("NL78ABNA0887544053");
		notPresentAgreementIds.add("NL78ABNA0887544054");
		errorMap.put(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR, notPresentAgreementIds);

		List<String> invalidAgreementIds = new ArrayList<>();
		errorMap.put(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR, null);

		Errors errors = requestProcessor.createResponseErrors(errorMap, traceId);
		assertNotNull(errors);
		assertNotNull(errors.getErrors());
		assertEquals(1, errors.getErrors().size());

		Error error1 = errors.getErrors().get(0);
		assertEquals("AGREEMENT_IDS_NOT_PRESENT", error1.getCode());
		assertEquals("At least 1 agreementId provided in the input must be present in the database", error1.getMessage());
		assertEquals(AgreementOverviewConstants.RESPONSE_STATUS_400, error1.getStatus());
		assertEquals(traceId, error1.getTraceId());
		assertNotNull(error1.getParams());
		assertEquals(2, error1.getParams().size());
		assertTrue(error1.getParams().contains("NL78ABNA0887544053"));
		assertTrue(error1.getParams().contains("NL78ABNA0887544054"));
	}

	@Test
	public void createResponseErrorsWithInvalidParametersV2() {
		String traceId = "XYZ001";
		Map<String, List<String>> errorMap = new HashMap<>();
		List<String> notPresentAgreementIds = new ArrayList<>();
		errorMap.put(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR, notPresentAgreementIds);

		List<String> invalidAgreementIds = new ArrayList<>();
		invalidAgreementIds.add("NL78ABNA0887544053");
		invalidAgreementIds.add("NL78ABNA0887544054");
		errorMap.put(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR, invalidAgreementIds);

		Errors errors = requestProcessor.createResponseErrors(errorMap, traceId);
		assertNotNull(errors);
		assertNotNull(errors.getErrors());
		assertEquals(1, errors.getErrors().size());

		Error error1 = errors.getErrors().get(0);
		assertEquals("AGREEMENT_IDS_INVALID", error1.getCode());
		assertEquals("All Agreement Ids provided in the input are invalid", error1.getMessage());
		assertEquals(AgreementOverviewConstants.RESPONSE_STATUS_400, error1.getStatus());
		assertEquals(traceId, error1.getTraceId());
		assertNotNull(error1.getParams());
		assertEquals(2, error1.getParams().size());
		assertTrue(error1.getParams().contains("NL78ABNA0887544053"));
		assertTrue(error1.getParams().contains("NL78ABNA0887544054"));
	}

	@Test
	public void createResponseErrorsWithInvalidAndMissingParametersV2() {
		String traceId = "XYZ001";
		Map<String, List<String>> errorMap = new HashMap<>();
		List<String> notPresentAgreementIds = new ArrayList<>();
		notPresentAgreementIds.add("NL78ABNA0887544055");
		errorMap.put(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR, notPresentAgreementIds);

		List<String> invalidAgreementIds = new ArrayList<>();
		invalidAgreementIds.add("NL78ABNA0887544053");
		invalidAgreementIds.add("NL78ABNA0887544054");
		errorMap.put(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR, invalidAgreementIds);

		Errors errors = requestProcessor.createResponseErrors(errorMap, traceId);
		assertNotNull(errors);
		assertNotNull(errors.getErrors());
		assertEquals(2, errors.getErrors().size());

		Error error1 = errors.getErrors().get(0);
		assertEquals("AGREEMENT_IDS_INVALID", error1.getCode());
		assertEquals("All Agreement Ids provided in the input are invalid", error1.getMessage());
		assertEquals(AgreementOverviewConstants.RESPONSE_STATUS_400, error1.getStatus());
		assertEquals(traceId, error1.getTraceId());
		assertNotNull(error1.getParams());
		assertEquals(2, error1.getParams().size());
		assertTrue(error1.getParams().contains("NL78ABNA0887544053"));
		assertTrue(error1.getParams().contains("NL78ABNA0887544054"));

		Error error2 = errors.getErrors().get(1);
		assertEquals("AGREEMENT_IDS_NOT_PRESENT", error2.getCode());
		assertEquals("At least 1 agreementId provided in the input must be present in the database", error2.getMessage());
		assertEquals(AgreementOverviewConstants.RESPONSE_STATUS_400, error2.getStatus());
		assertEquals(traceId, error2.getTraceId());
		assertNotNull(error2.getParams());
		assertEquals(1, error2.getParams().size());
		assertTrue(error2.getParams().contains("NL78ABNA0887544055"));
	}

	@Test
	public void createSuccesfulResponseV2() {
		String traceId = "GHJ454";
		List<String> agreementIds = new ArrayList<>();
		agreementIds.add("1234567890");
		agreementIds.add("2234567890");
		agreementIds.add("3234567890");
		agreementIds.add("NL78ABNA0987654321");
		agreementIds.add("NL72ABNA3434343434");
		Map<String, String> bbanIbanMap = new HashMap<>();
		bbanIbanMap.put("1234567890", "1234567890");
		bbanIbanMap.put("2234567890", "2234567890");
		bbanIbanMap.put("3234567890", "3234567890");
		bbanIbanMap.put("0987654321", "NL78ABNA0987654321");
		bbanIbanMap.put("3434343434", "NL72ABNA3434343434");
		List<String> existingBbanAgreementIds = new ArrayList<>();
		existingBbanAgreementIds.add("2234567890");
		existingBbanAgreementIds.add("3434343434");
		Map<String, List<String>> errors = new HashMap<>();
		List<String> notPresentAgreementIds = new ArrayList<>();
		notPresentAgreementIds.add("1234567890");
		notPresentAgreementIds.add("NL78ABNA0987654321");
		errors.put(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR, notPresentAgreementIds);
		List<String> notValidAgreementIds = new ArrayList<>();
		notValidAgreementIds.add("3234567890");
		errors.put(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR, notValidAgreementIds);
		List<ContractHeaderView> persistentContractHeaders = new ArrayList<>();
		ContractHeaderView contractHeader1 = new ContractHeaderView();
		contractHeader1.setAgreementId("2234567890");
		contractHeader1.setProductId(345678);
		List<BuildingBlockReference> buildingBlockReferences1 = new ArrayList<>();
		BuildingBlockReference buildingBlockReference1 = new BuildingBlockReference();
		buildingBlockReference1.setBbId(43);
		buildingBlockReference1.setBbRefContractId("12");
		buildingBlockReferences1.add(buildingBlockReference1);
		BuildingBlockReference buildingBlockReference2 = new BuildingBlockReference();
		buildingBlockReference2.setBbId(87);
		buildingBlockReference2.setBbRefContractId("9877");
		buildingBlockReferences1.add(buildingBlockReference2);
		contractHeader1.setBuildingBlockReferences(buildingBlockReferences1);
		contractHeader1.setNickname("contract header no. 1");
		contractHeader1.setCustomerId(9786);
		contractHeader1.setBlockingCode("2");
		contractHeader1.setParentCHId("PAR009922");
		contractHeader1.setStatus(AgreementOverviewConstants.STATUS_ACTIVE);
		persistentContractHeaders.add(contractHeader1);

		ContractHeaderView contractHeader2 = new ContractHeaderView();
		contractHeader2.setAgreementId("3434343434");
		contractHeader2.setProductId(798987);
		List<BuildingBlockReference> buildingBlockReferences2 = new ArrayList<>();
		BuildingBlockReference buildingBlockReference11 = new BuildingBlockReference();
		buildingBlockReference11.setBbId(5434);
		buildingBlockReference11.setBbRefContractId("345322");
		buildingBlockReferences2.add(buildingBlockReference11);
		BuildingBlockReference buildingBlockReference12 = new BuildingBlockReference();
		buildingBlockReference12.setBbId(924);
		buildingBlockReference12.setBbRefContractId("9847");
		buildingBlockReferences2.add(buildingBlockReference12);
		contractHeader2.setBuildingBlockReferences(buildingBlockReferences2);
		contractHeader2.setNickname("contract header no. 2");
		contractHeader2.setCustomerId(2957);
		contractHeader2.setBlockingCode("2");
		contractHeader2.setParentCHId("PAR909090");
		contractHeader2.setStatus(AgreementOverviewConstants.STATUS_ACTIVE);
		persistentContractHeaders.add(contractHeader2);

		ContractHeaderView contractHeader3 = new ContractHeaderView();
		contractHeader3.setAgreementId("3434343434");
		contractHeader3.setProductId(254);
		List<BuildingBlockReference> buildingBlockReferences3 = new ArrayList<>();
		BuildingBlockReference buildingBlockReference31 = new BuildingBlockReference();
		buildingBlockReference31.setBbId(73);
		buildingBlockReference31.setBbRefContractId("56292");
		buildingBlockReferences3.add(buildingBlockReference31);
		BuildingBlockReference buildingBlockReference32 = new BuildingBlockReference();
		buildingBlockReference32.setBbId(82);
		buildingBlockReference32.setBbRefContractId("86931");
		buildingBlockReferences3.add(buildingBlockReference32);
		contractHeader3.setBuildingBlockReferences(buildingBlockReferences3);
		contractHeader3.setNickname("contract header no. 3");
		contractHeader3.setCustomerId(628);
		contractHeader3.setBlockingCode("2");
		contractHeader3.setParentCHId("PAR909072");
		contractHeader3.setStatus(AgreementOverviewConstants.STATUS_ACTIVE);
		persistentContractHeaders.add(contractHeader3);

		HashMap<Integer,ProductDetailsView> productHashMap = new HashMap<Integer,ProductDetailsView>();
		ProductDetailsView product1 = new ProductDetailsView();
		product1.setProductId(345678);
		product1.setIbanIndicator(false);
		product1.setInternalName("product internal name 345678  ");
		product1.setExternalName("product external name 345678   ");
		List<Integer> productGroupIdList1 = new ArrayList<>();
		productGroupIdList1.add(23);
		productGroupIdList1.add(87);
		productGroupIdList1.add(12);
		product1.setProductGroupList(productGroupIdList1);
		productHashMap.put(product1.getProductId(), product1);
		ProductDetailsView product2 = new ProductDetailsView();
		product2.setProductId(798987);
		product2.setIbanIndicator(true);
		product2.setInternalName("product internal name 798987 ");
		product2.setExternalName("product external name 798987  ");
		product2.setInternalNameEnglish("english internal name 798987");
		product2.setExternalNameEnglish("english external name 798987");
		List<Integer> productGroupIdList2 = new ArrayList<>();
		productGroupIdList2.add(435);
		productGroupIdList2.add(9);
		product2.setProductGroupList(productGroupIdList2);
		productHashMap.put(product2.getProductId(), product2);
		ProductDetailsView product3 = new ProductDetailsView();
		product3.setProductId(254);
		product3.setIbanIndicator(true);
		product3.setInternalName("product internal name 254 ");
		product3.setExternalName("product external name 254  ");
		List<Integer> productGroupIdList3 = new ArrayList<>();
		productGroupIdList3.add(12);
		productGroupIdList3.add(93);
		product3.setProductGroupList(productGroupIdList3);
		productHashMap.put(product3.getProductId(), product3);
		List<ContractHeaderView>  contractHeaderViewList = new ArrayList<ContractHeaderView>();

		CacheCollector.setProductCache(productHashMap);
		String languageAccept = "EN";
		AgreementList agreementList = requestProcessor.createSuccesfulResponse(agreementIds, bbanIbanMap, existingBbanAgreementIds, errors, persistentContractHeaders, languageAccept, traceId);
		assertNotNull(agreementList);
		assertNotNull(agreementList.getAgreements());
		assertEquals(3, agreementList.getAgreements().size());
		Agreement agreement1 = agreementList.getAgreements().get(0);
		assertNotNull(agreement1);
		assertEquals("2234567890", agreement1.getAgreementId());
		assertNull(agreement1.getIBAN());
		assertEquals(Agreement.LifecycleStatusEnum.ACTIVE, agreement1.getLifecycleStatus());
		assertEquals(345678, agreement1.getProductId().intValue());
		assertFalse(agreement1.isBlocked());
		assertEquals(9786L, agreement1.getAgreementPartyClusterId().longValue());
		assertEquals("contract header no. 1", agreement1.getNickName());
		assertEquals("PAR009922", agreement1.getParentAgreementCustomerReferenceId());
		assertNotNull(agreement1.getAgreementAdministrationKeys());
		assertEquals(2, agreement1.getAgreementAdministrationKeys().size());
		assertEquals("43_12", agreement1.getAgreementAdministrationKeys().get(0));
		assertEquals("87_9877", agreement1.getAgreementAdministrationKeys().get(1));
		assertNull(agreement1.getInternalProductName());
		assertNull(agreement1.getCommercialProductName());
		assertNotNull(agreement1.getProductGroupIds());
		List<Integer> productGroupIds1 = agreement1.getProductGroupIds();
		assertEquals(3, productGroupIds1.size());
		assertEquals(23, productGroupIds1.get(0).intValue());
		assertEquals(87, productGroupIds1.get(1).intValue());
		assertEquals(12, productGroupIds1.get(2).intValue());

		Agreement agreement2 = agreementList.getAgreements().get(1);
		assertNotNull(agreement2);
		assertEquals("3434343434", agreement2.getAgreementId());
		assertEquals("NL72ABNA3434343434", agreement2.getIBAN());
		assertEquals(Agreement.LifecycleStatusEnum.ACTIVE, agreement2.getLifecycleStatus());
		assertEquals(798987, agreement2.getProductId().intValue());
		assertFalse(agreement2.isBlocked());
		assertEquals(2957L, agreement2.getAgreementPartyClusterId().longValue());
		assertEquals("contract header no. 2", agreement2.getNickName());
		assertEquals("PAR909090", agreement2.getParentAgreementCustomerReferenceId());
		assertNotNull(agreement2.getAgreementAdministrationKeys());
		assertEquals(2, agreement2.getAgreementAdministrationKeys().size());
		assertEquals("5434_345322", agreement2.getAgreementAdministrationKeys().get(0));
		assertEquals("924_9847", agreement2.getAgreementAdministrationKeys().get(1));
		assertEquals("english internal name 798987", agreement2.getInternalProductName());
		assertEquals("english external name 798987", agreement2.getCommercialProductName());
		assertNotNull(agreement2.getProductGroupIds());
		List<Integer> productGroupIds2 = agreement2.getProductGroupIds();
		assertEquals(2, productGroupIds2.size());
		assertEquals(435, productGroupIds2.get(0).intValue());
		assertEquals(9, productGroupIds2.get(1).intValue());

		Agreement agreement3 = agreementList.getAgreements().get(2);
		assertNotNull(agreement3);
		assertEquals("3434343434", agreement3.getAgreementId());
		assertEquals("NL72ABNA3434343434", agreement3.getIBAN());
		assertEquals(Agreement.LifecycleStatusEnum.ACTIVE, agreement3.getLifecycleStatus());
		assertEquals(254, agreement3.getProductId().intValue());
		assertFalse(agreement3.isBlocked());
		assertEquals(628L, agreement3.getAgreementPartyClusterId().longValue());
		assertEquals("contract header no. 3", agreement3.getNickName());
		assertEquals("PAR909072", agreement3.getParentAgreementCustomerReferenceId());
		assertNotNull(agreement3.getAgreementAdministrationKeys());
		assertEquals(2, agreement3.getAgreementAdministrationKeys().size());
		assertEquals("73_56292", agreement3.getAgreementAdministrationKeys().get(0));
		assertEquals("82_86931", agreement3.getAgreementAdministrationKeys().get(1));
		assertNull(agreement3.getInternalProductName());
		assertNull(agreement3.getCommercialProductName());
		assertNotNull(agreement3.getProductGroupIds());
		List<Integer> productGroupIds3 = agreement3.getProductGroupIds();
		assertEquals(2, productGroupIds3.size());
		assertEquals(12, productGroupIds3.get(0).intValue());
		assertEquals(93, productGroupIds3.get(1).intValue());

		assertNotNull(agreementList.getMessages());
		assertEquals(2, agreementList.getMessages().size());
		ValidationMessage validationMessage1 = agreementList.getMessages().get(1);
		assertNotNull(validationMessage1);
		assertEquals("AGREEMENT_ID_NOT_PRESENT", validationMessage1.getCode());
		assertEquals("One or more agreement Ids provided in the input could not be found. params contains list of agreementIds which have this issue.", validationMessage1.getText());
		assertNotNull(validationMessage1.getParams());
		assertEquals(2, validationMessage1.getParams().size());
		assertEquals("1234567890", validationMessage1.getParams().get(0));
		assertEquals("NL78ABNA0987654321", validationMessage1.getParams().get(1));
		ValidationMessage validationMessage2 = agreementList.getMessages().get(0);
		assertNotNull(validationMessage2);
		assertEquals("AGREEMENT_ID_INVALID", validationMessage2.getCode());
		assertEquals("One or more agreement Ids provided in the input are invalid. params contains list of agreementIds which have this issue.", validationMessage2.getText());
		assertNotNull(validationMessage2.getParams());
		assertEquals(1, validationMessage2.getParams().size());
		assertEquals("3234567890", validationMessage2.getParams().get(0));
	}
}
