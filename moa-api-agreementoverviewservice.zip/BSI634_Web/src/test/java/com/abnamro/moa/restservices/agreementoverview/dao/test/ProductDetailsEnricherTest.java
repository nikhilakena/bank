package com.abnamro.moa.restservices.agreementoverview.dao.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.core.classloader.annotations.PrepareForTest;

import com.abnamro.moa.restservices.agreementoverview.dao.ProductDetailsEnricher;
import com.abnamro.moa.restservices.agreementoverview.exceptions.AgreementOverviewApplicationException;
import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsDB2DAO;
import com.abnamro.pna.productdetailsprovider.dao.ProductDetailsView;
import com.abnamro.pna.productdetailsprovider.exceptions.ProductDetailsProviderException;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ProductDetailsEnricher.class})
@PowerMockIgnore({"javax.security.auth.*","com.sun.jmx.*","javax.management.*"})
public class ProductDetailsEnricherTest {
    @InjectMocks
	private ProductDetailsEnricher underTest;
	@Mock
	private ProductDetailsDB2DAO mockDAO;
	
	@Test
	public void testGetProductDetailsForCaching() {
		List<ProductDetailsView> productDetailsViewList = new ArrayList<ProductDetailsView>();
		ProductDetailsView productDetailsView = new ProductDetailsView(); 
		productDetailsView.setOrderId(12);
		productDetailsView.setProductId(123);
		
		List<Integer> productGroupList = new ArrayList<Integer>();
		productGroupList.add(1);
		productGroupList.add(2);
		
		productDetailsView.setProductGroupList(productGroupList );
		productDetailsViewList.add(productDetailsView);
		try {
			Mockito.when(mockDAO.readProductDetails()).thenReturn(productDetailsViewList);
			underTest.getProductDetailsForCaching();
		} catch (ProductDetailsProviderException e) {
			Assert.fail("No Exception expected");
		} catch (AgreementOverviewApplicationException e) {
			Assert.fail("No Exception expected");
		}
	}

}
