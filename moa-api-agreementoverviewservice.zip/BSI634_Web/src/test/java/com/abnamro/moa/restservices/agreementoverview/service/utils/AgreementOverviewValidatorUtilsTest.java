package com.abnamro.moa.restservices.agreementoverview.service.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.*;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import com.abnamro.moa.restservices.agreementoverview.resourcemodel.AgreementSearchRequest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Errors;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Error;
import com.abnamro.moa.restservices.agreementoverview.exceptions.AgreementOverviewApplicationException;
import com.abnamro.moa.restservices.agreementoverview.service.constants.AgreementOverviewConstants;

public class AgreementOverviewValidatorUtilsTest {
	private AgreementOverviewValidatorUtils validator;

	@Before
	public void initialize() {
		validator = new AgreementOverviewValidatorUtils();
	}

	@Test
	public void testvalidateInputNoInput() throws AgreementOverviewApplicationException{
		AgreementSearchRequest input = new AgreementSearchRequest();
		try {
			validator.validateInput(input,"abc001");
		} catch (WebApplicationException e) {
			Assert.assertEquals("No input provided", 400, e.getResponse().getStatus());
		}
	}
	
	@Test
	public void testvalidateInputBlankAgreementId() throws AgreementOverviewApplicationException{
		AgreementSearchRequest input = new AgreementSearchRequest();
		List<String> agreements = new ArrayList<>();
		agreements.add("");
		
		input.setAgreementIds(agreements);
		try {
			validator.validateInput(input,"abc001");
		} catch (WebApplicationException e) {
			Assert.assertEquals("Invalid input selection criteria", 400, e.getResponse().getStatus());
		}
	}
	
	@Test
	public void testvalidateInputInvalidAgreementId() throws AgreementOverviewApplicationException{
		AgreementSearchRequest input = new AgreementSearchRequest();
		List<String> agreements = new ArrayList<>();
		agreements.add("1234567890");
		input.setAgreementIds(agreements);
		try {
			validator.validateInput(input,"abc001");
			agreements.add("12345678901234567");
			validator.validateInput(input,"abc001");
		} catch (WebApplicationException e) {
			Assert.assertEquals("Invalid input selection criteria", 400, e.getResponse().getStatus());
		}
	}
	
	@Test
	public void testvalidateInputInvalidIBAN() throws AgreementOverviewApplicationException{
		AgreementSearchRequest input = new AgreementSearchRequest();
		List<String> agreements = new ArrayList<>();
		agreements.add("NL53ABNA1234567890");
		
		input.setAgreementIds(agreements);
		try {
			validator.validateInput(input,"abc001");
			agreements.add("NL53ABNA123456789");
			validator.validateInput(input,"abc001");
		} catch (WebApplicationException e) {
			Assert.assertEquals("Invalid input selection criteria", 400, e.getResponse().getStatus());
		}
	}

	@Test
	public void validateInputNull() {
		String traceId = "123as";
		try {
			AgreementSearchRequest request = null;
			validator.validateInput(request, traceId);
			fail("exception expected");
		} catch(WebApplicationException exception) {
			assertEquals(400, exception.getResponse().getStatus());
			assertTrue(exception.getResponse().getEntity() instanceof Errors);
			Errors errors = (Errors) exception.getResponse().getEntity();
			assertEquals(1, errors.getErrors().size());
			Error error = errors.getErrors().get(0);
			assertEquals("AGREEMENT_IDS_MISSING", error.getCode());
			assertEquals("At least 1 agreementId is needed as input", error.getMessage());
			assertEquals("400", error.getStatus());
			assertEquals(traceId, error.getTraceId());
			assertNull(error.getParams());
		}
	}

	@Test
	public void validateInputWithoutAgreementIds() {
		String traceId = "124as";
		AgreementSearchRequest input = new AgreementSearchRequest();
		input.setAgreementIds(new ArrayList<String>());

		try {
			validator.validateInput(input, traceId);
			fail("exception expected");
		} catch(WebApplicationException exception) {
			assertEquals(400, exception.getResponse().getStatus());
			assertTrue(exception.getResponse().getEntity() instanceof Errors);
			Errors errors = (Errors) exception.getResponse().getEntity();
			assertEquals(1, errors.getErrors().size());
			Error error = errors.getErrors().get(0);
            assertEquals("AGREEMENT_IDS_MISSING", error.getCode());
            assertEquals("At least 1 agreementId is needed as input", error.getMessage());
			assertEquals("400", error.getStatus());
			assertEquals(traceId, error.getTraceId());
			assertNull(error.getParams());
		}
	}

	@Test
	public void validateInputWithTooManyAgreementIds() {
		String traceId = "125as";
		AgreementSearchRequest input = new AgreementSearchRequest();
		List<String> agreementIds = new ArrayList<>();
		for (int index = 0; index < 101; index++) {
			agreementIds.add("ASD");
		}
		input.setAgreementIds(agreementIds);

		try {
			validator.validateInput(input, traceId);
			fail("exception expected");
		} catch(WebApplicationException exception) {
			assertEquals(400, exception.getResponse().getStatus());
			assertTrue(exception.getResponse().getEntity() instanceof Errors);
			Errors errors = (Errors) exception.getResponse().getEntity();
			assertEquals(1, errors.getErrors().size());
			Error error = errors.getErrors().get(0);
			assertEquals("MAX_NO_OF_AGREEMENT_IDS_EXCEEDED", error.getCode());
			assertEquals("Cannot fetch details for more than 100 agreementIds", error.getMessage());
			assertEquals("400", error.getStatus());
			assertEquals(traceId, error.getTraceId());
			assertNull(error.getParams());
		}
	}

	@Test
	public void validateInputWithAgreementIds() {
		String traceId = "126as";
		AgreementSearchRequest input = new AgreementSearchRequest();
		List<String> agreementIds = new ArrayList<>();
		agreementIds.add("#$%HL");
		agreementIds.add("*))(*)");
		input.setAgreementIds(agreementIds);

		try {
			validator.validateInput(input, traceId);
		} catch(WebApplicationException exception) {
			fail("no exception expected");
		}
	}

	@Test
	public void validateAgreementIds() {
		assertFalse(validator.isValidAgreementId(""));
		assertFalse(validator.isValidAgreementId("NL99RABO1231212123"));
		assertFalse(validator.isValidAgreementId("NL99ABNA01231212123"));
		assertFalse(validator.isValidAgreementId("NL9ABNA01231212123"));
		assertFalse(validator.isValidAgreementId("DE99ABNA1231212123"));
		assertTrue(validator.isValidAgreementId("NL99ABNA12312121"));
		assertTrue(validator.isValidAgreementId("NL99ABNA1231212123"));
		assertTrue(validator.isValidAgreementId("NL99ABNA1231212199"));

		assertTrue(validator.isValidAgreementId("NL99ABNA1231"));
		assertTrue(validator.isValidAgreementId("NLABNA1231"));
		assertTrue(validator.isValidAgreementId("991231"));
		assertTrue(validator.isValidAgreementId("9"));
	}

	@Test
	public void validateEmptyArgumentIds() {
		List<String> agreementIds = new ArrayList<>();

		Map<String, List<String>> errors = new HashMap<>();
		errors.put(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR, new ArrayList<String>());
		errors.put(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR, new ArrayList<String>());

		List<String> validAgreementIds = validator.validateAgreementIds(agreementIds, errors);
		assertNotNull(validAgreementIds);
		assertTrue(validAgreementIds.isEmpty());
		assertNotNull(errors);
		assertTrue(errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).isEmpty());
		assertTrue(errors.get(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR).isEmpty());
	}

	@Test
	public void validateArgumentIds() {
		List<String> agreementIds = new ArrayList<>();
		agreementIds.add("NL99RABO1231212123");
		agreementIds.add("DE99ABNA1231212123");
		agreementIds.add("NL99ABNA1231212123");
		agreementIds.add("NLABNA1231");
		agreementIds.add("9");

		Map<String, List<String>> errors = new HashMap<>();
		errors.put(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR, new ArrayList<String>());
		errors.put(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR, new ArrayList<String>());

		List<String> validAgreementIds = validator.validateAgreementIds(agreementIds, errors);
		assertNotNull(validAgreementIds);
		assertEquals(3, validAgreementIds.size());
		assertTrue(validAgreementIds.contains("NL99ABNA1231212123"));
		assertTrue(validAgreementIds.contains("9"));
		assertTrue(validAgreementIds.contains("NLABNA1231"));
		assertFalse(validAgreementIds.contains("NL99RABO1231212123"));
		assertFalse(validAgreementIds.contains("DE99ABNA1231212123"));
		assertNotNull(errors);
		assertEquals(0, errors.get(AgreementOverviewConstants.AGREEMENT_ID_NOT_PRESENT_ERROR).size());
		assertEquals(2, errors.get(AgreementOverviewConstants.AGREEMENT_ID_INVALID_ERROR).size());
	}

	@Test
	public void testvalidateInputV2NoInput() throws AgreementOverviewApplicationException{
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest input = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest();
		try {
			validator.validateInput(input,"abc001");
		} catch (WebApplicationException e) {
			Assert.assertEquals("No input provided", 400, e.getResponse().getStatus());
		}
	}

	@Test
	public void testvalidateInputV2BlankAgreementId() throws AgreementOverviewApplicationException{
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest input = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest();
		List<String> agreements = new ArrayList<>();
		agreements.add("");

		input.setAgreementIds(agreements);
		try {
			validator.validateInput(input,"abc001");
		} catch (WebApplicationException e) {
			Assert.assertEquals("Invalid input selection criteria", 400, e.getResponse().getStatus());
		}
	}

	@Test
	public void testvalidateInputV2InvalidAgreementId() throws AgreementOverviewApplicationException{
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest input = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest();
		List<String> agreements = new ArrayList<>();
		agreements.add("1234567890");
		input.setAgreementIds(agreements);
		try {
			validator.validateInput(input,"abc001");
			agreements.add("12345678901234567");
			validator.validateInput(input,"abc001");
		} catch (WebApplicationException e) {
			Assert.assertEquals("Invalid input selection criteria", 400, e.getResponse().getStatus());
		}
	}

	@Test
	public void testvalidateInputV2InvalidIBAN() throws AgreementOverviewApplicationException{
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest input = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest();
		List<String> agreements = new ArrayList<>();
		agreements.add("NL53ABNA1234567890");

		input.setAgreementIds(agreements);
		try {
			validator.validateInput(input,"abc001");
			agreements.add("NL53ABNA123456789");
			validator.validateInput(input,"abc001");
		} catch (WebApplicationException e) {
			Assert.assertEquals("Invalid input selection criteria", 400, e.getResponse().getStatus());
		}
	}

	@Test
	public void validateInputV2Null() {
		String traceId = "123as";
		try {
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest request = null;
			validator.validateInput(request, traceId);
			fail("exception expected");
		} catch(WebApplicationException exception) {
			assertEquals(400, exception.getResponse().getStatus());
			assertTrue(exception.getResponse().getEntity() instanceof com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors);
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors errors = (com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors) exception.getResponse().getEntity();
			assertEquals(1, errors.getErrors().size());
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error error = errors.getErrors().get(0);
			assertEquals("AGREEMENT_IDS_MISSING", error.getCode());
			assertEquals("At least 1 agreementId is needed as input", error.getMessage());
			assertEquals("400", error.getStatus());
			assertEquals(traceId, error.getTraceId());
			assertNull(error.getParams());
		}
	}

	@Test
	public void validateInputV2WithoutAgreementIds() {
		String traceId = "124as";
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest input = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest();
		input.setAgreementIds(new ArrayList<String>());

		try {
			validator.validateInput(input, traceId);
			fail("exception expected");
		} catch(WebApplicationException exception) {
			assertEquals(400, exception.getResponse().getStatus());
			assertTrue(exception.getResponse().getEntity() instanceof com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors);
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors errors = (com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors) exception.getResponse().getEntity();
			assertEquals(1, errors.getErrors().size());
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error error = errors.getErrors().get(0);
			assertEquals("AGREEMENT_IDS_MISSING", error.getCode());
			assertEquals("At least 1 agreementId is needed as input", error.getMessage());
			assertEquals("400", error.getStatus());
			assertEquals(traceId, error.getTraceId());
			assertNull(error.getParams());
		}
	}

	@Test
	public void validateInputV2WithTooManyAgreementIds() {
		String traceId = "125as";
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest input = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest();
		List<String> agreementIds = new ArrayList<>();
		for (int index = 0; index < 101; index++) {
			agreementIds.add("ASD");
		}
		input.setAgreementIds(agreementIds);

		try {
			validator.validateInput(input, traceId);
			fail("exception expected");
		} catch(WebApplicationException exception) {
			assertEquals(400, exception.getResponse().getStatus());
			assertTrue(exception.getResponse().getEntity() instanceof com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors);
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors errors = (com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors) exception.getResponse().getEntity();
			assertEquals(1, errors.getErrors().size());
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error error = errors.getErrors().get(0);
			assertEquals("MAX_NO_OF_AGREEMENT_IDS_EXCEEDED", error.getCode());
			assertEquals("Cannot fetch details for more than 100 agreementIds", error.getMessage());
			assertEquals("400", error.getStatus());
			assertEquals(traceId, error.getTraceId());
			assertNull(error.getParams());
		}
	}

	@Test
	public void validateInputV2WithAgreementIds() {
		String traceId = "126as";
		com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest input = new com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.AgreementSearchRequest();
		List<String> agreementIds = new ArrayList<>();
		agreementIds.add("#$%HL");
		agreementIds.add("*))(*)");
		input.setAgreementIds(agreementIds);

		try {
			validator.validateInput(input, traceId);
		} catch(WebApplicationException exception) {
			fail("no exception expected");
		}
	}

	@Test
	public void validateInputLanguageV2() {
		String traceId = "ASDA1";
		assertEquals("NL", validator.validateLanguageInput(null, traceId));
		assertEquals("NL", validator.validateLanguageInput("NL", traceId));
		assertEquals("EN", validator.validateLanguageInput("EN", traceId));

		try {
			validator.validateLanguageInput("FR", traceId);
			fail("exception expected");
		} catch(WebApplicationException exception) {
			assertTrue(exception instanceof WebApplicationException);
			WebApplicationException webApplicationException = (WebApplicationException) exception;
			assertNotNull(webApplicationException.getResponse());
			Response response = webApplicationException.getResponse();
			assertNotNull(response.getEntity());
			assertTrue(response.getEntity() instanceof com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors);
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors errors = (com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors) response.getEntity();
			assertNotNull(errors.getErrors());
			assertEquals(1, errors.getErrors().size());
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error error = (com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error) errors.getErrors().get(0);
			assertNotNull(error);
			assertEquals("REQUESTED_LANGUAGE_NOT_SUPPORTED", error.getCode());
			assertEquals("The requested language is not supported", error.getMessage());
			assertEquals("406", error.getStatus());
			assertEquals("ASDA1", error.getTraceId());
			assertEquals(1, error.getParams().size());
			assertEquals("FR", error.getParams().get(0));
		}

		try {
			validator.validateLanguageInput("", traceId);
			fail("exception expected");
		} catch(WebApplicationException exception) {
			assertTrue(exception instanceof WebApplicationException);
			WebApplicationException webApplicationException = (WebApplicationException) exception;
			assertNotNull(webApplicationException.getResponse());
			Response response = webApplicationException.getResponse();
			assertNotNull(response.getEntity());
			assertTrue(response.getEntity() instanceof com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors);
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors errors = (com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Errors) response.getEntity();
			assertNotNull(errors.getErrors());
			assertEquals(1, errors.getErrors().size());
			com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error error = (com.abnamro.moa.restservices.agreementoverview.resourcemodelv2.Error) errors.getErrors().get(0);
			assertNotNull(error);
			assertEquals("REQUESTED_LANGUAGE_NOT_SUPPORTED", error.getCode());
			assertEquals("The requested language is not supported", error.getMessage());
			assertEquals("406", error.getStatus());
			assertEquals("ASDA1", error.getTraceId());
			assertEquals(1, error.getParams().size());
			assertEquals("", error.getParams().get(0));
		}
	}
}
