package com.abnamro.moa.restservices.agreementoverview.service;

import static org.junit.Assert.fail;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import com.abnamro.moa.restservices.agreementoverview.resourcemodel.AgreementSearchRequest;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Errors;
import com.abnamro.moa.restservices.agreementoverview.resourcemodel.Error;
import com.abnamro.moa.restservices.agreementoverview.service.constants.AgreementOverviewConstants;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(AgreementOverviewRestService.class)
@PowerMockIgnore({"javax.security.auth.*","com.sun.jmx.*","javax.management.*"})
public class CustomerAgreementsRestServiceTest {
	@InjectMocks
	private AgreementOverviewRestService underTest;

    @Test
    public void searchWithoutAgreementIds() {
        AgreementSearchRequest request = new AgreementSearchRequest();
        try {
            underTest.searchAgreementOverview("asd", request);
            fail("expected an exception");
        } catch (WebApplicationException exception) {
            assertNotNull(exception);
            assertNotNull(exception.getResponse());
            Response response = exception.getResponse();
            assertEquals(400, response.getStatus());
            assertNotNull(response.getEntity());
            assertTrue(response.getEntity() instanceof Errors);
            Errors errors = (Errors) response.getEntity();
            assertEquals(1, errors.getErrors().size());
            Error error1 = errors.getErrors().get(0);
            assertNotNull(error1);
            assertEquals("asd", error1.getTraceId());
            assertEquals("400", error1.getStatus());
            assertEquals("AGREEMENT_IDS_MISSING", error1.getCode());
            assertEquals("At least 1 agreementId is needed as input", error1.getMessage());
            assertNull(error1.getParams());
        }
    }

    @Test
    public void searchTooManyAgreementIds() {
        AgreementSearchRequest request = new AgreementSearchRequest();
        for (int index = 0; index < 102; index++) {
            request.addAgreementIdsItem(Integer.toString(index));
        }
        try {
            underTest.searchAgreementOverview("asd", request);
            fail("expected an exception");
        } catch (WebApplicationException exception) {
            assertNotNull(exception);
            assertNotNull(exception.getResponse());
            Response response = exception.getResponse();
            assertEquals(400, response.getStatus());
            assertNotNull(response.getEntity());
            assertTrue(response.getEntity() instanceof Errors);
            Errors errors = (Errors) response.getEntity();
            assertEquals(1, errors.getErrors().size());
            Error error1 = errors.getErrors().get(0);
            assertNotNull(error1);
            assertEquals("asd", error1.getTraceId());
            assertEquals("400", error1.getStatus());
            assertEquals("MAX_NO_OF_AGREEMENT_IDS_EXCEEDED", error1.getCode());
            assertEquals("Cannot fetch details for more than 100 agreementIds", error1.getMessage());
            assertNull(error1.getParams());
        }
    }

    @Test
    public void searchWithoutDatabase() {
        AgreementSearchRequest request = new AgreementSearchRequest();
        request.addAgreementIdsItem("121212121");
        try {
            underTest.searchAgreementOverview("asd", request);
            fail("expected an exception");
        } catch (WebApplicationException exception) {
            assertNotNull(exception);
            assertNotNull(exception.getResponse());
            Response response = exception.getResponse();
            assertEquals(500, response.getStatus());
            assertNotNull(response.getEntity());
            assertTrue(response.getEntity() instanceof Errors);
            Errors errors = (Errors) response.getEntity();
            assertEquals(1, errors.getErrors().size());
            Error error1 = errors.getErrors().get(0);
            assertNotNull(error1);
            assertEquals("asd", error1.getTraceId());
            assertEquals("500", error1.getStatus());
            assertEquals("INTERNAL_SERVER_ERROR", error1.getCode());
            assertEquals("Internal error occurred", error1.getMessage());
            assertNull(error1.getParams());
        }
    }
}
