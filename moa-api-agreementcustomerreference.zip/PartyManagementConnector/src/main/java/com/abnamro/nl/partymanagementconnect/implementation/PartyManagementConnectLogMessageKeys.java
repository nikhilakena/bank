package com.abnamro.nl.partymanagementconnect.implementation;

import com.abnamro.nl.messages.MessageKey;

/**
 * PartyManagementConnectLogMessageKeys. Message key constant class for Party Management Connect
 * 
 */

public class PartyManagementConnectLogMessageKeys {

	public static final MessageKey EXCEPTION_IN_RETRIEVE_PARTY_DETAILS = new MessageKey("MESSAGE_PRTCON_001");
	public static final MessageKey RETRIEVE_PARTY_DETAILS_CONFIGURATION_SERVICE_EXCEPTION = new MessageKey("MESSAGE_PRTCON_003");
	public static final MessageKey EXCEPTION_INVALID_RESPONSE_FROM_SERVICE = new MessageKey("MESSAGE_PRTCON_004");

}
