package com.abnamro.nl.partymanagementconnect.implementation;
/**
 * PartyManagementConnectLogConstants : Class contains Log constants which are used in PartyManagementConnect
 * 
 */
public class PartyManagementConnectLogConstants {

	public static final String LOG_RETRIEVE_PARTY_DETAILS_EXCEPTION = "LOG_BAI714_1001";
	public static final String LOG_CHECK_RING_FENCING_STATUS_EXCEPTION = "LOG_BAI714_1002";
	public static final String LOG_RETRIEVE_PARTY_DETAILS_CONFIGURATION_SERVICE_EXCEPTION = "LOG_BAI714_1003";
	public static final String LOG_INVALID_RESPONSE_FROM_SERVICE = "LOG_BAI714_1004";
	

}
