package com.abnamro.nl.partymanagementconnect.implementation;

/**
 * PartyManagementConnectConstants : It has constant definitions for connecting ESB services.
 * 
 */
public class PartyManagementConnectConstants {
	
	public static final String SERVICE_NAME = "partymanagementconnect";
	
	public static final String CONNECT_URL = "url";
	
	public static final String INTERNAL_SERVER_ERRROR = "500";
	public static final String ERROR_BC_IS_NOT_ACTIVE = "BC_NOT_ACTIVE";
	public static final String ERROR_BC_DOES_NOT_EXIST = "BC_NOT_EXIST";

	public static final int INTERNAL_SERVER_ERRROR_HTTP_STATUS = 500;
	
	public static final int BAD_REQUEST_HTTP_STATUS = 400;
}
