package com.abnamro.nl.partymanagementconnect.implementation;

import java.util.List;

/**
 * This is the Exception class for the PartyManagementConnect
 *
 */
public class PartyManagementConnectException extends Exception {

	private int status;

    private List<String> params;
    

    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param cause cause of the error
     * @param status https status of the error
     */
    public PartyManagementConnectException(String message, Throwable cause, int status) {
        super(message, cause);
        this.status = status;
    }

    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param status https status of the error
     */
    public PartyManagementConnectException(String message, int status) {
        super(message);
        this.status = status;
    }


    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param status https status of the error
     * @param params list of additional param information
     */
    public PartyManagementConnectException(String message, int status,List<String> params) {
        super(message);
        this.params = params;
        this.status = status;
    }

    public int getStatus() {
        return this.status;
    }

    public List<String> getParams() {
        return params;
    }

}
