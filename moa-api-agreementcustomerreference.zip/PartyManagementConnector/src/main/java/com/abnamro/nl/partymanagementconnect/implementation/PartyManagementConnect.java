package com.abnamro.nl.partymanagementconnect.implementation;

import javax.xml.ws.soap.SOAPFaultException;

import org.springframework.stereotype.Component;

import com.abnamro.nl.commondf.v3.Exception;
import com.abnamro.nl.configurationservice.ConfigurationService;
import com.abnamro.nl.configurationservice.ConfigurationServiceException;
import com.abnamro.nl.configurationservice.TechnicalConfigurationServiceFactory;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.partymanagement.v4.IPartyManagementPortProxy;
import com.abnamro.nl.partymanagement.v4.RetrievePartyDetailsException;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsRequestTO;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;

/**
 * Product Eligibility connect. This service is used to connect BCDB services
 * and retrieve customer information
 * 
 * <PRE>
 * <B>History:</B>
* Developer		Date		Change Reason		Change
* ---------		----		-------------		------
* TCS	 	Jun 11, 2018	Initial version		Loyalty
 * </PRE>
 *
 */
@Component
public class PartyManagementConnect {

	private static final LogHelper LOGGER = new LogHelper(PartyManagementConnect.class);

	private static final ConfigurationService configurationService = TechnicalConfigurationServiceFactory
			.createInstanceForService(PartyManagementConnectConstants.SERVICE_NAME,PartyManagementConnect.class.getName());

	/**
	 * Retrieves Party details for Product Eligibility check
	 * 
	 * @param retrievePartyDetailsRequestTO
	 *            RetrievePartyDetailsRequestTO
	 * 
	 * @return RetrievePartyDetailsResponseTO
	 * 
	 * @throws PartyManagementConnectException
	 *             ProductEligibilityConnectException
	 */
	public RetrievePartyDetailsResponseTO retrievePartyDetails(
			RetrievePartyDetailsRequestTO retrievePartyDetailsRequestTO) throws PartyManagementConnectException{

		final String logMethod = "retrievePartyDetails(retrievePartyDetailsRequestTO):RetrievePartyDetailsResponseTO";

		IPartyManagementPortProxy proxy = null;
		RetrievePartyDetailsResponseTO response = null;

		try {
			proxy = getPartyManagementProxy();
			response = proxy.retrievePartyDetails(retrievePartyDetailsRequestTO);

		} catch (SOAPFaultException soapFaultException) {
			throw new PartyManagementConnectException(PartyManagementConnectConstants.ERROR_BC_IS_NOT_ACTIVE, PartyManagementConnectConstants.BAD_REQUEST_HTTP_STATUS);
		} catch (RetrievePartyDetailsException e) {
			checkForInvalidBC(e);
			LOGGER.error(logMethod, PartyManagementConnectLogConstants.LOG_RETRIEVE_PARTY_DETAILS_EXCEPTION, e);
			throw new PartyManagementConnectException(PartyManagementConnectConstants.INTERNAL_SERVER_ERRROR,PartyManagementConnectConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}

		return response;
	}

	private void checkForInvalidBC(RetrievePartyDetailsException e) throws PartyManagementConnectException {
		if(e.getFaultInfo()!=null){
			for(Exception exception: e.getFaultInfo().getExceptionElement()) {
				if("4002".equals(exception.getCode())){
					throw new PartyManagementConnectException(PartyManagementConnectConstants.ERROR_BC_DOES_NOT_EXIST, PartyManagementConnectConstants.BAD_REQUEST_HTTP_STATUS);
				}
			}
		}
	}

	private IPartyManagementPortProxy getPartyManagementProxy()  throws PartyManagementConnectException{

		final String logMethod = "productEligibilityConnect:IPartyManagementPortProxy";

		IPartyManagementPortProxy proxy = null;

		try {

			proxy = new IPartyManagementPortProxy();

			String endpointUrl = configurationService.getString(PartyManagementConnectConstants.CONNECT_URL);

			proxy._getDescriptor().setEndpoint(endpointUrl);

		} catch (ConfigurationServiceException configurationServiceException) {

			LOGGER.error(logMethod,
					PartyManagementConnectLogConstants.LOG_RETRIEVE_PARTY_DETAILS_CONFIGURATION_SERVICE_EXCEPTION,
					configurationServiceException);

			throw new PartyManagementConnectException(PartyManagementConnectConstants.INTERNAL_SERVER_ERRROR,PartyManagementConnectConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
		return proxy;
	}

}
