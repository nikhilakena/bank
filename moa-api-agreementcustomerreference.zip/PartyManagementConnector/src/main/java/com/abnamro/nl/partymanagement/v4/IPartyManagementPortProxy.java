package com.abnamro.nl.partymanagement.v4;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;
import com.abnamro.nl.partymanagementobjects.v4.CheckCustomerRingFencingStatusRequestTO;
import com.abnamro.nl.partymanagementobjects.v4.CheckCustomerRingFencingStatusResponseTO;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsRequestTO;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;
import com.abnamro.nl.partymanagementobjects.v4.SearchPartyRequestTO;
import com.abnamro.nl.partymanagementobjects.v4.SearchPartyResponseTO;
import com.abnamro.nl.retrieverelatedpartiesobjects.v4.RetrieveRelatedPartyRequestTO;
import com.abnamro.nl.retrieverelatedpartiesobjects.v4.RetrieveRelatedPartyResponseTO;

public class IPartyManagementPortProxy{

    protected Descriptor _descriptor;

    public class Descriptor {
        private com.abnamro.nl.partymanagement.v4.PartyManagement _service = null;
        private com.abnamro.nl.partymanagement.v4.IPartyManagement _proxy = null;
        private Dispatch<Source> _dispatch = null;
        private boolean _useJNDIOnly = false;

        public Descriptor() {
            init();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new com.abnamro.nl.partymanagement.v4.PartyManagement(wsdlLocation, serviceName);
            initCommon();
        }

        public void init() {
            _service = null;
            _proxy = null;
            _dispatch = null;
            try
            {
                InitialContext ctx = new InitialContext();
                _service = (com.abnamro.nl.partymanagement.v4.PartyManagement)ctx.lookup("java:comp/env/service/PartyManagement");
            }
            catch (NamingException e)
            {
                if ("true".equalsIgnoreCase(System.getProperty("DEBUG_PROXY"))) {
                    System.out.println("JNDI lookup failure: javax.naming.NamingException: " + e.getMessage());
                    e.printStackTrace(System.out);
                }
            }

            if (_service == null && !_useJNDIOnly)
                _service = new com.abnamro.nl.partymanagement.v4.PartyManagement();
            initCommon();
        }

        private void initCommon() {
            _proxy = _service.getIPartyManagementPort();
        }

        public com.abnamro.nl.partymanagement.v4.IPartyManagement getProxy() {
            return _proxy;
        }

        public void useJNDIOnly(boolean useJNDIOnly) {
            _useJNDIOnly = useJNDIOnly;
            init();
        }

        public Dispatch<Source> getDispatch() {
            if (_dispatch == null ) {
                QName portQName = new QName("", "IPartyManagementPort");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = (BindingProvider) _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if (_dispatch != null ) {
                bp = (BindingProvider) _dispatch;
                bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }

        public void setMTOMEnabled(boolean enable) {
            SOAPBinding binding = (SOAPBinding) ((BindingProvider) _proxy).getBinding();
            binding.setMTOMEnabled(enable);
        }
    }

    public IPartyManagementPortProxy() {
        _descriptor = new Descriptor();
        _descriptor.setMTOMEnabled(false);
    }

    public IPartyManagementPortProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
        _descriptor.setMTOMEnabled(false);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }

    public CheckCustomerRingFencingStatusResponseTO checkCustomerRingFencingStatus(CheckCustomerRingFencingStatusRequestTO requestParameters) throws CheckCustomerRingFencingStatusException {
        return _getDescriptor().getProxy().checkCustomerRingFencingStatus(requestParameters);
    }

    public RetrievePartyDetailsResponseTO retrievePartyDetails(RetrievePartyDetailsRequestTO requestParameters) throws RetrievePartyDetailsException {
        return _getDescriptor().getProxy().retrievePartyDetails(requestParameters);
    }

    public SearchPartyResponseTO searchParty(SearchPartyRequestTO requestParameters) throws SearchPartyException {
        return _getDescriptor().getProxy().searchParty(requestParameters);
    }

    public RetrieveRelatedPartyResponseTO retrieveRelatedParty(RetrieveRelatedPartyRequestTO requestParameters) throws RetrieveRelatedPartyException {
        return _getDescriptor().getProxy().retrieveRelatedParty(requestParameters);
    }

}