package com.abnamro.moa.generic.agreementcustomerreference.publisher;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.dto.PublishContractHeaderInputDTO;
import com.abnamro.moa.generic.agreementcustomerreference.publisher.exceptions.AgreementCustomerReferenceExternalPublisherException;


/**
 * This Interface which will be used to IMS transaction MO856 for publishing mutations to the External systems
 *
 */
public interface AgreementCustomerReferenceExternalPublisher {

	/**
	 * This method calls IMS transaction MO856 for publishing mutations to the External systems
	 * 
	 * @param publishContractHeaderInputDTO contract header related input which requires for IMS transaction call(MO503)
	 * @param publishType indicating create/ update/ delete of contract header
	 * @throws AgreementCustomerReferenceExternalPublisherException Exception thrown if any issue in processing IMS transaction 
	 */
	public void publishAgreementCustomerReference(PublishContractHeaderInputDTO publishContractHeaderInputDTO, String publishType) throws AgreementCustomerReferenceExternalPublisherException;
	
}
