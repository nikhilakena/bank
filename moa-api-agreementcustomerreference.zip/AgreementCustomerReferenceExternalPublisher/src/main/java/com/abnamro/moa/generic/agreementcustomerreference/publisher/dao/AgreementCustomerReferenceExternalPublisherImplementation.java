package com.abnamro.moa.generic.agreementcustomerreference.publisher.dao;

import java.sql.Timestamp;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.abnamro.component.transactionconnect.factory.IMSTransactionConnectorFactory;
import com.abnamro.component.transactionconnect.interfaces.IMSTransactionException;
import com.abnamro.component.transactionconnect.interfaces.TransactionConnectorInterface;
import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.generic.agreementcustomerreference.publisher.dao.generated.MO856INPUTMSG;
import com.abnamro.moa.generic.agreementcustomerreference.publisher.dao.generated.MO856OUTPUTMSG;
import com.abnamro.moa.generic.agreementcustomerreference.publisher.dto.PublishContractHeaderInputDTO;
import com.abnamro.moa.generic.agreementcustomerreference.publisher.exceptions.AgreementCustomerReferenceExternalPublisherException;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;

/**
 * This class calls IMS transaction MO856 for publishing mutations to the External systems
 */
@Component
public class AgreementCustomerReferenceExternalPublisherImplementation implements AgreementCustomerReferenceExternalPublisher {
	
	private static final LogHelper logHelper = new LogHelper(AgreementCustomerReferenceExternalPublisherImplementation.class);
	

	@Override
	public void publishAgreementCustomerReference(PublishContractHeaderInputDTO publishContractHeaderInputDTO, String publishType) throws AgreementCustomerReferenceExternalPublisherException{

		final String logMethod = "createContractHeader(InputHeaderDTO, CreateContractHeaderInputDTO)";

		MO856INPUTMSG sendRecord = new MO856INPUTMSG();
		MO856OUTPUTMSG recordReceive;
		String transactionCode = AgreementCustomerReferenceExternalPublisherConstants.TRANSACTION_CODE_MO856T01;
		
		try {
			sendRecord.setZz_Veld((short) 0);
			sendRecord.setLl_Veld((short) sendRecord.getSize());
			sendRecord.setIms_Transakt_Kode(transactionCode);
			
			populateHeaderDetailsForPublishType(sendRecord,publishType, publishContractHeaderInputDTO.getLastModifiedDate());

			sendRecord = addContractHeaderDetailsInSendRecord(sendRecord, publishContractHeaderInputDTO);

			String LOG_METHOD = "publishAgreementCustomerReference";
			logHelper.error(LOG_METHOD, "contract header id:" + sendRecord.getContractheaderid() + ":");
			logHelper.error(LOG_METHOD, "BC number:" + sendRecord.getMgbuscontnr() + ":");
			logHelper.error(LOG_METHOD, "BC number old:" + sendRecord.getMgbuscontnr_Oud() + ":");
			logHelper.error(LOG_METHOD, "product id:" + sendRecord.getProductid() + ":");
			logHelper.error(LOG_METHOD, "product id old:" + sendRecord.getProductid_Oud() + ":");
			logHelper.error(LOG_METHOD, "status:" + sendRecord.getChcontractstatus() + ":");
			logHelper.error(LOG_METHOD, "status old:" + sendRecord.getChcontractstatus_Oud() + ":");
			logHelper.error(LOG_METHOD, "chid parent:" + sendRecord.getChid_Parent() + ":");
			logHelper.error(LOG_METHOD, "chid parent old:" + sendRecord.getChid_Parent_Oud() + ":");
			logHelper.error(LOG_METHOD, "contract id:" + sendRecord.getCommercial_Contrnr() + ":");
			logHelper.error(LOG_METHOD, "building block id:" + sendRecord.getBuildingblockid() + ":");
			logHelper.error(LOG_METHOD, "IMS transaction code:" + sendRecord.getIms_Transakt_Kode() + ":");
			logHelper.error(LOG_METHOD, "size:" + sendRecord.getSize() + ":");
			logHelper.error(LOG_METHOD, "MO destination:" + sendRecord.getMo_Destination() + ":");
			logHelper.error(LOG_METHOD, "LL:" + sendRecord.getLl_Veld() + ":");
			logHelper.error(LOG_METHOD, "ZZ:" + sendRecord.getZz_Veld() + ":");
			logHelper.error(LOG_METHOD, "update type:" + sendRecord.getUpdatetype() + ":");

			TransactionConnectorInterface txnConnectorIfc = IMSTransactionConnectorFactory.newInstance();
			recordReceive = txnConnectorIfc.sendReceive(sendRecord, MO856OUTPUTMSG.class);
			
			if (recordReceive == null) {
				logHelper.error(logMethod, AgreementCustomerReferenceExternalPublisherLogConstants.LOG_RSLT_CODE_FAILURE_OR_NO_RESULTS);
				throw new AgreementCustomerReferenceExternalPublisherException(AgreementCustomerReferenceExternalPublisherConstants.INTERNAL_SERVER_ERRROR, AgreementCustomerReferenceExternalPublisherConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
			} else {
				verifyResponse(recordReceive);// Do we still message in this Transaction Context? For now I have changed it to - retrieve resultcode
			}
		} catch (IMSTransactionException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceExternalPublisherLogConstants.LOG_IMS_EXCEPTION_IN_MO_PUBLISH, exception);
			throw new AgreementCustomerReferenceExternalPublisherException(AgreementCustomerReferenceExternalPublisherConstants.INTERNAL_SERVER_ERRROR, AgreementCustomerReferenceExternalPublisherConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}finally{
			logHelper.info(logMethod, transactionCode);
		}
	}
	
	
	private void populateHeaderDetailsForPublishType(MO856INPUTMSG sendRecord, String publishType, Timestamp lastModifiedDate) {
		populateStaticHeaderDetails(sendRecord);
		if(AgreementCustomerReferenceExternalPublisherConstants.PUBLISH_TYPE_CREATE.equals(publishType)) {
			populateHeaderDetailsForCreate(sendRecord);
		}
		if(AgreementCustomerReferenceExternalPublisherConstants.PUBLISH_TYPE_UPDATE.equals(publishType)) {
			populateHeaderDetailsForUpdate(sendRecord, lastModifiedDate);
		}
		if(AgreementCustomerReferenceExternalPublisherConstants.PUBLISH_TYPE_DELETE.equals(publishType)) {
			populateHeaderDetailsForDelete(sendRecord);
		}
		
	}

	private void populateStaticHeaderDetails(MO856INPUTMSG sendRecord) {
		
		sendRecord.setSourceid(AgreementCustomerReferenceExternalPublisherConstants.SOURCE_ID);

		sendRecord.setChanged_Obj_Type(AgreementCustomerReferenceExternalPublisherConstants.OBJECT_TYPE);

		sendRecord.setPubmessage_Length(sendRecord.getSize());

		sendRecord.setSourcecomponentid(AgreementCustomerReferenceExternalPublisherConstants.SPACE);

		sendRecord.setProcessid(AgreementCustomerReferenceExternalPublisherConstants.INT_ZERO);

		sendRecord.setSegment_Sequence_Number(AgreementCustomerReferenceExternalPublisherConstants.INT_ZERO);

		sendRecord.setReason_Code(AgreementCustomerReferenceExternalPublisherConstants.INT_ZERO);

		sendRecord.setData_Structure_Definition(AgreementCustomerReferenceExternalPublisherConstants.SPACE);
		
	}
	
	
	private void populateHeaderDetailsForCreate(MO856INPUTMSG sendRecord) {
		
		sendRecord.setUpdatetype(AgreementCustomerReferenceExternalPublisherConstants.UPDATE_TYPE_CREATE);

		sendRecord.setNew_Timestamp((new Timestamp(System.currentTimeMillis())).toString());

		sendRecord.setPrevious_Timestamp(AgreementCustomerReferenceExternalPublisherConstants.SPACE);

	}
	
	private void populateHeaderDetailsForUpdate(MO856INPUTMSG sendRecord, Timestamp lastModifiedDate) {
		
		sendRecord.setUpdatetype(AgreementCustomerReferenceExternalPublisherConstants.UPDATE_TYPE_UPDATE);

		sendRecord.setNew_Timestamp((new Timestamp(System.currentTimeMillis())).toString());

		sendRecord.setPrevious_Timestamp(lastModifiedDate.toString());
		
	}

	private void populateHeaderDetailsForDelete(MO856INPUTMSG sendRecord) {
		
		sendRecord.setUpdatetype(AgreementCustomerReferenceExternalPublisherConstants.UPDATE_TYPE_DELETE);

		sendRecord.setNew_Timestamp(AgreementCustomerReferenceExternalPublisherConstants.SPACE);

		sendRecord.setPrevious_Timestamp((new Timestamp(System.currentTimeMillis())).toString());
		
	}

	private MO856INPUTMSG addContractHeaderDetailsInSendRecord(MO856INPUTMSG sendRecord,
			PublishContractHeaderInputDTO publishContractHeaderInputDTO) {
		
		if(publishContractHeaderInputDTO != null){
			sendRecord.setMgbuscontnr(publishContractHeaderInputDTO.getBcNumber());
			sendRecord.setMgbuscontnr_Oud(publishContractHeaderInputDTO.getBcNumberOld());
			sendRecord.setContractheaderid(publishContractHeaderInputDTO.getContractHeaderId());
			sendRecord.setProductid(StringUtils.leftPad(String.valueOf(publishContractHeaderInputDTO.getProductId()), AgreementCustomerReferenceExternalPublisherConstants.PRODUCTID_ALLOWED_LENGTH, "0"));
			sendRecord.setProductid_Oud(StringUtils.leftPad(String.valueOf(publishContractHeaderInputDTO.getProductIdOld()), AgreementCustomerReferenceExternalPublisherConstants.PRODUCTID_ALLOWED_LENGTH, "0"));
			sendRecord.setBuildingblockid(publishContractHeaderInputDTO.getBuildingBlockId());
			sendRecord.setCommercial_Contrnr(publishContractHeaderInputDTO.getCommercialContractNumber());
			sendRecord.setTask_Id(publishContractHeaderInputDTO.getTaskId());			
			sendRecord.setChid_Parent(publishContractHeaderInputDTO.getContracheaderIdParent());
			sendRecord.setChid_Parent_Oud(publishContractHeaderInputDTO.getContractheaderParentOld());
			sendRecord.setChcontractstatus(publishContractHeaderInputDTO.getContractStatus());
			sendRecord.setChcontractstatus_Oud(publishContractHeaderInputDTO.getContractStatusOld());
			sendRecord.setUserid(publishContractHeaderInputDTO.getUserId());
		}
		return sendRecord;
	} 

	
	
	private void verifyResponse(MO856OUTPUTMSG recordReceive) throws AgreementCustomerReferenceExternalPublisherException {
		String logMethod = "populateContractHeaderId(recordReceive)";
		String resultaatCode = null;
		if(StringUtils.isNotBlank(recordReceive.getMo_Resultaatcode())){
			resultaatCode = recordReceive.getMo_Resultaatcode().trim();
		}
		 
		boolean noErrors = (AgreementCustomerReferenceExternalPublisherConstants.STRING_ZERO).equals(resultaatCode)
							|| (AgreementCustomerReferenceExternalPublisherConstants.STRING_ONE).equals(resultaatCode);

		if (!noErrors) {
			
			for (int i = 0; i < recordReceive.getMo_Aantal_Returncodes(); i++) {
					logHelper.error(logMethod, AgreementCustomerReferenceExternalPublisherLogConstants.LOG_RSLT_CODE_FAILURE + " return code from MO856 is " + recordReceive.getMo_Returncode(i));
			}
			throw new AgreementCustomerReferenceExternalPublisherException(AgreementCustomerReferenceExternalPublisherConstants.INTERNAL_SERVER_ERRROR, AgreementCustomerReferenceExternalPublisherConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} 
	}
	
} 
