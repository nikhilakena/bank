package com.abnamro.moa.generic.agreementcustomerreference.publisher.dao;

/**
* 
* This is used to store log constants for AgreementCustomerReferenceExternalPublisher
* 
*/
public final class AgreementCustomerReferenceExternalPublisherConstants {
	private AgreementCustomerReferenceExternalPublisherConstants() {}

	public static final String STRING_ZERO = "0";

	public static final String STRING_ONE = "1";

	public static final String STRING_SEVEN = "7";

	public static final String STRING_NINE = "9";
	
	public static final String CREATION_DATE_FORMAT = "yyDDDHHmmss";
	
	public static final String TRANSACTION_CODE_MO856T01 = "MO856T01";

	public static final int PRODUCTID_ALLOWED_LENGTH = 6;
	
	public static final String INTERNAL_SERVER_ERRROR = "500";
	
	public static final int INTERNAL_SERVER_ERRROR_HTTP_STATUS = 500;

	public static final int UPDATE_TYPE_CREATE = 7;

	public static final short SOURCE_ID = (short)4;

	public static final int OBJECT_TYPE = 18;

	public static final String SPACE = " ";

	public static final int INT_ZERO = 0;

	public static final int UPDATE_TYPE_UPDATE = 0;
	
	public static final int UPDATE_TYPE_DELETE = 1;
	
	public static final String PUBLISH_TYPE_CREATE = "C";
	
	public static final String PUBLISH_TYPE_UPDATE = "U";
	
	public static final String PUBLISH_TYPE_DELETE = "D";
	
}
