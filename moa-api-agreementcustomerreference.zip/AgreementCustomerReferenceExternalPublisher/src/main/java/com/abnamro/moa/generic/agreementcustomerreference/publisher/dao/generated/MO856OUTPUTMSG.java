package com.abnamro.moa.generic.agreementcustomerreference.publisher.dao.generated;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import com.ibm.etools.marshall.util.*;

/**
 * @generated
 * Generated Class: MOOUTPUTMSG
 * @type-descriptor.aggregate-instance-td accessor="readWrite" contentSize="580" offset="0" size="580"
 * @type-descriptor.platform-compiler-info language="COBOL" defaultBigEndian="true" defaultCodepage="ibm-037" defaultExternalDecimalSign="ebcdic" defaultFloatType="ibm390Hex"
 */

public class MO856OUTPUTMSG implements javax.resource.cci.Record,
		javax.resource.cci.Streamable, com.ibm.etools.marshall.RecordBytes {
	private static final long serialVersionUID = -2939596735230675148L;
	/**
	 * @generated
	 */
	private byte[] buffer_ = null;
	/**
	 * @generated
	 */
	private static final int bufferSize_;
	/**
	 * @generated
	 */
	private static final byte[] initializedBuffer_;
	/**
	 * @generated
	 */
	private static java.util.HashMap getterMap_ = null;
	/**
	 * @generated
	 */
	private java.util.HashMap valFieldNameMap_ = null;

	/**
	 * initializer
	 * @generated
	 */
	static {
		bufferSize_ = 580;
		initializedBuffer_ = new byte[bufferSize_];
		String mo_ResultaatcodeInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				mo_ResultaatcodeInitialValue, initializedBuffer_, 12,
				"ibm-037", 1, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		short zz_VeldInitialValue = (short) +0;
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(
				zz_VeldInitialValue, initializedBuffer_, 2, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		String mpp_BmpInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				mpp_BmpInitialValue, initializedBuffer_, 192, "ibm-037", 1,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String ims_Transakt_KodeInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				ims_Transakt_KodeInitialValue, initializedBuffer_, 4,
				"ibm-037", 8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String module_Afzender_AlgInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				module_Afzender_AlgInitialValue, initializedBuffer_, 182,
				"ibm-037", 10, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String progr_AfzenderInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				progr_AfzenderInitialValue, initializedBuffer_, 174, "ibm-037",
				8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String signaal_TekstInitialValue = " ";
		for (int index1 = 0; index1 < 4; index1++)
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					signaal_TekstInitialValue, initializedBuffer_,
					198 + (74 * index1), "ibm-037", 74,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String boodschapnummerInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				boodschapnummerInitialValue, initializedBuffer_, 494,
				"ibm-037", 6, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String mo_FoutboodschapInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				mo_FoutboodschapInitialValue, initializedBuffer_, 95,
				"ibm-037", 74, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String foutboodschapInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				foutboodschapInitialValue, initializedBuffer_, 500, "ibm-037",
				80, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String returncodeInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				returncodeInitialValue, initializedBuffer_, 193, "ibm-037", 4,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String soort_OpmaakInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				soort_OpmaakInitialValue, initializedBuffer_, 197, "ibm-037",
				1, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
	}

	/**
	 * constructor
	 * @generated
	 */
	public MO856OUTPUTMSG() {
		initialize();
	}

	/**
	 * constructor
	 * @generated
	 */
	public MO856OUTPUTMSG(java.util.HashMap valFieldNameMap) {
		valFieldNameMap_ = valFieldNameMap;
		initialize();
	}

	/**
	 * @generated
	 * initialize
	 */
	public void initialize() {
		buffer_ = new byte[bufferSize_];
		System.arraycopy(initializedBuffer_, 0, buffer_, 0, bufferSize_);
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Streamable#read(java.io.InputStream)
	 */
	public void read(java.io.InputStream inputStream)
			throws java.io.IOException {
		byte[] input = new byte[inputStream.available()];
		inputStream.read(input);
		buffer_ = input;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Streamable#write(java.io.OutputStream)
	 */
	public void write(java.io.OutputStream outputStream)
			throws java.io.IOException {
		outputStream.write(buffer_, 0, getSize());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#getRecordName()
	 */
	public String getRecordName() {
		return (this.getClass().getName());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#setRecordName(String)
	 */
	public void setRecordName(String recordName) {
		return;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#setRecordShortDescription(String)
	 */
	public void setRecordShortDescription(String shortDescription) {
		return;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#getRecordShortDescription()
	 */
	public String getRecordShortDescription() {
		return (this.getClass().getName());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#clone()
	 */
	public Object clone() throws CloneNotSupportedException {
		return (super.clone());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#equals
	 */
	public boolean equals(Object object) {
		return (super.equals(object));
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#hashCode
	 */
	public int hashCode() {
		return (super.hashCode());
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#getBytes
	 */
	public byte[] getBytes() {
		return (buffer_);
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#setBytes
	 */
	public void setBytes(byte[] bytes) {
		if ((bytes != null) && (bytes.length != 0))
			buffer_ = bytes;
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#getSize
	 */
	public int getSize() {
		return (580);
	}

	/**
	 * @generated
	 */
	public boolean match(Object obj) {
		if (obj == null)
			return (false);
		if (obj.getClass().isArray()) {
			byte[] currBytes = buffer_;
			try {
				byte[] objByteArray = (byte[]) obj;
				if (objByteArray.length != buffer_.length)
					return (false);
				buffer_ = objByteArray;
			} catch (ClassCastException exc) {
				return (false);
			} finally {
				buffer_ = currBytes;
			}
		} else
			return (false);
		return (true);
	}

	/**
	 * @generated
	 */
	public void populate(Object obj) {
		if (obj.getClass().isArray()) {
			try {
				buffer_ = (byte[]) obj;
			} catch (ClassCastException exc) {
			}
		}
	}

	/**
	 * @generated
	 * @see java.lang.Object#toString
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer(super.toString());
		sb.append("\n");
		ConversionUtils.dumpBytes(sb, buffer_);
		return (sb.toString());
	}

	/**
	 * @generated
	 * wrappedGetNumber
	 */
	public Number wrappedGetNumber(String propertyName) {
		Number result = null;

		if (getterMap_ == null) {
			synchronized (initializedBuffer_) {
				if (getterMap_ == null) {
					java.util.HashMap getterMap = new java.util.HashMap();
					try {
						BeanInfo info = Introspector.getBeanInfo(this
								.getClass());
						PropertyDescriptor[] props = info
								.getPropertyDescriptors();

						for (int i = 0; i < props.length; i++) {
							String propName = props[i].getName();
							getterMap.put(propName, props[i].getReadMethod());
						}
					} catch (IntrospectionException exc) {
					}
					getterMap_ = getterMap;
				}
			}
		}

		Method method = (Method) getterMap_.get(propertyName);
		if (method != null) {
			try {
				result = (Number) method.invoke(this, new Object[0]);
			} catch (Exception exc) {
			}
		}

		return (result);
	}

	/**
	 * @generated
	 * evaluateMap
	 */
	public java.util.HashMap evaluateMap(java.util.HashMap valFieldNameMap) {
		if (valFieldNameMap == null)
			return (null);
		java.util.HashMap returnMap = new java.util.HashMap(
				valFieldNameMap.size());
		java.util.Set aSet = valFieldNameMap.entrySet();

		for (java.util.Iterator cursor = aSet.iterator(); cursor.hasNext();) {
			java.util.Map.Entry element = (java.util.Map.Entry) cursor.next();
			String key = (String) element.getKey();
			String fieldName = (String) element.getValue();
			Number fieldValue = wrappedGetNumber(fieldName);
			if (fieldValue == null)
				fieldValue = new Integer(0);
			returnMap.put(key, fieldValue);
		}

		return (returnMap);
	}

	/**
	 * @generated
	 * Returns the integer value of the formula string for an offset or size.
	 * The formula can be comprised of the following functions:
	 * neg(x)   := -x       // prefix negate
	 * add(x,y) := x+y      // infix add
	 * sub(x,y) := x-y      // infix subtract
	 * mpy(x,y) := x*y      // infix multiply
	 * div(x,y) := x/y      // infix divide
	 * max(x,y) := max(x,y)
	 * min(x,y) := min(x,y)
	 *
	 * mod(x,y) := x mod y
	 *
	 * The mod function is defined as mod(x,y) = r where r is the smallest non-negative integer
	 * such that x-r is evenly divisible by y. So mod(7,4) is 3, but mod(-7,4) is 1. If y is a
	 * power of 2, then mod(x,y) is equal to the bitwise-and of x and y-1.
	 *
	 * val(1, m, n, o,..)
	 *
	 * The val function returns the value of a field in the model. The val function takes one
	 * or more arguments, and the first argument refers to a level-1 field in the type model and must be either:
	 *    - the name of a level-1 field described in the language model
	 *    - the integer 1 (indicating that the level-1 parent of the current structure is meant)
	 * If the first argument to the val function is the integer 1, then and only then are subsequent arguments
	 * permitted. These subsequent arguments are integers that the specify the ordinal number within its
	 * substructure of the subfield that should be dereferenced.
	 *
	 * @return The integer value of the formula string for an offset or size.
	 * @param formula The formula to be evaluated.
	 * @param valFieldNameMap A map of val() formulas to field names.
	 * @throws IllegalArgumentException if the formula is null.
	 */

	public int evaluateFormula(String formula, java.util.HashMap valFieldNameMap)
			throws IllegalArgumentException {
		if (formula == null)
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.MARSHRT_FORMULA_NULL));

		int result = 0;

		int index = formula.indexOf("(");

		if (index == -1) // It's a number not an expression
		{
			try {
				result = Integer.parseInt(formula);
			} catch (Exception exc) {
			}

			return (result);
		}

		// Determine the outermost function
		String function = formula.substring(0, index);

		if (function.equalsIgnoreCase("val")) {
			Object field = valFieldNameMap.get(formula);
			if (field == null)
				return (0);

			if (field instanceof String) {
				Number num = wrappedGetNumber((String) field);
				if (num == null) // Element does not exist
					return (0);
				result = num.intValue();
			} else if (field instanceof Number)
				result = ((Number) field).intValue();
			else
				return (0);

			return (result);
		} else if (function.equalsIgnoreCase("neg")) {
			// The new formula is the content between the brackets
			formula = formula.substring(index + 1, formula.length() - 1);
			result = -1 * evaluateFormula(formula, valFieldNameMap);
			return (result);
		} else {
			// Get the contents between the outermost brackets
			formula = formula.substring(index + 1, formula.length() - 1);
			char[] formulaChars = formula.toCharArray();

			// Get the left side and the right side of the operation

			int brackets = 0;
			int i = 0;

			for (; i < formulaChars.length; i++) {
				if (formulaChars[i] == '(')
					brackets++;
				else if (formulaChars[i] == ')')
					brackets--;
				else if (formulaChars[i] == ',') {
					if (brackets == 0)
						break;
				}
			}

			String leftSide = "0";
			String rightSide = "0";

			leftSide = formula.substring(0, i);
			rightSide = formula.substring(i + 1);

			if (function.equalsIgnoreCase("add"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						+ evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("mpy"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						* evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("sub"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						- evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("div"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						/ evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("max"))
				result = Math.max(evaluateFormula(leftSide, valFieldNameMap),
						evaluateFormula(rightSide, valFieldNameMap));
			else if (function.equalsIgnoreCase("min"))
				result = Math.min(evaluateFormula(leftSide, valFieldNameMap),
						evaluateFormula(rightSide, valFieldNameMap));
			else if (function.equalsIgnoreCase("mod"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						% evaluateFormula(rightSide, valFieldNameMap);
		}

		return (result);
	}

	/**
	 * @generated
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="0" size="2"
	 * @type-descriptor.integer-td signCoding="twosComplement"
	 */
	public short getLl_Veld() {
		short ll_Veld = 0;
		ll_Veld = MarshallIntegerUtils.unmarshallTwoByteIntegerFromBuffer(
				buffer_, 0, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		return (ll_Veld);
	}

	/**
	 * @generated
	 */
	public void setLl_Veld(short ll_Veld) {
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(ll_Veld, buffer_,
				0, true, MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
	}

	/**
	 * @generated
	 * @type-descriptor.initial-value kind="string_value" value="+0"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="2" size="2"
	 * @type-descriptor.integer-td signCoding="twosComplement"
	 */
	public short getZz_Veld() {
		short zz_Veld = 0;
		zz_Veld = MarshallIntegerUtils.unmarshallTwoByteIntegerFromBuffer(
				buffer_, 2, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		return (zz_Veld);
	}

	/**
	 * @generated
	 */
	public void setZz_Veld(short zz_Veld) {
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(zz_Veld, buffer_,
				2, true, MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="4" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getIms_Transakt_Kode() {
		String ims_Transakt_Kode = null;
		ims_Transakt_Kode = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 4, "ibm-037", 8);
		return (ims_Transakt_Kode);
	}

	/**
	 * @generated
	 */
	public void setIms_Transakt_Kode(String ims_Transakt_Kode) {
		if (ims_Transakt_Kode != null) {
			if (ims_Transakt_Kode.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								ims_Transakt_Kode, "8", "ims_Transakt_Kode"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					ims_Transakt_Kode, buffer_, 4, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="1"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="1" offset="12" size="1"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getMo_Resultaatcode() {
		String mo_Resultaatcode = null;
		mo_Resultaatcode = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 12, "ibm-037",
						1);
		return (mo_Resultaatcode);
	}

	/**
	 * @generated
	 */
	public void setMo_Resultaatcode(String mo_Resultaatcode) {
		if (mo_Resultaatcode != null) {
			if (mo_Resultaatcode.length() > 1)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								mo_Resultaatcode, "1", "mo_Resultaatcode"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					mo_Resultaatcode, buffer_, 12, "ibm-037", 1,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="99"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="13" size="2"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public short getMo_Aantal_Returncodes() {
		short mo_Aantal_Returncodes = 0;
		mo_Aantal_Returncodes = MarshallExternalDecimalUtils
				.unmarshallShortFromBuffer(
						buffer_,
						13,
						2,
						false,
						-1,
						MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (mo_Aantal_Returncodes);
	}

	/**
	 * @generated
	 */
	public void setMo_Aantal_Returncodes(short mo_Aantal_Returncodes) {
		if ((mo_Aantal_Returncodes < 0) || (mo_Aantal_Returncodes > 99))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Short.toString(mo_Aantal_Returncodes),
							"mo_Aantal_Returncodes", "0", "99"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(
				mo_Aantal_Returncodes, buffer_, 13, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="9999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="80" offset="15" size="80"
	 * @type-descriptor.array-td lowerBound="20" stride="4" upperBound="20"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public short[] getMo_Returncode() {
		int baseOffset = 15;
		int stride = 4;
		int upperBound = 20;
		short[] mo_Returncode = new short[upperBound];
		for (int i = 0; i < upperBound; i++) {
			short value;
			value = MarshallExternalDecimalUtils.unmarshallShortFromBuffer(
					buffer_, baseOffset + (stride * i), 4, false, -1,
					MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
			mo_Returncode[i] = value;
		}
		return (mo_Returncode);
	}

	/**
	 * @generated
	 */
	public void setMo_Returncode(short[] mo_Returncode) {
		int baseOffset = 15;
		int stride = 4;
		int upperBound = 20;
		if (mo_Returncode != null) {
			if (mo_Returncode.length < 20)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0122E, "mo_Returncode",
								"20"));
			if (mo_Returncode.length > upperBound)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0123E, "mo_Returncode",
								Integer.toString(upperBound)));
			for (int i = 0; i < mo_Returncode.length; i++)
				if ((mo_Returncode[i] < 0) || (mo_Returncode[i] > 9999))
					throw new IllegalArgumentException(MarshallResource
							.instance().getString(
									MarshallResource.IWAA0127E,
									Short.toString(mo_Returncode[i]),
									"mo_Returncode[" + Integer.toString(i)
											+ "]", "0", "9999"));
			int numElems = Math.min(mo_Returncode.length, upperBound);
			for (int i = 0; i < numElems; i++) {
				MarshallExternalDecimalUtils
						.marshallExternalDecimalIntoBuffer(
								mo_Returncode[i],
								buffer_,
								baseOffset + (stride * i),
								4,
								false,
								-1,
								MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
			}
		}
	}

	/**
	 * @generated
	 */
	public short getMo_Returncode(int index) {
		int upperBound = 20;
		if ((index < 0) || (index > upperBound - 1))
			throw new ArrayIndexOutOfBoundsException(index);
		int baseOffset = 15;
		int stride = 4;
		short mo_Returncode = 0;
		mo_Returncode = MarshallExternalDecimalUtils.unmarshallShortFromBuffer(
				buffer_, baseOffset + (stride * index), 4, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (mo_Returncode);
	}

	/**
	 * @generated
	 */
	public void setMo_Returncode(int index, short mo_Returncode) {
		int upperBound = 20;
		if ((index < 0) || (index > upperBound - 1))
			throw new ArrayIndexOutOfBoundsException(index);
		if ((mo_Returncode < 0) || (mo_Returncode > 9999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Short.toString(mo_Returncode), "mo_Returncode",
							"0", "9999"));
		int baseOffset = 15;
		int stride = 4;
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(
				mo_Returncode, buffer_, baseOffset + (stride * index), 4,
				false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="74"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="74" offset="95" size="74"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getMo_Foutboodschap() {
		String mo_Foutboodschap = null;
		mo_Foutboodschap = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 95, "ibm-037",
						74);
		return (mo_Foutboodschap);
	}

	/**
	 * @generated
	 */
	public void setMo_Foutboodschap(String mo_Foutboodschap) {
		if (mo_Foutboodschap != null) {
			if (mo_Foutboodschap.length() > 74)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								mo_Foutboodschap, "74", "mo_Foutboodschap"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					mo_Foutboodschap, buffer_, 95, "ibm-037", 74,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="99999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="5" offset="169" size="5"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public int getMo_Lengte_View() {
		int mo_Lengte_View = 0;
		mo_Lengte_View = MarshallExternalDecimalUtils.unmarshallIntFromBuffer(
				buffer_, 169, 5, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (mo_Lengte_View);
	}

	/**
	 * @generated
	 */
	public void setMo_Lengte_View(int mo_Lengte_View) {
		if ((mo_Lengte_View < 0) || (mo_Lengte_View > 99999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Integer.toString(mo_Lengte_View), "mo_Lengte_View",
							"0", "99999"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(
				mo_Lengte_View, buffer_, 169, 5, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="174" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getProgr_Afzender() {
		String progr_Afzender = null;
		progr_Afzender = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 174, "ibm-037",
						8);
		return (progr_Afzender);
	}

	/**
	 * @generated
	 */
	public void setProgr_Afzender(String progr_Afzender) {
		if (progr_Afzender != null) {
			if (progr_Afzender.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, progr_Afzender,
								"8", "progr_Afzender"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					progr_Afzender, buffer_, 174, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="10"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="10" offset="182" size="10"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getModule_Afzender_Alg() {
		String module_Afzender_Alg = null;
		module_Afzender_Alg = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 182, "ibm-037",
						10);
		return (module_Afzender_Alg);
	}

	/**
	 * @generated
	 */
	public void setModule_Afzender_Alg(String module_Afzender_Alg) {
		if (module_Afzender_Alg != null) {
			if (module_Afzender_Alg.length() > 10)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								module_Afzender_Alg, "10",
								"module_Afzender_Alg"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					module_Afzender_Alg, buffer_, 182, "ibm-037", 10,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="1"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="1" offset="192" size="1"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getMpp_Bmp() {
		String mpp_Bmp = null;
		mpp_Bmp = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 192, "ibm-037", 1);
		return (mpp_Bmp);
	}

	/**
	 * @generated
	 */
	public void setMpp_Bmp(String mpp_Bmp) {
		if (mpp_Bmp != null) {
			if (mpp_Bmp.length() > 1)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, mpp_Bmp, "1",
								"mpp_Bmp"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(mpp_Bmp,
					buffer_, 192, "ibm-037", 1,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="4"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="4" offset="193" size="4"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getReturncode() {
		String returncode = null;
		returncode = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 193, "ibm-037", 4);
		return (returncode);
	}

	/**
	 * @generated
	 */
	public void setReturncode(String returncode) {
		if (returncode != null) {
			if (returncode.length() > 4)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, returncode, "4",
								"returncode"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(returncode,
					buffer_, 193, "ibm-037", 4,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="1"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.level88 name="Call_Signaal" value="3"
	 * @type-descriptor.level88 name="Db2_Signaal" value="2"
	 * @type-descriptor.level88 name="Ims_Signaal" value="1"
	 * @type-descriptor.level88 name="Opgemaakt" value="0"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="1" offset="197" size="1"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getSoort_Opmaak() {
		String soort_Opmaak = null;
		soort_Opmaak = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 197, "ibm-037",
						1);
		return (soort_Opmaak);
	}

	/**
	 * @generated
	 */
	public void setSoort_Opmaak(String soort_Opmaak) {
		if (soort_Opmaak != null) {
			if (soort_Opmaak.length() > 1)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, soort_Opmaak,
								"1", "soort_Opmaak"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					soort_Opmaak, buffer_, 197, "ibm-037", 1,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 */
	public static String getCall_Signaal() {
		return ("3");
	}

	/**
	 * @generated
	 */
	public static boolean isCall_Signaal(String call_Signaal) {
		return ("3".equals(call_Signaal));
	}

	/**
	 * @generated
	 */
	public static String getDb2_Signaal() {
		return ("2");
	}

	/**
	 * @generated
	 */
	public static boolean isDb2_Signaal(String db2_Signaal) {
		return ("2".equals(db2_Signaal));
	}

	/**
	 * @generated
	 */
	public static String getIms_Signaal() {
		return ("1");
	}

	/**
	 * @generated
	 */
	public static boolean isIms_Signaal(String ims_Signaal) {
		return ("1".equals(ims_Signaal));
	}

	/**
	 * @generated
	 */
	public static String getOpgemaakt() {
		return ("0");
	}

	/**
	 * @generated
	 */
	public static boolean isOpgemaakt(String opgemaakt) {
		return ("0".equals(opgemaakt));
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="74"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="296" offset="198" size="296"
	 * @type-descriptor.array-td lowerBound="4" stride="74" upperBound="4"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String[] getSignaal_Tekst() {
		int baseOffset = 198;
		int stride = 74;
		int upperBound = 4;
		String[] signaal_Tekst = new String[upperBound];
		for (int i = 0; i < upperBound; i++) {
			String value;
			value = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
					buffer_, baseOffset + (stride * i), "ibm-037", 74);
			signaal_Tekst[i] = value;
		}
		return (signaal_Tekst);
	}

	/**
	 * @generated
	 */
	public void setSignaal_Tekst(String[] signaal_Tekst) {
		int baseOffset = 198;
		int stride = 74;
		int upperBound = 4;
		if (signaal_Tekst != null) {
			if (signaal_Tekst.length < 4)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0122E, "signaal_Tekst",
								"4"));
			if (signaal_Tekst.length > upperBound)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0123E, "signaal_Tekst",
								Integer.toString(upperBound)));
			for (int i = 0; i < signaal_Tekst.length; i++)
				if ((signaal_Tekst[i] != null)
						&& (signaal_Tekst[i].length() > 74))
					throw new IllegalArgumentException(MarshallResource
							.instance().getString(
									MarshallResource.IWAA0124E,
									signaal_Tekst[i],
									"74",
									"signaal_Tekst[" + Integer.toString(i)
											+ "]"));
			int numElems = Math.min(signaal_Tekst.length, upperBound);
			for (int i = 0; i < numElems; i++) {
				if (signaal_Tekst[i] == null)
					continue;
				MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
						signaal_Tekst[i], buffer_, baseOffset + (stride * i),
						"ibm-037", 74,
						MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
			}
		}
	}

	/**
	 * @generated
	 */
	public String getSignaal_Tekst(int index) {
		int upperBound = 4;
		if ((index < 0) || (index > upperBound - 1))
			throw new ArrayIndexOutOfBoundsException(index);
		int baseOffset = 198;
		int stride = 74;
		String signaal_Tekst = null;
		signaal_Tekst = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, baseOffset
						+ (stride * index), "ibm-037", 74);
		return (signaal_Tekst);
	}

	/**
	 * @generated
	 */
	public void setSignaal_Tekst(int index, String signaal_Tekst) {
		int upperBound = 4;
		if ((index < 0) || (index > upperBound - 1))
			throw new ArrayIndexOutOfBoundsException(index);
		if (signaal_Tekst != null) {
			if (signaal_Tekst.length() > 74)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, signaal_Tekst,
								"74", "signaal_Tekst"));
			int baseOffset = 198;
			int stride = 74;
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					signaal_Tekst, buffer_, baseOffset + (stride * index),
					"ibm-037", 74,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="14"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="14" offset="198" size="14"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getPcb_Naam() {
		String pcb_Naam = null;
		pcb_Naam = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 198, "ibm-037", 14);
		return (pcb_Naam);
	}

	/**
	 * @generated
	 */
	public void setPcb_Naam(String pcb_Naam) {
		if (pcb_Naam != null) {
			if (pcb_Naam.length() > 14)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, pcb_Naam, "14",
								"pcb_Naam"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(pcb_Naam,
					buffer_, 198, "ibm-037", 14,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="4"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="4" offset="212" size="4"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getCall_Functie() {
		String call_Functie = null;
		call_Functie = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 212, "ibm-037",
						4);
		return (call_Functie);
	}

	/**
	 * @generated
	 */
	public void setCall_Functie(String call_Functie) {
		if (call_Functie != null) {
			if (call_Functie.length() > 4)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, call_Functie,
								"4", "call_Functie"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					call_Functie, buffer_, 212, "ibm-037", 4,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="2"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="216" size="2"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getStatus_Code() {
		String status_Code = null;
		status_Code = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 216, "ibm-037",
						2);
		return (status_Code);
	}

	/**
	 * @generated
	 */
	public void setStatus_Code(String status_Code) {
		if (status_Code != null) {
			if (status_Code.length() > 2)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, status_Code,
								"2", "status_Code"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					status_Code, buffer_, 216, "ibm-037", 2,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="59"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="59" offset="218" size="59"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getVolledig_Pcb() {
		String volledig_Pcb = null;
		volledig_Pcb = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 218, "ibm-037",
						59);
		return (volledig_Pcb);
	}

	/**
	 * @generated
	 */
	public void setVolledig_Pcb(String volledig_Pcb) {
		if (volledig_Pcb != null) {
			if (volledig_Pcb.length() > 59)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, volledig_Pcb,
								"59", "volledig_Pcb"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					volledig_Pcb, buffer_, 218, "ibm-037", 59,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="59"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="118" offset="277" size="118"
	 * @type-descriptor.array-td lowerBound="2" stride="59" upperBound="2"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String[] getSsa_Info_Alg() {
		int baseOffset = 277;
		int stride = 59;
		int upperBound = 2;
		String[] ssa_Info_Alg = new String[upperBound];
		for (int i = 0; i < upperBound; i++) {
			String value;
			value = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
					buffer_, baseOffset + (stride * i), "ibm-037", 59);
			ssa_Info_Alg[i] = value;
		}
		return (ssa_Info_Alg);
	}

	/**
	 * @generated
	 */
	public void setSsa_Info_Alg(String[] ssa_Info_Alg) {
		int baseOffset = 277;
		int stride = 59;
		int upperBound = 2;
		if (ssa_Info_Alg != null) {
			if (ssa_Info_Alg.length < 2)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0122E, "ssa_Info_Alg",
								"2"));
			if (ssa_Info_Alg.length > upperBound)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0123E, "ssa_Info_Alg",
								Integer.toString(upperBound)));
			for (int i = 0; i < ssa_Info_Alg.length; i++)
				if ((ssa_Info_Alg[i] != null)
						&& (ssa_Info_Alg[i].length() > 59))
					throw new IllegalArgumentException(
							MarshallResource
									.instance()
									.getString(
											MarshallResource.IWAA0124E,
											ssa_Info_Alg[i],
											"59",
											"ssa_Info_Alg["
													+ Integer.toString(i) + "]"));
			int numElems = Math.min(ssa_Info_Alg.length, upperBound);
			for (int i = 0; i < numElems; i++) {
				if (ssa_Info_Alg[i] == null)
					continue;
				MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
						ssa_Info_Alg[i], buffer_, baseOffset + (stride * i),
						"ibm-037", 59,
						MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
			}
		}
	}

	/**
	 * @generated
	 */
	public String getSsa_Info_Alg(int index) {
		int upperBound = 2;
		if ((index < 0) || (index > upperBound - 1))
			throw new ArrayIndexOutOfBoundsException(index);
		int baseOffset = 277;
		int stride = 59;
		String ssa_Info_Alg = null;
		ssa_Info_Alg = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, baseOffset
						+ (stride * index), "ibm-037", 59);
		return (ssa_Info_Alg);
	}

	/**
	 * @generated
	 */
	public void setSsa_Info_Alg(int index, String ssa_Info_Alg) {
		int upperBound = 2;
		if ((index < 0) || (index > upperBound - 1))
			throw new ArrayIndexOutOfBoundsException(index);
		if (ssa_Info_Alg != null) {
			if (ssa_Info_Alg.length() > 59)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, ssa_Info_Alg,
								"59", "ssa_Info_Alg"));
			int baseOffset = 277;
			int stride = 59;
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					ssa_Info_Alg, buffer_, baseOffset + (stride * index),
					"ibm-037", 59,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="99"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="99" offset="395" size="99"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getFill_0() {
		String fill_0 = null;
		fill_0 = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 395, "ibm-037", 99);
		return (fill_0);
	}

	/**
	 * @generated
	 */
	public void setFill_0(String fill_0) {
		if (fill_0 != null) {
			if (fill_0.length() > 99)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, fill_0, "99",
								"fill_0"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(fill_0,
					buffer_, 395, "ibm-037", 99,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="136"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="136" offset="198" size="136"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getDb2_Sqlca() {
		String db2_Sqlca = null;
		db2_Sqlca = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 198, "ibm-037", 136);
		return (db2_Sqlca);
	}

	/**
	 * @generated
	 */
	public void setDb2_Sqlca(String db2_Sqlca) {
		if (db2_Sqlca != null) {
			if (db2_Sqlca.length() > 136)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, db2_Sqlca,
								"136", "db2_Sqlca"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(db2_Sqlca,
					buffer_, 198, "ibm-037", 136,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="10"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="10" offset="334" size="10"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getDb2_Functie() {
		String db2_Functie = null;
		db2_Functie = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 334, "ibm-037",
						10);
		return (db2_Functie);
	}

	/**
	 * @generated
	 */
	public void setDb2_Functie(String db2_Functie) {
		if (db2_Functie != null) {
			if (db2_Functie.length() > 10)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, db2_Functie,
								"10", "db2_Functie"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					db2_Functie, buffer_, 334, "ibm-037", 10,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="30"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="30" offset="344" size="30"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getDb2_Key() {
		String db2_Key = null;
		db2_Key = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 344, "ibm-037", 30);
		return (db2_Key);
	}

	/**
	 * @generated
	 */
	public void setDb2_Key(String db2_Key) {
		if (db2_Key != null) {
			if (db2_Key.length() > 30)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, db2_Key, "30",
								"db2_Key"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(db2_Key,
					buffer_, 344, "ibm-037", 30,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="120"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="120" offset="374" size="120"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getFill_1() {
		String fill_1 = null;
		fill_1 = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 374, "ibm-037", 120);
		return (fill_1);
	}

	/**
	 * @generated
	 */
	public void setFill_1(String fill_1) {
		if (fill_1 != null) {
			if (fill_1.length() > 120)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, fill_1, "120",
								"fill_1"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(fill_1,
					buffer_, 374, "ibm-037", 120,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="10"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="10" offset="198" size="10"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getMod_Fout() {
		String mod_Fout = null;
		mod_Fout = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 198, "ibm-037", 10);
		return (mod_Fout);
	}

	/**
	 * @generated
	 */
	public void setMod_Fout(String mod_Fout) {
		if (mod_Fout != null) {
			if (mod_Fout.length() > 10)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, mod_Fout, "10",
								"mod_Fout"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(mod_Fout,
					buffer_, 198, "ibm-037", 10,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="9999999999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="10" offset="208" size="10"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public long getMod_Resultaat_N() {
		long mod_Resultaat_N = 0;
		mod_Resultaat_N = MarshallExternalDecimalUtils
				.unmarshallLongFromBuffer(
						buffer_,
						208,
						10,
						false,
						-1,
						MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (mod_Resultaat_N);
	}

	/**
	 * @generated
	 */
	public void setMod_Resultaat_N(long mod_Resultaat_N) {
		if ((mod_Resultaat_N < 0L) || (mod_Resultaat_N > 9999999999L))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Long.toString(mod_Resultaat_N), "mod_Resultaat_N",
							"0", "9999999999"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(
				mod_Resultaat_N, buffer_, 208, 10, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="74"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="222" offset="218" size="222"
	 * @type-descriptor.array-td lowerBound="3" stride="74" upperBound="3"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String[] getMod_Toelichting() {
		int baseOffset = 218;
		int stride = 74;
		int upperBound = 3;
		String[] mod_Toelichting = new String[upperBound];
		for (int i = 0; i < upperBound; i++) {
			String value;
			value = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
					buffer_, baseOffset + (stride * i), "ibm-037", 74);
			mod_Toelichting[i] = value;
		}
		return (mod_Toelichting);
	}

	/**
	 * @generated
	 */
	public void setMod_Toelichting(String[] mod_Toelichting) {
		int baseOffset = 218;
		int stride = 74;
		int upperBound = 3;
		if (mod_Toelichting != null) {
			if (mod_Toelichting.length < 3)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0122E,
								"mod_Toelichting", "3"));
			if (mod_Toelichting.length > upperBound)
				throw new IllegalArgumentException(
						MarshallResource.instance().getString(
								MarshallResource.IWAA0123E, "mod_Toelichting",
								Integer.toString(upperBound)));
			for (int i = 0; i < mod_Toelichting.length; i++)
				if ((mod_Toelichting[i] != null)
						&& (mod_Toelichting[i].length() > 74))
					throw new IllegalArgumentException(MarshallResource
							.instance().getString(
									MarshallResource.IWAA0124E,
									mod_Toelichting[i],
									"74",
									"mod_Toelichting[" + Integer.toString(i)
											+ "]"));
			int numElems = Math.min(mod_Toelichting.length, upperBound);
			for (int i = 0; i < numElems; i++) {
				if (mod_Toelichting[i] == null)
					continue;
				MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
						mod_Toelichting[i], buffer_, baseOffset + (stride * i),
						"ibm-037", 74,
						MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
			}
		}
	}

	/**
	 * @generated
	 */
	public String getMod_Toelichting(int index) {
		int upperBound = 3;
		if ((index < 0) || (index > upperBound - 1))
			throw new ArrayIndexOutOfBoundsException(index);
		int baseOffset = 218;
		int stride = 74;
		String mod_Toelichting = null;
		mod_Toelichting = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, baseOffset
						+ (stride * index), "ibm-037", 74);
		return (mod_Toelichting);
	}

	/**
	 * @generated
	 */
	public void setMod_Toelichting(int index, String mod_Toelichting) {
		int upperBound = 3;
		if ((index < 0) || (index > upperBound - 1))
			throw new ArrayIndexOutOfBoundsException(index);
		if (mod_Toelichting != null) {
			if (mod_Toelichting.length() > 74)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, mod_Toelichting,
								"74", "mod_Toelichting"));
			int baseOffset = 218;
			int stride = 74;
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					mod_Toelichting, buffer_, baseOffset + (stride * index),
					"ibm-037", 74,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="54"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="54" offset="440" size="54"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getFill_2() {
		String fill_2 = null;
		fill_2 = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 440, "ibm-037", 54);
		return (fill_2);
	}

	/**
	 * @generated
	 */
	public void setFill_2(String fill_2) {
		if (fill_2 != null) {
			if (fill_2.length() > 54)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, fill_2, "54",
								"fill_2"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(fill_2,
					buffer_, 440, "ibm-037", 54,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="6"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="6" offset="494" size="6"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getBoodschapnummer() {
		String boodschapnummer = null;
		boodschapnummer = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 494, "ibm-037",
						6);
		return (boodschapnummer);
	}

	/**
	 * @generated
	 */
	public void setBoodschapnummer(String boodschapnummer) {
		if (boodschapnummer != null) {
			if (boodschapnummer.length() > 6)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, boodschapnummer,
								"6", "boodschapnummer"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					boodschapnummer, buffer_, 494, "ibm-037", 6,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="80"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="80" offset="500" size="80"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getFoutboodschap() {
		String foutboodschap = null;
		foutboodschap = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 500, "ibm-037",
						80);
		return (foutboodschap);
	}

	/**
	 * @generated
	 */
	public void setFoutboodschap(String foutboodschap) {
		if (foutboodschap != null) {
			if (foutboodschap.length() > 80)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, foutboodschap,
								"80", "foutboodschap"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					foutboodschap, buffer_, 500, "ibm-037", 80,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

}