package com.abnamro.moa.generic.agreementcustomerreference.publisher.dto;

import java.sql.Timestamp;

/**
 * This class contains relevant information related to contract header which is used for create contract header.
 * @author PA2619
 *
 */
public class PublishContractHeaderInputDTO {
	
	private long bcNumber;
	
	private long bcNumberOld;
	
	private String contractHeaderId; // Type check
	
	private int productId;
	
	private int productIdOld;
	
	private int buildingBlockId; // Type check
	
	private String commercialContractNumber;
	
	private int taskId;
	
	private String contracheaderIdParent;
	
	private String contractStatus;
	
	private String contractheaderParentOld;
	
	private String contractStatusOld;
	
	private String userId;
	
	private Timestamp lastModifiedDate;
	
	public long getBcNumber() {
		return bcNumber;
	}

	public void setBcNumber(long bcNumber) {
		this.bcNumber = bcNumber;
	}

	public String getContractHeaderId() {
		return contractHeaderId;
	}

	public void setContractHeaderId(String contractHeaderId) {
		this.contractHeaderId = contractHeaderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getBuildingBlockId() {
		return buildingBlockId;
	}

	public void setBuildingBlockId(int buildingBlockId) {
		this.buildingBlockId = buildingBlockId;
	}

	public String getCommercialContractNumber() {
		return commercialContractNumber;
	}

	public void setCommercialContractNumber(String commercialContractNumber) {
		this.commercialContractNumber = commercialContractNumber;
	}

	public long getBcNumberOld() {
		return bcNumberOld;
	}

	public void setBcNumberOld(long bcNumberOld) {
		this.bcNumberOld = bcNumberOld;
	}

	public int getProductIdOld() {
		return productIdOld;
	}

	public void setProductIdOld(int productIdOld) {
		this.productIdOld = productIdOld;
	}

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public String getContracheaderIdParent() {
		return contracheaderIdParent;
	}

	public void setContracheaderIdParent(String contracheaderParent) {
		this.contracheaderIdParent = contracheaderParent;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public String getContractheaderParentOld() {
		return contractheaderParentOld;
	}

	public void setContractheaderParentOld(String contractheaderParentOld) {
		this.contractheaderParentOld = contractheaderParentOld;
	}

	public String getContractStatusOld() {
		return contractStatusOld;
	}

	public void setContractStatusOld(String contractStatusOld) {
		this.contractStatusOld = contractStatusOld;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
}
