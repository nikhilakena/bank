package com.abnamro.moa.generic.agreementcustomerreference.publisher.dao;

/**
* 
* This is used to store log constants for AgreementCustomerReferenceExternalPublisher
*/
public final class AgreementCustomerReferenceExternalPublisherLogConstants {
	private AgreementCustomerReferenceExternalPublisherLogConstants() {}

	public static final String LOG_IMS_EXCEPTION_IN_MO_PUBLISH = "LOG_AGPUB_001";
	
	public static final String LOG_RSLT_CODE_FAILURE_OR_NO_RESULTS = "LOG_AGPUB_002";

	public static final String LOG_RSLT_CODE_FAILURE = "LOG_AGPUB_003";
}
