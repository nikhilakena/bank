package com.abnamro.moa.generic.agreementcustomerreference.publisher.dao.generated;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import com.ibm.etools.marshall.util.*;

/**
 * @generated
 * Generated Class: MOINPUTMSG
 * @type-descriptor.aggregate-instance-td accessor="readWrite" contentSize="232" offset="0" size="232"
 * @type-descriptor.platform-compiler-info language="COBOL" defaultBigEndian="true" defaultCodepage="ibm-037" defaultExternalDecimalSign="ebcdic" defaultFloatType="ibm390Hex"
 */

public class MO856INPUTMSG implements javax.resource.cci.Record,
		javax.resource.cci.Streamable, com.ibm.etools.marshall.RecordBytes {
	private static final long serialVersionUID = 5097664534829775684L;
	/**
	 * @generated
	 */
	private byte[] buffer_ = null;
	/**
	 * @generated
	 */
	private static final int bufferSize_;
	/**
	 * @generated
	 */
	private static final byte[] initializedBuffer_;
	/**
	 * @generated
	 */
	private static java.util.HashMap getterMap_ = null;
	/**
	 * @generated
	 */
	private java.util.HashMap valFieldNameMap_ = null;

	/**
	 * initializer
	 * @generated
	 */
	static {
		bufferSize_ = 232;
		initializedBuffer_ = new byte[bufferSize_];
		String data_Structure_DefinitionInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				data_Structure_DefinitionInitialValue, initializedBuffer_, 143,
				"ibm-037", 8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		short zz_VeldInitialValue = (short) +0;
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(
				zz_VeldInitialValue, initializedBuffer_, 2, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		String ims_Transakt_KodeInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				ims_Transakt_KodeInitialValue, initializedBuffer_, 4,
				"ibm-037", 8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String mo_DestinationInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				mo_DestinationInitialValue, initializedBuffer_, 16, "ibm-037",
				8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String effective_DateInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				effective_DateInitialValue, initializedBuffer_, 86, "ibm-037",
				26, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String previous_TimestampInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				previous_TimestampInitialValue, initializedBuffer_, 60,
				"ibm-037", 26, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String useridInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				useridInitialValue, initializedBuffer_, 120, "ibm-037", 12,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String chid_Parent_OudInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				chid_Parent_OudInitialValue, initializedBuffer_, 222,
				"ibm-037", 9, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String chcontractstatus_OudInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				chcontractstatus_OudInitialValue, initializedBuffer_, 231,
				"ibm-037", 1, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String sourcecomponentidInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				sourcecomponentidInitialValue, initializedBuffer_, 112,
				"ibm-037", 8, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String commercial_ContrnrInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				commercial_ContrnrInitialValue, initializedBuffer_, 178,
				"ibm-037", 16, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String productid_OudInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				productid_OudInitialValue, initializedBuffer_, 201, "ibm-037",
				6, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String productidInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				productidInitialValue, initializedBuffer_, 167, "ibm-037", 6,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String contractheaderidInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				contractheaderidInitialValue, initializedBuffer_, 158,
				"ibm-037", 9, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String fill_0InitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				fill_0InitialValue, initializedBuffer_, 12, "ibm-037", 1,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String new_TimestampInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				new_TimestampInitialValue, initializedBuffer_, 34, "ibm-037",
				26, MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		String chcontractstatusInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				chcontractstatusInitialValue, initializedBuffer_, 221,
				"ibm-037", 1, MarshallStringUtils.STRING_JUSTIFICATION_LEFT,
				" ");
		String chid_ParentInitialValue = " ";
		MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
				chid_ParentInitialValue, initializedBuffer_, 212, "ibm-037", 9,
				MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
	}

	/**
	 * constructor
	 * @generated
	 */
	public MO856INPUTMSG() {
		initialize();
	}

	/**
	 * constructor
	 * @generated
	 */
	public MO856INPUTMSG(java.util.HashMap valFieldNameMap) {
		valFieldNameMap_ = valFieldNameMap;
		initialize();
	}

	/**
	 * @generated
	 * initialize
	 */
	public void initialize() {
		buffer_ = new byte[bufferSize_];
		System.arraycopy(initializedBuffer_, 0, buffer_, 0, bufferSize_);
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Streamable#read(java.io.InputStream)
	 */
	public void read(java.io.InputStream inputStream)
			throws java.io.IOException {
		byte[] input = new byte[inputStream.available()];
		inputStream.read(input);
		buffer_ = input;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Streamable#write(java.io.OutputStream)
	 */
	public void write(java.io.OutputStream outputStream)
			throws java.io.IOException {
		outputStream.write(buffer_, 0, getSize());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#getRecordName()
	 */
	public String getRecordName() {
		return (this.getClass().getName());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#setRecordName(String)
	 */
	public void setRecordName(String recordName) {
		return;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#setRecordShortDescription(String)
	 */
	public void setRecordShortDescription(String shortDescription) {
		return;
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#getRecordShortDescription()
	 */
	public String getRecordShortDescription() {
		return (this.getClass().getName());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#clone()
	 */
	public Object clone() throws CloneNotSupportedException {
		return (super.clone());
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#equals
	 */
	public boolean equals(Object object) {
		return (super.equals(object));
	}

	/**
	 * @generated
	 * @see javax.resource.cci.Record#hashCode
	 */
	public int hashCode() {
		return (super.hashCode());
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#getBytes
	 */
	public byte[] getBytes() {
		return (buffer_);
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#setBytes
	 */
	public void setBytes(byte[] bytes) {
		if ((bytes != null) && (bytes.length != 0))
			buffer_ = bytes;
	}

	/**
	 * @generated
	 * @see com.ibm.etools.marshall.RecordBytes#getSize
	 */
	public int getSize() {
		return (232);
	}

	/**
	 * @generated
	 */
	public boolean match(Object obj) {
		if (obj == null)
			return (false);
		if (obj.getClass().isArray()) {
			byte[] currBytes = buffer_;
			try {
				byte[] objByteArray = (byte[]) obj;
				if (objByteArray.length != buffer_.length)
					return (false);
				buffer_ = objByteArray;
			} catch (ClassCastException exc) {
				return (false);
			} finally {
				buffer_ = currBytes;
			}
		} else
			return (false);
		return (true);
	}

	/**
	 * @generated
	 */
	public void populate(Object obj) {
		if (obj.getClass().isArray()) {
			try {
				buffer_ = (byte[]) obj;
			} catch (ClassCastException exc) {
			}
		}
	}

	/**
	 * @generated
	 * @see java.lang.Object#toString
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer(super.toString());
		sb.append("\n");
		ConversionUtils.dumpBytes(sb, buffer_);
		return (sb.toString());
	}

	/**
	 * @generated
	 * wrappedGetNumber
	 */
	public Number wrappedGetNumber(String propertyName) {
		Number result = null;

		if (getterMap_ == null) {
			synchronized (initializedBuffer_) {
				if (getterMap_ == null) {
					java.util.HashMap getterMap = new java.util.HashMap();
					try {
						BeanInfo info = Introspector.getBeanInfo(this
								.getClass());
						PropertyDescriptor[] props = info
								.getPropertyDescriptors();

						for (int i = 0; i < props.length; i++) {
							String propName = props[i].getName();
							getterMap.put(propName, props[i].getReadMethod());
						}
					} catch (IntrospectionException exc) {
					}
					getterMap_ = getterMap;
				}
			}
		}

		Method method = (Method) getterMap_.get(propertyName);
		if (method != null) {
			try {
				result = (Number) method.invoke(this, new Object[0]);
			} catch (Exception exc) {
			}
		}

		return (result);
	}

	/**
	 * @generated
	 * evaluateMap
	 */
	public java.util.HashMap evaluateMap(java.util.HashMap valFieldNameMap) {
		if (valFieldNameMap == null)
			return (null);
		java.util.HashMap returnMap = new java.util.HashMap(
				valFieldNameMap.size());
		java.util.Set aSet = valFieldNameMap.entrySet();

		for (java.util.Iterator cursor = aSet.iterator(); cursor.hasNext();) {
			java.util.Map.Entry element = (java.util.Map.Entry) cursor.next();
			String key = (String) element.getKey();
			String fieldName = (String) element.getValue();
			Number fieldValue = wrappedGetNumber(fieldName);
			if (fieldValue == null)
				fieldValue = new Integer(0);
			returnMap.put(key, fieldValue);
		}

		return (returnMap);
	}

	/**
	 * @generated
	 * Returns the integer value of the formula string for an offset or size.
	 * The formula can be comprised of the following functions:
	 * neg(x)   := -x       // prefix negate
	 * add(x,y) := x+y      // infix add
	 * sub(x,y) := x-y      // infix subtract
	 * mpy(x,y) := x*y      // infix multiply
	 * div(x,y) := x/y      // infix divide
	 * max(x,y) := max(x,y)
	 * min(x,y) := min(x,y)
	 *
	 * mod(x,y) := x mod y
	 *
	 * The mod function is defined as mod(x,y) = r where r is the smallest non-negative integer
	 * such that x-r is evenly divisible by y. So mod(7,4) is 3, but mod(-7,4) is 1. If y is a
	 * power of 2, then mod(x,y) is equal to the bitwise-and of x and y-1.
	 *
	 * val(1, m, n, o,..)
	 *
	 * The val function returns the value of a field in the model. The val function takes one
	 * or more arguments, and the first argument refers to a level-1 field in the type model and must be either:
	 *    - the name of a level-1 field described in the language model
	 *    - the integer 1 (indicating that the level-1 parent of the current structure is meant)
	 * If the first argument to the val function is the integer 1, then and only then are subsequent arguments
	 * permitted. These subsequent arguments are integers that the specify the ordinal number within its
	 * substructure of the subfield that should be dereferenced.
	 *
	 * @return The integer value of the formula string for an offset or size.
	 * @param formula The formula to be evaluated.
	 * @param valFieldNameMap A map of val() formulas to field names.
	 * @throws IllegalArgumentException if the formula is null.
	 */

	public int evaluateFormula(String formula, java.util.HashMap valFieldNameMap)
			throws IllegalArgumentException {
		if (formula == null)
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.MARSHRT_FORMULA_NULL));

		int result = 0;

		int index = formula.indexOf("(");

		if (index == -1) // It's a number not an expression
		{
			try {
				result = Integer.parseInt(formula);
			} catch (Exception exc) {
			}

			return (result);
		}

		// Determine the outermost function
		String function = formula.substring(0, index);

		if (function.equalsIgnoreCase("val")) {
			Object field = valFieldNameMap.get(formula);
			if (field == null)
				return (0);

			if (field instanceof String) {
				Number num = wrappedGetNumber((String) field);
				if (num == null) // Element does not exist
					return (0);
				result = num.intValue();
			} else if (field instanceof Number)
				result = ((Number) field).intValue();
			else
				return (0);

			return (result);
		} else if (function.equalsIgnoreCase("neg")) {
			// The new formula is the content between the brackets
			formula = formula.substring(index + 1, formula.length() - 1);
			result = -1 * evaluateFormula(formula, valFieldNameMap);
			return (result);
		} else {
			// Get the contents between the outermost brackets
			formula = formula.substring(index + 1, formula.length() - 1);
			char[] formulaChars = formula.toCharArray();

			// Get the left side and the right side of the operation

			int brackets = 0;
			int i = 0;

			for (; i < formulaChars.length; i++) {
				if (formulaChars[i] == '(')
					brackets++;
				else if (formulaChars[i] == ')')
					brackets--;
				else if (formulaChars[i] == ',') {
					if (brackets == 0)
						break;
				}
			}

			String leftSide = "0";
			String rightSide = "0";

			leftSide = formula.substring(0, i);
			rightSide = formula.substring(i + 1);

			if (function.equalsIgnoreCase("add"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						+ evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("mpy"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						* evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("sub"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						- evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("div"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						/ evaluateFormula(rightSide, valFieldNameMap);
			else if (function.equalsIgnoreCase("max"))
				result = Math.max(evaluateFormula(leftSide, valFieldNameMap),
						evaluateFormula(rightSide, valFieldNameMap));
			else if (function.equalsIgnoreCase("min"))
				result = Math.min(evaluateFormula(leftSide, valFieldNameMap),
						evaluateFormula(rightSide, valFieldNameMap));
			else if (function.equalsIgnoreCase("mod"))
				result = evaluateFormula(leftSide, valFieldNameMap)
						% evaluateFormula(rightSide, valFieldNameMap);
		}

		return (result);
	}

	/**
	 * @generated
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="0" size="2"
	 * @type-descriptor.integer-td signCoding="twosComplement"
	 */
	public short getLl_Veld() {
		short ll_Veld = 0;
		ll_Veld = MarshallIntegerUtils.unmarshallTwoByteIntegerFromBuffer(
				buffer_, 0, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		return (ll_Veld);
	}

	/**
	 * @generated
	 */
	public void setLl_Veld(short ll_Veld) {
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(ll_Veld, buffer_,
				0, true, MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
	}

	/**
	 * @generated
	 * @type-descriptor.initial-value kind="string_value" value="+0"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="2" size="2"
	 * @type-descriptor.integer-td signCoding="twosComplement"
	 */
	public short getZz_Veld() {
		short zz_Veld = 0;
		zz_Veld = MarshallIntegerUtils.unmarshallTwoByteIntegerFromBuffer(
				buffer_, 2, true,
				MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
		return (zz_Veld);
	}

	/**
	 * @generated
	 */
	public void setZz_Veld(short zz_Veld) {
		MarshallIntegerUtils.marshallTwoByteIntegerIntoBuffer(zz_Veld, buffer_,
				2, true, MarshallIntegerUtils.SIGN_CODING_TWOS_COMPLEMENT);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="4" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getIms_Transakt_Kode() {
		String ims_Transakt_Kode = null;
		ims_Transakt_Kode = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 4, "ibm-037", 8);
		return (ims_Transakt_Kode);
	}

	/**
	 * @generated
	 */
	public void setIms_Transakt_Kode(String ims_Transakt_Kode) {
		if (ims_Transakt_Kode != null) {
			if (ims_Transakt_Kode.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								ims_Transakt_Kode, "8", "ims_Transakt_Kode"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					ims_Transakt_Kode, buffer_, 4, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="1"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="1" offset="12" size="1"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getFill_0() {
		String fill_0 = null;
		fill_0 = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 12, "ibm-037", 1);
		return (fill_0);
	}

	/**
	 * @generated
	 */
	public void setFill_0(String fill_0) {
		if (fill_0 != null) {
			if (fill_0.length() > 1)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, fill_0, "1",
								"fill_0"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(fill_0,
					buffer_, 12, "ibm-037", 1,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="-99999" upperBound="99999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="3" offset="13" size="3"
	 * @type-descriptor.packed-decimal-td
	 */
	public int getUpdatetype() {
		int updatetype = 0;
		updatetype = MarshallPackedDecimalUtils.unmarshallIntFromBuffer(
				buffer_, 13, 3);
		return (updatetype);
	}

	/**
	 * @generated
	 */
	public void setUpdatetype(int updatetype) {
		if ((updatetype < -99999) || (updatetype > 99999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Integer.toString(updatetype), "updatetype",
							"-99999", "99999"));
		MarshallPackedDecimalUtils.marshallPackedDecimalIntoBuffer(updatetype,
				buffer_, 13, 3, true);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="16" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getMo_Destination() {
		String mo_Destination = null;
		mo_Destination = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 16, "ibm-037",
						8);
		return (mo_Destination);
	}

	/**
	 * @generated
	 */
	public void setMo_Destination(String mo_Destination) {
		if (mo_Destination != null) {
			if (mo_Destination.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, mo_Destination,
								"8", "mo_Destination"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					mo_Destination, buffer_, 16, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="99"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="2" offset="24" size="2"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public short getSourceid() {
		short sourceid = 0;
		sourceid = MarshallExternalDecimalUtils.unmarshallShortFromBuffer(
				buffer_, 24, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (sourceid);
	}

	/**
	 * @generated
	 */
	public void setSourceid(short sourceid) {
		if ((sourceid < 0) || (sourceid > 99))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Short.toString(sourceid), "sourceid", "0", "99"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(
				sourceid, buffer_, 24, 2, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="-99999" upperBound="99999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="3" offset="26" size="3"
	 * @type-descriptor.packed-decimal-td
	 */
	public int getChanged_Obj_Type() {
		int changed_Obj_Type = 0;
		changed_Obj_Type = MarshallPackedDecimalUtils.unmarshallIntFromBuffer(
				buffer_, 26, 3);
		return (changed_Obj_Type);
	}

	/**
	 * @generated
	 */
	public void setChanged_Obj_Type(int changed_Obj_Type) {
		if ((changed_Obj_Type < -99999) || (changed_Obj_Type > 99999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Integer.toString(changed_Obj_Type),
							"changed_Obj_Type", "-99999", "99999"));
		MarshallPackedDecimalUtils.marshallPackedDecimalIntoBuffer(
				changed_Obj_Type, buffer_, 26, 3, true);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="-999999999" upperBound="999999999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="5" offset="29" size="5"
	 * @type-descriptor.packed-decimal-td
	 */
	public int getPubmessage_Length() {
		int pubmessage_Length = 0;
		pubmessage_Length = MarshallPackedDecimalUtils.unmarshallIntFromBuffer(
				buffer_, 29, 5);
		return (pubmessage_Length);
	}

	/**
	 * @generated
	 */
	public void setPubmessage_Length(int pubmessage_Length) {
		if ((pubmessage_Length < -999999999) || (pubmessage_Length > 999999999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Integer.toString(pubmessage_Length),
							"pubmessage_Length", "-999999999", "999999999"));
		MarshallPackedDecimalUtils.marshallPackedDecimalIntoBuffer(
				pubmessage_Length, buffer_, 29, 5, true);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="26"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="26" offset="34" size="26"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getNew_Timestamp() {
		String new_Timestamp = null;
		new_Timestamp = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 34, "ibm-037",
						26);
		return (new_Timestamp);
	}

	/**
	 * @generated
	 */
	public void setNew_Timestamp(String new_Timestamp) {
		if (new_Timestamp != null) {
			if (new_Timestamp.length() > 26)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, new_Timestamp,
								"26", "new_Timestamp"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					new_Timestamp, buffer_, 34, "ibm-037", 26,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="26"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="26" offset="60" size="26"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getPrevious_Timestamp() {
		String previous_Timestamp = null;
		previous_Timestamp = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 60, "ibm-037",
						26);
		return (previous_Timestamp);
	}

	/**
	 * @generated
	 */
	public void setPrevious_Timestamp(String previous_Timestamp) {
		if (previous_Timestamp != null) {
			if (previous_Timestamp.length() > 26)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								previous_Timestamp, "26", "previous_Timestamp"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					previous_Timestamp, buffer_, 60, "ibm-037", 26,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="26"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="26" offset="86" size="26"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getEffective_Date() {
		String effective_Date = null;
		effective_Date = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 86, "ibm-037",
						26);
		return (effective_Date);
	}

	/**
	 * @generated
	 */
	public void setEffective_Date(String effective_Date) {
		if (effective_Date != null) {
			if (effective_Date.length() > 26)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, effective_Date,
								"26", "effective_Date"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					effective_Date, buffer_, 86, "ibm-037", 26,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="112" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getSourcecomponentid() {
		String sourcecomponentid = null;
		sourcecomponentid = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 112, "ibm-037",
						8);
		return (sourcecomponentid);
	}

	/**
	 * @generated
	 */
	public void setSourcecomponentid(String sourcecomponentid) {
		if (sourcecomponentid != null) {
			if (sourcecomponentid.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								sourcecomponentid, "8", "sourcecomponentid"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					sourcecomponentid, buffer_, 112, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="12"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="12" offset="120" size="12"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getUserid() {
		String userid = null;
		userid = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 120, "ibm-037", 12);
		return (userid);
	}

	/**
	 * @generated
	 */
	public void setUserid(String userid) {
		if (userid != null) {
			if (userid.length() > 12)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, userid, "12",
								"userid"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(userid,
					buffer_, 120, "ibm-037", 12,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="-999999999" upperBound="999999999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="5" offset="132" size="5"
	 * @type-descriptor.packed-decimal-td
	 */
	public int getProcessid() {
		int processid = 0;
		processid = MarshallPackedDecimalUtils.unmarshallIntFromBuffer(buffer_,
				132, 5);
		return (processid);
	}

	/**
	 * @generated
	 */
	public void setProcessid(int processid) {
		if ((processid < -999999999) || (processid > 999999999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Integer.toString(processid), "processid",
							"-999999999", "999999999"));
		MarshallPackedDecimalUtils.marshallPackedDecimalIntoBuffer(processid,
				buffer_, 132, 5, true);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="-99999" upperBound="99999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="3" offset="137" size="3"
	 * @type-descriptor.packed-decimal-td
	 */
	public int getSegment_Sequence_Number() {
		int segment_Sequence_Number = 0;
		segment_Sequence_Number = MarshallPackedDecimalUtils
				.unmarshallIntFromBuffer(buffer_, 137, 3);
		return (segment_Sequence_Number);
	}

	/**
	 * @generated
	 */
	public void setSegment_Sequence_Number(int segment_Sequence_Number) {
		if ((segment_Sequence_Number < -99999)
				|| (segment_Sequence_Number > 99999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Integer.toString(segment_Sequence_Number),
							"segment_Sequence_Number", "-99999", "99999"));
		MarshallPackedDecimalUtils.marshallPackedDecimalIntoBuffer(
				segment_Sequence_Number, buffer_, 137, 3, true);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="-99999" upperBound="99999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="3" offset="140" size="3"
	 * @type-descriptor.packed-decimal-td
	 */
	public int getReason_Code() {
		int reason_Code = 0;
		reason_Code = MarshallPackedDecimalUtils.unmarshallIntFromBuffer(
				buffer_, 140, 3);
		return (reason_Code);
	}

	/**
	 * @generated
	 */
	public void setReason_Code(int reason_Code) {
		if ((reason_Code < -99999) || (reason_Code > 99999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Integer.toString(reason_Code), "reason_Code",
							"-99999", "99999"));
		MarshallPackedDecimalUtils.marshallPackedDecimalIntoBuffer(reason_Code,
				buffer_, 140, 3, true);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="8"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="8" offset="143" size="8"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getData_Structure_Definition() {
		String data_Structure_Definition = null;
		data_Structure_Definition = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 143, "ibm-037",
						8);
		return (data_Structure_Definition);
	}

	/**
	 * @generated
	 */
	public void setData_Structure_Definition(String data_Structure_Definition) {
		if (data_Structure_Definition != null) {
			if (data_Structure_Definition.length() > 8)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								data_Structure_Definition, "8",
								"data_Structure_Definition"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					data_Structure_Definition, buffer_, 143, "ibm-037", 8,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="-9999999999999" upperBound="9999999999999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="7" offset="151" size="7"
	 * @type-descriptor.packed-decimal-td
	 */
	public long getMgbuscontnr() {
		long mgbuscontnr = 0;
		mgbuscontnr = MarshallPackedDecimalUtils.unmarshallLongFromBuffer(
				buffer_, 151, 7);
		return (mgbuscontnr);
	}

	/**
	 * @generated
	 */
	public void setMgbuscontnr(long mgbuscontnr) {
		if ((mgbuscontnr < -9999999999999L) || (mgbuscontnr > 9999999999999L))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Long.toString(mgbuscontnr), "mgbuscontnr",
							"-9999999999999", "9999999999999"));
		MarshallPackedDecimalUtils.marshallPackedDecimalIntoBuffer(mgbuscontnr,
				buffer_, 151, 7, true);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="9"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="9" offset="158" size="9"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getContractheaderid() {
		String contractheaderid = null;
		contractheaderid = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 158, "ibm-037",
						9);
		return (contractheaderid);
	}

	/**
	 * @generated
	 */
	public void setContractheaderid(String contractheaderid) {
		if (contractheaderid != null) {
			if (contractheaderid.length() > 9)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								contractheaderid, "9", "contractheaderid"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					contractheaderid, buffer_, 158, "ibm-037", 9,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="6"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="6" offset="167" size="6"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getProductid() {
		String productid = null;
		productid = MarshallStringUtils.unmarshallFixedLengthStringFromBuffer(
				buffer_, 167, "ibm-037", 6);
		return (productid);
	}

	/**
	 * @generated
	 */
	public void setProductid(String productid) {
		if (productid != null) {
			if (productid.length() > 6)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, productid, "6",
								"productid"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(productid,
					buffer_, 167, "ibm-037", 6,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="0" upperBound="99999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="5" offset="173" size="5"
	 * @type-descriptor.external-decimal-td signed="false" signFormat="trailing"
	 */
	public int getBuildingblockid() {
		int buildingblockid = 0;
		buildingblockid = MarshallExternalDecimalUtils.unmarshallIntFromBuffer(
				buffer_, 173, 5, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (buildingblockid);
	}

	/**
	 * @generated
	 */
	public void setBuildingblockid(int buildingblockid) {
		if ((buildingblockid < 0) || (buildingblockid > 99999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Integer.toString(buildingblockid),
							"buildingblockid", "0", "99999"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(
				buildingblockid, buffer_, 173, 5, false, -1,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="16"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="16" offset="178" size="16"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getCommercial_Contrnr() {
		String commercial_Contrnr = null;
		commercial_Contrnr = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 178, "ibm-037",
						16);
		return (commercial_Contrnr);
	}

	/**
	 * @generated
	 */
	public void setCommercial_Contrnr(String commercial_Contrnr) {
		if (commercial_Contrnr != null) {
			if (commercial_Contrnr.length() > 16)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								commercial_Contrnr, "16", "commercial_Contrnr"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					commercial_Contrnr, buffer_, 178, "ibm-037", 16,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="-9999999999999" upperBound="9999999999999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="7" offset="194" size="7"
	 * @type-descriptor.packed-decimal-td
	 */
	public long getMgbuscontnr_Oud() {
		long mgbuscontnr_Oud = 0;
		mgbuscontnr_Oud = MarshallPackedDecimalUtils.unmarshallLongFromBuffer(
				buffer_, 194, 7);
		return (mgbuscontnr_Oud);
	}

	/**
	 * @generated
	 */
	public void setMgbuscontnr_Oud(long mgbuscontnr_Oud) {
		if ((mgbuscontnr_Oud < -9999999999999L)
				|| (mgbuscontnr_Oud > 9999999999999L))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Long.toString(mgbuscontnr_Oud), "mgbuscontnr_Oud",
							"-9999999999999", "9999999999999"));
		MarshallPackedDecimalUtils.marshallPackedDecimalIntoBuffer(
				mgbuscontnr_Oud, buffer_, 194, 7, true);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="6"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="6" offset="201" size="6"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getProductid_Oud() {
		String productid_Oud = null;
		productid_Oud = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 201, "ibm-037",
						6);
		return (productid_Oud);
	}

	/**
	 * @generated
	 */
	public void setProductid_Oud(String productid_Oud) {
		if (productid_Oud != null) {
			if (productid_Oud.length() > 6)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, productid_Oud,
								"6", "productid_Oud"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					productid_Oud, buffer_, 201, "ibm-037", 6,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction lowerBound="-99999" upperBound="99999"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="5" offset="207" size="5"
	 * @type-descriptor.external-decimal-td signFormat="trailing"
	 */
	public int getTask_Id() {
		int task_Id = 0;
		task_Id = MarshallExternalDecimalUtils.unmarshallIntFromBuffer(buffer_,
				207, 5, true,
				MarshallExternalDecimalUtils.SIGN_FORMAT_TRAILING,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
		return (task_Id);
	}

	/**
	 * @generated
	 */
	public void setTask_Id(int task_Id) {
		if ((task_Id < -99999) || (task_Id > 99999))
			throw new IllegalArgumentException(MarshallResource.instance()
					.getString(MarshallResource.IWAA0127E,
							Integer.toString(task_Id), "task_Id", "-99999",
							"99999"));
		MarshallExternalDecimalUtils.marshallExternalDecimalIntoBuffer(task_Id,
				buffer_, 207, 5, true,
				MarshallExternalDecimalUtils.SIGN_FORMAT_TRAILING,
				MarshallExternalDecimalUtils.EXTERNAL_DECIMAL_SIGN_EBCDIC);
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="9"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="9" offset="212" size="9"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getChid_Parent() {
		String chid_Parent = null;
		chid_Parent = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 212, "ibm-037",
						9);
		return (chid_Parent);
	}

	/**
	 * @generated
	 */
	public void setChid_Parent(String chid_Parent) {
		if (chid_Parent != null) {
			if (chid_Parent.length() > 9)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, chid_Parent,
								"9", "chid_Parent"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					chid_Parent, buffer_, 212, "ibm-037", 9,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="1"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="1" offset="221" size="1"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getChcontractstatus() {
		String chcontractstatus = null;
		chcontractstatus = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 221, "ibm-037",
						1);
		return (chcontractstatus);
	}

	/**
	 * @generated
	 */
	public void setChcontractstatus(String chcontractstatus) {
		if (chcontractstatus != null) {
			if (chcontractstatus.length() > 1)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								chcontractstatus, "1", "chcontractstatus"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					chcontractstatus, buffer_, 221, "ibm-037", 1,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="9"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="9" offset="222" size="9"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getChid_Parent_Oud() {
		String chid_Parent_Oud = null;
		chid_Parent_Oud = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 222, "ibm-037",
						9);
		return (chid_Parent_Oud);
	}

	/**
	 * @generated
	 */
	public void setChid_Parent_Oud(String chid_Parent_Oud) {
		if (chid_Parent_Oud != null) {
			if (chid_Parent_Oud.length() > 9)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E, chid_Parent_Oud,
								"9", "chid_Parent_Oud"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					chid_Parent_Oud, buffer_, 222, "ibm-037", 9,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

	/**
	 * @generated
	 * @type-descriptor.restriction maxLength="1"
	 * @type-descriptor.initial-value kind="SPACE"
	 * @type-descriptor.simple-instance-td accessor="readWrite" contentSize="1" offset="231" size="1"
	 * @type-descriptor.string-td characterSize="1" lengthEncoding="fixedLength" paddingCharacter=" " prefixLength="0"
	 */
	public String getChcontractstatus_Oud() {
		String chcontractstatus_Oud = null;
		chcontractstatus_Oud = MarshallStringUtils
				.unmarshallFixedLengthStringFromBuffer(buffer_, 231, "ibm-037",
						1);
		return (chcontractstatus_Oud);
	}

	/**
	 * @generated
	 */
	public void setChcontractstatus_Oud(String chcontractstatus_Oud) {
		if (chcontractstatus_Oud != null) {
			if (chcontractstatus_Oud.length() > 1)
				throw new IllegalArgumentException(MarshallResource.instance()
						.getString(MarshallResource.IWAA0124E,
								chcontractstatus_Oud, "1",
								"chcontractstatus_Oud"));
			MarshallStringUtils.marshallFixedLengthStringIntoBuffer(
					chcontractstatus_Oud, buffer_, 231, "ibm-037", 1,
					MarshallStringUtils.STRING_JUSTIFICATION_LEFT, " ");
		}
	}

}