package com.abnamro.moa.generic.agreementcustomerreference.publisher.exceptions;

import java.util.ArrayList;
import java.util.List;


/**
 * This is exception class for the agreement customer reference publisher.
 */
public class AgreementCustomerReferenceExternalPublisherException extends Exception {
	
	private static final long serialVersionUID = 1L;

	private final int status;

    private final List<String> params = new ArrayList<>();
    

    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param cause cause of the error
     * @param status https status of the error
     */
    public AgreementCustomerReferenceExternalPublisherException(String message, Throwable cause, int status) {
        super(message, cause);
        this.status = status;
    }

    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param status https status of the error
     */
    public AgreementCustomerReferenceExternalPublisherException(String message, int status) {
        super(message);
        this.status = status;
    }


    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param status https status of the error
     * @param params list of additional param information
     */
    public AgreementCustomerReferenceExternalPublisherException(String message, int status,List<String> params) {
        super(message);
        this.params.clear();
		this.params.addAll(params);
        this.status = status;
    }

    public int getStatus() {
        return this.status;
    }

    public List<String> getParams() {
        return params;
    }
}
