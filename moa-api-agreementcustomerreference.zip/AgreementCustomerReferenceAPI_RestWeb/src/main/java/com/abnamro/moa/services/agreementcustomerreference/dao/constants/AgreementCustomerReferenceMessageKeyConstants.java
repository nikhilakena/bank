package com.abnamro.moa.services.agreementcustomerreference.dao.constants;

import com.abnamro.nl.messages.MessageKey;

/**
 * This class contains the keys of the messages that are presented to the consumer.
 */
public final class AgreementCustomerReferenceMessageKeyConstants {
	private AgreementCustomerReferenceMessageKeyConstants() {}

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION = new MessageKey("MESSAGE_ACRDL_001");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION = new MessageKey("MESSAGE_ACRDL_002");
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_CREATING_BUILDING_BLOCK = new MessageKey("MESSAGE_ACRDL_003");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_CREATING_BUILDING_BLOCK = new MessageKey("MESSAGE_ACRDL_004");
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_CREATING_CONTRACT_HEADER = new MessageKey("MESSAGE_ACRDL_005");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_CREATING_CONTRACT_HEADER = new MessageKey("MESSSAGE_ACRDL_006");
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVE_MAX_CONTRACT_HEADER_ID = new MessageKey("MESSAGE_ACRDL_007");
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_VALIDATING_PRODUCT_ID = new MessageKey("MESSAGE_ACRDL_008");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_VALIDATING_PRODUCT_ID = new MessageKey("MESSAGE_ACRDL_009");
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_CREATING_RESPONSIBLE_PARTY = new MessageKey("MESSAGE_ACRDL_010");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_CREATING_RESPONSIBLE_PARTY = new MessageKey("MESSAGE_ACRDL_011");
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_CREATING_RESPONSIBLE_PARTY_VERSION = new MessageKey("MESSAGE_ACRDL_012");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_CREATING_RESPONSIBLE_PARTY_VERSION = new MessageKey("MESSAGE_ACRDL_013");
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVING_HIGHEST_RESPONSIBLE_PARTY_ID = new MessageKey("MESSAGE_ACRDL_014");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVING_HIGHEST_RESPONSIBLE_PARTY_ID = new MessageKey("MESSAGE_ACRDL_015");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_CREATING_SETTLEMENT_ACCOUNT = new MessageKey("MESSAGE_ACRDL_016");
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVE_MAX_SETTLEMENT_ACCOUNT_ID = new MessageKey("MESSAGE_ACRDL_017");
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_VALIDATING_PACKAGE = new MessageKey("MESSAGE_ACRDL_018");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_VALIDATING_PACKAGE = new MessageKey("MESSAGE_ACRDL_019");
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_SELECT_NUMBER_CONTRACT_HEADER = new MessageKey("MESSAGE_ACRDL_020");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_SELECT_NUMBER_CONTRACT_HEADER = new MessageKey("MESSAGE_ACRDL_021");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_GENERATING_CONTRACT_HEADER_ID = new MessageKey("MESSAGE_ACRDL_022");
	public static final MessageKey DATABASE_EXCEPTION_WHILE_CREATING_AGREEMENT_CUSTOMERREF = new MessageKey("MESSAGE_ACRDL_023");
	public static final MessageKey SQL_EXCEPTION_WHILE_CREATING_AGREEMENT_CUSTOMERREF = new MessageKey("MESSAGE_ACRDL_024");
	
	public static final MessageKey EXCEPTION_WHILE_WHILE_RETRIEVING_BC_DETAILS = new MessageKey("MESSAGE_ACRDL_025");
}
