package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.generic.agreementcustomerreference.publisher.dto.PublishContractHeaderInputDTO;
import com.abnamro.moa.generic.agreementcustomerreference.publisher.exceptions.AgreementCustomerReferenceExternalPublisherException;
import com.abnamro.moa.services.agreementcustomerreference.constants.AgreementCustomerReferenceConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementLifeCycleStatusTypeEnum;

/**
 * This is the helper class for publishing the agreement customer reference
 * details after create and update
 */
@Component
public class PublishAgreementCustomerReferenceHelper {

    @Autowired
    private AgreementCustomerReferenceExternalPublisher agreementCustomerReferencePublisher;

    @Autowired
    private AgreementCustomerReferenceRequestProcessorUtils processorUtils;

	/**
	 * Publish the changes in the agreement customer reference to other administrations.
	 * @param agreementCustomerReferenceView - the agreement customer reference that is changed
	 * @param updateRequestInput - the new details of the agreement customer reference
	 * @param buildingBlockClusterTypeViewList - type of the building block cluster
	 * @param consumerId - the name of the consumer that requests the change
	 * @throws AgreementCustomerReferenceExternalPublisherException in case of an error
	 */
    public void publishUpdateAgreementCustomerReference(AgreementCustomerReferenceView agreementCustomerReferenceView,
            AgreementCustomerReferenceForPatch updateRequestInput,
            List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList, String consumerId)
            throws AgreementCustomerReferenceExternalPublisherException {
        PublishContractHeaderInputDTO publishContractHeaderInputDTO = populatePublishContractHeaderInputDTO(
                agreementCustomerReferenceView, updateRequestInput, buildingBlockClusterTypeViewList, consumerId);
        agreementCustomerReferencePublisher.publishAgreementCustomerReference(publishContractHeaderInputDTO,
                AgreementCustomerReferenceConstants.PUBLISH_TYPE_UPDATE);

    }

	/**
	 * Copy the changes from the agreement customer reference and standard details to the data object and return it.
	 * @param agreementCustomerReferenceView - the details of the current version of the agreement customer reference
	 * @param updateRequestInput - the details of the agreement customer reference that are changed
	 * @param buildingBlockClusterTypeViewList - the administrations that are involved with the product of the agreement customer reference
	 * @param consumerId - the name of the consumer that requests the change
	 * @return the record that holds the new details and previous details of the agreement customer reference
	 */
	private PublishContractHeaderInputDTO populatePublishContractHeaderInputDTO(AgreementCustomerReferenceView agreementCustomerReferenceView,
			AgreementCustomerReferenceForPatch updateRequestInput, List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList, String consumerId) {
        PublishContractHeaderInputDTO publishContractHeaderInputDTO = new PublishContractHeaderInputDTO();
        // Check every field from the update input,
		// if its not empty then compare the value with the database value, if different than
        // if its empty then update the value with blank
        // if its null it means it will not be updated at all.
        setCurrentValues(publishContractHeaderInputDTO, agreementCustomerReferenceView);
        setUpdateValues(agreementCustomerReferenceView, updateRequestInput, publishContractHeaderInputDTO);

        if (!org.springframework.util.CollectionUtils
                .isEmpty(updateRequestInput.getAgreementAdministrationReferences())) {
            publishContractHeaderInputDTO.setBuildingBlockId(processorUtils.getFirstAgreementAdministrationKey(
                    updateRequestInput.getAgreementAdministrationReferences(), buildingBlockClusterTypeViewList));
        }

        publishContractHeaderInputDTO.setTaskId(AgreementCustomerReferenceConstants.INT_ZERO);
        publishContractHeaderInputDTO.setContractHeaderId(agreementCustomerReferenceView.getId());
        publishContractHeaderInputDTO.setUserId(consumerId);
        publishContractHeaderInputDTO.setLastModifiedDate(agreementCustomerReferenceView.getDateModified());
        return publishContractHeaderInputDTO;
    }

    private void setUpdateValues(AgreementCustomerReferenceView agreementCustomerReferenceView,
            AgreementCustomerReferenceForPatch updateRequestInput,
            PublishContractHeaderInputDTO publishContractHeaderInputDTO) {
        if (updateRequestInput.getCustomerId() != null && !Long.valueOf(updateRequestInput.getCustomerId())
                .equals(Long.valueOf(agreementCustomerReferenceView.getCustomerId()))) {
            publishContractHeaderInputDTO.setBcNumber(Long.valueOf(updateRequestInput.getCustomerId()));
        } else {
            publishContractHeaderInputDTO.setBcNumber(Long.valueOf(agreementCustomerReferenceView.getCustomerId()));
        }
        
        if (updateRequestInput.getProductId() != null && !Integer.valueOf(updateRequestInput.getProductId())
                .equals(Integer.valueOf(agreementCustomerReferenceView.getProductId()))) {
            publishContractHeaderInputDTO.setProductId(Integer.parseInt(updateRequestInput.getProductId()));
        } else {
            publishContractHeaderInputDTO.setProductId(Integer.parseInt(agreementCustomerReferenceView.getProductId()));
        }

        if (updateRequestInput.getParentAgreementCustomerReferenceId() != null && !updateRequestInput
                .getParentAgreementCustomerReferenceId().equals(agreementCustomerReferenceView.getParentId())) {
            publishContractHeaderInputDTO
                    .setContracheaderIdParent(updateRequestInput.getParentAgreementCustomerReferenceId());
        } else {
            publishContractHeaderInputDTO.setContracheaderIdParent(agreementCustomerReferenceView.getParentId());
        }

        if (updateRequestInput.getAgreementLifeCycleStatus() != null && !updateRequestInput
                .getAgreementLifeCycleStatus().equals(agreementCustomerReferenceView.getStatus())) {
            publishContractHeaderInputDTO.setContractStatus(AgreementLifeCycleStatusTypeEnum
                    .fromValue(updateRequestInput.getAgreementLifeCycleStatus()).getDbValue());
        } else {
            publishContractHeaderInputDTO.setContractStatus(agreementCustomerReferenceView.getStatus());
        }
        
        if(updateRequestInput.getCommercialAgreementId()!=null) {
        	publishContractHeaderInputDTO.setCommercialContractNumber(updateRequestInput.getCommercialAgreementId());
        }else {
        	publishContractHeaderInputDTO.setCommercialContractNumber(agreementCustomerReferenceView.getCommercialContractNumber());
        }
    }
    
    private void setCurrentValues(PublishContractHeaderInputDTO publishContractHeaderInputDTO,
            AgreementCustomerReferenceView agreementCustomerReferenceView) {
        publishContractHeaderInputDTO.setBcNumberOld(Long.valueOf(agreementCustomerReferenceView.getCustomerId()));
        publishContractHeaderInputDTO.setProductIdOld(new Integer(agreementCustomerReferenceView.getProductId()));
        publishContractHeaderInputDTO.setContractheaderParentOld(AgreementCustomerReferenceConstants.SPACE);
        publishContractHeaderInputDTO.setContractStatusOld(agreementCustomerReferenceView.getStatus());
    }

    /**
     * Create a data object, enter the details of the changed agreement customer reference and call the publisher to inform others of the change.
     * @param agreementCustomerReferenceId - the id of the changed agreement customer reference
     * @param agreementCustomerReference - the details of the agreement customer reference
     * @param buildingBlockClusterTypeViewList - the list of administrations that are involved in the handling of the product of the agreement customer reference
     * @param consumerId - the name of the consumer that requests the change
     * @throws AgreementCustomerReferenceExternalPublisherException in case of an error
     */
    public void publishCreateAgreementCustomerReference(String agreementCustomerReferenceId,
            AgreementCustomerReference agreementCustomerReference, List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList, String consumerId) throws AgreementCustomerReferenceExternalPublisherException {
        
        PublishContractHeaderInputDTO publishContractHeaderInputDTO = new PublishContractHeaderInputDTO();
        publishContractHeaderInputDTO.setBcNumber(Long.valueOf(agreementCustomerReference.getCustomerId()));
        publishContractHeaderInputDTO.setBcNumberOld(AgreementCustomerReferenceConstants.INT_ZERO);
        publishContractHeaderInputDTO.setContracheaderIdParent(agreementCustomerReference.getParentAgreementCustomerReferenceId());
        publishContractHeaderInputDTO.setContractheaderParentOld(AgreementCustomerReferenceConstants.SPACE);
        publishContractHeaderInputDTO.setBuildingBlockId(processorUtils.getFirstAgreementAdministrationKey(agreementCustomerReference.getAgreementAdministrationReferences(), buildingBlockClusterTypeViewList));
        publishContractHeaderInputDTO.setCommercialContractNumber(agreementCustomerReference.getCommercialAgreementId());
        publishContractHeaderInputDTO.setTaskId(AgreementCustomerReferenceConstants.INT_ZERO);
        publishContractHeaderInputDTO.setContractHeaderId(agreementCustomerReferenceId);
        publishContractHeaderInputDTO.setContractStatus(agreementCustomerReference.getAgreementLifeCycleStatus().getDbValue());
        publishContractHeaderInputDTO.setContractStatusOld(AgreementCustomerReferenceConstants.SPACE);
        publishContractHeaderInputDTO.setProductId(Integer.valueOf(agreementCustomerReference.getProductId()));
        publishContractHeaderInputDTO.setProductIdOld(AgreementCustomerReferenceConstants.INT_ZERO);
        publishContractHeaderInputDTO.setUserId(consumerId);
        agreementCustomerReferencePublisher.publishAgreementCustomerReference(publishContractHeaderInputDTO, AgreementCustomerReferenceConstants.PUBLISH_TYPE_CREATE);
    }

    /**
     * Create a data object that contains the differences in the agreement customer reference before and after the operation and return it.
     * The data object is used to be published and to inform other systems of the change.
     * @param persistentAgreementCustomerReference - the agreement customer reference details before the operation
     * @param buildingBlockClusterTypeViewList List of building block details
     * @param agreementCustomerReferenceId - the id of the agreement customer reference that is to be deleted
     * @param consumerId - the name of the consumer that requests the delete operation
     * @throws AgreementCustomerReferenceExternalPublisherException in case of an error
     */
    public void publishDeleteAgreementCustomerReference
            (AgreementCustomerReferenceView persistentAgreementCustomerReference, List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList
					, String agreementCustomerReferenceId, String consumerId)
            throws AgreementCustomerReferenceExternalPublisherException {
        PublishContractHeaderInputDTO publishContractHeaderInputDTO = new PublishContractHeaderInputDTO();

        publishContractHeaderInputDTO.setBcNumberOld(AgreementCustomerReferenceConstants.INT_ZERO);
        publishContractHeaderInputDTO.setBcNumber(Long.valueOf(persistentAgreementCustomerReference.getCustomerId()));

        publishContractHeaderInputDTO.setContracheaderIdParent(persistentAgreementCustomerReference.getParentId());
        publishContractHeaderInputDTO.setContractheaderParentOld(AgreementCustomerReferenceConstants.SPACE);

        if (buildingBlockClusterTypeViewList != null && !buildingBlockClusterTypeViewList.isEmpty()) {
            int buildingBlockId = processorUtils.findFirstAgreementAdministrationKey(buildingBlockClusterTypeViewList);
			publishContractHeaderInputDTO.setBuildingBlockId(buildingBlockId);
        }

        publishContractHeaderInputDTO.setCommercialContractNumber(persistentAgreementCustomerReference.getCommercialContractNumber());
        publishContractHeaderInputDTO.setTaskId(AgreementCustomerReferenceConstants.INT_ZERO);
        publishContractHeaderInputDTO.setContractHeaderId(agreementCustomerReferenceId);

        publishContractHeaderInputDTO.setContractStatus(persistentAgreementCustomerReference.getStatus());
        publishContractHeaderInputDTO.setContractStatusOld(AgreementCustomerReferenceConstants.SPACE);

        int productId = Integer.parseInt(persistentAgreementCustomerReference.getProductId());
        publishContractHeaderInputDTO.setProductIdOld(AgreementCustomerReferenceConstants.INT_ZERO);
        publishContractHeaderInputDTO.setProductId(productId);

        publishContractHeaderInputDTO.setUserId(consumerId);

        agreementCustomerReferencePublisher.publishAgreementCustomerReference(publishContractHeaderInputDTO, AgreementCustomerReferenceConstants.PUBLISH_TYPE_DELETE);

    }
}
