package com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator;


import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * This is custom validator class for the checking null and blank
 */
public class NotNullOrNotBlankValidator implements ConstraintValidator<NotNullOrNotBlank, String> {

	@Override
    public void initialize(NotNullOrNotBlank parameters) {
        // Nothing to do here
    }

	@Override
    public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
        if (value == null) {
            return false;
        }
        if (value.length() == 0) {
            return false;
        }

        boolean isAllWhitespace = value.matches("^\\s*$");
        return !isAllWhitespace;
    }
}

