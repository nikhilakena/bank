package com.abnamro.moa.services.agreementcustomerreference.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;


/**
 * This is the customised exception class for the Agreement Customer Reference service
 */
public class AgreementCustomerReferenceApplicationException extends Exception {


    private final HttpStatus status;

    private final List<String> params = new ArrayList<>();

    /**
     * Public constructor with http status
     *
     * @param status http status of the error
     */
    public AgreementCustomerReferenceApplicationException(HttpStatus status) {
        super();
        this.status = status;
    }

    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param cause cause of the error
     * @param status https status of the error
     */
    public AgreementCustomerReferenceApplicationException(String message, Throwable cause, HttpStatus status) {
        super(message, cause);
        this.status = status;
    }

    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param status https status of the error
     */
    public AgreementCustomerReferenceApplicationException(String message, HttpStatus status) {
        super(message);
        this.status = status;
    }
    
    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param status https status of the error
     */
    public AgreementCustomerReferenceApplicationException(String message, int status) {
        super(message);
        this.status = HttpStatus.valueOf(status);
    }

    /**
     * Public constructor with http status, cause, message
     *
     * @param message string message of error
     * @param status https status of the error
     * @param params list of additional param information
     */
    public AgreementCustomerReferenceApplicationException(String message, HttpStatus status,List<String> params) {
        super(message);
        this.params.clear();
        this.params.addAll(params);
        this.status = status;
    }

    public HttpStatus getStatus() {
        return this.status;
    }

    public List<String> getParams() {
        return params;
    }
}
