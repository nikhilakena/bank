package com.abnamro.moa.services.agreementcustomerreference.resourcemodel;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Response of the retrieve agreement customer reference operation
 */
@ApiModel(description = "Response of the retrieve agreement customer reference operation")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-03-18T11:37:19.835Z")

public class GetAgreementCustomerReferenceResponse extends AgreementCustomerReference  {
  @JsonProperty("linkedAgreementReferences")
  @Valid
  private List<AgreementCustomerReference> linkedAgreementReferences = null;

  public GetAgreementCustomerReferenceResponse linkedAgreementReferences(List<AgreementCustomerReference> linkedAgreementReferences) {
    this.linkedAgreementReferences = linkedAgreementReferences;
    return this;
  }

  public GetAgreementCustomerReferenceResponse addLinkedAgreementReferencesItem(AgreementCustomerReference linkedAgreementReferencesItem) {
    if (this.linkedAgreementReferences == null) {
      this.linkedAgreementReferences = new ArrayList<AgreementCustomerReference>();
    }
    this.linkedAgreementReferences.add(linkedAgreementReferencesItem);
    return this;
  }

  /**
   * It contains agreement customer references of agreements within the package.
   * @return linkedAgreementReferences
  **/
  @ApiModelProperty(value = "It contains agreement customer references of agreements within the package.")

  @Valid
@Size(min=0,max=20) 
  public List<AgreementCustomerReference> getLinkedAgreementReferences() {
    return linkedAgreementReferences;
  }

  public void setLinkedAgreementReferences(List<AgreementCustomerReference> linkedAgreementReferences) {
    this.linkedAgreementReferences = linkedAgreementReferences;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    GetAgreementCustomerReferenceResponse getAgreementCustomerReferenceResponse = (GetAgreementCustomerReferenceResponse) o;
    return Objects.equals(this.linkedAgreementReferences, getAgreementCustomerReferenceResponse.linkedAgreementReferences) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(linkedAgreementReferences, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class GetAgreementCustomerReferenceResponse {\n    ");
    sb.append(toIndentedString(super.toString()));
    sb.append("\n    linkedAgreementReferences: ");
    sb.append(toIndentedString(linkedAgreementReferences));
    sb.append("\n}");

    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

