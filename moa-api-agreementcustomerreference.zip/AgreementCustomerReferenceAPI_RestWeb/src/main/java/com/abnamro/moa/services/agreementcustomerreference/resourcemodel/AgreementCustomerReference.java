package com.abnamro.moa.services.agreementcustomerreference.resourcemodel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Agreement Customer Reference that needs to be stored.
 */
@ApiModel(description = "Agreement Customer Reference that needs to be stored.")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-04-05T06:58:44.424Z")

@JsonInclude(value = Include.NON_DEFAULT)
public class AgreementCustomerReference   {

  @JsonProperty("agreementLifeCycleStatus")
  private AgreementLifeCycleStatusTypeEnum agreementLifeCycleStatus = null;

  @JsonProperty("agreementAdministrationReferences")
  @Valid
  private List<AgreementAdministrationReference> agreementAdministrationReferences = null;

  @JsonProperty("commercialAgreementId")
  private String commercialAgreementId = null;

  @JsonProperty("customerId")
  private String customerId = null;

  @JsonProperty("agreementNickName")
  private String agreementNickName = null;

  @JsonProperty("parentAgreementCustomerReferenceId")
  private String parentAgreementCustomerReferenceId = null;
  
  @JsonProperty("agreementCustomerReferenceId")
  private String agreementCustomerReferenceId;

  @JsonProperty("productId")
  private String productId = null;

  @JsonProperty("organisationUnitId")
  private String organisationUnitId = null;

  @JsonProperty("settlementAccountNumber")
  private String settlementAccountNumber = null;

  @JsonProperty("referenceStartDate")
  private String referenceStartDate;

  @JsonProperty("packageSettlementAccountNumber")
  private String packageSettlementAccountNumber;

  public AgreementCustomerReference agreementLifeCycleStatusType(AgreementLifeCycleStatusTypeEnum agreementLifeCycleStatus) {
    this.agreementLifeCycleStatus = agreementLifeCycleStatus;
    return this;
  }

  /**
   * Contains status of the agreement within the lifecycle.
   * @return agreementLifeCycleStatusType
  **/
  @ApiModelProperty(example = "ACTIVE", value = "Contains status of the agreement within the lifecycle.")
  @NotNull(message = "4014")
  public AgreementLifeCycleStatusTypeEnum getAgreementLifeCycleStatus() {
    return agreementLifeCycleStatus;
  }

  public void setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum agreementLifeCycleStatus) {
    this.agreementLifeCycleStatus = agreementLifeCycleStatus;
  }

  public AgreementCustomerReference agreementAdministrationReferences(List<AgreementAdministrationReference> agreementAdministrationReferences) {
    this.agreementAdministrationReferences = agreementAdministrationReferences;
    return this;
  }

  public AgreementCustomerReference addAgreementAdministrationReferencesItem(AgreementAdministrationReference agreementAdministrationReferencesItem) {
    if (this.agreementAdministrationReferences == null) {
      this.agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
    }
    this.agreementAdministrationReferences.add(agreementAdministrationReferencesItem);
    return this;
  }

  /**
   * The agreementAdministrationReference. Mandatory when the product is not a package.
   * @return agreementAdministrationReferences
  **/
  @ApiModelProperty(value = "The agreementAdministrationReference. Mandatory when the product is not a package.")

  @Valid
  @Size(min=0,max=10)
  public List<AgreementAdministrationReference> getAgreementAdministrationReferences() {
    return agreementAdministrationReferences;
  }

  public void setAgreementAdministrationReferences(List<AgreementAdministrationReference> agreementAdministrationReferences) {
    this.agreementAdministrationReferences = agreementAdministrationReferences;
  }

  public AgreementCustomerReference commercialAgreementId(String commercialAgreementId) {
    this.commercialAgreementId = commercialAgreementId;
    return this;
  }

  /**
   * Unique value by what the agreement can be retrieved and identified and used in communication and maintenance
   * @return commercialAgreementId
  **/
  @ApiModelProperty(example = "0558967531", value = "Unique value by what the agreement can be retrieved and identified and used in communication and maintenance")

  @Valid
  @Size(min = 0, max = 16, message = "4017")
  public String getCommercialAgreementId() {
    return commercialAgreementId;
  }

  public void setCommercialAgreementId(String commercialAgreementId) {
    this.commercialAgreementId = commercialAgreementId;
  }

  public AgreementCustomerReference customerId(String customerId) {
    this.customerId = customerId;
    return this;
  }

  /**
   * Identification of the individual or business that holds the Agreement Customer Reference.
   * @return customerId
  **/
  @ApiModelProperty(example = "76890341", required = true, value = "Identification of the individual or business that holds the Agreement Customer Reference.")
  @NotNull(message = "4001")
  @Valid
  public String getCustomerId() {
    return customerId;
  }

  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  public AgreementCustomerReference agreementNickName(String agreementNickName) {
    this.agreementNickName = agreementNickName;
    return this;
  }

  /**
   * The name of the Agreement given by the customer.
   * @return agreementNickName
  **/
  @ApiModelProperty(example = "PENSIOEN AANVULLING INBRENG", value = "The name of the Agreement given by the customer.")


  @Valid
  @Size(min = 0, max = 48, message = "4016")
  public String getAgreementNickName() {
    return agreementNickName;
  }

  public void setAgreementNickName(String agreementNickName) {
    this.agreementNickName = agreementNickName;
  }

  public AgreementCustomerReference parentAgreementCustomerReferenceId(String parentAgreementCustomerReferenceId) {
    this.parentAgreementCustomerReferenceId = parentAgreementCustomerReferenceId;
    return this;
  }

  /**
   * The agreementCustomerReferenceId of the package or arrangement the Agreement customer is part of. parentAgreementCustomerReferenceId is optional when the agreementCustomerReferenceId is part of a package or arrangement.
   * @return parentAgreementCustomerReferenceId
  **/
  @ApiModelProperty(example = "HHI030210", value = "The agreementCustomerReferenceId of the package or arrangement the Agreement customer is part of. parentAgreementCustomerReferenceId is optional when the agreementCustomerReferenceId is part of a package or arrangement.")

  @Valid
  @Pattern(regexp = "^[A-Z]{3}\\d{6}$", message = "4019")
  public String getParentAgreementCustomerReferenceId() {
    return parentAgreementCustomerReferenceId;
  }

  public void setParentAgreementCustomerReferenceId(String parentAgreementCustomerReferenceId) {
    this.parentAgreementCustomerReferenceId = parentAgreementCustomerReferenceId;
  }

  public AgreementCustomerReference productId(String productId) {
    this.productId = productId;
    return this;
  }

  /**
   * Identificataion of the product for which this agreement has been created
   * @return productId
  **/
  @ApiModelProperty(example = "1234", required = true, value = "Identificataion of the product for which this agreement has been created")
  @NotNull(message="4004")
  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public AgreementCustomerReference organisationUnitId(String organisationUnitId) {
    this.organisationUnitId = organisationUnitId;
    return this;
  }

  /**
   * The identification of the responsible party of a customer who has initiated the postAgreementCustomerReference operation and thus wants to create an Agreement Customer Reference. 
   * @return organisationUnitId
  **/
  @ApiModelProperty(example = "690839", value = "The identification of the responsible party of a customer who has initiated the postAgreementCustomerReference operation and thus wants to create an Agreement Customer Reference. ")

  @Valid
  //@Digits(integer = 6, fraction = 0, message = "4012")
  public String getOrganisationUnitId() {
    return organisationUnitId;
  }

  public void setOrganisationUnitId(String organisationUnitId) {
    this.organisationUnitId = organisationUnitId;
  }

	public String getAgreementCustomerReferenceId() {
		return agreementCustomerReferenceId;
	}

	public void setAgreementCustomerReferenceId(String agreementCustomerReferenceId) {
		this.agreementCustomerReferenceId = agreementCustomerReferenceId;
	}

	public String getReferenceStartDate() {
		return referenceStartDate;
	}

	public void setReferenceStartDate(String date) {
		referenceStartDate = date;
	}

	/**
	   * The identification(IBAN) which is used for settlement account. SettlementAccountId is mandatory when an AgreementCustomerReference of a package is to be created.  A package is a means of bundling products for tariffing purposes.
	   * @return settlementAccountId
	**/
	@ApiModelProperty(example = "NL32ABNA0419943927", value = "The identification(IBAN) which is used for settlement account. SettlementAccountId is mandatory when an AgreementCustomerReference of a package is to be created.  A package is a means of bundling products for tariffing purposes.")

	@Valid
	@Pattern(regexp = "^NL\\d{2}[A-Z]{4}\\d{10}$", message = "4013")
	public String getPackageSettlementAccountNumber() {
		return packageSettlementAccountNumber;
	}

	public void setPackageSettlementAccountNumber(String accountNumber) {
		packageSettlementAccountNumber = accountNumber;
	}

	@Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AgreementCustomerReference agreementCustomerReference = (AgreementCustomerReference) o;
    return Objects.equals(this.agreementLifeCycleStatus, agreementCustomerReference.agreementLifeCycleStatus) &&
        Objects.equals(this.agreementAdministrationReferences, agreementCustomerReference.agreementAdministrationReferences) &&
        Objects.equals(this.commercialAgreementId, agreementCustomerReference.commercialAgreementId) &&
        Objects.equals(this.customerId, agreementCustomerReference.customerId) &&
        Objects.equals(this.agreementNickName, agreementCustomerReference.agreementNickName) &&
        Objects.equals(this.parentAgreementCustomerReferenceId, agreementCustomerReference.parentAgreementCustomerReferenceId) &&
        Objects.equals(this.agreementCustomerReferenceId, agreementCustomerReference.agreementCustomerReferenceId) &&
        Objects.equals(this.productId, agreementCustomerReference.productId) &&
        Objects.equals(this.organisationUnitId, agreementCustomerReference.organisationUnitId) &&
        Objects.equals(this.settlementAccountNumber, agreementCustomerReference.settlementAccountNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(agreementLifeCycleStatus, agreementAdministrationReferences, commercialAgreementId, customerId, agreementNickName, parentAgreementCustomerReferenceId, productId, organisationUnitId, settlementAccountNumber, agreementCustomerReferenceId);
  }

}

