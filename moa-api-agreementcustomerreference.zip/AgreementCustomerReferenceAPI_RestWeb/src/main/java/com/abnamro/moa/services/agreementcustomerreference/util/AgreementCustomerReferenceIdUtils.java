package com.abnamro.moa.services.agreementcustomerreference.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

/**
 * This class contains utility methods regarding the id of the Agreement Customer Reference.
 */
public final class AgreementCustomerReferenceIdUtils {
	/**
	 * The minimum length of the id that is to be converted to the agreement customer reference id.
	 */
	private final static int MINIMUM_LENGTH_ID = 9;

	private AgreementCustomerReferenceIdUtils() {}

	/**
	 * The map to convert from a number to a character.
	 */
	private static Map<String, String> numberToCharacterConversions = initializeAgreementCustomerReferenceIdConvertMap();

	/**
	 * Convert the given number to an id in the format of the agreement customer references.
	 * For instance the number 95192193 will be converted to "TPL092193".
	 * @param generatedId - the unique id as a number
	 * @return the unique id converted to the agreement customer reference format
	 */
	public static String convertGeneratedIdToAgreementCustomerReferenceId(Integer generatedId) {
		String agreementCustomerReferenceId = null;

		if (generatedId != null) {
			StringBuilder convertedId = new StringBuilder();
			String idAsText = generatedId.toString();

			// make the id the correct length, fill with leading 0s
			idAsText = correctLength(idAsText);

			// convert the first 3 numbers to characters
			convertedId.append(numberToCharacterConversions.get(idAsText.substring(0, 1)));
			convertedId.append(numberToCharacterConversions.get(idAsText.substring(1, 2)));
			convertedId.append(numberToCharacterConversions.get(idAsText.substring(2, 3)));

			// add the remainder of the number
			convertedId.append(idAsText.substring(3));

			agreementCustomerReferenceId = convertedId.toString();
		}

		return agreementCustomerReferenceId;
	}

	/**
	 * Fill the number with leading '0's up to the minimum length.
	 * @param number the number that must have at least the minimum number of digits
	 * @return the number that has at least the minimum length
	 */
	private static String correctLength(String number) {
		if (number.length() < AgreementCustomerReferenceIdUtils.MINIMUM_LENGTH_ID) {
			number = StringUtils.leftPad(number, AgreementCustomerReferenceIdUtils.MINIMUM_LENGTH_ID, '0');
		}

		return number;
	}

	/**
	 * Return the map that is used to convert a number to a character in the agreement customer reference id.
	 * @return the map that contains the conversions.
	 */
	private static Map<String, String> initializeAgreementCustomerReferenceIdConvertMap() {
		Map<String, String> conversions = new HashMap<>();
		conversions.put("0", "K");
		conversions.put("1", "L");
		conversions.put("2", "M");
		conversions.put("3", "N");
		conversions.put("4", "O");
		conversions.put("5", "P");
		conversions.put("6", "Q");
		conversions.put("7", "R");
		conversions.put("8", "S");
		conversions.put("9", "T");

		return conversions;
	}
}
