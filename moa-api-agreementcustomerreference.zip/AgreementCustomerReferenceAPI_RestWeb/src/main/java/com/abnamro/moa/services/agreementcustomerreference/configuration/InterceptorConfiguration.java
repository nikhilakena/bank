package com.abnamro.moa.services.agreementcustomerreference.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * This class extends WebMvcConfigurerAdapter and overrides the addInterceptors
 * method to add custom interceptors to registry
 */
@Component
public class InterceptorConfiguration implements WebMvcConfigurer  {

	@Autowired
	private TraceIdInterceptor traceIdInterceptor;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(traceIdInterceptor);
	}
}
