package com.abnamro.moa.services.agreementcustomerreference.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = {"com.abnamro.moa.services.agreementcustomerreference.controller"
        , "com.abnamro.moa.services.agreementcustomerreference"
        , "com.abnamro.moa.services.agreementcustomerreference.requestprocessor"
        , "com.abnamro.nl.partymanagementconnect.implementation"
        , "com.abnamro.moa.generic.agreementcustomerreference.publisher"
        , "com.abnamro.moa.services.agreementcustomerreference.configuration"})
public class APIConfiguration {
}
