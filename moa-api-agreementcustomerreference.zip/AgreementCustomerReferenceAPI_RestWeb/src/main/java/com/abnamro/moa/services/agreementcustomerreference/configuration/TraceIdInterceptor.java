package com.abnamro.moa.services.agreementcustomerreference.configuration;

import javax.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**
 * This implements HandlerInterceptor interface and sets the header element Trace-ID in request scope
 */
@Component
public class TraceIdInterceptor implements HandlerInterceptor {
	
	@Autowired
	private RequestScopeBeans requestScopeBeans;

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		requestScopeBeans.setTraceId(request.getHeader("Trace-Id"));
		return true;
	}

	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		//Nothing to do here
	}

	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
		//Nothing to do here
	}

}
