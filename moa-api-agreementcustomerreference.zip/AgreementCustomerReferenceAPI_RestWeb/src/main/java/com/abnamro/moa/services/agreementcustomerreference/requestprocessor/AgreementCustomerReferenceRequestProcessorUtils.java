package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import java.util.Collections;
import java.util.List;

import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnectConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.constants.AgreementCustomerReferenceLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyVersionView;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.nl.commondt.v3.ReferenceContext;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnect;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnectException;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsRequestTO;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;

/**
 *  This is the request processor util class for the AgreementCustomerReferenceRequestProcessor
 */
@Component
public class AgreementCustomerReferenceRequestProcessorUtils {
	public static final int MAX_LENGTH_CONSUMER_ID = 12;
	public static final String DEFAULT_API_CONSUMER_ID = "API-ACR";

	private static LogHelper log = new LogHelper(AgreementCustomerReferenceRequestProcessorUtils.class);

	@Autowired
	private PartyManagementConnect partyManagementConnect;
	
	/**
	 * This is used to retrieve responsible party details
	 * 
	 * @param customerId unique identifier for the customer
	 * @return responsible party details
	 * @throws AgreementCustomerReferenceApplicationException in case errors
	 */
	public RetrievePartyDetailsResponseTO getCustomerDetails(String customerId) throws AgreementCustomerReferenceApplicationException {
		final String logMethod = "getCustomerDetails(Long):RetrievePartyDetailsResponseTO";
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = null;
		
		RetrievePartyDetailsRequestTO retrievePartyDetailsRequestTO = new RetrievePartyDetailsRequestTO();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setValue(customerId);
		retrievePartyDetailsRequestTO.setPartyId(referenceContext);
		retrievePartyDetailsRequestTO.setSelectPartyFlag(true);
		retrievePartyDetailsRequestTO.setSelectCustomerFlag(true);
		
		try {
			retrievePartyDetailsResponseTO = partyManagementConnect.retrievePartyDetails(retrievePartyDetailsRequestTO);
		} catch (PartyManagementConnectException exception) {
			if (PartyManagementConnectConstants.ERROR_BC_IS_NOT_ACTIVE.equals(exception.getMessage())) {
				log.error(logMethod, "BC_IS_NOT_ACTIVE");
				throw new AgreementCustomerReferenceApplicationException("4024", AgreementCustomerReferenceDAOConstants.BAD_REQUEST_HTTP_STATUS);
			} else if (PartyManagementConnectConstants.ERROR_BC_DOES_NOT_EXIST.equals(exception.getMessage())) {
				log.error(logMethod, "BC_DOES_NOT_EXIST");
				throw new AgreementCustomerReferenceApplicationException("4003", AgreementCustomerReferenceDAOConstants.BAD_REQUEST_HTTP_STATUS);
			} else {
				log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_EXCEPTION_WHILE_RETRIEVING_BC_DETAILS, exception);
				throw new AgreementCustomerReferenceApplicationException(exception.getMessage(), exception.getStatus());
			}
		}

		return retrievePartyDetailsResponseTO;
	}

	/**
	 * returns the active version of the responsible party 
	 * 
	 * @param responsiblePartyVersionViewList responsible party versions from database
	 * @return active responsible party version
	 */
	public ResponsiblePartyVersionView retrieveActiveResponsiblePartyVersion(List<ResponsiblePartyVersionView> responsiblePartyVersionViewList){
		Collections.sort(responsiblePartyVersionViewList);
		for( ResponsiblePartyVersionView responsiblePartyVersion  : responsiblePartyVersionViewList){
			if("1".equals(responsiblePartyVersion.getStatus())){
				return responsiblePartyVersion;
			}
		}
		return null;
	}
	
	/**
	 * returns BO number from the input
	 * 
	 * @param retrievePartyDetailsResponseTO Party details of the customer
	 * @return organization Id
	 */
	public String getCustomerBO(RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO) {
		if(retrievePartyDetailsResponseTO!=null 
				&& retrievePartyDetailsResponseTO.getCustomer()!=null 
				&& retrievePartyDetailsResponseTO.getCustomer().getManagingOrganizationUnitId()!=null
				&& retrievePartyDetailsResponseTO.getCustomer().getManagingOrganizationUnitId().getValue()!= null){
			
			return retrievePartyDetailsResponseTO.getCustomer().getManagingOrganizationUnitId().getValue();
		}
		return null;
	}
	
	/**
	 * This method returns building block Id of the first contract administration
	 * 
	 * @param agreementAdministrationReferences building block references from rest model
	 * @param buildingBlockClusterTypeViewList building block details of the product from database
	 * @return building block Id of the first contract administration
	 */
	public int getFirstAgreementAdministrationKey(List<AgreementAdministrationReference> agreementAdministrationReferences, List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList) {
		int firstAgreementAdministrationKey = 0;
		outer : for(BuildingBlockClusterTypeView buildingBlockClusterTypeView: buildingBlockClusterTypeViewList){
			for(AgreementAdministrationReference agreementAdministrationReference :agreementAdministrationReferences){
				if(Integer.valueOf(agreementAdministrationReference.getAgreementAdministrationId()) == buildingBlockClusterTypeView.getBuildingBlockId()
						&& "C".equals(buildingBlockClusterTypeView.getBuildingBlockType())) {
					firstAgreementAdministrationKey = Integer.valueOf(agreementAdministrationReference.getAgreementAdministrationId());
					break outer;
				}
			}
		}
		return firstAgreementAdministrationKey;
	}

	/**
	 * This method returns building block Id of the first contract administration
	 *
	 * @param buildingBlockClusterTypeViewList building block details of the product from database
	 * @return building block Id of the first contract administration
	 */
	public int findFirstAgreementAdministrationKey(List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList) {
		int agreementAdministrationKey = 0;

		for (BuildingBlockClusterTypeView buildingBlockClusterType : buildingBlockClusterTypeViewList) {
			if ("C".equals(buildingBlockClusterType.getBuildingBlockType())) {
				agreementAdministrationKey = buildingBlockClusterType.getBuildingBlockId();

				break;
			}
		}

		return agreementAdministrationKey;
	}

	/**
	 * Truncate the given consumer id to fit into the database, i.e. column CHUSERID which has a maximum of 13 characters.
	 * The consumer-id may contain the business application of up to 5 characters or the OAR id of the consuming application.
	 * @param consumerId - the incoming consumer id that may not fit into the database
	 * @return the consumer id that will fit
	 */
	public String truncateConsumerId(String consumerId) {
		String truncatedConsumerId = "";

		// if the length exceeds the maximum length it is expected to contain the OAR id where hyphens are used as a separator, e.g. AAB-SYS-017664
		if (consumerId != null && consumerId.length() > MAX_LENGTH_CONSUMER_ID) {

			// remove the hyphens from the OAR id
			truncatedConsumerId = consumerId.replace("-", "");

			// check if the truncated text does fit
			if (truncatedConsumerId.length() > MAX_LENGTH_CONSUMER_ID) {

				// take the maximum allowed number of characters from the right
				truncatedConsumerId = truncatedConsumerId.substring(truncatedConsumerId.length() - MAX_LENGTH_CONSUMER_ID);
				log.info("truncateConsumerId", AgreementCustomerReferenceLogConstants.LOG_CONSUMER_ID_HAS_UNEXPECTED_FORMAT, "consumer-id: " + consumerId);
			}
		} else if (isConsumerIdEmpty(consumerId)) {
			truncatedConsumerId = AgreementCustomerReferenceRequestProcessorUtils.DEFAULT_API_CONSUMER_ID;
		} else {
			truncatedConsumerId = consumerId;
		}

		return truncatedConsumerId;
	}

	/**
	 * Return true if the given consumer id is considered an empty string.
	 */
	boolean isConsumerIdEmpty(String consumerId) {
		boolean isEmpty = false;

		if (consumerId == null || consumerId.trim().length() == 0) {
			isEmpty = true;
		}

		return isEmpty;
	}
}
