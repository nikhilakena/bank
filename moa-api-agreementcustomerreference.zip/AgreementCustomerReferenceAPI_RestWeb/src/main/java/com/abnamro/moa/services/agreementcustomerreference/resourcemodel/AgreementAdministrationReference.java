package com.abnamro.moa.services.agreementcustomerreference.resourcemodel;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import java.util.Objects;

/**
 * The identification of an agreementadministration. Contains the reference details of the agreementAdministration.
 */
@ApiModel(description = "The identification of an agreementadministration. Contains the reference details of the agreementAdministration.")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-04-05T11:21:31.987Z")

public class AgreementAdministrationReference   {
  @JsonProperty("agreementAdministrationId")
  private String agreementAdministrationId = null;

  @JsonProperty("agreementAdministrationReferenceId")
  private String agreementAdministrationReferenceId = null;

  public AgreementAdministrationReference agreementAdministrationId(String agreementAdministrationId) {
    this.agreementAdministrationId = agreementAdministrationId;
    return this;
  }

  /**
   * agreementAdministrationId contains the numeric identification of an administration where the agreement is registered.  For example 05 = CRC (current account adminstration)  
   * @return agreementAdministrationId
  **/
  @ApiModelProperty(example = "5", required = true, value = "agreementAdministrationId contains the numeric identification of an administration where the agreement is registered.  For example 05 = CRC (current account adminstration)  ")
  public String getAgreementAdministrationId() {
    return agreementAdministrationId;
  }

  public void setAgreementAdministrationId(String agreementAdministrationId) {
    this.agreementAdministrationId = agreementAdministrationId;
  }

  public AgreementAdministrationReference agreementAdministrationReferenceId(String agreementAdministrationReferenceId) {
    this.agreementAdministrationReferenceId = agreementAdministrationReferenceId;
    return this;
  }

  /**
   * Agreement identification used within an adminstration. Can be BRN / CIN / FileNumber etc.
   * @return agreementAdministrationReferenceId
  **/
  @ApiModelProperty(example = "1091283011", required = true, value = "Agreement identification used within an adminstration. Can be BRN / CIN / FileNumber etc.")
  public String getAgreementAdministrationReferenceId() {
    return agreementAdministrationReferenceId;
  }

  public void setAgreementAdministrationReferenceId(String agreementAdministrationReferenceId) {
    this.agreementAdministrationReferenceId = agreementAdministrationReferenceId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AgreementAdministrationReference agreementAdministrationReference = (AgreementAdministrationReference) o;
    return Objects.equals(this.agreementAdministrationId, agreementAdministrationReference.agreementAdministrationId) &&
        Objects.equals(this.agreementAdministrationReferenceId, agreementAdministrationReference.agreementAdministrationReferenceId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(agreementAdministrationId, agreementAdministrationReferenceId);
  }

}

