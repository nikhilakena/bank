package com.abnamro.moa.services.agreementcustomerreference.daoinvoker;

import java.sql.Connection;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyVersionView;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyView;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.mapper.ResponsiblePartyMapper;
import com.abnamro.moa.services.agreementcustomerreference.requestprocessor.AgreementCustomerReferenceRequestProcessorUtils;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;

/**
 * It facilitates calling of dao layer methods
 */
@Component
public class ResponsiblePartyDAOInvoker {
	
	@Autowired
	private ResponsiblePartyDAO responsiblePartyDao;
	
	@Autowired
	private ResponsiblePartyMapper responsiblePartyMapper;
	
    @Autowired
    private AgreementCustomerReferenceRequestProcessorUtils processorUtils;

	/**
	 * Calls dao layer method to retrieve responsible party
	 * 
	 * @param agreementCustomerReferenceId unique Id of the contract header
	 * @return responsible party details
	 * @throws AgreementCustomerReferenceDAOException in case of errors
	 */
	public ResponsiblePartyView getResponsibleParty(String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {
		return responsiblePartyDao.getResponsibleParty(agreementCustomerReferenceId);
	}
	
	/**
	 * Maps rest resource model to dao layer view and calls the dao layer to create responsible party
	 * 
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId unique Id of the contract header
	 * @param consumerId user ID
	 * @return responsiblePartyId unique key for Responsible party in contract header
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public int createResponsibleParty(Connection connection, String agreementCustomerReferenceId, String consumerId) throws AgreementCustomerReferenceDAOException {

        String userId = consumerId != null ? consumerId : " ";
        ResponsiblePartyView responsiblePartyView = responsiblePartyMapper
                .getPopulatedResponsiblePartyView(agreementCustomerReferenceId, userId);

        int responsiblePartyId  = responsiblePartyDao.createResponsibleParty(connection,responsiblePartyView);
        
        return responsiblePartyId;
	}
	
	/**
	 * Maps rest resource model to dao layer view and calls the dao layer to create responsible party version
	 * 
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId unique Id of the contract header
	 * @param responsiblePartyId unique key for Responsible party in contract header
	 * @param organizationId BO number
	 * @param consumerId BC number
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */ 
	public void createResponsiblePartyVersion(Connection connection, String agreementCustomerReferenceId, int responsiblePartyId, String organizationId, String consumerId) throws AgreementCustomerReferenceDAOException {

		 String userId = consumerId != null ? consumerId : " ";
		 
		ResponsiblePartyVersionView responsiblePartyVersion = responsiblePartyMapper
                .getPopulatedResponsiblePartyVersionView(agreementCustomerReferenceId, responsiblePartyId, userId);

        responsiblePartyVersion.setOrganizationUnitId(StringUtils.leftPad(String.valueOf(organizationId), 6, "0"));

        responsiblePartyDao.createResponsiblePartyVersion(connection,responsiblePartyVersion);
	}

	/**
	 * Delete the responsible party that has the given agreement customer reference id.
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId - id of the responsible party that is to be deleted
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public void deleteResponsibleParties(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {
		responsiblePartyDao.deleteResponsibleParties(connection, agreementCustomerReferenceId);
	}

	/**
	 *  Maps rest resource model to dao layer view and calls the dao layer to update responsible party version
	 * 
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param responsiblePartyVersion active responsible party version
	 * @param responsiblePartyId unique key for Responsible party in contract header
	 * @param consumerId user ID
	 * @param status to be updated
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public void updateResponsiblePartyVersionStatus(Connection connection, ResponsiblePartyVersionView responsiblePartyVersion, int responsiblePartyId, String consumerId, String status) throws AgreementCustomerReferenceDAOException {
		
		String userId = consumerId != null ? consumerId : " ";
		
		responsiblePartyDao.updateResponsiblePartyVersionStatus(connection,responsiblePartyId, responsiblePartyVersion.getStartDate(),status,userId);
	}

	/**
	 * Delete the responsible party version with the given agreement customer reference id.
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId - the agreement customer reference id of the responsible party versions that is to be deleted.
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public void deleteResponsiblePartyVersions(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {
		responsiblePartyDao.deleteResponsiblePartyVersions(connection, agreementCustomerReferenceId);
	}
}
