package com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.ElementType;

import javax.validation.Constraint;
import javax.validation.Payload;

/**
 * NotNullOrNotBlank custom annotation 
 */
@Target(value = {ElementType.FIELD,ElementType.METHOD, ElementType.PARAMETER})
@Retention(value = RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = NotNullOrNotBlankValidator.class)
public @interface NotNullOrNotBlank {
	
    /**
     * Override method for the @interface 
     * 
     * @return default message
     */
    String message() default "{javax.validation.constraints.Pattern.message}";


    /**
     * Override method for the @interface 
     * 
     * @return default is empty
     */
    Class<?>[] groups() default { };
    
    /**
     * Override method for the @interface 
     * 
     * @return default is empty
     */
    Class<? extends Payload>[] payload() default {};
}

