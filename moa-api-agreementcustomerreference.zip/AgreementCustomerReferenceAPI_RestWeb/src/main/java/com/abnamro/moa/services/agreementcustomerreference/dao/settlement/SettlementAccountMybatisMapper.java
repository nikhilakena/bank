package com.abnamro.moa.services.agreementcustomerreference.dao.settlement;

import org.apache.ibatis.annotations.Param;

/**
 * This class is the mapper class for AgreementCustomerReferenceDAO with the database
 */
public interface SettlementAccountMybatisMapper {
	/**
	 * Create a settlement account in the database.
	 * 
	 * @param schemaName - the name of the schema where the persistent settlement accounts resides
	 * @param settlementAccount - details of the settlement account that is to be persisted
	 */
	public void insertSettlementAccount(
			@Param("schemaName") String schemaName
			, @Param("settlementAccountView") SettlementAccountView settlementAccount);

	/**
	 * Find the maximum id of the settlement accounts in the database and return it.
	 * 
	 * @param schemaName - the name of the schema where the persistent settlement accounts reside
	 * @return the highest of all persistent settlement accounts
	 */
	public int getMaxSettlementAccountId(@Param("schemaName") String schemaName);

	/**
	 * Delete the settlement account from the database.
	 * @param schemaName - the name of the schema where the persistent settlement accounts resides
	 * @param agreementCustomerReferenceId - the agreement customer reference id of the settlement account that is to be deleted
	 */
	public void deleteSettlementAccount(@Param("schemaName") String schemaName, @Param("agreementCustomerReferenceId") String agreementCustomerReferenceId);

	/**
	 * Retrieve the settlement account with the given agreement customer reference id and return it.
	 * @param schemaName - the name of the schema where the persistent settlement accounts resides
	 * @param agreementCustomerReferenceId - the agreement customer reference id of the settlement account that is to be deleted
	 * @return the settlement account number of the settlement account with the given id
	 */
	String retrieveSettlementAccount(@Param("schemaName") String schemaName, @Param("agreementCustomerReferenceId") String agreementCustomerReferenceId);
	
	/**
	 * Updates a settlement account in the database.
	 * 
	 * @param schemaName - the name of the schema where the persistent settlement accounts resides
	 * @param settlementAccount - details of the settlement account that is to be persisted
	 */
	public void updateSettlementAccount(@Param("schemaName") String schemaName, @Param("settlementAccountView") SettlementAccountView settlementAccount);

}
