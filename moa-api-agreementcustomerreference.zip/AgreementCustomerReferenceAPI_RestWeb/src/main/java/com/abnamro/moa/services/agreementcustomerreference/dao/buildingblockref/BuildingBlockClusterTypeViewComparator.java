package com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref;

import java.util.Comparator;

/**
 * This is the Comparator class which will be used to sort the BuildingBlockClusterTypeView based on Type and then based on building block ID
 *
 */
public class BuildingBlockClusterTypeViewComparator implements Comparator<BuildingBlockClusterTypeView>{

	@Override
	public int compare(BuildingBlockClusterTypeView o1, BuildingBlockClusterTypeView o2) {
		if(o1.getBuildingBlockType().compareTo(o2.getBuildingBlockType()) == 0){
			return o1.getBuildingBlockId()- o2.getBuildingBlockId();
		}else {
			return o1.getBuildingBlockType().compareTo(o2.getBuildingBlockType());
		}
	}

}
