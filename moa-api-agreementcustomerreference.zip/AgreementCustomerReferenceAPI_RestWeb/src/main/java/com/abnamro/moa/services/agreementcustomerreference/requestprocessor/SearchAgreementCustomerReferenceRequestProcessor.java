package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.constants.AgreementCustomerReferenceLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.constants.AgreementCustomerReferenceValidatorConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.mapper.ObjectMapper;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.util.IbanUtils;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *  This is the request processor interface for the Search AgreementCustomerReference operation
 *
 */
@Component
public class SearchAgreementCustomerReferenceRequestProcessor {
	private static LogHelper log = new LogHelper(UpdateAgreementCustomerReferenceRequestProcessor.class);
	
	@Autowired
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDAO;

	@Autowired
	private SettlementAccountDAO settlementAccountDao;

	@Autowired
	private ConnectionProvider connectionProvider;

	@Autowired
	private AgreementCustomerReferenceValidator validator;

	@Autowired
	private AgreementCustomerReferenceProductValidationDAO productValidationDao;

	/**
	 * Retrieves the contract header details from dao layer and pass it to rest layer
	 * 
	 * @param productId unique identifier of the product
	 * @param commercialAgreementId unique identifier of the contract
	 * @param agreementAdministrationId building block id
	 * @param agreementAdministrationReferenceId building block reference contract number
	 * @return Contract header details
	 * @throws AgreementCustomerReferenceApplicationException in case of errors
	 */
	public AgreementCustomerReference processSearchAgreementCustomerReference(String productId, String commercialAgreementId,
			String agreementAdministrationId, String agreementAdministrationReferenceId) throws AgreementCustomerReferenceApplicationException {
		final String logMethod = "processSearchAgreementCustomerReference";
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		try {
			AgreementCustomerReferenceView agreementCustomerReferenceView = agreementCustomerReferenceDAO.retrieveAgreementCustomerReferences(productId,commercialAgreementId,agreementAdministrationId,agreementAdministrationReferenceId);
			agreementCustomerReference = copyPersistentAgreementCustomerReferenceToResponse(agreementCustomerReferenceView, agreementCustomerReference);
		} catch (AgreementCustomerReferenceDAOException exception) {
			log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_DAO_EXCEPTION_IN_SEARCH_AGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(),exception.getStatus());
		}
		return agreementCustomerReference;
	}

	/**
	 * Copy the details from the persistent agreement customer reference to the response object.
	 * @param persistentAgreementCustomerReference - the persistent agreement customer reference
	 * @param responseAgreementCustomerReference - the agreement customer reference in the response
	 * @return the agreement customer reference object with the details from the persistent object
	 * @throws AgreementCustomerReferenceApplicationException in case an error occurrs
	 */
	private AgreementCustomerReference copyPersistentAgreementCustomerReferenceToResponse(AgreementCustomerReferenceView persistentAgreementCustomerReference,
		AgreementCustomerReference responseAgreementCustomerReference) throws AgreementCustomerReferenceApplicationException {
		if (persistentAgreementCustomerReference != null) {
			responseAgreementCustomerReference = ObjectMapper.convertToAgreementCustomerReferenceFromView(persistentAgreementCustomerReference);

			// retrieve the settlement account number of the package
			if (isPackage(persistentAgreementCustomerReference)) {
				String packageSettlementAccountNumber = retrievePackageSettlementAccount(persistentAgreementCustomerReference.getId());
				if (StringUtils.isNotBlank(packageSettlementAccountNumber)) {
					String packageSettlementAccountNumberIban = IbanUtils.convertToIBAN(packageSettlementAccountNumber.trim());
					responseAgreementCustomerReference.setPackageSettlementAccountNumber(packageSettlementAccountNumberIban);
				}
			}
		}

		return responseAgreementCustomerReference;
	}

	private String retrievePackageSettlementAccount(String agreementCustomerReferenceId) throws AgreementCustomerReferenceApplicationException {
		String settlementAccount = null;

		String logMethod = "retrievePackageSettlementAccount";

		try {
			settlementAccount = settlementAccountDao.retrieveSettlementAccountNumber(agreementCustomerReferenceId);
		} catch (AgreementCustomerReferenceDAOException exception) {
			log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_DAO_EXCEPTION_IN_SEARCH_AGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(), exception.getStatus());
		}

		return settlementAccount;
	}

	/**
	 * Return true if the product in the given agreement customer reference is a package.
	 * @param agreementCustomerReference - the persistent agreement customer reference
	 * @return true if its product is a package
	 */
	private boolean isPackage(AgreementCustomerReferenceView agreementCustomerReference) {
		boolean isPackage = false;

		// check the package type
		try {
			String productType = productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()));
			if(StringUtils.isNotBlank(productType) && AgreementCustomerReferenceValidatorConstants.PACKAGE_PRODUCT_TYPE.equalsIgnoreCase(productType)){
				isPackage = true;
			}
		} catch (AgreementCustomerReferenceDAOException exception) {
			log.info("isPackage", AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_WHILE_VALIDATING_PRODUCT_ID, exception);
		}

		return isPackage;
	}
}
