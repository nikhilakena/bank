package com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import com.abnamro.moa.services.agreementcustomerreference.dao.AgreementCustomerReferenceMybatisMapper;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.nl.channels.jndilookup.JndiConstants;
import com.abnamro.nl.channels.jndilookup.JndiLookup;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.dao.util.mybatis.MyBatisConfigException;
import com.abnamro.nl.dao.util.mybatis.MyBatisConnectionFactory;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;

/**
 * Implementation to validate products by interacting with the database.
 */
@Configuration
public class AgreementCustomerReferenceProductValidationDAOImpl implements AgreementCustomerReferenceProductValidationDAO {
	private static LogHelper logHelper = new LogHelper(AgreementCustomerReferenceProductValidationDAOImpl.class);
	
	@Autowired
	private ConnectionProvider connectionProvider;

	private final String dbSchemaPrefix;
	private final String dataSourceName;
	private static final String CONFIG_FILE_PATH = "dao/acr-mybatis-config.xml";
	private static MyBatisConnectionFactory connetionFactory;

	/**
	 * Create the DAO and setup the connection to the database.
	 */
	public AgreementCustomerReferenceProductValidationDAOImpl() {
		dbSchemaPrefix = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.SCHEMA_DATABASE, AgreementCustomerReferenceDAOConstants.DEFAULT_DB_SCHEMA);
		dataSourceName = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.DATASOURCE_NAME, AgreementCustomerReferenceDAOConstants.DEFAULT_DATASOURCE);
		if (connetionFactory == null) {
			setConnetionFactory(getConnectionFactoryInstance());
		}
	}

	@Override
	public boolean isProductIdValid(Integer productId) throws AgreementCustomerReferenceDAOException {
		boolean valid = false;

		Connection connection = null;
		String logMethod = "isProductIdValid";

		try {
			connection = connectionProvider.getConnection();
			SqlSession sqlSession = connetionFactory.getSession(connection);

			AgreementCustomerReferenceProductView product = sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).selectProductsById(dbSchemaPrefix, productId);
			valid = isProductValid(product);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_WHILE_VALIDATING_PRODUCT_ID
					+ " mybatis exception while validating product id {0}"
				, exception, productId);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (DAODatabaseException daoDatabaseException) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_CONNECTION,
					daoDatabaseException);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnection(connection);
		}

		return valid;
	}

	/**
	 * Return true if the given product is considered valid.
	 */
	boolean isProductValid(AgreementCustomerReferenceProductView product) {
		boolean valid = false;

		// valid product must exist in product model
		valid = product != null;

		// valid product has type of 'P'
		if (valid) {
			valid = StringUtils.isNotEmpty(product.getType());
		}

		return valid;
	}

	/**
	 * @return returns an instance of MyBatisConnectionFactory class
	 */
	private static synchronized MyBatisConnectionFactory getConnectionFactoryInstance() {
	    final String logMethod = "getConnectionFactoryInstance():MyBatisConnectionFactory";

		try {
			// Creates new Instance for MyBatis Connection factory & loads the
			// Mybatis Configuration file
			return new MyBatisConnectionFactory(CONFIG_FILE_PATH);
		} catch (MyBatisConfigException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_IBATIS_INITIALIZATION, null, exception);
		}

		return null;
	}

	private static synchronized void setConnetionFactory(MyBatisConnectionFactory myBatisConnectionFactory) {
		connetionFactory = myBatisConnectionFactory;
	}

	/**
	 * It returns data source name to be used by the DAO.
	 * 
	 * @return the data source name to be used by the DAO.
	 */
	protected String getDataSourceName() {
		return dataSourceName;
	}

	/**
	 * @param productId unique id of the product
	 * @return productType product type value
	 * @throws AgreementCustomerReferenceDAOException Exception thrown at DAO layer
	 */
	@Override
	public String getProductType(Integer productId) throws AgreementCustomerReferenceDAOException {
		String type = null;
		Connection connection = null;
		String logMethod = "getProductType";

		try {
			connection = connectionProvider.getConnection();
			SqlSession sqlSession = connetionFactory.getSession(connection);

			AgreementCustomerReferenceProductView product = sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).selectProductsById(dbSchemaPrefix, productId);
			if(product != null && StringUtils.isNotBlank(product.getType())){
				type = product.getType().trim();
			}
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_WHILE_VALIDATING_PRODUCT_ID
					+ " mybatis exception while retrieving product type {0}"
				, exception, productId);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (DAODatabaseException daoDatabaseException) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_CONNECTION,
					daoDatabaseException);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnection(connection);
		}

		return type;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Integer> retrieveProductGroupIdsForProduct(int productId) throws AgreementCustomerReferenceDAOException {
		List<Integer> productGroupIds = new ArrayList<>();

		Connection connection = null;
		String logMethod = "retrieveProductGroupIdsForProduct";

		try {
			connection = connectionProvider.getConnection();
			SqlSession sqlSession = connetionFactory.getSession(connection);

			// execute the query to retrieve the list of product group ids of the product
			List<ProductGroupIdsView> productGroupIdsView = sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).readProductGroupIds(dbSchemaPrefix, productId);

			productGroupIds = convertProductGroupIdsViewToIntegers(productGroupIdsView);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
				AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_WHILE_VALIDATING_PRODUCT_ID
					+ " mybatis exception while retrieving product groups for product id {0}"
				, exception, productId);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (DAODatabaseException daoDatabaseException) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_CONNECTION, daoDatabaseException);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnection(connection);
		}

		return productGroupIds;
	}

	/**
	 * Iterate over the list of persistent ProductGroupIdsView objects, read each product id into a local list
	 * and return that list.
	 * @param productGroupIdsViews - the list of persistent product group id objects
	 * @return the list of product group ids
	 */
	private List<Integer> convertProductGroupIdsViewToIntegers(List<ProductGroupIdsView> productGroupIdsViews) {
		List<Integer> productGroupIds = new ArrayList<>();

		if (productGroupIdsViews != null) {
			for (ProductGroupIdsView productGroupId : productGroupIdsViews) {
				productGroupIds.add(productGroupId.getProductGroupId());
			}
		}

		return productGroupIds;
	}
}
