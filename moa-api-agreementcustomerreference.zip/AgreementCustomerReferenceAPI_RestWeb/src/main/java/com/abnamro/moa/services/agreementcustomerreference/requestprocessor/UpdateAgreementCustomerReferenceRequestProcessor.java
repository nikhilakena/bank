package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.exceptions.AgreementCustomerReferenceExternalPublisherException;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.constants.AgreementCustomerReferenceLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeViewComparator;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyVersionView;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyView;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.AgreementCustomerReferenceDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.ResponsiblePartyDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.SettlementAccountDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.mapper.BuildingBlockMapper;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

/**
 *  This is the request processor interface for the UpdateAgreementCustomerReference operation
 *
 */
@Component
public class UpdateAgreementCustomerReferenceRequestProcessor {
    
    private static LogHelper log = new LogHelper(UpdateAgreementCustomerReferenceRequestProcessor.class);
    
    @Autowired
    private AgreementCustomerReferenceValidator agreementCustomerReferenceValidator;

    @Autowired
    private AgreementCustomerReferenceDAOInvoker agreementCustomerReferenceDAOInvoker;
    
    @Autowired
    private BuildingBlockDAO buildingBlockDao;
    
    @Autowired
    private ResponsiblePartyDAOInvoker responsiblePartyDAOInvoker;
    
    @Autowired
    private BuildingBlockMapper buildingBlockMapper;

    @Autowired
    private ConnectionProvider connectionProvider;
    
    @Autowired
    private AgreementCustomerReferenceRequestProcessorUtils processorUtils;
    
    @Autowired
    private PublishAgreementCustomerReferenceHelper publishAgreementCustomerReferenceHelper;
    
    @Autowired
    private SettlementAccountDAOInvoker settlementAccountDAOInvoker;
    
    /**
     * Calls different dao layer methods to update record
     * 
     * @param agreementCustomerReferenceId unique identifier for contract header
     * @param updateRequestInput update request for AgreementCustomerReference
     * @param consumerId user Id or application ID
     * @throws AgreementCustomerReferenceApplicationException in case of error
     */
    public void processUpdateAgreementCustomerReferenceRequest(String agreementCustomerReferenceId, AgreementCustomerReferenceForPatch updateRequestInput, String consumerId) throws AgreementCustomerReferenceApplicationException {
        final String logMethod = "processUpdateAgreementCustomerReferenceRequest";

		Connection connection = null;

        try {
            AgreementCustomerReferenceView agreementCustomerReferenceView = agreementCustomerReferenceDAOInvoker.getAgreementCustomerReference(agreementCustomerReferenceId);

            if(agreementCustomerReferenceView!=null){
                if(updateRequestInput.getProductId()!=null) {
                	agreementCustomerReferenceValidator.validateProductTypeChange(updateRequestInput.getProductId(),agreementCustomerReferenceView.getProductId());
                }
                
                // retrieve the customer's details
				RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = checkCustomerExistence(updateRequestInput.getCustomerId());

                //retrieve responsible party details for contract header Id
                ResponsiblePartyView responsiblePartyView = responsiblePartyDAOInvoker.getResponsibleParty(agreementCustomerReferenceView.getId());

                //retrieving the building block details for product Id
				List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = validateBuildingBlocks(updateRequestInput, agreementCustomerReferenceView);

				connection = connectionProvider.getConnection();
                connection.setAutoCommit(false);
                
                //update AgreementCustomerReference 
                updateAgreementCustomerReference(connection, agreementCustomerReferenceView.getId(), updateRequestInput, consumerId);
                //update building block details 
                updateBuildingBlockDetails(connection,updateRequestInput,buildingBlockClusterTypeViewList,agreementCustomerReferenceView.getId());
                //process updation or creation of responsible party
                processResponsibleParty(connection,responsiblePartyView,agreementCustomerReferenceView,updateRequestInput, retrievePartyDetailsResponseTO, consumerId);
              
                //publish MO update event to other systems by calling MO856 transaction
                publishAgreementCustomerReferenceHelper.publishUpdateAgreementCustomerReference(agreementCustomerReferenceView, updateRequestInput, buildingBlockClusterTypeViewList,consumerId);
                
                connection.commit();   
            } else {
                //agreement record not present in database for input productId and commercial agreement Id
                throw new AgreementCustomerReferenceApplicationException("4028",AgreementCustomerReferenceDAOConstants.RESOURCE_NOT_FOUND_HTTP_STATUS);
            }
        } catch (DAODatabaseException exception) {
             log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_DAO_EXCEPTION_UPDATE_AGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
             throw new AgreementCustomerReferenceApplicationException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
        } catch (SQLException exception) {
            log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_SQL_EXCEPTION_UPDATE_AGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
             throw new AgreementCustomerReferenceApplicationException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
        } catch (AgreementCustomerReferenceDAOException exception) {
            log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_DAO_EXCEPTION_IN_UPDATE_AGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
            throw new AgreementCustomerReferenceApplicationException(exception.getMessage(),exception.getStatus());
        } catch (AgreementCustomerReferenceExternalPublisherException exception) {
            log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_IMS_PUBLISH_EXCEPTION_IN_CREATEAGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
            throw new AgreementCustomerReferenceApplicationException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnection(connection);
        }
    }

	private void processResponsibleParty(Connection connection, ResponsiblePartyView responsiblePartyView,
			AgreementCustomerReferenceView agreementCustomerReferenceView, AgreementCustomerReferenceForPatch updateRequestInput,
			RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO, String consumerId) throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException {
    	if (responsiblePartyView == null) {
            //if no details are present for input contract header Id then create responsible party and version
    		String organizationId = updateRequestInput.getOrganisationUnitId() != null 
    				? updateRequestInput.getOrganisationUnitId() 
    				: getCustomerBO(retrievePartyDetailsResponseTO,agreementCustomerReferenceView.getCustomerId());
    				
    		int responsiblePartyId  = responsiblePartyDAOInvoker.createResponsibleParty(connection, agreementCustomerReferenceView.getId(), consumerId);
    				
    		responsiblePartyDAOInvoker.createResponsiblePartyVersion(connection, agreementCustomerReferenceView.getId(), responsiblePartyId, organizationId, consumerId);
    		
        } else if (updateRequestInput.getOrganisationUnitId() != null) {
            //if details are present for input contract header Id and OrganisationUnitId is present in input then create new version and update existing responsible party version
        	
        	responsiblePartyDAOInvoker.createResponsiblePartyVersion(connection, agreementCustomerReferenceView.getId(), responsiblePartyView.getNumber(), updateRequestInput.getOrganisationUnitId(), consumerId);
        	
        	if(!org.springframework.util.CollectionUtils.isEmpty(responsiblePartyView.getResponsiblePartyVersionViewList())){

                ResponsiblePartyVersionView activeVersion = processorUtils.retrieveActiveResponsiblePartyVersion(responsiblePartyView.getResponsiblePartyVersionViewList());
                if(activeVersion!= null){
                	responsiblePartyDAOInvoker.updateResponsiblePartyVersionStatus(connection, activeVersion, responsiblePartyView.getNumber(), consumerId, "9");
                }
        	}
        }
	}

	private List<BuildingBlockClusterTypeView> getBuildingBlockDetails(AgreementCustomerReferenceForPatch updateRequestInput, String productId)
		throws AgreementCustomerReferenceDAOException {
		return updateRequestInput.getProductId() != null
				? buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(updateRequestInput.getProductId()))
				: buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(productId));
	}

	private void updateBuildingBlockDetails(Connection connection,
            AgreementCustomerReferenceForPatch updateRequestInput, List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {

        if(!org.springframework.util.CollectionUtils.isEmpty(updateRequestInput.getAgreementAdministrationReferences())){
            
        	//delete all the references 
            buildingBlockDao.deleteBuildingBlockReferences(connection,agreementCustomerReferenceId);
            
            Collections.sort(buildingBlockClusterTypeViewList, new BuildingBlockClusterTypeViewComparator());
            //populate to be inserted list of building blocks
            List<BuildingBlockView> buildingBlockViewList = buildingBlockMapper.getPopulatedBuildingBlockViewList(updateRequestInput.getAgreementAdministrationReferences(),buildingBlockClusterTypeViewList,agreementCustomerReferenceId);
            
            for(BuildingBlockView buildingBlockView :buildingBlockViewList) {
                buildingBlockDao.insertBuildingBlockRef(connection,buildingBlockView);
            }
        } else if(updateRequestInput.getProductId()!=null) {
            buildingBlockDao.deleteBuildingBlockReferences(connection,agreementCustomerReferenceId);
        }
        
    }

    private void updateAgreementCustomerReference(Connection connection, String agreementCustomerReferenceId, AgreementCustomerReferenceForPatch updateRequestInput, String consumerId) throws AgreementCustomerReferenceDAOException {
    	
    	agreementCustomerReferenceDAOInvoker.updateAgreementCustomerReference(connection, agreementCustomerReferenceId, updateRequestInput, consumerId);
        
    }

	/**
	 * Check if the customer with the given id exists and return its details if possible.
	 * @param customerId - the id of the customer to check for
	 * @return the details of the found customer
	 * @throws AgreementCustomerReferenceApplicationException is thrown if validations are not passed successfully
	 */
    private RetrievePartyDetailsResponseTO checkCustomerExistence(String customerId) throws AgreementCustomerReferenceApplicationException {
		RetrievePartyDetailsResponseTO customerDetails = null;

		if (customerId != null){

			//retrieving the responsible party details of the customer
			customerDetails = processorUtils.getCustomerDetails(customerId);

			//validating the life cycle status of the customer
			agreementCustomerReferenceValidator.isCustomerExists(customerDetails);
		}

		return customerDetails;
	}

	/**
	 * Validate the building blocks and return it if possible.
	 * @param updateRequestInput - the details to update from the request
	 * @param agreementCustomerReference - the persistent agreement customer reference
	 * @return the list of building blocks
	 * @throws AgreementCustomerReferenceDAOException is thrown if an exception occurs when retrieving details from the database
	 * @throws AgreementCustomerReferenceApplicationException is thrown when the details from the input cannot be validated
	 */
	private List<BuildingBlockClusterTypeView> validateBuildingBlocks(AgreementCustomerReferenceForPatch updateRequestInput, AgreementCustomerReferenceView agreementCustomerReference)
		throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		List<BuildingBlockClusterTypeView> buildingBlocks = null;

		if(!org.springframework.util.CollectionUtils.isEmpty(updateRequestInput.getAgreementAdministrationReferences())){
			buildingBlocks = getBuildingBlockDetails(updateRequestInput, agreementCustomerReference.getProductId());

			// validate Building Block Details by checking if only building blocks linked to product are present in input
			agreementCustomerReferenceValidator.validateBuildingBlockDetailsForUpdate(buildingBlocks, updateRequestInput.getAgreementAdministrationReferences(), agreementCustomerReference.getId());
		}

		return buildingBlocks;
	}

	 private String getCustomerBO(RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO, String customerId) throws  AgreementCustomerReferenceApplicationException {
	        if(retrievePartyDetailsResponseTO==null){
	            retrievePartyDetailsResponseTO = processorUtils.getCustomerDetails(customerId);
	        }
	        return processorUtils.getCustomerBO(retrievePartyDetailsResponseTO);
	   }

}
