package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.constants.AgreementCustomerReferenceLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.constants.AgreementCustomerReferenceValidatorConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.mapper.ObjectMapper;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.GetAgreementCustomerReferenceResponse;
import com.abnamro.moa.services.agreementcustomerreference.util.IbanUtils;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;

/**
 * This is the request processor interface for the Search
 * AgreementCustomerReference operation
 *
 */
@Component
public class RetrieveAgreementCustomerReferenceRequestProcessor {
	private static LogHelper log = new LogHelper(UpdateAgreementCustomerReferenceRequestProcessor.class);

	@Autowired
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDAO;

	@Autowired
	private SettlementAccountDAO settlementAccountDao;

	@Autowired
	private AgreementCustomerReferenceProductValidationDAO productValidationDao;

	/**
	 * Retrieves the contract header details from dao layer and pass it to rest
	 * layer
	 * 
	 * @param agreementCustomerReferenceId
	 *            agreement customer reference id
	 * @param includeLinkedAgreementReferences
	 *            used to fetch linked agreement customer references
	 * @return Retrieve Agreement Customer Reference response
	 * @throws AgreementCustomerReferenceApplicationException
	 *             in case of errors
	 */
	public GetAgreementCustomerReferenceResponse processRetrieveAgreementCustomerReference(
			String agreementCustomerReferenceId, boolean includeLinkedAgreementReferences)
			throws AgreementCustomerReferenceApplicationException {
		final String logMethod = "processRetrieveAgreementCustomerReference";
		GetAgreementCustomerReferenceResponse response = null;
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		try {
			// retrieve details of agreementCustomerReferenceId from database
			AgreementCustomerReferenceView agreementCustomerReferenceView = agreementCustomerReferenceDAO
					.retrieveAgreementCustomerReference(agreementCustomerReferenceId);
			if (agreementCustomerReferenceView != null) {
				// map database view into response object
				agreementCustomerReference = copyPersistentAgreementCustomerReferenceToResponse(
						agreementCustomerReferenceView, agreementCustomerReference);
				response = new GetAgreementCustomerReferenceResponse();
				copyAgreementCustomerReferenceToResponse(agreementCustomerReference, response);
				
				// Fetch linked agreement customer references & populate it in response 
				if (includeLinkedAgreementReferences) {
					populateLinkedAgreementReferences(agreementCustomerReferenceId, response);
				}
			}else{
		         //agreement record not present in database for input agreementCustomerReference Id
		         throw new AgreementCustomerReferenceApplicationException("4033",AgreementCustomerReferenceDAOConstants.RESOURCE_NOT_FOUND_HTTP_STATUS);
			}
		} catch (AgreementCustomerReferenceDAOException exception) {
			log.error(logMethod,
					AgreementCustomerReferenceLogConstants.LOG_DAO_EXCEPTION_IN_RETRIEVE_AGREEMENTCUSTOMERREF_IN_PROCESSOR,
					exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(), exception.getStatus());
		}
		return response;
	}

	private void populateLinkedAgreementReferences(String agreementCustomerReferenceId,
			GetAgreementCustomerReferenceResponse response)
			throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		List<AgreementCustomerReference> linkedAgreementReferences = new ArrayList<AgreementCustomerReference>();
		List<AgreementCustomerReferenceView> agreementCustomerReferenceViewList = agreementCustomerReferenceDAO
				.retrieveLinkedAgreementCustomerReferences(agreementCustomerReferenceId);
		if (!agreementCustomerReferenceViewList.isEmpty()) {
			for (int i = 0; i < agreementCustomerReferenceViewList.size(); i++) {
				AgreementCustomerReference linkedAgreementReference = new AgreementCustomerReference();
				linkedAgreementReferences.add(copyPersistentAgreementCustomerReferenceToResponse(
						agreementCustomerReferenceViewList.get(i), linkedAgreementReference));
			}
		}
		response.setLinkedAgreementReferences(linkedAgreementReferences);
	
	}

	private void copyAgreementCustomerReferenceToResponse(AgreementCustomerReference agreementCustomerReference,
			GetAgreementCustomerReferenceResponse response) {
		if (agreementCustomerReference != null) {
			response.setProductId(agreementCustomerReference.getProductId());
			response.setCustomerId(agreementCustomerReference.getCustomerId());
			response.setAgreementLifeCycleStatus(agreementCustomerReference.getAgreementLifeCycleStatus());
			response.setAgreementCustomerReferenceId(
					agreementCustomerReference.getAgreementCustomerReferenceId().trim());
			response.setCommercialAgreementId(agreementCustomerReference.getCommercialAgreementId().trim());
			response.setAgreementAdministrationReferences(
					agreementCustomerReference.getAgreementAdministrationReferences());
			response.setReferenceStartDate(agreementCustomerReference.getReferenceStartDate());
			response.setPackageSettlementAccountNumber(agreementCustomerReference.getPackageSettlementAccountNumber());
			response.setAgreementNickName(agreementCustomerReference.getAgreementNickName());
		}

	}

	/**
	 * Copy the details from the persistent agreement customer reference to the
	 * response object.
	 * 
	 * @param persistentAgreementCustomerReference
	 *            - the persistent agreement customer reference
	 * @param responseAgreementCustomerReference
	 *            - the agreement customer reference in the response
	 * @return the agreement customer reference object with the details from the
	 *         persistent object
	 * @throws AgreementCustomerReferenceApplicationException
	 *             in case an error occurrs
	 */
	private AgreementCustomerReference copyPersistentAgreementCustomerReferenceToResponse(
			AgreementCustomerReferenceView persistentAgreementCustomerReference,
			AgreementCustomerReference responseAgreementCustomerReference)
			throws AgreementCustomerReferenceApplicationException {
		if (persistentAgreementCustomerReference != null) {
			responseAgreementCustomerReference = ObjectMapper
					.convertToAgreementCustomerReferenceFromView(persistentAgreementCustomerReference);

			// retrieve the settlement account number of the package
			if (isPackage(persistentAgreementCustomerReference)) {
				String packageSettlementAccountNumber = retrievePackageSettlementAccount(
						persistentAgreementCustomerReference.getId());
				if (StringUtils.isNotBlank(packageSettlementAccountNumber)) {
					String packageSettlementAccountNumberIban = IbanUtils
							.convertToIBAN(packageSettlementAccountNumber.trim());
					responseAgreementCustomerReference
							.setPackageSettlementAccountNumber(packageSettlementAccountNumberIban);
				}
			}
		}

		return responseAgreementCustomerReference;
	}

	private String retrievePackageSettlementAccount(String agreementCustomerReferenceId)
			throws AgreementCustomerReferenceApplicationException {
		String settlementAccount = null;

		String logMethod = "retrievePackageSettlementAccount";

		try {
			settlementAccount = settlementAccountDao.retrieveSettlementAccountNumber(agreementCustomerReferenceId);
		} catch (AgreementCustomerReferenceDAOException exception) {
			log.error(logMethod,
					AgreementCustomerReferenceLogConstants.LOG_DAO_EXCEPTION_IN_SEARCH_AGREEMENTCUSTOMERREF_IN_PROCESSOR,
					exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(), exception.getStatus());
		}

		return settlementAccount;
	}

	/**
	 * Return true if the product in the given agreement customer reference is a
	 * package.
	 * 
	 * @param agreementCustomerReference
	 *            - the persistent agreement customer reference
	 * @return true if its product is a package
	 */
	private boolean isPackage(AgreementCustomerReferenceView agreementCustomerReference) {
		boolean isPackage = false;

		// check the package type
		try {
			String productType = productValidationDao
					.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()));
			if (StringUtils.isNotBlank(productType) && AgreementCustomerReferenceValidatorConstants.PACKAGE_PRODUCT_TYPE
					.equalsIgnoreCase(productType)) {
				isPackage = true;
			}
		} catch (AgreementCustomerReferenceDAOException exception) {
			log.info("isPackage", AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_WHILE_VALIDATING_PRODUCT_ID,
					exception);
		}

		return isPackage;
	}
}
