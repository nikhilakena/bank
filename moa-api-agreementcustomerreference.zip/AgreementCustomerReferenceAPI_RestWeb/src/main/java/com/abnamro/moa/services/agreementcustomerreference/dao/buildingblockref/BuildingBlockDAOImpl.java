package com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref;

import java.sql.Connection;
import java.util.List;

import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.nl.channels.jndilookup.JndiConstants;
import com.abnamro.nl.channels.jndilookup.JndiLookup;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.dao.util.mybatis.MyBatisConfigException;
import com.abnamro.nl.dao.util.mybatis.MyBatisConnectionFactory;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;

/**
 * Methods to access the persistent building block.
 */
@Configuration
public class BuildingBlockDAOImpl implements BuildingBlockDAO {
	private static LogHelper logHelper = new LogHelper(BuildingBlockDAOImpl.class);

	private final String dbSchemaPrefix;
	private static final String CONFIG_FILE_PATH = "dao/acr-mybatis-config.xml";
	private static MyBatisConnectionFactory connetionFactory;

	@Autowired
	private ConnectionProvider connectionProvider;
	
	/**
	 * Create the access object to communicate with the database.
	 */
	public BuildingBlockDAOImpl() {
		dbSchemaPrefix = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.SCHEMA_DATABASE, AgreementCustomerReferenceDAOConstants.DEFAULT_DB_SCHEMA);
		if (connetionFactory == null) {
			setConnetionFactory(getConnectionFactoryInstance());
		}
	}

	@Override
	public void insertBuildingBlockRef(Connection connection, BuildingBlockView buildingBlock) 
			throws AgreementCustomerReferenceDAOException {
		String logMethod = "insertBuildingBlock";

		try {
			SqlSession sqlSession = connetionFactory.getSession(connection);
			sqlSession.getMapper(BuildingBlockMybatisMapper.class).insertBuildingBlockRef(dbSchemaPrefix, buildingBlock);
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_CREATING_BUILDING_BLOCK
					+ " exception while creating contract header", exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
	}

	/**
	 * @return returns an instance of MyBatisConnectionFactory class
	 */
	private static synchronized MyBatisConnectionFactory getConnectionFactoryInstance() {
	    final String logMethod = "getConnectionFactoryInstance():MyBatisConnectionFactory";

		try {
			// Creates new Instance for MyBatis Connection factory & loads the
			// Mybatis Configuration file
			return new MyBatisConnectionFactory(CONFIG_FILE_PATH);
		} catch (MyBatisConfigException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_IBATIS_INITIALIZATION, null, exception);
		}

		return null;
	}

	private static synchronized void setConnetionFactory(MyBatisConnectionFactory myBatisConnectionFactory) {
		connetionFactory = myBatisConnectionFactory;
	}

	@Override
	public List<BuildingBlockClusterTypeView> getBuildingBlockDetailsForProduct(Integer productId) throws AgreementCustomerReferenceDAOException {
		Connection connection = null;
		String logMethod = "getBuildingBlockDetailsForProduct():List<BuildingBlockClusterTypeView>";
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = null;
		try {
			 connection = connectionProvider.getConnection();
			 SqlSession sqlSession= connetionFactory.getSession(connection);
			 buildingBlockClusterTypeViewList = sqlSession.getMapper(BuildingBlockMybatisMapper.class).getBuildingBlockDetailsForProduct(dbSchemaPrefix, productId);
		 } catch (MyBatisConfigException | PersistenceException | DAODatabaseException exception) {
			 logHelper.error(logMethod,
						AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_RETRIEVE_BUILDING_BLOCK_DETAILS
						+ "Exception while retrieving building block details of the product", exception);
			 throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnectionNew(connection);
		}
		return buildingBlockClusterTypeViewList;
	}

	@Override
	public boolean isBuildingBlockReferencePresent(int buildingBlockId, String buildingBlockReferenceContractId) throws AgreementCustomerReferenceDAOException {
		boolean flag = false;
		String logMethod = "isBuildingBlockReferencePresent(buildingBlockId,buildingBlockReferenceContractId):";
		Connection connection = null;
		try {
			 connection = connectionProvider.getConnection();
			 SqlSession sqlSession= connetionFactory.getSession(connection);
			 int count = sqlSession.getMapper(BuildingBlockMybatisMapper.class).getCountOfBuildingBlockReference(dbSchemaPrefix, buildingBlockId, buildingBlockReferenceContractId);
			 if(count>0){
				 flag = true;
			 }
			 
		 } catch (MyBatisConfigException | PersistenceException | DAODatabaseException exception) {
			 logHelper.error(logMethod,
						AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_RETRIEVE_COUNT_OF_BUILDING_BLOCK_REF
						+ "Exception while retrieving count of building block ref", exception);
			 throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnectionNew(connection);
		}
		
		return flag;
	}

	@Override
	public void deleteBuildingBlockReferences(Connection connection,String agreementCustomerReferenceId)
			throws AgreementCustomerReferenceDAOException {
		String logMethod = "deleteBuildingBlockReferences(parentAgreementCustomerReferenceId)";
		try {
			 SqlSession sqlSession= connetionFactory.getSession(connection);
			 sqlSession.getMapper(BuildingBlockMybatisMapper.class).deleteBuildingBlockReferences(dbSchemaPrefix,agreementCustomerReferenceId);
		} catch(MyBatisConfigException | PersistenceException exception){
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_DELETING_BUILDING_BLOCK_REF
					+ "Exception while deleting building block ref", exception);
		 throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);

		}
		
		
	}

	@Override
	public String getAgreementCustomerReferenceForBuildingBlockReference(Integer agreementAdministrationId,
			String agreementAdministrationReferenceId) throws AgreementCustomerReferenceDAOException {
		String logMethod = "getAgreementCustomerReferenceForBuildingBlockReference(buildingBlockId,buildingBlockReferenceContractId):";
		Connection connection = null;
		String agreementCustomerReferenceId = null;
		try {
			 connection = connectionProvider.getConnection();
			 SqlSession sqlSession= connetionFactory.getSession(connection);
			 agreementCustomerReferenceId = sqlSession.getMapper(BuildingBlockMybatisMapper.class).getAgreementCustomerReference(dbSchemaPrefix, agreementAdministrationId, agreementAdministrationReferenceId);
			 
		 } catch (MyBatisConfigException | PersistenceException | DAODatabaseException exception) {
			 logHelper.error(logMethod,
						AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_RETRIEVE_AGREEMENT_CUSTMER_REFERENCE_FOR_BUILDING_BLOCK_REF
						+ "Exception while retrieving agreementCustomerReferenceId for building block ref", exception);
			 throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnectionNew(connection);
		}
		return agreementCustomerReferenceId;
	}
	
	

}
