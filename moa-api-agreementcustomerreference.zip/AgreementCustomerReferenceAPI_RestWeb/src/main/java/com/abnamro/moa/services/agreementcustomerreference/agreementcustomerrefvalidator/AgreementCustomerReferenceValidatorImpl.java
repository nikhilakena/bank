package com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.constants.AgreementCustomerReferenceValidatorConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.model.AgreementCustomerReferenceId;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementLifeCycleStatusTypeEnum;
import com.abnamro.moa.services.agreementcustomerreference.util.IbanUtils;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;


/**
 * This is the validator implementation for the Agreement Customer Reference API
 *
 */
@Component
public class AgreementCustomerReferenceValidatorImpl implements AgreementCustomerReferenceValidator {
	
	private static LogHelper logHelper = new LogHelper(AgreementCustomerReferenceValidatorImpl.class);
	
	@Autowired
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDao;

	@Autowired
	private AgreementCustomerReferenceProductValidationDAO productValidationDao;
	
	@Autowired
	private BuildingBlockDAO buildingBlockDAO;

	public void setProductValidationDao(AgreementCustomerReferenceProductValidationDAO dao) {
		productValidationDao = dao;
	}

	public void setAgreementCustomerReferenceDao(AgreementCustomerReferenceDAO dao) {
		agreementCustomerReferenceDao = dao;
	}

	@Override
	public void validateAgreementCustomerReferenceId(String agreementCustomerReferenceId) throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceId id = new AgreementCustomerReferenceId(agreementCustomerReferenceId);
		if (!id.isValidFormat()) {
			throw new AgreementCustomerReferenceApplicationException("4032", HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	public void validatePackage(AgreementCustomerReference agreementCustomerReference) throws AgreementCustomerReferenceApplicationException{
		final String LOG_METHOD = "validatePackage(AgreementCustomerReference agreementCustomerReference):void";
		try {
			// check the type of product if its packaged product then settlement account should be filled in
			validateProductIdFormat(agreementCustomerReference.getProductId());
			
			String productType = productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()));
			
			if(productType == null){
				throw new AgreementCustomerReferenceApplicationException("4006",HttpStatus.BAD_REQUEST);
			}
			
			if(AgreementCustomerReferenceValidatorConstants.PACKAGE_PRODUCT_TYPE.equalsIgnoreCase(productType)){
				validatePackageContent(agreementCustomerReference);
			}else{
				// Check if at least one agreement administration ref present for non packaged product
				validateAgreementAdministrationReferences(agreementCustomerReference.getAgreementAdministrationReferences());
				
				// CommercialAgreementId mandatory for non packaged product
				if(agreementCustomerReference.getCommercialAgreementId()== null){
					throw new AgreementCustomerReferenceApplicationException("4023",HttpStatus.BAD_REQUEST);
				}
				if(org.apache.commons.lang3.StringUtils.isBlank(agreementCustomerReference.getCommercialAgreementId())) {
					throw new AgreementCustomerReferenceApplicationException("4017",HttpStatus.BAD_REQUEST);
				}
				
				if(org.apache.commons.lang3.StringUtils.isNotBlank(agreementCustomerReference.getPackageSettlementAccountNumber())){
					throw new AgreementCustomerReferenceApplicationException("4021",HttpStatus.BAD_REQUEST);
				}
			}
			
			// check the parent agreement customer reference exists in database if given
			if (StringUtils.isNotBlank(agreementCustomerReference.getParentAgreementCustomerReferenceId()) && !existsAgreementCustomerReference(agreementCustomerReference.getParentAgreementCustomerReferenceId())) {
					throw new AgreementCustomerReferenceApplicationException("4007",HttpStatus.BAD_REQUEST);
			}
			
		} catch (AgreementCustomerReferenceDAOException exception) {
			logHelper.error(LOG_METHOD, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_WHILE_VALIDATING_PRODUCT_ID, exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(),exception.getStatus());
		}
	}

	void validateAgreementAdministrationReferences(
			List<AgreementAdministrationReference> agreementAdministrationReferences) throws AgreementCustomerReferenceApplicationException {
		if(agreementAdministrationReferences == null || agreementAdministrationReferences.isEmpty()){
			throw new AgreementCustomerReferenceApplicationException("4008",HttpStatus.BAD_REQUEST);
		}
		for(int i = 0; i<agreementAdministrationReferences.size(); i++) {
			AgreementAdministrationReference agreementAdministrationReference = agreementAdministrationReferences.get(i);
			List<String> paramList = new ArrayList<>();
			paramList.add(String.valueOf(i+1));
			if(agreementAdministrationReference.getAgreementAdministrationId() == null) {
				throw new AgreementCustomerReferenceApplicationException("4010",HttpStatus.BAD_REQUEST,paramList);
			}
			if(!isValidInteger(agreementAdministrationReference.getAgreementAdministrationId()) || agreementAdministrationReference.getAgreementAdministrationId().length()>5) {
				throw new AgreementCustomerReferenceApplicationException("4009",HttpStatus.BAD_REQUEST,paramList);
			}
			if(agreementAdministrationReference.getAgreementAdministrationReferenceId() == null) {
				throw new AgreementCustomerReferenceApplicationException("4011",HttpStatus.BAD_REQUEST,paramList);
			}
			if(StringUtils.isBlank(agreementAdministrationReference.getAgreementAdministrationReferenceId()) || agreementAdministrationReference.getAgreementAdministrationReferenceId().length()>16) {
				throw new AgreementCustomerReferenceApplicationException("4020",HttpStatus.BAD_REQUEST,paramList);
			}
		}
	}

	/**
	 * Validate the contents of the package.
	 * A payment package MUST have a package settlement account number.
	 * A non-payment package MUST have one agreement administration at least and MUST NOT have a package settlement account number.
	 * @param agreementCustomerReference - the agreement customer reference that contains the package details
	 */
	private void validatePackageContent(AgreementCustomerReference agreementCustomerReference)
		throws AgreementCustomerReferenceApplicationException {
		boolean emptySettlementAccountNumber = org.apache.commons.lang3.StringUtils.isBlank(agreementCustomerReference.getPackageSettlementAccountNumber());

		int productId = Integer.parseInt(agreementCustomerReference.getProductId());
		if (isPaymentPackage(productId)) {

			// payment package must have a settlement account number
			if (emptySettlementAccountNumber) {
				throw new AgreementCustomerReferenceApplicationException("4027", HttpStatus.BAD_REQUEST);
			} else {
				validateSettlementAccount(agreementCustomerReference.getPackageSettlementAccountNumber());
			}
		} else {

			// a non payment package must have an agreement administration
			validateAgreementAdministrationReferences(agreementCustomerReference.getAgreementAdministrationReferences());

			// a non-payment package must not have a package settlement account number
			if (!emptySettlementAccountNumber) {
				throw new AgreementCustomerReferenceApplicationException("4034", HttpStatus.BAD_REQUEST);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isPaymentPackage(int productId) {
		boolean isPaymentPackage = false;

		String logMethod = "isPaymentPackage";
		try {
			List<Integer> productGroupIds = productValidationDao.retrieveProductGroupIdsForProduct(productId);

			// check for the product group ids that indicate a payment package
			isPaymentPackage = productGroupIds.contains(Integer.valueOf(77)) || productGroupIds.contains(Integer.valueOf(86));
		} catch (AgreementCustomerReferenceDAOException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_RETRIEVING_PRODUCT_GROUP_IDS, exception);
		}

		return isPaymentPackage;
	}

	void validateProductIdFormat(String productId) throws AgreementCustomerReferenceApplicationException {
		if(!StringUtils.isNumeric(productId) || productId.length()>6 || !isValidInteger(productId)) {
			throw new AgreementCustomerReferenceApplicationException("4005",HttpStatus.BAD_REQUEST);
		}
	}
	
	boolean isValidInteger(String string) {
		final String LOG_METHOD = "isValidInteger";
		try {
			Integer.parseInt(string);
		} catch (NumberFormatException e) {
			logHelper.info(LOG_METHOD, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_NON_INTEGER_INPUT, e);
			return false;
		}
		return true;
	}

	void validateSettlementAccount(String settlementAccountId) throws AgreementCustomerReferenceApplicationException {
		final String LOG_METHOD = "validateSettlementAccount(settlementAccountId)";
		try {
			String bban = convertToBBAN(settlementAccountId);
			if(!buildingBlockDAO.isBuildingBlockReferencePresent(5, bban)){
				throw new AgreementCustomerReferenceApplicationException("4026",HttpStatus.BAD_REQUEST);
			}
		} catch (AgreementCustomerReferenceDAOException exception) {
			logHelper.error(LOG_METHOD, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_WHILE_VALIDATING_PRODUCT_ID, exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(),exception.getStatus());
		}
	}

	/**
	 * Return true if the
	 * @param retrievePartyDetailsResponseTO customer details
	 * @throws AgreementCustomerReferenceApplicationException Exception thrown if validation fails
	 */
	@Override
	public void isCustomerExists(RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO) throws AgreementCustomerReferenceApplicationException {
		boolean isValid = false;

		if(retrievePartyDetailsResponseTO!= null
			&& retrievePartyDetailsResponseTO.getPartyDetails()!=null
			&& retrievePartyDetailsResponseTO.getPartyDetails().getParty()!=null
			&& retrievePartyDetailsResponseTO.getPartyDetails().getParty().getPartyLifeCycleStatusTypeId()!=null){

			if("Business contact life cycle status type".equals(retrievePartyDetailsResponseTO.getPartyDetails().getParty().getPartyLifeCycleStatusTypeId().getScheme())
				&& "1".equals(retrievePartyDetailsResponseTO.getPartyDetails().getParty().getPartyLifeCycleStatusTypeId().getValue())){
				isValid = true;
			}
		}

		if(!isValid){
			throw new AgreementCustomerReferenceApplicationException("4024",HttpStatus.BAD_REQUEST);
		}
	}
	
	boolean existsAgreementCustomerReference(String agreementCustomerReferenceId) throws AgreementCustomerReferenceApplicationException {
		boolean exists = false;
		final String LOG_METHOD = "existsAgreementCustomerReference(String agreementCustomerReferenceId):boolean";
		try {
			exists = agreementCustomerReferenceDao.existsAgreementCustomerReference(agreementCustomerReferenceId);
		} catch(AgreementCustomerReferenceDAOException exception) {
			logHelper.error(LOG_METHOD, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_SELECT_NUMBER_CONTRACT_HEADER,exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(),exception.getStatus());
		}

		return exists;
	}

	@Override
	public void validateBuildingBlockDetails(List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList,
			List<AgreementAdministrationReference> agreementAdministrationReferenceList) throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException {
		
		validateIfBBIsLinkedToProduct(buildingBlockClusterTypeViewList,agreementAdministrationReferenceList);
		
		if(agreementAdministrationReferenceList!=null && !agreementAdministrationReferenceList.isEmpty()){
			for (AgreementAdministrationReference agreementAdministrationReference : agreementAdministrationReferenceList) {
				if(buildingBlockDAO.isBuildingBlockReferencePresent(Integer.valueOf(agreementAdministrationReference.getAgreementAdministrationId()), agreementAdministrationReference.getAgreementAdministrationReferenceId())){
					throw new AgreementCustomerReferenceApplicationException("4015", HttpStatus.BAD_REQUEST);
				}
			}
		}
	}
	
	@Override
	public void validateBuildingBlockDetailsForUpdate(List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList,
			List<AgreementAdministrationReference> agreementAdministrationReferenceList,String agreementCustomerReferenceID) throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException {
		
		validateIfBBIsLinkedToProduct(buildingBlockClusterTypeViewList,agreementAdministrationReferenceList);
		
		if(agreementAdministrationReferenceList!=null && !agreementAdministrationReferenceList.isEmpty()){
			for (AgreementAdministrationReference agreementAdministrationReference : agreementAdministrationReferenceList) {
				String currentAgreementCustomerReferenceID = buildingBlockDAO.getAgreementCustomerReferenceForBuildingBlockReference(Integer.valueOf(agreementAdministrationReference.getAgreementAdministrationId()), agreementAdministrationReference.getAgreementAdministrationReferenceId());
				if(currentAgreementCustomerReferenceID!=null && !agreementCustomerReferenceID.equals(currentAgreementCustomerReferenceID)){
					throw new AgreementCustomerReferenceApplicationException("4015", HttpStatus.BAD_REQUEST);
				}
			}
		}
	}
	
	void validateIfBBIsLinkedToProduct(List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList,
			List<AgreementAdministrationReference> agreementAdministrationReferenceList) throws AgreementCustomerReferenceApplicationException {
		if(agreementAdministrationReferenceList!=null && !agreementAdministrationReferenceList.isEmpty()){
			for (int i = 0; i<agreementAdministrationReferenceList.size(); i++) {
				boolean isBBLinkedToProduct = false;
				for (BuildingBlockClusterTypeView buildingBlockClusterTypeView : buildingBlockClusterTypeViewList) {
					isBBLinkedToProduct = (Integer.valueOf(agreementAdministrationReferenceList.get(i).getAgreementAdministrationId()) == buildingBlockClusterTypeView.getBuildingBlockId()) || isBBLinkedToProduct;
				}
				if (!isBBLinkedToProduct) {
					List<String> params=new ArrayList<>();
					params.add(String.valueOf(i+1));
					throw new AgreementCustomerReferenceApplicationException("4025", HttpStatus.BAD_REQUEST,params);
				}
			}
		}
	}

	String convertToBBAN(String agreementId) throws AgreementCustomerReferenceApplicationException {
		// Check if length of agreementId is 18 & if it starts with "NL"
		// then pick last 10 digit from it as BBAN
		if(StringUtils.isNotBlank(agreementId) && agreementId.length() == AgreementCustomerReferenceValidatorConstants.COMMERCIALAGREEMENTID_IBAN_LENGTH
				&& agreementId.startsWith(AgreementCustomerReferenceValidatorConstants.COMMERCIALAGREEMENTID_IBAN_PREFIX)){
		
			// Convert that BBAN to IBAN by using below standard algorithm
			String bban = IbanUtils.convertToIBAN(agreementId.substring(agreementId.length() - 10));
			
			// compare the result of above method with the input agreementId
			if(StringUtils.isNotBlank(bban) && bban.equalsIgnoreCase(agreementId)){
				return agreementId.substring(agreementId.length() - 10);
			} else {
				throw new AgreementCustomerReferenceApplicationException("4013", HttpStatus.BAD_REQUEST);
			}
		} else {
			throw new AgreementCustomerReferenceApplicationException("4013", HttpStatus.BAD_REQUEST);
		}
	}
	
	@Override
	public void validatePartialUpdateRequest(String agreementCustomerReferenceId,
			AgreementCustomerReferenceForPatch updateRequestInput)
			throws AgreementCustomerReferenceApplicationException {
		
		//validate
		validateAgreementCustomerReferenceId(agreementCustomerReferenceId);
		
		//validate AgreementLifeCycleStatus if its is in allowed enum values
		validateAgreementLifeCycleStatus(updateRequestInput.getAgreementLifeCycleStatus());
		
		//validate product details if product Id is filled
		if(updateRequestInput.getProductId()!=null){
			validateProductIdFormat(updateRequestInput.getProductId());
			validateProductIdForUpdate(updateRequestInput);
		}
		
		if(updateRequestInput.getCustomerId()!=null) {
			validateCustomerId(updateRequestInput.getCustomerId());
		}
		
		//validate if ParentAgreementCustomerReferenceId is exist in database
		if (StringUtils.isNotBlank(updateRequestInput.getParentAgreementCustomerReferenceId()) && !existsAgreementCustomerReference(updateRequestInput.getParentAgreementCustomerReferenceId())) {
			throw new AgreementCustomerReferenceApplicationException("4007",HttpStatus.BAD_REQUEST);
		}
		
		//CommercialAgreementId can not be empty
		if(updateRequestInput.getCommercialAgreementId()!= null && StringUtils.isBlank(updateRequestInput.getCommercialAgreementId())){
			throw new AgreementCustomerReferenceApplicationException("4017",HttpStatus.BAD_REQUEST);
		}
		
		// validate organizationUnitId if it is filled
		if(updateRequestInput.getOrganisationUnitId() != null) {
			validateOrgUnitId(updateRequestInput.getOrganisationUnitId());
		}
		
	}

	void validateProductIdForUpdate(AgreementCustomerReferenceForPatch updateRequestInput) throws AgreementCustomerReferenceApplicationException {
		final String LOG_METHOD = "validateProductIdForUpdate";
		try {
			
			String newProductType = productValidationDao.getProductType(Integer.parseInt(updateRequestInput.getProductId()));
			
			if (newProductType == null) {
				throw new AgreementCustomerReferenceApplicationException("4006", HttpStatus.BAD_REQUEST);
			}
			
			//For non package product AgreementAdministrationReferences are mandatory
			validateAgreementAdministrationReferences(updateRequestInput.getAgreementAdministrationReferences());
			
		} catch (AgreementCustomerReferenceDAOException exception) {
			logHelper.error(LOG_METHOD,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_WHILE_VALIDATING_PRODUCT_ID, exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(), exception.getStatus());
		}
	}

	private void validateAgreementLifeCycleStatus(String agreementLifeCycleStatusType) throws AgreementCustomerReferenceApplicationException {
		if(agreementLifeCycleStatusType!= null && AgreementLifeCycleStatusTypeEnum.fromValue(agreementLifeCycleStatusType)==null){
			throw new AgreementCustomerReferenceApplicationException("4014",HttpStatus.BAD_REQUEST);
		}
		
	}

	void validateCommercialAgreementId(String commercialAgreementId) throws AgreementCustomerReferenceApplicationException {
		if(StringUtils.isBlank(commercialAgreementId) || commercialAgreementId.length()>16) {
			throw new AgreementCustomerReferenceApplicationException("4017",HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	public void validateOrgUnitId(String orgUnitId) throws AgreementCustomerReferenceApplicationException {
		
		if(!StringUtils.isNumeric(orgUnitId) || orgUnitId.length()>6 
				|| !isValidInteger(orgUnitId) /*|| !orgUnitIdValidator.checkIfValidOrgUnitIdInInput(orgUnitId)*/) {
			throw new AgreementCustomerReferenceApplicationException("4012",HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	public void validateSearchRequest(String productId, String commercialAgreementId, String agreementAdministrationId,
		String agreementAdministrationReferenceId) throws AgreementCustomerReferenceApplicationException {
		
		//validate if the productId in path parameter is numeric or not
		validateProductIdFormatQueryParam(productId);
			
		//validate if length of CommercialAgreementId
		if(commercialAgreementId!= null){
			validateCommercialAgreementId(commercialAgreementId);
		}
		
		//validate if the buildingBlockId in path parameter is numeric or not
		validateStringBuildingBlockId(agreementAdministrationId);
		
		//validate if length of buildingBlock reference
		validateBuildingBlockRefId(agreementAdministrationReferenceId);
		
		//validate atleast one selection criteria should be provided
		validateAtleastOneSelectionCriteria(productId, commercialAgreementId, agreementAdministrationId, agreementAdministrationReferenceId);
		
		//validate only one selection criteria should be provided
		validateOnlyOneSelectionCriteria(productId, commercialAgreementId, agreementAdministrationId, agreementAdministrationReferenceId);
		
	}

	void validateOnlyOneSelectionCriteria(String productId, String commercialAgreementId,
			String agreementAdministrationId, String agreementAdministrationReferenceId) throws AgreementCustomerReferenceApplicationException {
		if((StringUtils.isNotBlank(productId) || StringUtils.isNotBlank(commercialAgreementId))
				&& (StringUtils.isNotBlank(agreementAdministrationId) || StringUtils.isNotBlank(agreementAdministrationReferenceId))){
			throw new AgreementCustomerReferenceApplicationException("4031",HttpStatus.BAD_REQUEST);
		}
		
	}

	void validateAtleastOneSelectionCriteria(String productId, String commercialAgreementId,
			String agreementAdministrationId, String agreementAdministrationReferenceId) throws AgreementCustomerReferenceApplicationException {
		if(StringUtils.isBlank(productId) && StringUtils.isBlank(commercialAgreementId)
				&& StringUtils.isBlank(agreementAdministrationId) && StringUtils.isBlank(agreementAdministrationReferenceId)){
			throw new AgreementCustomerReferenceApplicationException("4031",HttpStatus.BAD_REQUEST);
		}
		
	}

	void validateProductIdFormatQueryParam(String productId) throws AgreementCustomerReferenceApplicationException {
		if(productId!=null){
			if(StringUtils.isEmpty(productId) || productId.length()>6 || !StringUtils.isNumeric(productId)){
				throw new AgreementCustomerReferenceApplicationException("4005",HttpStatus.BAD_REQUEST);
			}
		}
	}

	void validateBuildingBlockRefId(String agreementAdministrationReferenceId) throws AgreementCustomerReferenceApplicationException {
		if(agreementAdministrationReferenceId!= null){
			if(StringUtils.isBlank(agreementAdministrationReferenceId) || agreementAdministrationReferenceId.length()>16) {
				throw new AgreementCustomerReferenceApplicationException("4020",HttpStatus.BAD_REQUEST);
			}
		}
	}

	void validateStringBuildingBlockId(String agreementAdministrationId) throws AgreementCustomerReferenceApplicationException {
		if(agreementAdministrationId!=null){
			if(StringUtils.isEmpty(agreementAdministrationId) || agreementAdministrationId.length()>6 || !StringUtils.isNumeric(agreementAdministrationId)){
				throw new AgreementCustomerReferenceApplicationException("4009",HttpStatus.BAD_REQUEST);
			}
		}
		
	}

	@Override
	public void validateProductTypeChange(String newProductId, String oldPproductId) throws AgreementCustomerReferenceApplicationException {
		final String LOG_METHOD = "validateProductTypeChange";
		try {
			
			String newProductType = productValidationDao.getProductType(Integer.parseInt(newProductId));
			
			String oldProductType = productValidationDao.getProductType(Integer.parseInt(oldPproductId));
			
			if (newProductType == null) {
				throw new AgreementCustomerReferenceApplicationException("4006", HttpStatus.BAD_REQUEST);
			}
			
			if(!newProductType.equals(oldProductType)){
				throw new AgreementCustomerReferenceApplicationException("4029",HttpStatus.BAD_REQUEST);
			}
			
		} catch (AgreementCustomerReferenceDAOException exception) {
			logHelper.error(LOG_METHOD,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_WHILE_VALIDATING_PRODUCT_ID, exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(), exception.getStatus());
		}
		
	}

	@Override
	public void validateCustomerId(String customerId) throws AgreementCustomerReferenceApplicationException {
		if(!StringUtils.isNumeric(customerId) || customerId.length()>12 || !isValidLong(customerId)) {
			throw new AgreementCustomerReferenceApplicationException("4002",HttpStatus.BAD_REQUEST);
		}
	}
	
	private boolean isValidLong(String string) {
		final String LOG_METHOD = "isValidlong";
		try {
			Long.parseLong(string);
		} catch (NumberFormatException e) {
			logHelper.info(LOG_METHOD, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_NON_LONG_INPUT, e);
			return false;
		}
		return true;
	}
	
	/**
	 * Validates if product is payment package or not as settlement account number can only be updated for payment packages
	 * @param productId - product id of agreement customer reference for which settlement account number is going to be updated
	 * @throws AgreementCustomerReferenceApplicationException Exception at application layer
	 */
	public void validateProductForSettlementAccountUpdate(String productId) throws AgreementCustomerReferenceApplicationException{ 

		if (!isPaymentPackage(Integer.parseInt(productId))) {
			throw new AgreementCustomerReferenceApplicationException("4038", HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * Validates if status is active or not before updating settlement account number
	 * @param agreementLifeCycleStatusType - agreementLifeCycleStatusType of agreement customer reference for which settlement account number is going to be updated
	 * @throws AgreementCustomerReferenceApplicationException Exception at application layer
	 */
	public void validateStatusBeforeSettlementAccountUpdate(String agreementLifeCycleStatusType) throws AgreementCustomerReferenceApplicationException {
		if(StringUtils.isNotBlank(agreementLifeCycleStatusType) && AgreementLifeCycleStatusTypeEnum.ENDED.getDbValue().equalsIgnoreCase(agreementLifeCycleStatusType)){
			throw new AgreementCustomerReferenceApplicationException("4036",HttpStatus.BAD_REQUEST);
		}
	}
	
	public void validateSettlementAccountForUpdate(String settlementAccountId) throws AgreementCustomerReferenceApplicationException {
		final String LOG_METHOD = "validateSettlementAccountForUpdate(settlementAccountId)";
		try {
			String bban = convertSettlementAccountToBBAN(settlementAccountId);
			if(!buildingBlockDAO.isBuildingBlockReferencePresent(5, bban)){
				throw new AgreementCustomerReferenceApplicationException("4037",HttpStatus.BAD_REQUEST);
			}
		} catch (AgreementCustomerReferenceDAOException exception) {
			logHelper.error(LOG_METHOD, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_VALIDATING_SETTLEMENT_ACCOUNT, exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(),exception.getStatus());
		}
	}
	
	private String convertSettlementAccountToBBAN(String settlementAccountNumber) throws AgreementCustomerReferenceApplicationException {
		// Check if length of agreementId is 18 & if it starts with "NL"
		// then pick last 10 digit from it as BBAN
		if(StringUtils.isNotBlank(settlementAccountNumber) && settlementAccountNumber.length() == AgreementCustomerReferenceValidatorConstants.COMMERCIALAGREEMENTID_IBAN_LENGTH
				&& settlementAccountNumber.startsWith(AgreementCustomerReferenceValidatorConstants.COMMERCIALAGREEMENTID_IBAN_PREFIX)){
		
			// Convert that BBAN to IBAN by using below standard algorithm
			String bban = IbanUtils.convertToIBAN(settlementAccountNumber.substring(settlementAccountNumber.length() - 10));
			
			// compare the result of above method with the input agreementId
			if(StringUtils.isNotBlank(bban) && bban.equalsIgnoreCase(settlementAccountNumber)){
				return settlementAccountNumber.substring(settlementAccountNumber.length() - 10);
			} else {
				throw new AgreementCustomerReferenceApplicationException("4035", HttpStatus.BAD_REQUEST);
			}
		} else {
			throw new AgreementCustomerReferenceApplicationException("4035", HttpStatus.BAD_REQUEST);
		}
	}
	

}
