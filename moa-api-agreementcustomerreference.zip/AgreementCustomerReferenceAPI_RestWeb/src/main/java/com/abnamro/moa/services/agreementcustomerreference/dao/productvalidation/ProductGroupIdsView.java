package com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation;

import com.abnamro.nl.dto.util.AbstractDTO;

import java.util.List;

/** This class contains details about the Product
 * @author C36098
 *
 */
public class ProductGroupIdsView extends AbstractDTO {
	private static final long serialVersionUID = 1L;

	private Integer productGroupId;

	public Integer getProductGroupId() {
		return productGroupId;
	}

	public void setProductGroupId(Integer id) {
		productGroupId = id;
	}
}
