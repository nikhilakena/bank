package com.abnamro.moa.services.agreementcustomerreference.dao.settlement;

import java.sql.Timestamp;

/**
 * The details of the settlement account that is to be persisted.
 */
public class SettlementAccountView {
	private String id;
	private Timestamp dateCreated;
	private Timestamp dateModified;
	private String userId;
	private String contractHeaderId;

	public String getId() {
		return id;
	}

	public void setId(String settlementAccountId) {
		id = settlementAccountId;
	}

	public Timestamp getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Timestamp date) {
		dateCreated = date;
	}

	public Timestamp getDateModified() {
		return dateModified;
	}

	public void setDateModified(Timestamp date) {
		dateModified = date;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getContractHeaderId() {
		return contractHeaderId;
	}

	public void setContractHeaderId(String contractHeaderId) {
		this.contractHeaderId = contractHeaderId;
	}
}