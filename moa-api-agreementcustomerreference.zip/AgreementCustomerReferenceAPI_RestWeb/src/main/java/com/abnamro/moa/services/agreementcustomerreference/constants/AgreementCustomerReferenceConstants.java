package com.abnamro.moa.services.agreementcustomerreference.constants;

/**
 * 
 * This is the constant class for the Agreement Customer Reference API
 */
public final class AgreementCustomerReferenceConstants {
	private AgreementCustomerReferenceConstants() {}

	/**
	 * The type of the responsible party.
	 */
	public static final String AGREEMENT_ADMINISTRATION_TYPE = "01";

	/**
	 * The type of the bank of the responsible party.
	 */
	public static final int AGREEMENT_ADMINISTRATION_BANK_OBJECT_TYPE = 1;
	
	public static final int COMMERCIALAGREEMENTID_IBAN_LENGTH = 18;
	
	public static final String COMMERCIALAGREEMENTID_IBAN_PREFIX = "NL";
	
	public static final String CODE_LABEL = "_code";
	
	public static final String MESSAGE_LABEL = "_message";

	public static final String SPACE = " ";

	public static final int INT_ZERO = 0;

	public static final String PUBLISH_TYPE_CREATE = "C";
	
	public static final String PUBLISH_TYPE_UPDATE = "U";

	public static final String PUBLISH_TYPE_DELETE = "D";

	public static final String SERVICE_NAME = "retrieveorgunitconnect";
	
	public static final String CONNECT_URL = "url";
	
	public static final String INTERNAL_SERVER_ERRROR = "500";
	
	public static final int INTERNAL_SERVER_ERRROR_HTTP_STATUS = 500;
	
	public static final String REF_SCHEME_BO_NUMBER = "BO number";
	
	public static final String REF_SCHEME_BO_NUMBER_STATUS = "Bo Status Code";
	
	public static final String RETRIEVE_ORGUNIT_DETAILS_CONSUMERID = "MOA";
	
	public static final String BO_NUMBER_ACTIVE_STATUS = "2";
	
	public static final String BO_NUMBER_NOT_FOUND_RESULTCODE = "1003";
}
