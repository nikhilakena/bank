package com.abnamro.moa.services.agreementcustomerreference.resourcemodel;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Agreement Customer Reference details that needs to be updated.
 */
public class AgreementCustomerReferenceForPatch {

	  @JsonProperty("agreementLifeCycleStatus")
	  private String agreementLifeCycleStatus = null;

	  @JsonProperty("agreementAdministrationReferences")
	  @Valid
	  private List<AgreementAdministrationReference> agreementAdministrationReferences = null;

	  @JsonProperty("commercialAgreementId")
	  private String commercialAgreementId = null;

	  @JsonProperty("customerId")
	  private String customerId = null;

	  @JsonProperty("agreementNickName")
	  private String agreementNickName = null;

	  @JsonProperty("parentAgreementCustomerReferenceId")
	  private String parentAgreementCustomerReferenceId = null;

	  @JsonProperty("productId")
	  private String productId = null;

	  @JsonProperty("organisationUnitId")
	  private String organisationUnitId = null;
	
	 /**
	   * Contains status of the agreement within the lifecycle.
	   * @return agreementLifeCycleStatusType
	  **/
	  @ApiModelProperty(example = "ACTIVE", value = "Contains status of the agreement within the lifecycle.")
	  public String getAgreementLifeCycleStatus() {
	    return agreementLifeCycleStatus;
	  }

	  public void setAgreementLifeCycleStatus(String agreementLifeCycleStatus) {
	    this.agreementLifeCycleStatus = agreementLifeCycleStatus;
	  }

	  /**
	   * The agreementAdministrationReference. Mandatory when the product is not a package.
	   * @return agreementAdministrationReferences
	  **/
	  @ApiModelProperty(value = "The agreementAdministrationReference. Mandatory when the product is not a package.")

	  @Valid
	  @Size(min=0,max=10)
	  public List<AgreementAdministrationReference> getAgreementAdministrationReferences() {
	    return agreementAdministrationReferences;
	  }

	  public void setAgreementAdministrationReferences(List<AgreementAdministrationReference> agreementAdministrationReferences) {
	    this.agreementAdministrationReferences = agreementAdministrationReferences;
	  }

	  /**
	   * Unique value by what the agreement can be retrieved and identified and used in communication and maintenance
	   * @return commercialAgreementId
	  **/
	  @ApiModelProperty(example = "0558967531", value = "Unique value by what the agreement can be retrieved and identified and used in communication and maintenance")

	  @Valid
	  @Size(min = 0, max = 16, message = "4017")
	  public String getCommercialAgreementId() {
	    return commercialAgreementId;
	  }

	  public void setCommercialAgreementId(String commercialAgreementId) {
	    this.commercialAgreementId = commercialAgreementId;
	  }

	  /**
	   * Identification of the individual or business that holds the Agreement Customer Reference.
	   * @return customerId
	  **/
	  @ApiModelProperty(example = "76890341", required = true, value = "Identification of the individual or business that holds the Agreement Customer Reference.")
	  @Valid
	  //@Digits(integer = 12, fraction = 0, message = "4003")
	  public String getCustomerId() {
	    return customerId;
	  }

	  public void setCustomerId(String customerId) {
	    this.customerId = customerId;
	  }

	  /**
	   * The name of the Agreement given by the customer.
	   * @return agreementNickName
	  **/
	  @ApiModelProperty(example = "PENSIOEN AANVULLING INBRENG", value = "The name of the Agreement given by the customer.")


	  @Valid
	  @Size(min = 0, max = 48, message = "4016")
	  public String getAgreementNickName() {
	    return agreementNickName;
	  }

	  public void setAgreementNickName(String agreementNickName) {
	    this.agreementNickName = agreementNickName;
	  }

	  /**
	   * The agreementCustomerReferenceId of the package or arrangement the Agreement customer is part of. parentAgreementCustomerReferenceId is optional when the agreementCustomerReferenceId is part of a package or arrangement.
	   * @return parentAgreementCustomerReferenceId
	  **/
	  @ApiModelProperty(example = "HHI030210", value = "The agreementCustomerReferenceId of the package or arrangement the Agreement customer is part of. parentAgreementCustomerReferenceId is optional when the agreementCustomerReferenceId is part of a package or arrangement.")

	  @Valid
	  @Pattern(regexp = "^([A-Z]{3}\\d{6}|$)$", message = "4019")
	  public String getParentAgreementCustomerReferenceId() {
	    return parentAgreementCustomerReferenceId;
	  }

	  public void setParentAgreementCustomerReferenceId(String parentAgreementCustomerReferenceId) {
	    this.parentAgreementCustomerReferenceId = parentAgreementCustomerReferenceId;
	  }

	  /**
	   * Identificataion of the product for which this agreement has been created
	   * @return productId
	  **/
	  @ApiModelProperty(example = "1234", required = true, value = "Identificataion of the product for which this agreement has been created")
	  @Valid
	  //@Digits(integer = 6, fraction = 0, message = "4006")
	  public String getProductId() {
	    return productId;
	  }

	  public void setProductId(String productId) {
	    this.productId = productId;
	  }

	  /**
	   * The identification of the responsible party of a customer who has initiated the postAgreementCustomerReference operation and thus wants to create an Agreement Customer Reference. 
	   * @return organisationUnitId
	  **/
	  @ApiModelProperty(example = "690839", value = "The identification of the responsible party of a customer who has initiated the postAgreementCustomerReference operation and thus wants to create an Agreement Customer Reference. ")

	  @Valid
	  //@Digits(integer = 6, fraction = 0, message = "4012")
	  public String getOrganisationUnitId() {
	    return organisationUnitId;
	  }

	  public void setOrganisationUnitId(String organisationUnitId) {
	    this.organisationUnitId = organisationUnitId;
	  }


}
