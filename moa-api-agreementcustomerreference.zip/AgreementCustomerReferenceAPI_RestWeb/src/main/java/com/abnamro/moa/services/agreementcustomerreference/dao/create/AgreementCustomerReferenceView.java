package com.abnamro.moa.services.agreementcustomerreference.dao.create;

import java.sql.Timestamp;
import java.util.List;

import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;

/**
 * This class contains all the attributes of Contract Header
 */
public class AgreementCustomerReferenceView {
	private String id;
	private String nickName;
	private String status;
	private Timestamp dateCreated;
	private Timestamp dateModified;
	private String userId;
	private String parentId;
	private String commercialContractNumber;
	private String customerId;
	private String productId;
	private String transferService;
	private String blockingCode;
	private List<BuildingBlockView> buildingBlockViewList;

	public String getId() {
		return id;
	}

	public void setId(String agreementCustomerReferenceId) {
		id = agreementCustomerReferenceId;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String name) {
		nickName = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Timestamp date) {
		dateCreated = date;
	}

	public Timestamp getDateModified() {
		return dateModified;
	}

	public void setDateModified(Timestamp date) {
		dateModified = date;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getCommercialContractNumber() {
		return commercialContractNumber;
	}

	public void setCommercialContractNumber(String number) {
		commercialContractNumber = number;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTransferService() {
		return transferService;
	}

	public void setTransferService(String service) {
		transferService = service;
	}

	public String getBlockingCode() {
		return blockingCode;
	}

	public void setBlockingCode(String code) {
		blockingCode = code;
	}

	public List<BuildingBlockView> getBuildingBlockViewList() {
		return buildingBlockViewList;
	}

	public void setBuildingBlockViewList(List<BuildingBlockView> buildingBlockViewList) {
		this.buildingBlockViewList = buildingBlockViewList;
	}
	
	
}