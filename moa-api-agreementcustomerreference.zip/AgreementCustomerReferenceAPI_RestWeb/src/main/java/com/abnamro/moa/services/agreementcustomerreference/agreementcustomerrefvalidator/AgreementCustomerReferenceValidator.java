package com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator;

import java.util.List;

import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;

/**
 * This is the validator interface for the Agreement Customer Reference API
 */
public interface AgreementCustomerReferenceValidator {
	/**
	 * Validate the format of the given agreement customer reference id.
	 * @param agreementCustomerReferenceId - the text to be validated as an agreement customer reference id
	 * @throws AgreementCustomerReferenceApplicationException in case of validation failure
	 */
	void validateAgreementCustomerReferenceId(String agreementCustomerReferenceId) throws AgreementCustomerReferenceApplicationException;

	/**
	 * If the given agreement customer reference is part of a package, validate the package.
	 * 
	 * @param agreementCustomerReference create contract header input
	 * @throws AgreementCustomerReferenceApplicationException in case of validation failure
	 */
	void validatePackage(AgreementCustomerReference agreementCustomerReference) throws AgreementCustomerReferenceApplicationException;


	/**
	 * This method validates the lifecycle status of the BC
	 * 
	 * @param retrievePartyDetailsResponseTO customer details
	 * @throws AgreementCustomerReferenceApplicationException in case of error
	 */
	void isCustomerExists(RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO) throws AgreementCustomerReferenceApplicationException;

	/**
	 * validate Building Block Details by checking if only building blocks linked to product are present in input
	 * Also if input building block reference should not be present in database
	 * 
	 * @param buildingBlockClusterTypeViewList building block details retrieved from database
	 * @param agreementAdministrationReferenceList Agreement Administration Reference
	 * @throws AgreementCustomerReferenceApplicationException in case of error
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	void validateBuildingBlockDetails(List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList,
			List<AgreementAdministrationReference> agreementAdministrationReferenceList) throws AgreementCustomerReferenceApplicationException,AgreementCustomerReferenceDAOException;

	
	
	/**
	 * validates the details for Partial Update of AgreementCustomerReference
	 * 
	 * @param agreementCustomerReferenceId unique identifier for contract header
	 * @param updateRequestInput update request for AgreementCustomerReference
	 * @throws AgreementCustomerReferenceApplicationException in case of error
	 */
	void validatePartialUpdateRequest(String agreementCustomerReferenceId, AgreementCustomerReferenceForPatch updateRequestInput) throws AgreementCustomerReferenceApplicationException;

	/**
	 * validate Building Block Details by checking if only building blocks linked to product are present in input
	 * Also if input building block reference should not be present in database
	 * 
	 * @param buildingBlockClusterTypeViewList building block details retrieved from database
	 * @param agreementCustomerReferenceID unique identifier for agreementCustomerReference
	 * @param agreementAdministrationReferences Agreement Administration Reference
	 * @throws AgreementCustomerReferenceApplicationException in case of error
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	void validateBuildingBlockDetailsForUpdate(List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList,
			List<AgreementAdministrationReference> agreementAdministrationReferences, String agreementCustomerReferenceID) throws AgreementCustomerReferenceApplicationException,AgreementCustomerReferenceDAOException;
	
	/**
	 * validate organization unit id by calling service exposed via ESB and return error in case of invalid BO number or BO status
	 * 
	 * @param orgUnitId Organization Unit ID(BO Number)
	 * @throws AgreementCustomerReferenceApplicationException in case of error
	 */
	void validateOrgUnitId(String orgUnitId) throws AgreementCustomerReferenceApplicationException;


	/**
	 * It validate and format of each field. Also validates that atleast and only one selection criteria should be provided
	 * 
	 * @param productId unique identifier of the product
	 * @param commercialAgreementId unique identifier of the contract
	 * @param agreementAdministrationId building block id
	 * @param agreementAdministrationReferenceId building block reference contract number
	 * @throws AgreementCustomerReferenceApplicationException in case validation fails
	 */
	void validateSearchRequest(String productId, String commercialAgreementId, String agreementAdministrationId,
			String agreementAdministrationReferenceId) throws AgreementCustomerReferenceApplicationException;

	/**
	 * validates change of product type
	 * 
	 * @param newProductId new ProductId
	 * @param oldPproductId old ProductId
	 * @throws AgreementCustomerReferenceApplicationException in case of errors
	 */
	void validateProductTypeChange(String newProductId, String oldPproductId) throws AgreementCustomerReferenceApplicationException;

	/**
	 * It validates customer Id
	 * 
	 * @param customerId BC number
	 * @throws AgreementCustomerReferenceApplicationException in case of error
	 */
	void validateCustomerId(String customerId) throws AgreementCustomerReferenceApplicationException;

	/**
	 * Return true if the given product contains a payment package.
	 * @param productId - the id of the product to check for having a payment package
	 * @return true if the product is a payment package, false otherwise
	 */
	boolean isPaymentPackage(int productId);
	
	/**
	 * Validates if product is payment package or not as settlement account number can only be updated for payment packages
	 * @param productId - product id of agreement customer reference for which settlement account number is going to be updated
	 * @throws AgreementCustomerReferenceApplicationException Exception at application layer
	 */
	void validateProductForSettlementAccountUpdate(String productId) throws AgreementCustomerReferenceApplicationException;
	
	/**
	 * Validates if status is active or not before updating settlement account number
	 * @param agreementLifeCycleStatusType - agreementLifeCycleStatusType of agreement customer reference for which settlement account number is going to be updated
	 * @throws AgreementCustomerReferenceApplicationException Exception at application layer
	 */
	public void validateStatusBeforeSettlementAccountUpdate(String agreementLifeCycleStatusType) throws AgreementCustomerReferenceApplicationException;

	/**
	 * Validates if settlement account is in valid format or not and check if its current account or not
	 * @param settlementAccountId settlement account number to be validated
	 * @throws AgreementCustomerReferenceApplicationException Exception at application layer
	 */
	public void validateSettlementAccountForUpdate(String settlementAccountId) throws AgreementCustomerReferenceApplicationException;
}
