package com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation;

import java.sql.Connection;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import com.abnamro.moa.services.agreementcustomerreference.dao.AgreementCustomerReferenceMybatisMapper;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.nl.channels.jndilookup.JndiConstants;
import com.abnamro.nl.channels.jndilookup.JndiLookup;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.dao.util.mybatis.MyBatisConfigException;
import com.abnamro.nl.dao.util.mybatis.MyBatisConnectionFactory;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;

/**
 * Methods to validate input values by interacting with the persistent storage.
 */
@Configuration
public class AgreementCustomerReferencePackageValidationDAOImpl implements AgreementCustomerReferencePackageValidationDAO {
	private static LogHelper logHelper = new LogHelper(AgreementCustomerReferencePackageValidationDAOImpl.class);
	
	@Autowired
	private ConnectionProvider connectionProvider;

	private final String dbSchemaPrefix;
	private final String dataSourceName;
	private static final String CONFIG_FILE_PATH = "dao/acr-mybatis-config.xml";
	private static MyBatisConnectionFactory connetionFactory;

	/**
	 * Create the DAO implementation, setup connection to database.
	 */
	public AgreementCustomerReferencePackageValidationDAOImpl() {
		dbSchemaPrefix = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.SCHEMA_DATABASE, AgreementCustomerReferenceDAOConstants.DEFAULT_DB_SCHEMA);
		dataSourceName = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.DATASOURCE_NAME, AgreementCustomerReferenceDAOConstants.DEFAULT_DATASOURCE);
		if (connetionFactory == null) {
			setConnetionFactory(getConnectionFactoryInstance());
		}
	}

	@Override
	public boolean isPackageIdValid(Integer packageId) throws AgreementCustomerReferenceDAOException {
		boolean valid = false;

		Connection connection = null;
		String logMethod = "isPackageIdValid";

		try {
			connection = connectionProvider.getConnection();
			SqlSession sqlSession = connetionFactory.getSession(connection);

			Integer count = sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).countNumberOfContractHeaders(dbSchemaPrefix, packageId);
			valid = count > 0;
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_WHILE_VALIDATING_PACKAGE
					+ " mybatis exception while validating product id {0}"
				, exception, packageId);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (DAODatabaseException daoDatabaseException) {
			
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_CONNECTION,
					daoDatabaseException);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnection(connection);
		}

		return valid;
	}

	/**
	 * @return returns an instance of MyBatisConnectionFactory class
	 */
	private static synchronized MyBatisConnectionFactory getConnectionFactoryInstance() {
	    final String logMethod = "getConnectionFactoryInstance():MyBatisConnectionFactory";

		try {
			// Creates new Instance for MyBatis Connection factory & loads the
			// Mybatis Configuration file
			return new MyBatisConnectionFactory(CONFIG_FILE_PATH);
		} catch (MyBatisConfigException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_IBATIS_INITIALIZATION, null, exception);
		}

		return null;
	}

	private static synchronized void setConnetionFactory(MyBatisConnectionFactory myBatisConnectionFactory) {
		connetionFactory = myBatisConnectionFactory;
	}

	/**
	 * It returns data source name to be used by the DAO.
	 * 
	 * @return the data source name to be used by the DAO.
	 */
	protected String getDataSourceName() {
		return dataSourceName;
	}
}
