package com.abnamro.moa.services.agreementcustomerreference.application;

import com.abnamro.moa.services.agreementcustomerreference.configuration.APIConfiguration;
import com.abnamro.moa.services.agreementcustomerreference.controller.AgreementCustomerReferenceController;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletRegistration;

public class APIInitializer implements WebApplicationInitializer {
    private static LogHelper log = new LogHelper(AgreementCustomerReferenceController.class);

    @Override
    public void onStartup(ServletContext servletContext) {
        log.error("", "APIInitializer::onStartup");

        AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
        context.register(APIConfiguration.class);

        DispatcherServlet dispatcher = new DispatcherServlet(context);
        ServletRegistration.Dynamic registration = servletContext.addServlet("AgreementCustomerReferenceAPI", dispatcher);
        registration.setLoadOnStartup(1);
        registration.addMapping("/");
    }
}
