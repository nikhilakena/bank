package com.abnamro.moa.services.agreementcustomerreference.controller;

import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.requestprocessor.*;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.GetAgreementCustomerReferenceResponse;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.ResponseForPostAgreementCustomerReference;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.ws.rs.QueryParam;

/**
 * This is the controller class for the Agreement Customer Reference API. It has operations for create, update, delete of contract header.
 */
@Configuration
@RestController
@RequestMapping("/")
public class AgreementCustomerReferenceController {
	private static LogHelper log = new LogHelper(AgreementCustomerReferenceController.class);

	@Autowired
	private AgreementCustomerReferenceValidator validator;

	@Autowired
	private AgreementCustomerReferenceRequestProcessorUtils requestProcessor;

	@Autowired
	private CreateAgreementCustomerReferenceRequestProcessor createRequestProcessor;
	
	@Autowired
	private UpdateAgreementCustomerReferenceRequestProcessor updateRequestProcessor;
	
	@Autowired
	private SearchAgreementCustomerReferenceRequestProcessor searchRequestProcessor;

	@Autowired
	private DeleteAgreementCustomerReferenceRequestProcessor deleteRequestProcessor;
	
	@Autowired
	private RetrieveAgreementCustomerReferenceRequestProcessor retrieveRequestProcessor;
	    

	/**
	 * This operation is used to create Contract header based on input request.
	 * It performs validations and forwards request to request processor
	 *
	 * @param consumerId consumer Id of the calling application
	 * @param traceId trace Id of the input request
	 * @param createRequestInput Input request for create Agreement Customer Reference
	 * @return response containing Created Contract header
	 * @throws AgreementCustomerReferenceApplicationException in case of error
	 */
	@PostMapping(value = "/v1", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseForPostAgreementCustomerReference> addAgreementCustomerReference(
		@RequestHeader(name="Consumer-Id", required = false) String consumerId,
		@RequestHeader(name="Trace-Id", required = false) String traceId,
		@RequestBody(required = true) @Valid AgreementCustomerReference createRequestInput) throws AgreementCustomerReferenceApplicationException {

		ResponseEntity<ResponseForPostAgreementCustomerReference> response = null;
		String agreementCustomerReferenceId;

		validator.validatePackage(createRequestInput);

		validator.validateCustomerId(createRequestInput.getCustomerId());

		if(createRequestInput.getOrganisationUnitId() != null){
			validator.validateOrgUnitId(createRequestInput.getOrganisationUnitId());
		}

		consumerId = requestProcessor.truncateConsumerId(consumerId);

		agreementCustomerReferenceId = createRequestProcessor.processCreateAgreementCustomerReferenceRequest(createRequestInput, consumerId);

		response = createSuccessFullResponse(agreementCustomerReferenceId);
		return response;
	}

	private ResponseEntity<ResponseForPostAgreementCustomerReference> createSuccessFullResponse(String agreementCustomerReferenceId) {
		ResponseEntity<ResponseForPostAgreementCustomerReference> response = null;

		// add the id of the created agreement customer reference to the response
		ResponseForPostAgreementCustomerReference body = new ResponseForPostAgreementCustomerReference();
		body.setAgreementCustomerReferenceId(agreementCustomerReferenceId);

		// create the response
		response = new ResponseEntity<>(body, HttpStatus.CREATED);

		return response;
	}

	/**
	 * This operation is used to update Contract header for input product Id and commercial agreement Id.
	 * It performs validations and forwards request to request processor
	 * 
	 * @param consumerId consumer Id of the calling application
	 * @param traceId trace Id of the input request
	 * @param agreementCustomerReferenceId unique identifier of the contract header
	 * @param updateRequestInput AgreementCustomerReference details for partial update
	 * @return response containing Created Contract header
	 * @throws AgreementCustomerReferenceApplicationException in case of error
	 */
	@PostMapping(value = "/v1/{agreementCustomerReferenceId}/patch", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> partialUpdateAgreementCustomerReference(
			@RequestHeader(name="Consumer-Id", required = false) String consumerId,
			@RequestHeader(name="Trace-Id", required = false) String traceId,
			@PathVariable(value="agreementCustomerReferenceId") String agreementCustomerReferenceId,
			@RequestBody(required = true) @Valid AgreementCustomerReferenceForPatch updateRequestInput) throws AgreementCustomerReferenceApplicationException {

		validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateRequestInput);

		consumerId = requestProcessor.truncateConsumerId(consumerId);

		updateRequestProcessor.processUpdateAgreementCustomerReferenceRequest(agreementCustomerReferenceId, updateRequestInput, consumerId);
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	/**
	 * This operation is used to retrieve the Contract header for two selection criteria
	 * 1. product Id and commercial agreement Id.
	 * 2. agreementAdministrationId and agreementAdministrationReferenceId
	 * 
	 * For a single request only one selection criteria can be provided
	 * It performs validations and forwards request to request processor
	 * 
	 * @param consumerId consumer Id of the calling application
	 * @param traceId trace Id of the input request
	 * @param productId unique identifier of the product
	 * @param commercialAgreementId unique identifier of the contract
	 * @param agreementAdministrationId building block id
	 * @param agreementAdministrationReferenceId building block reference contract number
	 * @return response containing Contract header details
	 * @throws AgreementCustomerReferenceApplicationException in case of error
	 */
	@Valid
	@GetMapping(value = "/v1", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AgreementCustomerReference> searchAgreementCustomerReference(
			@RequestHeader(name="Consumer-Id", required = false) String consumerId,
			@RequestHeader(name="Trace-Id", required = false) String traceId,
			@QueryParam(value="productId") String productId,
			@QueryParam(value="commercialAgreementId") String commercialAgreementId,
			@QueryParam(value="agreementAdministrationId") String agreementAdministrationId,
			@QueryParam(value="agreementAdministrationReferenceId") String agreementAdministrationReferenceId) throws AgreementCustomerReferenceApplicationException {
		
		validator.validateSearchRequest(productId, commercialAgreementId, agreementAdministrationId,agreementAdministrationReferenceId);
		
		AgreementCustomerReference agreementCustomerReference = searchRequestProcessor.processSearchAgreementCustomerReference(productId, commercialAgreementId, agreementAdministrationId,agreementAdministrationReferenceId);
		
		return new ResponseEntity<>(agreementCustomerReference,HttpStatus.OK);
	}
	
	/**
	 * This operation provides the details of an agreement customer reference.
	 * If the agreement customer reference is of package agreement then its also possible to fetch agreement customer references of agreements within the package.@param consumerId - id of the consumer that is calling this operation
	 * 
	 * @param consumerId consumer Id of the calling application
	 * @param traceId - id given by apigee to trace the request
	 * @param agreementCustomerReferenceId - id of the agreement customer reference to be deleted
	 * @param includeLinkedAgreementReferences when set to true,it can be used to fetch underlying agreement customer references of agreements linked to the requested agreement customer reference. 
	 * @return the HTTP status code and content of the result of the operation
	 * @throws AgreementCustomerReferenceApplicationException in case of error executing the delete operation
	 */
	@GetMapping(value = "/v1/{agreementCustomerReferenceId}", consumes =  MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GetAgreementCustomerReferenceResponse> retrieveAgreementCustomerReference(
			@RequestHeader(name="Consumer-Id", required = false) String consumerId,
			@RequestHeader(name="Trace-Id", required = false) String traceId,
			@PathVariable(value="agreementCustomerReferenceId") String agreementCustomerReferenceId,
			@QueryParam(value="includeLinkedAgreementReferences") boolean includeLinkedAgreementReferences) throws AgreementCustomerReferenceApplicationException {
	    
		// validate the input
		validator.validateAgreementCustomerReferenceId(agreementCustomerReferenceId);

		// fetch the agreement customer reference from the database
		GetAgreementCustomerReferenceResponse response = retrieveRequestProcessor.processRetrieveAgreementCustomerReference(agreementCustomerReferenceId, includeLinkedAgreementReferences);
		
		return new ResponseEntity<>(response,HttpStatus.OK);
	}

	

	/**
	 * Delete the agreement customer reference with the given id from the database.
	 * This method is called if the DELETE operation on this resource is performed.
	 * @param consumerId - id of the consumer that is calling this operation
	 * @param traceId - id given by apigee to trace the request
	 * @param agreementCustomerReferenceId - id of the agreement customer reference to be deleted
	 * @return the HTTP status code and content of the result of the operation
	 * @throws AgreementCustomerReferenceApplicationException in case of error executing the delete operation
	 */
	@DeleteMapping(value = "/v1/{agreementCustomerReferenceId}", consumes =  MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> deleteAgreementCustomerReference(
			@RequestHeader(name="Consumer-Id", required = false) String consumerId,
			@RequestHeader(name="Trace-Id", required = false) String traceId,
			@PathVariable(value = "agreementCustomerReferenceId") String agreementCustomerReferenceId) throws AgreementCustomerReferenceApplicationException {

		// validate the input
		validator.validateAgreementCustomerReferenceId(agreementCustomerReferenceId);

		consumerId = requestProcessor.truncateConsumerId(consumerId);

		// delete the agreement customer reference from the database
		deleteRequestProcessor.processDeleteOfAgreementCustomerReference(agreementCustomerReferenceId, consumerId);

		// return success without content
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
