package com.abnamro.moa.services.agreementcustomerreference.mapper;

import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * This is the mapper class for mapping the building block details
 */
@Component
public class BuildingBlockMapper {

	/**
	 * This method is used to get the building block view details to be added in database based on input request building blocks and building block details of input product
	 * 
	 * @param agreementAdministrationReferences  list of agreementAdministrationReferences 
	 * @param buildingBlockClusterTypeViewList list containing building block ID, cluster,  building block type
	 * @param agreementCustomerReferenceId unique identifier of contract in contract header (Contract header Id)
	 * @return populated list of building blocks
	 */ 
	public List<BuildingBlockView> getPopulatedBuildingBlockViewList(
			List<AgreementAdministrationReference> agreementAdministrationReferences,
			List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList, String agreementCustomerReferenceId) {
		
		List<BuildingBlockView> buildingBlockViewList = new ArrayList<>() ;
		
		// get the first AgreementAdministrationReferenceId of type C building block from input request 
		String firstAgreementAdministrationReferenceId = getFirstAgreementAdministrationReferenceId(agreementAdministrationReferences,buildingBlockClusterTypeViewList);
		
		for(BuildingBlockClusterTypeView buildingBlockClusterTypeView: buildingBlockClusterTypeViewList){
			boolean isLinkedBuildingBlockPresent = false;
			//check one by one if the building blocks are present in input or not
			for(AgreementAdministrationReference agreementAdministrationReference :agreementAdministrationReferences){
				if(Integer.valueOf(agreementAdministrationReference.getAgreementAdministrationId()) == buildingBlockClusterTypeView.getBuildingBlockId()) {
					isLinkedBuildingBlockPresent = true;
					//if the building block is present in input then populate the details from input
					buildingBlockViewList.add(getPopulatedBuildingBlockView(buildingBlockClusterTypeView, agreementCustomerReferenceId, agreementAdministrationReference.getAgreementAdministrationReferenceId()));
				}
			}
			
			if(!isLinkedBuildingBlockPresent && "F".equals(buildingBlockClusterTypeView.getBuildingBlockType())){
				//if the building block is not present in input and building block type is F
				//populate the building block details with AgreementAdministrationReferenceId as firstAgreementAdministrationReferenceId
				buildingBlockViewList.add(getPopulatedBuildingBlockView(buildingBlockClusterTypeView, agreementCustomerReferenceId, firstAgreementAdministrationReferenceId));
			}
		}
		
		return buildingBlockViewList;
	}

	/**
	 * Delivers the first type C contract AgreementAdministrationReferenceId from input
	 */
	private String getFirstAgreementAdministrationReferenceId(List<AgreementAdministrationReference> agreementAdministrationReferences, List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList) {
		String firstAgreementAdministrationReferenceId = null;
		outer : for(BuildingBlockClusterTypeView buildingBlockClusterTypeView: buildingBlockClusterTypeViewList){
			for(AgreementAdministrationReference agreementAdministrationReference :agreementAdministrationReferences){
				if(Integer.valueOf(agreementAdministrationReference.getAgreementAdministrationId()) == buildingBlockClusterTypeView.getBuildingBlockId()
						&& "C".equals(buildingBlockClusterTypeView.getBuildingBlockType())) {
					firstAgreementAdministrationReferenceId = agreementAdministrationReference.getAgreementAdministrationReferenceId();
					break outer;
				}
			}
		}
		return firstAgreementAdministrationReferenceId;
	}

	private BuildingBlockView getPopulatedBuildingBlockView(
			BuildingBlockClusterTypeView buildingBlockClusterTypeView, String agreementCustomerReferenceId, String agreementAdministrationReferenceId) {
		BuildingBlockView buildingBlockView = new BuildingBlockView();
		buildingBlockView.setBuildingBlockId(buildingBlockClusterTypeView.getBuildingBlockId());
		buildingBlockView.setBuildingBlockType(buildingBlockClusterTypeView.getBuildingBlockType());
		buildingBlockView.setProductId(buildingBlockClusterTypeView.getProductId());
		buildingBlockView.setBuildingBlockReferenceContractId(agreementAdministrationReferenceId);
		buildingBlockView.setClusterId(buildingBlockClusterTypeView.getClusterId());
		buildingBlockView.setContractHeaderId(agreementCustomerReferenceId);
		return buildingBlockView;
	}

}
