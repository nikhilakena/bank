package com.abnamro.moa.services.agreementcustomerreference.mapper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;

import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementLifeCycleStatusTypeEnum;

/**
 * Methods to convert from request input to persistent object and from persistent object to response output.
 */
public class ObjectMapper {
	/**
	 * This method is used to map the agreementCustomerReference model to database view
	 * 
	 * @param agreementCustomerReference agreementCustomerReference input request
	 * @param consumerId unique identifier of the customer
	 * @return agreementCustomerReference database view
	 */
	public static AgreementCustomerReferenceView convertFromRequestToPersistent(AgreementCustomerReference agreementCustomerReference, String consumerId) {
		AgreementCustomerReferenceView view = new AgreementCustomerReferenceView();

		view.setNickName(agreementCustomerReference.getAgreementNickName());
		view.setStatus(agreementCustomerReference.getAgreementLifeCycleStatus().getDbValue());
		
		if(consumerId!=null) {
			view.setUserId(consumerId);
		} else {
			view.setUserId(" ");
		}
		view.setParentId(agreementCustomerReference.getParentAgreementCustomerReferenceId());
		view.setCommercialContractNumber(agreementCustomerReference.getCommercialAgreementId());
		view.setCustomerId(String.valueOf(agreementCustomerReference.getCustomerId()));
		view.setProductId(String.valueOf(agreementCustomerReference.getProductId()));
		
		view.setBlockingCode(" ");
		view.setTransferService(" ");

		return view;
	}

	/**
	 * This method is used to map the update agreementCustomerReference model to database view
	 * 
	 * @param updateRequestInput agreementCustomerReference input request
	 * @param consumerId unique identifier of the customer
	 * @return database view
	 */
	public static AgreementCustomerReferenceView convertToAgreementCustomerReferenceViewForUpdate(
			AgreementCustomerReferenceForPatch updateRequestInput, String consumerId) {
		AgreementCustomerReferenceView view = new AgreementCustomerReferenceView();
		
		view.setNickName(updateRequestInput.getAgreementNickName());
		
		if(updateRequestInput.getAgreementLifeCycleStatus()!=null){
			view.setStatus(AgreementLifeCycleStatusTypeEnum.fromValue(updateRequestInput.getAgreementLifeCycleStatus()).getDbValue());
		}
		
		if(consumerId!=null) {
			view.setUserId(consumerId);
		} else {
			view.setUserId(" ");
		}
		view.setParentId(updateRequestInput.getParentAgreementCustomerReferenceId());
		view.setCommercialContractNumber(updateRequestInput.getCommercialAgreementId());
		if(updateRequestInput.getCustomerId()!=null){
			view.setCustomerId(String.valueOf(updateRequestInput.getCustomerId()));
		}
		if(updateRequestInput.getProductId()!=null){
			view.setProductId(String.valueOf(updateRequestInput.getProductId()));
		}
		return view;
	}

	/**
	 * It returns the rest model resource from the database view
	 * 
	 * @param agreementCustomerReferenceView contract header details from database
	 * @return contract header details in resource format
	 */
	public static AgreementCustomerReference convertToAgreementCustomerReferenceFromView(
			AgreementCustomerReferenceView agreementCustomerReferenceView) {
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		if(StringUtils.isNotBlank(agreementCustomerReferenceView.getProductId())){
			agreementCustomerReference.setProductId(agreementCustomerReferenceView.getProductId());
		}
		if(StringUtils.isNotBlank(agreementCustomerReferenceView.getCustomerId())){
			agreementCustomerReference.setCustomerId(agreementCustomerReferenceView.getCustomerId());
		}
		if(StringUtils.isNotBlank(agreementCustomerReferenceView.getStatus())){
			AgreementLifeCycleStatusTypeEnum statusEnum = AgreementLifeCycleStatusTypeEnum.fromDBValue(agreementCustomerReferenceView.getStatus().trim());
			agreementCustomerReference.setAgreementLifeCycleStatus(statusEnum);
		}
		if(StringUtils.isNotBlank(agreementCustomerReferenceView.getId())){
			agreementCustomerReference.setAgreementCustomerReferenceId(agreementCustomerReferenceView.getId().trim());
		}
		if(StringUtils.isNotBlank(agreementCustomerReferenceView.getCommercialContractNumber())){
			agreementCustomerReference.setCommercialAgreementId(agreementCustomerReferenceView.getCommercialContractNumber().trim());
		}
		populateAgreementAdministratioRefs(agreementCustomerReferenceView.getBuildingBlockViewList(), agreementCustomerReference);

		if (agreementCustomerReferenceView.getDateCreated() != null) {
			SimpleDateFormat timeFormatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
			String createDateTime = timeFormatter.format(agreementCustomerReferenceView.getDateCreated());
			agreementCustomerReference.setReferenceStartDate(createDateTime);
		}

		if (agreementCustomerReferenceView.getNickName() != null) {
			agreementCustomerReference.setAgreementNickName(agreementCustomerReferenceView.getNickName().trim());
		} else {
			agreementCustomerReference.setAgreementNickName("");
		}

		return agreementCustomerReference;
	}

	private static void populateAgreementAdministratioRefs(List<BuildingBlockView> buildingBlockViewList,
			AgreementCustomerReference agreementCustomerReference) {
		if(buildingBlockViewList != null){
			List<AgreementAdministrationReference> agreementAdministrationReferenceList = new ArrayList<AgreementAdministrationReference>();
			for(BuildingBlockView buildingBlockView: buildingBlockViewList){
				AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
				agreementAdministrationReference.setAgreementAdministrationId(String.valueOf(buildingBlockView.getBuildingBlockId()));
				if(StringUtils.isNotBlank(buildingBlockView.getBuildingBlockReferenceContractId())){
					agreementAdministrationReference.setAgreementAdministrationReferenceId(buildingBlockView.getBuildingBlockReferenceContractId().trim());
				}
				agreementAdministrationReferenceList.add(agreementAdministrationReference);
			}
			agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferenceList);
		}
	}
}
