package com.abnamro.moa.services.agreementcustomerreference.util;

/**
 * Utility methods regarding the IBAN-format.
 */
public final class IbanUtils {
	private IbanUtils() {}

	/**
	 * This returns the IBAN number for input BBAN number using standard algorithm
	 *
	 * @param agreementId BBAN number
	 * @return IBAN number
	 */
	public static String convertToIBAN(String agreementId) {
		String iban = "";
		String abna = "10112310";
		String nl = "2321";
		String temp = abna + agreementId + nl + "00";
		String temp9 = "";
		int rem = 0;
		String remString;
		int finalCheckDigit;
		String finalCheckDigitString;

		temp9 = temp.substring(0, 9);
		rem = Integer.valueOf(temp9) % 97;
		remString = convertTheReminder(rem);

		temp9 = remString + temp.substring(9, 16);
		rem = Integer.valueOf(temp9) % 97;
		remString = convertTheReminder(rem);

		temp9 = remString + temp.substring(16, 23);
		rem = Integer.valueOf(temp9) % 97;
		remString = convertTheReminder(rem);

		temp9 = "000000" + remString + "0";
		rem = Integer.valueOf(temp9) % 97;
		finalCheckDigit = 98 - rem;
		finalCheckDigitString = convertTheReminder(finalCheckDigit);

		iban = "NL" + finalCheckDigitString + "ABNA" + agreementId;

		return iban;
	}

	private static String convertTheReminder(int rem) {
		String remString;
		if (rem < 10) {
			remString = "0" + String.valueOf(rem);
		} else {
			remString = String.valueOf(rem);
		}
		return remString;
	}
}
