package com.abnamro.moa.services.agreementcustomerreference.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductView;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.ProductGroupIdsView;

/**
 * This class is the mapper class for AgreementCustomerReferenceDAO with the database
 */
public interface AgreementCustomerReferenceMybatisMapper {

	/**
	 * This method retrieve count of the entries for input consumerId, operation and version.
	 * 
	 * @param schemaName - String value for schemaName of database
	 * @param consumerId - unique value for consumer application calling the API
	 * @param operation - name of the operation
	 * @param version of the operation
	 * @return number of authorizations found
	 */
	public int isAuthorizedConsumer(@Param("schemaName") final String schemaName, @Param("consumerId") final String consumerId, 
		@Param("operation") final String operation, @Param("version") final String version);

	/**
	 * This method updates last date used
	 * 
	 * @param schemaName - String value for schemaName of database
	 * @param consumerId - unique value for consumer application calling the API
	 * @param operation - name of the operation
	 * @param version - version number of the operation
	 */
	public void updateLastDateUsed(@Param("schemaName") final String schemaName,@Param("consumerId") final String consumerId, 
			@Param("operation") final  String operation, @Param("version") final  String version);

	/**
	 * Return the product with the given id.
	 * 
	 * @param schemaName - String value for schemaName of database
	 * @param productId - unique value for the product to be found
	 * @return returns the product with the given product id
	 */
	public AgreementCustomerReferenceProductView selectProductsById(
			@Param("schemaName") final String schemaName
			, @Param("productId") Integer productId);

	/**
	 * Create a contract header in the database from the given agreement customer reference.
	 * 
	 * @param schemaName - String value for schemaName of database
	 * @param agreementCustomerReference - details of the agreement customer reference to be created
	 */
	public void insertContractHeader(
			@Param("schemaName") String schemaName
			, @Param("contractHeaderView") AgreementCustomerReferenceView agreementCustomerReference);

	/**
	 * Let the database generate a new id for the agreement customer reference.
	 * @param schemaName - String value for schemaName of database
	 * @return generated Agreement Customer Reference Id
	 */
	public Integer generateAgreementCustomerReferenceId(@Param("schemaName") String schemaName);

	/**
	 * Retrieve the last generated agreement customer id from the database.
	 * @param schemaName - String value for schemaName of database
	 * @return generated Agreement Customer Reference Id
	 */
	public Integer selectGeneratedAgreementCustomerReferenceId(@Param("schemaName") String schemaName);

	/**
	 * Delete the generated agreement customer reference id with the given value.
	 * @param schemaName - String value for schemaName of database
	 * @param agreementCustomerReferenceId - the generated id that is to be deleted
	 */
	public void deleteGeneratedAgreementCustomerReferenceId(@Param("schemaName") String schemaName, @Param("agreementCustomerReferenceId") Integer agreementCustomerReferenceId);

	/**
	 * Count the number of contract headers in the database with the given id.
	 * @param schemaName - String value for schemaName of database
	 * @param agreementCustomerReferenceId - the id of the contract header to search for
	 * @return the number of contract headers with the given id
	 */
	int selectNumberOfContractHeaderById(@Param("schemaName") String schemaName
			, @Param("contractHeaderId") String agreementCustomerReferenceId);

	/**
	 * Return the number of agreement customer references with the given id.
	 * 
	 * @param schemaName - String value for schemaName of database
	 * @param contractHeaderId - unique value for the agreement customer reference to be found
	 * @return returns the number of agreement customer references with the given contract header id
	 */
	Integer countNumberOfContractHeaders(@Param("schemaName") String schemaName
			, @Param("contractHeaderId") Integer contractHeaderId);
	
	/**
	 * Get the AgreementCustomerReference from database for input product id and commercialAgreementId
	 * 
	 * @param dbSchemaPrefix String value for schemaName of database
	 * @param agreementCustomerReferenceId unique identifier of the contract header
	 * @return AgreementCustomerReferenceView database details
	 */
	public AgreementCustomerReferenceView getAgreementCustomerReference(@Param("schemaName")String dbSchemaPrefix, 
			@Param("agreementCustomerReferenceId") String agreementCustomerReferenceId);

	/**
	 * Updates contract header in database
	 *
	 * @param dbSchemaPrefix String value for schemaName of database
	 * @param agreementCustomerReferenceId unique identifier of the contract header
	 * @param agreementCustomerReference the details of the agreement customer reference
	 */
	public void updateContractHeader(@Param("schemaName") String dbSchemaPrefix, @Param("agreementCustomerReferenceId") String agreementCustomerReferenceId,
			@Param("agreementCustomerReference") AgreementCustomerReferenceView agreementCustomerReference);

	/**
	 * It retrieves the agreement customer reference details from database
	 * 
	 * @param dbSchemaPrefix String value for schemaName of database
	 * @param productId unique identifier of the product
	 * @param commercialAgreementId unique identifier of the contract
	 * @param buildingBlockId building block id
	 * @param buildingBlockReferenceContractId building block reference contract number
	 * @return contract header details from database
	 */
	public AgreementCustomerReferenceView retrieveAgreementCustomerReferences(@Param("schemaName") String dbSchemaPrefix, @Param("productId") int productId,
			@Param("commercialAgreementId") String commercialAgreementId, @Param("buildingBlockId") int buildingBlockId, @Param("buildingBlockReferenceContractId") String buildingBlockReferenceContractId);

	/**
	 * Retrieve the details of agreement customer references of agreements within the package.
	 *
	 * @param dbSchemaPrefix String value for schemaName of database
	 * @param agreementCustomerReferenceId unique identifier of the contract header
	 * @return list of contract header details from database
	 */
	public List<AgreementCustomerReferenceView> retrieveLinkedAgreementCustomerReferences(@Param("schemaName") String dbSchemaPrefix,  @Param("agreementCustomerReferenceId") String agreementCustomerReferenceId);


	/**
	 * Retrieve the agreement customer reference with the given id.
	 * @param dbSchemaPrefix - the schema name of the database
	 * @param agreementCustomerReferenceId - id of the agreement customer reference to retrieve
	 * @return details of the found agreement customer reference
	 */
	public AgreementCustomerReferenceView retrieveAgreementCustomerReference(@Param("schemaName") String dbSchemaPrefix, @Param("agreementCustomerReferenceId") String agreementCustomerReferenceId);

	/**
	 * Delete the contract header with the given id from the database
	 * @param dbSchemaPrefix - the schema name of the database
	 * @param agreementCustomerReferenceId - the id of the contract header to delete
	 */
	public void deleteContractHeader(@Param("schemaName") String dbSchemaPrefix, @Param("agreementCustomerReferenceId") String agreementCustomerReferenceId);

	/**
	 * Clear the reference to the parent agreement customer reference for all children of the given agreement customer reference
	 * @param dbSchemaPrefix - the schema name of the database
	 * @param parentAgreementCustomerReferenceId - the id of the parent agreement customer reference
	 * @param agreementCustomerReference the details of the agreement customer reference
	 */
	void clearParentReferences(@Param("schemaName") String dbSchemaPrefix, @Param("parentAgreementCustomerReferenceId") String parentAgreementCustomerReferenceId, @Param("agreementCustomerReference") AgreementCustomerReferenceView agreementCustomerReference);

	/**
	 * Return all product group ids that are related to the given product.
	 * @param dbSchemaPrefix - the schema name of the database
	 * @param productId - the id of the product to search for its product group ids
	 * @return the list of related produdct group ids
	 */
	List<ProductGroupIdsView> readProductGroupIds(@Param("schemaName") String dbSchemaPrefix, @Param("productId") int productId);
}
