package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.exceptions.AgreementCustomerReferenceExternalPublisherException;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.constants.AgreementCustomerReferenceLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyView;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.AgreementCustomerReferenceDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.ResponsiblePartyDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.SettlementAccountDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 *  This is the request processor interface for the UpdateAgreementCustomerReference operation
 *
 */
@Component
public class DeleteAgreementCustomerReferenceRequestProcessor {
    private static LogHelper log = new LogHelper(DeleteAgreementCustomerReferenceRequestProcessor.class);

    @Autowired
    private AgreementCustomerReferenceDAO agreementCustomerReferenceDAO;

    @Autowired
    private AgreementCustomerReferenceDAOInvoker agreementCustomerReferenceDAOinvoker;

    @Autowired
    private PublishAgreementCustomerReferenceHelper publishAgreementCustomerReferenceHelper;

    @Autowired
    private ConnectionProvider connectionProvider;

    @Autowired
    private ResponsiblePartyDAOInvoker responsiblePartyDAO;

    @Autowired
    private SettlementAccountDAOInvoker settlementAccountDAO;

	@Autowired
	private BuildingBlockDAO buildingBlockDao;

    /**
     * Make calls to the DAO layer to delete the given agreement customer reference from the database.
     * 
     * @param agreementCustomerReferenceId - identifier of the agreement customer reference to be deleted
     * @param consumerId user id
     * @throws AgreementCustomerReferenceApplicationException in case of error
     */
    public void processDeleteOfAgreementCustomerReference(String agreementCustomerReferenceId, String consumerId)
            throws AgreementCustomerReferenceApplicationException {
        final String logMethod = "processDeleteOfAgreementCustomerReference";

		Connection connection = null;

        try {
        	// retrieve the persistent details for the agreement customer reference that is to be deleted
            AgreementCustomerReferenceView persistentAgreementCustomerReference = agreementCustomerReferenceDAO.retrieveAgreementCustomerReference(agreementCustomerReferenceId);

            if (persistentAgreementCustomerReference != null) {

				//retrieve the persistent building block details
				List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(persistentAgreementCustomerReference.getProductId()));

                // start session
                connection = connectionProvider.getConnection();
                if (connection != null) {
                    connection.setAutoCommit(false);
                }

                // delete the actual agreement customer reference
                agreementCustomerReferenceDAO.deleteAgreementCustomerReference(connection, agreementCustomerReferenceId);

                publishAgreementCustomerReferenceHelper.publishDeleteAgreementCustomerReference(persistentAgreementCustomerReference, buildingBlockClusterTypeViewList, agreementCustomerReferenceId, consumerId);

                if (connection != null) {
                    connection.commit();
                }
            } else {

                // agreement record not present in database for input productId and commercial agreement Id
                throw new AgreementCustomerReferenceApplicationException("4028", AgreementCustomerReferenceDAOConstants.RESOURCE_NOT_FOUND_HTTP_STATUS);
            }
        } catch (DAODatabaseException exception) {
            log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_DAO_EXCEPTION_UPDATE_AGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
            throw new AgreementCustomerReferenceApplicationException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
        } catch (SQLException exception) {
            log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_SQL_EXCEPTION_UPDATE_AGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
            throw new AgreementCustomerReferenceApplicationException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
        } catch (AgreementCustomerReferenceDAOException exception) {
            log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_DAO_EXCEPTION_IN_UPDATE_AGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
            throw new AgreementCustomerReferenceApplicationException(exception.getMessage(),exception.getStatus());
        } catch (AgreementCustomerReferenceExternalPublisherException exception) {
            log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_IMS_PUBLISH_EXCEPTION_IN_CREATEAGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
            throw new AgreementCustomerReferenceApplicationException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnection(connection);
        }
    }

	/**
	 * Delete the responsible party for the given agreement customer reference and delete its versions from the database.
	 * @param connection - the connection to the database
	 * @param agreementCustomerReferenceId - the identifier of the agreement customer reference of the responsible party to delete
	 * @throws AgreementCustomerReferenceDAOException is thrown if the query cannot be executed by the database
	 */
    private void deleteResponsibleParty(Connection connection, String agreementCustomerReferenceId)
		throws AgreementCustomerReferenceDAOException {
		ResponsiblePartyView responsibleParty = responsiblePartyDAO.getResponsibleParty(agreementCustomerReferenceId);
		if (responsibleParty != null) {
			responsiblePartyDAO.deleteResponsiblePartyVersions(connection, agreementCustomerReferenceId);

			responsiblePartyDAO.deleteResponsibleParties(connection, agreementCustomerReferenceId);
		}
	}
}
