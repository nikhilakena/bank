package com.abnamro.moa.services.agreementcustomerreference.dao.constants;

/**
 * This class contains the constants that are used in the logs and refer to the method from where the log is written.
 */
public final class AgreementCustomerReferenceDAOLogConstants {
	private AgreementCustomerReferenceDAOLogConstants() {}

	public static final String LOG_ERROR_IBATIS_INITIALIZATION = "LOG_ACRDL_001";
	public static final String LOG_ERROR_DB_CONNECTION = "LOG_ACRDL_002";
	public static final String LOG_ERROR_WHILE_RETRIEVING_AUTHORIZATION = "LOG_ACRDL_003";
	public static final String LOG_ERROR_WHILE_CREATING_BUILDING_BLOCK = "LOG_ACRDL_004";
	public static final String LOG_ERROR_WHILE_CREATING_CONTRACT_HEADER = "LOG_ACRDL_005";
	public static final String LOG_ERROR_WHILE_RETRIEVING_MAX_CONTRACT_HEADER_ID = "LOG_ACRDL_006";
	public static final String LOG_ERROR_DB_WHILE_VALIDATING_PRODUCT_ID = "LOG_ACRDL_007";
	public static final String LOG_ERROR_WHILE_CREATING_RESPONSIBLE_PARTY = "LOG_ACRDL_008";
	public static final String LOG_ERROR_WHILE_CREATING_RESPONSIBLE_PARTY_VERSION = "LOG_ACRDL_009";
	public static final String LOG_ERROR_WHILE_RETRIEVING_HIGHEST_RESPONSIBLE_PARTY_ID = "LOG_ACRDL_010";
	public static final String LOG_ERROR_WHILE_CREATING_SETTLEMENT_ACCOUNT = "LOG_ACRDL_011";
	public static final String LOG_ERROR_DATA_RETRIEVE_MAX_SETTLEMENT_ACCOUNT_ID = "LOG_ACRDL_012";
	public static final String LOG_ERROR_DB_WHILE_VALIDATING_PACKAGE = "LOG_ACRDL_013";
	public static final String LOG_ERROR_WHILE_SELECT_NUMBER_CONTRACT_HEADER = "LOG_ACRDL_014";
	public static final String LOG_ERROR_WHILE_GENERATING_CONTRACT_HEADER_ID = "LOG_ACRDL_015";
	public static final String LOG_ERROR_WHILE_CREATING_BUILDING_BLOCK_DUPLICATE_KEY = "LOG_ACRDL_016";
	public static final String LOG_ERROR_WHILE_RETRIEVE_BUILDING_BLOCK_DETAILS = "LOG_ACRDL_017";
	public static final String LOG_ERROR_WHILE_RETRIEVE_COUNT_OF_BUILDING_BLOCK_REF = "LOG_ACRDL_018";
	public static final String LOG_ERROR_WHILE_GET_CONTRACT_HEADER = "LOG_ACRDL_019";
	public static final String LOG_ERROR_WHILE_RETRIVING_RESPONSIBLE_PARTY = "LOG_ACRDL_020";
	public static final String LOG_ERROR_WHILE_UPDATING_RESPONSIBLE_PARTY_VERSION = "LOG_ACRDL_021";
	public static final String LOG_ERROR_WHILE_DELETING_BUILDING_BLOCK_REF = "LOG_ACRDL_022";
	public static final String LOG_ERROR_RETRIEVE_AGREEMENT_CUSTMER_REFERENCE_FOR_BUILDING_BLOCK_REF = "LOG_ACRDL_023";
	public static final String LOG_ERROR_WHILE_SEARCH_CONTRACT_HEADER = "LOG_ACRDL_024";
	public static final String LOG_ERROR_WHILE_DELETING_RESPONSIBLE_PARTIES = "LOG_ACRDL_025";
	public static final String LOG_ERROR_WHILE_DELETING_RESPONSIBLE_PARTY_VERSIONS = "LOG_ACRDL_026";
	public static final String LOG_ERROR_WHILE_DELETING_SETTLEMENT_ACCOUNT = "LOG_ACRDL_027";
	public static final String LOG_ERROR_NON_INTEGER_INPUT = "LOG_ACRDL_028";
	public static final String LOG_ERROR_NON_LONG_INPUT = "LOG_ACRDL_029";
	public static final String LOG_ERROR_WHILE_RETRIEVING_SETTLEMENT_ACCOUNT = "LOG_ACRDL_030";
	public static final String LOG_ERROR_WHILE_RETRIEVE_LINKED_AGREEMENT_REFERENCES = "LOG_ACRDL_031";
	public static final String LOG_ERROR_WHILE_RETRIEVING_PRODUCT_GROUP_IDS = "LOG_ACRDL_032";
	public static final String LOG_ERROR_WHILE_UPDATING_SETTLEMENT_ACCOUNT = "LOG_ACRDL_033";
	public static final String LOG_ERROR_WHILE_VALIDATING_SETTLEMENT_ACCOUNT = "LOG_ACRDL_034";
}
