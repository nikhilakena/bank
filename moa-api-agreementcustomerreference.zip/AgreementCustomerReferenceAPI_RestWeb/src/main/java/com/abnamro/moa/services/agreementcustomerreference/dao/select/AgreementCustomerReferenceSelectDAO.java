package com.abnamro.moa.services.agreementcustomerreference.dao.select;

import java.util.List;

import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;

/**
 * This DAO is used for test purpose. It dies not have actual Implementation
 *
 */
public interface AgreementCustomerReferenceSelectDAO {
	/**
	 * It is used to retrieve all the AgreementCustomerReferences
	 * 
	 * @return all the AgreementCustomerReferences
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	List<AgreementCustomerReferenceView> selectAgreementCustomerReferences()
			throws AgreementCustomerReferenceDAOException;
}