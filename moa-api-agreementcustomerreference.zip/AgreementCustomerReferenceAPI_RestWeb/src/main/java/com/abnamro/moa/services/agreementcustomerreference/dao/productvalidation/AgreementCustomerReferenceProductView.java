package com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation;

/**
 * The representation of a product in the database as a POJO.
 */
public class AgreementCustomerReferenceProductView {
	private String id;
	private String status;
	private String type;

	public String getId() {
		return id;
	}

	public void setId(String productId) {
		id = productId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String productStatus) {
		status = productStatus;
	}

	public String getType() {
		return type;
	}

	public void setType(String productType) {
		type = productType;
	}
}