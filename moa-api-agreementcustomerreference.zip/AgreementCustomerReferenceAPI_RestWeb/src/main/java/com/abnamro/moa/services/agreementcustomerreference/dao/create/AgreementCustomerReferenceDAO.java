package com.abnamro.moa.services.agreementcustomerreference.dao.create;

import java.sql.Connection;
import java.util.List;

import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;

/**
 * Accessor methods to interact with the persistent agreement customer reference/contract header.
 */
public interface AgreementCustomerReferenceDAO {
	/**
	 * Create an agreement customer reference in the persistent storage and return its id.
	 * 
	 * @param connection Connection object that is input so that transactionality can be maintained
	 *  
	 * @param agreementCustomerReference - the details of the new agreement customer reference
	 * 
	 * @return - the id of the persistent agreement customer reference
	 * 
	 * @throws AgreementCustomerReferenceDAOException - thrown in case of error
	 */
	String createAgreementCustomerReference(Connection connection, AgreementCustomerReferenceView agreementCustomerReference)
			throws AgreementCustomerReferenceDAOException;

	/**
	 * Check an agreement customer reference with the given id exists in the persistent storage.
	 * @param agreementCustomerReferenceId - the id of the agreement customer reference to check for
	 * @return true if an agreement customer reference exists
	 * @throws AgreementCustomerReferenceDAOException - thrown in case of error
	 */
	boolean existsAgreementCustomerReference(String agreementCustomerReferenceId)
			throws AgreementCustomerReferenceDAOException;

	/**
	 * Retrieve details based on input agreementCustomerReferenceId
	 * 
	 * @param agreementCustomerReferenceId unique identifier of the contract header
	 * @return AgreementCustomerReference details 
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	AgreementCustomerReferenceView getAgreementCustomerReference(String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Updates agreement customer reference in the database
	 * 
	 * @param connection Connection object that is input so that transactionality can be maintained
	 * @param agreementCustomerReferenceId unique identifier of the contract header
	 * @param agreementCustomerReference the details of the new agreement customer reference
	 * @throws AgreementCustomerReferenceDAOException - thrown in case of error
	 */
	void updateAgreementCustomerReference(Connection connection, String agreementCustomerReferenceId, AgreementCustomerReferenceView agreementCustomerReference) throws AgreementCustomerReferenceDAOException;

	/**
	 * It retrieves the agreement customer reference details from database
	 * 
	 * @param productId unique identifier of the product
	 * @param commercialAgreementId unique identifier of the contract
	 * @param agreementAdministrationId building block id
	 * @param agreementAdministrationReferenceId building block reference contract number
	 * @return contract header details from database
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	AgreementCustomerReferenceView retrieveAgreementCustomerReferences(String productId, String commercialAgreementId,
			String agreementAdministrationId, String agreementAdministrationReferenceId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Retrieve the details of the agreement customer reference with the given id.
	 * @param agreementCustomerReferenceId - id of the agreement customer reference to retrieve
	 * @return the complete agreement customer reference
	 * @throws AgreementCustomerReferenceDAOException in case of an error
	 */
	AgreementCustomerReferenceView retrieveAgreementCustomerReference(String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Retrieve the details of agreement customer references of agreements within the package. 
	 * 
	 * @param agreementCustomerReferenceId - id of the agreement customer reference whose linked references needs to be retrieved
	 * @return the list of agreement customer references
	 * @throws AgreementCustomerReferenceDAOException in case of an error
	 */
	List<AgreementCustomerReferenceView> retrieveLinkedAgreementCustomerReferences(String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Delete the given agreement customer reference from the database.
	 * @param connection Connection object that is input so that transactionality can be maintained
	 * @param agreementCustomerReferenceId - the id of the agreement customer reference to be deleted.
	 * @throws AgreementCustomerReferenceDAOException - thrown in case of error in the DAO layer
	 */
	void deleteAgreementCustomerReference(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Remove the reference from all child agreement customer references where the given agreement customer reference is its parent.
	 * @param connection Connection object that is input so that transactionality can be maintained
	 * @param agreementCustomerReferenceId - the parent id that is to be cleared
	 * @param agreementCustomerReference - Agreement customer reference details
	 * @throws AgreementCustomerReferenceDAOException - thrown in case of error in the DAO layer
	 */
	void clearParentReferences(Connection connection, String agreementCustomerReferenceId, AgreementCustomerReferenceView agreementCustomerReference)
			throws AgreementCustomerReferenceDAOException;

}
