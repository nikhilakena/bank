package com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty;

import java.sql.Timestamp;

/**
 * The details of a responsible party version that is to be persisted.
 */
public class ResponsiblePartyVersionView implements Comparable<ResponsiblePartyVersionView> {
	private int responsiblePartyNumber;
	private Timestamp startDate;
	private Timestamp creationDate;
	private String creatorName;
	private String contractHeaderId;
	private String organizationUnitId;
	private int bankObjectType;
	private String status;
	private String dcActCode;
	private String entryId;
	private Timestamp dateAuthorized;
	private String authorizorName;
	private String issuerName;
	private String processId;

	public int getResponsiblePartyNumber() {
		return responsiblePartyNumber;
	}

	public void setResponsiblePartyNumber(int number) {
		responsiblePartyNumber = number;
	}

	public Timestamp getStartDate() {
		return startDate;
	}

	public void setStartDate(Timestamp date) {
		startDate = date;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp date) {
		creationDate = date;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String name) {
		creatorName = name;
	}

	public String getContractHeaderId() {
		return contractHeaderId;
	}

	public void setContractHeaderId(String contractHeaderId) {
		this.contractHeaderId = contractHeaderId;
	}

	public String getOrganizationUnitId() {
		return organizationUnitId;
	}

	public void setOrganizationUnitId(String organizationUnitId) {
		this.organizationUnitId = organizationUnitId;
	}

	public int getBankObjectType() {
		return bankObjectType;
	}

	public void setBankObjectType(int bankObjectType) {
		this.bankObjectType = bankObjectType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDcActCode() {
		return dcActCode;
	}

	public void setDcActCode(String dcActCode) {
		this.dcActCode = dcActCode;
	}

	public String getEntryId() {
		return entryId;
	}

	public void setEntryId(String entryId) {
		this.entryId = entryId;
	}

	public Timestamp getDateAuthorized() {
		return dateAuthorized;
	}

	public void setDateAuthorized(Timestamp dateAuthorized) {
		this.dateAuthorized = dateAuthorized;
	}

	public String getAuthorizorName() {
		return authorizorName;
	}

	public void setAuthorizorName(String authorizorName) {
		this.authorizorName = authorizorName;
	}

	public String getIssuerName() {
		return issuerName;
	}

	public void setIssuerName(String issuerName) {
		this.issuerName = issuerName;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	@Override
	public int compareTo(ResponsiblePartyVersionView responsiblePartyVersionView) {
		return responsiblePartyVersionView.getStartDate().compareTo(this.getStartDate());
	}

	@Override
	public boolean equals(Object object) {
		boolean equalView = false;

		if (object != null && this.getClass() == object.getClass()) {
			ResponsiblePartyVersionView view = (ResponsiblePartyVersionView) object;
			equalView = compareTo(view) == 0;
		}

		return equalView;
	}

	@Override
    public int hashCode() {
	    int hashCode = 1;

	    if (startDate != null) {
	        hashCode = startDate.hashCode();
        }

	    return hashCode;
    }
}