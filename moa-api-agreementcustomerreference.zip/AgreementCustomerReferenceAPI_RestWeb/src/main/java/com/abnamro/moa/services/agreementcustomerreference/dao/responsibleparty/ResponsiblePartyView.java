package com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty;

import java.sql.Timestamp;
import java.util.List;

/**
 * The details of a responsible party that is to be persisted.
 */
public class ResponsiblePartyView {
	private int number;
	private Timestamp dateCreated;
	private String creatorName;
	private String contractHeaderId;
	private String type;
	private List<ResponsiblePartyVersionView> responsiblePartyVersionViewList;
	

	public int getNumber() {
		return number;
	}

	public void setNumber(int responsiblePartyNumber) {
		number = responsiblePartyNumber;
	}

	public Timestamp getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Timestamp date) {
		dateCreated = date;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String createdBy) {
		creatorName = createdBy;
	}

	public String getContractHeaderId() {
		return contractHeaderId;
	}

	public void setContractHeaderId(String id) {
		contractHeaderId = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String responsiblePartyType) {
		type = responsiblePartyType;
	}

	public List<ResponsiblePartyVersionView> getResponsiblePartyVersionViewList() {
		return responsiblePartyVersionViewList;
	}

	public void setResponsiblePartyVersionViewList(List<ResponsiblePartyVersionView> responsiblePartyVersionViewList) {
		this.responsiblePartyVersionViewList = responsiblePartyVersionViewList;
	}
	
}