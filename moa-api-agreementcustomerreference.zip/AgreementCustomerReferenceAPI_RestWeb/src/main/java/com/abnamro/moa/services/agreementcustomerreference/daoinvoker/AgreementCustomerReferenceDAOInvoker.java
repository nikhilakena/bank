package com.abnamro.moa.services.agreementcustomerreference.daoinvoker;

import java.sql.Connection;
import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.mapper.ObjectMapper;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;

/**
 * It facilitates calling of dao layer methods
 */
@Component
public class AgreementCustomerReferenceDAOInvoker {
	
	@Autowired
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDAO;

	/**
	 * Maps rest resource model to dao layer view and calls the dao layer to create AgreementCustomerReference
	 * 
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReference contract header details to be created
	 * @param consumerId user Id
	 * @return unique Id of the contract header
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public String createAgreementCustomerReference(Connection connection,
			AgreementCustomerReference agreementCustomerReference, String consumerId) throws AgreementCustomerReferenceDAOException {
		
		AgreementCustomerReferenceView view = ObjectMapper.convertFromRequestToPersistent(agreementCustomerReference, consumerId);

		// set the creation date
		long time = System.currentTimeMillis();
		view.setDateCreated(new Timestamp(time));
		view.setDateModified(new Timestamp(time));
		
		return agreementCustomerReferenceDAO.createAgreementCustomerReference(connection, view);
	}

	/**
	 * Retrieve details based on input agreementCustomerReferenceId
	 * 
	 * @param agreementCustomerReferenceId unique identifier of the contract header
	 * @return AgreementCustomerReference details 
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public AgreementCustomerReferenceView getAgreementCustomerReference(String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {
		return agreementCustomerReferenceDAO.getAgreementCustomerReference(agreementCustomerReferenceId);
	}

	/**
	 * Maps rest resource model to dao layer view and calls the dao layer to update agreement customer reference
	 * 
	 * @param connection Connection object that is input so that transactionality can be maintained
	 * @param agreementCustomerReferenceId unique identifier of the contract header
	 * @param updateRequestInput the details of the new agreement customer reference
	 * @param consumerId user Id
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public void updateAgreementCustomerReference(Connection connection, String agreementCustomerReferenceId, AgreementCustomerReferenceForPatch updateRequestInput, String consumerId) throws AgreementCustomerReferenceDAOException {
		
		AgreementCustomerReferenceView view = ObjectMapper.convertToAgreementCustomerReferenceViewForUpdate(updateRequestInput, consumerId);
        // set the creation date
        view.setDateModified(new Timestamp(System.currentTimeMillis()));
        
        agreementCustomerReferenceDAO.updateAgreementCustomerReference(connection, agreementCustomerReferenceId, view);
		
	}

	/**
	 * Clear the references to the parent agreement customer reference where the parent reference equals the given reference.
	 * @param connection - the connection to the database
	 * @param agreementCustomerReferenceId - the parent reference
	 * @param consumerId - the consumer that invokes the clear operation
	 * @throws AgreementCustomerReferenceDAOException in case of errors
	 */
	public void clearParentReferences(Connection connection, String agreementCustomerReferenceId, String consumerId)
			throws AgreementCustomerReferenceDAOException {
		AgreementCustomerReferenceView agreementCustomerReference = new AgreementCustomerReferenceView();
		String userId = consumerId != null ? consumerId : " ";
		agreementCustomerReference.setUserId(userId);
		agreementCustomerReference.setDateModified(new Timestamp(System.currentTimeMillis()));

		agreementCustomerReferenceDAO.clearParentReferences(connection, agreementCustomerReferenceId, agreementCustomerReference);
	}
}
