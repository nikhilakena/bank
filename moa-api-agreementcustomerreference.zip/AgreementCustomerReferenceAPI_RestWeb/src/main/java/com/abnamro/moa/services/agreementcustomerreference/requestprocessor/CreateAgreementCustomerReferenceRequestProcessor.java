package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;


import java.sql.Connection;
import java.util.List;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;

import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;

/**
 * This is the request processor interface for the CreateAgreementCustomerReference operation
 *
 */
public interface CreateAgreementCustomerReferenceRequestProcessor {
	
	/**
	 * Validate the given input details If both validated then calls different dao layer methods to insert records 
	 * 
	 * @param agreementCustomerReference input request containing input request for create
	 * @param consumerId unique Identifier of the customer
	 * @return unique Identifier of agreementCustomerReference (Contract header Id)
	 * @throws AgreementCustomerReferenceApplicationException in case of error
	 */
	String processCreateAgreementCustomerReferenceRequest(AgreementCustomerReference agreementCustomerReference, String consumerId) throws AgreementCustomerReferenceApplicationException;
	
	/**
	 * create an agreement customer reference in the database.
	 * 
	 * @param connection Connection object that is input so that transactionality can be maintained
	 * @param agreementCustomerReference input request containing input request for create
	 * @param consumerId unique Identifier of the customer
	 * @return unique Identifier of agreementCustomerReference (Contract header Id)
	 * @throws AgreementCustomerReferenceDAOException in case of error 
	 */
	String createAgreementCustomerReference(Connection connection,AgreementCustomerReference agreementCustomerReference, String consumerId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Create a settlement account if the given input is a package.
	 * @param connection Connection object that is input so that transactionality can be maintained
	 * @param agreementCustomerReference input request containing input request for create
	 * @param consumerId unique Identifier of the customer
	 * @param agreementCustomerReferenceId unique Identifier of agreementCustomerReference (Contract header Id)
	 * @throws AgreementCustomerReferenceDAOException in case of error 
	 * @throws AgreementCustomerReferenceApplicationException in case of error 
	 */

	void createSettlementAccount(Connection connection,String agreementCustomerReferenceId, AgreementCustomerReference agreementCustomerReference, String consumerId) throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException;


	/**
	 * Create the responsible party and its version in database.
	 * 
	 * @param connection Connection object that is input so that transactionality can be maintained
	 * @param agreementCustomerReference input request containing input request for create
	 * @param consumerId unique Identifier of the customer
	 * @param retrievePartyDetailsResponseTO responsible party details
	 * @param agreementCustomerReferenceId unique Identifier of agreementCustomerReference (Contract header Id)
	 * @throws AgreementCustomerReferenceDAOException in case of error 
	 */
	void createResponsibleParty(Connection connection,String agreementCustomerReferenceId, AgreementCustomerReference agreementCustomerReference, RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO, String consumerId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Create a building block for each and make it persistent.
	 * 
	 * @param connection Connection object that is input so that transactionality can be maintained
	 * @param agreementCustomerReference input request containing input request for create
	 * @param buildingBlockClusterTypeViewList building blcok details
	 * @param agreementCustomerReferenceId unique Identifier of agreementCustomerReference (Contract header Id)
	 * @throws AgreementCustomerReferenceDAOException in case of error 
	 */
	void createBuildingBlock(Connection connection,String agreementCustomerReferenceId, AgreementCustomerReference agreementCustomerReference, List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList) throws AgreementCustomerReferenceDAOException;

}
