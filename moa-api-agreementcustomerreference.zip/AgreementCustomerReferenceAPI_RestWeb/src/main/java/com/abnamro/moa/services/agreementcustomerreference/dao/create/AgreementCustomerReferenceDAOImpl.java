package com.abnamro.moa.services.agreementcustomerreference.dao.create;

import java.sql.Connection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.abnamro.moa.services.agreementcustomerreference.dao.AgreementCustomerReferenceMybatisMapper;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.util.AgreementCustomerReferenceIdUtils;
import com.abnamro.nl.channels.jndilookup.JndiConstants;
import com.abnamro.nl.channels.jndilookup.JndiLookup;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.dao.util.mybatis.MyBatisConfigException;
import com.abnamro.nl.dao.util.mybatis.MyBatisConnectionFactory;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;

/**
 * Methods to interact with agreement customer references that are persisted in the database.
 */
@Configuration
public class AgreementCustomerReferenceDAOImpl implements AgreementCustomerReferenceDAO {
	
	private static LogHelper logHelper = new LogHelper(AgreementCustomerReferenceDAOImpl.class);
	private static final String LOG_MYBATIS_ACTION = " mybatis exception while updating contract header";

	private final String dbSchemaPrefix;
	private final String dataSourceName;
	private static final String CONFIG_FILE_PATH = "dao/acr-mybatis-config.xml";
	private static MyBatisConnectionFactory connetionFactory;
	
	@Autowired
	private ConnectionProvider connectionProvider;

	/**
	 * Create the DAO implementation, setup connection to database.
	 */
	public AgreementCustomerReferenceDAOImpl() {
		dbSchemaPrefix = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.SCHEMA_DATABASE, AgreementCustomerReferenceDAOConstants.DEFAULT_DB_SCHEMA);
		dataSourceName = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.DATASOURCE_NAME, AgreementCustomerReferenceDAOConstants.DEFAULT_DATASOURCE);
		if (connetionFactory == null) {
			setConnetionFactory(getConnectionFactoryInstance());
		}
	}

	@Override
	public String createAgreementCustomerReference(Connection connection, AgreementCustomerReferenceView agreementCustomerReference) 
			throws AgreementCustomerReferenceDAOException {
		String agreementCustomerReferenceId = "";

		String logMethod = "createAgreementCustomerReference";

		try {
			SqlSession sqlSession = connetionFactory.getSession(connection);

			// generate the next id for the agreement customer reference to be created
			agreementCustomerReferenceId = generateNextAgreementCustomerReferenceId(connection);
			agreementCustomerReference.setId(agreementCustomerReferenceId);
			
			if(StringUtils.isEmpty(agreementCustomerReference.getCommercialContractNumber())){
				agreementCustomerReference.setCommercialContractNumber(agreementCustomerReferenceId);
			}

			sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).insertContractHeader(dbSchemaPrefix, agreementCustomerReference);
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_CREATING_CONTRACT_HEADER
					+ " mybatis exception while creating contract header {0}"
				, exception, agreementCustomerReferenceId);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}

		return agreementCustomerReferenceId;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean existsAgreementCustomerReference(String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {
		boolean exists = false;
		Connection connection = null;
		String logMethod = "existsAgreementCustomerReference():boolean";
		try {
			 connection = connectionProvider.getConnection();
			 SqlSession sqlSession= connetionFactory.getSession(connection);
			 int numberOfAgreementCustomerReferences = sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).selectNumberOfContractHeaderById(dbSchemaPrefix, agreementCustomerReferenceId);
			 exists = numberOfAgreementCustomerReferences > 0;
			 
		 } catch (MyBatisConfigException | PersistenceException exception) {
			 logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_SELECT_NUMBER_CONTRACT_HEADER, exception);
		     throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (DAODatabaseException daoDatabaseException) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_CONNECTION,
		          new String[] {dataSourceName}, daoDatabaseException);
		    throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnectionNew(connection);
		}

		return exists;
	}

	/**
	 * Generate a new id for the agreement customer reference and return it.
	 * @param connection - Connection object that is input so that transactionality can be maintained
	 * @return the generated id of the agreement customer reference
	 * @throws AgreementCustomerReferenceDAOException is thrown in case of an error
	 */
	private String generateNextAgreementCustomerReferenceId(Connection connection) throws AgreementCustomerReferenceDAOException {
		String agreementCustomerReferenceId = null;

		String logMethod = "generateNextAgreementCustomerReferenceId";
		try {
			SqlSession sqlSession = connetionFactory.getSession(connection);

			Integer previousGeneratedId = retrieveGeneratedAgreementCustomerReferenceId(sqlSession);
			if (previousGeneratedId != null) {
				deleteGeneratedAgreementCustomerReferenceId(sqlSession, previousGeneratedId);
			}

			// have the database generated a new id & retrieve this generated id
			Integer generatedId = generateAgreementCustomerReferenceId(sqlSession);

			// convert the generated number into the agreement customer reference id format
			agreementCustomerReferenceId = AgreementCustomerReferenceIdUtils.convertGeneratedIdToAgreementCustomerReferenceId(generatedId);

			// delete the generated id
			deleteGeneratedAgreementCustomerReferenceId(sqlSession, generatedId);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod
				, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_GENERATING_CONTRACT_HEADER_ID + " mybatis exception while creating contract header"
				, exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR, AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}

		return agreementCustomerReferenceId;
	}

	private Integer generateAgreementCustomerReferenceId(SqlSession session) {
		return session.getMapper(AgreementCustomerReferenceMybatisMapper.class).generateAgreementCustomerReferenceId(dbSchemaPrefix);
	}

	private Integer retrieveGeneratedAgreementCustomerReferenceId(SqlSession session) {
		return session.getMapper(AgreementCustomerReferenceMybatisMapper.class).selectGeneratedAgreementCustomerReferenceId(dbSchemaPrefix);
	}

	private void deleteGeneratedAgreementCustomerReferenceId(SqlSession session, Integer agreementCustomerReferenceId) {
		session.getMapper(AgreementCustomerReferenceMybatisMapper.class).deleteGeneratedAgreementCustomerReferenceId(dbSchemaPrefix, agreementCustomerReferenceId);
	}

	/**
	 * @return returns an instance of MyBatisConnectionFactory class
	 */
	private static synchronized MyBatisConnectionFactory getConnectionFactoryInstance() {
	    final String logMethod = "getConnectionFactoryInstance():MyBatisConnectionFactory";

		try {
			// Creates new Instance for MyBatis Connection factory & loads the
			// Mybatis Configuration file
			return new MyBatisConnectionFactory(CONFIG_FILE_PATH);
		} catch (MyBatisConfigException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_IBATIS_INITIALIZATION, null, exception);
		}

		return null;
	}

	private static synchronized void setConnetionFactory(MyBatisConnectionFactory myBatisConnectionFactory) {
		connetionFactory = myBatisConnectionFactory;
	}

	@Override
	public AgreementCustomerReferenceView getAgreementCustomerReference(String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {
		Connection connection = null;
		String logMethod = "getAgreementCustomerReference";
		AgreementCustomerReferenceView agreementCustomerReferenceView= null;
		try {
			 connection = connectionProvider.getConnection();
			 SqlSession sqlSession= connetionFactory.getSession(connection);
			 agreementCustomerReferenceView = sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).getAgreementCustomerReference(dbSchemaPrefix, agreementCustomerReferenceId);
			 
		 } catch (MyBatisConfigException | PersistenceException exception) {
			 logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_GET_CONTRACT_HEADER, exception);
		     throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (DAODatabaseException daoDatabaseException) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_CONNECTION,
		          new String[] {dataSourceName}, daoDatabaseException);
		    throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnectionNew(connection);
		}
		return agreementCustomerReferenceView;
	}

	@Override
	public void updateAgreementCustomerReference(Connection connection, String agreementCustomerReferenceId,
			AgreementCustomerReferenceView agreementCustomerReference) throws AgreementCustomerReferenceDAOException {
		
		String logMethod = "updateAgreementCustomerReference";

		try {
			SqlSession sqlSession = connetionFactory.getSession(connection);

			sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).updateContractHeader(dbSchemaPrefix, agreementCustomerReferenceId, agreementCustomerReference);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_CREATING_CONTRACT_HEADER
					+ LOG_MYBATIS_ACTION, exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
	}

	@Override
	public AgreementCustomerReferenceView retrieveAgreementCustomerReferences(String productId, String commercialAgreementId,
			String agreementAdministrationId, String agreementAdministrationReferenceId) throws AgreementCustomerReferenceDAOException {
		Connection connection = null;
		AgreementCustomerReferenceView agreementCustomerReferenceView  = null;
		String logMethod = "retrieveAgreementCustomerReferences";
		try {
			 connection = connectionProvider.getConnection();
			 SqlSession sqlSession= connetionFactory.getSession(connection);
			 int productIdNumber = productId!= null ? Integer.parseInt(productId) :0;
			 int bbidNumber = agreementAdministrationId != null ? Integer.parseInt(agreementAdministrationId) :0;
			 
			 agreementCustomerReferenceView = sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).retrieveAgreementCustomerReferences(dbSchemaPrefix, productIdNumber,commercialAgreementId, bbidNumber, agreementAdministrationReferenceId);
		} catch (MyBatisConfigException | PersistenceException exception) {
			 logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_SEARCH_CONTRACT_HEADER, exception);
		     throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (DAODatabaseException daoDatabaseException) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_CONNECTION,
		          new String[] {dataSourceName}, daoDatabaseException);
		    throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnectionNew(connection);
		}
		return agreementCustomerReferenceView;
	}
	
	@Override
	public AgreementCustomerReferenceView retrieveAgreementCustomerReference(String agreementCustomerReferenceId)
			throws AgreementCustomerReferenceDAOException {
		AgreementCustomerReferenceView agreementCustomerReferenceView  = null;
		Connection connection = null;
		String logMethod = "retrieveAgreementCustomerReference";

		try {
			connection = connectionProvider.getConnection();
			SqlSession sqlSession= connetionFactory.getSession(connection);

			agreementCustomerReferenceView = sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).retrieveAgreementCustomerReference(dbSchemaPrefix, agreementCustomerReferenceId);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_SEARCH_CONTRACT_HEADER, exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (DAODatabaseException daoDatabaseException) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_CONNECTION,
					new String[] {dataSourceName}, daoDatabaseException);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnectionNew(connection);
		}

		return agreementCustomerReferenceView;
	}
	
	@Override
	public List<AgreementCustomerReferenceView> retrieveLinkedAgreementCustomerReferences(String agreementCustomerReferenceId)
			throws AgreementCustomerReferenceDAOException {
		List<AgreementCustomerReferenceView> agreementCustomerReferenceViewList  = null;
		Connection connection = null;
		String logMethod = "retrieveLinkedAgreementCustomerReferences";

		try {
			connection = connectionProvider.getConnection();
			SqlSession sqlSession= connetionFactory.getSession(connection);
			agreementCustomerReferenceViewList = sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).retrieveLinkedAgreementCustomerReferences(dbSchemaPrefix, agreementCustomerReferenceId);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_RETRIEVE_LINKED_AGREEMENT_REFERENCES, exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (DAODatabaseException daoDatabaseException) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_CONNECTION,
					new String[] {dataSourceName}, daoDatabaseException);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			DAODatabaseUtil.closeConnectionNew(connection);
		}

		return agreementCustomerReferenceViewList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public 	void deleteAgreementCustomerReference(Connection connection,String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {
		String logMethod = "deleteAgreementCustomerReference";

		try {
			SqlSession sqlSession = connetionFactory.getSession(connection);

			sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).deleteContractHeader(dbSchemaPrefix, agreementCustomerReferenceId);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			String errorMessage = AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_CREATING_CONTRACT_HEADER + LOG_MYBATIS_ACTION;
			logHelper.error(logMethod, errorMessage, exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR, AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void clearParentReferences(Connection connection, String parentAgreementCustomerReferenceId, AgreementCustomerReferenceView agreementCustomerReference)
			throws AgreementCustomerReferenceDAOException {
		String logMethod = "clearParentReferences";

		try {
			SqlSession sqlSession = connetionFactory.getSession(connection);
			sqlSession.getMapper(AgreementCustomerReferenceMybatisMapper.class).clearParentReferences(dbSchemaPrefix, parentAgreementCustomerReferenceId, agreementCustomerReference);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			String errorMessage = AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_CREATING_CONTRACT_HEADER + LOG_MYBATIS_ACTION;
			logHelper.error(logMethod, errorMessage, exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR, AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
	}
}
