package com.abnamro.moa.services.agreementcustomerreference.dao.settlement;

import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAOImpl;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.nl.channels.jndilookup.JndiConstants;
import com.abnamro.nl.channels.jndilookup.JndiLookup;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.dao.util.mybatis.MyBatisConfigException;
import com.abnamro.nl.dao.util.mybatis.MyBatisConnectionFactory;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

/**
 * The accessor methods to interact with the persistent settlement accounts in the database.
 */
@Component
public class SettlementAccountDAOImpl implements SettlementAccountDAO {
	private static LogHelper logHelper = new LogHelper(AgreementCustomerReferenceDAOImpl.class);

	private final String dbSchemaPrefix;
	private final String dataSourceName;
	private static final String CONFIG_FILE_PATH = "dao/acr-mybatis-config.xml";
	private static MyBatisConnectionFactory connectionFactory;

	@Autowired
	private ConnectionProvider connectionProvider;

	/**
	 * Create the DAO and setup the connection to the database.
	 */
	public SettlementAccountDAOImpl() {
		dbSchemaPrefix = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.SCHEMA_DATABASE, AgreementCustomerReferenceDAOConstants.DEFAULT_DB_SCHEMA);
		dataSourceName = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.DATASOURCE_NAME, AgreementCustomerReferenceDAOConstants.DEFAULT_DATASOURCE);
		if (connectionFactory == null) {
			setConnetionFactory(getConnectionFactoryInstance());
		}
	}

	@Override
	public int createSettlementAccount(Connection connection,SettlementAccountView settlementAccount)
			throws AgreementCustomerReferenceDAOException {
		int settlementAccountId = 0;

		String logMethod = "createSettlementAccount";

		try {
			SqlSession sqlSession = connectionFactory.getSession(connection);
			sqlSession.getMapper(SettlementAccountMybatisMapper.class).insertSettlementAccount(dbSchemaPrefix, settlementAccount);
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_CREATING_SETTLEMENT_ACCOUNT
					+ " mybatis exception while creating contract header", exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}

		return settlementAccountId;
	}

	@Override
	public List<SettlementAccountView> selectAllSettlementAccounts() {
		return new ArrayList<>();
	}

	/**
	 * Delete the settlement account with the given agreement customer reference.
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId - the agreement customer reference id of the responsible party versions that is to be deleted.
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public void deleteSettlementAccount(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {
		String logMethod = "deleteSettlementAccount";

		try {
			SqlSession sqlSession = connectionFactory.getSession(connection);
			sqlSession.getMapper(SettlementAccountMybatisMapper.class).deleteSettlementAccount(dbSchemaPrefix, agreementCustomerReferenceId);
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_DELETING_SETTLEMENT_ACCOUNT
							+ " mybatis exception while deleting SettlementAccount", exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR, AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
	}

	public String retrieveSettlementAccountNumber(String agreementCustomerReferenceId)
		throws AgreementCustomerReferenceDAOException {
		String settlementAccountNumber = null;

		String logMethod = "retrieveSettlementAccountNumber";
		Connection connection = null;

		try {
			connection = connectionProvider.getConnection();
			SqlSession sqlSession = connectionFactory.getSession(connection);
			settlementAccountNumber = sqlSession.getMapper(SettlementAccountMybatisMapper.class).retrieveSettlementAccount(dbSchemaPrefix, agreementCustomerReferenceId);
		} catch (DAODatabaseException daoDatabaseException) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_DB_CONNECTION,
				new String[] {dataSourceName}, daoDatabaseException);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
				AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_RETRIEVING_SETTLEMENT_ACCOUNT + " mybatis exception while retrieving SettlementAccountNumber", exception);
		} finally {
			DAODatabaseUtil.closeConnectionNew(connection);
		}

		return settlementAccountNumber;
	}

	/**
	 * @return returns an instance of MyBatisConnectionFactory class
	 */
	private static synchronized MyBatisConnectionFactory getConnectionFactoryInstance() {
	    final String logMethod = "getConnectionFactoryInstance():MyBatisConnectionFactory";

		try {
			// Creates new Instance for MyBatis Connection factory & loads the
			// Mybatis Configuration file
			return new MyBatisConnectionFactory(CONFIG_FILE_PATH);
		} catch (MyBatisConfigException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_IBATIS_INITIALIZATION, null, exception);
		}

		return null;
	}

	private static synchronized void setConnetionFactory(MyBatisConnectionFactory myBatisConnectionFactory) {
		connectionFactory = myBatisConnectionFactory;
	}
	
	
	@Override
	public void updateSettlementAccount(Connection connection,SettlementAccountView settlementAccount)
			throws AgreementCustomerReferenceDAOException {
		String logMethod = "updateSettlementAccount";

		try {
			SqlSession sqlSession = connectionFactory.getSession(connection);
			sqlSession.getMapper(SettlementAccountMybatisMapper.class).updateSettlementAccount(dbSchemaPrefix, settlementAccount);
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_UPDATING_SETTLEMENT_ACCOUNT
					+ " mybatis exception while updating settlement account", exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
	}

}
