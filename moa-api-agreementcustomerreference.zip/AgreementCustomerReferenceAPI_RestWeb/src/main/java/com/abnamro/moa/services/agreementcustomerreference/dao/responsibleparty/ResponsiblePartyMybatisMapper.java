package com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty;

import java.sql.Timestamp;

import org.apache.ibatis.annotations.Param;

/**
 * Methods to interact with the persistent responsible party and responsible party version through my batis.
 */
public interface ResponsiblePartyMybatisMapper {
	/**
	 * Create a responsible party in the database.
	 * 
	 * @param schemaName - the name of the schema where the responsible party is persisted
	 * @param responsibleParty - the details of the repsonsible party that is to be persisted
	 */
	public void insertResponsibleParty(
			@Param("schemaName") String schemaName
			, @Param("responsibleParty") ResponsiblePartyView responsibleParty);

	/**
	 * Return the highest id of the responsible parties.
	 * 
	 * @param schemaName - the name of the schema of the responsible parties
	 * 
	 * @return the highest id of the persistent responsible parties
	 */
	public int getMaximumResponsiblePartyId(@Param("schemaName") String schemaName);

	/**
	 * Create a responsible party version in the database.
	 * 
	 * @param schemaName - the name of the schema where the responsible party versions are persisted
	 * @param responsiblePartyVersion - the details of the responsible party version that is to be persisted
	 */
	public void insertResponsiblePartyVersion(
			@Param("schemaName") String schemaName
			, @Param("responsiblePartyVersion") ResponsiblePartyVersionView responsiblePartyVersion);

	/**
	 * Generate a unique id for the responsible party record.
	 * @param schemaName - the name of the schema where the unique ids of the responsible party are stored
	 * @return the generated id
	 */
	public Integer generateResponsiblePartyId(@Param("schemaName") String schemaName);

	/**
	 * Retrieve the generated id of a responsible party.
	 * @param schemaName - the name of the schema where the unique ids of the responsible party are stored
	 * @return the generated id
	 */
	public Integer selectResponsiblePartyId(@Param("schemaName") String schemaName);

	/**
	 * Delete the given id from the generated responsible party id.
	 * @param schemaName - the name of the schema where the unique ids of the responsible party are stored
	 * @param responsiblePartyId - the id that is removed from the table of generated ids
	 */
	public void deleteGeneratedReposiblePartyId(@Param("schemaName") String schemaName, @Param("responsiblePartyId") int responsiblePartyId);

	/**
	 * Retrieve responsible party details
	 * 
	 * @param schemaName database schema name 
	 * @param agreementCustomerReferenceId unique Id of the contract header
	 * @return responsible party details
	 */
	public ResponsiblePartyView getResponsibleParty(@Param("schemaName") String schemaName, @Param("agreementCustomerReferenceId") String agreementCustomerReferenceId);

	/**
	 * Delete the responsible parties with the agreement customer reference id.
	 * @param schemaName database schema name
	 * @param agreementCustomerReferenceId unique Id of the contract header
	 */
	public void deleteResponsibleParties(@Param("schemaName") String schemaName, @Param("agreementCustomerReferenceId") String agreementCustomerReferenceId);

	/**
	 * Update status for the responsibleParty
	 * 
	 * @param dbSchemaPrefix database schema name 
	 * @param responsiblePartyId unique Id of the responsible party 
	 * @param startDate start date of the responsible party version 
	 * @param status to be updated status
	 * @param userId to be updated userId
	 */
	public void updateResponsiblePartyVersionStatus(@Param("schemaName") String dbSchemaPrefix, @Param("responsiblePartyId") int responsiblePartyId, @Param("startDate") Timestamp startDate,
			@Param("status") String status, @Param("userId") String userId);

	/**
	 * Delete the responsible party versions with the agreement customer reference id.
	 * @param schemaName database schema name
	 * @param agreementCustomerReferenceId unique Id of the contract header
	 */
	public void deleteResponsiblePartyVersions(@Param("schemaName") String schemaName, @Param("agreementCustomerReferenceId") String agreementCustomerReferenceId);
}
