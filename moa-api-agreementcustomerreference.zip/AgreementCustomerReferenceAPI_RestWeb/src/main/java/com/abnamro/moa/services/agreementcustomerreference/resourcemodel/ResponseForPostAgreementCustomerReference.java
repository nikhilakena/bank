package com.abnamro.moa.services.agreementcustomerreference.resourcemodel;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Response of the operation
 */
@ApiModel(description = "Response of the operation")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-04-05T06:58:44.424Z")

public class ResponseForPostAgreementCustomerReference   {
  @JsonProperty("agreementCustomerReferenceId")
  private String agreementCustomerReferenceId = null;

  public ResponseForPostAgreementCustomerReference agreementCustomerReferenceId(String agreementCustomerReferenceId) {
    this.agreementCustomerReferenceId = agreementCustomerReferenceId;
    return this;
  }

  /**
   * Unique identification for an Agreement Customer Reference (ContractHeader). Agreement Customer References are  golden references for ABN AMRO customers and their agreements.
   * @return agreementCustomerReferenceId
  **/
  @ApiModelProperty(example = "EGC450082", required = true, value = "Unique identification for an Agreement Customer Reference (ContractHeader). Agreement Customer References are  golden references for ABN AMRO customers and their agreements.")
  @NotNull


  public String getAgreementCustomerReferenceId() {
    return agreementCustomerReferenceId;
  }

  public void setAgreementCustomerReferenceId(String agreementCustomerReferenceId) {
    this.agreementCustomerReferenceId = agreementCustomerReferenceId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ResponseForPostAgreementCustomerReference responseForPostAgreementCustomerReference = (ResponseForPostAgreementCustomerReference) o;
    return Objects.equals(this.agreementCustomerReferenceId, responseForPostAgreementCustomerReference.agreementCustomerReferenceId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(agreementCustomerReferenceId);
  }

}

