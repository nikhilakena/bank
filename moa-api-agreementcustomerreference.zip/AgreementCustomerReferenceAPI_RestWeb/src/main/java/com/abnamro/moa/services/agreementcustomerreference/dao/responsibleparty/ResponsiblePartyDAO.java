package com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty;

import java.sql.Connection;
import java.sql.Timestamp;

import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;

/**
 * Methods to interact with the persistent responsible party and the responsible party version.
 */
public interface ResponsiblePartyDAO {
	/**
	 * Insert the given responsible party into the database.
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * 
	 * @param responsibleParty - the details of the responsible party that is to be created
	 * 
	 * @return the id of the responsible party that is persisted
	 * 
	 * @throws AgreementCustomerReferenceDAOException if the connection with the persistent storage cannot be made
	 */
	int createResponsibleParty(Connection connection, ResponsiblePartyView responsibleParty) throws AgreementCustomerReferenceDAOException;

	/**
	 * Insert the given responsible party version into the database.
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * 
	 * @param responsiblePartyVersion - the details of the resposible party version that is to be persisted
	 * 
	 * @throws AgreementCustomerReferenceDAOException if the connection with the persistent storage cannot be made
	 */
	void createResponsiblePartyVersion(Connection connection, ResponsiblePartyVersionView responsiblePartyVersion) throws AgreementCustomerReferenceDAOException;

	/**
	 * Returns the responsible party details for input agreementCustomerReferenceId
	 * 
	 * @param agreementCustomerReferenceId unique Id of the contract header
	 * @return responsible party details
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	ResponsiblePartyView getResponsibleParty(String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Delete the responsible party that has the given agreement customer reference id.
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId - id of the responsible party that is to be deleted
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	void deleteResponsibleParties(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Updates responsible party version status
	 * 
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param responsiblePartyId unique Id of the responsible party 
	 * @param startDate start date of the responsible party version 
	 * @param status to be updated status
	 * @param userId to be updated userId
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	void updateResponsiblePartyVersionStatus(Connection connection, int responsiblePartyId, Timestamp startDate, String status,
			String userId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Delete the responsible party version with the given agreement customer reference id.
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId - the agreement customer reference id of the responsible party versions that is to be deleted.
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	void deleteResponsiblePartyVersions(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException;
}