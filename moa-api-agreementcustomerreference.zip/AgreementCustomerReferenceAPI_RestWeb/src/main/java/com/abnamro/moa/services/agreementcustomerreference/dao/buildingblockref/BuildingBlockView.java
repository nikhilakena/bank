package com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref;

/**
 * The representation of the persistent building block.
 */
public class BuildingBlockView {
	private String buildingBlockReferenceContractId;
	private int productId;
	private int clusterId;
	private int buildingBlockId;
	private String contractHeaderId;
	private String buildingBlockType;

	public String getBuildingBlockReferenceContractId() {
		return buildingBlockReferenceContractId;
	}

	public void setBuildingBlockReferenceContractId(String id) {
		buildingBlockReferenceContractId = id;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int id) {
		productId = id;
	}

	public int getClusterId() {
		return clusterId;
	}

	public void setClusterId(int id) {
		clusterId = id;
	}

	public int getBuildingBlockId() {
		return buildingBlockId;
	}

	public void setBuildingBlockId(int id) {
		buildingBlockId = id;
	}

	public String getContractHeaderId() {
		return contractHeaderId;
	}

	public void setContractHeaderId(String id) {
		contractHeaderId = id;
	}
	public String getBuildingBlockType() {
		return buildingBlockType;
	}

	public void setBuildingBlockType(String buildingBlockType) {
		this.buildingBlockType = buildingBlockType;
	}
}