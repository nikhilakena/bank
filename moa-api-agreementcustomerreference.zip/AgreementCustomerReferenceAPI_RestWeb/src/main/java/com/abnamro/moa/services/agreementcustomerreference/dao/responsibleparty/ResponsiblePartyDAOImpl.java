package com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty;

import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.nl.channels.jndilookup.JndiConstants;
import com.abnamro.nl.channels.jndilookup.JndiLookup;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.dao.util.mybatis.MyBatisConfigException;
import com.abnamro.nl.dao.util.mybatis.MyBatisConnectionFactory;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import java.sql.Connection;
import java.sql.Timestamp;

/**
 * This is the DAO implementation class for the maintaining responsible party
 *
 */
@Configuration
public class ResponsiblePartyDAOImpl implements ResponsiblePartyDAO {
	private static LogHelper logHelper = new LogHelper(ResponsiblePartyDAOImpl.class);
	
	@Autowired
	private ConnectionProvider connectionProvider;

	private final String dbSchemaPrefix;
	private static final String CONFIG_FILE_PATH = "dao/acr-mybatis-config.xml";
	private static volatile MyBatisConnectionFactory connetionFactory;

	/**
	 * Default constructor creating Mybatis connection factory
	 */
	public ResponsiblePartyDAOImpl() {
		dbSchemaPrefix = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.SCHEMA_DATABASE, AgreementCustomerReferenceDAOConstants.DEFAULT_DB_SCHEMA);
		if (connetionFactory == null) {
			setConnetionFactory(getConnectionFactoryInstance());
		}
	}

	@Override
	public int createResponsibleParty(Connection connection,ResponsiblePartyView responsibleParty) 
			throws AgreementCustomerReferenceDAOException {
		Integer generatedResponsiblePartyId = null;

		String logMethod = "createResponsibleParty";
		
		if (responsibleParty != null){
			try {
				SqlSession sqlSession = connetionFactory.getSession(connection);

				// delete a previously generated responsible party id
				int previousResponsiblePartyId = retrieveGeneratedResponsiblePartyId(sqlSession);
				if (previousResponsiblePartyId != 0) {
					deleteGeneratedResponsiblePartyId(sqlSession, previousResponsiblePartyId);
				}

				// generate & fetch a new id for the responsible party
				generatedResponsiblePartyId = generateResponsiblePartyId(sqlSession);

				// delete the generated id from the database
				deleteGeneratedResponsiblePartyId(sqlSession, generatedResponsiblePartyId);

				// set the id and store the responsible party in the database
				responsibleParty.setNumber(generatedResponsiblePartyId);
				sqlSession.getMapper(ResponsiblePartyMybatisMapper.class).insertResponsibleParty(dbSchemaPrefix, responsibleParty);
				
			} catch (MyBatisConfigException | PersistenceException exception) {
				logHelper.error(logMethod,
						AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_CREATING_RESPONSIBLE_PARTY
						+ " mybatis exception while creating contract header", exception);
				throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
			} 
		}
		
		return generatedResponsiblePartyId;
	}
	
	@Override
	public void createResponsiblePartyVersion(Connection connection,ResponsiblePartyVersionView responsiblePartyVersion) 
			throws AgreementCustomerReferenceDAOException {
		String logMethod = "createResponsiblePartyVersion";
		
		if (responsiblePartyVersion != null) {
			try {
				SqlSession sqlSession = connetionFactory.getSession(connection);

				sqlSession.getMapper(ResponsiblePartyMybatisMapper.class).insertResponsiblePartyVersion(dbSchemaPrefix, responsiblePartyVersion);
				
			} catch (MyBatisConfigException | PersistenceException exception) {
				logHelper.error(logMethod,
			AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_CREATING_RESPONSIBLE_PARTY_VERSION
				+ " mybatis exception while creating responsible party version", exception);
				throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
			}
		} else {
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
	}

	private int generateResponsiblePartyId(SqlSession session) throws AgreementCustomerReferenceDAOException {
		int newId = 0;
		Integer responsiblePartyId = session.getMapper(ResponsiblePartyMybatisMapper.class).generateResponsiblePartyId(dbSchemaPrefix);
		if (responsiblePartyId != null) {
			newId = responsiblePartyId.intValue();
		}
		return newId;
	}

	private int retrieveGeneratedResponsiblePartyId(SqlSession session) throws AgreementCustomerReferenceDAOException {
		int newId = 0;

		Integer responsiblePartyId = session.getMapper(ResponsiblePartyMybatisMapper.class).selectResponsiblePartyId(dbSchemaPrefix);
		if (responsiblePartyId != null) {
			newId = responsiblePartyId.intValue();
		}

		return newId;
	}

	private void deleteGeneratedResponsiblePartyId(SqlSession session, int responsiblePartyId) throws AgreementCustomerReferenceDAOException {
		session.getMapper(ResponsiblePartyMybatisMapper.class).deleteGeneratedReposiblePartyId(dbSchemaPrefix, responsiblePartyId);
	}

	/**
	 * @return returns an instance of MyBatisConnectionFactory class
	 */
	private static synchronized MyBatisConnectionFactory getConnectionFactoryInstance() {
	    final String logMethod = "getConnectionFactoryInstance():MyBatisConnectionFactory";

		try {
			// Creates new Instance for MyBatis Connection factory & loads the
			// Mybatis Configuration file
			return new MyBatisConnectionFactory(CONFIG_FILE_PATH);
		} catch (MyBatisConfigException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_IBATIS_INITIALIZATION, null, exception);
		}

		return null;
	}

	private static synchronized void setConnetionFactory(MyBatisConnectionFactory myBatisConnectionFactory) {
		connetionFactory = myBatisConnectionFactory;
	}

	@Override
	public ResponsiblePartyView getResponsibleParty(String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {
		
		Connection connection = null;
		String logMethod = "getResponsibleParty";
		ResponsiblePartyView responsiblePartyView = null;
		
		try {
			connection = connectionProvider.getConnection();
			SqlSession sqlSession = connetionFactory.getSession(connection);
			responsiblePartyView = sqlSession.getMapper(ResponsiblePartyMybatisMapper.class).getResponsibleParty(dbSchemaPrefix, agreementCustomerReferenceId);
			
		} catch (MyBatisConfigException | PersistenceException | DAODatabaseException exception) {
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_RETRIVING_RESPONSIBLE_PARTY
					+ " mybatis exception while retriving responsible party", exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
			 DAODatabaseUtil.closeConnection(connection);
		}
		return responsiblePartyView;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void deleteResponsibleParties(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException  {
		String logMethod = "deleteResponsibleParties()";

		try {
			SqlSession sqlSession = connetionFactory.getSession(connection);
			sqlSession.getMapper(ResponsiblePartyMybatisMapper.class).deleteResponsibleParties(dbSchemaPrefix, agreementCustomerReferenceId);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_DELETING_RESPONSIBLE_PARTIES, exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR, AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
	}

	@Override
	public void updateResponsiblePartyVersionStatus(Connection connection, int responsiblePartyId, Timestamp startDate,
			String status, String userId) throws AgreementCustomerReferenceDAOException {
		String logMethod = "updateResponsiblePartyVersionStatus";
		try {
			SqlSession sqlSession = connetionFactory.getSession(connection);
			sqlSession.getMapper(ResponsiblePartyMybatisMapper.class).updateResponsiblePartyVersionStatus(dbSchemaPrefix, responsiblePartyId, startDate, status, userId);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod,
					AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_UPDATING_RESPONSIBLE_PARTY_VERSION
					+ " mybatis exception while updating responsible party version", exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void deleteResponsiblePartyVersions(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException  {
		String logMethod = "deleteResponsiblePartyVersions()";

		try {
			SqlSession sqlSession = connetionFactory.getSession(connection);
			sqlSession.getMapper(ResponsiblePartyMybatisMapper.class).deleteResponsiblePartyVersions(dbSchemaPrefix, agreementCustomerReferenceId);
			
		} catch (MyBatisConfigException | PersistenceException exception) {
			logHelper.error(logMethod, AgreementCustomerReferenceDAOLogConstants.LOG_ERROR_WHILE_DELETING_RESPONSIBLE_PARTY_VERSIONS, exception);
			throw new AgreementCustomerReferenceDAOException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR, AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		}
	}
}
