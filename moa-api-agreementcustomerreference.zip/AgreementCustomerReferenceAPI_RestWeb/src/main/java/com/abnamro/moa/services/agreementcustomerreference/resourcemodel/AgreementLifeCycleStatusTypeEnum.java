package com.abnamro.moa.services.agreementcustomerreference.resourcemodel;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Contains status of the agreement within the lifecycle.
 */
public enum AgreementLifeCycleStatusTypeEnum {
	
  ACTIVE("ACTIVE", "2"),
  
  ENDED("ENDED", "3");

  private String value;
  private String dbValue;

  AgreementLifeCycleStatusTypeEnum(String value, String dbValue) {
    this.value = value;
    this.dbValue = dbValue;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  	/**
  	 * converts rest value into DB2 value
  	 * 
	 * @param value String value from resource model
	 * @return database value
	 */
	@JsonCreator
  public static AgreementLifeCycleStatusTypeEnum fromValue(String value) {
    for (AgreementLifeCycleStatusTypeEnum b : AgreementLifeCycleStatusTypeEnum.values()) {
      if (String.valueOf(b.value).equals(value)) {
        return b;
      }
    }
    return null;
  }
	
	/**
	 * converts DB2 value into rest value
	 * 
	 * @param dbValue database value
	 * @return resource value
	 */
	  public static AgreementLifeCycleStatusTypeEnum fromDBValue(String dbValue) {
	    for (AgreementLifeCycleStatusTypeEnum b : AgreementLifeCycleStatusTypeEnum.values()) {
	      if (String.valueOf(b.dbValue).equals(dbValue)) {
	        return b;
	      }
	    }
	    return null;
	  }

	public String getValue() {
		return value;
	}

	public String getDbValue() {
		return dbValue;
	}
  
}
