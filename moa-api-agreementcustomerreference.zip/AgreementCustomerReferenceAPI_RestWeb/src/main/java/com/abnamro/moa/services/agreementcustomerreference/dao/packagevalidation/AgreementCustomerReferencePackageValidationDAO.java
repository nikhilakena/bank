package com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation;

import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;

/**
 * Methods to validate the input to create an agreement customer reference.
 */
public interface AgreementCustomerReferencePackageValidationDAO {
	/**
	 * This operation validates the package.
	 * 
	 * @param packageId - the id of the package to validate
	 * 
	 * @return true if the given package is valid
	 * 
	 * @throws AgreementCustomerReferenceDAOException if the package cannot be validated
	 */
	boolean isPackageIdValid(Integer packageId) throws AgreementCustomerReferenceDAOException;
}