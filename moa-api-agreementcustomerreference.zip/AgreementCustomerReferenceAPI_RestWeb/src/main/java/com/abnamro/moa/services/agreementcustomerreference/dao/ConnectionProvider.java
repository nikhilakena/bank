package com.abnamro.moa.services.agreementcustomerreference.dao;

import java.sql.Connection;

import org.springframework.stereotype.Component;

import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.nl.channels.jndilookup.JndiConstants;
import com.abnamro.nl.channels.jndilookup.JndiLookup;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;

/**
 * Connection provider class for the database connections It is used so that autowiring of Connection is easier for test classes
 */
@Component
public class ConnectionProvider {
	
	private final String dataSourceName;
	
	/**
	 * Default constructor for initializing datasource
	 */
	public ConnectionProvider() {
		dataSourceName = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.DATASOURCE_NAME, AgreementCustomerReferenceDAOConstants.DEFAULT_DATASOURCE);
	}
	
	public Connection getConnection() throws DAODatabaseException{
		return DAODatabaseUtil.openConnection(dataSourceName);
	}

}
