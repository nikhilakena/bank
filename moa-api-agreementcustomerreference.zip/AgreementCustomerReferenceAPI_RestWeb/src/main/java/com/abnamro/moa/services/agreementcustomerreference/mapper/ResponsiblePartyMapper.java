package com.abnamro.moa.services.agreementcustomerreference.mapper;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.abnamro.moa.services.agreementcustomerreference.constants.AgreementCustomerReferenceConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyVersionView;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyView;

/**
 * This is the reponsible party mapper class
 *
 */
@Component
public class ResponsiblePartyMapper {

	/**
	 * This is used to populate ResponsiblePartyVersion database view from input
	 *  
	 * @param agreementCustomerReferenceId unique identifier of the agreementCustomerReference Contract header ID
	 * @param responsiblePartyId BO number from input
	 * @param userId userId/consumerID from input
	 * @return ResponsiblePartyVersion database view
	 */
	public ResponsiblePartyVersionView getPopulatedResponsiblePartyVersionView(String agreementCustomerReferenceId,
			int responsiblePartyId, String userId) {
		
		Date now = new Date();
		ResponsiblePartyVersionView responsiblePartyVersion = new ResponsiblePartyVersionView();
		responsiblePartyVersion.setResponsiblePartyNumber(responsiblePartyId);
		responsiblePartyVersion.setStartDate(new Timestamp(now.getTime()));
		responsiblePartyVersion.setCreationDate(new Timestamp(now.getTime()));
		responsiblePartyVersion.setCreatorName(userId);
		responsiblePartyVersion.setContractHeaderId(agreementCustomerReferenceId);
		
		responsiblePartyVersion.setBankObjectType(AgreementCustomerReferenceConstants.AGREEMENT_ADMINISTRATION_BANK_OBJECT_TYPE);
		responsiblePartyVersion.setStatus("1");
		responsiblePartyVersion.setDcActCode("0");
		responsiblePartyVersion.setEntryId(" ");
		responsiblePartyVersion.setDateAuthorized(new Timestamp(now.getTime()));
		responsiblePartyVersion.setAuthorizorName(userId);
		responsiblePartyVersion.setIssuerName(" ");
		responsiblePartyVersion.setProcessId(" ");
		return responsiblePartyVersion;
	}

	/**
	 * This is used to populate ResponsibleParty database view from input
	 *  
	 * @param agreementCustomerReferenceId unique identifier of the agreementCustomerReference Contract header ID
	 * @param userId userId/consumerID from input
	 * @return ResponsiblePartyn database view
	 */
	public ResponsiblePartyView getPopulatedResponsiblePartyView(String agreementCustomerReferenceId,
			String userId) {
		ResponsiblePartyView responsiblePartyView = new ResponsiblePartyView();
		responsiblePartyView.setContractHeaderId(agreementCustomerReferenceId);
		Date now = new Date();
		responsiblePartyView.setDateCreated(new Timestamp(now.getTime()));
		responsiblePartyView.setCreatorName(userId);
		responsiblePartyView.setType(AgreementCustomerReferenceConstants.AGREEMENT_ADMINISTRATION_TYPE);
		return responsiblePartyView;
	}


}
