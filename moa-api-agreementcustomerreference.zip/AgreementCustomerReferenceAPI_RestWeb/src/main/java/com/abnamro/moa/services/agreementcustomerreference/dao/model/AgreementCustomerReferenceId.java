package com.abnamro.moa.services.agreementcustomerreference.dao.model;

import java.util.regex.Pattern;

import com.abnamro.nl.logging.log4j2.helper.LogHelper;

/**
 * The representation of an id of the agreement customer reference.
 * Its format: 3 characters + 6 digits, e.g. ABC000327
 */
public class AgreementCustomerReferenceId {
	
	private static LogHelper logHelper = new LogHelper(AgreementCustomerReferenceId.class);
	
	private String sequenceText;
	private String sequenceNumber;
	private boolean validFormat;

	/**
	 * Create the id of the agreement customer reference.
	 * @param contractHeaderId - the id of the contract header
	 */
	public AgreementCustomerReferenceId(String contractHeaderId) {
		if (contractHeaderId != null && contractHeaderId.length() == 9) {
			String literalPart = contractHeaderId.substring(0, 3);
			boolean validAlphaFormat = isAlpha(literalPart);

			String numericPart = contractHeaderId.substring(3);
			boolean validNumericFormat = convertTextToNumber(numericPart) != -1;

			if (validAlphaFormat && validNumericFormat) {
				sequenceText = literalPart;
				sequenceNumber = numericPart;
				validFormat = true;
			}
		} else {
			validFormat = false;
		}
	}

	private boolean isAlpha(String s) {
		Pattern p = Pattern.compile("^[A-Z]");
		return p.matcher(s).find();
	}
	
	/**
	 * Return if the input value is the correct format of a contract header id.
	 * @return true if the input is in the expected format
	 */
	public boolean isValidFormat() {
		return validFormat;
	}

	/**
	 * Return the textual part of the given contract header.
	 * For a contract header with id "ABC000327" the text "ABC" will be returned.
	 * @return the textual part of the contract header id
	 */
	public String getLiteralPart() {
		return sequenceText;
	}

	/**
	 * Return the numeric part of the given contract header.
	 * For a contract header with id "ABC000327" the text "000327" will be returned.
	 * @return the numeric part of the contract header id as text with the fixed length
	 */
	public String getNumericPart() {
		return sequenceNumber;
	}

	/**
	 * Assemble the next id for the given contract header id.
	 * @return the next id for the given contract header id
	 */
	public String generateNextId() {
		String nextId = null;

		if (isValidFormat()) {
			if ("999999".equals(sequenceNumber)) {
				nextId = determineNextLiteral(sequenceText) + "000000";
			} else {
				nextId = sequenceText + calculateNextNumber(sequenceNumber);
			}
		}

		return nextId;
	}

	/**
	 * Increase the given literal by one character to the next literal, e.g. for input "ASD" "ASE" will be returned.
	 * @param currentLiteral - the current literal
	 * @return the next literal in line
	 */
	private String determineNextLiteral(String currentLiteral) {
		StringBuilder nextLiteral = new StringBuilder();

		// iterate over the literal, starting at the end, and increase the character
		int index = 2;
		boolean checkPreviousCharacter = true;
		while (checkPreviousCharacter) {
			char currentCharacter = currentLiteral.charAt(index);

			if (currentCharacter == 'Z') {

				// set the current character to 'A', the starting character and increase the previous character
				nextLiteral.insert(0, 'A');

				// increase the previous character if the start is not reached
				index--;
				checkPreviousCharacter = index >= 0;
			} else {

				// increase the current character and copy the remaining character as is
				++currentCharacter;
				char nextCharacter = currentCharacter;
				nextLiteral.insert(0, nextCharacter);
				--index;
				nextLiteral = copyRemainingCharacters(currentLiteral, index, nextLiteral.toString());

				checkPreviousCharacter = false;
			}
		}

 		return nextLiteral.toString();
	}

	/**
	 * Copy the first characters from the given text until the given index before the given end of the text.
	 * @param completeText - the source text to copy the remaining text from
	 * @param startPosition - the start position from where the text must be copied, move to 0
	 * @param endOfText - the text that must be positioned at the end of the text
	 * @return - the assembled text
	 */
	private StringBuilder copyRemainingCharacters(String completeText, int startPosition, String endOfText) {
		StringBuilder text = new StringBuilder(endOfText);

		for (int index = startPosition; index >= 0; index--) {
			text.insert(0, completeText.charAt(index));
		}

		return text;
	}

	/**
	 * Increase the given number by 1 and format it into the text format.
	 * @param currentNumber - textual representation of the current number
	 * @return the textual representation of the next number
	 */
	private String calculateNextNumber(String currentNumberAsText) {
		String nextNumberAssText = null;

		int currentNumber = convertTextToNumber(currentNumberAsText);
		int nextNumber = currentNumber + 1;
		nextNumberAssText = String.format("%06d", nextNumber);

		return nextNumberAssText;
	}

	/**
	 * Convert the given text to a numeric value if possible.
	 * @param text - the text to be converted into a number
	 * @return the numeric value or -1 if the conversion to a number is not possible
	 */
	private int convertTextToNumber(String text) {
		int number = -1;

		try {
			number = Integer.parseInt(text);
		} catch (NumberFormatException exception) {
			logHelper.info("convertTextToNumber", "Exception while validating parent Contract header");
		}

		return number;
	}
}
