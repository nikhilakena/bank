package com.abnamro.moa.services.agreementcustomerreference.daoinvoker;

import java.sql.Connection;
import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.abnamro.moa.services.agreementcustomerreference.constants.AgreementCustomerReferenceConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountView;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;

/**
 * It facilitates calling of dao layer methods
 */
@Component
public class SettlementAccountDAOInvoker {
	
	@Autowired
	private SettlementAccountDAO settlementAccountDao;

	/**
	 * Maps rest resource model to dao layer view and calls the dao layer to create settlement account
	 * 
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId unique Id of the contract header
	 * @param input settlement account Id
	 * @param consumerId user id
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public void createSettlementAccount(Connection connection, String agreementCustomerReferenceId,
			AgreementCustomerReference input, String consumerId) throws AgreementCustomerReferenceDAOException {
		
		String userId = consumerId != null ? consumerId : " ";

		SettlementAccountView view = new SettlementAccountView();

		view.setContractHeaderId(agreementCustomerReferenceId);
	    long time = System.currentTimeMillis();
		view.setDateCreated(new Timestamp(time));
		view.setDateModified(new Timestamp(time));
		view.setId(convertToBBAN(input.getPackageSettlementAccountNumber()));
		view.setUserId(userId);
		settlementAccountDao.createSettlementAccount(connection, view);
		
	}

	/**
	 * Delete the settlement account with the given agreement customer reference.
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId - the agreement customer reference id of the responsible party versions that is to be deleted.
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public void deleteSettlementAccount(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException {
		settlementAccountDao.deleteSettlementAccount(connection, agreementCustomerReferenceId);
	}

	private String convertToBBAN(String agreementId) {
		if(agreementId.length() == AgreementCustomerReferenceConstants.COMMERCIALAGREEMENTID_IBAN_LENGTH
				&& agreementId.startsWith(AgreementCustomerReferenceConstants.COMMERCIALAGREEMENTID_IBAN_PREFIX)){
		
			return agreementId.substring(agreementId.length() - 10);
		} 
		return agreementId;
	}
	
	/**
	 * Maps rest resource model to dao layer view and calls the dao layer to update settlement account
	 * 
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId unique Id of the contract header
	 * @param packageSettlementAccountNumber settlement account Id
	 * @param consumerId user id
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	public void updateSettlementAccount(Connection connection, String agreementCustomerReferenceId,
			String packageSettlementAccountNumber, String consumerId) throws AgreementCustomerReferenceDAOException {
		
		String userId = consumerId != null ? consumerId : " ";

		SettlementAccountView view = new SettlementAccountView();
		view.setContractHeaderId(agreementCustomerReferenceId);
	    long time = System.currentTimeMillis();
		view.setDateModified(new Timestamp(time));
		view.setId(convertToBBAN(packageSettlementAccountNumber));
		view.setUserId(userId);
		settlementAccountDao.updateSettlementAccount(connection, view);
		
	}

}