package com.abnamro.moa.services.agreementcustomerreference.dao.settlement;

import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;

import java.sql.Connection;
import java.util.List;

/**
 * Contains accessor methods to interact with the persistent settlement accounts.
 */
public interface SettlementAccountDAO {
	/**
	 * Persist the given settlement account in the database.
	 * @param connection Connection object which is shared so that transactionality can be maintained
	 * 
	 * @param settlementAccount - the details of the settlement account that is to be created
	 * 
	 * @return the id of the persistent settlement account
	 * 
	 * @throws AgreementCustomerReferenceDAOException if the connection to the persistent storage is not available
	 */
	int createSettlementAccount(Connection connection, SettlementAccountView settlementAccount)
			throws AgreementCustomerReferenceDAOException;

	/**
	 * Retrieve all settlement accounts from the database and return it.
	 * 
	 * @return the list of all persistent settlement accounts
	 */
	List<SettlementAccountView> selectAllSettlementAccounts();

	/**
	 * Delete the settlement account with the given agreement customer reference.
	 * @param connection Connection object that is used so that transactionality can be maintained
	 * @param agreementCustomerReferenceId - the agreement customer reference id of the responsible party versions that is to be deleted.
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	void deleteSettlementAccount(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Retrieve the settlement account number with the given agreement customer reference id and return it.
	 * @param agreementCustomerReferenceId - the id of the agreement customer reference to search for
	 * @return the settlement account number of the settlement account with the id
	 * @throws AgreementCustomerReferenceDAOException is thrown if problems with the database occurr
	 */
	String retrieveSettlementAccountNumber(String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException;
	
	/**
	 * Updates the given settlement account in the database.
	 * @param connection Connection object which is shared so that transactionality can be maintained
	 * @param settlementAccount - the details of the settlement account that is to be created
	 * @throws AgreementCustomerReferenceDAOException if the connection to the persistent storage is not available
	 */
	void updateSettlementAccount(Connection connection, SettlementAccountView settlementAccount)
			throws AgreementCustomerReferenceDAOException;

}
