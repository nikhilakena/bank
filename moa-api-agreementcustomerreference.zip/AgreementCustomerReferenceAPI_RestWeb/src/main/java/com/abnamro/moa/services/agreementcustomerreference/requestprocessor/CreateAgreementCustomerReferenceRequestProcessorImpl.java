package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.exceptions.AgreementCustomerReferenceExternalPublisherException;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.constants.AgreementCustomerReferenceLogConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeViewComparator;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;
import com.abnamro.moa.services.agreementcustomerreference.dao.constants.AgreementCustomerReferenceDAOConstants;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.AgreementCustomerReferenceDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.ResponsiblePartyDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.SettlementAccountDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.mapper.BuildingBlockMapper;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.nl.channels.jndilookup.JndiConstants;
import com.abnamro.nl.channels.jndilookup.JndiLookup;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.dao.util.DAODatabaseUtil;
import com.abnamro.nl.logging.log4j2.helper.LogHelper;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;


/**
 * This is the request processor implementation class for the CreateAgreementCustomerReference operation
 */
@Component
public class CreateAgreementCustomerReferenceRequestProcessorImpl implements CreateAgreementCustomerReferenceRequestProcessor{

	private static LogHelper log = new LogHelper(CreateAgreementCustomerReferenceRequestProcessorImpl.class);
	
	@Autowired
	private AgreementCustomerReferenceValidator agreementCustomerReferenceValidator;

	@Autowired
	private AgreementCustomerReferenceDAOInvoker agreementCustomerReferenceDAOInvoker;
	
	@Autowired
	private SettlementAccountDAOInvoker settlementAccountDAOInvoker;
	
	@Autowired
	private ResponsiblePartyDAOInvoker responsiblePartyDAOInvoker;
	
	@Autowired
	private BuildingBlockDAO buildingBlockDao;
	
	@Autowired
	private BuildingBlockMapper buildingBlockMapper;
	
	@Autowired
	private ConnectionProvider connectionProvider;
	
	@Autowired
	private AgreementCustomerReferenceRequestProcessorUtils processorUtils;
	
	@Autowired
	private PublishAgreementCustomerReferenceHelper publishAgreementCustomerReferenceHelper;
	
	private final String dataSourceName;
	
	/**
	 * This is the default constructor used to initialize data source and Mybatis connection factory
	 */
	public CreateAgreementCustomerReferenceRequestProcessorImpl(){
		dataSourceName = new JndiLookup(JndiConstants.SYSMGMT_CONTEXT).getString(AgreementCustomerReferenceDAOConstants.DATASOURCE_NAME, AgreementCustomerReferenceDAOConstants.DEFAULT_DATASOURCE);
	}
	
	/**
	 * It returns data source name to be used by the DAO.
	 * 
	 * @return the data source name to be used by the DAO.
	 */
	protected String getDataSourceName() {
		return dataSourceName;
	}
	
	
	@Override
	public String processCreateAgreementCustomerReferenceRequest(AgreementCustomerReference createRequestInput, String consumerId) throws AgreementCustomerReferenceApplicationException {
		final String logMethod = "processCreateAgreementCustomerReferenceRequest(AgreementCustomerReference, String):String";
		String agreementCustomerReferenceId = null;
		Connection connection = null;
		
		try {
			
			//retrieving the responsible party details of the customer
			RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = processorUtils.getCustomerDetails(createRequestInput.getCustomerId());
			
			//validating the life cycle status of the customer
			agreementCustomerReferenceValidator.isCustomerExists(retrievePartyDetailsResponseTO);
			
			//retrieving the building block details
			List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(createRequestInput.getProductId()));
			
			//validate Building Block Details by checking if only building blocks linked to product are present in input
			agreementCustomerReferenceValidator.validateBuildingBlockDetails(buildingBlockClusterTypeViewList,createRequestInput.getAgreementAdministrationReferences());
			
			connection = connectionProvider.getConnection();
			connection.setAutoCommit(false);
			
			createRequestInput.setCommercialAgreementId(createRequestInput.getCommercialAgreementId());
			
			//inserting record into Contract Header table
			agreementCustomerReferenceId = createAgreementCustomerReference(connection,createRequestInput, consumerId);

			//inserting responsible party details
			createResponsibleParty(connection,agreementCustomerReferenceId, createRequestInput, retrievePartyDetailsResponseTO, consumerId);
			
			//inserting building block details
			createBuildingBlock(connection,agreementCustomerReferenceId, createRequestInput, buildingBlockClusterTypeViewList);
			
			//inserting settlement account details
			createSettlementAccount(connection,agreementCustomerReferenceId, createRequestInput,consumerId);
			
			//publish MO create event to other systems by calling MO856 transaction
			publishAgreementCustomerReferenceHelper.publishCreateAgreementCustomerReference(agreementCustomerReferenceId, createRequestInput,buildingBlockClusterTypeViewList,consumerId);
			
			connection.commit();
			
		} catch (DAODatabaseException exception) {
			 log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_DAO_EXCEPTION_CREATEAGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
			 throw new AgreementCustomerReferenceApplicationException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (SQLException exception) {
			log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_SQL_EXCEPTION_CREATEAGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
			 throw new AgreementCustomerReferenceApplicationException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} catch (AgreementCustomerReferenceDAOException exception) {
			log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_AGREEMENT_CUSTOMER_REFERENCE_EXCEPTION_IN_CREATEAGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
			throw new AgreementCustomerReferenceApplicationException(exception.getMessage(),exception.getStatus());
		} catch (AgreementCustomerReferenceExternalPublisherException exception) {
			log.error(logMethod, AgreementCustomerReferenceLogConstants.LOG_IMS_PUBLISH_EXCEPTION_IN_CREATEAGREEMENTCUSTOMERREF_IN_PROCESSOR, exception);
			throw new AgreementCustomerReferenceApplicationException(AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR,AgreementCustomerReferenceDAOConstants.INTERNAL_SERVER_ERRROR_HTTP_STATUS);
		} finally {
		      DAODatabaseUtil.closeConnection(connection);
		}
		
		return agreementCustomerReferenceId;
		
	}


	@Override
	public String createAgreementCustomerReference(Connection connection, AgreementCustomerReference agreementCustomerReference, String consumerId) throws AgreementCustomerReferenceDAOException {
		return agreementCustomerReferenceDAOInvoker.createAgreementCustomerReference(connection, agreementCustomerReference, consumerId);
	}

	@Override
	public void createSettlementAccount(Connection connection, String agreementCustomerReferenceId,
			AgreementCustomerReference input, String consumerId)
			throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {

		if (input.getPackageSettlementAccountNumber() != null && !input.getPackageSettlementAccountNumber().isEmpty()) {
			
			settlementAccountDAOInvoker.createSettlementAccount(connection,agreementCustomerReferenceId,input,consumerId);
			
		}

	}

	@Override
	public void createResponsibleParty(Connection connection, String agreementCustomerReferenceId, AgreementCustomerReference input,
			RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO, String consumerId) throws AgreementCustomerReferenceDAOException {
		
		
		int responsiblePartyId = responsiblePartyDAOInvoker.createResponsibleParty(connection, agreementCustomerReferenceId, consumerId);
		
		String organizationId = input.getOrganisationUnitId() != null ? input.getOrganisationUnitId()
				: processorUtils.getCustomerBO(retrievePartyDetailsResponseTO);
		
		responsiblePartyDAOInvoker.createResponsiblePartyVersion(connection, agreementCustomerReferenceId, responsiblePartyId, organizationId, consumerId);

	}
	
	@Override
	public void createBuildingBlock(Connection connection, String agreementCustomerReferenceId, AgreementCustomerReference agreementCustomerReference, List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList) throws AgreementCustomerReferenceDAOException {

		Collections.sort(buildingBlockClusterTypeViewList, new BuildingBlockClusterTypeViewComparator());
		
		List<BuildingBlockView> buildingBlockViewList = buildingBlockMapper.getPopulatedBuildingBlockViewList(agreementCustomerReference.getAgreementAdministrationReferences(),buildingBlockClusterTypeViewList,agreementCustomerReferenceId);
		
		for(BuildingBlockView buildingBlockView :buildingBlockViewList) {
			buildingBlockDao.insertBuildingBlockRef(connection,buildingBlockView);
		}
	}
}
