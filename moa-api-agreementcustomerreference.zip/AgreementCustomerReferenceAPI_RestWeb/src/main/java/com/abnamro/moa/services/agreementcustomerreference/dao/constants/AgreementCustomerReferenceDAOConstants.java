package com.abnamro.moa.services.agreementcustomerreference.dao.constants;

/**
 * This class contains constants to access the database.
 */
public final class AgreementCustomerReferenceDAOConstants {
	private AgreementCustomerReferenceDAOConstants() {}

	/**
	 * The schema name of the database to be used.
	 */
	public static final String SCHEMA_DATABASE = "SCHEMA_MOA";

	/**
	 * The default schema name of the database.
	 */
	public static final String DEFAULT_DB_SCHEMA = "UU01";

	/**
	 * The name of the data source.
	 */
	public static final String DATASOURCE_NAME = "MOADATASOURCE";

	/**
	 * The default name of the data source.
	 */
	public static final String DEFAULT_DATASOURCE = "jdbc/MOA_DataSource";	
	
	
	public static final String INTERNAL_SERVER_ERRROR = "500";
	
	public static final int INTERNAL_SERVER_ERRROR_HTTP_STATUS = 500;
	
	public static final int BAD_REQUEST_HTTP_STATUS = 400;

	public static final int RESOURCE_NOT_FOUND_HTTP_STATUS = 404;
	
	
}
