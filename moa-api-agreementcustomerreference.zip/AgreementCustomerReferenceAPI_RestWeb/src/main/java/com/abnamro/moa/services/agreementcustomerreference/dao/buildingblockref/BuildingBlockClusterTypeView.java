package com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref;

/**
 * This is database view class which will be used to get details of the building block from database
 *
 */
public class BuildingBlockClusterTypeView {
	
	private int clusterId;
	private int buildingBlockId;
	private int productId;
	private String buildingBlockType;
	
	public int getClusterId() {
		return clusterId;
	}
	public void setClusterId(int clusterId) {
		this.clusterId = clusterId;
	}
	public int getBuildingBlockId() {
		return buildingBlockId;
	}
	public void setBuildingBlockId(int buildingBlockId) {
		this.buildingBlockId = buildingBlockId;
	}
	public String getBuildingBlockType() {
		return buildingBlockType;
	}
	public void setBuildingBlockType(String buildingBlockType) {
		this.buildingBlockType = buildingBlockType;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	
}
