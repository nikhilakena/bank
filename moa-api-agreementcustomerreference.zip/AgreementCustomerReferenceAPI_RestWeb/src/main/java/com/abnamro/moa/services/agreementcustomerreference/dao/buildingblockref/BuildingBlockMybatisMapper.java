package com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref;

import java.util.List;

import org.apache.ibatis.annotations.Param;

/**
 * Contains methods to map persistent building blocks to pojos through my batis.
 */
public interface BuildingBlockMybatisMapper {
	/**
	 * Method to call the query in the my batis configuration to the building block persistent.
	 * 
	 * @param schemaName - the schema name of the peristent building block
	 * @param buildingBlock - the building block to be persisted
	 */
	public void insertBuildingBlockRef(
			@Param("schemaName") String schemaName
			, @Param("buildingBlock") BuildingBlockView buildingBlock);
	
	/**
	 * Method to get the cluster if from input product id
	 * 
	 * @param schemaName the schema name of the database
	 * @param productId to get ClusterId
	 * @return building block details containing Id, type and cluster ID
	 */
	public List<BuildingBlockClusterTypeView> getBuildingBlockDetailsForProduct(@Param("schemaName") String schemaName, @Param("productId") Integer productId);

	/**
	 * This method is used to get count of records for input buildingBlockId and buildingBlockReferenceContractId
	 * 
	 * @param schemaName the schema name of the database
	 * @param buildingBlockId unique id of the building block
	 * @param buildingBlockReferenceContractId agreement id in the backend administrations
	 * @return no of records in database
	 */
	public int getCountOfBuildingBlockReference(@Param("schemaName") String schemaName,@Param("buildingBlockId")  int buildingBlockId,
			@Param("buildingBlockReferenceContractId") String buildingBlockReferenceContractId);

	/**
	 * Method is used to delete BuildingBlockReferences for input agreementCustomerReferenceId
	 * 
	 * @param dbSchemaPrefix the schema name of the database
	 * @param agreementCustomerReferenceId unique identifier of the contract header
	 */
	public void deleteBuildingBlockReferences(@Param("schemaName") String dbSchemaPrefix, @Param("agreementCustomerReferenceId") String agreementCustomerReferenceId);

	/**
	 * This method is used to get agreementCustomerReferenceId for the input buildingBlockReference
	 * 
	 * @param dbSchemaPrefix the schema name of the database
	 * @param buildingBlockId unique id of the building block
	 * @param buildingBlockReferenceContractId agreement id in the backend administrations
	 * @return agreementCustomerReferenceId unique identifier of the contract header
	 */
	public String getAgreementCustomerReference(@Param("schemaName") String dbSchemaPrefix, @Param("buildingBlockId") Integer buildingBlockId,
			@Param("buildingBlockReferenceContractId") String buildingBlockReferenceContractId);
}