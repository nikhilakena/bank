package com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation;

import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;

import java.util.List;

/**
 * Methods to validate the product by interacting with the persistent storage.
 */
public interface AgreementCustomerReferenceProductValidationDAO {
	/**
	 * This operation validates the product.
	 * 
	 * @param productId - the id of the persistent product to be validated
	 * 
	 * @return true if the given product is considered valid
	 * 
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	boolean isProductIdValid(Integer productId) throws AgreementCustomerReferenceDAOException;
	
	/**
	 * This operation is used to get the product type from the database.
	 * 
	 * @param productId unique id of the product
	 * @return product type
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	String getProductType(Integer productId) throws AgreementCustomerReferenceDAOException;

	/**
	 * Return the product group ids that are part of the given product.
	 * @param productId - the id of the product to return its product group ids for
	 * @return the list of product group ids
	 * @throws AgreementCustomerReferenceDAOException in case of error
	 */
	List<Integer> retrieveProductGroupIdsForProduct(int productId) throws AgreementCustomerReferenceDAOException;
}
