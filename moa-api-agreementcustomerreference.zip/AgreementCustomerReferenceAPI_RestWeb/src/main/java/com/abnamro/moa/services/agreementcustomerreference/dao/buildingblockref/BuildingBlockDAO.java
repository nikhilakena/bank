package com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref;

import java.sql.Connection;
import java.util.List;

import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;

/**
 * Contains methods to access persistent building blocks.
 */
public interface BuildingBlockDAO {
	
	/**
	 * Create the given building block into the database.
	 * 
	 * @param connection Connection object which is shared so that transactionality can be maintained
	 * @param buildingBlock the details of the new persistent building block
	 * @throws AgreementCustomerReferenceDAOException thrown if access to persistent storage cannot be obtained
	 */
	void insertBuildingBlockRef(Connection connection, BuildingBlockView buildingBlock) throws AgreementCustomerReferenceDAOException;

	/**
	 * This operation is used to retrieve the building block details from database
	 * 
	 * @param productId unique identifier for the product 
	 * @return building block details containing Id, type and cluster ID
	 * @throws AgreementCustomerReferenceDAOException in case of errors
	 */
	List<BuildingBlockClusterTypeView> getBuildingBlockDetailsForProduct(Integer productId) throws AgreementCustomerReferenceDAOException;
	
	/**
	 * This method will return true if BuildingBlockReference is present in database otherwise false is returned 
	 * 
	 * @param buildingBlockId unique id of the building block
	 * @param buildingBlockReferenceContractId agreement id in the backend administrations
	 * @return true if BuildingBlockReference is present otherwise false
	 * @throws AgreementCustomerReferenceDAOException in case of errors
	 */
	boolean isBuildingBlockReferencePresent(int buildingBlockId, String buildingBlockReferenceContractId) throws AgreementCustomerReferenceDAOException;

	/**
	 * It deleted all BuildingBlockReferences for input contract header Id
	 * @param connection Connection object which is shared so that transactionality can be maintained
	 * @param agreementCustomerReferenceId unique Identifier for contract header 
	 * @throws AgreementCustomerReferenceDAOException in case of errors
	 */
	void deleteBuildingBlockReferences(Connection connection, String agreementCustomerReferenceId) throws AgreementCustomerReferenceDAOException;

	/**
	 * It retrieves AgreementCustomerReference for input BuildingBlockReference
	 * 
	 * @param agreementAdministrationId unique id of the building block
	 * @param agreementAdministrationReferenceId agreement id in the backend administrations
	 * @return AgreementCustomerReferenceID unique Identifier for contract header 
	 * @throws AgreementCustomerReferenceDAOException in case of errors
	 */
	String getAgreementCustomerReferenceForBuildingBlockReference(Integer agreementAdministrationId,
			String agreementAdministrationReferenceId) throws AgreementCustomerReferenceDAOException;

}