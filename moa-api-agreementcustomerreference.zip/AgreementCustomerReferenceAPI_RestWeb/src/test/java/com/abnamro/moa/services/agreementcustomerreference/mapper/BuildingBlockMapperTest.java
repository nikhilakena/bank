package com.abnamro.moa.services.agreementcustomerreference.mapper;

import org.junit.jupiter.api.Assertions;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;

public class BuildingBlockMapperTest {

	
	BuildingBlockMapper buildingBlockMapper = new BuildingBlockMapper();
	
	@Test
	public void getPopulatedBuildingBlockViewListSingleBBTest() {
		
		String agreementCustomerReferenceId = "123";
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView.setBuildingBlockId(123);
		buildingBlockClusterTypeView.setBuildingBlockType("C");
		buildingBlockClusterTypeView.setProductId(1234);
		buildingBlockClusterTypeView.setClusterId(1234);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView);

		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("123");
		agreementAdministrationReference.setAgreementAdministrationReferenceId("AB1234");
		agreementAdministrationReferences.add(agreementAdministrationReference);
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		agreementCustomerReference.setProductId("1234");
		
		List<BuildingBlockView> bbview = buildingBlockMapper.getPopulatedBuildingBlockViewList(agreementAdministrationReferences, buildingBlockClusterTypeViewList, agreementCustomerReferenceId);
		
		int bbvalue = 0;
		for(BuildingBlockView bb :bbview) {
			bbvalue = bb.getBuildingBlockId();
		}
		Assertions.assertEquals(123, bbvalue);
		
	}
	
	@Test
	public void getPopulatedBuildingBlockViewListMultipleBBTest() {
		
		String agreementCustomerReferenceId = "123";
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView.setBuildingBlockId(123);
		buildingBlockClusterTypeView.setBuildingBlockType("C");
		buildingBlockClusterTypeView.setClusterId(1234);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView);
		BuildingBlockClusterTypeView buildingBlockClusterTypeView1 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView1.setBuildingBlockId(1234);
		buildingBlockClusterTypeView1.setBuildingBlockType("F");
		buildingBlockClusterTypeView1.setClusterId(12345);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView1);
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("123");
		agreementAdministrationReference.setAgreementAdministrationReferenceId("AB1234");
		agreementAdministrationReferences.add(agreementAdministrationReference);
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		agreementCustomerReference.setProductId("1234");
		
		List<BuildingBlockView> bbview = buildingBlockMapper.getPopulatedBuildingBlockViewList(agreementAdministrationReferences, buildingBlockClusterTypeViewList, agreementCustomerReferenceId);
		
		String bbConvalue = "";
		for(BuildingBlockView bb :bbview) {
			if(bb.getBuildingBlockId()==1234) {
				bbConvalue = "AB1234";
			}
		}
		Assertions.assertEquals("AB1234",bbConvalue);
	}
	
	@Test
	public void getPopulatedBuildingBlockViewListMultipleBBTest2() {
		
		String agreementCustomerReferenceId = "123";
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView.setBuildingBlockId(1234);
		buildingBlockClusterTypeView.setBuildingBlockType("C");
		buildingBlockClusterTypeView.setClusterId(1234);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView);
		BuildingBlockClusterTypeView buildingBlockClusterTypeView1 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView1.setBuildingBlockId(1235);
		buildingBlockClusterTypeView1.setBuildingBlockType("C");
		buildingBlockClusterTypeView1.setClusterId(12345);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView1);
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("123");
		agreementAdministrationReference.setAgreementAdministrationReferenceId("AB1234");
		agreementAdministrationReferences.add(agreementAdministrationReference);
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		agreementCustomerReference.setProductId("1234");
		
		List<BuildingBlockView> bbview = buildingBlockMapper.getPopulatedBuildingBlockViewList(agreementAdministrationReferences, buildingBlockClusterTypeViewList, agreementCustomerReferenceId);
		
		int bbvalue = 0;
		for(BuildingBlockView bb :bbview) {
			bbvalue += 1;
		}
		Assertions.assertEquals(0, bbvalue);
	}
	
	@Test
	public void getPopulatedBuildingBlockViewListMultipleBBTest3() {
		
		String agreementCustomerReferenceId = "123";
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView.setBuildingBlockId(123);
		buildingBlockClusterTypeView.setBuildingBlockType("C");
		buildingBlockClusterTypeView.setClusterId(1234);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView);
		BuildingBlockClusterTypeView buildingBlockClusterTypeView1 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView1.setBuildingBlockId(1235);
		buildingBlockClusterTypeView1.setBuildingBlockType("C");
		buildingBlockClusterTypeView1.setClusterId(12345);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView1);
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("123");
		agreementAdministrationReference.setAgreementAdministrationReferenceId("AB1234");
		agreementAdministrationReferences.add(agreementAdministrationReference);
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		agreementCustomerReference.setProductId("1234");
		
		List<BuildingBlockView> bbview = buildingBlockMapper.getPopulatedBuildingBlockViewList(agreementAdministrationReferences, buildingBlockClusterTypeViewList, agreementCustomerReferenceId);
		
		int bbvalue = 0;
		for(BuildingBlockView bb :bbview) {
			bbvalue = bb.getBuildingBlockId();
		}
		Assertions.assertEquals(123, bbvalue);
	}
	
	@Test
	public void getPopulatedBuildingBlockViewListMultipleBBTest4() {
		
		String agreementCustomerReferenceId = "123";
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView.setBuildingBlockId(123);
		buildingBlockClusterTypeView.setBuildingBlockType("C");
		buildingBlockClusterTypeView.setClusterId(1234);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView);
		BuildingBlockClusterTypeView buildingBlockClusterTypeView1 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView1.setBuildingBlockId(1235);
		buildingBlockClusterTypeView1.setBuildingBlockType("C");
		buildingBlockClusterTypeView1.setClusterId(12345);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView1);
		BuildingBlockClusterTypeView buildingBlockClusterTypeView2 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView2.setBuildingBlockId(1236);
		buildingBlockClusterTypeView2.setBuildingBlockType("F");
		buildingBlockClusterTypeView2.setClusterId(123456);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView2);
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("123");
		agreementAdministrationReference.setAgreementAdministrationReferenceId("AB1234");
		agreementAdministrationReferences.add(agreementAdministrationReference);
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		agreementCustomerReference.setProductId("1234");
		
		List<BuildingBlockView> bbview = buildingBlockMapper.getPopulatedBuildingBlockViewList(agreementAdministrationReferences, buildingBlockClusterTypeViewList, agreementCustomerReferenceId);
		
		int bbvalue = 0;
		for(BuildingBlockView bb :bbview) {
			bbvalue += 1;
		}
		Assertions.assertEquals(2, bbvalue);
		
		String bbConvalue = "";
		for(BuildingBlockView bb :bbview) {
			if(bb.getBuildingBlockId()==1236) {
				bbConvalue = "AB1234";
			}
		}
		Assertions.assertEquals("AB1234",bbConvalue);
	}
}
