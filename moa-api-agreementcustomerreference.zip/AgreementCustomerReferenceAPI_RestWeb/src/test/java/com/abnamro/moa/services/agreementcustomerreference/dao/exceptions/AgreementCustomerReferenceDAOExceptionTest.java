package com.abnamro.moa.services.agreementcustomerreference.dao.exceptions;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

class AgreementCustomerReferenceDAOExceptionTest {
    @Test
    void createExceptionStatus() {
        AgreementCustomerReferenceDAOException exception = new AgreementCustomerReferenceDAOException(HttpStatus.OK);

        Assertions.assertNotNull(exception);
        Assertions.assertEquals(HttpStatus.OK, exception.getStatus());
        Assertions.assertNotNull(exception.getParams());
        Assertions.assertEquals(0, exception.getParams().size());
        Assertions.assertNull(exception.getMessage());
    }

    @Test
    void createExceptionMessageCauseStatus() {
        String message = "exception message";
        Throwable throwable = new Throwable("throwable message");
        AgreementCustomerReferenceDAOException exception = new AgreementCustomerReferenceDAOException(message, throwable, HttpStatus.OK);

        Assertions.assertNotNull(exception);
        Assertions.assertEquals(HttpStatus.OK, exception.getStatus());
        Assertions.assertNotNull(exception.getParams());
        Assertions.assertEquals(0, exception.getParams().size());
        Assertions.assertNotNull(exception.getMessage());
        Assertions.assertEquals("exception message", exception.getMessage());
    }

    @Test
    void createExceptionMessageStatus() {
        String message = "exception message";
        AgreementCustomerReferenceDAOException exception = new AgreementCustomerReferenceDAOException(message, HttpStatus.OK);

        Assertions.assertNotNull(exception);
        Assertions.assertEquals(HttpStatus.OK, exception.getStatus());
        Assertions.assertNotNull(exception.getParams());
        Assertions.assertEquals(0, exception.getParams().size());
        Assertions.assertNotNull(exception.getMessage());
        Assertions.assertEquals("exception message", exception.getMessage());
    }

    @Test
    void createExceptionMessageStatusParams() {
        String message = "exception message";
        List<String> parameters = new ArrayList<>();
        parameters.add("parameter 1");
        parameters.add("parameter 2");
        AgreementCustomerReferenceDAOException exception = new AgreementCustomerReferenceDAOException(message, HttpStatus.OK, parameters);

        Assertions.assertNotNull(exception);
        Assertions.assertEquals(HttpStatus.OK, exception.getStatus());
        Assertions.assertNotNull(exception.getParams());
        Assertions.assertEquals(2, exception.getParams().size());
        Assertions.assertEquals("parameter 1", exception.getParams().get(0));
        Assertions.assertEquals("parameter 2", exception.getParams().get(1));
        Assertions.assertNotNull(exception.getMessage());
        Assertions.assertEquals("exception message", exception.getMessage());
    }
}
