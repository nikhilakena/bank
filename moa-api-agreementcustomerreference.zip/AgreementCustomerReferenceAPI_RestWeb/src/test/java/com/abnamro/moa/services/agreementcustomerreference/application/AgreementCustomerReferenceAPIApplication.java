package com.abnamro.moa.services.agreementcustomerreference.application;

//import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.boot.builder.SpringApplicationBuilder;
//import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.web.context.WebApplicationContext;
import com.abnamro.moa.services.agreementcustomerreference.configuration.RequestScopeBeans;

/**
 *
 * This is the application class for the Agreement Customer Reference API. 
 * It extends SpringBootServletInitializer so application runs as SpringApplication from a traditional WAR archive deployed on a web container. 
 * This class binds Servlet, Filter and ServletContextInitializer beans from the application context to the server.
 * 
 */

@Configuration
//@SpringBootApplication
@ComponentScan(basePackages = { "com.abnamro.moa.services.*", "com.abnamro.moa.generic.*",
		"com.abnamro.nl.partymanagementconnect.*", "com.abnamro.moa.generic.agreementcustomerreference.publisher.*"
		})
public class AgreementCustomerReferenceAPIApplication /* extends SpringBootServletInitializer */ {
	
//	@Override
//    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
//		 return application.sources(AgreementCustomerReferenceAPIApplication.class);
//    }
	
	/**
	 * This method is used to register RequestScopeBeans
	 * 
	 * @return Request Scope Beans object 
	 */
	@Bean
	@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
	public RequestScopeBeans requestScopedBean() {
	    return new RequestScopeBeans();
	}
}
