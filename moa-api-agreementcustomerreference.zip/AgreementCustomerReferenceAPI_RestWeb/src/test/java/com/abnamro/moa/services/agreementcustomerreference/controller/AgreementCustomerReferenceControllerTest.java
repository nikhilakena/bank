package com.abnamro.moa.services.agreementcustomerreference.controller;

import org.easymock.Mock;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation.AgreementCustomerReferencePackageValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.requestprocessor.CreateAgreementCustomerReferenceRequestProcessor;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.ResponseForPostAgreementCustomerReference;

@ExtendWith(MockitoExtension.class)
//@ExtendWith(SpringExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ContextConfiguration
public class AgreementCustomerReferenceControllerTest {

//	//	@MockBean
	@Mock
	private AgreementCustomerReferenceValidator validator;

//	@Autowired
	@Mock
	private AgreementCustomerReferenceController agreementCustomerReferenceController;

	//	//	@MockBean
	@Mock
	private CreateAgreementCustomerReferenceRequestProcessor createRequestProcessor;

	//	//	@MockBean
	@Mock
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDao;

	//	//	@MockBean
	@Mock
	private AgreementCustomerReferenceProductValidationDAO productValidationDao;

	//	//	@MockBean
	@Mock
	private SettlementAccountDAO settlementAccountDao;

	//	//	@MockBean
	@Mock
	private ResponsiblePartyDAO responsiblePartyDao;

	//	//	@MockBean
	@Mock
	private BuildingBlockDAO buildingBlockDao;

	//	//	@MockBean
	@Mock
	private AgreementCustomerReferencePackageValidationDAO agreementCustomerReferencePackageValidationDao;

	//	//	@MockBean
	@Mock
	private AgreementCustomerReferenceExternalPublisher agreementCustomerReferencePublisher;
	
	@Test
	public void addAgreementCustomerReferenceMissingConsumerId() throws AgreementCustomerReferenceApplicationException {
		ResponseForPostAgreementCustomerReference expectedResponse = new ResponseForPostAgreementCustomerReference();
		expectedResponse.setAgreementCustomerReferenceId("aaa123456");

		AgreementCustomerReference createRequestInput = new AgreementCustomerReference();

		agreementCustomerReferenceController = Mockito.mock(AgreementCustomerReferenceController.class);
		Mockito.doReturn(new ResponseEntity<ResponseForPostAgreementCustomerReference>(expectedResponse, HttpStatus.CREATED)).when(agreementCustomerReferenceController).addAgreementCustomerReference("abc001", "T001", createRequestInput);

//		Mockito.when(createRequestProcessor.processCreateAgreementCustomerReferenceRequest(createRequestInput, "abc001")).thenReturn("aaa123456");
		ResponseEntity<ResponseForPostAgreementCustomerReference> response = agreementCustomerReferenceController.addAgreementCustomerReference("abc001", "T001", createRequestInput);
		Assertions.assertEquals("aaa123456", response.getBody().getAgreementCustomerReferenceId());
	}
}
