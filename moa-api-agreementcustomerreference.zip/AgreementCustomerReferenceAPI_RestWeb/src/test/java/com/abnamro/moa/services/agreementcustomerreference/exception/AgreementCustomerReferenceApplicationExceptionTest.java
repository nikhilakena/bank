package com.abnamro.moa.services.agreementcustomerreference.exception;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

class AgreementCustomerReferenceApplicationExceptionTest {
    @Test
    void createHttpStatus() {
        AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException(HttpStatus.BAD_REQUEST);
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        Assertions.assertNotNull(exception.getParams());
        Assertions.assertTrue(exception.getParams().isEmpty());
        Assertions.assertNull(exception.getMessage());
    }

    @Test
    void createMessageCauseHttpStatus() {
        AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("message1", null, HttpStatus.OK);
        Assertions.assertEquals(HttpStatus.OK, exception.getStatus());
        Assertions.assertEquals("message1", exception.getMessage());
        Assertions.assertNull(exception.getCause());
    }

    @Test
    void createMessageStatus() {
        AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("message1", HttpStatus.OK);
        Assertions.assertEquals(HttpStatus.OK, exception.getStatus());
        Assertions.assertEquals("message1", exception.getMessage());
        Assertions.assertNull(exception.getCause());
    }
}
