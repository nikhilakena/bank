package com.abnamro.moa.services.agreementcustomerreference.validator;

import java.util.ArrayList;
import java.util.List;

import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidatorImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation.AgreementCustomerReferencePackageValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.nl.commondt.v3.ReferenceContext;
import com.abnamro.nl.partymanagementobjects.v4.Party;
import com.abnamro.nl.partymanagementobjects.v4.PartyDetails;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;

import javax.inject.Inject;

//@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ContextConfiguration
public class AgreementCustomerReferenceValidatorTest {

//	//	@MockBean
	@Mock
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDao;

	//	//	@MockBean
	@Mock
	private AgreementCustomerReferenceProductValidationDAO productValidationDao;

	//	//	@MockBean
	@Mock
	private AgreementCustomerReferencePackageValidationDAO agreementCustomerReferencePackageValidationDao;

	//	//	@MockBean
	@Mock
	private SettlementAccountDAO settlementAccountDao;

	//	//	@MockBean
	@Mock
	private ResponsiblePartyDAO responsiblePartyDao;

	//	//	@MockBean
	@Mock
	private BuildingBlockDAO buildingBlockDao;

//	@Autowired
//	@Inject
	@InjectMocks
	private AgreementCustomerReferenceValidator validator = new AgreementCustomerReferenceValidatorImpl();
//	private AgreementCustomerReferenceValidator validator = new AgreementCustomerReferenceValidatorImpl();

	//	//	@MockBean
	@Mock
	private AgreementCustomerReferenceExternalPublisher agreementCustomerReferencePublisher;

	@Test
	public void validatePackageSuccessTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
		agreementCustomerReference.setPackageSettlementAccountNumber("NL17ABNA0123456907");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1335003106");
		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(true);
		Mockito.when(buildingBlockDao.isBuildingBlockReferencePresent(5, "0123456907")).thenReturn(true);
		List<Integer> productGroupIds = new ArrayList<>();
		productGroupIds.add(77);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(437)).thenReturn(productGroupIds);

		validator.validatePackage(agreementCustomerReference);
	}
	
	@Test
	public void validatePackageProductIdNullFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn(null);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4006", e.getMessage());
		}
	}

	@Test
	public void validatePackageProductIdNullFailureTest1() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn(null);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4006", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4006", e.getMessage());
		}
	}

	@Test
	public void validatePackageSettlementAccountIdEmptyFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
		agreementCustomerReference.setPackageSettlementAccountNumber("");
		List<AgreementAdministrationReference> agreementAdministrations = new ArrayList<>();
		AgreementAdministrationReference agreementAdministration1 = new AgreementAdministrationReference();
		agreementAdministration1.setAgreementAdministrationId("3");
		agreementAdministration1.setAgreementAdministrationReferenceId("678567");
		agreementAdministrations.add(agreementAdministration1);
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrations);

		try {
			validator.validatePackage(agreementCustomerReference);
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.fail("no exception expected");
			throw e;
		}
	}

	@Test
	public void validatePackageSettlementAccountIdEmptySuccessTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		List<AgreementAdministrationReference> agreementAdministrations = new ArrayList<>();
		AgreementAdministrationReference agreementAdministration1 = new AgreementAdministrationReference();
		agreementAdministration1.setAgreementAdministrationId("5");
		agreementAdministration1.setAgreementAdministrationReferenceId("123321");
		agreementAdministrations.add(agreementAdministration1);
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrations);
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
//		Mockito.when(buildingBlockDao.isBuildingBlockReferencePresent(5, "")).thenReturn(true);
		agreementCustomerReference.setPackageSettlementAccountNumber("");
		try {
			validator.validatePackage(agreementCustomerReference);
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.fail("no exception expected");
		}
	}

	@Test
	public void validatePackageParentAgreementCustomerReferenceIdEmptyFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
		agreementCustomerReference.setPackageSettlementAccountNumber("NL17ABNA0123456907");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1234");
		List<Integer> productGroups = new ArrayList<>();
		productGroups.add(77);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(437)).thenReturn(productGroups);
//		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(true);
		Mockito.when(buildingBlockDao.isBuildingBlockReferencePresent(5, "0123456907")).thenReturn(true);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4007", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4007", e.getMessage());
		}
	
	}
	
	@Test
	public void validatePackageParentAgreementCustomerReferenceIdNotExistFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
		agreementCustomerReference.setPackageSettlementAccountNumber("NL17ABNA0123456907");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1335003106");
		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(false);
		Mockito.when(buildingBlockDao.isBuildingBlockReferencePresent(5, "0123456907")).thenReturn(true);
		List<Integer> productGroups = new ArrayList<>();
		productGroups.add(86);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(437)).thenReturn(productGroups);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4007", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4007", e.getMessage());
		}
	}
	
	@Test
	public void validateSettlementAccountFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {

		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
		agreementCustomerReference.setPackageSettlementAccountNumber("NL21ABNA0123456907");
		List<Integer> productGroups = new ArrayList<>();
		productGroups.add(86);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(437)).thenReturn(productGroups);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4013", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4013", e.getMessage());
		}
	}
	
	@Test
	public void validateBasicProductSuccessTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("");
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("1234");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setCommercialAgreementId("12345");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1335003106");
		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(true);
		
		validator.validatePackage(agreementCustomerReference);
	}
	
	@Test
	public void validateBasicProductAgreementAdministrationReferencesNullFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("");
		agreementCustomerReference.setAgreementAdministrationReferences(null);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4008", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4008");
		}

	}
	
	@Test
	public void validateBasicProductAgreementAdministrationReferencesEmptyFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("");
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4008", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4008", e.getMessage());
		}

	}
	
	@Test
	public void validateBasicProductCommercialAgreementIdBlankFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("");
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("1234");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setCommercialAgreementId("");

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4017", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4017", e.getMessage());
		}

	}
	
	@Test
	public void validateBasicProductParentAgreementCustomerReferenceIdEmptyFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("");
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("1234");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setCommercialAgreementId("12345");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("12345");
//		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(true);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4007", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4007", e.getMessage());
		}
	}
	
	@Test
	public void validateBasicProductParentAgreementCustomerReferenceIdNotExistFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId("437");
		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("");
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("1234");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setCommercialAgreementId("12345");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1335003106");
		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(false);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4007", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4007", e.getMessage());
		}
	}

	@Test
	public void validateSettlementAccountForPaymentPackage77() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		Integer productId = 707;
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId(productId.toString());
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("1234");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setCommercialAgreementId("12345");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1335003106");

		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
//		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(true);

		List<Integer> productGroupIds = new ArrayList<>();
		productGroupIds.add(77);
		productGroupIds.add(78);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(productId)).thenReturn(productGroupIds);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4027", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("excepted exception");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4027", e.getMessage());
		}
	}

	@Test
	public void validateSettlementAccountForPaymentPackage86() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		Integer productId = 806;
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId(productId.toString());
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("1234");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setCommercialAgreementId("12345");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1335003106");

		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
//		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(true);

		List<Integer> productGroupIds = new ArrayList<>();
		productGroupIds.add(85);
		productGroupIds.add(86);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(productId)).thenReturn(productGroupIds);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4027", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("excepted exception");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4027", e.getMessage());
		}
	}

	@Test
	public void validateSettlementAccountForNonPaymentPackage() throws AgreementCustomerReferenceDAOException {
		Integer productId = 806;
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId(productId.toString());
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("1234");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setCommercialAgreementId("12345");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1335003106");

		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(true);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(productId)).thenReturn(new ArrayList<Integer>());

		try {
			validator.validatePackage(agreementCustomerReference);
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.fail("no exception expected");
		}
	}

	@Test
	public void validateNonPaymentPackageWithoutAgreementAdministrations() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		Integer productId = 1239;
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId(productId.toString());
		agreementCustomerReference.setCommercialAgreementId("12345");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1335003106");

		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
//		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(true);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(productId)).thenReturn(new ArrayList<Integer>());

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4008", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("excepted exception");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4008", e.getMessage());
		}
	}

	@Test
	public void validateNonPaymentPackageWithAgreementAdministrations() throws AgreementCustomerReferenceDAOException {
		Integer productId = 1239;
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId(productId.toString());
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("1234");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setCommercialAgreementId("12345");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1335003106");

		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(true);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(productId)).thenReturn(new ArrayList<Integer>());

		try {
			validator.validatePackage(agreementCustomerReference);
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.fail("no exception expected");
		}
	}

	@Test
	public void validateNonPaymentPackageWithSettlementAccount() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		Integer productId = 1239;
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		agreementCustomerReference.setProductId(productId.toString());
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("1234");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setCommercialAgreementId("12345");
		agreementCustomerReference.setParentAgreementCustomerReferenceId("1335003106");
		agreementCustomerReference.setPackageSettlementAccountNumber("NL17ABNA0123456907");

		Mockito.when(productValidationDao.getProductType(Integer.parseInt(agreementCustomerReference.getProductId()))).thenReturn("P");
//		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("1335003106")).thenReturn(true);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(productId)).thenReturn(new ArrayList<Integer>());

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4034", 400);
//		Mockito.doThrow(exception).when(validator).validatePackage(agreementCustomerReference);

		try {
			validator.validatePackage(agreementCustomerReference);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4034", e.getMessage());
		}
	}

	@Test
	public void isCustomerExistsSuccesTest() throws AgreementCustomerReferenceApplicationException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);

		try {
			validator.isCustomerExists(retrievePartyDetailsResponseTO);
		} catch(AgreementCustomerReferenceApplicationException e) {
			Assertions.fail("no exception expected");
		}
	}
	
	@Test
	public void isCustomerExistsSchemaFailureTest() throws AgreementCustomerReferenceApplicationException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4024", 400);
//		Mockito.doThrow(exception).when(validator).isCustomerExists(retrievePartyDetailsResponseTO);

		try {
			validator.isCustomerExists(retrievePartyDetailsResponseTO);
			Assertions.fail("exception expected");
		} catch(AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4024", e.getMessage());
		}
	}
	
	@Test
	public void isCustomerExistsValueFailureTest() throws AgreementCustomerReferenceApplicationException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("0");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4024", 400);
//		Mockito.doThrow(exception).when(validator).isCustomerExists(retrievePartyDetailsResponseTO);

		try {
			validator.isCustomerExists(retrievePartyDetailsResponseTO);
			Assertions.fail("exception expected");
		} catch(AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4024", e.getMessage());
		}
	}
	
	@Test
	public void validateBuildingBlockDetailsSuccessTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView.setBuildingBlockId(1234);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView);
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("1234");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);
		
		validator.validateBuildingBlockDetails(buildingBlockClusterTypeViewList, agreementAdministrationReferences);
		
	}
	
	@Test
	public void validateBuildingBlockDetailsFailureTest() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView.setBuildingBlockId(1234);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView);
		AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementadministrationreference = new AgreementAdministrationReference();
		agreementadministrationreference.setAgreementAdministrationId("12345");
		agreementadministrationreference.setAgreementAdministrationReferenceId("1234");
		agreementAdministrationReferences.add(agreementadministrationreference);
		agreementCustomerReference.setAgreementAdministrationReferences(agreementAdministrationReferences);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4025", 400);
//		Mockito.doThrow(exception).when(validator).validateBuildingBlockDetails(buildingBlockClusterTypeViewList, agreementAdministrationReferences);

		try {
			validator.validateBuildingBlockDetails(buildingBlockClusterTypeViewList, agreementAdministrationReferences);
			Assertions.fail("exception expected");
		} catch(AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4025", e.getMessage());
		}
	}
	
	/*@Test
	public void validateOrgUnitIdSuccessTest() throws AgreementCustomerReferenceApplicationException {
		Mockito.when(orgUnitIdValidator.checkIfValidOrgUnitIdInInput("437098")).thenReturn(true);
		validator.validateOrgUnitId("437098");
	}*/
	
	/*@Test
	public void validateOrgUnitIdFailureTest() throws AgreementCustomerReferenceApplicationException {
		Mockito.when(orgUnitIdValidator.checkIfValidOrgUnitIdInInput("437000")).thenReturn(false);
		try{
			validator.validateOrgUnitId("437000");
			Assertions.fail("exception expected");
		} catch(AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4012", e.getMessage());
		}
	}*/

	@Test
	public void validatePaymentPackage77() throws AgreementCustomerReferenceDAOException{
		List<Integer> productGroupIds = new ArrayList<>();
		productGroupIds.add(76);
		productGroupIds.add(77);
		productGroupIds.add(78);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(123)).thenReturn(productGroupIds);

//		Mockito.doReturn(true).when(validator).isPaymentPackage(123);

		Assertions.assertTrue(validator.isPaymentPackage(123));
	}

	@Test
	public void validatePaymentPackage86() throws AgreementCustomerReferenceDAOException{
		List<Integer> productGroupIds = new ArrayList<>();
		productGroupIds.add(85);
		productGroupIds.add(86);
		productGroupIds.add(87);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(123)).thenReturn(productGroupIds);

//		Mockito.doReturn(true).when(validator).isPaymentPackage(123);

		Assertions.assertTrue(validator.isPaymentPackage(123));
	}

	@Test
	public void validatePaymentPackageEmpty() throws AgreementCustomerReferenceDAOException{
		List<Integer> productGroupIds = new ArrayList<>();
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(123)).thenReturn(productGroupIds);
//		Mockito.doReturn(false).when(validator).isPaymentPackage(123);

		Assertions.assertFalse(validator.isPaymentPackage(123));
	}

	@Test
	public void validatePaymentPackageOther() throws AgreementCustomerReferenceDAOException{
		List<Integer> productGroupIds = new ArrayList<>();
		productGroupIds.add(176);
		productGroupIds.add(177);
		productGroupIds.add(178);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(123)).thenReturn(productGroupIds);
//		Mockito.doReturn(false).when(validator).isPaymentPackage(123);

		Assertions.assertFalse(validator.isPaymentPackage(123));
	}
	
	@Test
	public void validateProductForSettlementAccountUpdate() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException {
		List<Integer> productGroupIds = new ArrayList<>();
		productGroupIds.add(176);
		productGroupIds.add(177);
		productGroupIds.add(178);
		Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(123)).thenReturn(productGroupIds);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4038", 400);
//		Mockito.doThrow(exception).when(validator).validateProductForSettlementAccountUpdate("123");

		try {
			validator.validateProductForSettlementAccountUpdate("123");
			Assertions.fail("exception expected");
		} catch(AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4038", e.getMessage());
		}
	}
	
	@Test
	public void validateStatusBeforeSettlementAccountUpdate() throws AgreementCustomerReferenceApplicationException{
//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4036", 400);
//		Mockito.doThrow(exception).when(validator).validateStatusBeforeSettlementAccountUpdate("3");
		try{
			validator.validateStatusBeforeSettlementAccountUpdate("3");
			Assertions.fail("exception expected");
		} catch(AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4036", e.getMessage());
		}
	}
	
	@Test
	public void validateSettlementAccountWithNotCurrentAccount() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException{
//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4037", 400);
//		Mockito.doThrow(exception).when(validator).validateSettlementAccountForUpdate("NL17ABNA0123456907");

		try{
//			Mockito.when(buildingBlockDao.isBuildingBlockReferencePresent(5, "NL17ABNA0123456907")).thenReturn(false);
			validator.validateSettlementAccountForUpdate("NL17ABNA0123456907");
			Assertions.fail("exception expected");
		} catch(AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4037", e.getMessage());
		}
	}
	
	@Test
	public void validateUpdateSettlementAccountWithEmptyInput() throws AgreementCustomerReferenceApplicationException{
//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4035", 400);
//		Mockito.doThrow(exception).when(validator).validateSettlementAccountForUpdate("");

		try{
			validator.validateSettlementAccountForUpdate("");
			Assertions.fail("exception expected");
		} catch(AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4035", e.getMessage());
		}
	}
	
	@Test
	public void validateUpdateSettlementAccountWithInvalidFormat() throws AgreementCustomerReferenceApplicationException{
//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4035", 400);
//		Mockito.doThrow(exception).when(validator).validateSettlementAccountForUpdate("ABNA0123456907");

		try{
			validator.validateSettlementAccountForUpdate("ABNA0123456907");
			Assertions.fail("exception expected");
		} catch(AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals("4035", e.getMessage());
		}
	}
}
