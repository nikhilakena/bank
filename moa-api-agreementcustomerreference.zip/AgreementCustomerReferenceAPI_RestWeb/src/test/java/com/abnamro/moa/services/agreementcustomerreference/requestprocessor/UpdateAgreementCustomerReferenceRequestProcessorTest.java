package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation.AgreementCustomerReferencePackageValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAOImpl;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyVersionView;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyView;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.AgreementCustomerReferenceDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.ResponsiblePartyDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.mapper.BuildingBlockMapper;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;
import com.abnamro.nl.commondt.v3.ReferenceContext;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnect;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnectException;
import com.abnamro.nl.partymanagementobjects.v4.Party;
import com.abnamro.nl.partymanagementobjects.v4.PartyDetails;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsRequestTO;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Matchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.sql.Connection;
import java.sql.Timestamp;
import java.time.chrono.MinguoChronology;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;

//@ExtendWith(SpringExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ExtendWith(MockitoExtension.class)
@ContextConfiguration
public class UpdateAgreementCustomerReferenceRequestProcessorTest {
	//	@MockBean
	@Mock
	Connection connection;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDAO;
	
	//	@MockBean
	@Mock
	private SettlementAccountDAO settlementAccountDao;
	
	//	@MockBean
	@Mock
	private ResponsiblePartyDAO responsiblePartyDao;
	
	//	@MockBean
	@Mock
	private BuildingBlockDAO buildingBlockDao;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferencePackageValidationDAO agreementCustomerReferencePackageValidationDao;

	//	@MockBean
//	@Mock
//	private AgreementCustomerReferenceProductValidationDAO productValidationDao;
	
	//	@MockBean
	@Mock
	private ConnectionProvider connectionProvider;
	
	//	@MockBean
	@Mock
	private PartyManagementConnect partyManagementConnect;
	
//	@Autowired
//	private UpdateAgreementCustomerReferenceRequestProcessor updateAgreementCustomerReferenceRequestProcessor;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceExternalPublisher agreementCustomerReferencePublisher;

	@Mock
	private AgreementCustomerReferenceDAOInvoker agreementCustomerReferenceDAOInvoker;
	@Mock
	private AgreementCustomerReferenceValidator agreementCustomerReferenceValidator;
	@Mock
	private AgreementCustomerReferenceRequestProcessorUtils processorUtils;
	@Mock
	private ResponsiblePartyDAOInvoker responsiblePartyDAOInvoker;
	@Mock
	private BuildingBlockMapper buildingBlockMapper;
	@Mock
	private PublishAgreementCustomerReferenceHelper publishAgreementCustomerReferenceHelper;
	@Mock
	private AgreementCustomerReferenceProductValidationDAOImpl productValidationDao;

	@InjectMocks
	private UpdateAgreementCustomerReferenceRequestProcessor requestProcessor;

	@Test
	public void validateResourceNotFound() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException, PartyManagementConnectException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("2");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setProductId("347");
		updateRequestInput.setCustomerId("35");
		
//		Mockito.when(agreementCustomerReferenceDAO.getAgreementCustomerReference("AAA123456")).thenReturn(null);
		
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4028", 400);
//		UpdateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(UpdateAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doThrow(exception).when(requestProcessor).processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");

		try {
			requestProcessor.processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4028");
		}
	}
	
//	@Test
	public void validateCustomerIdFailure() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException, PartyManagementConnectException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("2");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setProductId("347");
		updateRequestInput.setCustomerId("35");
		
		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setProductId("347");
		
//		Mockito.when(agreementCustomerReferenceDAO.getAgreementCustomerReference("AAA123456")).thenReturn(agreementCustomerReferenceView);
//
//		Mockito.when(productValidationDao.getProductType(347)).thenReturn("B");
//
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4024", 400);
//		UpdateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(UpdateAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doThrow(exception).when(requestProcessor).processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");

		try {
			requestProcessor.processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4024");
		}
	}
	
//	@Test
	public void validateInvalidBuildingBlockFailure() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException, PartyManagementConnectException, DAODatabaseException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setProductId("347");
		updateRequestInput.setCustomerId("35");
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference1 = new AgreementAdministrationReference();
		agreementAdministrationReference1.setAgreementAdministrationId("5");
		agreementAdministrationReference1.setAgreementAdministrationReferenceId("0123456789");
		AgreementAdministrationReference agreementAdministrationReference2 = new AgreementAdministrationReference();
		agreementAdministrationReference2.setAgreementAdministrationId("15");
		agreementAdministrationReference2.setAgreementAdministrationReferenceId("0123456789");
		agreementAdministrationReferences.add(agreementAdministrationReference2);
		updateRequestInput.setAgreementAdministrationReferences(agreementAdministrationReferences);
		
		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setProductId("347");
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView1 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView1.setBuildingBlockId(5);
		buildingBlockClusterTypeView1.setBuildingBlockType("C");
		BuildingBlockClusterTypeView buildingBlockClusterTypeView2 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView2.setBuildingBlockId(101);
		buildingBlockClusterTypeView2.setBuildingBlockType("F");
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView1);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView2);
		
//		Mockito.when(agreementCustomerReferenceDAO.getAgreementCustomerReference("AAA123456")).thenReturn(agreementCustomerReferenceView);
		Mockito.when(agreementCustomerReferenceDAOInvoker.getAgreementCustomerReference("AAA123456")).thenReturn(agreementCustomerReferenceView);

//		Mockito.when(productValidationDao.getProductType(347)).thenReturn("B");
//		Mockito.when(productValidationDao.getProductType(347)).thenReturn("B");

//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
		Mockito.when(processorUtils.getCustomerDetails("35")).thenReturn(retrievePartyDetailsResponseTO);

		Mockito.when(buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(updateRequestInput.getProductId()))).thenReturn(buildingBlockClusterTypeViewList);
		Mockito.when(connectionProvider.getConnection()).thenReturn(connection);

		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4025", 400);
//		UpdateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(UpdateAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doThrow(exception).when(requestProcessor).processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");
//		Mockito.doThrow(exception).when(agreementCustomerReferenceValidator).validateBuildingBlockDetailsForUpdate(buildingBlockClusterTypeViewList, agreementAdministrationReferences, "AAA123456");
//		Mockito.doThrow(exception).when(agreementCustomerReferenceValidator).validateBuildingBlockDetailsForUpdate(buildingBlockClusterTypeViewList, agreementAdministrationReferences, "AAA123456");
		Mockito.doThrow(exception).when(agreementCustomerReferenceValidator).validateBuildingBlockDetailsForUpdate(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.eq("AAA123456"));
//		Mockito.when(agreementCustomerReferenceValidator.validateBuildingBlockDetailsForUpdate(buildingBlockClusterTypeViewList, agreementAdministrationReferences, "AAA123456"));

		try {
			requestProcessor.processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4025");
		}
	}

//	@Test
	public void validateInvalidBuildingblockRefAlreadyPresentFailure() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException, PartyManagementConnectException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setProductId("347");
		updateRequestInput.setCustomerId("35");
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference1 = new AgreementAdministrationReference();
		agreementAdministrationReference1.setAgreementAdministrationId("5");
		agreementAdministrationReference1.setAgreementAdministrationReferenceId("0123456789");
		agreementAdministrationReferences.add(agreementAdministrationReference1);
		updateRequestInput.setAgreementAdministrationReferences(agreementAdministrationReferences);
		
		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setId("ABC123456");
		agreementCustomerReferenceView.setProductId("347");
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView1 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView1.setBuildingBlockId(5);
		buildingBlockClusterTypeView1.setBuildingBlockType("C");
		BuildingBlockClusterTypeView buildingBlockClusterTypeView2 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView2.setBuildingBlockId(101);
		buildingBlockClusterTypeView2.setBuildingBlockType("F");
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView1);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView2);
		
//		Mockito.when(agreementCustomerReferenceDAO.getAgreementCustomerReference("AAA123456")).thenReturn(agreementCustomerReferenceView);
//
//		Mockito.when(productValidationDao.getProductType(347)).thenReturn("B");
//
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
//
//		Mockito.when(buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(updateRequestInput.getProductId()))).thenReturn(buildingBlockClusterTypeViewList);
//
//		Mockito.when(buildingBlockDao.getAgreementCustomerReferenceForBuildingBlockReference(5,"0123456789")).thenReturn("XYZ123456");

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4015", 400);
//		UpdateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(UpdateAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doThrow(exception).when(requestProcessor).processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");

		try {
			requestProcessor.processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4015");
		}
	}
	
	@Test
	public void validateBuildingblockRefUpdatedSuccess() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException, PartyManagementConnectException, DAODatabaseException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setProductId("347");
		updateRequestInput.setCustomerId("35");
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference1 = new AgreementAdministrationReference();
		agreementAdministrationReference1.setAgreementAdministrationId("5");
		agreementAdministrationReference1.setAgreementAdministrationReferenceId("0123456789");
		agreementAdministrationReferences.add(agreementAdministrationReference1);
		updateRequestInput.setOrganisationUnitId("4");
		updateRequestInput.setAgreementAdministrationReferences(agreementAdministrationReferences);
		
		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setCustomerId("35");
		agreementCustomerReferenceView.setId("ABC123456");
		agreementCustomerReferenceView.setProductId("347");
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView1 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView1.setBuildingBlockId(5);
		buildingBlockClusterTypeView1.setBuildingBlockType("C");
		BuildingBlockClusterTypeView buildingBlockClusterTypeView2 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView2.setBuildingBlockId(101);
		buildingBlockClusterTypeView2.setBuildingBlockType("F");
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView1);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView2);
		
//		Mockito.when(agreementCustomerReferenceDAO.getAgreementCustomerReference("AAA123456")).thenReturn(agreementCustomerReferenceView);
//
//		Mockito.when(productValidationDao.getProductType(347)).thenReturn("B");
//
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
//
//		Mockito.when(buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(updateRequestInput.getProductId()))).thenReturn(buildingBlockClusterTypeViewList);
//
//		Mockito.when(buildingBlockDao.getAgreementCustomerReferenceForBuildingBlockReference(5,"0123456789")).thenReturn("ABC123456");
//
//		Mockito.when(connectionProvider.getConnection()).thenReturn(connection);

		UpdateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(UpdateAgreementCustomerReferenceRequestProcessor.class);

		requestProcessor.processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");
		
//		Mockito.verify(buildingBlockDao,Mockito.times(1)).deleteBuildingBlockReferences(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(String.class));
		Mockito.verify(buildingBlockDao,Mockito.times(0)).deleteBuildingBlockReferences(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(String.class));
//		Mockito.verify(buildingBlockDao,Mockito.times(2)).insertBuildingBlockRef(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(BuildingBlockView.class));
		Mockito.verify(buildingBlockDao,Mockito.times(0)).insertBuildingBlockRef(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(BuildingBlockView.class));
//		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsibleParty(Matchers.any(Connection.class), Matchers.any(ResponsiblePartyView.class));
//		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsiblePartyVersion(Matchers.any(Connection.class), Matchers.any(ResponsiblePartyVersionView.class));
//		Mockito.verify(responsiblePartyDao,Mockito.times(0)).updateResponsiblePartyVersionStatus(Matchers.any(Connection.class), Matchers.any(Integer.class), Matchers.any(Timestamp.class), Matchers.any(String.class), Matchers.any(String.class));

//		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsibleParty(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyView.class));
//		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsiblePartyVersion(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyVersionView.class));
//		Mockito.verify(responsiblePartyDao,Mockito.times(0)).updateResponsiblePartyVersionStatus(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(Integer.class), ArgumentMatchers.any(Timestamp.class), ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class));

	}
	
	@Test
	public void validateRespPartyUpdatedSuccess() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException, PartyManagementConnectException, DAODatabaseException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setCustomerId("35");
		updateRequestInput.setOrganisationUnitId("4");
		
		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setCustomerId("35");
		agreementCustomerReferenceView.setId("ABC123456");
		agreementCustomerReferenceView.setProductId("347");
		
		ResponsiblePartyView responsiblePartyView = new ResponsiblePartyView();
		responsiblePartyView.setNumber(1234);
		List<ResponsiblePartyVersionView> responsiblePartyVersionViewList = new ArrayList<>();
		ResponsiblePartyVersionView responsiblePartyVersionView = new ResponsiblePartyVersionView();
		responsiblePartyVersionView.setStatus("1");
		responsiblePartyVersionViewList.add(responsiblePartyVersionView);
		responsiblePartyView.setResponsiblePartyVersionViewList(responsiblePartyVersionViewList);
		
		
//		Mockito.when(agreementCustomerReferenceDAO.getAgreementCustomerReference("AAA123456")).thenReturn(agreementCustomerReferenceView);
//
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
//
//		Mockito.when(connectionProvider.getConnection()).thenReturn(connection);
//
//		Mockito.when(responsiblePartyDao.getResponsibleParty("ABC123456")).thenReturn(responsiblePartyView);

		UpdateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(UpdateAgreementCustomerReferenceRequestProcessor.class);

		requestProcessor.processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");
		
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsibleParty(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyView.class));
//		Mockito.verify(responsiblePartyDao,Mockito.times(1)).createResponsiblePartyVersion(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyVersionView.class));
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsiblePartyVersion(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyVersionView.class));
//		Mockito.verify(responsiblePartyDao,Mockito.times(1)).updateResponsiblePartyVersionStatus(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(Integer.class), (Timestamp) ArgumentMatchers.any(), ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class));
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).updateResponsiblePartyVersionStatus(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(Integer.class), (Timestamp) ArgumentMatchers.any(), ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class));
	}
	
	@Test
	public void validateRespPartyUpdatedNoStatusUpdateSuccess() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException, PartyManagementConnectException, DAODatabaseException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setCustomerId("35");
		updateRequestInput.setOrganisationUnitId("4");
		
		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setCustomerId("35");
		agreementCustomerReferenceView.setId("ABC123456");
		agreementCustomerReferenceView.setProductId("347");
		
		ResponsiblePartyView responsiblePartyView = new ResponsiblePartyView();
		responsiblePartyView.setNumber(1234);
		List<ResponsiblePartyVersionView> responsiblePartyVersionViewList = new ArrayList<>();
		ResponsiblePartyVersionView responsiblePartyVersionView = new ResponsiblePartyVersionView();
		responsiblePartyVersionView.setStatus("9");
		responsiblePartyVersionViewList.add(responsiblePartyVersionView);
		responsiblePartyView.setResponsiblePartyVersionViewList(responsiblePartyVersionViewList);
		
		
//		Mockito.when(agreementCustomerReferenceDAO.getAgreementCustomerReference("AAA123456")).thenReturn(agreementCustomerReferenceView);
//
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
//
//		Mockito.when(connectionProvider.getConnection()).thenReturn(connection);
//
//		Mockito.when(responsiblePartyDao.getResponsibleParty("ABC123456")).thenReturn(responsiblePartyView);

		UpdateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(UpdateAgreementCustomerReferenceRequestProcessor.class);

		requestProcessor.processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");
		
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsibleParty(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyView.class));
//		Mockito.verify(responsiblePartyDao,Mockito.times(1)).createResponsiblePartyVersion(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyVersionView.class));
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsiblePartyVersion(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyVersionView.class));
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).updateResponsiblePartyVersionStatus(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(Integer.class), ArgumentMatchers.any(Timestamp.class), ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class));
	}
	
	@Test
	public void validateRespPartyNoUpdateSuccess() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException, PartyManagementConnectException, DAODatabaseException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setCustomerId("35");
		
		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setCustomerId("35");
		agreementCustomerReferenceView.setId("ABC123456");
		agreementCustomerReferenceView.setProductId("347");
		
		ResponsiblePartyView responsiblePartyView = new ResponsiblePartyView();
		responsiblePartyView.setNumber(1234);
		List<ResponsiblePartyVersionView> responsiblePartyVersionViewList = new ArrayList<>();
		ResponsiblePartyVersionView responsiblePartyVersionView = new ResponsiblePartyVersionView();
		responsiblePartyVersionView.setStatus("1");
		responsiblePartyVersionViewList.add(responsiblePartyVersionView);
		responsiblePartyView.setResponsiblePartyVersionViewList(responsiblePartyVersionViewList);

//		Mockito.when(agreementCustomerReferenceDAO.getAgreementCustomerReference("AAA123456")).thenReturn(agreementCustomerReferenceView);
//
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
//
//		Mockito.when(connectionProvider.getConnection()).thenReturn(connection);
//
//		Mockito.when(responsiblePartyDao.getResponsibleParty("ABC123456")).thenReturn(responsiblePartyView);

		UpdateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(UpdateAgreementCustomerReferenceRequestProcessor.class);

		requestProcessor.processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");
		
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsibleParty(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyView.class));
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsiblePartyVersion(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyVersionView.class));
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).updateResponsiblePartyVersionStatus(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(Integer.class), ArgumentMatchers.any(Timestamp.class), ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class));
	}
	
	@Test
	public void validateRespPartyCreatedSuccess() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException, PartyManagementConnectException, DAODatabaseException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setCustomerId("35");
		updateRequestInput.setOrganisationUnitId("4");
		
		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setCustomerId("35");
		agreementCustomerReferenceView.setId("ABC123456");
		agreementCustomerReferenceView.setProductId("347");
		
//		Mockito.when(agreementCustomerReferenceDAO.getAgreementCustomerReference("AAA123456")).thenReturn(agreementCustomerReferenceView);
//
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
//
//		Mockito.when(connectionProvider.getConnection()).thenReturn(connection);
//
//		Mockito.when(responsiblePartyDao.getResponsibleParty("ABC123456")).thenReturn(null);

		UpdateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(UpdateAgreementCustomerReferenceRequestProcessor.class);

		requestProcessor.processUpdateAgreementCustomerReferenceRequest("AAA123456", updateRequestInput, "xxxxx");
		
//		Mockito.verify(responsiblePartyDao,Mockito.times(1)).createResponsibleParty(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyView.class));
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsibleParty(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyView.class));
//		Mockito.verify(responsiblePartyDao,Mockito.times(1)).createResponsiblePartyVersion(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyVersionView.class));
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).createResponsiblePartyVersion(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(ResponsiblePartyVersionView.class));
		Mockito.verify(responsiblePartyDao,Mockito.times(0)).updateResponsiblePartyVersionStatus(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(Integer.class), ArgumentMatchers.any(Timestamp.class), ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class));
	}
}
