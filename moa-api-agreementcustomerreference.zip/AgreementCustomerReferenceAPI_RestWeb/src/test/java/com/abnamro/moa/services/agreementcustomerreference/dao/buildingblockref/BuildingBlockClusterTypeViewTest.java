package com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class BuildingBlockClusterTypeViewTest {
    @Test
    void create() {
        BuildingBlockClusterTypeView clusterType = new BuildingBlockClusterTypeView();
        Assertions.assertEquals(0, clusterType.getClusterId());
        Assertions.assertEquals(0, clusterType.getBuildingBlockId());
        Assertions.assertEquals(0, clusterType.getProductId());
        Assertions.assertNull(clusterType.getBuildingBlockType());
    }

    @Test
    void gettersAndSetters() {
        BuildingBlockClusterTypeView clusterType = new BuildingBlockClusterTypeView();
        clusterType.setBuildingBlockType("type");
        clusterType.setClusterId(10);
        clusterType.setBuildingBlockId(11);
        clusterType.setProductId(12);

        Assertions.assertNotNull(clusterType);
        Assertions.assertEquals("type", clusterType.getBuildingBlockType());
        Assertions.assertEquals(10, clusterType.getClusterId());
        Assertions.assertEquals(11, clusterType.getBuildingBlockId());
        Assertions.assertEquals(12, clusterType.getProductId());
    }
}
