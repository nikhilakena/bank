package com.abnamro.moa.services.agreementcustomerreference.validator;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation.AgreementCustomerReferencePackageValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;

//@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ContextConfiguration
public class SearchAgreementCustomerReferenceValidatorTest {
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDao;

	//	@MockBean
	@Mock
	private AgreementCustomerReferenceProductValidationDAO productValidationDao;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferencePackageValidationDAO agreementCustomerReferencePackageValidationDao;
	
	//	@MockBean
	@Mock
	private SettlementAccountDAO settlementAccountDao;
	
	//	@MockBean
	@Mock
	private ResponsiblePartyDAO responsiblePartyDao;
	
	//	@MockBean
	@Mock
	private BuildingBlockDAO buildingBlockDao;

//	@Autowired
	@Mock
	private AgreementCustomerReferenceValidator validator;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceExternalPublisher agreementCustomerReferencePublisher;

	@Test
	public void validateSearchRequestTestNonNumericProductId() throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4005", 400);
		Mockito.doThrow(exception).when(validator).validateSearchRequest("1234a", "1234567890", null, null);

		try {
			validator.validateSearchRequest("1234a", "1234567890", null, null);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4005");
		}
	}
	
	@Test
	public void validateSearchRequestTestProductIdInavlidLength() throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4005", 400);
		Mockito.doThrow(exception).when(validator).validateSearchRequest("1234567", "1234567890", null, null);

		try {
			validator.validateSearchRequest("1234567", "1234567890", null, null);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4005");
		}
	}
	
	@Test
	public void validateSearchRequestTestCommercialAgreementIdInavlidLength() throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4017", 400);
		Mockito.doThrow(exception).when(validator).validateSearchRequest("12345", "12345678901234567890", null, null);

		try {
			validator.validateSearchRequest("12345", "12345678901234567890", null, null);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4017");
		}
	}
	
	@Test
	public void validateSearchRequestTestNonNumericBBId() throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4009", 400);
		Mockito.doThrow(exception).when(validator).validateSearchRequest(null, null,"1234a", "1234567890");

		try {
			validator.validateSearchRequest(null, null,"1234a", "1234567890");
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4009");
		}
	}
	
	@Test
	public void validateSearchRequestTestBBIdInavlidLength() throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4009", 400);
		Mockito.doThrow(exception).when(validator).validateSearchRequest(null, null, "1234567", "1234567890");

		try {
			validator.validateSearchRequest(null, null, "1234567", "1234567890");
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4009");
		}
	}
	
	@Test
	public void validateSearchRequestTestBBRefInavlidLength() throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4020", 400);
		Mockito.doThrow(exception).when(validator).validateSearchRequest(null, null, "12345", "12345678901234567890");

		try {
			validator.validateSearchRequest(null, null, "12345", "12345678901234567890");
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4020");
		}
	}
	
	@Test
	public void validateSearchRequestAtleastOneSelectionNullTest() throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4031", 400);
		Mockito.doThrow(exception).when(validator).validateSearchRequest(null, null, null, null);

		try {
			validator.validateSearchRequest(null, null, null, null);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4031");
		}
	}
	
	@Test
	public void validateSearchRequestOnlyOneSelectionTest() throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4031", 400);
		Mockito.doThrow(exception).when(validator).validateSearchRequest("1234", "1234567890", "5", "1234567890");

		try {
			validator.validateSearchRequest("1234", "1234567890", "5", "1234567890");
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4031");
		}
	}
}
