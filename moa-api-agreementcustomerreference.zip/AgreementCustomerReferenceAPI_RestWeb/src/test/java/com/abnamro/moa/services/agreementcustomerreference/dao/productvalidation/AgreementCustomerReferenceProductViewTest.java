package com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AgreementCustomerReferenceProductViewTest {
    @Test
    void gettersAndSetters() {
        AgreementCustomerReferenceProductView product = new AgreementCustomerReferenceProductView();
        product.setId("123");
        product.setStatus("ok");
        product.setType("package");

        Assertions.assertEquals("123", product.getId());
        Assertions.assertEquals("ok", product.getStatus());
        Assertions.assertEquals("package", product.getType());
    }

    @Test
    void createProduct() {
        AgreementCustomerReferenceProductView product = new AgreementCustomerReferenceProductView();

        Assertions.assertNotNull(product);
        Assertions.assertNull(product.getId());
        Assertions.assertNull(product.getStatus());
        Assertions.assertNull(product.getType());
    }
}
