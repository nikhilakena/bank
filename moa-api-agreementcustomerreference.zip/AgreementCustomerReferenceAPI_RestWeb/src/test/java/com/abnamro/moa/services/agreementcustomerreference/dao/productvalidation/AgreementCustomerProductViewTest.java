package com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

class AgreementCustomerProductViewTest {
    @Test
    void createAgreementCustomerProductView() {
        AgreementCustomerProductView productView = new AgreementCustomerProductView();
        Assertions.assertNull(productView.getChId());
        Assertions.assertNull(productView.getAgreementId());
        Assertions.assertNull(productView.getStatus());
        Assertions.assertNull(productView.getNickname());
        Assertions.assertNull(productView.getBbIdList());
        Assertions.assertEquals(0, productView.getProductId());
        Assertions.assertEquals(0, productView.getOrderId());
        Assertions.assertNull(productView.getIBAN());
    }

    @Test
    void gettersAndSetters() {
        AgreementCustomerProductView productView = new AgreementCustomerProductView();

        productView.setChId("chid");
        Assertions.assertEquals("chid", productView.getChId());

        productView.setAgreementId("123");
        Assertions.assertEquals("123", productView.getAgreementId());

        productView.setStatus("status");
        Assertions.assertEquals("status", productView.getStatus());

        productView.setNickname("nickname");
        Assertions.assertEquals("nickname", productView.getNickname());

        List<Integer> buildingBlockList = new ArrayList<>();
        buildingBlockList.add(1);
        buildingBlockList.add(8);
        productView.setBbIdList(buildingBlockList);
        Assertions.assertNotNull(productView.getBbIdList());
        Assertions.assertEquals(2, productView.getBbIdList().size());
        Assertions.assertEquals(8, productView.getBbIdList().get(1));

        productView.setProductId(4);
        Assertions.assertEquals(4, productView.getProductId());

        productView.setOrderId(9);
        Assertions.assertEquals(9, productView.getOrderId());

        productView.setIBAN("iban");
        Assertions.assertEquals("iban", productView.getIBAN());
    }
}
