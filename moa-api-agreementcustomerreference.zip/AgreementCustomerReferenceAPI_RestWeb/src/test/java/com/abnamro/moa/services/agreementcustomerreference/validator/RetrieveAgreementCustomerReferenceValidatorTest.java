package com.abnamro.moa.services.agreementcustomerreference.validator;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;

//@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ContextConfiguration
public class RetrieveAgreementCustomerReferenceValidatorTest {

//	@Autowired
	@Mock
	private AgreementCustomerReferenceValidator validator;

	@Test
	public void validateRetrieveRequestTestNumericAcrId() throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4032", 400);
		Mockito.doThrow(exception).when(validator).validateAgreementCustomerReferenceId("1234567890");

		try {
			validator.validateAgreementCustomerReferenceId("1234567890");
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4032");
		}
	}

	@Test
	public void validateRetrieveRequestTestInvalidLengthAcrId() throws AgreementCustomerReferenceApplicationException {
		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4032", 400);
		Mockito.doThrow(exception).when(validator).validateAgreementCustomerReferenceId("1234567");
		try {
			validator.validateAgreementCustomerReferenceId("1234567");
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4032");
		}
	}

}
