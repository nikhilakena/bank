package com.abnamro.moa.services.agreementcustomerreference.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AgreementCustomerReferenceIdUtilsTest {
	@Test
	public void convertAgreementCustomerReferenceIds() {
		Assertions.assertNull(AgreementCustomerReferenceIdUtils.convertGeneratedIdToAgreementCustomerReferenceId(null));
		Assertions.assertEquals("LMN456789", AgreementCustomerReferenceIdUtils.convertGeneratedIdToAgreementCustomerReferenceId(123456789));
		Assertions.assertEquals("MLR099900", AgreementCustomerReferenceIdUtils.convertGeneratedIdToAgreementCustomerReferenceId(217099900));
	}
}
