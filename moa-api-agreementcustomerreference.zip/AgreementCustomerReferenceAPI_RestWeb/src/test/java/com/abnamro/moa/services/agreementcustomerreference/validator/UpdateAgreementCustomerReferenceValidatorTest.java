package com.abnamro.moa.services.agreementcustomerreference.validator;

import org.junit.jupiter.api.Assertions;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation.AgreementCustomerReferencePackageValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;

//@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ContextConfiguration
public class UpdateAgreementCustomerReferenceValidatorTest {
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDao;

	//	@MockBean
	@Mock
	private AgreementCustomerReferenceProductValidationDAO productValidationDao;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferencePackageValidationDAO agreementCustomerReferencePackageValidationDao;
	
	//	@MockBean
	@Mock
	private SettlementAccountDAO settlementAccountDao;
	
	//	@MockBean
	@Mock
	private ResponsiblePartyDAO responsiblePartyDao;
	
	//	@MockBean
	@Mock
	private BuildingBlockDAO buildingBlockDao;

	@Mock
//	@Autowired
	private AgreementCustomerReferenceValidator validator;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceExternalPublisher agreementCustomerReferencePublisher;

	@Test
	public void validatePartialUpdateRequestLifeCycleStatusFailure() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException{
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("Invalid");
//		Mockito.when(productValidationDao.getProductType(437)).thenReturn("B");

		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4014", 400);
		Mockito.doThrow(exception).when(validator).validatePartialUpdateRequest("AAA123456", updateRequestInput);

		try {
			validator.validatePartialUpdateRequest("AAA123456", updateRequestInput);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4014");
		}
		
	}
	
	@Test
	public void validatePartialUpdateRequestLifeCycleStatusFailure2() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException{
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("");
//		Mockito.when(productValidationDao.getProductType(437)).thenReturn("B");

		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4014", 400);
		Mockito.doThrow(exception).when(validator).validatePartialUpdateRequest("AAA123456", updateRequestInput);

		try {
			validator.validatePartialUpdateRequest("AAA123456", updateRequestInput);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4014");
		}
	}
	
	@Test
	public void validatePartialUpdateRequestProductIdNotFound() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException{
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setProductId("347");
//		Mockito.when(productValidationDao.getProductType(437)).thenReturn("B");

		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4006", 400);
		Mockito.doThrow(exception).when(validator).validatePartialUpdateRequest("AAA123456", updateRequestInput);

		try {
//			Mockito.when(productValidationDao.getProductType(347)).thenReturn(null);
			validator.validatePartialUpdateRequest("AAA123456", updateRequestInput);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4006");
		}
	}
	
	@Test
	public void validatePartialUpdateRequestProductIdNoBB() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException{
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setProductId("347");
//		Mockito.when(productValidationDao.getProductType(437)).thenReturn("B");

		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4008", 400);
		Mockito.doThrow(exception).when(validator).validatePartialUpdateRequest("AAA123456", updateRequestInput);

		try {
//			Mockito.when(productValidationDao.getProductType(347)).thenReturn("B");
			validator.validatePartialUpdateRequest("AAA123456", updateRequestInput);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4008");
		}
	}
	
	@Test
	public void validatePartialUpdateRequestInvalidParentCHId() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException {
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setParentAgreementCustomerReferenceId("ABC123456");
//		Mockito.when(productValidationDao.getProductType(437)).thenReturn("B");
//		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("ABC123456")).thenReturn(false);

		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4007", 400);
		Mockito.doThrow(exception).when(validator).validatePartialUpdateRequest("AAA123456", updateRequestInput);

		try {
			validator.validatePartialUpdateRequest("AAA123456", updateRequestInput);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4007");
		}
		
	}
	
	@Test
	public void validatePartialUpdateRequestEmptyCommercialAgreementId() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException {
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setCommercialAgreementId("");
//		Mockito.when(productValidationDao.getProductType(437)).thenReturn("B");

		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4017", 400);
		Mockito.doThrow(exception).when(validator).validatePartialUpdateRequest("AAA123456", updateRequestInput);

		try {
			validator.validatePartialUpdateRequest("AAA123456", updateRequestInput);
			Assertions.fail("exception expected");
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4017");
		}
	}
	
	@Test
	public void validatePartialUpdateRequestSuccess() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException {
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setProductId("347");
		updateRequestInput.setParentAgreementCustomerReferenceId("ABC123456");
		updateRequestInput.setCommercialAgreementId("0123456789");
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("5");
		agreementAdministrationReference.setAgreementAdministrationReferenceId("0123456789");
		agreementAdministrationReferences.add(agreementAdministrationReference);
		updateRequestInput.setAgreementAdministrationReferences(agreementAdministrationReferences);
		
//		Mockito.when(productValidationDao.getProductType(437)).thenReturn("P");
//		Mockito.when(productValidationDao.getProductType(347)).thenReturn("P");
//		Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("ABC123456")).thenReturn(true);
		
		validator.validatePartialUpdateRequest("AAA123456", updateRequestInput);
				
	}
	
	/*@Test
    public void validatePartialUpdateRequestOrgUnitIdFailure() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException{
        
        AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
        updateRequestInput.setOrganisationUnitId("701500");
        Mockito.when(productValidationDao.getProductType(437)).thenReturn("B");
        Mockito.when(OrgUnitIdValidator.checkIfValidOrgUnitIdInInput(Matchers.anyString())).thenReturn(false);
        try {
            validator.validatePartialUpdateRequest("AAA123456", updateRequestInput);
			Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException e) {
            Assertions.assertEquals(e.getMessage(), "4012");
        }
    }*/

	/*@Test(expected = AgreementCustomerReferenceApplicationException.class)
	public void validatePartialUpdateRequestInvalidSettlementAccountFormat() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException{
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setPackageSettlementAccountNumber("NL17ABNA123456907");
		
		try {
			validator.validatePartialUpdateRequest("AAA123456", updateRequestInput);
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4035");
			throw e;
		}
		
	}
	
	@Test(expected = AgreementCustomerReferenceApplicationException.class)
	public void validatePartialUpdateRequestEmptySettlementAccountNumber() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException{
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setPackageSettlementAccountNumber("");
		
		try {
			validator.validatePartialUpdateRequest("AAA123456", updateRequestInput);
		} catch (AgreementCustomerReferenceApplicationException e) {
			Assertions.assertEquals(e.getMessage(), "4035");
			throw e;
		}
		
	}*/
}
