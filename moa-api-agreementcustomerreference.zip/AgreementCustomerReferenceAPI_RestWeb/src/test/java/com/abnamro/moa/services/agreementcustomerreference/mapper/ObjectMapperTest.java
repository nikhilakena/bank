package com.abnamro.moa.services.agreementcustomerreference.mapper;

import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementLifeCycleStatusTypeEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

class ObjectMapperTest {
    @Test
    void convertFromRequestToPersistent() {
        AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
        agreementCustomerReference.setAgreementNickName("nickname");
        agreementCustomerReference.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ACTIVE);
        agreementCustomerReference.setCommercialAgreementId("1232312");
        agreementCustomerReference.setCustomerId("79867");
        agreementCustomerReference.setProductId("4453");

        AgreementCustomerReferenceView view = ObjectMapper.convertFromRequestToPersistent(agreementCustomerReference, "customer-id");

        Assertions.assertNotNull(view);
        Assertions.assertEquals("nickname", view.getNickName());
        Assertions.assertEquals(AgreementLifeCycleStatusTypeEnum.ACTIVE.getDbValue(), view.getStatus());
        Assertions.assertEquals("customer-id", view.getUserId());
        Assertions.assertNull(view.getParentId());
        Assertions.assertEquals("1232312", view.getCommercialContractNumber());
        Assertions.assertEquals("79867", view.getCustomerId());
        Assertions.assertEquals("4453", view.getProductId());
        Assertions.assertEquals("1232312", view.getCommercialContractNumber());
        Assertions.assertEquals(" ", view.getBlockingCode());
        Assertions.assertEquals(" ", view.getTransferService());
    }

    @Test
    void convertFromRequestToPersistentEmptyCustomerId() {
        AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
        agreementCustomerReference.setAgreementNickName("nickname");
        agreementCustomerReference.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ACTIVE);
        agreementCustomerReference.setCommercialAgreementId("1232312");
        agreementCustomerReference.setCustomerId("79867");
        agreementCustomerReference.setProductId("4453");

        AgreementCustomerReferenceView view = ObjectMapper.convertFromRequestToPersistent(agreementCustomerReference, null);

        Assertions.assertNotNull(view);
        Assertions.assertEquals("nickname", view.getNickName());
        Assertions.assertEquals(AgreementLifeCycleStatusTypeEnum.ACTIVE.getDbValue(), view.getStatus());
        Assertions.assertEquals(" ", view.getUserId());
        Assertions.assertNull(view.getParentId());
        Assertions.assertEquals("1232312", view.getCommercialContractNumber());
        Assertions.assertEquals("79867", view.getCustomerId());
        Assertions.assertEquals("4453", view.getProductId());
        Assertions.assertEquals("1232312", view.getCommercialContractNumber());
        Assertions.assertEquals(" ", view.getBlockingCode());
        Assertions.assertEquals(" ", view.getTransferService());
    }

    @Test
    void convertToAgreementCustomerReferenceViewForUpdate() {
        AgreementCustomerReferenceForPatch agreementCustomerReference = new AgreementCustomerReferenceForPatch();
        agreementCustomerReference.setAgreementNickName("nick name");
        agreementCustomerReference.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        agreementCustomerReference.setParentAgreementCustomerReferenceId("SDF234234");
        agreementCustomerReference.setCommercialAgreementId("789678");
        agreementCustomerReference.setCustomerId("234");
        agreementCustomerReference.setProductId("5543");

        AgreementCustomerReferenceView view = ObjectMapper.convertToAgreementCustomerReferenceViewForUpdate(agreementCustomerReference, "consumer-id");

        Assertions.assertNotNull(view);
        Assertions.assertEquals("nick name", view.getNickName());
        Assertions.assertEquals("3", view.getStatus());
        Assertions.assertEquals("SDF234234", view.getParentId());
        Assertions.assertEquals("789678", view.getCommercialContractNumber());
        Assertions.assertEquals("234", view.getCustomerId());
        Assertions.assertEquals("5543", view.getProductId());
        Assertions.assertEquals("consumer-id", view.getUserId());
    }

    @Test
    void convertToAgreementCustomerReferenceViewForUpdateEmptyValues() {
        AgreementCustomerReferenceForPatch agreementCustomerReference = new AgreementCustomerReferenceForPatch();

        AgreementCustomerReferenceView view = ObjectMapper.convertToAgreementCustomerReferenceViewForUpdate(agreementCustomerReference, null);

        Assertions.assertNotNull(view);
        Assertions.assertNull(view.getNickName());
        Assertions.assertNull(view.getStatus());
        Assertions.assertNull(view.getParentId());
        Assertions.assertNull(view.getCommercialContractNumber());
        Assertions.assertNull(view.getCustomerId());
        Assertions.assertNull(view.getProductId());
        Assertions.assertEquals(" ", view.getUserId());
    }

    @Test
    void convertToAgreementCustomerReferenceFromView() {
        AgreementCustomerReferenceView view = new AgreementCustomerReferenceView();
        view.setProductId("1233");
        view.setCustomerId("456");
        view.setStatus("active");
        view.setId("SDV893425");
        view.setCommercialContractNumber("234432");
        BuildingBlockView administration = new BuildingBlockView();
        administration.setBuildingBlockId(5);
        administration.setBuildingBlockReferenceContractId("234234");
        List<BuildingBlockView> administrations = new ArrayList<>();
        administrations.add(administration);
        view.setBuildingBlockViewList(administrations);
        Calendar clock = Calendar.getInstance();
        clock.set(2023, Calendar.SEPTEMBER, 10, 21, 58, 57);
        Timestamp createDateTime = new Timestamp(clock.getTimeInMillis());
        view.setDateCreated(createDateTime);
        view.setNickName("nick name");

        AgreementCustomerReference agreementCustomerReference = ObjectMapper.convertToAgreementCustomerReferenceFromView(view);

        Assertions.assertNotNull(agreementCustomerReference);
        Assertions.assertEquals("1233", agreementCustomerReference.getProductId());
        Assertions.assertEquals("456", agreementCustomerReference.getCustomerId());
        Assertions.assertEquals("234432", agreementCustomerReference.getCommercialAgreementId());
        Assertions.assertEquals("SDV893425", agreementCustomerReference.getAgreementCustomerReferenceId());
        List<AgreementAdministrationReference> administrationReferences = agreementCustomerReference.getAgreementAdministrationReferences();
        Assertions.assertNotNull(administrationReferences);
        Assertions.assertEquals(1, administrationReferences.size());
        Assertions.assertEquals("5", administrationReferences.get(0).getAgreementAdministrationId());
        Assertions.assertEquals("234234", administrationReferences.get(0).getAgreementAdministrationReferenceId());
        Assertions.assertEquals("2023-09-10", agreementCustomerReference.getReferenceStartDate());
        Assertions.assertEquals("nick name", agreementCustomerReference.getAgreementNickName());
    }
}
