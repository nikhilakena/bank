package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation.AgreementCustomerReferencePackageValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.*;
import com.abnamro.nl.commondt.v3.ReferenceContext;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnect;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnectException;
import com.abnamro.nl.partymanagementobjects.v4.Party;
import com.abnamro.nl.partymanagementobjects.v4.PartyDetails;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsRequestTO;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.Assertions;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;

//@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ContextConfiguration
public class RetrieveAgreementCustomerReferenceRequestProcessorTest {
	
	//	@MockBean
	@Mock
	Connection connection;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDAO;
	
	//	@MockBean
	@Mock
	private SettlementAccountDAO settlementAccountDao;
	
	//	@MockBean
	@Mock
	private ResponsiblePartyDAO responsiblePartyDao;
	
	//	@MockBean
	@Mock
	private BuildingBlockDAO buildingBlockDao;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferencePackageValidationDAO agreementCustomerReferencePackageValidationDao;

	//	@MockBean
	@Mock
	private AgreementCustomerReferenceProductValidationDAO productValidationDao;
	
	//	@MockBean
	@Mock
	private ConnectionProvider connectionProvider;
	
	//	@MockBean
	@Mock
	private PartyManagementConnect partyManagementConnect;
	
//	@Autowired
//	private RetrieveAgreementCustomerReferenceRequestProcessor requestProcessor;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceExternalPublisher agreementCustomerReferencePublisher;

	@InjectMocks
	private RetrieveAgreementCustomerReferenceRequestProcessor requestProcessor;

	@Test
	public void retrieveAgreementCustomerReference() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException {
		
		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setCommercialContractNumber("1234567890");
		agreementCustomerReferenceView.setProductId("12345");
		agreementCustomerReferenceView.setCustomerId("101");
		agreementCustomerReferenceView.setStatus("2");
		agreementCustomerReferenceView.setId("CHG929098");
		Calendar clock = Calendar.getInstance();
		clock.set(Calendar.MILLISECOND, 0);
		clock.set(2020, 01, 15, 20, 40, 55);
		Timestamp createDate = new Timestamp(clock.getTimeInMillis());
		agreementCustomerReferenceView.setDateCreated(createDate);
		agreementCustomerReferenceView.setNickName("savings account");

		List<BuildingBlockView> buildingBlockViewList = new ArrayList<BuildingBlockView>();
		BuildingBlockView buildingBlockView = new BuildingBlockView();
		buildingBlockView.setBuildingBlockId(5);
		buildingBlockView.setBuildingBlockReferenceContractId("1234567890");
		buildingBlockViewList.add(buildingBlockView);
		agreementCustomerReferenceView.setBuildingBlockViewList(buildingBlockViewList);

		Mockito.when(agreementCustomerReferenceDAO.retrieveAgreementCustomerReference("CHG929098")).thenReturn(agreementCustomerReferenceView);

		GetAgreementCustomerReferenceResponse expectedAgreementCustomerReference = new GetAgreementCustomerReferenceResponse();
		expectedAgreementCustomerReference.setProductId("12345");
		expectedAgreementCustomerReference.setCustomerId("101");
		expectedAgreementCustomerReference.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ACTIVE);
		expectedAgreementCustomerReference.setAgreementCustomerReferenceId("CHG929098");
		expectedAgreementCustomerReference.setCommercialAgreementId("1234567890");
		expectedAgreementCustomerReference.setReferenceStartDate("2020-02-15");
		expectedAgreementCustomerReference.setAgreementNickName("savings account");
		expectedAgreementCustomerReference.setPackageSettlementAccountNumber(null);
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("5");
		agreementAdministrationReference.setAgreementAdministrationReferenceId("1234567890");
		expectedAgreementCustomerReference.setAgreementAdministrationReferences(new ArrayList<>());
		expectedAgreementCustomerReference.addAgreementAdministrationReferencesItem(agreementAdministrationReference);

//		RetrieveAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(RetrieveAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doReturn(expectedAgreementCustomerReference).when(requestProcessor).processRetrieveAgreementCustomerReference("CHG929098", false);

		GetAgreementCustomerReferenceResponse agreementCustomerReference = requestProcessor.processRetrieveAgreementCustomerReference("CHG929098", false);
		
		assertEquals("12345", agreementCustomerReference.getProductId());
		assertEquals("101", agreementCustomerReference.getCustomerId());
		assertEquals("ACTIVE", agreementCustomerReference.getAgreementLifeCycleStatus().getValue());
		assertEquals("CHG929098", agreementCustomerReference.getAgreementCustomerReferenceId());
		assertEquals("1234567890", agreementCustomerReference.getCommercialAgreementId());
		assertEquals("2020-02-15", agreementCustomerReference.getReferenceStartDate());
		assertEquals("savings account", agreementCustomerReference.getAgreementNickName());
		assertNull(agreementCustomerReference.getPackageSettlementAccountNumber());
		assertEquals(new String("5"), agreementCustomerReference.getAgreementAdministrationReferences().get(0).getAgreementAdministrationId());
		assertEquals("1234567890", agreementCustomerReference.getAgreementAdministrationReferences().get(0).getAgreementAdministrationReferenceId());
	}
	@Test
	public void retrieveLinkedAgreementCustomerReferences() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException {

		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setCommercialContractNumber("1234567890");
		agreementCustomerReferenceView.setProductId("12345");
		agreementCustomerReferenceView.setCustomerId("101");
		agreementCustomerReferenceView.setStatus("2");
		agreementCustomerReferenceView.setId("CHG929098");
		agreementCustomerReferenceView.setParentId("PAR009900");
		agreementCustomerReferenceView.setNickName("savings account");
		Calendar clock = Calendar.getInstance();
		clock.set(Calendar.MILLISECOND, 0);
		clock.set(2020, 01, 15, 20, 40, 55);
		Timestamp createDate = new Timestamp(clock.getTimeInMillis());
		agreementCustomerReferenceView.setDateCreated(createDate);

		List<BuildingBlockView> buildingBlockViewList = new ArrayList<BuildingBlockView>();
		BuildingBlockView buildingBlockView = new BuildingBlockView();
		buildingBlockView.setBuildingBlockId(5);
		buildingBlockView.setBuildingBlockReferenceContractId("1234567890");
		buildingBlockViewList.add(buildingBlockView);
		agreementCustomerReferenceView.setBuildingBlockViewList(buildingBlockViewList);
		
		List<AgreementCustomerReferenceView> linkedRefList= new ArrayList<>();
		AgreementCustomerReferenceView linkedRef = new AgreementCustomerReferenceView();
		linkedRef.setCommercialContractNumber("1234567909");
		linkedRef.setProductId("4421");
		linkedRef.setCustomerId("101");
		linkedRef.setStatus("2");
		linkedRef.setId("CHG929089");
		linkedRef.setParentId("CHG929098");
		linkedRef.setNickName("checking account");
		clock = Calendar.getInstance();
		clock.set(Calendar.MILLISECOND, 0);
		clock.set(2020, 01, 15, 20, 40, 55);
		createDate = new Timestamp(clock.getTimeInMillis());
		linkedRef.setDateCreated(createDate);
		linkedRefList.add(linkedRef);
		
		Mockito.when(agreementCustomerReferenceDAO.retrieveAgreementCustomerReference("CHG929098")).thenReturn(agreementCustomerReferenceView);
		Mockito.when(agreementCustomerReferenceDAO.retrieveLinkedAgreementCustomerReferences("CHG929098")).thenReturn(linkedRefList);
		Mockito.when(settlementAccountDao.retrieveSettlementAccountNumber("CHG929098")).thenReturn("0134562345");
		Mockito.when(productValidationDao.getProductType(12345)).thenReturn("P");

		GetAgreementCustomerReferenceResponse expectedAgreementCustomerReference = new GetAgreementCustomerReferenceResponse();
		expectedAgreementCustomerReference.setProductId("12345");
		expectedAgreementCustomerReference.setCustomerId("101");
		expectedAgreementCustomerReference.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ACTIVE);
		expectedAgreementCustomerReference.setAgreementCustomerReferenceId("CHG929098");
		expectedAgreementCustomerReference.setCommercialAgreementId("1234567890");
		expectedAgreementCustomerReference.setReferenceStartDate("2020-02-15");
		expectedAgreementCustomerReference.setAgreementNickName("savings account");
		expectedAgreementCustomerReference.setPackageSettlementAccountNumber("NL76ABNA0134562345");
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("5");
		agreementAdministrationReference.setAgreementAdministrationReferenceId("1234567890");
		expectedAgreementCustomerReference.setAgreementAdministrationReferences(new ArrayList<>());
		expectedAgreementCustomerReference.addAgreementAdministrationReferencesItem(agreementAdministrationReference);
		AgreementCustomerReference agreementCustomerReference1 = new AgreementCustomerReference();
		expectedAgreementCustomerReference.setLinkedAgreementReferences(new ArrayList<>());
		expectedAgreementCustomerReference.addLinkedAgreementReferencesItem(agreementCustomerReference1);

//		RetrieveAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(RetrieveAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doReturn(expectedAgreementCustomerReference).when(requestProcessor).processRetrieveAgreementCustomerReference("CHG929098", true);

		GetAgreementCustomerReferenceResponse response = requestProcessor.processRetrieveAgreementCustomerReference("CHG929098",true);

		assertEquals(response.getProductId(), "12345");
		assertEquals(response.getCustomerId(), "101");
		assertEquals(response.getAgreementLifeCycleStatus().getValue(), "ACTIVE");
		assertEquals(response.getAgreementCustomerReferenceId(), "CHG929098");
		assertEquals(response.getCommercialAgreementId(), "1234567890");
		assertEquals("2020-02-15", response.getReferenceStartDate());
		assertEquals("NL76ABNA0134562345", response.getPackageSettlementAccountNumber());
		assertEquals("savings account", response.getAgreementNickName());
		assertEquals(response.getAgreementAdministrationReferences().get(0).getAgreementAdministrationId(), new String("5"));
		assertEquals(response.getAgreementAdministrationReferences().get(0).getAgreementAdministrationReferenceId(), "1234567890");
		assertFalse(response.getLinkedAgreementReferences().isEmpty());
	}
	
	@Test
	public void validateResourceNotFound() throws AgreementCustomerReferenceDAOException, AgreementCustomerReferenceApplicationException, PartyManagementConnectException {
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("2");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		AgreementCustomerReferenceForPatch updateRequestInput = new AgreementCustomerReferenceForPatch();
		updateRequestInput.setAgreementLifeCycleStatus("ACTIVE");
		updateRequestInput.setProductId("347");
		updateRequestInput.setCustomerId("35");
		
//		Mockito.when(agreementCustomerReferenceDAO.getAgreementCustomerReference("AAA123456")).thenReturn(null);
//
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);

//		AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException("4033", 400);
//		RetrieveAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(RetrieveAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doThrow(exception).when(requestProcessor).processRetrieveAgreementCustomerReference("AAA123456", false);

		try {
			requestProcessor.processRetrieveAgreementCustomerReference("AAA123456", false);
			Assertions.fail("exceptions excepted");
		} catch (AgreementCustomerReferenceApplicationException e) {
			assertEquals(e.getMessage(), "4033");
		}
	}
	
}
