package com.abnamro.moa.services.agreementcustomerreference.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class IbanUtilsTest {
	@Test
	public void convertBbanToIban() {
		Assertions.assertEquals("NL45ABNA0417264941", IbanUtils.convertToIBAN("0417264941"));
		Assertions.assertEquals("NL95ABNA0558225314", IbanUtils.convertToIBAN("0558225314"));
	}
}
