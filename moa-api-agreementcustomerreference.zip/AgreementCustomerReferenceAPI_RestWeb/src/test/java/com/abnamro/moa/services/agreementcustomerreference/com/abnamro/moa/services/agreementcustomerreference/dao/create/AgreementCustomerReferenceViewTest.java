package com.abnamro.moa.services.agreementcustomerreference.com.abnamro.moa.services.agreementcustomerreference.dao.create;

import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AgreementCustomerReferenceViewTest {
    @Test
    void create() {
        AgreementCustomerReferenceView agreementCustomerReference = new AgreementCustomerReferenceView();

        Assertions.assertNotNull(agreementCustomerReference);
        Assertions.assertNull(agreementCustomerReference.getId());
        Assertions.assertNull(agreementCustomerReference.getNickName());
        Assertions.assertNull(agreementCustomerReference.getStatus());
        Assertions.assertNull(agreementCustomerReference.getDateCreated());
        Assertions.assertNull(agreementCustomerReference.getDateModified());
        Assertions.assertNull(agreementCustomerReference.getUserId());
        Assertions.assertNull(agreementCustomerReference.getParentId());
        Assertions.assertNull(agreementCustomerReference.getCommercialContractNumber());
        Assertions.assertNull(agreementCustomerReference.getCustomerId());
        Assertions.assertNull(agreementCustomerReference.getProductId());
        Assertions.assertNull(agreementCustomerReference.getTransferService());
        Assertions.assertNull(agreementCustomerReference.getBlockingCode());
        Assertions.assertNull(agreementCustomerReference.getBuildingBlockViewList());
    }

    @Test
    void gettersAndSetters() {
        AgreementCustomerReferenceView agreementCustomerReference = new AgreementCustomerReferenceView();

        agreementCustomerReference.setId("10");
        agreementCustomerReference.setNickName("nick name");
        agreementCustomerReference.setStatus("status");

        Calendar clock1 = Calendar.getInstance();
        clock1.set(2023, Calendar.FEBRUARY, 12, 18, 45, 58);
        agreementCustomerReference.setDateCreated(new Timestamp(clock1.getTimeInMillis()));

        Calendar clock2 = Calendar.getInstance();
        clock2.set(2023, Calendar.MARCH, 13, 19, 46, 59);
        agreementCustomerReference.setDateModified(new Timestamp(clock2.getTimeInMillis()));

        agreementCustomerReference.setUserId("user");
        agreementCustomerReference.setParentId("par123");
        agreementCustomerReference.setCommercialContractNumber("34554");
        agreementCustomerReference.setCustomerId("98");
        agreementCustomerReference.setProductId("3452");
        agreementCustomerReference.setTransferService("transfer service");
        agreementCustomerReference.setBlockingCode("blocked");

        List<BuildingBlockView> buildingBlocks = new ArrayList<>();
        BuildingBlockView buildingBlock1 = new BuildingBlockView();
        buildingBlock1.setBuildingBlockId(11);
        buildingBlock1.setBuildingBlockReferenceContractId("sdf2354");
        buildingBlocks.add(buildingBlock1);
        BuildingBlockView buildingBlock2 = new BuildingBlockView();
        buildingBlock2.setBuildingBlockId(23);
        buildingBlock2.setBuildingBlockReferenceContractId("7823sd8");
        buildingBlocks.add(buildingBlock2);
        agreementCustomerReference.setBuildingBlockViewList(buildingBlocks);

        Assertions.assertEquals("10", agreementCustomerReference.getId());
        Assertions.assertEquals("nick name", agreementCustomerReference.getNickName());
        Assertions.assertEquals("status", agreementCustomerReference.getStatus());

        Calendar checkClock = Calendar.getInstance();
        Timestamp createDate = agreementCustomerReference.getDateCreated();
        checkClock.setTimeInMillis(createDate.getTime());
        Assertions.assertEquals(Calendar.FEBRUARY, checkClock.get(Calendar.MONTH));
        Assertions.assertEquals(45, checkClock.get(Calendar.MINUTE));
        Assertions.assertEquals(58, checkClock.get(Calendar.SECOND));

        Timestamp modifiedDate = agreementCustomerReference.getDateModified();
        checkClock.setTimeInMillis(modifiedDate.getTime());
        Assertions.assertEquals(Calendar.MARCH, checkClock.get(Calendar.MONTH));
        Assertions.assertEquals(46, checkClock.get(Calendar.MINUTE));
        Assertions.assertEquals(59, checkClock.get(Calendar.SECOND));

        Assertions.assertEquals("user", agreementCustomerReference.getUserId());
        Assertions.assertEquals("par123", agreementCustomerReference.getParentId());
        Assertions.assertEquals("34554", agreementCustomerReference.getCommercialContractNumber());
        Assertions.assertEquals("98", agreementCustomerReference.getCustomerId());
        Assertions.assertEquals("3452", agreementCustomerReference.getProductId());
        Assertions.assertEquals("transfer service", agreementCustomerReference.getTransferService());
        Assertions.assertEquals("blocked", agreementCustomerReference.getBlockingCode());

        Assertions.assertNotNull(agreementCustomerReference.getBuildingBlockViewList());
        Assertions.assertEquals(2, agreementCustomerReference.getBuildingBlockViewList().size());
        Assertions.assertEquals(11, agreementCustomerReference.getBuildingBlockViewList().get(0).getBuildingBlockId());
        Assertions.assertEquals("sdf2354", agreementCustomerReference.getBuildingBlockViewList().get(0).getBuildingBlockReferenceContractId());
        Assertions.assertEquals(23, agreementCustomerReference.getBuildingBlockViewList().get(1).getBuildingBlockId());
        Assertions.assertEquals("7823sd8", agreementCustomerReference.getBuildingBlockViewList().get(1).getBuildingBlockReferenceContractId());
    }
}
