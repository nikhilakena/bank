package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

//import org.easymock.Mock;
import com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator.AgreementCustomerReferenceValidator;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.AgreementCustomerReferenceDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.ResponsiblePartyDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.SettlementAccountDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.mapper.BuildingBlockMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.Matchers;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation.AgreementCustomerReferencePackageValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementLifeCycleStatusTypeEnum;

import com.abnamro.nl.commondt.v3.ReferenceContext;
import com.abnamro.nl.dao.util.DAODatabaseException;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnect;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnectException;
import com.abnamro.nl.partymanagementobjects.v4.Party;
import com.abnamro.nl.partymanagementobjects.v4.PartyDetails;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsRequestTO;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;

import javax.inject.Inject;

//@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ContextConfiguration
public class CreateAgreementCustomerReferenceRequestProcessorTest {

	@Mock
	Connection connection;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceDAO createDao;
	
	//	@MockBean
	@Mock
	private SettlementAccountDAO settlementAccountDao;
	
	//	@MockBean
	@Mock
	private ResponsiblePartyDAO responsiblePartyDao;
	
	//	@MockBean
	@Mock
	private BuildingBlockDAO buildingBlockDao;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferencePackageValidationDAO agreementCustomerReferencePackageValidationDao;

	//	@MockBean
	@Mock
	private AgreementCustomerReferenceProductValidationDAO productValidationDao;
	
	//	@MockBean
	@Mock
	private ConnectionProvider connectionProvider;
	
	//	@MockBean
	@Mock
	private PartyManagementConnect partyManagementConnect;

	@Mock
	private AgreementCustomerReferenceRequestProcessorUtils processorUtils;
	@Mock
	private AgreementCustomerReferenceValidator agreementCustomerReferenceValidator;
	@Mock
	private AgreementCustomerReferenceDAOInvoker agreementCustomerReferenceDAOInvoker;
	@Mock
	private ResponsiblePartyDAOInvoker responsiblePartyDAOInvoker;
	@Mock
	private BuildingBlockMapper buildingBlockMapper;
	@Mock
	private PublishAgreementCustomerReferenceHelper publishAgreementCustomerReferenceHelper;
	@Mock
	private SettlementAccountDAOInvoker settlementAccountDAOInvoker;

	//	@Autowired
//	@Mock
//	@Inject
	@InjectMocks
//	private CreateAgreementCustomerReferenceRequestProcessor requestProcessor;
	private CreateAgreementCustomerReferenceRequestProcessor requestProcessor = new CreateAgreementCustomerReferenceRequestProcessorImpl();
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceExternalPublisher agreementCustomerReferencePublisher;
	
	@Test
	public void createSingleBBProductTest() throws AgreementCustomerReferenceDAOException , AgreementCustomerReferenceApplicationException, PartyManagementConnectException, DAODatabaseException {
		
		String consumerId = "c1234";
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("1234");
		
		AgreementCustomerReference createRequestInput = new AgreementCustomerReference();
		createRequestInput.setCustomerId("1234");
		createRequestInput.setProductId("123");
		createRequestInput.setAgreementAdministrationReferences(agreementAdministrationReferences);
		createRequestInput.setCommercialAgreementId("0123456789");
		createRequestInput.setAgreementNickName("abcd");
		createRequestInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ACTIVE);
		createRequestInput.setParentAgreementCustomerReferenceId("abcd");
		createRequestInput.setOrganisationUnitId("1234");
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView.setBuildingBlockId(1234);
		buildingBlockClusterTypeView.setBuildingBlockType("C");
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView);
		
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
		
		Mockito.when(buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(createRequestInput.getProductId()))).thenReturn(buildingBlockClusterTypeViewList);
		
		Mockito.when(connectionProvider.getConnection()).thenReturn(connection);
		
		Mockito.when(agreementCustomerReferenceDAOInvoker.createAgreementCustomerReference(connection, createRequestInput, consumerId)).thenReturn("A123456");

		String response = requestProcessor.processCreateAgreementCustomerReferenceRequest(createRequestInput, consumerId);

		Assertions.assertEquals("A123456", response);
	}
	
	@Test
	public void createSingleBBProductWithValidIBANTest() throws AgreementCustomerReferenceDAOException , AgreementCustomerReferenceApplicationException, PartyManagementConnectException, DAODatabaseException {
		
		String consumerId = "c1234";
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("1234");
		
		AgreementCustomerReference createRequestInput = new AgreementCustomerReference();
		createRequestInput.setCustomerId("123");
		createRequestInput.setProductId("123");
		createRequestInput.setAgreementAdministrationReferences(agreementAdministrationReferences);
		createRequestInput.setCommercialAgreementId("0123456789");
		createRequestInput.setAgreementNickName("abcd");
		createRequestInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ACTIVE);
		createRequestInput.setParentAgreementCustomerReferenceId("abcd");
		createRequestInput.setOrganisationUnitId("1234");
		createRequestInput.setPackageSettlementAccountNumber("NL02ABNA0123456789");
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView.setBuildingBlockId(1234);
		buildingBlockClusterTypeView.setBuildingBlockType("C");
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView);
		
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
		
//		Mockito.when(buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(createRequestInput.getProductId()))).thenReturn(buildingBlockClusterTypeViewList);
		
		Mockito.when(connectionProvider.getConnection()).thenReturn(connection);
		
//		Mockito.when(createDao.createAgreementCustomerReference(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(AgreementCustomerReferenceView.class))).thenReturn("A123456");
		Mockito.when(agreementCustomerReferenceDAOInvoker.createAgreementCustomerReference(connection, createRequestInput, consumerId)).thenReturn("A123456");

//		CreateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(CreateAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doReturn("A123456").when(requestProcessor).processCreateAgreementCustomerReferenceRequest(createRequestInput, consumerId);

		String response = requestProcessor.processCreateAgreementCustomerReferenceRequest(createRequestInput, consumerId);

		Assertions.assertEquals("A123456", response);
	}
	
	@Test
	public void createBasicDoubleBBProductTest() throws AgreementCustomerReferenceDAOException , AgreementCustomerReferenceApplicationException, PartyManagementConnectException, DAODatabaseException {
		
		String consumerId = "c1234";
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("1234");
		
		AgreementCustomerReference createRequestInput = new AgreementCustomerReference();
		createRequestInput.setCustomerId("123");
		createRequestInput.setProductId("123");
		createRequestInput.setAgreementAdministrationReferences(agreementAdministrationReferences);
		createRequestInput.setCommercialAgreementId("0123456789");
		createRequestInput.setAgreementNickName("abcd");
		createRequestInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ACTIVE);
		createRequestInput.setParentAgreementCustomerReferenceId("abcd");
		createRequestInput.setOrganisationUnitId("1234");
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView1 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView1.setBuildingBlockId(5);
		buildingBlockClusterTypeView1.setBuildingBlockType("C");
		BuildingBlockClusterTypeView buildingBlockClusterTypeView2 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView2.setBuildingBlockId(19);
		buildingBlockClusterTypeView2.setBuildingBlockType("C");
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView1);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView2);
		
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
		
		Mockito.when(buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(createRequestInput.getProductId()))).thenReturn(buildingBlockClusterTypeViewList);
		
		Mockito.when(connectionProvider.getConnection()).thenReturn(connection);
		
//		Mockito.when(createDao.createAgreementCustomerReference(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(AgreementCustomerReferenceView.class))).thenReturn("A123456");
		Mockito.when(agreementCustomerReferenceDAOInvoker.createAgreementCustomerReference(connection, createRequestInput, consumerId)).thenReturn("A123456");

//		CreateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(CreateAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doReturn("A123456").when(requestProcessor).processCreateAgreementCustomerReferenceRequest(createRequestInput, consumerId);

		String response = requestProcessor.processCreateAgreementCustomerReferenceRequest(createRequestInput, consumerId);

		Assertions.assertEquals("A123456", response);
	}
	
	@Test
	public void createBasicAndGenericBBProductTest() throws AgreementCustomerReferenceDAOException , AgreementCustomerReferenceApplicationException, PartyManagementConnectException, DAODatabaseException {
		
		String consumerId = "c1234";
		
		List<AgreementAdministrationReference> agreementAdministrationReferences = new ArrayList<AgreementAdministrationReference>();
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("1234");
		
		AgreementCustomerReference createRequestInput = new AgreementCustomerReference();
		createRequestInput.setCustomerId("123");
		createRequestInput.setProductId("123");
		createRequestInput.setAgreementAdministrationReferences(agreementAdministrationReferences);
		createRequestInput.setCommercialAgreementId("0123456789");
		createRequestInput.setAgreementNickName("abcd");
		createRequestInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ACTIVE);
		createRequestInput.setParentAgreementCustomerReferenceId("abcd");
		createRequestInput.setOrganisationUnitId("1234");
		
		RetrievePartyDetailsResponseTO retrievePartyDetailsResponseTO = new RetrievePartyDetailsResponseTO();
		PartyDetails partydetails = new PartyDetails();
		Party party = new Party();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setScheme("Business contact life cycle status type");
		referenceContext.setValue("1");
		party.setPartyLifeCycleStatusTypeId(referenceContext);
		partydetails.setParty(party);
		retrievePartyDetailsResponseTO.setPartyDetails(partydetails);
		
		List<BuildingBlockClusterTypeView> buildingBlockClusterTypeViewList = new ArrayList<BuildingBlockClusterTypeView>();
		BuildingBlockClusterTypeView buildingBlockClusterTypeView1 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView1.setBuildingBlockId(5);
		buildingBlockClusterTypeView1.setBuildingBlockType("C");
		BuildingBlockClusterTypeView buildingBlockClusterTypeView2 = new BuildingBlockClusterTypeView();
		buildingBlockClusterTypeView2.setBuildingBlockId(101);
		buildingBlockClusterTypeView2.setBuildingBlockType("F");
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView1);
		buildingBlockClusterTypeViewList.add(buildingBlockClusterTypeView2);
		
//		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any(RetrievePartyDetailsRequestTO.class))).thenReturn(retrievePartyDetailsResponseTO);
		
		Mockito.when(buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(createRequestInput.getProductId()))).thenReturn(buildingBlockClusterTypeViewList);
		
		Mockito.when(connectionProvider.getConnection()).thenReturn(connection);
		
//		Mockito.when(createDao.createAgreementCustomerReference(ArgumentMatchers.any(Connection.class), ArgumentMatchers.any(AgreementCustomerReferenceView.class))).thenReturn("A123456");
		Mockito.when(agreementCustomerReferenceDAOInvoker.createAgreementCustomerReference(connection, createRequestInput, consumerId)).thenReturn("A123456");

//		CreateAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(CreateAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doReturn("A123456").when(requestProcessor).processCreateAgreementCustomerReferenceRequest(createRequestInput, consumerId);

		String response = requestProcessor.processCreateAgreementCustomerReferenceRequest(createRequestInput, consumerId);
		Assertions.assertEquals("A123456", response);
	}
}