package com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class BuildingBlockViewTest {
/*
	private String buildingBlockReferenceContractId;
	private int productId;
	private int clusterId;
	private int buildingBlockId;
	private String contractHeaderId;
	private String buildingBlockType;
 */
    @Test
    void create() {
        BuildingBlockView buildingBlock = new BuildingBlockView();

        Assertions.assertNotNull(buildingBlock);
        Assertions.assertNull(buildingBlock.getBuildingBlockReferenceContractId());
        Assertions.assertEquals(0, buildingBlock.getProductId());
        Assertions.assertEquals(0, buildingBlock.getClusterId());
        Assertions.assertEquals(0, buildingBlock.getBuildingBlockId());
        Assertions.assertNull(buildingBlock.getContractHeaderId());
        Assertions.assertNull(buildingBlock.getBuildingBlockType());
    }

    @Test
    void gettersAndSetters() {
        BuildingBlockView buildingBlock = new BuildingBlockView();
        buildingBlock.setBuildingBlockReferenceContractId("10");
        buildingBlock.setProductId(11);
        buildingBlock.setClusterId(12);
        buildingBlock.setBuildingBlockId(13);
        buildingBlock.setContractHeaderId("14");
        buildingBlock.setBuildingBlockType("15");

        Assertions.assertNotNull(buildingBlock);
        Assertions.assertEquals("10", buildingBlock.getBuildingBlockReferenceContractId());
        Assertions.assertEquals(11, buildingBlock.getProductId());
        Assertions.assertEquals(12, buildingBlock.getClusterId());
        Assertions.assertEquals(13, buildingBlock.getBuildingBlockId());
        Assertions.assertEquals("14", buildingBlock.getContractHeaderId());
        Assertions.assertEquals("15", buildingBlock.getBuildingBlockType());
    }
}
