package com.abnamro.moa.services.agreementcustomerreference.dao.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AgreementCustomerReferenceIdTest {
    @Test
    void invalidAgreementCustomerReferenceId1() {
        AgreementCustomerReferenceId id = new AgreementCustomerReferenceId("SDFA123123");
        Assertions.assertNotNull(id);
        Assertions.assertFalse(id.isValidFormat());
        Assertions.assertNull(id.getLiteralPart());
        Assertions.assertNull(id.getNumericPart());
        Assertions.assertNull(id.generateNextId());
    }

    @Test
    void invalidAgreementCustomerReferenceId2() {
        AgreementCustomerReferenceId id = new AgreementCustomerReferenceId("SDF1231234");
        Assertions.assertNotNull(id);
        Assertions.assertFalse(id.isValidFormat());
        Assertions.assertNull(id.getLiteralPart());
        Assertions.assertNull(id.getNumericPart());
        Assertions.assertNull(id.generateNextId());
    }

    @Test
    void validAgreementCustomerReferenceId() {
        AgreementCustomerReferenceId id = new AgreementCustomerReferenceId("SDF123123");
        Assertions.assertNotNull(id);
        Assertions.assertTrue(id.isValidFormat());
        Assertions.assertEquals("SDF", id.getLiteralPart());
        Assertions.assertEquals("123123", id.getNumericPart());
        Assertions.assertEquals("SDF123124", id.generateNextId());
    }
}
