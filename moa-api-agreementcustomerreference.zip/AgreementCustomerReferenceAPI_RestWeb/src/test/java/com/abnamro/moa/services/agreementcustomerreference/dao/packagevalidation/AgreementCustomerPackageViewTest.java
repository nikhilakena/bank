package com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation;

import org.apache.logging.log4j.core.util.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

class AgreementCustomerPackageViewTest {
    @Test
    void createAgreementCustomerPackageView() {
        AgreementCustomerPackageView view = new AgreementCustomerPackageView();
        Assertions.assertNull(view.getChId());
        Assertions.assertNull(view.getStatus());
        Assertions.assertNull(view.getNickname());
        Assertions.assertNull(view.getBbIdList());
        Assertions.assertEquals(0, view.getProductId());
        Assertions.assertEquals(0, view.getOrderId());
        Assertions.assertNull(view.getIBAN());
    }

    @Test
    void settersAndGetters() {
        AgreementCustomerPackageView packageView = new AgreementCustomerPackageView();
        packageView.setChId("chid");
        Assertions.assertEquals("chid", packageView.getChId());

        packageView.setStatus("status");
        Assertions.assertEquals("status", packageView.getStatus());

        packageView.setNickname("nickname");
        Assertions.assertEquals("nickname", packageView.getNickname());

        List<Integer> buildingBlockList = new ArrayList<>();
        buildingBlockList.add(1);
        buildingBlockList.add(8);
        packageView.setBbIdList(buildingBlockList);
        Assertions.assertNotNull(packageView.getBbIdList());
        Assertions.assertEquals(2, packageView.getBbIdList().size());
        Assertions.assertEquals(8, packageView.getBbIdList().get(1));

        packageView.setProductId(12);
        Assertions.assertEquals(12, packageView.getProductId());

        packageView.setOrderId(34);
        Assertions.assertEquals(34, packageView.getOrderId());

        packageView.setIBAN("iban");
        Assertions.assertEquals("iban", packageView.getIBAN());
    }
}
