package com.abnamro.moa.services.agreementcustomerreference.com.abnamro.moa.services.agreementcustomerreference.dao.create;

import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAOImpl;
import org.apache.ibatis.session.SqlSession;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Connection;

@ExtendWith(MockitoExtension.class)
public class AgreementCustomerReferenceDAOImplTest {
    @Mock
    private ConnectionProvider connectionProvider;
    @Mock
    private Connection connection;
    @Mock
    private SqlSession sqlSession;


    @InjectMocks
    private AgreementCustomerReferenceDAO dao = new AgreementCustomerReferenceDAOImpl();

    @Test
    void create() {
        try {
            AgreementCustomerReferenceDAOImpl daoImpl = new AgreementCustomerReferenceDAOImpl();
        } catch (Exception exception) {
            Assertions.fail("no exception accepted");
        }
    }
}
