package com.abnamro.moa.services.agreementcustomerreference.controller;

import com.abnamro.moa.services.agreementcustomerreference.configuration.RequestScopeBeans;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.Errors;
import org.apache.logging.log4j.core.util.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.mock.http.MockHttpInputMessage;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class AgreementCustomerReferenceExceptionHandlerTest {
    @Mock
    private Environment env;
    @Mock
    private RequestScopeBeans requestScopeBeans;

    @InjectMocks
    private AgreementCustomerReferenceExceptionHandler handler;

    @Test
    void handleMethodArgumentNotValid() {
        ResponseEntity<Object> response = handler.handleMethodArgumentNotValid(null, null, null, null);

        Assertions.assertNotNull(response);
        Assertions.assertNotNull(response.getStatusCode());
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        Assertions.assertNotNull(response.getBody());

        Errors errors = (Errors) response.getBody();
        Assertions.assertNotNull(errors);
        Assertions.assertEquals(1, errors.getErrors().size());

        com.abnamro.moa.services.agreementcustomerreference.resourcemodel.Error error = errors.getErrors().get(0);
        Assertions.assertEquals("400", error.getStatus());
        Assertions.assertNull(error.getParams());
    }

    @Test
    void handleHttpMessageNotReadable() {
        String httpInputMessage = "http input message";
        HttpInputMessage inputMessage = new MockHttpInputMessage(httpInputMessage.getBytes(StandardCharsets.UTF_8));
        HttpMessageNotReadableException exception = new HttpMessageNotReadableException("exception message", inputMessage);

        HttpHeaders header = new HttpHeaders();
        header.add("header1", "parameter1");
        ResponseEntity<Object> response = handler.handleHttpMessageNotReadable(exception, header, HttpStatus.NO_CONTENT, null);

        Assertions.assertNotNull(response);
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        Assertions.assertNotNull(response.getBody());

        Object responseObject = response.getBody();
        Errors errors = (Errors) responseObject;
        Assertions.assertEquals(1, errors.getErrors().size());

        com.abnamro.moa.services.agreementcustomerreference.resourcemodel.Error error = errors.getErrors().get(0);
        Assertions.assertNull(error.getParams());
        Assertions.assertEquals("exception message", error.getMessage());
        Assertions.assertEquals("400 BAD_REQUEST", error.getStatus());
        Assertions.assertEquals("JSON_PARSE_ERROR", error.getCode());
    }

    @Test
    void handleAgreementCustomerReferenceException() {
        String message = "exception message";
        List<String> parameters = new ArrayList<>();
        parameters.add("parameter 1");
        parameters.add("parameter 2");
        AgreementCustomerReferenceApplicationException exception = new AgreementCustomerReferenceApplicationException(message, HttpStatus.BAD_REQUEST, parameters);
        ResponseEntity<Errors> response = handler.handleAgreementCustomerReferenceException(exception);

        Assertions.assertNotNull(response);
        Errors errors = response.getBody();
        Assertions.assertNotNull(errors);
        Assertions.assertEquals(1, errors.getErrors().size());
        com.abnamro.moa.services.agreementcustomerreference.resourcemodel.Error error = errors.getErrors().get(0);
        Assertions.assertEquals("400", error.getStatus());
        Assertions.assertEquals("parameter 1", error.getParams());
        Assertions.assertNull(error.getMessage());
    }

    @Test
    void handleGeneralException() {
        Exception exception = new Exception("exception message");
        ResponseEntity<Errors> response = handler.handleGeneralException(exception, null);

        Assertions.assertNotNull(response);
        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        Errors errors = response.getBody();
        Assertions.assertNotNull(errors.getErrors());
        Assertions.assertEquals(1, errors.getErrors().size());
        com.abnamro.moa.services.agreementcustomerreference.resourcemodel.Error error = errors.getErrors().get(0);
        Assertions.assertNotNull(error);
        Assertions.assertNull(error.getCode());
        Assertions.assertNull(error.getMessage());
        Assertions.assertNull(error.getParams());
        Assertions.assertEquals("500", error.getStatus());
        Assertions.assertNull(error.getParams());
        Assertions.assertNull(error.getMessage());
    }
}
