package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.generic.agreementcustomerreference.publisher.exceptions.AgreementCustomerReferenceExternalPublisherException;
import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.AgreementCustomerReferenceDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.ResponsiblePartyDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.daoinvoker.SettlementAccountDAOInvoker;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

//@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ContextConfiguration
public class DeleteAgreementCustomerReferenceRequestProcessorTest {
	//	//	@MockBean
	@Mock
	Connection connection;
	
	//	//	@MockBean
	@Mock
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDAO;

	//	@MockBean
	@Mock
	private ConnectionProvider connectionProvider;
	
//	@Autowired
//	private DeleteAgreementCustomerReferenceRequestProcessor deleteAgreementCustomerReferenceRequestProcessor;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceExternalPublisher agreementCustomerReferencePublisher;

	//	@MockBean
	@Mock
	private PublishAgreementCustomerReferenceHelper publishAgreementCustomerReferenceHelper;

	//	@MockBean
	@Mock
	private SettlementAccountDAOInvoker settlementAccountDAO;

	//	@MockBean
	@Mock
	private ResponsiblePartyDAOInvoker responsiblePartyDAO;

	//	@MockBean
	@Mock
	private BuildingBlockDAO buildingBlockDao;

	@Mock
	private AgreementCustomerReferenceDAOInvoker agreementCustomerReferenceDAOinvoker;

	@InjectMocks
	DeleteAgreementCustomerReferenceRequestProcessor requestProcessor;

	@Test
	public void deleteNotExistingAgreementCustomerReference() throws AgreementCustomerReferenceApplicationException {
		String agreementCustomerReferenceId = "ZZZ999999";
		String customerId = "CONS1";

//		AgreementCustomerReferenceApplicationException expectedException = new AgreementCustomerReferenceApplicationException("4028", 400);
//		DeleteAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(DeleteAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doThrow(expectedException).when(requestProcessor).processDeleteOfAgreementCustomerReference(agreementCustomerReferenceId, customerId);

		try {
//			Mockito.when(agreementCustomerReferenceDAO.existsAgreementCustomerReference(agreementCustomerReferenceId)).thenReturn(false);

			requestProcessor.processDeleteOfAgreementCustomerReference(agreementCustomerReferenceId, customerId);
			fail("expected an exception");
		} catch (AgreementCustomerReferenceApplicationException exception) {
			assertEquals("4028", exception.getMessage());
		}
	}

	@Test
	public void deleteExistingAgreementCustomerReference() {
		String agreementCustomerReferenceId = "ZZZ999999";
		String consumerId = "CONS2";
		String productId = "8989";
		Connection connection = null;
		List<BuildingBlockClusterTypeView> emptyBuildingBlockClusterTypeList = new ArrayList<>();
		AgreementCustomerReferenceView persistentAgreementCustomerReference = new AgreementCustomerReferenceView();
		persistentAgreementCustomerReference.setId(agreementCustomerReferenceId);
		persistentAgreementCustomerReference.setProductId(productId);

//		DeleteAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(DeleteAgreementCustomerReferenceRequestProcessor.class);

		try {
			Mockito.when(agreementCustomerReferenceDAO.retrieveAgreementCustomerReference(agreementCustomerReferenceId)).thenReturn(persistentAgreementCustomerReference);
//			Mockito.when(buildingBlockDao.getBuildingBlockDetailsForProduct(Integer.parseInt(productId))).thenReturn(emptyBuildingBlockClusterTypeList);
//			Mockito.doNothing().when(publishAgreementCustomerReferenceHelper).publishDeleteAgreementCustomerReference(persistentAgreementCustomerReference, emptyBuildingBlockClusterTypeList, agreementCustomerReferenceId, consumerId);
//			Mockito.when(responsiblePartyDAO.getResponsibleParty(agreementCustomerReferenceId)).thenReturn(null);
//			Mockito.doNothing().when(settlementAccountDAO).deleteSettlementAccount(connection, agreementCustomerReferenceId);

			requestProcessor.processDeleteOfAgreementCustomerReference(agreementCustomerReferenceId, consumerId);
		} catch (AgreementCustomerReferenceApplicationException | AgreementCustomerReferenceDAOException exception) {
			fail("not expected an exception");
		}
	}
}
