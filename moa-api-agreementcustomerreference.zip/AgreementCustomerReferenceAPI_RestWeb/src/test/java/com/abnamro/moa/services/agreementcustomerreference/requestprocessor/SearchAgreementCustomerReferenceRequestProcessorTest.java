package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import com.abnamro.moa.generic.agreementcustomerreference.publisher.AgreementCustomerReferenceExternalPublisher;
import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.dao.ConnectionProvider;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockView;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceView;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.packagevalidation.AgreementCustomerReferencePackageValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.settlement.SettlementAccountDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementLifeCycleStatusTypeEnum;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnect;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

//@ExtendWith(SpringExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ExtendWith(MockitoExtension.class)
@ContextConfiguration
public class SearchAgreementCustomerReferenceRequestProcessorTest {
	
	//	@MockBean
	@Mock
	Connection connection;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceDAO agreementCustomerReferenceDAO;
	
	//	@MockBean
	@Mock
	private SettlementAccountDAO settlementAccountDao;
	
	//	@MockBean
	@Mock
	private ResponsiblePartyDAO responsiblePartyDao;
	
	//	@MockBean
	@Mock
	private BuildingBlockDAO buildingBlockDao;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferencePackageValidationDAO agreementCustomerReferencePackageValidationDao;

	//	@MockBean
	@Mock
	private AgreementCustomerReferenceProductValidationDAO productValidationDao;
	
	//	@MockBean
	@Mock
	private ConnectionProvider connectionProvider;
	
	//	@MockBean
	@Mock
	private PartyManagementConnect partyManagementConnect;
	
//	@Autowired
//	private SearchAgreementCustomerReferenceRequestProcessor requestProcessor;
	
	//	@MockBean
	@Mock
	private AgreementCustomerReferenceExternalPublisher agreementCustomerReferencePublisher;

	@InjectMocks
	private SearchAgreementCustomerReferenceRequestProcessor requestProcessor;

	@Test
	public void searchAgreementCustomerReference() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException {
		
		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setCommercialContractNumber("1234567890");
		agreementCustomerReferenceView.setProductId("12345");
		agreementCustomerReferenceView.setCustomerId("101");
		agreementCustomerReferenceView.setStatus("2");
		agreementCustomerReferenceView.setId("AAA000001");
		Calendar clock = Calendar.getInstance();
		clock.set(Calendar.MILLISECOND, 0);
		clock.set(2020, 01, 15, 20, 40, 55);
		Timestamp createDate = new Timestamp(clock.getTimeInMillis());
		agreementCustomerReferenceView.setDateCreated(createDate);
		agreementCustomerReferenceView.setNickName("first bank account");
		
		List<BuildingBlockView> buildingBlockViewList = new ArrayList<BuildingBlockView>();
		BuildingBlockView buildingBlockView = new BuildingBlockView();
		buildingBlockView.setBuildingBlockId(5);
		buildingBlockView.setBuildingBlockReferenceContractId("1234567890");
		buildingBlockViewList.add(buildingBlockView);
		agreementCustomerReferenceView.setBuildingBlockViewList(buildingBlockViewList);
		
		Mockito.when(agreementCustomerReferenceDAO.retrieveAgreementCustomerReferences("12345", "1234567890", null, null)).thenReturn(agreementCustomerReferenceView);

		AgreementCustomerReference expectedAgreementCustomerReference = new AgreementCustomerReference();
		expectedAgreementCustomerReference.setProductId("12345");
		expectedAgreementCustomerReference.setCustomerId("101");
		expectedAgreementCustomerReference.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ACTIVE);
		expectedAgreementCustomerReference.setAgreementCustomerReferenceId("AAA000001");
		expectedAgreementCustomerReference.setCommercialAgreementId("1234567890");
		expectedAgreementCustomerReference.setReferenceStartDate("2020-02-15");
		expectedAgreementCustomerReference.setPackageSettlementAccountNumber(null);
		expectedAgreementCustomerReference.setAgreementNickName("first bank account");
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("5");
		agreementAdministrationReference.setAgreementAdministrationReferenceId("1234567890");
		expectedAgreementCustomerReference.setAgreementAdministrationReferences(new ArrayList<>());
		expectedAgreementCustomerReference.addAgreementAdministrationReferencesItem(agreementAdministrationReference);

//		SearchAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(SearchAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doReturn(expectedAgreementCustomerReference).when(requestProcessor).processSearchAgreementCustomerReference("12345", "1234567890", null, null);

		AgreementCustomerReference agreementCustomerReference = requestProcessor.processSearchAgreementCustomerReference("12345", "1234567890", null, null);
		
		assertEquals(agreementCustomerReference.getProductId(), "12345");
		assertEquals(agreementCustomerReference.getCustomerId(), "101");
		assertEquals(agreementCustomerReference.getAgreementLifeCycleStatus().getValue(), "ACTIVE");
		assertEquals(agreementCustomerReference.getAgreementCustomerReferenceId(), "AAA000001");
		assertEquals(agreementCustomerReference.getCommercialAgreementId(), "1234567890");
		assertEquals("2020-02-15", agreementCustomerReference.getReferenceStartDate());
		assertNull(agreementCustomerReference.getPackageSettlementAccountNumber());
		assertEquals("first bank account", agreementCustomerReference.getAgreementNickName());
		
		assertEquals(agreementCustomerReference.getAgreementAdministrationReferences().get(0).getAgreementAdministrationId(), new String("5"));
		assertEquals(agreementCustomerReference.getAgreementAdministrationReferences().get(0).getAgreementAdministrationReferenceId(), "1234567890");
	}
	@Test
	public void searchAgreementCustomerReferencePackage() throws AgreementCustomerReferenceApplicationException, AgreementCustomerReferenceDAOException {

		AgreementCustomerReferenceView agreementCustomerReferenceView = new AgreementCustomerReferenceView();
		agreementCustomerReferenceView.setCommercialContractNumber("1234567890");
		agreementCustomerReferenceView.setProductId("12345");
		agreementCustomerReferenceView.setCustomerId("101");
		agreementCustomerReferenceView.setStatus("2");
		agreementCustomerReferenceView.setId("AAA000001");
		agreementCustomerReferenceView.setParentId("PAR009900");
		Calendar clock = Calendar.getInstance();
		clock.set(Calendar.MILLISECOND, 0);
		clock.set(2020, 01, 15, 20, 40, 55);
		Timestamp createDate = new Timestamp(clock.getTimeInMillis());
		agreementCustomerReferenceView.setDateCreated(createDate);
		agreementCustomerReferenceView.setNickName("second bank account");

		List<BuildingBlockView> buildingBlockViewList = new ArrayList<BuildingBlockView>();
		BuildingBlockView buildingBlockView = new BuildingBlockView();
		buildingBlockView.setBuildingBlockId(5);
		buildingBlockView.setBuildingBlockReferenceContractId("1234567890");
		buildingBlockViewList.add(buildingBlockView);
		agreementCustomerReferenceView.setBuildingBlockViewList(buildingBlockViewList);

		Mockito.when(agreementCustomerReferenceDAO.retrieveAgreementCustomerReferences("12345", "1234567890", null, null)).thenReturn(agreementCustomerReferenceView);
		Mockito.when(settlementAccountDao.retrieveSettlementAccountNumber("AAA000001")).thenReturn("0134562345");
		Mockito.when(productValidationDao.getProductType(12345)).thenReturn("P");

		AgreementCustomerReference expectedAgreementCustomerReference = new AgreementCustomerReference();
		expectedAgreementCustomerReference.setProductId("12345");
		expectedAgreementCustomerReference.setCustomerId("101");
		expectedAgreementCustomerReference.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ACTIVE);
		expectedAgreementCustomerReference.setAgreementCustomerReferenceId("AAA000001");
		expectedAgreementCustomerReference.setCommercialAgreementId("1234567890");
		expectedAgreementCustomerReference.setReferenceStartDate("2020-02-15");
		expectedAgreementCustomerReference.setPackageSettlementAccountNumber("NL76ABNA0134562345");
		expectedAgreementCustomerReference.setAgreementNickName("second bank account");
		AgreementAdministrationReference agreementAdministrationReference = new AgreementAdministrationReference();
		agreementAdministrationReference.setAgreementAdministrationId("5");
		agreementAdministrationReference.setAgreementAdministrationReferenceId("1234567890");
		expectedAgreementCustomerReference.setAgreementAdministrationReferences(new ArrayList<>());
		expectedAgreementCustomerReference.addAgreementAdministrationReferencesItem(agreementAdministrationReference);

//		SearchAgreementCustomerReferenceRequestProcessor requestProcessor = Mockito.mock(SearchAgreementCustomerReferenceRequestProcessor.class);
//		Mockito.doReturn(expectedAgreementCustomerReference).when(requestProcessor).processSearchAgreementCustomerReference("12345", "1234567890", null, null);

		AgreementCustomerReference agreementCustomerReference = requestProcessor.processSearchAgreementCustomerReference("12345", "1234567890", null, null);

		assertEquals(agreementCustomerReference.getProductId(), "12345");
		assertEquals(agreementCustomerReference.getCustomerId(), "101");
		assertEquals(agreementCustomerReference.getAgreementLifeCycleStatus().getValue(), "ACTIVE");
		assertEquals(agreementCustomerReference.getAgreementCustomerReferenceId(), "AAA000001");
		assertEquals(agreementCustomerReference.getCommercialAgreementId(), "1234567890");
		assertEquals("2020-02-15", agreementCustomerReference.getReferenceStartDate());
		assertEquals("NL76ABNA0134562345", agreementCustomerReference.getPackageSettlementAccountNumber());
		assertEquals("second bank account", agreementCustomerReference.getAgreementNickName());

		assertEquals(agreementCustomerReference.getAgreementAdministrationReferences().get(0).getAgreementAdministrationId(), new String("5"));
		assertEquals(agreementCustomerReference.getAgreementAdministrationReferences().get(0).getAgreementAdministrationReferenceId(), "1234567890");
	}
}
