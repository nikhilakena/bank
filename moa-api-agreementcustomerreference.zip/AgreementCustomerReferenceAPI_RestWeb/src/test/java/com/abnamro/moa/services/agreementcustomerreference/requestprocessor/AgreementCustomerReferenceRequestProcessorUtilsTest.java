package com.abnamro.moa.services.agreementcustomerreference.requestprocessor;

import com.abnamro.moa.services.agreementcustomerreference.application.AgreementCustomerReferenceAPIApplication;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.responsibleparty.ResponsiblePartyVersionView;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.nl.commondt.v3.ReferenceContext;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnect;
import com.abnamro.nl.partymanagementconnect.implementation.PartyManagementConnectException;
import com.abnamro.nl.partymanagementobjects.v4.Customer;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;
import org.apache.logging.log4j.core.util.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

//@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
//@SpringBootTest(classes = AgreementCustomerReferenceAPIApplication.class)
@ContextConfiguration
public class AgreementCustomerReferenceRequestProcessorUtilsTest {
	@Mock
	private PartyManagementConnect partyManagementConnect;

	@InjectMocks
	private AgreementCustomerReferenceRequestProcessorUtils utils;

	@Test
	void getCustomerDetails() throws AgreementCustomerReferenceApplicationException, PartyManagementConnectException {
		RetrievePartyDetailsResponseTO expectedResponse = new RetrievePartyDetailsResponseTO();
		Customer customer1 = new Customer();
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setValue("value 1");
		customer1.setManagingOrganizationUnitId(referenceContext);
		expectedResponse.setCustomer(customer1);

		Mockito.when(partyManagementConnect.retrievePartyDetails(ArgumentMatchers.any())).thenReturn(expectedResponse);
		RetrievePartyDetailsResponseTO response = utils.getCustomerDetails("1");

		Assertions.assertNotNull(response);
		Assertions.assertEquals("value 1", response.getCustomer().getManagingOrganizationUnitId().getValue());
	}

	@Test
	void retrieveActiveResponsiblePartyVersion() {
		Calendar clock = Calendar.getInstance();

		List<ResponsiblePartyVersionView> parties = new ArrayList<>();
		ResponsiblePartyVersionView party1 = new ResponsiblePartyVersionView();
		party1.setStatus("1");
		clock.set(2023, Calendar.SEPTEMBER, 3, 13, 1, 2);
		party1.setStartDate(new Timestamp(clock.getTimeInMillis()));

		ResponsiblePartyVersionView party2 = new ResponsiblePartyVersionView();
		party2.setStatus("2");
		clock.set(2023, Calendar.SEPTEMBER, 2, 13, 1, 2);
		party2.setStartDate(new Timestamp(clock.getTimeInMillis()));

		ResponsiblePartyVersionView party3 = new ResponsiblePartyVersionView();
		party3.setStatus("3");
		clock.set(2023, Calendar.SEPTEMBER, 1, 13, 1, 2);
		party3.setStartDate(new Timestamp(clock.getTimeInMillis()));

		parties.add(party3);
		parties.add(party2);
		parties.add(party1);

		Assertions.assertEquals(party1, utils.retrieveActiveResponsiblePartyVersion(parties));

		List<ResponsiblePartyVersionView> parties1 = new ArrayList<>();
		parties1.add(party3);
		parties1.add(party2);

		Assertions.assertNull(utils.retrieveActiveResponsiblePartyVersion(parties1));
	}

	@Test
	void getEmptyCustomerBO() {
		ReferenceContext referenceContext = new ReferenceContext();
		Customer customer1 = new Customer();
		customer1.setManagingOrganizationUnitId(referenceContext);
		RetrievePartyDetailsResponseTO partyDetails = new RetrievePartyDetailsResponseTO();
		partyDetails.setCustomer(customer1);

		Assertions.assertNull(utils.getCustomerBO(partyDetails));
	}

	@Test
	void getCustomerBO() {
		ReferenceContext referenceContext = new ReferenceContext();
		referenceContext.setValue("value");
		Customer customer1 = new Customer();
		customer1.setManagingOrganizationUnitId(referenceContext);
		RetrievePartyDetailsResponseTO partyDetails = new RetrievePartyDetailsResponseTO();
		partyDetails.setCustomer(customer1);

		Assertions.assertEquals("value", utils.getCustomerBO(partyDetails));
	}

	@Test
	void findFirstAgreementAdministrationKeyEmptyList() {
		List<BuildingBlockClusterTypeView> types = new ArrayList<>();

		int administrationKey = utils.findFirstAgreementAdministrationKey(types);

		Assertions.assertEquals(0, administrationKey);
	}

	@Test
	void getFirstAgreementAdministrationKeyEmptyLists() {
		List<AgreementAdministrationReference> administrations = new ArrayList<>();
		List<BuildingBlockClusterTypeView> clusterTypes = new ArrayList<>();

		int agreementAdministationKey = utils.getFirstAgreementAdministrationKey(administrations, clusterTypes);

		Assertions.assertEquals(0, agreementAdministationKey);
	}

	@Test
	void getFirstAgreementAdministrationKey() {
		List<AgreementAdministrationReference> administrations = new ArrayList<>();

		AgreementAdministrationReference administration1 = new AgreementAdministrationReference();
		administration1.setAgreementAdministrationId("10");
		administration1.setAgreementAdministrationReferenceId("11");
		administrations.add(administration1);

		AgreementAdministrationReference administration2 = new AgreementAdministrationReference();
		administration2.setAgreementAdministrationId("20");
		administration2.setAgreementAdministrationReferenceId("21");
		administrations.add(administration2);

		List<BuildingBlockClusterTypeView> clusterTypes = new ArrayList<>();

		BuildingBlockClusterTypeView clusterType1 = new BuildingBlockClusterTypeView();
		clusterType1.setBuildingBlockId(10);
		clusterType1.setBuildingBlockType("A");
		clusterTypes.add(clusterType1);

		BuildingBlockClusterTypeView clusterType2 = new BuildingBlockClusterTypeView();
		clusterType2.setBuildingBlockId(20);
		clusterType2.setBuildingBlockType("C");
		clusterTypes.add(clusterType2);

		int agreementAdministationKey = utils.getFirstAgreementAdministrationKey(administrations, clusterTypes);

		Assertions.assertEquals(20, agreementAdministationKey);
	}

	@Test
	void findFirstAgreementAdministrationKey() {
		List<BuildingBlockClusterTypeView> types = new ArrayList<>();

		BuildingBlockClusterTypeView type1 = new BuildingBlockClusterTypeView();
		type1.setBuildingBlockId(11);
		type1.setProductId(12);
		type1.setClusterId(13);
		type1.setBuildingBlockType("A");
		types.add(type1);

		BuildingBlockClusterTypeView type2 = new BuildingBlockClusterTypeView();
		type2.setBuildingBlockId(21);
		type2.setProductId(22);
		type2.setClusterId(23);
		type2.setBuildingBlockType("B");
		types.add(type2);

		BuildingBlockClusterTypeView type3 = new BuildingBlockClusterTypeView();
		type3.setBuildingBlockId(31);
		type3.setProductId(32);
		type3.setClusterId(33);
		type3.setBuildingBlockType("C");
		types.add(type3);

		int administrationKey = utils.findFirstAgreementAdministrationKey(types);

		Assertions.assertEquals(31, administrationKey);
	}

	@Test
	public void truncateConsumerId() {
		Assertions.assertEquals(AgreementCustomerReferenceRequestProcessorUtils.DEFAULT_API_CONSUMER_ID, utils.truncateConsumerId(null));
		Assertions.assertEquals(AgreementCustomerReferenceRequestProcessorUtils.DEFAULT_API_CONSUMER_ID, utils.truncateConsumerId(""));
		Assertions.assertEquals("MOA", utils.truncateConsumerId("MOA"));
		Assertions.assertEquals("vm00004660", utils.truncateConsumerId("vm00004660"));
		Assertions.assertEquals("AABSYS017664", utils.truncateConsumerId("AAB-SYS-017664"));
		Assertions.assertEquals("B.SYS.017664", utils.truncateConsumerId("AAB.SYS.017664"));
		Assertions.assertEquals("901234567890", utils.truncateConsumerId("12345678901234567890"));
	}

	@Test
	void isConsumerIdEmpty() {
		AgreementCustomerReferenceRequestProcessorUtils utils = new AgreementCustomerReferenceRequestProcessorUtils();
		Assertions.assertTrue(utils.isConsumerIdEmpty(null));
		Assertions.assertTrue(utils.isConsumerIdEmpty(""));
		Assertions.assertTrue(utils.isConsumerIdEmpty(" "));
		Assertions.assertTrue(utils.isConsumerIdEmpty("    "));
		Assertions.assertFalse(utils.isConsumerIdEmpty("."));
		Assertions.assertFalse(utils.isConsumerIdEmpty("-"));
		Assertions.assertFalse(utils.isConsumerIdEmpty("asd"));
		Assertions.assertFalse(utils.isConsumerIdEmpty("empty"));
	}
}
