package com.abnamro.moa.services.agreementcustomerreference.agreementcustomerrefvalidator;

import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.create.AgreementCustomerReferenceDAO;
import com.abnamro.moa.services.agreementcustomerreference.dao.exceptions.AgreementCustomerReferenceDAOException;
import com.abnamro.moa.services.agreementcustomerreference.dao.productvalidation.AgreementCustomerReferenceProductValidationDAO;
import com.abnamro.moa.services.agreementcustomerreference.exception.AgreementCustomerReferenceApplicationException;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementAdministrationReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReference;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementCustomerReferenceForPatch;
import com.abnamro.moa.services.agreementcustomerreference.resourcemodel.AgreementLifeCycleStatusTypeEnum;
import com.abnamro.nl.partymanagementobjects.v4.Party;
import com.abnamro.nl.partymanagementobjects.v4.PartyDetails;
import com.abnamro.nl.partymanagementobjects.v4.RetrievePartyDetailsResponseTO;
import io.swagger.models.auth.In;
import org.apache.logging.log4j.core.util.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class AgreementCustomerReferenceValidatorImplTest {
    @Mock
    private AgreementCustomerReferenceProductValidationDAO productValidationDao;
    @Mock
    private BuildingBlockDAO buildingBlockDAO;
    @Mock
    private AgreementCustomerReferenceDAO agreementCustomerReferenceDao;

    @InjectMocks
    private AgreementCustomerReferenceValidatorImpl validator = new AgreementCustomerReferenceValidatorImpl();

    @Test
    void validatePackageNoCommercialAgreementId() throws AgreementCustomerReferenceDAOException {
        AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
        agreementCustomerReference.setProductId("123456");
        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("121");
        administration.setAgreementAdministrationReferenceId("234432");
        administrations.add(administration);
        agreementCustomerReference.setAgreementAdministrationReferences(administrations);

        Mockito.when(productValidationDao.getProductType(123456)).thenReturn("A");

        try {
            validator.validatePackage(agreementCustomerReference);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNotNull(exception);
            Assertions.assertEquals("4023", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePackageWithSettlementAccountNumber() throws AgreementCustomerReferenceDAOException {
        AgreementCustomerReference agreementCustomerReference = new AgreementCustomerReference();
        agreementCustomerReference.setProductId("123456");
        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("121");
        administration.setAgreementAdministrationReferenceId("234432");
        administrations.add(administration);
        agreementCustomerReference.setAgreementAdministrationReferences(administrations);
        agreementCustomerReference.setCommercialAgreementId("12323");
        agreementCustomerReference.setPackageSettlementAccountNumber("878998");

        Mockito.when(productValidationDao.getProductType(123456)).thenReturn("A");

        try {
            validator.validatePackage(agreementCustomerReference);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNotNull(exception);
            Assertions.assertEquals("4021", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateAgreementAdministationsEmpty() {
        try {
            validator.validateAgreementAdministrationReferences(null);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNotNull(exception);
            Assertions.assertEquals("4008", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateAgreementAdministationsEmptyAdministationIds() {
        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("121");
        administration.setAgreementAdministrationReferenceId("234432");
        administrations.add(administration);
        AgreementAdministrationReference administration1 = new AgreementAdministrationReference();
        administration1.setAgreementAdministrationReferenceId("43253");
        administrations.add(administration1);

        try {
            validator.validateAgreementAdministrationReferences(administrations);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNotNull(exception);
            Assertions.assertEquals("4010", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateAgreementAdministationsAdministationIdTooLong() {
        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("121");
        administration.setAgreementAdministrationReferenceId("234432");
        administrations.add(administration);
        AgreementAdministrationReference administration1 = new AgreementAdministrationReference();
        administration1.setAgreementAdministrationId("1234567");
        administration1.setAgreementAdministrationReferenceId("1234567");
        administrations.add(administration1);

        try {
            validator.validateAgreementAdministrationReferences(administrations);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNotNull(exception);
            Assertions.assertEquals("4009", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateAgreementAdministationsAdministationReferenceIdLongerThanIBAN() {
        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("121");
        administration.setAgreementAdministrationReferenceId("234432");
        administrations.add(administration);
        AgreementAdministrationReference administration1 = new AgreementAdministrationReference();
        administration1.setAgreementAdministrationId("121");
        administration1.setAgreementAdministrationReferenceId("12345678901234567890");
        administrations.add(administration1);

        try {
            validator.validateAgreementAdministrationReferences(administrations);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNotNull(exception);
            Assertions.assertEquals("4020", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateAgreementAdministationsAdministationReferenceIdEmpty() {
        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("121");
        administration.setAgreementAdministrationReferenceId("234432");
        administrations.add(administration);
        AgreementAdministrationReference administration1 = new AgreementAdministrationReference();
        administration1.setAgreementAdministrationId("121");
        administrations.add(administration1);

        try {
            validator.validateAgreementAdministrationReferences(administrations);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNotNull(exception);
            Assertions.assertEquals("4011", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validAgreementCustomerReferenceId() {
        try {
            validator.validateAgreementCustomerReferenceId("ASD234234");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void invalidAgreementCustomerReferenceId() {
        try {
            validator.validateAgreementCustomerReferenceId("qqq");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4032", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateValidProductId() {
        try {
            validator.validateProductIdFormat("123456");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateInvalidProductIdNaN() {
        try {
            validator.validateProductIdFormat("12345as");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4005", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateInvalidProductIdLengthBiggerThan6() {
        try {
            validator.validateProductIdFormat("1234567");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4005", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateIsPaymentPackage() throws AgreementCustomerReferenceDAOException {
        Mockito.doThrow(AgreementCustomerReferenceDAOException.class).when(productValidationDao).retrieveProductGroupIdsForProduct(43);

        boolean isPayamentPackage = validator.isPaymentPackage(43);
        Assertions.assertFalse(isPayamentPackage);
    }

    @Test
    void validateNumber() {
        Assertions.assertTrue(validator.isValidInteger("123"));
        Assertions.assertTrue(validator.isValidInteger("0"));
        Assertions.assertTrue(validator.isValidInteger("100"));
        Assertions.assertFalse(validator.isValidInteger("a100"));
        Assertions.assertFalse(validator.isValidInteger("a"));
        Assertions.assertFalse(validator.isValidInteger("ouch"));
    }

    @Test
    void validateSettlementAccount() throws AgreementCustomerReferenceDAOException {
        Mockito.when(buildingBlockDAO.isBuildingBlockReferencePresent(5, "0123456789")).thenReturn(false);

        try {
            validator.validateSettlementAccount("NL02ABNA0123456789");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4026", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateSettlementAccountDAOException() throws AgreementCustomerReferenceDAOException {
        Mockito.doThrow(AgreementCustomerReferenceDAOException.class).when(buildingBlockDAO).isBuildingBlockReferencePresent(5, "0123456789");

        try {
            validator.validateSettlementAccount("NL02ABNA0123456789");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNull(exception.getMessage());
            Assertions.assertNull(exception.getStatus());
        }
    }

    @Test
    void isCustomerExistsNoPartyDetailsResponse() {
        try {
            validator.isCustomerExists(null);
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4024", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void isCustomerExistsNoPartyDetails() {
        RetrievePartyDetailsResponseTO partyDetailsResponse = new RetrievePartyDetailsResponseTO();

        try {
            validator.isCustomerExists(partyDetailsResponse);
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4024", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void isCustomerExistsNoParty() {
        RetrievePartyDetailsResponseTO partyDetailsResponse = new RetrievePartyDetailsResponseTO();
        PartyDetails partyDetails = new PartyDetails();
        partyDetailsResponse.setPartyDetails(partyDetails);

        try {
            validator.isCustomerExists(partyDetailsResponse);
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4024", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void isCustomerExistsNoPartyLifeCycleStatus() {
        RetrievePartyDetailsResponseTO partyDetailsResponse = new RetrievePartyDetailsResponseTO();
        PartyDetails partyDetails = new PartyDetails();
        Party party = new Party();
        partyDetails.setParty(party);
        partyDetailsResponse.setPartyDetails(partyDetails);

        try {
            validator.isCustomerExists(partyDetailsResponse);
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4024", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void existsAgreementCustomerReference() throws AgreementCustomerReferenceDAOException {
        Mockito.doThrow(AgreementCustomerReferenceDAOException.class).when(agreementCustomerReferenceDao).existsAgreementCustomerReference("123");

        try {
            boolean exists = validator.existsAgreementCustomerReference("123");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNull(exception.getMessage());
            Assertions.assertNull(exception.getStatus());
        }
    }

    @Test
    public void validateBuildingBlockDetailsNoBuildingBLocksAndNoAdministrations() {
        try {
            validator.validateBuildingBlockDetails(null, null);
        } catch (AgreementCustomerReferenceApplicationException | AgreementCustomerReferenceDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateBuildingBlockDetailsNoBuildingBLocksAndEmptyAdministrations() {
        List<BuildingBlockClusterTypeView> buildingBlocks = new ArrayList<>();
        List<AgreementAdministrationReference> administrations = new ArrayList<>();

        try {
            validator.validateBuildingBlockDetails(buildingBlocks, administrations);
        } catch (AgreementCustomerReferenceApplicationException | AgreementCustomerReferenceDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    public void validateBuildingBlockDetailsNoBuildingBLocksAndWithAdministrations() throws AgreementCustomerReferenceDAOException {
        List<BuildingBlockClusterTypeView> buildingBlocks = new ArrayList<>();
        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration1 = new AgreementAdministrationReference();
        administration1.setAgreementAdministrationId("12");
        administration1.setAgreementAdministrationReferenceId("234");

        try {
            validator.validateBuildingBlockDetails(buildingBlocks, administrations);
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4015", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateBuildingBlockDetailsForUpdateNoAdministrations() {
        try {
            validator.validateBuildingBlockDetailsForUpdate(null, null, "ASD890789");
        } catch (AgreementCustomerReferenceApplicationException | AgreementCustomerReferenceDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateBuildingBlockDetailsForUpdateEmptyAdministrations() {
        List<AgreementAdministrationReference> administrations = new ArrayList<>();

        try {
            validator.validateBuildingBlockDetailsForUpdate(null, administrations, "ASD890789");
        } catch (AgreementCustomerReferenceApplicationException | AgreementCustomerReferenceDAOException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateBuildingBlockDetailsForUpdateNonExistingAdministrations() throws AgreementCustomerReferenceDAOException {
        List<BuildingBlockClusterTypeView> clusterTypes = new ArrayList<>();
        BuildingBlockClusterTypeView clusterType = new BuildingBlockClusterTypeView();
        clusterType.setBuildingBlockId(13);
        clusterTypes.add(clusterType);

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("13");
        administration.setAgreementAdministrationReferenceId("789567");
        administrations.add(administration);

        Mockito.when(buildingBlockDAO.getAgreementCustomerReferenceForBuildingBlockReference(13, "789567")).thenReturn(null);

        try {
            validator.validateBuildingBlockDetailsForUpdate(clusterTypes, administrations, "ASD890789");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateBuildingBlockDetailsForUpdateExistingAdministrationsIncorrectAgreementCustomerReferenceId() throws AgreementCustomerReferenceDAOException {
        List<BuildingBlockClusterTypeView> clusterTypes = new ArrayList<>();
        BuildingBlockClusterTypeView clusterType = new BuildingBlockClusterTypeView();
        clusterType.setBuildingBlockId(13);
        clusterTypes.add(clusterType);

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("13");
        administration.setAgreementAdministrationReferenceId("789567");
        administrations.add(administration);

        Mockito.when(buildingBlockDAO.getAgreementCustomerReferenceForBuildingBlockReference(13, "789567")).thenReturn("AAA121212");

        try {
            validator.validateBuildingBlockDetailsForUpdate(clusterTypes, administrations, "ASD890789");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4015", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateBuildingBlockDetailsForUpdateExistingAdministrations() throws AgreementCustomerReferenceDAOException {
        List<BuildingBlockClusterTypeView> clusterTypes = new ArrayList<>();
        BuildingBlockClusterTypeView clusterType = new BuildingBlockClusterTypeView();
        clusterType.setBuildingBlockId(13);
        clusterTypes.add(clusterType);

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("13");
        administration.setAgreementAdministrationReferenceId("789567");
        administrations.add(administration);

        Mockito.when(buildingBlockDAO.getAgreementCustomerReferenceForBuildingBlockReference(13, "789567")).thenReturn("ASD890789");

        try {
            validator.validateBuildingBlockDetailsForUpdate(clusterTypes, administrations, "ASD890789");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception exptected");
        }
    }

    @Test
    void validateIfBBIsLinkedToProductNoAdministrations() {
        try {
            validator.validateIfBBIsLinkedToProduct(null, null);
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateIfBBIsLinkedToProductEmptyAdministrations() {
        List<AgreementAdministrationReference> administrations = new ArrayList<>();

        try {
            validator.validateIfBBIsLinkedToProduct(null, administrations);
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateIfBBIsLinkedToProductWithoutLinkedAdministrations() {
        List<BuildingBlockClusterTypeView> clusterTypes = new ArrayList<>();
        BuildingBlockClusterTypeView clusterType1 = new BuildingBlockClusterTypeView();
        clusterType1.setBuildingBlockId(20);
        clusterTypes.add(clusterType1);
        BuildingBlockClusterTypeView clusterType2 = new BuildingBlockClusterTypeView();
        clusterType2.setBuildingBlockId(30);
        clusterTypes.add(clusterType2);

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration1 = new AgreementAdministrationReference();
        administration1.setAgreementAdministrationId("10");
        administration1.setAgreementAdministrationReferenceId("NL02ABNA0123456789");
        administrations.add(administration1);
        AgreementAdministrationReference administration2 = new AgreementAdministrationReference();
        administration2.setAgreementAdministrationId("21");
        administration2.setAgreementAdministrationReferenceId("NL02ABNA0123456789");
        administrations.add(administration2);

        try {
            validator.validateIfBBIsLinkedToProduct(clusterTypes, administrations);
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4025", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateIfBBIsLinkedToProductWithLinkedAdministrations() {
        List<BuildingBlockClusterTypeView> clusterTypes = new ArrayList<>();
        BuildingBlockClusterTypeView clusterType1 = new BuildingBlockClusterTypeView();
        clusterType1.setBuildingBlockId(20);
        clusterTypes.add(clusterType1);
        BuildingBlockClusterTypeView clusterType2 = new BuildingBlockClusterTypeView();
        clusterType2.setBuildingBlockId(30);
        clusterTypes.add(clusterType2);

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration1 = new AgreementAdministrationReference();
        administration1.setAgreementAdministrationId("30");
        administration1.setAgreementAdministrationReferenceId("NL02ABNA0123456789");
        administrations.add(administration1);
        AgreementAdministrationReference administration2 = new AgreementAdministrationReference();
        administration2.setAgreementAdministrationId("20");
        administration2.setAgreementAdministrationReferenceId("NL02ABNA0123456789");
        administrations.add(administration2);

        try {
            validator.validateIfBBIsLinkedToProduct(clusterTypes, administrations);
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void convertValidIBANToBBAN() {
        try {
            validator.convertToBBAN("NL02ABNA0123456789");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void convertInvalidIBANToBBANEmpty() {
        try {
            validator.convertToBBAN("");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4013", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void convertInvalidIBANToBBANForeign() {
        try {
            validator.convertToBBAN("DE02ABNA0123456789");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4013", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void convertInvalidIBANToBBANIncorrectSize() {
        try {
            validator.convertToBBAN("NL02ABNA01234567890");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4013", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void convertInvalidIBANToBBAN() {
        try {
            validator.convertToBBAN("NL03ABNA0123456789");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4013", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestInvalidAgreementCustomerReferenceId() {
        String agreementCustomerReferenceId = "";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4032", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestEmptyLifeCycleStatus() {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validatePartialUpdateRequestInvalidLifeCycleStatus() {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getDbValue());

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4014", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestInvalidFormatProductId1() {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("1234567s");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4005", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestInvalidFormatProductId2() {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("1234567");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4005", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestNonExistingProductId() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn(null);

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4006", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestNoAdministrations() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4008", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestEmptyAdministrations() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");
        updateInput.setAgreementAdministrationReferences(new ArrayList<>());

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4008", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestNoAdministrationId() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationReferenceId("234432");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4010", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestNoValidAdministrationId1s() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("118a");
        administration.setAgreementAdministrationReferenceId("234432");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4009", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestNoValidAdministrationId2() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("118117");
        administration.setAgreementAdministrationReferenceId("234432");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4009", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestNoAdministrationReferenceId() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("22");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4011", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestEmptyAdministrationReferenceId() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("232");
        administration.setAgreementAdministrationReferenceId("");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4020", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestAdministrationReferenceIdTooLong() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("22");
        administration.setAgreementAdministrationReferenceId("12345678901234567");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4020", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestEmptyCustomerId() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("22");
        administration.setAgreementAdministrationReferenceId("01234567");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        updateInput.setCustomerId("");

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4002", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestNaNCustomerId() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("22");
        administration.setAgreementAdministrationReferenceId("01234567");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        updateInput.setCustomerId("12sd34");

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4002", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestCustomerIdTooLong() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("22");
        administration.setAgreementAdministrationReferenceId("01234567");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        updateInput.setCustomerId("1234567890123");

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4002", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestParentIdNotExist() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("22");
        administration.setAgreementAdministrationReferenceId("01234567");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        updateInput.setCustomerId("890123");
        updateInput.setParentAgreementCustomerReferenceId("AAA232323");

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");
        Mockito.when(agreementCustomerReferenceDao.existsAgreementCustomerReference("AAA232323")).thenReturn(false);

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4007", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestCommercialAgreementIdEmpty() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("22");
        administration.setAgreementAdministrationReferenceId("01234567");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        updateInput.setCustomerId("890123");
        updateInput.setCommercialAgreementId("");

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4017", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestOrganizationUnitIdNaN() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("22");
        administration.setAgreementAdministrationReferenceId("01234567");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        updateInput.setCustomerId("890123");
        updateInput.setOrganisationUnitId("12org");

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4012", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validatePartialUpdateRequestOrganizationUnitIdTooLong() throws AgreementCustomerReferenceDAOException {
        String agreementCustomerReferenceId = "CHI798987";
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setAgreementLifeCycleStatus(AgreementLifeCycleStatusTypeEnum.ENDED.getValue());
        updateInput.setProductId("12345");

        List<AgreementAdministrationReference> administrations = new ArrayList<>();
        AgreementAdministrationReference administration = new AgreementAdministrationReference();
        administration.setAgreementAdministrationId("22");
        administration.setAgreementAdministrationReferenceId("01234567");
        administrations.add(administration);
        updateInput.setAgreementAdministrationReferences(administrations);

        updateInput.setCustomerId("890123");
        updateInput.setOrganisationUnitId("1234567");

        Mockito.when(productValidationDao.getProductType(12345)).thenReturn("product type");

        try {
            validator.validatePartialUpdateRequest(agreementCustomerReferenceId, updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4012", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateProductIdForUpdate() throws AgreementCustomerReferenceDAOException {
        AgreementCustomerReferenceForPatch updateInput = new AgreementCustomerReferenceForPatch();
        updateInput.setProductId("12");

        Mockito.doThrow(AgreementCustomerReferenceDAOException.class).when(productValidationDao).getProductType(12);

        try {
            validator.validateProductIdForUpdate(updateInput);
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNull(exception.getMessage());
            Assertions.assertNull(exception.getStatus());
        }
    }

    @Test
    void validateCommercialAgreementIdEmpty() {
        try {
            validator.validateCommercialAgreementId(" ");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4017", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateCommercialAgreementIdTooLong() {
        try {
            validator.validateCommercialAgreementId("12345678901234567");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4017", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateCommercialAgreementId() {
        try {
            validator.validateCommercialAgreementId("123456789012");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateOrgUnitIdNaN() {
        try {
            validator.validateOrgUnitId("12as");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4012", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateOrgUnitIdTooLong() {
        try {
            validator.validateOrgUnitId("1234567");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4012", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateOrgUnitId() {
        try {
            validator.validateOrgUnitId("1234");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateSearchRequestProductIdNull() {
        try {
            validator.validateSearchRequest(null, "12", "13", "14");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNotEquals("4005", exception.getMessage());
        }
    }

    @Test
    void validateSearchRequestProductIdEmpty() {
        try {
            validator.validateSearchRequest("", "12", "13", "14");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4005", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateSearchRequestProductIdTooLong() {
        try {
            validator.validateSearchRequest("1234567", "12", "13", "14");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4005", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateSearchRequestCommercialAgreementIdEmpty() {
        try {
            validator.validateSearchRequest("11", " ", "13", "14");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4017", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateSearchRequestCommercialAgreementIdTooLong() {
        try {
            validator.validateSearchRequest("11", "12345678901234567", "13", "14");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4017", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateSearchRequestBuildingBlockIdEmpty() {
        try {
            validator.validateSearchRequest("11", "12", " ", "14");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4009", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateSearchRequestBuildingBlockIdTooLong() {
        try {
            validator.validateSearchRequest("11", "12", "1234567", "14");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4009", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateSearchRequestBuildingBlockReferenceIdEmpty() {
        try {
            validator.validateSearchRequest("11", "12", "13", " ");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4020", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateSearchRequestBuildingBlockReferenceIdTooLong() {
        try {
            validator.validateSearchRequest("11", "12", "13", "12345678901234567");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4020", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateAtLeastOneSelectionCriteria() {
        try {
            validator.validateAtleastOneSelectionCriteria(" ", " ", " ", " ");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4031", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateOnlyOneSelectionCriteriaProductIdAdministrationId() {
        try {
            validator.validateOnlyOneSelectionCriteria("11", " ", "13", " ");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4031", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateOnlyOneSelectionCriteriaProductIdAdministrationReferenceId() {
        try {
            validator.validateOnlyOneSelectionCriteria("11", " ", " ", "14");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4031", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateOnlyOneSelectionCriteriaAgreementIdAdministrationId() {
        try {
            validator.validateOnlyOneSelectionCriteria(" ", "12", "13", " ");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4031", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateOnlyOneSelectionCriteriaAgreementIdAdministrationReferenceId() {
        try {
            validator.validateOnlyOneSelectionCriteria(" ", "12", " ", "14");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4031", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateOnlyOneSelectionCriteriaProductIdAgreementId() {
        try {
            validator.validateOnlyOneSelectionCriteria("11", "12", " ", " ");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateOnlyOneSelectionCriteriaAdministrationIdAdministrationReferenceId() {
        try {
            validator.validateOnlyOneSelectionCriteria(" ", " ", "13", "14");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateProductIdFormatQueryParamEmpty() {
        try {
            validator.validateProductIdFormatQueryParam(" ");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4005", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateProductIdFormatQueryParamTooLong() {
        try {
            validator.validateProductIdFormatQueryParam("1234567");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4005", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateProductIdFormatQueryParamNaN() {
        try {
            validator.validateProductIdFormatQueryParam("123d");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4005", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateBuildingBlockRefIdEmpty() {
        try {
            validator.validateBuildingBlockRefId(" ");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4020", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateBuildingBlockRefIdTooLong() {
        try {
            validator.validateBuildingBlockRefId("12345678901234567");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4020", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateBuildingBlockRefId() {
        try {
            validator.validateBuildingBlockRefId("123d");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateStringBuildingBlockId() {
        try {
            validator.validateStringBuildingBlockId("123");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }

    @Test
    void validateStringBuildingBlockIdEmpty() {
        try {
            validator.validateStringBuildingBlockId(" ");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4009", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateStringBuildingBlockIdTooLong() {
        try {
            validator.validateStringBuildingBlockId("1234567890");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4009", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateStringBuildingBlockIdNaN() {
        try {
            validator.validateStringBuildingBlockId("123as");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4009", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateProductTypeChangeNewProductTypeNotExist() throws AgreementCustomerReferenceDAOException {
        Mockito.when(productValidationDao.getProductType(10)).thenReturn(null);

        try {
            validator.validateProductTypeChange("10" , "20");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4006", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateProductTypeChangeNewProductTypeNotEqualsOldProductType() throws AgreementCustomerReferenceDAOException {
        Mockito.when(productValidationDao.getProductType(10)).thenReturn("type 1");

        try {
            validator.validateProductTypeChange("10" , "20");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4029", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateProductTypeChangeDAOException() throws AgreementCustomerReferenceDAOException {
        Mockito.doThrow(AgreementCustomerReferenceDAOException.class).when(productValidationDao).getProductType(10);

        try {
            validator.validateProductTypeChange("10" , "20");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertNull(exception.getMessage());
            Assertions.assertNull(exception.getStatus());
        }
    }

    @Test
    void validateProductForSettlementAccountUpdateNoPaymentPackage() throws AgreementCustomerReferenceDAOException {
        List<Integer> productGroups = Arrays.asList(20, 21, 24);
        Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(10)).thenReturn(productGroups);

        try {
            validator.validateProductForSettlementAccountUpdate("10");
            Assertions.fail("exception expected");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.assertEquals("4038", exception.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        }
    }

    @Test
    void validateProductForSettlementAccountUpdatePaymentPackage() throws AgreementCustomerReferenceDAOException {
        List<Integer> productGroups = Arrays.asList(20, 21, 24, 77);
        Mockito.when(productValidationDao.retrieveProductGroupIdsForProduct(10)).thenReturn(productGroups);

        try {
            validator.validateProductForSettlementAccountUpdate("10");
        } catch (AgreementCustomerReferenceApplicationException exception) {
            Assertions.fail("no exception expected");
        }
    }
}
