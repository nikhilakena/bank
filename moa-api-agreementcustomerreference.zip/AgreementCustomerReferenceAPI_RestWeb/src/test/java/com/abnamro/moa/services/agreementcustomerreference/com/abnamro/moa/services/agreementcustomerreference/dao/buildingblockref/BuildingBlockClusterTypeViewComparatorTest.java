package com.abnamro.moa.services.agreementcustomerreference.com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref;

import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeView;
import com.abnamro.moa.services.agreementcustomerreference.dao.buildingblockref.BuildingBlockClusterTypeViewComparator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class BuildingBlockClusterTypeViewComparatorTest {
    @Test
    void compareBuildingBlockType() {
        BuildingBlockClusterTypeViewComparator comparator = new BuildingBlockClusterTypeViewComparator();

        BuildingBlockClusterTypeView smaller = new BuildingBlockClusterTypeView();
        smaller.setBuildingBlockType("aaa");

        BuildingBlockClusterTypeView bigger = new BuildingBlockClusterTypeView();
        bigger.setBuildingBlockType("bbb");

        Assertions.assertTrue(comparator.compare(smaller, bigger) < 0);
        Assertions.assertTrue(comparator.compare(bigger, smaller) > 0);
    }

    @Test
    void compareBuildingBlockId() {
        BuildingBlockClusterTypeViewComparator comparator = new BuildingBlockClusterTypeViewComparator();

        BuildingBlockClusterTypeView smaller = new BuildingBlockClusterTypeView();
        smaller.setBuildingBlockType("aaa");
        smaller.setBuildingBlockId(1);

        BuildingBlockClusterTypeView bigger = new BuildingBlockClusterTypeView();
        bigger.setBuildingBlockType("aaa");
        bigger.setBuildingBlockId(2);

        Assertions.assertTrue(comparator.compare(smaller, bigger) < 0);
        Assertions.assertTrue(comparator.compare(bigger, smaller) > 0);
    }
}
