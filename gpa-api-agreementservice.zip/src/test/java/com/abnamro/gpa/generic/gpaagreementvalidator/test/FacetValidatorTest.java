/**
 * This class performs validations based on the facet types & values defined for an administration.
 */
package com.abnamro.gpa.generic.gpaagreementvalidator.test;

import java.util.ArrayList;
import java.util.List;


import com.abnamro.gpa.generic.gpaagreementvalidator.FacetValidator;
import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermFacetRestResource;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * @author C45158
 * This class is test class for facet validator
 *
 */
@ExtendWith(MockitoExtension.class)
class FacetValidatorTest {

	private FacetValidator underTest;

	@Test
	void testValidateFacetWithNumeric() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestNumeric2");
		termDetails.setDataType(TermDataType.NUMERIC);

		termDetails.setFacets(facets);
		String termValue="1000";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithTotalDigits() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("Provisional Credit Limit");
		termDetails.setDataType(TermDataType.NUMERIC);

		termDetails.setFacets(facets);
		String termValue="2.456";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithFraction() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("Provisional Credit Limit");
		termDetails.setDataType(TermDataType.NUMERIC);

		termDetails.setFacets(facets);
		String termValue="233.45667";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithCorrectPattern() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("Bank Account Number");
		termDetails.setDataType(TermDataType.STRING);

		termDetails.setFacets(facets);
		String termValue="NL93ABNA1234567893";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithWrongPattern() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("Bank Account Number");
		termDetails.setDataType(TermDataType.STRING);

		termDetails.setFacets(facets);
		String termValue="7693ABNA1234593";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithValidListValues() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("Smart Safe Processer");
		termDetails.setDataType(TermDataType.STRING);

		termDetails.setFacets(facets);
		String termValue="Securecash";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithINValidListValues() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("Smart Safe Processer");
		termDetails.setDataType(TermDataType.STRING);

		termDetails.setFacets(facets);
		String termValue="InvalidTestValue";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithValidMaxLength() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("Unit Number Contract");
		termDetails.setDataType(TermDataType.STRING);

		termDetails.setFacets(facets);
		String termValue="6754657";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithInValidMaxLength() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("Unit Number Contract");
		termDetails.setDataType(TermDataType.STRING);

		termDetails.setFacets(facets);
		String termValue="58727689276728670";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithValidBoolean() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestBoolean1");
		termDetails.setDataType(TermDataType.BOOLEAN);

		termDetails.setFacets(facets);
		String termValue="Yes";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithInValidBoolean() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestBoolean1");
		termDetails.setDataType(TermDataType.BOOLEAN);

		termDetails.setFacets(facets);
		String termValue="Yes11";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithValidMinMaxLength() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestNumeric1");
		termDetails.setDataType(TermDataType.NUMERIC);

		termDetails.setFacets(facets);
		String termValue="18";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithInValidMinLength() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestNumeric1");
		termDetails.setDataType(TermDataType.NUMERIC);

		termDetails.setFacets(facets);
		String termValue="2";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithValidDate() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestDate1");
		termDetails.setDataType(TermDataType.DATE);

		termDetails.setFacets(facets);
		String termValue="2018-06-20";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithInValidDate() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestDate1");
		termDetails.setDataType(TermDataType.DATE);

		termDetails.setFacets(facets);
		String termValue="2018-06-20 5235325";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithValidDateTime() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestDate1");
		termDetails.setDataType(TermDataType.DATE);

		termDetails.setFacets(facets);
		String termValue="2018-06-20 12:45:37";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithInValidDateTime() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestDate1");
		termDetails.setDataType(TermDataType.DATE);

		termDetails.setFacets(facets);
		String termValue="2018-06-20 12:45:37:46873256";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithValidTime() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestDate1");
		termDetails.setDataType(TermDataType.DATE);

		termDetails.setFacets(facets);
		String termValue="12:45:37";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

	@Test()
	void testValidateFacetWithInValidTime() throws Exception{

		TermRestResource termDetails = new TermRestResource();
		List<TermFacetRestResource> facets=null;
		facets =new ArrayList<TermFacetRestResource>();

		termDetails.setName("TestDate1");
		termDetails.setDataType(TermDataType.DATE);

		termDetails.setFacets(facets);
		String termValue="12:45:37:57632";

		underTest = new FacetValidator();
		underTest.validateFacet(termDetails, termValue);
	}

}
