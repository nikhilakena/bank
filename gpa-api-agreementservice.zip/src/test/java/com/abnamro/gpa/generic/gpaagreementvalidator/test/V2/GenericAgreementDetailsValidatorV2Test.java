/**
 *
 */
package com.abnamro.gpa.generic.gpaagreementvalidator.test.V2;

import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.generic.gpaagreementvalidator.v2.GenericAgreementDetailsValidatorV2;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * @author C84653
 *
 * This class is tes class for GenericAgreementDetailsValidatorV2
 *
 */
@ExtendWith(MockitoExtension.class)
class GenericAgreementDetailsValidatorV2Test {

	@InjectMocks
	private GenericAgreementDetailsValidatorV2 underTest;

	@Test()
	void testValidateGenericDetailsWithInvalidProductId() {
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setAgreementEndDate("2020-06-16T12:16:10.100Z");//2020-08-19T00:00:00.000Z
		inputDTO.setAgreementId("121");
		inputDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.INACTIVE);
		inputDTO.setAgreementStartDate("2018-06-15T12:16:10.100Z");
		inputDTO.setCreatedBy("GPAA");
		inputDTO.setCustomerId("0001");
		inputDTO.setProductId("65872365c");
		List<Term> terms=null;
		terms = new ArrayList<Term>();

		inputDTO.setTerms(terms);

		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the invalid ProductId and SuccessIndicator condition false");
	}

	@Test()
	void testValidateGenericDetailsWithZeroDigitInvalidCustomerId(){
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setProductId("1621");
		inputDTO.setCustomerId("0");
		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the Invalid CustomerId");
	}

	@Test()
	void testValidateGenericDetailsWithMoreThanTwelveDigitInvalidCustomerId(){
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setProductId("1621");
		inputDTO.setCustomerId("9876543219876");
		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the Invalid CustomerId");
	}

	@Test()
	void testValidateGenericDetailsWithInvalidAgreementStartDate(){
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setProductId("1621");
		inputDTO.setCustomerId("0001");
		inputDTO.setAgreementStartDate("2018-06-12 00:59:59");
		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the Invalid AgreementStartDate");
	}

	@Test()
	void testValidateGenericDetailsWithInvalidAgreementEndDate(){
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setProductId("1621");
		inputDTO.setCustomerId("0001");
		inputDTO.setAgreementStartDate("2018-06-12T00:59:59.000Z");//2020-08-19T00:00:00.000Z
		inputDTO.setAgreementEndDate("2018-05-12 00:59:59");
		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the Invalid AgreementEndDate");
	}

	@Test()
	void testValidateGenericDetailsWithInvalidAgreementStartDateEndDate(){
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setProductId("1621");
		inputDTO.setCustomerId("0001");
		inputDTO.setAgreementStartDate("2018-06-12T00:59:59.000Z");
		inputDTO.setAgreementEndDate("2018-06-12T00:59:59.000Z");
		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the Invalid AgreementEndDate");
	}

	@Test()
	void testValidateGenericDetailsWithInvalidBlankAttributeName(){
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setProductId("1621");
		inputDTO.setCustomerId("0001");
		inputDTO.setAgreementStartDate("2018-06-12T00:59:59.000Z");
		inputDTO.setAgreementEndDate("2018-06-13T00:59:59.000Z");

		List<Term> terms=new ArrayList<Term>();
		Term term=new Term();
		term.setAttributeName("");

		terms.add(term);
		inputDTO.setTerms(terms);

		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the Invalid Status");
	}

	@Test()
	@DisplayName("This test case execute successfully only when the Invalid AttributeName and "
			+ "expected= NumberFormatException")
	void testValidateGenericDetailsWithInvalidAttributeName(){
		try{
				GeneralProductAgreement inputDTO = new GeneralProductAgreement();
				inputDTO.setProductId("1621");
				inputDTO.setCustomerId("0001");
				inputDTO.setAgreementStartDate("2018-06-12T00:59:59.000Z");
				inputDTO.setAgreementEndDate("2018-06-13T00:59:59.000Z");
				List<Term> terms=new ArrayList<Term>();
				Term term=new Term();
				term.setAttributeName(String.valueOf(Integer.parseInt("12345.")));

				terms.add(term);
				inputDTO.setTerms(terms);

				
				//when(underTest.validateGenericDetails(inputDTO)).thenThrow(NumberFormatException.class);

				NumberFormatException thrown = Assertions.assertThrows(NumberFormatException.class, () -> {
					underTest.validateGenericDetails(inputDTO);
				}, "NumberFormatException was expected");
			//Assertions.assertEquals("For input string: "+'"'+terms.get(0).getAttributeName()+'"', thrown.getMessage());
			Assertions.assertEquals("NumberFormatException was expected", thrown.getMessage());
		}catch (NumberFormatException e){
			Assertions.assertEquals("For input string: \"12345.\"", e.getMessage());
		}
	}

	@Test()
	void testValidateGenericDetailsWithMandatoryProductId() {
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setProductId("");
		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the Mandatory ProductId and SuccessIndicator condition false");
	}

	@Test()
	void testValidateGenericDetailsWithMandatoryCustomerId() {
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setProductId("1621");
		inputDTO.setCustomerId("");
		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the Mandatory CustomerId and SuccessIndicator condition false");
	}

	@Test()
	void testValidateGenericDetailsWithMandatoryAgreementStartDate() {
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setProductId("1621");
		inputDTO.setCustomerId("0001");
		inputDTO.setAgreementStartDate("");
		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the Mandatory AgreementStartDate and SuccessIndicator condition false");
	}

	@Test()
	void testValidateGenericDetailsWithMandatoryAgreementEndDate() {
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setProductId("1621");
		inputDTO.setCustomerId("0001");
		inputDTO.setAgreementStartDate("2018-06-15T12:16:10.100Z");
		inputDTO.setAgreementEndDate("");

		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateGenericDetails(inputDTO).isSuccessIndicator(),
				"This test case execute successfully "
								+ "only when the Mandatory AgreementEndDate and SuccessIndicator condition false");
	}

}




