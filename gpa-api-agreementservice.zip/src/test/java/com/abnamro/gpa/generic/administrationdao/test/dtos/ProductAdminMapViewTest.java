package com.abnamro.gpa.generic.administrationdao.test.dtos;

import com.abnamro.gpa.generic.administrationdao.dtos.ProductAdminMapView;
import java.sql.Timestamp;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ProductAdminMapViewTest {
    @InjectMocks
    ProductAdminMapView underTest;
    @Mock
    ProductAdminMapView productAdminMapView;

    @BeforeEach
    public void startUp() {
        underTest = getProductAdminMapView();
        productAdminMapView = getProductAdminMapView();
    }

    @Test
    void test(){
        Assertions.assertSame(underTest.getProductId(),productAdminMapView.getProductId());
        Assertions.assertSame(underTest.getCreatedBy(),productAdminMapView.getCreatedBy());
        Assertions.assertSame(underTest.getModifiedBy(),productAdminMapView.getModifiedBy());
        Assertions.assertSame(underTest.getCreatedTimeStamp().toLocalDateTime().getDayOfMonth(),productAdminMapView.getCreatedTimeStamp().toLocalDateTime().getDayOfMonth());
        Assertions.assertSame(underTest.getModifiedTimeStamp().toLocalDateTime().getDayOfMonth(),productAdminMapView.getModifiedTimeStamp().toLocalDateTime().getDayOfMonth());
    }

    private ProductAdminMapView getProductAdminMapView() {
        ProductAdminMapView productAdminMapView = new ProductAdminMapView();
        productAdminMapView.setProductId(1);
        productAdminMapView.setCreatedBy("TEST-USER");
        productAdminMapView.setModifiedBy("TEST-USER");
        productAdminMapView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
        productAdminMapView.setModifiedTimeStamp(new Timestamp(System.currentTimeMillis()));
        return productAdminMapView;
    }

}
