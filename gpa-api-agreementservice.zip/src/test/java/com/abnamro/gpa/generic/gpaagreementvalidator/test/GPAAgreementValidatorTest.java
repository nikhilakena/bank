/**
 *
 */
package com.abnamro.gpa.generic.gpaagreementvalidator.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dtos.AdminTermView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.constant.GPAAgreementValidatorMessageKeys;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.gpaagreementvalidator.GPAAgreementValidator;
import com.abnamro.gpa.generic.gpaagreementvalidator.GenericAgreementDetailsValidator;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * @author C45158
 *
 * This class is test class for GPAAgreementValidator
 *
 */
@ExtendWith(MockitoExtension.class)
class GPAAgreementValidatorTest {

	@Mock
	private GenericAgreementDetailsValidator gpGenericAgreementDetailsValidator;


	@InjectMocks
	private GPAAgreementValidator underTest;

	@Mock
	private GPAAdministrationDAO administrationdao;


	@Test()
	void testValidateAgreementWithEmptyInput() throws Exception{

		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		
		underTest.validateAgreement(inputDTO);
	}

	@Test()
	void testValidateAgreementWithInput(){
		try{
			GeneralProductAgreement inputDTO = new GeneralProductAgreement();
			inputDTO.setAgreementEndDate("2020-06-15 12:16:10");
			inputDTO.setAgreementId("121");
			inputDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.INACTIVE);
			inputDTO.setAgreementStartDate("2018-06-15 12:16:10");
			inputDTO.setCreatedBy("GPAA");
			inputDTO.setCustomerId("0001");
			inputDTO.setProductId("1621");
			List<Term> terms=null;
			terms = new ArrayList<Term>();

			inputDTO.setTerms(terms);

			underTest.validateAgreement(inputDTO);
		} catch (GPAAgreementValidatorException e) {
			assertEquals(GPAAgreementValidatorMessageKeys.TECHNICAL_EXCEPTION_IN_READ_ADMIN, (e.getMessages()).getMessages().get(0).getMessageKey());
		}
	}

	@Test()
	void testValidateAdministrationWithEmptyAdminView() throws Exception{

		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		AdministrationView administrationView=null;

		inputDTO.setAgreementEndDate("2020-06-15 12:16:10");
		inputDTO.setAgreementId("121");
		inputDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.INACTIVE);
		inputDTO.setAgreementStartDate("2018-06-15 12:16:10");
		inputDTO.setCreatedBy("GPAA");
		inputDTO.setCustomerId("0001");
		inputDTO.setProductId("1621");

		
		underTest.validateAdministration(administrationView,inputDTO);
	}

	@Test()
	void testValidateAdministrationWithEmptyAdminAgreement() throws Exception{

		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		AdministrationView administrationView=new AdministrationView();

		List<AdminTermView> adminTermViews=null;
		adminTermViews = new ArrayList<AdminTermView>();

		administrationView.setAdminTermViews(adminTermViews);

		
		underTest.validateAdministration(administrationView,inputDTO);
	}

	@Test()
	void testValidateAllterms() throws Exception{

		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		List<Term> terms=new ArrayList<Term>();
		Term term=new Term();
		term.setAttributeName("Account Number");
		term.setAttributeValue("NL93ABNA0250620502");
		terms.add(term);
		inputDTO.setTerms(terms);

		AdministrationView administrationView=new AdministrationView();

		List<AdminTermView> adminTermViews=null;
		adminTermViews = new ArrayList<AdminTermView>();
		AdminTermView adminTerm=new AdminTermView();
		adminTerm.setName("Account Number");
		adminTerm.setTermId(4);

		administrationView.setAdminTermViews(adminTermViews);

		
		underTest.validateAllTerms(administrationView,inputDTO);
	}

	@Test()
	void testValidateMandatoryTerms() throws Exception{

		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		List<Term> terms=new ArrayList<Term>();
		Term term=new Term();
		term.setAttributeName("Account Number");
		term.setAttributeValue("NL93ABNA0250620502");
		terms.add(term);
		inputDTO.setTerms(terms);

		AdministrationView administrationView=new AdministrationView();

		List<AdminTermView> adminTermViews=null;
		adminTermViews = new ArrayList<AdminTermView>();
		AdminTermView adminTerm=new AdminTermView();
		adminTerm.setName("Account Number");
		adminTerm.setTermId(4);
		adminTerm.setMandatoryIndicator("Y");

		administrationView.setAdminTermViews(adminTermViews);

		
		underTest.validateMandatoryTerms(administrationView,inputDTO);
	}

	/*@Test()//expected=GPAAgreementValidatorException.class
	void testReadAdministration(){
		GPAAgreementValidatorException e = assertThrows(GPAAgreementValidatorException.class,()->{
			GeneralProductAgreement inputDTO = new GeneralProductAgreement();
			AdministrationView adminView= new AdministrationView();
			inputDTO.setProductId("1621");
			
			Mockito.lenient().when(administrationdao.readAdministration(0, 1621)).thenReturn(adminView);
			*//*assertEquals(Integer.parseInt(inputDTO.getProductId()),
					underTest.readAdministration(inputDTO).
							getProductAdminMapViews().get(0).getProductId());*//*

			Mockito.when(administrationdao.readAdministration(any(),any())).thenThrow(new GPAAdministrationDAOException());

					underTest.readAdministration(inputDTO);
		});
		Assertions.assertEquals(
				GPAAgreementValidatorMessageKeys.TECHNICAL_EXCEPTION_IN_READ_ADMIN,
				(e.getMessages()).getMessages().get(0).getMessageKey());
		//Assertions.assertEquals("An GPAAgreementValidatorException was thrown!", e.getMessage());
	}*/

	@Test()
	void testHandleValidationError() throws Exception{
		
		String code="CODE_ATTRIBUTE_INVALID";
		String message="DESC_ATTRIBUTE_INVALID";
		String[] paramInfo=new String[]{"Account Number"};
		Boolean successIndicator=true;
		assertNotNull(underTest.handleValidationError(code, message,paramInfo,successIndicator));
	}

}

