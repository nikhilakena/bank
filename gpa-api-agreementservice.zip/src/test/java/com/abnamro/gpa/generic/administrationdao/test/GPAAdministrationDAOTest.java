package com.abnamro.gpa.generic.administrationdao.test;

import java.util.ArrayList;
import java.util.List;

import com.abnamro.gpa.generic.administrationdao.constants.GPAAdministrationDAOMessageKeys;
import com.abnamro.gpa.generic.administrationdao.dtos.*;
import org.apache.ibatis.session.SqlSession;

import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;


import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAOHelper;
import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAOMybatisMapper;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;

import org.apache.ibatis.exceptions.PersistenceException;
import org.springframework.dao.DuplicateKeyException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class GPAAdministrationDAOTest {

  @InjectMocks
  private GPAAdministrationDAO underTest;

  @Mock
  private GPAAdministrationDAOHelper helper;

  @Mock
  GPAAdministrationDAOMybatisMapper myBatisMapper;


  @Mock
  private SqlSession sqlSession;

  @Mock
  private SqlSessionFactory sessionFactory;



    /*@BeforeEach
    void startUp() throws Exception {
         //PowerMockito.when(DAODatabaseUtil.openConnection("test")).thenReturn(connection);
        connectionFactory = Mockito.mock(MyBatisConnectionFactory.class);
		Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(myBatisMapper);
        Mockito.when(connectionFactory.getSession()).thenReturn(sqlSession);

    }*/

  @Test
  void testSearchAdministration() {
    AdministrationSearchCriteriaView searchCriteriaView = new AdministrationSearchCriteriaView();
    searchCriteriaView.setCreatedBy("C36098");
    searchCriteriaView.setAdministrationName("Chartal");
    List<AdministrationView> adminViewList = new ArrayList<AdministrationView>();
    Mockito.when(myBatisMapper.searchAdministration(searchCriteriaView)).thenReturn(adminViewList);
    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    try {
      Assertions.assertEquals(adminViewList,
          (List<AdministrationView>) underTest.searchAdministration(searchCriteriaView));
    } catch (GPAAdministrationDAOException e) {
      Assertions.fail("No Exception expected");
    }
  }

  @Test
  void testSearchAdministrationException() throws GPAAdministrationDAOException {
    AdministrationSearchCriteriaView searchCriteriaView = new AdministrationSearchCriteriaView();
    searchCriteriaView.setCreatedBy("C36098");
    searchCriteriaView.setAdministrationName("Chartal");
    List<AdministrationView> adminViewList = new ArrayList<AdministrationView>();

    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class))
        .thenThrow(new PersistenceException());
    doNothing().when(helper).validateSearchAdministrationRequest(any());
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    Assertions.assertThrows(GPAAdministrationDAOException.class,
        () -> underTest.searchAdministration(searchCriteriaView));

    //	Assertions.assertEquals(adminViewList, (List<AdministrationView>) );

  }

   /* @Test
	void testValidateSearchAdministrationRequestInvalidAdminId() throws Exception{

    	AdministrationSearchCriteriaView searchCriteriaView = new AdministrationSearchCriteriaView();

			searchCriteriaView.setAdministrationId(8787878);
		//	Whitebox.setInternalState(GPAAdministrationDAOHelper.class, logHelper);

		Assertions.assertThrows(GPAAdministrationDAOException.class,
		() -> helper.validateSearchAdministrationRequest(searchCriteriaView));
    }*/

  @Test
  void testGetMaxAdministrationId() {
    Mockito.when(myBatisMapper.getMaxAdministrationId()).thenReturn(5);
    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    try {
      Assertions.assertEquals(5, underTest.getMaxAdministrationId());
    } catch (GPAAdministrationDAOException e) {
      Assertions.fail("No Exception expected");
    }
  }

  @Test
  void testCreateAdministration() {
    AdministrationView administrationView = new AdministrationView();
    administrationView.setCreatedBy("C36098");
    administrationView.setName("Chartal");
    administrationView.setId(1);
    //Mockito.when(myBatisMapper.getMaxAdministrationId()).thenReturn(5);
    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    try {
      underTest.createAdministration(administrationView);
    } catch (GPAAdministrationDAOException e) {
      Assertions.fail("No Exception expected");
    }
  }

  @Test
  void testCreateAdministrationException() throws GPAAdministrationDAOException {
    AdministrationView administrationView = new AdministrationView();
    administrationView.setCreatedBy("C36098");
    administrationView.setName("Chartal");
    administrationView.setId(1);
    //Mockito.when(myBatisMapper.getMaxAdministrationId()).thenReturn(5);
    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class))
        .thenThrow(new PersistenceException());

    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);
    doNothing().when(helper).validateCreateAdministrationRequest(any());

    Assertions.assertThrows(GPAAdministrationDAOException.class,
        () -> underTest.createAdministration(administrationView));


  }

  @Test
  void testCreateAdministrationDuplicateKeyException() {
    AdministrationView administrationView = new AdministrationView();
    administrationView.setCreatedBy("C36098");
    administrationView.setName("Chartal");
    administrationView.setId(1);
    Mockito.when(myBatisMapper.getMaxAdministrationId()).thenReturn(5);

    //Mockito.when(myBatisMapper.insertAdministration(administrationView)).thenThrow(new DuplicateKeyException("test createadmin exception"));
    //Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenThrow(new DuplicateKeyException("test createadmin exception"));
    //Mockito.when(connectionFactory.getSession()).thenReturn(sqlSession);

    doThrow(new PersistenceException(new DuplicateKeyException("duplicate test"))).when(myBatisMapper)
        .insertAdministration(any());

    when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    when(sessionFactory.openSession()).thenReturn(sqlSession);
    //

    //	thenReturn(sqlSession);

    try {
      underTest.createAdministration(administrationView);
      //	Assertions.assertEquals(adminViewList, (List<AdministrationView>) );
    } catch (GPAAdministrationDAOException e) {
      Assertions.assertEquals(
          GPAAdministrationDAOMessageKeys.DUPLICATE_KEY_EXCEPTION_WHILE_CREATING_ADMINISTRATION_DETAILS,
          (e.getMessages()).getMessages().get(0).getMessageKey());

    }
  }

  @Test
  void testCreateAdministrationFindProductToInsert() {
    AdministrationView administrationView = new AdministrationView();
    administrationView.setId(1);
    administrationView.setName("Tikkie Administration");
    administrationView.setOarId("AAB.SYS.12345");
    administrationView.setCreatedBy("PA2619");
    List<ProductAdminMapView> productAdminMapViews = new ArrayList<>();
    ProductAdminMapView productAdminMapView = new ProductAdminMapView();
    productAdminMapView.setProductId(3450);

    productAdminMapViews.add(productAdminMapView);
    administrationView.setProductAdminMapViews(productAdminMapViews);

    Mockito.when(myBatisMapper.getMaxAdministrationId()).thenReturn(5);
    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    try {
      underTest.createAdministration(administrationView);
      //	Assertions.assertEquals(adminViewList, (List<AdministrationView>) );
    } catch (GPAAdministrationDAOException e) {
      Assertions.assertEquals(
          GPAAdministrationDAOMessageKeys.DUPLICATE_KEY_EXCEPTION_WHILE_CREATING_ADMINISTRATION_DETAILS,
          (e.getMessages()).getMessages().get(0).getMessageKey());

    }
  }

  @Test
  void testUpdateAdministration() {
    AdministrationView administrationView = new AdministrationView();
    administrationView.setId(1);
    administrationView.setName("Tikkie Administration");
    administrationView.setOarId("AAB.SYS.12345");
    administrationView.setCreatedBy("PA2619");
    List<ProductAdminMapView> productAdminMapViews = new ArrayList<>();
    ProductAdminMapView productAdminMapView = new ProductAdminMapView();
    productAdminMapView.setProductId(3450);

    productAdminMapViews.add(productAdminMapView);
    administrationView.setProductAdminMapViews(productAdminMapViews);

    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    try {
      underTest.updateAdministration(administrationView, administrationView);
    } catch (GPAAdministrationDAOException e) {
      Assertions.assertEquals(
          GPAAdministrationDAOMessageKeys.DUPLICATE_KEY_EXCEPTION_WHILE_CREATING_ADMINISTRATION_DETAILS,
          (e.getMessages()).getMessages().get(0).getMessageKey());

    }
  }

  @Test
  void testUpdateAdministrationwithAdminFacets() {
    AdministrationView administrationView = new AdministrationView();
    administrationView.setId(1);
    administrationView.setName("Tikkie Administration");
    administrationView.setOarId("AAB.SYS.12345");
    administrationView.setCreatedBy("PA2619");
    List<AdminTermView> adminTermViews = new ArrayList<>();
    administrationView.setId(1);
    AdminTermView adminTermView = new AdminTermView();
    FacetView facetView = new FacetView();
    //facetView.setType("1234567891234567890123");
    List<FacetView> facetViews = new ArrayList<>();
    facetView.setType("1234567891234");
    facetView.setValue("BCT776655777777879877");
    facetViews.add(facetView);
    adminTermView.setTermId(34235);

    adminTermView.setMandatoryIndicator("Y");
    adminTermView.setFacetView(facetViews);
    adminTermViews.add(adminTermView);
    administrationView.setAdminTermViews(adminTermViews);
    List<ProductAdminMapView> productAdminMapViews = new ArrayList<>();
    ProductAdminMapView productAdminMapView = new ProductAdminMapView();
    productAdminMapView.setProductId(3450);

    productAdminMapViews.add(productAdminMapView);
    administrationView.setProductAdminMapViews(productAdminMapViews);

    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    try {
      underTest.updateAdministration(administrationView, administrationView);
      //	Assertions.assertEquals(adminViewList, (List<AdministrationView>) );
    } catch (GPAAdministrationDAOException e) {
      Assertions.assertEquals(
          GPAAdministrationDAOMessageKeys.DUPLICATE_KEY_EXCEPTION_WHILE_CREATING_ADMINISTRATION_DETAILS,
          (e.getMessages()).getMessages().get(0).getMessageKey());

    }
  }

  @Test
  void testCreateAdministrationInsertTermAndFacetDetails() {
    AdministrationView administrationView = new AdministrationView();
    administrationView.setId(1);
    administrationView.setName("Tikkie Administration");
    administrationView.setOarId("AAB.SYS.12345");
    administrationView.setCreatedBy("PA2619");
    List<AdminTermView> adminTermViews = new ArrayList<>();
    administrationView.setId(1);
    AdminTermView adminTermView = new AdminTermView();
    FacetView facetView = new FacetView();
    //facetView.setType("1234567891234567890123");
    List<FacetView> facetViews = new ArrayList<>();
    facetViews.add(facetView);
    adminTermView.setFacetView(facetViews);
    adminTermViews.add(adminTermView);
    administrationView.setAdminTermViews(adminTermViews);

    Mockito.when(myBatisMapper.getMaxAdministrationId()).thenReturn(5);
    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    try {
      underTest.createAdministration(administrationView);
      verify(myBatisMapper, times(1)).insertFacets(
          administrationView.getId(), adminTermView.getTermId(), facetView);

    } catch (GPAAdministrationDAOException e) {
      Assertions.assertEquals(
          GPAAdministrationDAOMessageKeys.DUPLICATE_KEY_EXCEPTION_WHILE_CREATING_ADMINISTRATION_DETAILS,
          (e.getMessages()).getMessages().get(0).getMessageKey());

    }
  }
   /* @Test
	void testValidateCreateAdministrationRequestInvalidAdminId() throws Exception{
    	AdministrationView administrationView = new AdministrationView();
    	administrationView.setId(878787846);

		Assertions.assertThrows(GPAAdministrationDAOException.class,
				() ->helper.validateCreateAdministrationRequest(administrationView));

    }


    @Test
	void testValidateCreateAdministrationRequestInvalidCreatedBy() throws Exception{
    	AdministrationView administrationView = new AdministrationView();
    	administrationView.setId(1);
    	administrationView.setCreatedBy("PA26191234");
	Assertions.assertThrows(GPAAdministrationDAOException.class,
				() ->	helper.validateCreateAdministrationRequest(administrationView));
    }

    @Test
   	void testValidateCreateAdministrationRequestInvalidFacetType() throws Exception{
       	AdministrationView administrationView = new AdministrationView();
       	List<AdminTermView> adminTermViews = new ArrayList<>();
       	administrationView.setId(1);
       	AdminTermView adminTermView = new AdminTermView();
       	FacetView facetView = new FacetView();
       	facetView.setType("1234567891234567890123");
       	List<FacetView> facetViews = new ArrayList<>();
       	facetViews.add(facetView);
       	adminTermView.setFacetView(facetViews);
       	adminTermViews.add(adminTermView);
       	administrationView.setAdminTermViews(adminTermViews);
		Assertions.assertThrows(GPAAdministrationDAOException.class,
				() ->		helper.validateCreateAdministrationRequest(administrationView));

       }*/

  @Test
  void testReadAdministrationSuccess() throws Exception {

    AdministrationView adminView = new AdministrationView();
    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    Mockito.when(myBatisMapper.readAdministration(101, 0)).thenReturn(adminView);

    try {
      Assertions.assertEquals(adminView, underTest.readAdministration(101, 0));
    } catch (GPAAdministrationDAOException e) {
      Assertions.fail("No Exception expected");
    }
  }

  @Test
  void testReadAdministrationInvalidAdminId() throws Exception {

    AdministrationView adminView = new AdministrationView();

    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class))
        .thenThrow(new PersistenceException());
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    Assertions.assertThrows(GPAAdministrationDAOException.class,
        () -> underTest.readAdministration(1000000, 0));

  }

  @Test
  void testReadAdministrationInvalidProductId() throws Exception {

    AdministrationView adminView = new AdministrationView();
    Mockito.when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class))
        .thenThrow(new PersistenceException());
    Mockito.when(sessionFactory.openSession()).thenReturn(sqlSession);

    Assertions.assertThrows(GPAAdministrationDAOException.class,
        () -> underTest.readAdministration(0, 1000000));

  }

}
