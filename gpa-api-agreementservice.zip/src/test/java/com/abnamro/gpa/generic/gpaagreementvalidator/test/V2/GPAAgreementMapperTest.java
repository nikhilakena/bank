package com.abnamro.gpa.generic.gpaagreementvalidator.test.V2;

import com.abnamro.gpa.generic.administrationdao.dtos.AdminTermView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.dtos.ProductAdminMapView;
import com.abnamro.gpa.generic.gpaagreementvalidator.helper.GPAAgreementMapper;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restresource.enumeration.TermDataType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class GPAAgreementMapperTest {

    private final GPAAgreementMapper mapper= new GPAAgreementMapper();


    @Test
    public void convertToAdministrationRestResourceTestSuccess() {
        AdministrationView administrationView=new AdministrationView();
        administrationView.setId(2);
        administrationView.setName("Admin1");
        administrationView.setDescription("Admin1 Description");
        administrationView.setOarId("AAB.SYS.1480");

        List<ProductAdminMapView> productViews = new ArrayList<>();
        ProductAdminMapView productAdmin= new ProductAdminMapView();
        productAdmin.setProductId(4444);
        productViews.add(productAdmin);
        administrationView.setProductAdminMapViews(productViews);

        List<AdminTermView> adminTermViews = new ArrayList<>();
        AdminTermView adminTerm=new AdminTermView();
        adminTerm.setName("Account Number");
        adminTerm.setTermId(4);
        adminTerm.setDataType(TermDataType.NUMERIC.name());
        adminTermViews.add(adminTerm);
        administrationView.setAdminTermViews(adminTermViews);
        AdministrationRestResource administrationRestResource
        = mapper.convertToAdministrationRestResource(administrationView);

        Assertions.assertEquals(4, administrationRestResource.getTerms().get(0).getId());
        Assertions.assertEquals(4444, administrationRestResource.getProducts().get(0).intValue());
        Assertions.assertEquals("Admin1", administrationRestResource.getName());
        Assertions.assertEquals("AAB.SYS.1480", administrationRestResource.getOarId());
    }
}
