package com.abnamro.gpa.generic.gpaagreementdao.dao.test;


import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.UpdateContractHeaderInputDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.v2.ContractHeaderUtilV2;
import com.abnamro.gpa.generic.gpaagreementdao.constants.GPAAgreementDAOMessageKeys;
import com.abnamro.gpa.generic.gpaagreementdao.dao.GPAAgreementDAOMybatisMapper;
import com.abnamro.gpa.generic.gpaagreementdao.dao.GPAAgreementDAOV2;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.generic.gpaagreementdao.helper.GPAAgreementDaoViewMapper;
import com.abnamro.gpa.generic.gpaagreementdao.view.GPAAgreementView;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DuplicateKeyException;

import org.apache.ibatis.exceptions.PersistenceException;

import java.sql.Timestamp;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * This is test dao layer class for GPA Agreement.
 *
 * @author C45158
 */


@ExtendWith(MockitoExtension.class)
class GPAAgreementDAOV2Test {


    @InjectMocks
    private GPAAgreementDAOV2 underTest;

@Mock
private ContractHeaderUtilV2 contractHeaderUtilV2;
    @Mock
    private GPAAgreementDAOMybatisMapper myBatisMapper;



    /*@Mock
    private MyBatisConnectionFactory connectionFactory;*/

    @Mock
    private SqlSessionFactory sqlSession;

    @Mock
    private SqlSession session;


    @Mock
    private GPAAgreementDaoViewMapper gpaAgreementViewMapper;

    /**
     * This method opens mocked test database connection at start of test case execution
     *
     */
    @BeforeEach
    public void startUp() throws GPAAgreementDAOException {
        /*PowerMockito.mockStatic(DAODatabaseUtil.class);
        when(DAODatabaseUtil.openConnection("test")).thenReturn(connection);
        connectionFactory = PowerMockito.mock(MyBatisConnectionFactory.class);
        when(connectionFactory.getSession(connection)).thenReturn(sqlSession);
        when(sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);*/

        //when(connectionHelper.getConnection("jdbc/GPA_DataSource")).thenReturn(connection);
        //when(sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);


      /*  when(connectionFactory.getMybatisSessionInstance()).thenReturn(sqlSession);
        when(sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);*/


    }



    /**
     * This method tests the behaviour of method in case input attribute length is exceeding the limit
     *
     * @throws GPAAgreementDAOException Exception thrown in case of any error
     */
    @Test
        @DisplayName("Test Create Agreement V2 With Invalid Input Attribute Length")
        void testCreateAgreementWithInvalidInputAttributeLength() {

            try{
                GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
                agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
                agreementDTO.setAgreementId(1234567890);
                agreementDTO.setProductId(1234);
                agreementDTO.setStatus("ACTIVE");
                agreementDTO.setCustomerId(1234566);
                //Invalid length for createdBy
                agreementDTO.setCreatedBy("PA2619345787");
                agreementDTO.setUpdatedBy("KE3459");

                underTest.createGPAAgreement("12340", agreementDTO);
            } catch (GPAAgreementDAOException e) {
                assertEquals(GPAAgreementDAOMessageKeys.INVALID_LENGTH_PARAMS_EXCEPTION_WHILE_CREATING_AGREEMENT, (e.getMessages()).getMessages().get(0).getMessageKey());
            }
    }
    @Test
    @DisplayName("Test Create Agreement V2 With Invalid Input Attribute Length")
    void testHandlePersistenceExceptionInCreateAgreement()   {

        try {
            GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
            agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
            agreementDTO.setAgreementId(1234567890);
            agreementDTO.setProductId(1234456);
            agreementDTO.setStatus("NOTACTIV");
            agreementDTO.setCustomerId(12345664);
            //Invalid length for createdBy
            agreementDTO.setCreatedBy("PA26193");
            agreementDTO.setUpdatedBy("KE34594");
            when(session.getMapper(GPAAgreementDAOMybatisMapper.class)).thenThrow(new PersistenceException());
            when(sqlSession.openSession()).thenReturn(session);
           underTest.createGPAAgreement("12340", agreementDTO);

        }catch(GPAAgreementDAOException e)
        {
            assertEquals(GPAAgreementDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_CREATING_AGREEMENT, (e.getMessages()).getMessages().get(0).getMessageKey());


        }

    } @Test
    @DisplayName("Test Create Agreement V2 With Invalid Input Attribute Length")
    void testHandlePersistenceExceptionInUpdateAgreement()   {

        try {
            UpdateContractHeaderInputDTO updateContractHeaderInputDTO= new UpdateContractHeaderInputDTO();
            GPAAgreementView gpaAgreementView = new GPAAgreementView();
            gpaAgreementView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
            gpaAgreementView.setAgreementId(13343534);
            gpaAgreementView.setProductId(1234);
            gpaAgreementView.setStatus("ACTIVE");
            gpaAgreementView.setCustomerId(1234566);
            gpaAgreementView.setCreatedBy("PA2680");
            gpaAgreementView.setUpdatedBy("KE3450");
            gpaAgreementView.setStartDate(new Timestamp(System.currentTimeMillis()));

            GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
            agreementDTO.setCreatedTimeStamp(gpaAgreementView.getCreatedTimeStamp());
            agreementDTO.setAgreementId(13343534);
            agreementDTO.setProductId(1234);
            agreementDTO.setStatus("ACTIVE");
            agreementDTO.setCustomerId(1234566);
            agreementDTO.setStartDate(gpaAgreementView.getStartDate());
            agreementDTO.setCreatedBy("PA2680");
            agreementDTO.setUpdatedBy("KE3450");



            when(session.getMapper(GPAAgreementDAOMybatisMapper.class)).thenThrow(new PersistenceException());
            when(sqlSession.openSession()).thenReturn(session);
           underTest.updateGPAAgreement("12340", agreementDTO);

        }catch( GPAAgreementDAOException e)
        {
            assertEquals(GPAAgreementDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_READING_AGREEMENT, (e.getMessages()).getMessages().get(0).getMessageKey());


        }

    }

    /**
     * This method tests the behaviour of method in case invalid status length
     *
     * @throws GPAAgreementDAOException Exception thrown in case of any error
     */
    @Test
    @DisplayName("Test Create Agreement V2 With Invalid Status Length")
    void testCreateAgreementWithInvalidStatusLength() {
        assertThrows(GPAAgreementDAOException.class,()->{
            GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
            agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
            agreementDTO.setAgreementId(1234567890);
            agreementDTO.setProductId(1234);
            agreementDTO.setStatus("NOTACTIVE12");
            agreementDTO.setCustomerId(1234566);
            agreementDTO.setCreatedBy("PA2620");
            agreementDTO.setUpdatedBy("KE3458");
            underTest.createGPAAgreement("12346", agreementDTO);
        });
    }


    /**
     * This method tests the behaviour of method in case input attribute length is exceeding the limit
     *
     * @throws GPAAgreementDAOException Exception thrown in case of any error
     */
    @Test
    @DisplayName("Test Update Agreement V2 With Invalid Attribute Length")
    void testUpdateAgreementWithInvalidInputAttributeLength() {
        assertThrows(GPAAgreementDAOException.class,()->{
            GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
            agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
            agreementDTO.setAgreementId(1234567890);
            agreementDTO.setProductId(1234);
            agreementDTO.setStatus("ACTIVE");
            agreementDTO.setCustomerId(1234566);
            //Invalid length for createdBy
            agreementDTO.setCreatedBy("PA261934567");
            agreementDTO.setUpdatedBy("KE3454");
            underTest.updateGPAAgreement("123405", agreementDTO);
        });
    }
    /*@Test
    @DisplayName("Test Update Agreement V2 With Invalid Attribute Length Exception")
    void testUpdateAgreementWithInvalidInputAttributeLengthException() throws ContractHeaderServiceInvokerException {
        UpdateContractHeaderInputDTO updateContractHeaderInputDTO= new UpdateContractHeaderInputDTO();
        GPAAgreementView gpaAgreementView = new GPAAgreementView();
        gpaAgreementView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
        gpaAgreementView.setAgreementId(13343534);
        gpaAgreementView.setProductId(1234);
        gpaAgreementView.setStatus("ACTIVE");
        gpaAgreementView.setCustomerId(1234566);
        gpaAgreementView.setCreatedBy("PA2680");
        gpaAgreementView.setUpdatedBy("KE3450");
        gpaAgreementView.setStartDate(new Timestamp(System.currentTimeMillis()));

        GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
        agreementDTO.setCreatedTimeStamp(gpaAgreementView.getCreatedTimeStamp());
        agreementDTO.setAgreementId(13343534);
        agreementDTO.setProductId(1234);
        agreementDTO.setStatus("INACTIVE");
        agreementDTO.setCustomerId(1234566);
        agreementDTO.setStartDate(gpaAgreementView.getStartDate());
        agreementDTO.setCreatedBy("PA2680");
        agreementDTO.setUpdatedBy("KE3450");

try {

    when(myBatisMapper.readGPAAgreement(new Long(13343534))).thenReturn(gpaAgreementView);
    when(sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    when(connectionFactory.getMybatisSessionInstance()).thenReturn(sqlSession);
    //  GPAAgreementDTO response = underTest.readGPAAgreement("13343534");

    //  when(connectionFactory.getMybatisSessionInstance()).thenThrow(new PersistenceException());
    underTest.updateGPAAgreement("12340", agreementDTO);
}
 catch (GPAAgreementDAOException e) {
     assertEquals(GPAAgreementDAOMessageKeys.DATABASE_EXCEPTION_WHILE_UPDATING_CONTRACTHEADER, (e.getMessages()).getMessages().get(0).getMessageKey());
}



    }*/

    /**
     * This method tests the behaviour of method in case invalid status length
     *
     * @throws GPAAgreementDAOException Exception thrown in case of any error
     */
    @Test
    @DisplayName("Test Update Agreement V2 With Invalid Status Length")
    void testUpdateAgreementWithInvalidStatusLength() {
        assertThrows(GPAAgreementDAOException.class,()->{
            GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
            agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
            agreementDTO.setAgreementId(1234567890);
            agreementDTO.setProductId(1234);
            agreementDTO.setStatus("NOTACTIVE345");
            agreementDTO.setCustomerId(1234566);
            agreementDTO.setCreatedBy("PA2622");
            agreementDTO.setUpdatedBy("KE3451");
            underTest.updateGPAAgreement("12345", agreementDTO);
        });
    }

    /**
     * This method tests the flow of creating an agreement and return an exception in case if duplicate key present in the database
     *
     * @throws GPAAgreementDAOException exception thrown at DAO layer
     */
    @Test
    @DisplayName("Test Read Agreement V2 ")
    void testReadAgreement() throws GPAAgreementDAOException {
        GPAAgreementView gpaAgreementView = new GPAAgreementView();
        gpaAgreementView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
        gpaAgreementView.setAgreementId(13343534);
        gpaAgreementView.setProductId(1234);
        gpaAgreementView.setStatus("ACTIVE");
        gpaAgreementView.setCustomerId(1234566);
        gpaAgreementView.setCreatedBy("PA2680");
        gpaAgreementView.setUpdatedBy("KE3450");

        GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
        agreementDTO.setCreatedTimeStamp(gpaAgreementView.getCreatedTimeStamp());
        agreementDTO.setAgreementId(13343534);
        agreementDTO.setProductId(1234);
        agreementDTO.setStatus("ACTIVE");
        agreementDTO.setCustomerId(1234566);
        agreementDTO.setCreatedBy("PA2680");
        agreementDTO.setUpdatedBy("KE3450");



        when(myBatisMapper.readGPAAgreement( Long.valueOf(13343534))).thenReturn(gpaAgreementView);
        when(session.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);
        when(sqlSession.openSession()).thenReturn(session);
        when(gpaAgreementViewMapper.covertToGPAAgreementDTO(any())).thenReturn(agreementDTO);
        GPAAgreementDTO response = underTest.readGPAAgreement("13343534");
      //  assertEquals(agreementDTO.getCustomerId(), response.getCustomerId());
        assertEquals(agreementDTO.getProductId(), response.getProductId());

    }


    /**
     * This method tests the flow of creating an agreement and return an exception in case if duplicate key present in the database
     *
     * @throws GPAAgreementDAOException exception thrown at DAO layer
     */
    @Test
   	void testCreateAgreementWithDuplicateKeyResponseFromDB() throws GPAAgreementDAOException {
   		GPAAgreementDTO agreementDTO=new GPAAgreementDTO();
   		agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
   		agreementDTO.setAgreementId(1234567890);
   		agreementDTO.setProductId(1234);
   		agreementDTO.setStatus("ACTIVE");
   		agreementDTO.setCustomerId(1234566);
   		agreementDTO.setCreatedBy("PA2619");
   		agreementDTO.setUpdatedBy("KE3450");
   		GPAAgreementView gpaAgreementView = new GPAAgreementView();
   		gpaAgreementView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
   		gpaAgreementView.setAgreementId(1234567890);
   		gpaAgreementView.setProductId(1234);
   		gpaAgreementView.setStatus("ACTIVE");
   		gpaAgreementView.setCustomerId(1234566);
   		gpaAgreementView.setCreatedBy("PA2619");
   		gpaAgreementView.setUpdatedBy("KE3450");

   		doThrow(new DuplicateKeyException("duplicate test")).when(myBatisMapper).insertAgreement( any());

        when(session.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);
        when(sqlSession.openSession()).thenReturn(session);
   		//PowerMockito.when(myBatisMapper.insertAgreement("test", null)).thenThrow(new DuplicateKeyException());

        assertThrows(DuplicateKeyException.class,()->{

                    underTest.createGPAAgreement(null, agreementDTO);

                    });
      }
   /* @Test
    public void testUpdateAgreementWithDuplicateKeyResponseFromDB() throws GPAAgreementDAOException {
        GPAAgreementDTO agreementDTO=new GPAAgreementDTO();
        agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
        agreementDTO.setAgreementId(1234567890);
        agreementDTO.setProductId(1234);
        agreementDTO.setStatus("ACTIVE");
        agreementDTO.setCustomerId(1234566);
        agreementDTO.setCreatedBy("PA2619");
        agreementDTO.setUpdatedBy("KE3450");
        GPAAgreementView gpaAgreementView = new GPAAgreementView();
        gpaAgreementView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
        gpaAgreementView.setAgreementId(1234567890);
        gpaAgreementView.setProductId(1234);
        gpaAgreementView.setStatus("ACTIVE");
        gpaAgreementView.setCustomerId(1234566);
        gpaAgreementView.setCreatedBy("PA2619");
        gpaAgreementView.setUpdatedBy("KE3450");

        doThrow(new DuplicateKeyException("duplicate test")).when(myBatisMapper).updateAgreement( any());

        when(session.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);
        when(sqlSession.openSession()).thenReturn(session);
        //PowerMockito.when(myBatisMapper.insertAgreement("test", null)).thenThrow(new DuplicateKeyException());
        when(gpaAgreementViewMapper.covertToAgreementView(any())).thenReturn(gpaAgreementView);
        assertThrows(DuplicateKeyException.class,()->{

            underTest.updateGPAAgreement(null, agreementDTO);

        });
    }*/
  /*  @Test()
    @DisplayName("Test Create Agreement V2 for DATABASE_EXCEPTION_WHILE_CREATING_CONTRACT_HEADER")
    void testCreateAgreement() {
        try{
                GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
            agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
            agreementDTO.setAgreementId(1234567890);
            agreementDTO.setProductId(1234);
            agreementDTO.setStatus("ACTIVE");
            agreementDTO.setCustomerId(1234566);
            agreementDTO.setCreatedBy("PA2619");
            agreementDTO.setUpdatedBy("KE3450");
            GPAAgreementView gpaAgreementView = new GPAAgreementView();
            gpaAgreementView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
            gpaAgreementView.setAgreementId(1234567890);
            gpaAgreementView.setProductId(1234);
            gpaAgreementView.setStatus("ACTIVE");
            gpaAgreementView.setCustomerId(1234566);
            gpaAgreementView.setCreatedBy("PA2619");
            gpaAgreementView.setUpdatedBy("KE3450");


           when(sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);
            Mockito.lenient().doNothing().when(myBatisMapper).insertAgreement( gpaAgreementView);

            underTest.createGPAAgreement("12345", agreementDTO);
        } catch (GPAAgreementDAOException e) {
            assertEquals(GPAAgreementDAOMessageKeys.DATABASE_EXCEPTION_WHILE_CREATING_CONTRACTHEADER, (e.getMessages()).getMessages().get(0).getMessageKey());
        }
    }*/
}
