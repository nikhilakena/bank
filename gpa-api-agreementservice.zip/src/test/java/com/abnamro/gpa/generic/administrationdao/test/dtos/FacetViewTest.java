package com.abnamro.gpa.generic.administrationdao.test.dtos;

import com.abnamro.gpa.generic.administrationdao.dtos.FacetView;
import java.sql.Timestamp;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FacetViewTest {

    @InjectMocks FacetView underTest;

    @Mock
    FacetView facetView;

    @BeforeEach
    public void startUp() {
        underTest = getFacetView();
        facetView = getFacetView();
    }

    @Test
    void test(){
        Assertions.assertSame(underTest.getType(),facetView.getType());
        Assertions.assertSame(underTest.getValue(),facetView.getValue());
        Assertions.assertSame(underTest.getCreatedBy(),facetView.getCreatedBy());
        Assertions.assertSame(underTest.getModifiedBy(),facetView.getModifiedBy());
        Assertions.assertSame(underTest.getCreatedTimeStamp().toLocalDateTime().getDayOfMonth(),facetView.getCreatedTimeStamp().toLocalDateTime().getDayOfMonth());
        Assertions.assertSame(underTest.getModifiedTimeStamp().toLocalDateTime().getDayOfMonth(),facetView.getModifiedTimeStamp().toLocalDateTime().getDayOfMonth());
    }

    private FacetView getFacetView() {
        FacetView facetView = new FacetView();
        facetView.setType("TEST-TYPE");
        facetView.setValue("TEST-VALUE");
        facetView.setCreatedBy("TEST-USER");
        facetView.setModifiedBy("TEST-USER");
        facetView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
        facetView.setModifiedTimeStamp(new Timestamp(System.currentTimeMillis()));
        return facetView;
    }

}
