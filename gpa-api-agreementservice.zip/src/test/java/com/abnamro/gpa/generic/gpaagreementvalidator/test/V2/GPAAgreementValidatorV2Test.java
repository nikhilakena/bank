/**
 *
 */
package com.abnamro.gpa.generic.gpaagreementvalidator.test.V2;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dtos.AdminTermView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.constant.GPAAgreementValidatorMessageKeys;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.generic.gpaagreementvalidator.v2.GPAAgreementValidatorV2;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import java.util.ArrayList;
import java.util.List;

import com.abnamro.gpa.restresource.enumeration.TermDataType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * @author C84653
 *
 * This class is test class for GPAAgreementValidatorV2
 *
 */
@ExtendWith(MockitoExtension.class)
class GPAAgreementValidatorV2Test {

	@InjectMocks
	private GPAAgreementValidatorV2 underTest;

	@Mock
	private GPAAdministrationDAO administrationdao;


	@Test()
	void testValidateAgreementWithEmptyInput() throws Exception{

		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateAgreement(inputDTO).isSuccessIndicator(),
				"This test validate agreement with Empty input");
	}

	/*@Test()
	void testValidateAgreementWithInput(){
		try{
			//GPAAgreementValidatorException e = assertThrows(GPAAgreementValidatorException.class,()->{
				GeneralProductAgreement inputDTO = new GeneralProductAgreement();
				inputDTO.setAgreementEndDate("2020-08-19T00:00:00.000Z");
				inputDTO.setAgreementId("121");
				inputDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.INACTIVE);
				inputDTO.setAgreementStartDate("2020-08-18T00:00:00.000Z");
				inputDTO.setCreatedBy("GPAA");
				inputDTO.setCustomerId("0001");
				inputDTO.setProductId("1621");
				List<Term> terms=null;
				terms = new ArrayList<Term>();

				inputDTO.setTerms(terms);


				when(underTest.validateAgreement(inputDTO)).
						thenThrow(new GPAAdministrationDAOException());
			//});
		}catch (GPAAgreementValidatorException e){
			Assertions.assertEquals(GPAAgreementValidatorMessageKeys.TECHNICAL_EXCEPTION_IN_READ_ADMIN, (e.getMessages()).getMessages().get(0).getMessageKey());
		}
	}
*/
	@Test()
	void testValidateAdministrationWithEmptyAdminView() throws Exception{

		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		AdministrationView administrationView=null;

		inputDTO.setAgreementEndDate("2020-06-15T12:16:10Z");
		inputDTO.setAgreementId("121");
		inputDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.INACTIVE);
		inputDTO.setAgreementStartDate("2018-06-15T12:16:10Z");
		inputDTO.setCreatedBy("GPAA");
		inputDTO.setCustomerId("0001");
		inputDTO.setProductId("1621");

		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(false);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateAdministration(administrationView,inputDTO).isSuccessIndicator(),
				"This test Validate Administration With Empty AdminView");
	}

	@Test()
	void testValidateAdministrationWithEmptyAdminAgreement() throws Exception{

		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		AdministrationView administrationView=new AdministrationView();

		List<AdminTermView> adminTermViews=null;
		adminTermViews = new ArrayList<AdminTermView>();

		administrationView.setAdminTermViews(adminTermViews);

		

		AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(true);

		Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
				underTest.validateAdministration(administrationView,inputDTO).isSuccessIndicator(),
				"This test Validate Administration With Empty AdminAgreement");
	}

	@Test()
	void testValidateAllterms() throws Exception{

		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		List<Term> terms=new ArrayList<Term>();
		Term term=new Term();
		term.setAttributeName("Account Number");
		term.setAttributeValue("NL93ABNA0250620502");
		terms.add(term);
		inputDTO.setTerms(terms);

		AdministrationView administrationView=new AdministrationView();

		List<AdminTermView> adminTermViews=null;
		adminTermViews = new ArrayList<AdminTermView>();
		AdminTermView adminTerm=new AdminTermView();
		adminTerm.setName("Account Number");
		adminTerm.setTermId(4);

		administrationView.setAdminTermViews(adminTermViews);

		

		assertNotNull(underTest.validateAllTerms(administrationView,inputDTO));
	}

	@Test()
	void testValidateMandatoryTerms(){

		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		List<Term> terms=new ArrayList<Term>();
		Term term=new Term();
		term.setAttributeName("Account Number");
		term.setAttributeValue("NL93ABNA0250620502");
		terms.add(term);
		inputDTO.setTerms(terms);

		AdministrationView administrationView=new AdministrationView();

		List<AdminTermView> adminTermViews=null;
		adminTermViews = new ArrayList<AdminTermView>();
		AdminTermView adminTerm=new AdminTermView();
		adminTerm.setName("Account Number");
		adminTerm.setTermId(4);
		adminTerm.setMandatoryIndicator("Y");

		administrationView.setAdminTermViews(adminTermViews);

		assertNotNull(underTest.validateMandatoryTerms(administrationView,inputDTO));
	}

	@Test()
	void testReadAdministration(){
		try{
			GeneralProductAgreement inputDTO = new GeneralProductAgreement();
			AdministrationView adminView= new AdministrationView();
			inputDTO.setProductId("1621");
			
			Mockito.lenient().when(administrationdao.readAdministration(0, 1621))
					.thenThrow(new GPAAdministrationDAOException() );



			when(underTest.readAdministration(inputDTO)).thenThrow(new GPAAdministrationDAOException());
		}catch (GPAAgreementValidatorException | GPAAdministrationDAOException e){
			Assertions
					.assertEquals(GPAAgreementValidatorMessageKeys.TECHNICAL_EXCEPTION_IN_READ_ADMIN, (e.getMessages()).getMessages().get(0).getMessageKey());
		}
	}

	@Test()
	void testHandleValidationError(){
		
		String code="CODE_ATTRIBUTE_INVALID";
		String message="DESC_ATTRIBUTE_INVALID";
		String[] paramInfo=new String[]{"Account Number"};
		Boolean successIndicator=true;

		assertNotNull(underTest.handleValidationError(code, message,paramInfo,successIndicator));
	}

	@Test()
	void testvalidateDataTypeValue() throws GPAAgreementValidatorException {
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		List<Term> terms=new ArrayList<Term>();
		Term term=new Term();
		term.setTermId("4");
		term.setAttributeName("Account Number");
		term.setAttributeValue("NL93ABNA0250620502");
		terms.add(term);
		inputDTO.setTerms(terms);

		AdministrationView administrationView=new AdministrationView();
		List<AdminTermView> adminTermViews = new ArrayList<>();
		AdminTermView adminTerm=new AdminTermView();
		adminTerm.setName("Account Number");
		adminTerm.setTermId(4);
		adminTerm.setDataType(TermDataType.NUMERIC.name());
		adminTermViews.add(adminTerm);
		administrationView.setAdminTermViews(adminTermViews);


		

		assertNotNull(underTest.validateAllTerms(administrationView,inputDTO));
	}

	@Test()
	void testvalidateDate() throws GPAAgreementValidatorException {
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		List<Term> terms=new ArrayList<Term>();
		Term term=new Term();
		term.setTermId("4");

		term.setAttributeName("Account Number");
		term.setAttributeValue("NL93ABNA0250620502");
		terms.add(term);
		inputDTO.setTerms(terms);

		AdministrationView administrationView=new AdministrationView();
		List<AdminTermView> adminTermViews = new ArrayList<>();
		AdminTermView adminTerm=new AdminTermView();
		adminTerm.setName("Account Number");
		adminTerm.setTermId(4);
		adminTerm.setDataType(TermDataType.DATE.name());

		adminTermViews.add(adminTerm);
		administrationView.setAdminTermViews(adminTermViews);


		

		assertNotNull(underTest.validateAllTerms(administrationView,inputDTO));
	}

	@Test()
	void testvalidateTime() throws GPAAgreementValidatorException {
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		List<Term> terms=new ArrayList<Term>();
		Term term=new Term();
		term.setTermId("4");

		term.setAttributeName("Account Number");
		term.setAttributeValue("NL93ABNA0250620502");
		terms.add(term);
		inputDTO.setTerms(terms);

		AdministrationView administrationView=new AdministrationView();
		List<AdminTermView> adminTermViews = new ArrayList<>();
		AdminTermView adminTerm=new AdminTermView();
		adminTerm.setName("Account Number");
		adminTerm.setTermId(4);
		adminTerm.setDataType(TermDataType.TIME.name());

		adminTermViews.add(adminTerm);
		administrationView.setAdminTermViews(adminTermViews);


		

		assertNotNull(underTest.validateAllTerms(administrationView,inputDTO));
	}

	@Test()
	void testvalidateDateTime() throws GPAAgreementValidatorException {
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		List<Term> terms=new ArrayList<Term>();
		Term term=new Term();
		term.setTermId("4");

		term.setAttributeName("Account Number");
		term.setAttributeValue("NL93ABNA0250620502");
		terms.add(term);
		inputDTO.setTerms(terms);

		AdministrationView administrationView=new AdministrationView();
		List<AdminTermView> adminTermViews = new ArrayList<>();
		AdminTermView adminTerm=new AdminTermView();
		adminTerm.setName("Account Number");
		adminTerm.setTermId(4);
		adminTerm.setDataType(TermDataType.DATETIME.name());

		adminTermViews.add(adminTerm);
		administrationView.setAdminTermViews(adminTermViews);


		

		assertNotNull(underTest.validateAllTerms(administrationView,inputDTO));
	}
}




