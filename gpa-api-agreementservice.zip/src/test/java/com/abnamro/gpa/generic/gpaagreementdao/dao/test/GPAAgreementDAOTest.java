package com.abnamro.gpa.generic.gpaagreementdao.dao.test;


import com.abnamro.gpa.generic.gpaagreementdao.constants.GPAAgreementDAOMessageKeys;
import com.abnamro.gpa.generic.gpaagreementdao.dao.GPAAgreementDAO;
import com.abnamro.gpa.generic.gpaagreementdao.dao.GPAAgreementDAOMybatisMapper;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.generic.gpaagreementdao.helper.GPAAgreementDaoViewMapper;
import com.abnamro.gpa.generic.gpaagreementdao.view.GPAAgreementView;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

/**
 * This is test dao layer class for GPA Agreement.
 * @author C45158
 *
 */


@ExtendWith(MockitoExtension.class)
class GPAAgreementDAOTest{
	@InjectMocks
	private GPAAgreementDAO underTest;
	@Mock
	private GPAAgreementDaoViewMapper gpaAgreementViewMapper ;

	@Mock
	private GPAAgreementDAOMybatisMapper myBatisMapper;



    @Mock
    private SqlSession sqlSession;

    @Mock
	private SqlSessionFactory sessionFactory;







	/**
     * This method opens mocked test database connection at start of test case execution
     * @throws DAODatabaseException exception in case of opening test database connection
     * @throws MyBatisConfigException exception in case of opening session using MyBatis connection factory
     */
    @BeforeEach
    public void startUp() throws GPAAgreementDAOException {

      //  when(DAODatabaseUtil.openConnection("test")).thenReturn(connection);
       /* connectionFactory = mock(ConnectionHelper.class);
        when(connectionFactory.getMybatisSessionInstance()).thenReturn(sqlSession);
        when(sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);
		underTest = new GPAAgreementDAO( "test", connectionFactory);*/
    }


    /**
     * This method tests the behaviour of method in case input attribute length is exceeding the limit
     * @throws GPAAgreementDAOException Exception thrown in case of any error
     */
    @Test
	@DisplayName("Test Create Agreement With Invalid Input Attribute Length")
	void testCreateAgreementWithInvalidInputAttributeLength() {
    	try{

			GPAAgreementDTO agreementDTO=new GPAAgreementDTO();
			agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
			agreementDTO.setAgreementId(1234567890);
			agreementDTO.setProductId(1234);
			agreementDTO.setStatus("ACTIVE");
			agreementDTO.setCustomerId(1234566);
			//Invalid length for createdBy
			agreementDTO.setCreatedBy("PA2619345787");
			agreementDTO.setUpdatedBy("KE3459");
			underTest.createGPAAgreement(agreementDTO);
		} catch (GPAAgreementDAOException e) {
			assertEquals(GPAAgreementDAOMessageKeys.INVALID_LENGTH_PARAMS_EXCEPTION_WHILE_CREATING_AGREEMENT, (e.getMessages()).getMessages().get(0).getMessageKey());
		}
	}

    /**
     * This method tests the behaviour of method in case invalid status length
     * @throws GPAAgreementDAOException Exception thrown in case of any error
     */
    @Test
	@DisplayName("Test Create Agreement With Invalid Status Length")
   	void testCreateAgreementWithInvalidStatusLength() {
    	try{

			GPAAgreementDTO agreementDTO=new GPAAgreementDTO();
			agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
			agreementDTO.setAgreementId(1234567890);
			agreementDTO.setProductId(1234);
			agreementDTO.setStatus("NOTACTIVE12");
			agreementDTO.setCustomerId(1234566);
			agreementDTO.setCreatedBy("PA2620");
			agreementDTO.setUpdatedBy("KE3458");
			underTest.createGPAAgreement(agreementDTO);
		} catch (GPAAgreementDAOException e) {
			assertEquals(GPAAgreementDAOMessageKeys.INVALID_LENGTH_PARAMS_EXCEPTION_WHILE_CREATING_AGREEMENT, (e.getMessages()).getMessages().get(0).getMessageKey());
		}
	}


    /**
     * This method tests the behaviour of method in case input attribute length is exceeding the limit
     * @throws GPAAgreementDAOException Exception thrown in case of any error
     */
    @Test
	@DisplayName("Test Update Agreement With Invalid Attribute Length")
   	void testUpdateAgreementWithInvalidInputAttributeLength() {
    	try{

			GPAAgreementDTO agreementDTO=new GPAAgreementDTO();
			agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
			agreementDTO.setAgreementId(1234567890);
			agreementDTO.setProductId(1234);
			agreementDTO.setStatus("ACTIVE");
			agreementDTO.setCustomerId(1234566);
			//Invalid length for createdBy
			agreementDTO.setCreatedBy("PA261934567");
			agreementDTO.setUpdatedBy("KE3454");
			underTest.updateGPAAgreement(agreementDTO);
		} catch (GPAAgreementDAOException e) {
			assertEquals(GPAAgreementDAOMessageKeys.INVALID_LENGTH_PARAMS_EXCEPTION_WHILE_UPDATING_AGREEMENT, (e.getMessages()).getMessages().get(0).getMessageKey());
		}
	}

    /**
     * This method tests the behaviour of method in case invalid status length
     * @throws GPAAgreementDAOException Exception thrown in case of any error
     */
    @Test
	@DisplayName("Test Update Agreement With Invalid Status Length")
   	void testUpdateAgreementWithInvalidStatusLength() {
		try {

			GPAAgreementDTO agreementDTO=new GPAAgreementDTO();
			agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
			agreementDTO.setAgreementId(1234567890);
			agreementDTO.setProductId(1234);
			agreementDTO.setStatus("NOTACTIVE345");
			agreementDTO.setCustomerId(1234566);
			agreementDTO.setCreatedBy("PA2622");
			agreementDTO.setUpdatedBy("KE3451");
			underTest.updateGPAAgreement(agreementDTO);
		} catch (GPAAgreementDAOException e) {
			assertEquals(GPAAgreementDAOMessageKeys.INVALID_LENGTH_PARAMS_EXCEPTION_WHILE_UPDATING_AGREEMENT, (e.getMessages()).getMessages().get(0).getMessageKey());
		}
	}

    /**
     * This method tests the flow of creating an agreement and return an exception in case if duplicate key present in the database
     * @throws GPAAgreementDAOException exception thrown at DAO layer
     */
    @Test
	@DisplayName("Test Read Agreement")
   	void testReadAgreement() {
		try {

			GPAAgreementView gpaAgreementView = new GPAAgreementView();
			gpaAgreementView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
			gpaAgreementView.setAgreementId(1234567890);
			gpaAgreementView.setProductId(1234);
			gpaAgreementView.setStatus("ACTIVE");
			gpaAgreementView.setCustomerId(1234566);
			gpaAgreementView.setCreatedBy("PA2680");
			gpaAgreementView.setUpdatedBy("KE3450");

			GPAAgreementDTO agreementDTO=new GPAAgreementDTO();
			agreementDTO.setCreatedTimeStamp(gpaAgreementView.getCreatedTimeStamp());
			agreementDTO.setAgreementId(1234567890);
			agreementDTO.setProductId(1234);
			agreementDTO.setStatus("ACTIVE");
			agreementDTO.setCustomerId(1234566);
			agreementDTO.setCreatedBy("PA2680");
			agreementDTO.setUpdatedBy("KE3450");



			when(myBatisMapper.readGPAAgreement( Long.valueOf(13343534))).thenReturn(gpaAgreementView);
			when(sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);
			when(sessionFactory.openSession()).thenReturn(sqlSession);
			when(gpaAgreementViewMapper.covertToGPAAgreementDTO(any())).thenReturn(agreementDTO);
			GPAAgreementDTO response = underTest.readGPAAgreement("13343534");

			assertEquals(agreementDTO.getCustomerId(), response.getCustomerId());
			assertEquals(agreementDTO.getProductId(), response.getProductId());

		} catch (GPAAgreementDAOException e) {
			fail("not expected an GPAAgreementDAOException");
		}
      }


    /**
     * This method tests the flow of creating an agreement and return an exception in case if duplicate key present in the database
     * @throws GPAAgreementDAOException exception thrown at DAO layer
     */
   /* @Test(expected=GPAAgreementDAOException.class)
   	public void testCreateAgreementWithDuplicateKeyResponseFromDB() throws GPAAgreementDAOException {
    	underTest = new GPAAgreementDAO("test","test",connectionFactory);
   		GPAAgreementDTO agreementDTO=new GPAAgreementDTO();
   		agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
   		agreementDTO.setAgreementId(1234567890);
   		agreementDTO.setProductId(1234);
   		agreementDTO.setStatus("ACTIVE");
   		agreementDTO.setCustomerId(1234566);
   		agreementDTO.setCreatedBy("PA2619");
   		agreementDTO.setUpdatedBy("KE3450");
   		GPAAgreementView gpaAgreementView = new GPAAgreementView();
   		gpaAgreementView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
   		gpaAgreementView.setAgreementId(1234567890);
   		gpaAgreementView.setProductId(1234);
   		gpaAgreementView.setStatus("ACTIVE");
   		gpaAgreementView.setCustomerId(1234566);
   		gpaAgreementView.setCreatedBy("PA2619");
   		gpaAgreementView.setUpdatedBy("KE3450");

   		PowerMockito.doThrow(new DuplicateKeyException()).when(myBatisMapper).insertAgreement("test", null);
   		//PowerMockito.when(myBatisMapper.insertAgreement("test", null)).thenThrow(new DuplicateKeyException());
   		underTest.createGPAAgreement(null, agreementDTO);
      }
   */
/*
	@Test()
	@DisplayName("Test Create Agreement for DATABASE_EXCEPTION_WHILE_CREATING_CONTRACT_HEADER")
	void testCreateAgreement() {
		try{
			GPAAgreementView gpaAgreementView = new GPAAgreementView();
			gpaAgreementView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
			gpaAgreementView.setAgreementId(1234567890);
			gpaAgreementView.setProductId(1234);
			gpaAgreementView.setStatus("ACTIVE");
			gpaAgreementView.setCustomerId(1234566);
			gpaAgreementView.setCreatedBy("PA2680");
			gpaAgreementView.setUpdatedBy("KE3450");
			gpaAgreementView.setStartDate(new Timestamp(System.currentTimeMillis()));

			GPAAgreementDTO agreementDTO=new GPAAgreementDTO();
			agreementDTO.setCreatedTimeStamp(gpaAgreementView.getCreatedTimeStamp());
			agreementDTO.setAgreementId(1234567890);
			agreementDTO.setProductId(1234);
			agreementDTO.setStatus("ACTIVE");
			agreementDTO.setCustomerId(1234566);
			agreementDTO.setCreatedBy("PA2680");
			agreementDTO.setUpdatedBy("KE3450");
			agreementDTO.setStartDate(gpaAgreementView.getStartDate());

			when(connectionHelperMock.getConnection("test")).thenReturn(connection);
			when(connectionHelperMock.getMybatisSessionInstance("test")).thenReturn(sqlSession);
			//when(gpaAgreementViewMapper.covertToAgreementView(agreementDTO)).thenReturn(gpaAgreementView);
			when(sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)).thenReturn(myBatisMapper);
			Mockito.lenient().doNothing().when(myBatisMapper).insertAgreement("UU01", gpaAgreementView);

			underTest.createGPAAgreement(agreementDTO);
		} catch (GPAAgreementDAOException e) {
			assertEquals(GPAAgreementDAOMessageKeys.DATABASE_EXCEPTION_WHILE_CREATING_CONTRACTHEADER, (e.getMessages()).getMessages().get(0).getMessageKey());
		} catch (DAODatabaseException e) {
			fail("not expected an exception");
		}
	}
*/
    }
