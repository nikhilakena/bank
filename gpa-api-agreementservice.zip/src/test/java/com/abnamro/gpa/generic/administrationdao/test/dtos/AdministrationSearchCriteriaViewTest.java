package com.abnamro.gpa.generic.administrationdao.test.dtos;

import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationSearchCriteriaView;
import java.sql.Timestamp;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AdministrationSearchCriteriaViewTest {

    @InjectMocks
    AdministrationSearchCriteriaView underTest;

    @Mock
    AdministrationSearchCriteriaView administrationSearchCriteriaView;

    @BeforeEach
    public void startUp() {
        underTest = getAdministrationSearchCriteriaView();
        administrationSearchCriteriaView = getAdministrationSearchCriteriaView();
    }

    @Test
    void test(){
        Assertions.assertSame(underTest.getAdministrationId(),administrationSearchCriteriaView.getAdministrationId());
        Assertions.assertSame(underTest.getAdministrationName(),administrationSearchCriteriaView.getAdministrationName());
        Assertions.assertSame(underTest.getOarId(),administrationSearchCriteriaView.getOarId());
        Assertions.assertSame(underTest.getCreatedBy(),administrationSearchCriteriaView.getCreatedBy());
        Assertions.assertSame(underTest.getCreatedTimestampFrom().toLocalDateTime().getDayOfMonth(),administrationSearchCriteriaView.getCreatedTimestampFrom().toLocalDateTime().getDayOfMonth());
        Assertions.assertSame(underTest.getCreatedTimestampTo().toLocalDateTime().getDayOfMonth(),administrationSearchCriteriaView.getCreatedTimestampTo().toLocalDateTime().getDayOfMonth());
    }

    private AdministrationSearchCriteriaView getAdministrationSearchCriteriaView() {
        AdministrationSearchCriteriaView administrationSearchCriteriaView = new AdministrationSearchCriteriaView();
        administrationSearchCriteriaView.setAdministrationId(1);
        administrationSearchCriteriaView.setAdministrationName("TEST-NAME");
        administrationSearchCriteriaView.setOarId("AAB.SYS.GPA");
        administrationSearchCriteriaView.setCreatedBy("TEST-USER");
        administrationSearchCriteriaView.setCreatedTimestampFrom(new Timestamp(System.currentTimeMillis()));
        administrationSearchCriteriaView.setCreatedTimestampTo(new Timestamp(System.currentTimeMillis()));
        return administrationSearchCriteriaView;
    }

}
