/**
 * This class performs validations based on the facet types & values defined for an administration.
 */
package com.abnamro.gpa.generic.gpaagreementvalidator.test.V2;



import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.generic.gpaagreementvalidator.v2.FacetValidatorV2;
import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermFacetRestResource;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * @author C84653
 * This class is test class for facet validator V2
 *
 */
@ExtendWith(MockitoExtension.class)
class FacetValidatorV2Test {

  @InjectMocks
  private FacetValidatorV2 underTest;

  @Test()
  void testValidateFacetWithNumeric(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestNumeric2");
    termDetails.setDataType(TermDataType.NUMERIC);

    TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
    termFacetRestResource.setFacetType(FacetTypes.LENGTH);
    termFacetRestResource.setFacetValue("3");

    AuditDetails auditDetails  = new AuditDetails();
    auditDetails.setCreatedBy("GPAGLO");
    auditDetails.setCreatedTimeStamp(new Date());

    termFacetRestResource.setAuditDetails(auditDetails);

    facets.add(termFacetRestResource);

    termDetails.setFacets(facets);
    String termValue="1000";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(false);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With Numeric");
  }

  @Test()
  void testvalidateSingleNumericValueFacetCategoty(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestNumeric2");
    termDetails.setDataType(TermDataType.NUMERIC);

    TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
    termFacetRestResource.setFacetType(FacetTypes.FRACTIONS);
    termFacetRestResource.setFacetValue("3");

    AuditDetails auditDetails  = new AuditDetails();
    auditDetails.setCreatedBy("GPAGLO");
    auditDetails.setCreatedTimeStamp(new Date());

    termFacetRestResource.setAuditDetails(auditDetails);

    facets.add(termFacetRestResource);

    termDetails.setFacets(facets);
    String termValue="1000.2345";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(false);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
            underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
            "This test Validate Facet With Numeric");
  }


  @Test()
  void testvalidateRangeFacetCategoty(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestNumeric2");
    termDetails.setDataType(TermDataType.NUMERIC);

    TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
    termFacetRestResource.setFacetType(FacetTypes.MININCLUSIVE);
    termFacetRestResource.setFacetValue("3");

    AuditDetails auditDetails  = new AuditDetails();
    auditDetails.setCreatedBy("GPAGLO");
    auditDetails.setCreatedTimeStamp(new Date());

    termFacetRestResource.setAuditDetails(auditDetails);

    facets.add(termFacetRestResource);

    termDetails.setFacets(facets);
    String termValue="1000.2345";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(false);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
            underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
            "This test Validate Facet With Numeric");
  }


  @Test()
  void testvalidateRangeFacetCategotyMInExcusive(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestNumeric2");
    termDetails.setDataType(TermDataType.NUMERIC);

    TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
    termFacetRestResource.setFacetType(FacetTypes.MINEXCLUSIVE);
    termFacetRestResource.setFacetValue("3");

    AuditDetails auditDetails  = new AuditDetails();
    auditDetails.setCreatedBy("GPAGLO");
    auditDetails.setCreatedTimeStamp(new Date());

    termFacetRestResource.setAuditDetails(auditDetails);

    facets.add(termFacetRestResource);

    termDetails.setFacets(facets);
    String termValue="1000.2345";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(false);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
            underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
            "This test Validate Facet With Numeric");
  }
  @Test()
  void testvalidateListFacetCategory(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestNumeric2");
    termDetails.setDataType(TermDataType.NUMERIC);

    TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
    termFacetRestResource.setFacetType(FacetTypes.ENUMERATION);
    termFacetRestResource.setFacetValue("3");

    AuditDetails auditDetails  = new AuditDetails();
    auditDetails.setCreatedBy("GPAGLO");
    auditDetails.setCreatedTimeStamp(new Date());

    termFacetRestResource.setAuditDetails(auditDetails);

    facets.add(termFacetRestResource);

    termDetails.setFacets(facets);
    String termValue="1000.2345";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(false);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
            underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
            "This test Validate Facet With Numeric");
  }
  @Test()
  void testValidateFacetWithTotalDigits(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("Provisional Credit Limit");
    termDetails.setDataType(TermDataType.NUMERIC);

    termDetails.setFacets(facets);
    String termValue="2.456";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With TotalDigits");
  }

  @Test()
  void testValidateFacetWithFraction(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("Provisional Credit Limit");
    termDetails.setDataType(TermDataType.NUMERIC);

    termDetails.setFacets(facets);
    String termValue="233.45667";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With Fraction");
  }

  @Test()
  void testValidateFacetWithCorrectPattern(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("Bank Account Number");
    termDetails.setDataType(TermDataType.STRING);

    termDetails.setFacets(facets);
    String termValue="NL93ABNA1234567893";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With CorrectPattern");
  }

  @Test()
  void testValidateFacetWithWrongPattern(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("Bank Account Number");
    termDetails.setDataType(TermDataType.STRING);

    termDetails.setFacets(facets);
    String termValue="7693ABNA1234593";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With WrongPattern");
  }
  @Test()
  void testvalidateSingleValueFacetCategotyPattern(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();
    TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
    termFacetRestResource.setFacetType(FacetTypes.PATTERN);
    termFacetRestResource.setFacetValue("7693ABNA1234593AS");

    termDetails.setName("Bank Account Number");
    termDetails.setDataType(TermDataType.STRING);
    facets.add(termFacetRestResource);
    termDetails.setFacets(facets);
    String termValue="7693ABNA1234593";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(false);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
            underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
            "This test Validate Facet With WrongPattern");
  }
  @Test()
  void testvalidateSingleValueFacetCategotyMinLength(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();
    TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
    termFacetRestResource.setFacetType(FacetTypes.MINLENGTH);
    termFacetRestResource.setFacetValue("769312");

    termDetails.setName("Bank Account Number");
    termDetails.setDataType(TermDataType.STRING);
    facets.add(termFacetRestResource);
    termDetails.setFacets(facets);
    String termValue="769312";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(false);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
            underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
            "Length for Attribute Name : "+termDetails.getName()+" is invalid");
  }
  @Test()
  void testvalidateSingleValueFacetCategotyMaxLength(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();
    TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
    termFacetRestResource.setFacetType(FacetTypes.MAXLENGTH);
    termFacetRestResource.setFacetValue("769312");

    termDetails.setName("Bank Account Number");
    termDetails.setDataType(TermDataType.STRING);
    facets.add(termFacetRestResource);
    termDetails.setFacets(facets);
    String termValue="769312";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
            underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
            "Maximum length for  Name : "+termDetails.getName()+" is invalid");
  }

  @Test()
  void testValidateFacetWithValidListValues(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("Smart Safe Processer");
    termDetails.setDataType(TermDataType.STRING);

    termDetails.setFacets(facets);
    String termValue="Securecash";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With Valid ListValues");

  }

  @Test()
  void testValidateFacetWithINValidListValues(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("Smart Safe Processer");
    termDetails.setDataType(TermDataType.STRING);

    termDetails.setFacets(facets);
    String termValue="InvalidTestValue";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With INValid ListValues");

  }

  @Test()
  void testValidateFacetWithValidMaxLength(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("Unit Number Contract");
    termDetails.setDataType(TermDataType.STRING);

    termDetails.setFacets(facets);
    String termValue="6754657";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With Valid MaxLength");

  }

  @Test()
  void testValidateFacetWithInValidMaxLength(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("Unit Number Contract");
    termDetails.setDataType(TermDataType.STRING);

    termDetails.setFacets(facets);
    String termValue="58727689276728670";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With InValid MaxLength");

  }

  @Test()
  void testValidateFacetWithValidBoolean(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestBoolean1");
    termDetails.setDataType(TermDataType.BOOLEAN);

    termDetails.setFacets(facets);
    String termValue="Yes";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With Valid Boolean");

  }

  @Test()
  void testValidateFacetWithInValidBoolean(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestBoolean1");
    termDetails.setDataType(TermDataType.BOOLEAN);

    termDetails.setFacets(facets);
    String termValue="Yes11";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With InValid Boolean");

  }

  @Test()
  void testValidateFacetWithValidMinMaxLength(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestNumeric1");
    termDetails.setDataType(TermDataType.NUMERIC);

    termDetails.setFacets(facets);
    String termValue="18";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With Valid MinMaxLength");

  }

  @Test()
  void testValidateFacetWithInValidMinLength(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestNumeric1");
    termDetails.setDataType(TermDataType.NUMERIC);

    termDetails.setFacets(facets);
    String termValue="2";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With InValid MinLength");

  }

  @Test()
  void testValidateFacetWithValidDate(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestDate1");
    termDetails.setDataType(TermDataType.DATE);

    termDetails.setFacets(facets);
    String termValue="2018-06-20";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With Valid Date");

  }

  @Test()
  void testValidateFacetWithInValidDate(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestDate1");
    termDetails.setDataType(TermDataType.DATE);

    termDetails.setFacets(facets);
    String termValue="2018-06-20 5235325";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With InValid Date");

  }

  @Test()
  void testValidateFacetWithValidDateTime(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestDate1");
    termDetails.setDataType(TermDataType.DATE);

    termDetails.setFacets(facets);
    String termValue="2018-06-20 12:45:37";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With Valid DateTime");

  }

  @Test()
  void testValidateFacetWithInValidDateTime(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestDate1");
    termDetails.setDataType(TermDataType.DATE);

    termDetails.setFacets(facets);
    String termValue="2018-06-20 12:45:37:46873256";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With InValid DateTime");

  }

  @Test()
  void testValidateFacetWithValidTime(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestDate1");
    termDetails.setDataType(TermDataType.DATE);

    termDetails.setFacets(facets);
    String termValue="12:45:37";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With Valid Time");

  }

  @Test()
  void testValidateFacetWithInValidTime(){

    TermRestResource termDetails = new TermRestResource();
    List<TermFacetRestResource> facets=null;
    facets =new ArrayList<TermFacetRestResource>();

    termDetails.setName("TestDate1");
    termDetails.setDataType(TermDataType.DATE);

    termDetails.setFacets(facets);
    String termValue="12:45:37:57632";

   

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    Assertions.assertEquals(agreementValidatorResultDTO.isSuccessIndicator(),
        underTest.validateFacet(termDetails, termValue).isSuccessIndicator(),
        "This test Validate Facet With InValidTime");
  }

}
