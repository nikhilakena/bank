/**
 *
 */
package com.abnamro.gpa.generic.gpaagreementvalidator.test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.abnamro.gpa.generic.gpaagreementvalidator.GenericAgreementDetailsValidator;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * @author C45158
 *
 * This class is tes class for GenericAgreementDetailsValidator
 *
 */
@ExtendWith(MockitoExtension.class)
class GenericAgreementDetailsValidatorTest {


	private GenericAgreementDetailsValidator underTest;

	@Test()
	void testValidateGenericDetailsWithInvalidProductId() {
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setAgreementEndDate("2020-06-15 12:16:10");
		inputDTO.setAgreementId("121");
		inputDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.INACTIVE);
		inputDTO.setAgreementStartDate("2018-06-15 12:16:10");
		inputDTO.setCreatedBy("GPAA");
		inputDTO.setCustomerId("0001");
		inputDTO.setProductId("65872365");
		List<Term> terms=null;
		terms = new ArrayList<Term>();

		inputDTO.setTerms(terms);

		underTest = new GenericAgreementDetailsValidator();
		underTest.validateGenericDetails(inputDTO);

		//Assert.assertEquals("This method validate enric details of an agreeement",agreementValidatorResultDTO, underTest.validateGenericDetails(inputDTO));
	}

	@Test()
	void testValidateGenericDetailsWithInvalidCustomerId() throws Exception{
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setCustomerId("563");
		underTest = new GenericAgreementDetailsValidator();
		underTest.validateGenericDetails(inputDTO);
	}

	@Test()
	void testValidateGenericDetailsWithInvalidAgreementStartDate() throws Exception{
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setAgreementStartDate("2018-06-12 00:59:59");
		underTest = new GenericAgreementDetailsValidator();
		underTest.validateGenericDetails(inputDTO);
	}

	@Test()
	void testValidateGenericDetailsWithInvalidAgreementEndDate() throws Exception{
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setAgreementStartDate("2018-05-12 00:59:59");
		underTest = new GenericAgreementDetailsValidator();
		underTest.validateGenericDetails(inputDTO);
	}

	@Test()
	void testValidateGenericDetailsWithInvalidStatus() throws Exception{
		GeneralProductAgreement inputDTO = new GeneralProductAgreement();
		inputDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.INACTIVE);
		underTest = new GenericAgreementDetailsValidator();

		assertNotNull(underTest.validateGenericDetails(inputDTO));
	}

}

