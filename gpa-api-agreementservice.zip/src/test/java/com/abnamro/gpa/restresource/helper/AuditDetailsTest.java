package com.abnamro.gpa.restresource.helper;

import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AuditDetailsTest{

  AuditDetails underTest;

  AuditDetails testAuditDetails = new AuditDetails();

  String createdBy = "GPAA";
  Date createdTimeStamp = new Date();
  String modifiedBy = "GPAA update";
  Date modifiedTimeStamp = new Date();

  @BeforeEach
  public void startUp() {
    underTest = new AuditDetails();

    //set default
    testAuditDetails = new AuditDetails();
    testAuditDetails.setCreatedBy("GPAA");
    testAuditDetails.setCreatedTimeStamp(createdTimeStamp);
    testAuditDetails.setModifiedBy("GPAA update");
    testAuditDetails.setModifiedTimeStamp(modifiedTimeStamp);
  }

  @Test
  void testGettersSetterAuditDetails() {

    underTest.setCreatedBy(createdBy);
    underTest.setCreatedTimeStamp(createdTimeStamp);
    underTest.setModifiedBy(modifiedBy);
    underTest.setModifiedTimeStamp(modifiedTimeStamp);

    Assertions.assertSame(underTest.getCreatedBy(),testAuditDetails.getCreatedBy());
    Assertions.assertSame(underTest.getCreatedTimeStamp(),testAuditDetails.getCreatedTimeStamp());
    Assertions.assertSame(underTest.getModifiedBy(),testAuditDetails.getModifiedBy());
    Assertions.assertSame(underTest.getModifiedTimeStamp(),testAuditDetails.getModifiedTimeStamp());
  }
}
