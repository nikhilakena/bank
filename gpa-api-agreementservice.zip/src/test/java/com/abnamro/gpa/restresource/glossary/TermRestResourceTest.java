package com.abnamro.gpa.restresource.glossary;

import com.abnamro.gpa.restresource.util.UtilityClass;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TermRestResourceTest {

  TermRestResource underTest;
  TermRestResource testTermRestResource;

  UtilityClass utilityClass = new UtilityClass();

  @BeforeEach
  public void startUp() {
    underTest = new TermRestResource();

    //set default
    testTermRestResource = new TermRestResource();
    testTermRestResource = utilityClass.setterTermRestResource();
  }

  @Test
  void testGettersSetterTermRestResource() {

    underTest = utilityClass.setterTermRestResource();

    Assertions.assertSame(underTest.getId(),testTermRestResource.getId());
    Assertions.assertSame(underTest.getName(),testTermRestResource.getName());
    Assertions.assertSame(underTest.getDataType(),testTermRestResource.getDataType());
    Assertions.assertSame(underTest.getDescription(),testTermRestResource.getDescription());
    Assertions.assertSame(underTest.isMandatory(),testTermRestResource.isMandatory());
    Assertions.assertSame(underTest.getFacets().get(0).getAuditDetails().getCreatedBy(),testTermRestResource.getFacets().get(0).getAuditDetails().getCreatedBy());
    Assertions.assertSame(underTest.getAuditDetails().getCreatedBy(),testTermRestResource.getAuditDetails().getCreatedBy());
  }
}
