package com.abnamro.gpa.restresource.glossary;

import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import com.abnamro.gpa.restresource.util.UtilityClass;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TermFacetRestResourceTest {

  TermFacetRestResource underTest;
  TermFacetRestResource testTermFacetRestResource;

  FacetTypes facetType ;

  String facetValue = "5";

  AuditDetails auditDetails;

  UtilityClass utilityClass = new UtilityClass();

  @BeforeEach
  public void startUp() {
    underTest = new TermFacetRestResource();

    //set default
    testTermFacetRestResource = new TermFacetRestResource();
    testTermFacetRestResource.setFacetType(FacetTypes.LENGTH);
    testTermFacetRestResource.setFacetValue(facetValue);

    auditDetails = utilityClass.setterAuditDetails();

    testTermFacetRestResource.setAuditDetails(auditDetails);
  }

  @Test
  void testGettersSetterTerm() {
    underTest.setFacetType(FacetTypes.LENGTH);
    underTest.setFacetValue(facetValue);

    auditDetails = utilityClass.setterAuditDetails();

    underTest.setAuditDetails(auditDetails);

    Assertions.assertSame(underTest.getFacetType(),testTermFacetRestResource.getFacetType());
    Assertions.assertSame(underTest.getFacetValue(),testTermFacetRestResource.getFacetValue());
    Assertions.assertSame(underTest.getAuditDetails().getCreatedBy(),testTermFacetRestResource.getAuditDetails().getCreatedBy());
  }

}
