package com.abnamro.gpa.restservices.gpaagreement.dataGenerator.v2;

import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.dtos.ProductAdminMapView;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementTermDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementRequestDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.ReadGPAAgreementResponseDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.TermResponseDTOV2;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TestDataGenerator {

    private static CreateGPAAgreementRequestDTOV2 createAgreementRequest;

    public static CreateGPAAgreementRequestDTOV2 getCreateAgreementRequest() {
        createAgreementRequest = new CreateGPAAgreementRequestDTOV2();
        createAgreementRequest.setProductId(3450);
        createAgreementRequest.setCustomerId("156043");
        createAgreementRequest.setAgreementEndDateTime("2021-04-01T00:00:00.000Z");
        createAgreementRequest.setAgreementStartDateTime("2021-04-30T00:00:00.000Z");
        createAgreementRequest.setAgreementLifeCycleStatusType("DRAFT");
        createAgreementRequest.setUserId("pa2619");

        List<Term> attributes = new ArrayList<Term>();
        Term term = new Term();
        term.setAttributeName("test term");
        term.setAttributeValue("Test term value");
        attributes.add(term);
        createAgreementRequest.setAttributes(attributes);

        return createAgreementRequest;
    }

    public static GeneralProductAgreement getGeneralProductAgreement() {
        GeneralProductAgreement generalProductAgreement = new GeneralProductAgreement();

        generalProductAgreement.setAgreementEndDate(createAgreementRequest.getAgreementEndDateTime());
        generalProductAgreement.setAgreementId(createAgreementRequest.getAgreementId());
        generalProductAgreement.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.valueOf(createAgreementRequest.getAgreementLifeCycleStatusType()));
        generalProductAgreement.setAgreementStartDate(createAgreementRequest.getAgreementStartDateTime());
        generalProductAgreement.setCustomerId(createAgreementRequest.getCustomerId());
        generalProductAgreement.setProductId(String.valueOf(createAgreementRequest.getProductId()));
        generalProductAgreement.setCreatedBy(createAgreementRequest.getUserId());

        if (createAgreementRequest.getAttributes() != null) {
            List<Term> restDomainTerms = null;

            restDomainTerms = new ArrayList<Term>();
            for (Term dtoTerms : createAgreementRequest.getAttributes()) {
                restDomainTerms.add(dtoTerms);
            }
            generalProductAgreement.setTerms(restDomainTerms);
        }
        return generalProductAgreement;
    }

    public static UpdateGPAAgreementRequestDTO getUpdateGPAAgreementRequestDTO() {
        UpdateGPAAgreementRequestDTO updateAgreementRequest = new UpdateGPAAgreementRequestDTO();
        updateAgreementRequest.setAgreementEndDateTime("2021-04-01 00:00:00");
        updateAgreementRequest.setAgreementLifeCycleStatusType("DRAFT");
        updateAgreementRequest.setAgreementStartDateTime("2021-04-30 00:00:00");
        updateAgreementRequest.setUserId("pa2619");

        List<Term> attributes = new ArrayList<Term>();
        Term term = new Term();
        term.setAttributeName("test term");
        term.setAttributeValue("Test term value");
        attributes.add(term);
        updateAgreementRequest.setAttributes(attributes);

        return updateAgreementRequest;
    }

    public static GPAAgreementDTO getGpaAgreementDTO() throws ParseException {
        GPAAgreementDTO gpaAgreementDTO = new GPAAgreementDTO();
        gpaAgreementDTO.setAgreementId(1382340740);
        gpaAgreementDTO.setCustomerId(156043);
        gpaAgreementDTO.setProductId(3450);
        gpaAgreementDTO.setStatus("DRAFT");
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Date date = formatter.parse("2021-04-01T00:00:00.000Z");
        Timestamp timeStampDate = new Timestamp(date.getTime());
        gpaAgreementDTO.setCreatedTimeStamp(timeStampDate);
        date = formatter.parse("2022-04-01T00:00:00.000Z");
        timeStampDate = new Timestamp(date.getTime());
        gpaAgreementDTO.setEndDate(timeStampDate);
        gpaAgreementDTO.setCreatedBy("PA2619");

        GPAAgreementTermDTO termDTO = new GPAAgreementTermDTO();
        termDTO.setTermName("test term");
        termDTO.setTermValue("Test term value");
        List<GPAAgreementTermDTO> terms = new ArrayList<>();
        terms.add(termDTO);
        gpaAgreementDTO.setTerms(terms);

        return gpaAgreementDTO;
    }

    public static AdministrationView getAdministrationView() {
        AdministrationView administrationView = new AdministrationView();
        administrationView.setId(1);
        administrationView.setName("Tikkie Administration");
        administrationView.setOarId("AAB.SYS.12345");
        administrationView.setCreatedBy("PA2619");
        List<ProductAdminMapView> productAdminMapViews = new ArrayList<>();
        ProductAdminMapView productAdminMapView = new ProductAdminMapView();
        productAdminMapView.setProductId(3450);
        administrationView.setProductAdminMapViews(productAdminMapViews);
        productAdminMapViews.add(productAdminMapView);

        return administrationView;
    }

    public static ReadGPAAgreementResponseDTOV2 getReadGPAAgreementResponseDTOV2() {
        GPAAgreementDTO gpaAgreementDTO = new GPAAgreementDTO();
        gpaAgreementDTO.setCustomerId(Long.parseLong("156043"));
        gpaAgreementDTO.setProductId(1253);
        gpaAgreementDTO.setStatus("DRAFT");
        gpaAgreementDTO.setStartDate(Timestamp.valueOf("2021-04-30 00:00:00"));//yyyy-mm-dd hh:mm:ss[.fffffffff]
        gpaAgreementDTO.setEndDate(Timestamp.valueOf("2021-04-01 00:00:00"));
        gpaAgreementDTO.setCreatedTimeStamp(Timestamp.valueOf("2021-04-30 00:00:00"));
        gpaAgreementDTO.setUpdatedTimeStamp(Timestamp.valueOf("2021-04-01 00:00:00.000"));
        gpaAgreementDTO.setCreatedBy("pa2619");
        gpaAgreementDTO.setUpdatedBy("pa2619");

        List<GPAAgreementTermDTO> terms = new ArrayList<>();
        GPAAgreementTermDTO gpaAgreementTermDTO = new GPAAgreementTermDTO();
        gpaAgreementTermDTO.setTermName("test term");
        gpaAgreementTermDTO.setTermValue("Test term value");
        terms.add(gpaAgreementTermDTO);
        gpaAgreementDTO.setTerms(terms);

        ReadGPAAgreementResponseDTOV2 readGPAAgreementResponseDTO;
        readGPAAgreementResponseDTO = new ReadGPAAgreementResponseDTOV2();
        readGPAAgreementResponseDTO.setCustomerId(String.valueOf(gpaAgreementDTO.getCustomerId()));
        readGPAAgreementResponseDTO.setProductId(String.valueOf(gpaAgreementDTO.getProductId()));
        readGPAAgreementResponseDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.valueOf(gpaAgreementDTO.getStatus()));
        readGPAAgreementResponseDTO.setAgreementStartDateTime(String.valueOf(gpaAgreementDTO.getStartDate()));
        readGPAAgreementResponseDTO.setAgreementEndDateTime(String.valueOf(gpaAgreementDTO.getEndDate()));
        readGPAAgreementResponseDTO.setCreatedDateTime(String.valueOf(gpaAgreementDTO.getCreatedTimeStamp()));
        readGPAAgreementResponseDTO.setModifiedDateTime(String.valueOf(gpaAgreementDTO.getUpdatedTimeStamp()));
        readGPAAgreementResponseDTO.setCreatedBy(gpaAgreementDTO.getCreatedBy());
        //ModifiedTimeStamp
        readGPAAgreementResponseDTO.setModifiedBy(gpaAgreementDTO.getUpdatedBy());
        if(gpaAgreementDTO.getTerms()!= null && !gpaAgreementDTO.getTerms().isEmpty()){
            List<TermResponseDTOV2> terms1 = new ArrayList<TermResponseDTOV2>();
            for(GPAAgreementTermDTO termDTO:gpaAgreementDTO.getTerms()){
                TermResponseDTOV2 term1 = new TermResponseDTOV2();
                term1.setAttributeName(termDTO.getTermName());
                term1.setAttributeValue(termDTO.getTermValue());
                terms1.add(term1);
            }
            readGPAAgreementResponseDTO.setAttributes(terms1);
        }
        return readGPAAgreementResponseDTO;
    }

    public static GPAAgreementDTO getGpaAgreementDTOForUpdate() throws ParseException {
        GPAAgreementDTO gpaAgreementDTO = new GPAAgreementDTO();
        gpaAgreementDTO.setAgreementId(1382340742);
        gpaAgreementDTO.setCustomerId(156043);
        gpaAgreementDTO.setProductId(3450);
        gpaAgreementDTO.setStatus("DRAFT");
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Date date = formatter.parse("2021-04-01T00:00:00.000Z");
        Timestamp timeStampDate = new Timestamp(date.getTime());
        gpaAgreementDTO.setCreatedTimeStamp(timeStampDate);
        date = formatter.parse("2022-04-01T00:00:00.000Z");
        timeStampDate = new Timestamp(date.getTime());
        gpaAgreementDTO.setEndDate(timeStampDate);
        gpaAgreementDTO.setCreatedBy("PA2619");

        GPAAgreementTermDTO termDTO = new GPAAgreementTermDTO();
        termDTO.setTermName("test term");
        termDTO.setTermValue("Test term value");
        List<GPAAgreementTermDTO> terms = new ArrayList<>();
        terms.add(termDTO);
        gpaAgreementDTO.setTerms(terms);

        return gpaAgreementDTO;
    }

}
