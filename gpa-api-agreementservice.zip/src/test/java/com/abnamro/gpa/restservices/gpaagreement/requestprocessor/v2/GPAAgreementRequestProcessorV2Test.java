package com.abnamro.gpa.restservices.gpaagreement.requestprocessor.v2;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.ReserveCINInputDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.v2.ReserveCINUtilV2;
import com.abnamro.gpa.generic.exception.*;
import com.abnamro.gpa.generic.gpaagreementdao.dao.GPAAgreementDAOV2;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementRequestDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.ReadGPAAgreementResponseDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Error;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementWebAppException;
import com.abnamro.gpa.restservices.gpaagreement.helper.v2.GPAAgreementRestMapperV2;
import com.abnamro.gpa.restservices.gpaagreement.helper.v2.GPAAgreementViewMapperV2;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import java.text.ParseException;

import static com.abnamro.gpa.restservices.gpaagreement.dataGenerator.v2.TestDataGenerator.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;


@ExtendWith(SpringExtension.class)
class GPAAgreementRequestProcessorV2Test {

    @InjectMocks
    GPAAgreementRequestProcessorV2 underTest;

    @Mock
    CreateGPAAgreementRequestDTOV2 createAgreementRequest;

    ReadGPAAgreementResponseDTOV2 readGPAAgreementResponseDTOV2 = new ReadGPAAgreementResponseDTOV2();

    @Mock
    GPAAgreementDAOV2 gpaAgreementDAO;

    @Mock
    GPAAdministrationDAO gpaAdministrationDAO;

    @Mock
    GPAAgreementRequestValidatorV2 gpaAgreeementRequestValidatorV2;

    @Mock
    GPAAgreementRestMapperV2 gpaAgreementRestMapperV2;

    @Mock
    ReserveCINUtilV2 reserveCINUtilV2;

    @Mock
    GPAAgreementViewMapperV2 gpaAgreementViewMapperV2;


    @BeforeEach
    void setUp() {

       // underTest = new GPAAgreementRequestProcessorV2(gpaAgreementRestMapperV2, gpaAgreeementRequestValidatorV2, gpaAgreementViewMapperV2, reserveCINUtilV2);

        createAgreementRequest = getCreateAgreementRequest();
    }

    @Test
    @DisplayName("Should create GPA Agreement")
    void shouldCreateGPAAgreement() {
        try {
            AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
            agreementValidatorResultDTO.setSuccessIndicator(true);

            GeneralProductAgreement generalProductAgreement = getGeneralProductAgreement();
            GPAAgreementDTO gpaAgreementDTO = getGpaAgreementDTO();

            when(gpaAgreementRestMapperV2.convertToGPAAgreementRestResource(createAgreementRequest)).thenReturn(generalProductAgreement);
            when(gpaAgreeementRequestValidatorV2.validateCreateAgreementRequest(generalProductAgreement, "156043", "12345")).thenReturn(agreementValidatorResultDTO);
            when(reserveCINUtilV2.reserveCIN(anyString(),any(ReserveCINInputDTO.class))).thenReturn(1382340740L);
            when(gpaAgreementViewMapperV2.convertToGPAAgreementDTO(generalProductAgreement)).thenReturn(gpaAgreementDTO);
            doNothing().when(gpaAgreementDAO).createGPAAgreement("12345", gpaAgreementDTO);

            String agreementId = underTest.createGPAAgreement(createAgreementRequest,"156043", "12345");
            assertEquals("1382340740",agreementId);

        } catch (ParseException | GPAAgreementValidatorException | GPAAdministrationDAOException | GPAAgreementApplicationException | GPAAgreementDAOException | ContractHeaderServiceInvokerException | GPAAgreementWebAppException e) {
            fail("not expected an exception");
        }
    }

    @Test
    @DisplayName("Should throw bad input error while creating GPA Agreement")
    void shouldNotCreateGPAAgreement() {
        try {
            AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
            agreementValidatorResultDTO.setSuccessIndicator(false);

            GeneralProductAgreement generalProductAgreement = getGeneralProductAgreement();

            when(gpaAgreementRestMapperV2.convertToGPAAgreementRestResource(createAgreementRequest)).thenReturn(generalProductAgreement);
            when(gpaAgreeementRequestValidatorV2.validateCreateAgreementRequest(generalProductAgreement, "156043", "12345")).thenReturn(agreementValidatorResultDTO);
            underTest.createGPAAgreement(createAgreementRequest,"156043", "12345");

        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException | GPAAgreementApplicationException | GPAAgreementDAOException e) {
            fail("not expected an exception");
        } catch (GPAAgreementWebAppException e) {
            assertEquals(400, e.getStatus().value());
        }
    }

   @Test
    @DisplayName("Should fail Create Agreement Request if agreementId already present in the database")
    void shouldFailCreateGPAAgreementIfDuplicateKeyException() {
        try {
            AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
            agreementValidatorResultDTO.setSuccessIndicator(true);

            GeneralProductAgreement generalProductAgreement = getGeneralProductAgreement();
            GPAAgreementDTO gpaAgreementDTO = getGpaAgreementDTO();

            Messages messages = new Messages();
            messages.addMessage(new Message(new MessageKey("MESSAGE_GPAG_003")), MessageType.getError());

            when(gpaAgreementRestMapperV2.convertToGPAAgreementRestResource(createAgreementRequest)).thenReturn(generalProductAgreement);
            when(gpaAgreeementRequestValidatorV2.validateCreateAgreementRequest(generalProductAgreement, "156043", "12345")).thenReturn(agreementValidatorResultDTO);
            when(reserveCINUtilV2.reserveCIN(anyString(),any(ReserveCINInputDTO.class))).thenReturn(1382340740L);
            when(gpaAgreementViewMapperV2.convertToGPAAgreementDTO(generalProductAgreement)).thenReturn(gpaAgreementDTO);
            doThrow(new GPAAgreementDAOException(messages)).when(gpaAgreementDAO).createGPAAgreement("12345", gpaAgreementDTO);

            underTest.createGPAAgreement(createAgreementRequest,"156043", "12345");

        }catch (GPAAgreementWebAppException e) {
            assertEquals(400, e.getStatus().value());
            if(e.getResponse() instanceof Error) {
            	assertEquals("AGREEMENT_ID_ALREADY_PRESENT",((Error)e.getResponse()).getCode());
            }
        } catch (ParseException | GPAAgreementValidatorException | GPAAdministrationDAOException | GPAAgreementApplicationException | ContractHeaderServiceInvokerException | GPAAgreementDAOException e) {
           e.printStackTrace();
            fail("not expected an exception");
        }
    }

    @Test
    @DisplayName("Should read GPA Agreement")
    void shouldReadGPAAgreement() {
        try {
            GPAAgreementDTO gpaAgreementDTO = getGpaAgreementDTO();

            when(gpaAgreementDAO.readGPAAgreement("1382340740")).thenReturn(gpaAgreementDTO);
            when(gpaAgreementViewMapperV2.convertToReadGPAAgreementResponseDTO(gpaAgreementDTO)).thenReturn(readGPAAgreementResponseDTOV2);

            assertEquals(readGPAAgreementResponseDTOV2,underTest.readGPAAgreement("1382340740","156043","12345"));
        } catch (GPAAgreementDAOException | ParseException | GPAAgreementWebAppException e) {
        	fail("not expected an exception");
		}
    }

    @Test
    @DisplayName("Should not read GPA Agreement")
    void shouldNotFoundAgreementInReadGPAAgreement() {
        try {
        	GPAAgreementDTO gpaAgreementDTO = null;
        	when(gpaAgreementDAO.readGPAAgreement("1382340742")).thenReturn(gpaAgreementDTO);
            underTest.readGPAAgreement("1382340742","156043","12345");
        } catch (GPAAgreementWebAppException e) {
            assertEquals(404, e.getStatus().value());
        } catch (GPAAgreementDAOException  e) {
        	fail("not expected an exception");
		}
    }

    @Test
    @DisplayName("Should update GPA Agreement")
    void shouldUpdateGpaAgreement() {
        UpdateGPAAgreementRequestDTO updateAgreementRequest = getUpdateGPAAgreementRequestDTO();

        try {
            GPAAgreementDTO gpaAgreementDTO = getGpaAgreementDTO();

            AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
            agreementValidatorResultDTO.setSuccessIndicator(true);

            GeneralProductAgreement generalProductAgreement = getGeneralProductAgreement();

            when(gpaAgreementDAO.readGPAAgreement("1382340740")).thenReturn(gpaAgreementDTO);
            when(gpaAgreementRestMapperV2.convertToGPAAgreementRestResourceForUpdate(updateAgreementRequest, "1382340740", gpaAgreementDTO)).thenReturn(generalProductAgreement);
            when(gpaAgreeementRequestValidatorV2.validateUpdateAgreementRequest(generalProductAgreement, "156043", "12345")).thenReturn(agreementValidatorResultDTO);
            when(gpaAgreementViewMapperV2.convertToGPAAgreementDTO(generalProductAgreement)).thenReturn(gpaAgreementDTO);
            doNothing().when(gpaAgreementDAO).updateGPAAgreement("12345", gpaAgreementDTO);

            underTest.updateGPAAgreement(updateAgreementRequest, "1382340740", "156043", "12345");
            //verify(gpaAgreementRequestProcessorV2).updateGPAAgreement(updateAgreementRequest, "1382340740", "156043", "12345");
        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException | GPAAgreementDAOException | ParseException | GPAAgreementWebAppException e) {
            fail("not expected an exception");
        }
    }

    @Test
    @DisplayName("Should not update GPA Agreement If AgreementId Not Valid")
    void shouldNotUpdateGpaAgreementIfAgreementIdNotValid() {
        UpdateGPAAgreementRequestDTO updateAgreementRequest = getUpdateGPAAgreementRequestDTO();

        try {
            //GPAAgreementDTO gpaAgreementDTO = getGpaAgreementDTOForUpdate();
            GPAAgreementDTO gpaAgreementDTO = null;

            AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
            agreementValidatorResultDTO.setSuccessIndicator(true);

            when(gpaAgreementDAO.readGPAAgreement("1382340742")).thenReturn(gpaAgreementDTO);

            underTest.updateGPAAgreement(updateAgreementRequest, "1382340742", "156043", "12345");
        } catch (GPAAgreementWebAppException e) {
            assertEquals(404,e.getStatus().value(),""+GPAAgreementConstantsV2.DESC_AGREEMENT_ID_NOT_FOUND);
            assertEquals("AGREEMENT_NOT_FOUND", (e.getError().getErrors().get(0).getCode()));
        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException | GPAAgreementDAOException  e) {
            fail("not expected an exception");
        }
    }

    @Test
    @DisplayName("Should fail update GPA Agreement If DAOException")
    void shouldFailUpdateGpaAgreementIfDAOException() {
        UpdateGPAAgreementRequestDTO updateAgreementRequest = getUpdateGPAAgreementRequestDTO();

        try {
            GPAAgreementDTO gpaAgreementDTO = getGpaAgreementDTOForUpdate();

            AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
            agreementValidatorResultDTO.setSuccessIndicator(true);

            GeneralProductAgreement generalProductAgreement = getGeneralProductAgreement();

            Messages messages = new Messages();
            messages.addMessage(new Message(new MessageKey("INTERNAL_SERVER_ERROR")), MessageType.getError());

            when(gpaAgreementDAO.readGPAAgreement("1382340740")).thenReturn(gpaAgreementDTO);
            when(gpaAgreementRestMapperV2.convertToGPAAgreementRestResourceForUpdate(updateAgreementRequest, "1382340740", gpaAgreementDTO)).thenReturn(generalProductAgreement);
            when(gpaAgreeementRequestValidatorV2.validateUpdateAgreementRequest(generalProductAgreement, "156043", "12345")).thenReturn(agreementValidatorResultDTO);
            when(gpaAgreementViewMapperV2.convertToGPAAgreementDTO(generalProductAgreement)).thenReturn(gpaAgreementDTO);
            doThrow(new GPAAgreementDAOException(messages)).when(gpaAgreementDAO).updateGPAAgreement("12345", gpaAgreementDTO);

            underTest.updateGPAAgreement(updateAgreementRequest, "1382340740", "156043", "12345");
        } catch (GPAAgreementWebAppException e) {
            assertEquals(500, e.getStatus().value());
            assertEquals("INTERNAL_SERVER_ERROR", (e.getError().getErrors().get(0).getCode()));
        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException | GPAAgreementDAOException | ParseException  e) {
            fail("not expected an exception");
        }
    }

}
