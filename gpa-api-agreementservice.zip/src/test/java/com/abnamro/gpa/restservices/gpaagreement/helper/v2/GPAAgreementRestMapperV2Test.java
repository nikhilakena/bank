package com.abnamro.gpa.restservices.gpaagreement.helper.v2;

import com.abnamro.gpa.generic.contractheaderserviceinvoker.apiconnectors.agreementcustomerrefapi.AgreementCustomerReferenceForPatch;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.apiconnectors.agreementcustomerrefapi.AgreementLifeCycleStatusTypeEnum;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.ContractHeaderStatusType;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.UpdateContractHeaderInputDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.util.v2.APIRequestResponseMapper;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementRequestDTOV2;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class GPAAgreementRestMapperV2Test {

    private GPAAgreementRestMapperV2 underTest;

    @Test
    public void testconvertToGPAAgreementRestResource()  {
        CreateGPAAgreementRequestDTOV2 inputDTO = new CreateGPAAgreementRequestDTOV2();
        inputDTO.setAgreementId("3434355454");
        inputDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.ACTIVE.toString());
        underTest = new GPAAgreementRestMapperV2();
        GeneralProductAgreement generalProductAgreement = underTest.convertToGPAAgreementRestResource(inputDTO);
        Assertions.assertEquals(AgreementLifeCycleStatusType.valueOf(inputDTO.getAgreementLifeCycleStatusType()), generalProductAgreement.getAgreementLifeCycleStatusType());
    }

    @Test
    public void testconvertToGPAAgreementRestResourceForUpdate()  {
        UpdateGPAAgreementRequestDTO inputDTO = new UpdateGPAAgreementRequestDTO();
        GPAAgreementDTO gpaAgreementDTO= new GPAAgreementDTO();
        gpaAgreementDTO.setProductId(3434355);
        gpaAgreementDTO.setAgreementId(4564656);
        inputDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.ACTIVE.toString());
        underTest = new GPAAgreementRestMapperV2();
        GeneralProductAgreement generalProductAgreement = underTest.convertToGPAAgreementRestResourceForUpdate(inputDTO,String.valueOf(gpaAgreementDTO.getAgreementId()),gpaAgreementDTO);
        Assertions.assertEquals(AgreementLifeCycleStatusType.valueOf(inputDTO.getAgreementLifeCycleStatusType()), generalProductAgreement.getAgreementLifeCycleStatusType());
    }
}
