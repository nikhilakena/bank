package com.abnamro.gpa.restservices.gpaagreement.service.v2;

import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementRequestDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementResponseDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.ReadGPAAgreementResponseDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Errors;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.requestprocessor.v2.GPAAgreementRequestProcessorV2;
import jakarta.ws.rs.WebApplicationException;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static com.abnamro.gpa.restservices.gpaagreement.dataGenerator.v2.TestDataGenerator.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GPAAgreementRestServiceV2Test {

    @Mock
    GPAAgreementRestServiceHelperV2 gpaAgreementRestServiceHelperV2;

    @Mock
    GPAAgreementRequestProcessorV2 gpaAgreementRequestProcessorV2;

    @InjectMocks
    private GPAAgreementRestServiceV2 underTest;

    private static CreateGPAAgreementRequestDTOV2 createAgreementRequest;

    @BeforeEach
    void setUp() {

        createAgreementRequest = getCreateAgreementRequest();

    }

    @Test
    @DisplayName("Should Successfully Create GPA Agreement")
    void shouldSuccessCreateGpaAgreement() {
        ResponseEntity<CreateGPAAgreementResponseDTOV2> createGPAAgreementResponseDTOV2 = null;
        try {
            //   doNothing().when(gpaAgreementRestServiceHelperV2).handleCreateSuccess(createGPAAgreementResponseDTOV2);
            when(gpaAgreementRequestProcessorV2.createGPAAgreement(createAgreementRequest, "156043", "12345")).thenReturn("1382340740");
            createGPAAgreementResponseDTOV2 = underTest.createAgreement("156043", "12345", createAgreementRequest);

            assertEquals(HttpStatus.CREATED, createGPAAgreementResponseDTOV2.getStatusCode());
        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException | GPAAgreementApplicationException | GPAAgreementDAOException e) {
            fail("not expected an exception");
        } catch (WebApplicationException e) {

            assertEquals("1382340740", ((CreateGPAAgreementResponseDTOV2) e.getResponse().getEntity()).getAgreementId());

        }
    }

    @Test
    @DisplayName("Should Throw consumerId  Create GPA Agreement")
    void shouldThrowConsumerIDException() {
        ResponseEntity<CreateGPAAgreementResponseDTOV2> createGPAAgreementResponseDTOV2 = null;
        try {

            createGPAAgreementResponseDTOV2 = underTest.createAgreement("", "12345", createAgreementRequest);


        } catch (WebApplicationException e) {

            assertEquals(GPAAgreementConstantsV2.CODE_CONSUMER_ID_MANDATORY, ((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode());

        }
    }

    @Test
    @DisplayName("Should Throw productId  Create GPA Agreement")
    void shouldThrowProductIDException() {
        createAgreementRequest = new CreateGPAAgreementRequestDTOV2();
        createAgreementRequest.setProductId(0);
        ResponseEntity<CreateGPAAgreementResponseDTOV2> createGPAAgreementResponseDTOV2;
        try {
            createGPAAgreementResponseDTOV2 = underTest.createAgreement("1334", "12345", createAgreementRequest);
        } catch (WebApplicationException e) {

            assertEquals(GPAAgreementConstantsV2.CODE_PRODUCT_ID_FORMAT_INVALID, ((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode());

        }
    }

    @Test
    @DisplayName("Should get GPA agreement")
    void shouldGetGpaAgreement() throws WebApplicationException {
        ReadGPAAgreementResponseDTOV2 readGPAAgreementResponseDTO = getReadGPAAgreementResponseDTOV2();

        when(gpaAgreementRequestProcessorV2.readGPAAgreement("1382340740", "156043", "12345")).thenReturn(readGPAAgreementResponseDTO);
        ResponseEntity<ReadGPAAgreementResponseDTOV2> response = underTest.getGPAAgreement("156043", "12345", "1382340740");

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    @DisplayName("Should not read GPA agreement if blank agreement id")
    void shouldNotReadGpaAgreementIfBlankAgreementId() {
        try {
            underTest.getGPAAgreement("156043", "12345", "");
        } catch (WebApplicationException e) {
            assertEquals(400, e.getResponse().getStatus());
            assertEquals("AGREEMENT_ID_INVALID", (((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode()));
        }
    }

    @Test
    @DisplayName("Should not read GPA agreement if non numeric agreement id")
    void shouldNotReadGpaAgreementIfNonNumericAgreementId() {
        try {
            underTest.getGPAAgreement("156043", "12345", "123ACR34F0");
        } catch (WebApplicationException e) {
            assertEquals(400, e.getResponse().getStatus());
            assertEquals("AGREEMENT_ID_INVALID", (((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode()));
        }
    }

    @Test
    @DisplayName("Should not read GPA agreement if agreement id length is not 10")
    void shouldNotReadGpaAgreementIfNotRequiredLengthAgreementId() {
        try {
            underTest.getGPAAgreement("156043", "12345", "34324254354354543");
        } catch (WebApplicationException e) {
            assertEquals(400, e.getResponse().getStatus());
            assertEquals("AGREEMENT_ID_INVALID", (((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode()));
        }
    }

    @Test
    @DisplayName("Should Update GPA Agreement")
    void shouldUpdateGpaAgreement() {
        UpdateGPAAgreementRequestDTO updateAgreementRequest = getUpdateGPAAgreementRequestDTO();

        try {
            doNothing().when(gpaAgreementRequestProcessorV2).updateGPAAgreement(any(UpdateGPAAgreementRequestDTO.class), any(String.class), any(String.class), any(String.class));
            underTest.updateGPAAgreement("156043", "12345", "1382340740", updateAgreementRequest);
            verify(gpaAgreementRequestProcessorV2, times(1)).updateGPAAgreement(updateAgreementRequest, "1382340740", "156043", "12345");
        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException e) {
            fail("not expected an exception");
        } catch (WebApplicationException e) {
            assertEquals(204, e.getResponse().getStatus(), "Internal Server Error");

        }
    }

    @Test
    @DisplayName("Should Fail Create Agreement")
    void shouldFailCreateAgreement() {
        try {
            when(gpaAgreementRequestProcessorV2.createGPAAgreement(createAgreementRequest, "156043", "12345")).thenThrow(new GPAAgreementDAOException());
            underTest.createAgreement("156043", "12345", createAgreementRequest);
        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException | GPAAgreementApplicationException | GPAAgreementDAOException e) {
            fail("No Exception expected");
        } catch (WebApplicationException e) {
            assertEquals(500, e.getResponse().getStatus(), "Internal Server Error");
        }
    }

    @Test
    @DisplayName("Should Fail Update Gpa Agreement if validator Exception")
    void shouldFailUpdateGpaAgreement() {
        UpdateGPAAgreementRequestDTO updateAgreementRequest = getUpdateGPAAgreementRequestDTO();

        try {
            doThrow(new GPAAgreementValidatorException()).when(gpaAgreementRequestProcessorV2).updateGPAAgreement(any(UpdateGPAAgreementRequestDTO.class), any(String.class), any(String.class), any(String.class));
            underTest.updateGPAAgreement("156043", "12345", "1382340740", updateAgreementRequest);
        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException e) {
            fail("No Exception expected");
        } catch (WebApplicationException e) {
            assertEquals(500, e.getResponse().getStatus(), "Internal Server Error");
        }
    }

    @Test
    @DisplayName("Should Fail Update Gpa Agreement if DAO Exception")
    void shouldFailUpdateGpaAgreementIfDAOException() throws WebApplicationException, GPAAdministrationDAOException, GPAAgreementValidatorException {
        UpdateGPAAgreementRequestDTO updateAgreementRequest = getUpdateGPAAgreementRequestDTO();


        try {
            doThrow(new GPAAdministrationDAOException()).when(gpaAgreementRequestProcessorV2).updateGPAAgreement(any(UpdateGPAAgreementRequestDTO.class), any(String.class), any(String.class), any(String.class));

            underTest.updateGPAAgreement("156043", "12345", "1382340740", updateAgreementRequest);


        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException e) {
            fail("No Exception expected");
        } catch (WebApplicationException e) {
            assertEquals(500, e.getResponse().getStatus(), "Internal Server Error");
        }
    }

    @Test
    @DisplayName("Should Fail Update Gpa Agreement if Application Exception")
    void shouldFailUpdateGpaAgreementIfApplicationExcepion() {
        UpdateGPAAgreementRequestDTO updateAgreementRequest = getUpdateGPAAgreementRequestDTO();

        try {
            doThrow(new GPAAdministrationDAOException()).when(gpaAgreementRequestProcessorV2).updateGPAAgreement(any(UpdateGPAAgreementRequestDTO.class), any(String.class), any(String.class), any(String.class));
            underTest.updateGPAAgreement("156043", "12345", "1382340740", updateAgreementRequest);
        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException e) {
            fail("No Exception expected");
        } catch (WebApplicationException e) {
            assertEquals(500, e.getResponse().getStatus(), "Internal Server Error");
        }
    }

    @Test
    @DisplayName("Should Fail Create Gpa Agreement If ValidatorException")
    void shouldFailCreateGpaAgreementIfValidatorException() {

        try {
            when(gpaAgreementRequestProcessorV2.createGPAAgreement(createAgreementRequest, "156043", "12345")).thenThrow(new GPAAgreementValidatorException());
            underTest.createAgreement("156043", "12345", createAgreementRequest);
        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException | GPAAgreementApplicationException | GPAAgreementDAOException e) {
            fail("not expected an exception");
        } catch (WebApplicationException e) {
            assertEquals(500, e.getResponse().getStatus());
            assertEquals("INTERNAL_SERVER_ERROR", (((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode()));
        }
    }

    @Test
    @DisplayName("Should Fail Create Gpa Agreement If DAOException")
    void shouldFailCreateGpaAgreementIfDAOException() {


        try {
            when(gpaAgreementRequestProcessorV2.createGPAAgreement(createAgreementRequest, "156043", "12345")).thenThrow(new GPAAdministrationDAOException());
            underTest.createAgreement("156043", "12345", createAgreementRequest);
        } catch (GPAAgreementValidatorException e) {
            e.printStackTrace();
        } catch (GPAAgreementApplicationException | GPAAdministrationDAOException | GPAAgreementDAOException gpaAgreementApplicationException) {
            fail("not expected an exception");

        } catch (WebApplicationException e) {
            assertEquals(500, e.getResponse().getStatus());
            assertEquals("INTERNAL_SERVER_ERROR", (((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode()));
        }
    }

    @Test
    @DisplayName("Should Fail Create Gpa Agreement If ApplicationException")
    void shouldFailCreateGpaAgreementIfApplicationException() {
        try {
            when(gpaAgreementRequestProcessorV2.createGPAAgreement(createAgreementRequest, "156043", "12345")).thenThrow(new GPAAgreementApplicationException());
            underTest.createAgreement("156043", "12345", createAgreementRequest);
        } catch (GPAAgreementValidatorException | GPAAdministrationDAOException | GPAAgreementApplicationException | GPAAgreementDAOException e) {
            fail("not expected an exception");
        } catch (WebApplicationException e) {
            assertEquals(500, e.getResponse().getStatus());
            assertEquals("INTERNAL_SERVER_ERROR",(((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode()));
        }
    }

    @Test
    @DisplayName("Should Throw consumerId Read GPA Agreement")
    void shouldThrowConsumerIDExceptionWhenReadMethodCall() {
        ResponseEntity<ReadGPAAgreementResponseDTOV2> readGPAAgreementResponseDTOV2 = null;
        try {
            readGPAAgreementResponseDTOV2 = underTest.getGPAAgreement("", "12345", "1234567890");
        } catch (WebApplicationException e) {
            assertEquals(GPAAgreementConstantsV2.CODE_CONSUMER_ID_MANDATORY, (((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode()));
            assertEquals(GPAAgreementConstantsV2.DESC_CONSUMER_ID_MANDATORY, (((Errors)e.getResponse().getEntity()).getErrors().get(0).getMessage()));
        }
    }

    @Test
    @DisplayName("Should Throw consumerId Read GPA Agreement")
    void shouldThrowProductIDExceptionWhenReadMethodCall() {
        ResponseEntity<ReadGPAAgreementResponseDTOV2> readGPAAgreementResponseDTOV2;
        try {
            readGPAAgreementResponseDTOV2 = underTest.getGPAAgreement("@@@@ss", "12345", "1234567890");
        } catch (WebApplicationException e) {
            assertEquals(GPAAgreementConstantsV2.CODE_CONSUMER_ID_LENGTH_EXCEEDED, (((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode()));
            assertEquals(GPAAgreementConstantsV2.DESC_CONSUMER_ID_LENGTH_EXCEEDED, (((Errors)e.getResponse().getEntity()).getErrors().get(0).getMessage()));
        }
    }

    @Test
    @DisplayName("Should Fail when AgreementID not valid Read GPA Agreement")
    void shouldCheckInvalidAgreementIDWhenReadMethodCall() {
        ResponseEntity<ReadGPAAgreementResponseDTOV2> readGPAAgreementResponseDTOV2;
        try {
            readGPAAgreementResponseDTOV2 = underTest.getGPAAgreement("156043", "12345", "1234567@@@");
        } catch (WebApplicationException e) {
            assertEquals(GPAAgreementConstantsV2.CODE_AGREEMENT_ID_INVALID, (((Errors)e.getResponse().getEntity()).getErrors().get(0).getCode()));
            assertEquals(GPAAgreementConstantsV2.DESC_AGREEMENT_ID_INVALID, (((Errors)e.getResponse().getEntity()).getErrors().get(0).getMessage()));
        }
    }

}
