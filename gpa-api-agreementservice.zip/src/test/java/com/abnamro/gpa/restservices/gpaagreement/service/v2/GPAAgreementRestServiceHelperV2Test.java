package com.abnamro.gpa.restservices.gpaagreement.service.v2;

import static com.abnamro.gpa.restservices.gpaagreement.dataGenerator.v2.TestDataGenerator.getCreateAgreementRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.abnamro.gpa.generic.contractheaderserviceinvoker.apiconnectors.agreementcustomerrefapi.AgreementLifeCycleStatusTypeEnum;
import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementRequestDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementResponseDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Error;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Errors;
import jakarta.ws.rs.WebApplicationException;
import java.util.Objects;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

@ExtendWith(MockitoExtension.class)
class GPAAgreementRestServiceHelperV2Test {

    @InjectMocks
    private GPAAgreementRestServiceHelperV2 underTest;

    private static CreateGPAAgreementRequestDTOV2 createAgreementRequest;

    @BeforeEach
    void setUp() {
        createAgreementRequest = getCreateAgreementRequest();
    }
    @Test
    @DisplayName("Check for invalidConsumerId")
    void shouldTestIsInvalidGenericDetails() {
        WebApplicationException exception = assertThrows(WebApplicationException.class, () -> underTest.isInvalidGenericDetails( "", "12345",   createAgreementRequest));
        assertEquals("CONSUMER_ID_MANDATORY", ((Errors) (exception.getResponse().getEntity())).getErrors().get(0).getCode());
    }
    @Test
    @DisplayName("Check for invalidAgreementID")
    void shouldTestIsInvalidGenericDetailsAgeementId() {
        createAgreementRequest.setAgreementId("123456789");
        WebApplicationException exception = assertThrows(WebApplicationException.class, () -> underTest.isInvalidGenericDetails( "12345", "12345",   createAgreementRequest));
        assertEquals("AGREEMENT_ID_INVALID", ((Errors) (exception.getResponse().getEntity())).getErrors().get(0).getCode());
    }

    @Test
    @DisplayName("Check for invalidProductID")
    void shouldTestIsInvalidGenericDetailsProductId() {
        createAgreementRequest.setProductId(3455555);
        WebApplicationException exception = assertThrows(WebApplicationException.class, () -> underTest.isInvalidGenericDetails( "12345", "12345",   createAgreementRequest));
        assertEquals(GPAAgreementConstantsV2.CODE_PRODUCT_ID_FORMAT_INVALID,((Errors) (exception.getResponse().getEntity())).getErrors().get(0).getCode());
    }

    @Test
    @DisplayName("Check for invalidUserID")
    void shouldTestIsInvalidGenericDetailsUserId() {
        createAgreementRequest.setProductId(345555);
        createAgreementRequest.setUserId("C87634558");
        WebApplicationException exception = assertThrows(WebApplicationException.class, () -> underTest.isInvalidGenericDetails( "12345", "12345",   createAgreementRequest));
        assertEquals(GPAAgreementConstantsV2.CODE_USER_ID_FORMAT_INVALID,((Errors) (exception.getResponse().getEntity())).getErrors().get(0).getCode());
    }

    @Test
    @DisplayName("Check for Update invalidAgreementID")
    void shouldTestisInvalidGenericDetailsForUpdateAgreementId() {
        UpdateGPAAgreementRequestDTO updateGPAAgreementRequestDTO= new UpdateGPAAgreementRequestDTO();
        updateGPAAgreementRequestDTO.setUserId("C647533");
        WebApplicationException exception = assertThrows(WebApplicationException.class, () -> underTest.isInvalidGenericDetailsForUpdate( "12345", "12345",   updateGPAAgreementRequestDTO,"12345676"));
        assertEquals(GPAAgreementConstantsV2.CODE_AGREEMENT_ID_INVALID,((Errors) (exception.getResponse().getEntity())).getErrors().get(0).getCode());
    }

    @Test
    @DisplayName("Check for Update invalidUserID")
    void shouldTestisInvalidGenericDetailsForUpdateUserId() {
        UpdateGPAAgreementRequestDTO updateGPAAgreementRequestDTO= new UpdateGPAAgreementRequestDTO();
        updateGPAAgreementRequestDTO.setUserId("C64753345");
        updateGPAAgreementRequestDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusTypeEnum.ACTIVE.getValue());
        WebApplicationException exception = assertThrows(WebApplicationException.class, () -> underTest.isInvalidGenericDetailsForUpdate( "12345", "12345",   updateGPAAgreementRequestDTO,"1234567890"));
        assertEquals(GPAAgreementConstantsV2.CODE_USER_ID_FORMAT_INVALID,((Errors) (exception.getResponse().getEntity())).getErrors().get(0).getCode());
    }

    @Test
    @DisplayName("Should Test For handle Create Success")
    void shouldTestForHandleCreateSuccess() {
        CreateGPAAgreementResponseDTOV2 response = new CreateGPAAgreementResponseDTOV2();
        response.setAgreementId("1423501230");
        WebApplicationException exception = assertThrows(WebApplicationException.class, () -> underTest.handleCreateSuccess(response));
        assertEquals("1423501230",((CreateGPAAgreementResponseDTOV2) (exception.getResponse().getEntity())).getAgreementId());
    }

    @Test
    @DisplayName("Should Test For Handle Update Success")
    void shouldTestForHandleUpdateSuccess() {
        Errors errors = new Errors();
        Error error = new Error();
        error.setStatus("204");
        errors.getErrors().add(error);
        WebApplicationException exception = assertThrows(WebApplicationException.class, () -> underTest.handleUpdateSuccess());
        assertEquals(HttpStatus.NO_CONTENT.value(),(Objects.requireNonNull((exception.getResponse()))).getStatus());
    }
}
