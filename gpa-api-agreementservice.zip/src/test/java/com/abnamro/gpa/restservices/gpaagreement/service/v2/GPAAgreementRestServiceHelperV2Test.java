package com.abnamro.gpa.restservices.gpaagreement.service.v2;

import com.abnamro.gpa.generic.contractheaderserviceinvoker.apiconnectors.agreementcustomerrefapi.AgreementLifeCycleStatusTypeEnum;
import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementRequestDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementWebAppException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.abnamro.gpa.restservices.gpaagreement.dataGenerator.v2.TestDataGenerator.getCreateAgreementRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class GPAAgreementRestServiceHelperV2Test {

    @InjectMocks
    private GPAAgreementRestServiceHelperV2 underTest;

    private static CreateGPAAgreementRequestDTOV2 createAgreementRequest;

    @BeforeEach
    void setUp() {
        createAgreementRequest = getCreateAgreementRequest();
    }
    @Test
    @DisplayName("Check for invalidConsumerId")
    void shouldTestIsInvalidGenericDetails() {
        GPAAgreementWebAppException exception = assertThrows(GPAAgreementWebAppException.class, () -> {
            underTest.isInvalidGenericDetails( "", "12345",   createAgreementRequest);
        });
        assertEquals("CONSUMER_ID_MANDATORY",exception.getError().getErrors().get(0).getCode());
    }
    @Test
    @DisplayName("Check for invalidAgreementID")
    void shouldTestIsInvalidGenericDetailsAgeementId() {
        createAgreementRequest.setAgreementId("123456789");
        GPAAgreementWebAppException exception = assertThrows(GPAAgreementWebAppException.class, () -> {
            underTest.isInvalidGenericDetails( "12345", "12345",   createAgreementRequest);
        });
        assertEquals("AGREEMENT_ID_INVALID",exception.getError().getErrors().get(0).getCode());
    }

    @Test
    @DisplayName("Check for invalidProductID")
    void shouldTestIsInvalidGenericDetailsProductId() {
        createAgreementRequest.setProductId(3455555);
        GPAAgreementWebAppException exception = assertThrows(GPAAgreementWebAppException.class, () -> {
            underTest.isInvalidGenericDetails( "12345", "12345",   createAgreementRequest);
        });
        assertEquals(GPAAgreementConstantsV2.CODE_PRODUCT_ID_FORMAT_INVALID,exception.getError().getErrors().get(0).getCode());
    }

    @Test
    @DisplayName("Check for invalidUserID")
    void shouldTestIsInvalidGenericDetailsUserId() {
        createAgreementRequest.setProductId(345555);
        createAgreementRequest.setUserId("C87634558");
        GPAAgreementWebAppException exception = assertThrows(GPAAgreementWebAppException.class, () -> {
            underTest.isInvalidGenericDetails( "12345", "12345",   createAgreementRequest);
        });
        assertEquals(GPAAgreementConstantsV2.CODE_USER_ID_FORMAT_INVALID,exception.getError().getErrors().get(0).getCode());
    }

    @Test
    @DisplayName("Check for Update invalidAgreementID")
    void shouldTestisInvalidGenericDetailsForUpdateAgreementId() {
        UpdateGPAAgreementRequestDTO updateGPAAgreementRequestDTO= new UpdateGPAAgreementRequestDTO();
        updateGPAAgreementRequestDTO.setUserId("C647533");
        GPAAgreementWebAppException exception = assertThrows(GPAAgreementWebAppException.class, () -> {
            underTest.isInvalidGenericDetailsForUpdate( "12345", "12345",   updateGPAAgreementRequestDTO
            ,"12345676");
        });
        assertEquals(GPAAgreementConstantsV2.CODE_AGREEMENT_ID_INVALID,exception.getError().getErrors().get(0).getCode());
    }

    @Test
    @DisplayName("Check for Update invalidUserID")
    void shouldTestisInvalidGenericDetailsForUpdateUserId() {
        UpdateGPAAgreementRequestDTO updateGPAAgreementRequestDTO= new UpdateGPAAgreementRequestDTO();
        updateGPAAgreementRequestDTO.setUserId("C64753345");
        updateGPAAgreementRequestDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusTypeEnum.ACTIVE.getValue());
        GPAAgreementWebAppException exception = assertThrows(GPAAgreementWebAppException.class, () -> {
            underTest.isInvalidGenericDetailsForUpdate( "12345", "12345",   updateGPAAgreementRequestDTO
                    ,"1234567890");
        });
        assertEquals(GPAAgreementConstantsV2.CODE_USER_ID_FORMAT_INVALID,exception.getError().getErrors().get(0).getCode());
    }
}
