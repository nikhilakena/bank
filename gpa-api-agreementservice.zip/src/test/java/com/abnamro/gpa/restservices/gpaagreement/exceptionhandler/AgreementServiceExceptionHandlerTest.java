package com.abnamro.gpa.restservices.gpaagreement.exceptionhandler;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Error;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Errors;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.util.Objects;
import org.glassfish.jersey.message.internal.OutboundJaxrsResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class AgreementServiceExceptionHandlerTest {

    private static AgreementServiceResponseHandler agreementServiceResponseHandler = new AgreementServiceResponseHandler();

    @Test
    void shouldCatchGPAAgreementApplicationException() {

        Errors errors=agreementServiceResponseHandler.handleApplicationException(new GPAAgreementApplicationException());

        Assertions.assertEquals(errors.getErrors().get(0).getCode(),String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));

    }


    @Test
    void shouldCatchWebApplicationException() {

    Errors errors = new Errors();
    Error error = new Error();
    error.setCode(GPAAgreementConstantsV2.CODE_PRODUCT_ID_FORMAT_INVALID);
    error.setTraceId("3546564565");
    error.setMessage(GPAAgreementConstantsV2.DESC_PRODUCT_ID_FORMAT_INVALID);
    error.setStatus(GPAAgreementConstantsV2.RESPONSE_STATUS_400);
    error.setParams(null);
    errors.getErrors().add(error);
    ResponseEntity errorResponse=agreementServiceResponseHandler.handleWebAppException(new WebApplicationException(
        Response.status(Status.BAD_REQUEST).type(GPAAgreementConstantsV2.MEDIA_TYPE).build()));
    assertEquals(Integer.parseInt(GPAAgreementConstantsV2.RESPONSE_STATUS_400),(errorResponse.getStatusCode().value()));
    }
}
