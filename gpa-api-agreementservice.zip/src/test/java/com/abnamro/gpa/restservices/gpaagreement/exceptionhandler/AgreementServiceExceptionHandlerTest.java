package com.abnamro.gpa.restservices.gpaagreement.exceptionhandler;

import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Error;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Errors;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementWebAppException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AgreementServiceExceptionHandlerTest {

    private static AgreementServiceResponseHandler agreementServiceResponseHandler = new AgreementServiceResponseHandler();

    @Test
    public void shouldCatchGPAAgreementApplicationException() {

        Errors errors=agreementServiceResponseHandler.handleApplicationException(new GPAAgreementApplicationException());

        Assertions.assertEquals(errors.getErrors().get(0).getCode(),String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));

    }


    @Test
    public void shouldCatchGPAAgreementWebApplicationException() {

    Errors errors = new Errors();
    Error error = new Error();
    error.setCode(GPAAgreementConstantsV2.CODE_PRODUCT_ID_FORMAT_INVALID);
    error.setTraceId("3546564565");
    error.setMessage(GPAAgreementConstantsV2.DESC_PRODUCT_ID_FORMAT_INVALID);
    error.setStatus(GPAAgreementConstantsV2.RESPONSE_STATUS_400);
    error.setParams(null);
    errors.getErrors().add(error);
        ResponseEntity errorResponse=agreementServiceResponseHandler.handleWebAppException(new GPAAgreementWebAppException(HttpStatus.BAD_REQUEST,errors));
     assertEquals(GPAAgreementConstantsV2.CODE_PRODUCT_ID_FORMAT_INVALID,((Errors)errorResponse.getBody()).getErrors().get(0).getCode());


    }
}
