package com.abnamro.gpa.restservices.gpaagreement.dao;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GPAAuthorizationDAOTest {
    @InjectMocks
    private GPAAuthorizationDAO underTest;
    @Mock
    private SqlSession sqlSession;
    @Mock
    private SqlSessionFactory sqlSessionFactory;

    @Test
    void shouldTestisAuthorizedConsumerForAdminForException(){
        when(sqlSessionFactory.openSession()).thenReturn(sqlSession);
        when(sqlSession.getMapper(GPAAgreementMybatisMapper.class)).thenThrow(new PersistenceException());
        assertThrows(GPAAgreementApplicationException.class,() -> underTest.isAuthorizedConsumerForAdmin(1, "156043", "createGPAAgreement", "V2"));
    }
    @Test
    void shouldTestisAuthorizedConsumerForProductForException(){
        when(sqlSessionFactory.openSession()).thenReturn(sqlSession);
        when(sqlSession.getMapper(GPAAgreementMybatisMapper.class)).thenThrow(new PersistenceException());
        assertThrows(GPAAgreementApplicationException.class,() -> underTest.isAuthorizedConsumerForProduct(3345,"156043", "createGPAAgreement", "V2"));
    }
}
