package com.abnamro.gpa.restservices.gpaagreement.helper.v2;

import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.ReadGPAAgreementResponseDTOV2;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GPAAgreementDaoViewMapperV2Test {

    private GPAAgreementViewMapperV2 underTest;

    @Test
    void testconvertToGPAAgreementDTO() throws ParseException {
        GeneralProductAgreement inputDTO = new GeneralProductAgreement();
        inputDTO.setAgreementId("3434355454");
        inputDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.ACTIVE);

        java.util.Date utilDate = new java.util.Date();
        DateFormat format = new SimpleDateFormat(GPAAgreementConstantsV2.DATE_FORMAT, Locale.getDefault());

        inputDTO.setAgreementStartDate(("2021-04-30T00:00:00.000Z"));
    //    java.sql.Timestamp timestamp = new java.sql.Timestamp(utilDate.getTime());

       // assertEquals(utilDate.getTime() , timestamp.getTime());

        underTest = new GPAAgreementViewMapperV2();
        GPAAgreementDTO generalProductAgreement = underTest.convertToGPAAgreementDTO(inputDTO);
        Assertions.assertEquals(new java.sql.Timestamp(format.parse(inputDTO.getAgreementStartDate()).getTime()), generalProductAgreement.getStartDate());
    }

    @Test
    void testconvertToReadGPAAgreementResponseDTO() throws ParseException {
        GPAAgreementDTO agreementDTO = new GPAAgreementDTO();
        agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
        agreementDTO.setAgreementId(1234567890);
        agreementDTO.setProductId(1234);
        agreementDTO.setStatus("ACTIVE");
        agreementDTO.setCustomerId(1234566);
        //Invalid length for createdBy
        agreementDTO.setCreatedBy("PA261934567");
        agreementDTO.setUpdatedBy("KE3454");
        java.util.Date utilDate = new java.util.Date();
        DateFormat format = new SimpleDateFormat(GPAAgreementConstantsV2.DATE_FORMAT, Locale.getDefault());
        java.sql.Timestamp timestamp = new java.sql.Timestamp(utilDate.getTime());
        agreementDTO.setStartDate(timestamp);//yyyy-mm-dd hh:mm:ss[.fffffffff]
        //

        // assertEquals(utilDate.getTime() , timestamp.getTime());

        underTest = new GPAAgreementViewMapperV2();
        ReadGPAAgreementResponseDTOV2 generalProductAgreement = underTest.convertToReadGPAAgreementResponseDTO(agreementDTO);
        Assertions.assertEquals(format.format(agreementDTO.getStartDate()), generalProductAgreement.getAgreementStartDateTime());
    }

}
