package com.abnamro.gpa.restservices.gpaagreement.requestprocessor.v2;

import static com.abnamro.gpa.restservices.gpaagreement.dataGenerator.v2.TestDataGenerator.getAdministrationView;
import static com.abnamro.gpa.restservices.gpaagreement.dataGenerator.v2.TestDataGenerator.getCreateAgreementRequest;
import static com.abnamro.gpa.restservices.gpaagreement.dataGenerator.v2.TestDataGenerator.getGeneralProductAgreement;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.generic.gpaagreementvalidator.v2.GPAAgreementValidatorV2;
import com.abnamro.gpa.generic.gpaagreementvalidator.v2.GenericAgreementDetailsValidatorV2;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restservices.gpaagreement.dao.GPAAuthorizationDAO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementRequestDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.service.v2.GPAAgreementRestServiceHelperV2;
import jakarta.ws.rs.WebApplicationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GPAAgreementRequestValidatorV2Test {
    GPAAgreementRequestValidatorV2 underTest;

    @Mock
    AgreementValidatorResultDTO agreementValidatorResultDTO;

    private static CreateGPAAgreementRequestDTOV2 createAgreementRequest;

    @Mock
    GPAAgreementValidatorV2 gpaAgreementValidatorV2;

    @Mock
    GPAAdministrationDAO administrationdao;

    @Mock
    GPAAuthorizationDAO authorizationdao;

    @Mock
    AdministrationView administrationView;

    @Mock
    GenericAgreementDetailsValidatorV2 genericAgreementDetailsValidatorV2;

    @Mock
    GPAAgreementRestServiceHelperV2 gpaAgreementRestServiceHelperV2;

    @BeforeEach
    void setUp() {
        underTest = new GPAAgreementRequestValidatorV2( administrationdao, gpaAgreementValidatorV2, authorizationdao,
        gpaAgreementRestServiceHelperV2);

        createAgreementRequest = getCreateAgreementRequest();
    }

    @Test
    @DisplayName("Should validate Create Agreement Request")
    void shouldValidateCreateAgreementRequest() {
        GeneralProductAgreement generalProductAgreement = getGeneralProductAgreement();

        AdministrationView administrationView = getAdministrationView();

        agreementValidatorResultDTO = new AgreementValidatorResultDTO();
        agreementValidatorResultDTO.setSuccessIndicator(true);

        try {
            when(administrationdao.readAdministration(0, Integer.parseInt(generalProductAgreement.getProductId()))).thenReturn(administrationView);
            when(authorizationdao.isAuthorizedConsumerForAdmin(1, "156043", "createGPAAgreement", "V2")).thenReturn(true);
            when(gpaAgreementValidatorV2.validateAgreement(generalProductAgreement)).thenReturn(agreementValidatorResultDTO);

            assertEquals(agreementValidatorResultDTO,underTest.validateCreateAgreementRequest(generalProductAgreement, "156043", "12345"));
        } catch (GPAAdministrationDAOException | GPAAgreementValidatorException | GPAAgreementApplicationException | GPAAgreementDAOException | WebApplicationException e) {
            fail("not expected an exception");
        }
    }
    /*@Test
    @DisplayName("Should fail validate Create Agreement Request if product not registered")
    void shouldFailValidateCreateAgreementRequestIfProductNotRegistered() {
        GeneralProductAgreement generalProductAgreement = getGeneralProductAgreement();

        AdministrationView administrationView = null;

        try {
            when(administrationdao.readAdministration(0, Integer.parseInt(generalProductAgreement.getProductId()))).thenReturn(administrationView);
            assertEquals(agreementValidatorResultDTO, underTest.validateCreateAgreementRequest(generalProductAgreement, "156043", "12345"));
        } catch (GPAAdministrationDAOException | GPAAgreementValidatorException | GPAAgreementApplicationException | GPAAgreementDAOException e) {
            fail("not expected an exception");
        } catch (WebApplicationException e) {
            assertEquals(400, e.getStatus().value());
            assertEquals("PRODUCT_ID_NOT_REGISTERED", (e.getError().getErrors().get(0).getCode()));
        }
    }
    */
    @Test
    @DisplayName("Should fail validate Create Agreement Request if database issue")
    void shouldFailValidateCreateAgreementRequestIfAdminDatabaseIssue() {
        GeneralProductAgreement generalProductAgreement = getGeneralProductAgreement();

        try {
            when(administrationdao.readAdministration(0, Integer.parseInt(generalProductAgreement.getProductId()))).thenThrow(new GPAAdministrationDAOException());
            assertEquals(agreementValidatorResultDTO, underTest.validateCreateAgreementRequest(generalProductAgreement, "156043", "12345"));
        } catch (GPAAgreementDAOException e) {
        	assertNotNull(e.getMessages());
        } catch (GPAAdministrationDAOException | GPAAgreementValidatorException | GPAAgreementApplicationException | WebApplicationException e) {
        	 fail("not expected an exception");
        }
    }

    @Test
    @DisplayName("Should read Administration")
    void shouldReadAdministration() {
        GeneralProductAgreement generalProductAgreement = new GeneralProductAgreement();
        generalProductAgreement.setProductId(String.valueOf(createAgreementRequest.getProductId()));

        try {
            when(administrationdao.readAdministration(0, Integer.parseInt(generalProductAgreement.getProductId()))).thenReturn(administrationView);
            assertEquals(administrationView,underTest.readAdministration(generalProductAgreement));
        } catch (GPAAgreementDAOException | GPAAdministrationDAOException e) {
            fail("not expected an exception");
        }
    }

    @Test
    @DisplayName("Should not read Administration if database issue")
    void shouldNotReadAdministrationIfDatabaseIssue() {
        GeneralProductAgreement generalProductAgreement = new GeneralProductAgreement();
        generalProductAgreement.setProductId(String.valueOf(createAgreementRequest.getProductId()));

        try {
            when(administrationdao.readAdministration(0, Integer.parseInt(generalProductAgreement.getProductId()))).thenThrow(new GPAAdministrationDAOException());
            assertEquals(administrationView,underTest.readAdministration(generalProductAgreement));
        } catch (GPAAdministrationDAOException e) {
            fail("not expected an exception");
        } catch (GPAAgreementDAOException e) {
        	assertNotNull(e.getMessages());
        }
    }

    @Test
    @DisplayName("Should validate Update AgreementRequest")
    void shouldValidateUpdateAgreementRequest() {
        GeneralProductAgreement generalProductAgreement = getGeneralProductAgreement();

        agreementValidatorResultDTO = new AgreementValidatorResultDTO();
        agreementValidatorResultDTO.setSuccessIndicator(true);

        try {
            when(gpaAgreementValidatorV2.validateAgreement(generalProductAgreement)).thenReturn(agreementValidatorResultDTO);
            when(authorizationdao.isAuthorizedConsumerForProduct(3450, "156043", "updateGPAAgreement", "V2")).thenReturn(true);
            assertEquals(agreementValidatorResultDTO,underTest.validateUpdateAgreementRequest(generalProductAgreement,"156043","12345"));
        } catch (GPAAgreementApplicationException | GPAAgreementValidatorException | WebApplicationException e) {
            fail("Assertion failed!!");
        }
    }
}
