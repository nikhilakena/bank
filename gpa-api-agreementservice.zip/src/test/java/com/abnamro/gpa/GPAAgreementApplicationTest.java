package com.abnamro.gpa;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GPAAgreementApplicationTest {
  @InjectMocks
  private GPAAgreementApplication underTest;


  @Test
  void testSetTimeZoneToDutch() {
    underTest.setTimeZoneToDutch();
  }
}
