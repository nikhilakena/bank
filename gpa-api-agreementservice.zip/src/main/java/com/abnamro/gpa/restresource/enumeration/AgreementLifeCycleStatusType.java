/**
 * 
 */
package com.abnamro.gpa.restresource.enumeration;

/**
 * @author C45158
 *
 */
public enum AgreementLifeCycleStatusType {
	ACTIVE,
	INACTIVE,
	DRAFT

}
