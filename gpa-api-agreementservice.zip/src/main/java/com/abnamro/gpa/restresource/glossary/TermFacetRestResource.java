/**
 * 
 */
package com.abnamro.gpa.restresource.glossary;

import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.helper.AuditDetails;

/**
 * @author C45410
 *
 */
public class TermFacetRestResource {
	
	private FacetTypes facetType ;
	
	private String facetValue;
	
	private AuditDetails auditDetails;

	/**
	 * @return the facetType
	 */
	public FacetTypes getFacetType() {
		return facetType;
	}

	/**
	 * @param facetType the facetType to set
	 */
	public void setFacetType(FacetTypes facetType) {
		this.facetType = facetType;
	}

	/**
	 * @return the facetValue
	 */
	public String getFacetValue() {
		return facetValue;
	}

	/**
	 * @param facetValue the facetValue to set
	 */
	public void setFacetValue(String facetValue) {
		this.facetValue = facetValue;
	}

	/**
	 * @return the auditDetails
	 */
	public AuditDetails getAuditDetails() {
		return auditDetails;
	}

	/**
	 * @param auditDetails the auditDetails to set
	 */
	public void setAuditDetails(AuditDetails auditDetails) {
		this.auditDetails = auditDetails;
	}
	

}
