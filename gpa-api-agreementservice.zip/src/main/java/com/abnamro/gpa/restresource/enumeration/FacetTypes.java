/**
 * 
 */
package com.abnamro.gpa.restresource.enumeration;

/**
 * @author C45410
 *
 */
public enum FacetTypes {
	ENUMERATION, 
	LENGTH, 
	PATTERN, 
	MAXLENGTH, 
	MINLENGTH, 
	MININCLUSIVE, 
	MAXINCLUSIVE,
	MINEXCLUSIVE, 
	MAXEXCLUSIVE,
	TOTALDIGITS,
	FRACTIONS
}
