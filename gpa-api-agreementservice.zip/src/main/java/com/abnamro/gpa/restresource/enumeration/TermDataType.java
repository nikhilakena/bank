/**
 * 
 */
package com.abnamro.gpa.restresource.enumeration;

/**
 * @author C45410
 *
 */
public enum TermDataType {
	STRING,
	NUMERIC,
	BOOLEAN,
	DATE,
	TIME,
	DATETIME
}
