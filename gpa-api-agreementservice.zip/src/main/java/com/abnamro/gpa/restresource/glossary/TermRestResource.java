/**
 * 
 */
package com.abnamro.gpa.restresource.glossary;

import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.helper.AuditDetails;

import java.util.List;

/**
 * @author C45410
 *
 */
public class TermRestResource {

	private int id;
	
	private String name;
	
	private TermDataType dataType;
	
	private String description;
	
	private boolean isMandatory;
	
	private List<TermFacetRestResource> facets;
	
	private AuditDetails auditDetails;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the dataType
	 */
	public TermDataType getDataType() {
		return dataType;
	}

	/**
	 * @param dataType the dataType to set
	 */
	public void setDataType(TermDataType dataType) {
		this.dataType = dataType;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the isMandatory
	 */
	public boolean isMandatory() {
		return isMandatory;
	}

	/**
	 * @param isMandatory the isMandatory to set
	 */
	public void setMandatory(boolean isMandatory) {
		this.isMandatory = isMandatory;
	}

	/**
	 * @return the facets
	 */
	public List<TermFacetRestResource> getFacets() {
		return facets;
	}

	/**
	 * @param facets the facets to set
	 */
	public void setFacets(List<TermFacetRestResource> facets) {
		this.facets = facets;
	}

	/**
	 * @return the auditDetails
	 */
	public AuditDetails getAuditDetails() {
		return auditDetails;
	}

	/**
	 * @param auditDetails the auditDetails to set
	 */
	public void setAuditDetails(AuditDetails auditDetails) {
		this.auditDetails = auditDetails;
	}
	
	
}
