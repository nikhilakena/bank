package com.abnamro.gpa;

import java.util.TimeZone;

import jakarta.annotation.PostConstruct;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This is an application class for GPAAgreementApplication
 */
@SpringBootApplication
@MapperScan({"com.abnamro.gpa.generic.administrationdao.dao", "com.abnamro.gpa.restservices.gpaagreement.dao"
    , "com.abnamro.gpa.generic.gpaagreementdao.dao"})
public class GPAAgreementApplication {

  /**
   * Main class
   */
  public static void main(String[] args) {
    SpringApplication.run(GPAAgreementApplication.class, args);
  }

  /**
   * Set the timezone to Europe/Amsterdam
   */
  @PostConstruct
  public void setTimeZoneToDutch() {
    TimeZone.setDefault(TimeZone.getTimeZone("Europe/Amsterdam"));
  }
}
