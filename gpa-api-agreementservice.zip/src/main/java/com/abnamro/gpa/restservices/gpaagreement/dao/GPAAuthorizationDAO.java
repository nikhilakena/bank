/**
 *
 */
package com.abnamro.gpa.restservices.gpaagreement.dao;

import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementMessageKeyConstants;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * @author C45158
 *
 */
@Component
@Slf4j
public class GPAAuthorizationDAO {

  @Autowired
  private SqlSessionFactory sessionFactory;




  /**
   * This method is used to check consumer is authorized or not.
   * @param adminId is integer
   * @param consumerId is String
   * @param operation is String
   * @param version is String
   * @return isAuthorized boolean value
   * @throws GPAAgreementApplicationException is an exception
   */
  public boolean isAuthorizedConsumerForAdmin(int adminId, String consumerId, String operation, String version)
      throws GPAAgreementApplicationException {
    final String LOG_METHOD = "isAuthorizedConsumerForAdmin():response:: ";
    boolean isAuthorized = false;

    try(SqlSession sqlSession = sessionFactory.openSession()) {
      int count = 0;

      count = sqlSession.getMapper(GPAAgreementMybatisMapper.class)
          .isAuthorizedConsumerForAdmin(consumerId, adminId, operation, version);
      log.info("{} record-count={} ", LOG_METHOD, count);
      if (count > 0) {
        isAuthorized = true;
        sqlSession.getMapper(GPAAgreementMybatisMapper.class)
            .updateLastDateUsedForAdmin(consumerId, operation, version);
        log.info("{} update_ts_isAuthorized = true ", LOG_METHOD);
      }
    } catch (PersistenceException persistenceException) {
      log.error(
          "{} PersistenceException catch ---> {} mybatis exception while checking authorization---> {} ---> {} ",
          LOG_METHOD, GPAAgreementDAOLogConstants.LOG_ERROR_WHILE_RETRIEVING_AUTHORIZATION, new Object[]{consumerId},
          persistenceException);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAgreementMessageKeyConstants.MYBATIS_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION),
          MessageType.getError());
      throw new GPAAgreementApplicationException(messages);
    }
    return isAuthorized;
  }


  /**
   * This method is used to check consumer is authorized or not for input product Id.
   * @param productId is integer
   * @param consumerId is String
   * @param operation is String
   * @param version is String
   * @return isAuthorized boolean value
   * @throws GPAAgreementApplicationException is an exception
   */
  public boolean isAuthorizedConsumerForProduct(int productId, String consumerId, String operation, String version)
      throws GPAAgreementApplicationException {
    final String LOG_METHOD = "isAuthorizedConsumerForProduct:response:: ";
    boolean isAuthorized = false;

    try(SqlSession sqlSession = sessionFactory.openSession()) {
      int count = 0;
      count = sqlSession.getMapper(GPAAgreementMybatisMapper.class)
          .isAuthorizedConsumerForProduct(consumerId, productId, operation, version);
      log.info("{} count={} ", LOG_METHOD, count);
      if (count > 0) {
        isAuthorized = true;
        log.info("{} consumerId={} | productId={} | operation={} | version={} | isAuthorized=true", LOG_METHOD,
            consumerId, productId, operation, version);
        sqlSession.getMapper(GPAAgreementMybatisMapper.class)
            .updateLastDateUsedForProduct(productId, consumerId, operation, version);
      }
    } catch (PersistenceException persistenceException) {
      log.error(
          "{} PersistenceException catch ---> {} mybatis exception while checking authorization---> {} ---> {} ",
          LOG_METHOD, GPAAgreementDAOLogConstants.LOG_ERROR_WHILE_RETRIEVING_AUTHORIZATION_PRODUCT_ID,
          new Object[]{consumerId}, persistenceException);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAgreementMessageKeyConstants.MYBATIS_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION_PRODUCT_ID),
          MessageType.getError());
      throw new GPAAgreementApplicationException(messages);
    }
    return isAuthorized;
  }

}
