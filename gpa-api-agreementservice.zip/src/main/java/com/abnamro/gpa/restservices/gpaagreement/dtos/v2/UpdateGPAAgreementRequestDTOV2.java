package com.abnamro.gpa.restservices.gpaagreement.dtos.v2;


import com.abnamro.gpa.restresource.agreement.Term;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.List;
import lombok.Data;

/**
 * This class is designed for API-v2
 *
 * @author C45158
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_DEFAULT)
public class UpdateGPAAgreementRequestDTOV2 {

    /**
     * serialization applied
     */
    private static final long serialVersionUID = 1L;

    private String agreementStartDateTime;
    private String agreementEndDateTime;
    private String agreementLifeCycleStatusType;
    private String userId;
    private List<Term> attributes;

}
