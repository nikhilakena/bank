package com.abnamro.gpa.restservices.gpaagreement.dao;

/**
 * @author C45158
 * This class contains Log Constants used for GPAAgreements
 */
public class GPAAgreementDAOLogConstants {

	public static final String LOG_ERROR_IBATIS_INITIALIZATION = "LOG_BSIDAO_001";
	  
	  public static final String LOG_ERROR_DB_CONNECTION = "LOG_BSIDAO_002";

	  public static final String LOG_ERROR_WHILE_RETRIEVING_AUTHORIZATION = "LOG_BSIDAO_003";

	public static final String LOG_ERROR_WHILE_RETRIEVING_AUTHORIZATION_PRODUCT_ID = "LOG_BSIDAO_004";

	public static final String LOG_ERROR_DB_CONNECTION_PRODUCT_ID = "LOG_BSIDAO_005";
	
	
}
