/**
 *
 */
package com.abnamro.gpa.restservices.gpaagreement.service;


import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

import com.abnamro.gpa.generic.exception.BusinessApplicationException;


import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementConstants;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementLogConstants;
import com.abnamro.gpa.restservices.gpaagreement.dtos.CreateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Errors;

import com.abnamro.gpa.restservices.gpaagreement.exceptions.Error;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @author C45158
 *
 */
@Component
public class GPAAgreementRestServiceHelper {
	private static final Logger logger = LoggerFactory.getLogger(GPAAgreementRestServiceHelper.class);



	/**
	 * this method is used to check agreement Id
	 * @param agreementId is input DTO
	 * @return flag is boolean value
	 */
	public boolean isInvalidAgreementId(String agreementId) {
		boolean flag= true;

		if(StringUtils.isNotBlank(agreementId)
				&& StringUtils.isNumeric(agreementId)
				&& agreementId.length()==10){
			flag = false;

		}else if(StringUtils.isBlank(agreementId)){
			flag = false;
		}

		return flag;

	}



	/**
	 * this method is used to check product Id
	 * @param productID is input DTO
	 * @return flag is boolean value
	 */
	public boolean isInvalidProductId(String productID) {
		boolean flag= true;
		if(StringUtils.isNotBlank(productID) && StringUtils.isNumeric(productID)
				&& productID.length()<=6){
			flag= false;
		}
		return flag;
	}




	/**
	 * This Method is used to set parameters in case of validation failure.
	 * @param code is String
	 * @param traceId is String
	 * @param message is String
	 * @param paramInfo is list of String
	 * @param successIndicator is boolean value
	 */
	public void handleValidationError(String code, String message, String[] paramInfo, Boolean successIndicator, String traceId) {

		Errors errors = new Errors();
		Error error = new Error();
		error.setCode(code);
		error.setTraceId(traceId);
		error.setMessage(message);
		error.setStatus(GPAAgreementConstants.RESPONSE_STATUS_400);
		error.setParams(paramInfo);
		errors.getErrors().add(error);
		throw new WebApplicationException(Response.status(Status.BAD_REQUEST).type(GPAAgreementConstants.MEDIA_TYPE).entity(errors).build());

	}


	/**
	 * This Method is used to set parameters in case of authorization failure.
	 * @param code is String
	 * @param traceId is String
	 * @param message is String
	 * @param paramInfo is list of String
	 * @param successIndicator is boolean value
	 */
	public void handleUnAuthorizedError(String code, String message, String[] paramInfo, Boolean successIndicator, String traceId) {

		Errors errors = new Errors();
		Error error = new Error();
		error.setCode(code);
		error.setTraceId(traceId);
		error.setMessage(message);
		error.setStatus(GPAAgreementConstants.RESPONSE_STATUS_401);
		error.setParams(paramInfo);
		errors.getErrors().add(error);
		throw new WebApplicationException(Response.status(Status.UNAUTHORIZED).type(GPAAgreementConstants.MEDIA_TYPE).entity(errors).build());

	}


	/**
	 * This method is used to verify status
	 * @param status is enum AgreementLifeCycleStatusType
	 * @return boolean value as flag
	 */
	public boolean isInvalidStatus(String status) {
		boolean flag= true;
		if(StringUtils.isNotBlank(status) && ("ACTIVE".equals(status) || "INACTIVE".equals(status) || "DRAFT".equals(status) )){
			flag = false;
		}
		return flag;
	}

	/**
	 * This method is used to verify inactive status
	 * @param status is enum AgreementLifeCycleStatusType
	 * @return boolean value as flag
	 */
	public boolean isInActiveStatus(String status) {
		boolean flag= false;
		if(StringUtils.isNotBlank(status) && ("INACTIVE".equals(status))){
			flag = true;
		}
		return flag;
	}

	/**
	 * This method is used to handel technical error
	 * @param code is String
	 * @param message is String
	 * @param traceId is String
	 * @param exception AABException
	 */
	public void handleTechnicalError(String code, String message, BusinessApplicationException exception, String traceId) {

			Errors errors = new Errors();
			Error error = new Error();
			error.setCode(code);
			error.setTraceId(traceId);
			error.setMessage(message);
			error.setStatus(GPAAgreementConstants.RESPONSE_STATUS_500);

			if (exception.getMessages() != null
					&& exception.getMessages().getMessages() != null) {
				String[] params = new String[exception.getMessages().getMessages().size()];
				for (int i = 0; i < exception.getMessages().getMessages().size(); i++) {
					params[i] = String.valueOf(exception.getMessages().getMessages().get(i).getMessageKey());
				}
				error.setParams(params);
			}

			errors.getErrors().add(error);
			throw new WebApplicationException(Response.status(Status.INTERNAL_SERVER_ERROR).type(GPAAgreementConstants.MEDIA_TYPE).entity(errors).build());

		}




	/**
	 * This Method is used for validating consumer ID
	 * @param consumerId is String
	 * @return flag as boolean
	 */
	public boolean isInvalidFormatConsumerID(String consumerId) {
		boolean flag= true;
		if(consumerId.length()<=50){
			flag=false;
		}

		return flag;
	}



	/**
	 * This method is used to validate genric details before validating terms
	 * @param consumerId is String
	 * @param traceId is String
	 * @param createAgreementRequest is CreateGPAAgreementRequestDTO
	 */

	public void isInvalidGenericDetails(String consumerId,String traceId, CreateGPAAgreementRequestDTO createAgreementRequest) {


		if(StringUtils.isBlank(consumerId)){
			handleValidationError(GPAAgreementConstants.CODE_CONSUMER_ID_MANDATORY,
					GPAAgreementConstants.DESC_CONSUMER_ID_MANDATORY,
					null,
					false,traceId);
		}
		if(isInvalidFormatConsumerID(consumerId)){
			handleValidationError(GPAAgreementConstants.CODE_CONSUMER_ID_FORMAT_INVALID,
					GPAAgreementConstants.DESC_CONSUMER_ID_FORMAT_INVALID,
					null,
					false,traceId);
		}
		if(isInvalidAgreementId(createAgreementRequest.getAgreementId())){
			handleValidationError(GPAAgreementConstants.CODE_AGREEMENT_ID_FORMAT_INVALID,
					GPAAgreementConstants.DESC_AGREEMENT_ID_FORMAT_INVALID,
					null,
					false,traceId);
		}
		if(StringUtils.isBlank(createAgreementRequest.getProductId())){
			handleValidationError(GPAAgreementConstants.CODE_PRODUCT_ID_MANDATORY,
					GPAAgreementConstants.DESC_PRODUCT_ID_MANDATORY,
					null,
					false,traceId);
		}
		if(isInvalidProductId(createAgreementRequest.getProductId())){
			handleValidationError(GPAAgreementConstants.CODE_PRODUCT_ID_FORMAT_INVALID,
					GPAAgreementConstants.DESC_PRODUCT_ID_FORMAT_INVALID,
					null,
					false,traceId);
		}
		if(StringUtils.isBlank(createAgreementRequest.getAgreementLifeCycleStatusType())){
			handleValidationError(GPAAgreementConstants.CODE_STATUS_MANDATORY,
					GPAAgreementConstants.DESC_STATUS_MANDATORY,
					null,
					false,traceId);
		}
		if(isInvalidStatus(createAgreementRequest.getAgreementLifeCycleStatusType())){
			handleValidationError(GPAAgreementConstants.CODE_STATUS_INVALID,
					GPAAgreementConstants.DESC_STATUS_INVALID,
					null,
					false,traceId);
		}
		if(isInActiveStatus(createAgreementRequest.getAgreementLifeCycleStatusType())){
			handleValidationError(GPAAgreementConstants.CODE_STATUS_INVALID,
					GPAAgreementConstants.DESC_INACTIVE_STATUS_INVALID,
					null,
					false,traceId);
		}
		if(StringUtils.isBlank(createAgreementRequest.getUserId())){
			handleValidationError(GPAAgreementConstants.CODE_USER_ID_MANDATORY,
					GPAAgreementConstants.DESC_USER_ID_MANDATORY,
					null,
					false,traceId);
		}
		if(createAgreementRequest.getUserId().length()>8 || !StringUtils.isAlphanumeric(createAgreementRequest.getUserId())){
			handleValidationError(GPAAgreementConstants.CODE_USER_ID_FORMAT_INVALID,
					GPAAgreementConstants.DESC_USER_ID_FORMAT_INVALID,
					null,
					false,traceId);
		}
	}




	/**
	 * this method is used to check agreement Id
	 * @param agreementId is input DTO
	 * @return flag is boolean value
	 */
	public boolean isInvalidAgreementIdForRead(String agreementId) {
		boolean flag= true;
		if(StringUtils.isNotBlank(agreementId)
				&& StringUtils.isNumeric(agreementId)
				&& agreementId.length()==10){
			flag = false;
		}

		return flag;

	}



	/**
	 *
	 * This method is to check genric details of agreement
	 * @param consumerId is String
	 * @param traceId is String
	 * @param agreementId is String
	 * @param updateAgreementRequest is UpdateGPAAgreementRequestDTO
	 */
	public void isInvalidGenericDetailsForUpdate(String consumerId, String traceId,
			UpdateGPAAgreementRequestDTO updateAgreementRequest,String agreementId) {
		if(updateAgreementRequest!=null){
			if (StringUtils.isBlank(consumerId)) {
				handleValidationError(GPAAgreementConstants.CODE_CONSUMER_ID_MANDATORY,
						GPAAgreementConstants.DESC_CONSUMER_ID_MANDATORY, null, false, traceId);
			}
			if (isInvalidFormatConsumerID(consumerId)) {
				handleValidationError(
						GPAAgreementConstants.CODE_CONSUMER_ID_FORMAT_INVALID,
						GPAAgreementConstants.DESC_CONSUMER_ID_FORMAT_INVALID, null, false, traceId);
			}
			if (isInvalidAgreementIdForRead(agreementId)) {
				// throw an exception if agreement id is invalid
				handleValidationError(
						GPAAgreementConstants.CODE_AGREEMENT_ID_FORMAT_INVALID,
						GPAAgreementConstants.DESC_AGREEMENT_ID_FORMAT_INVALID, null, false, traceId);
			}
			if(StringUtils.isBlank(updateAgreementRequest.getAgreementLifeCycleStatusType())){
				handleValidationError(GPAAgreementConstants.CODE_STATUS_MANDATORY,
						GPAAgreementConstants.DESC_STATUS_MANDATORY,
						null,
						false,traceId);
			}
			if(isInvalidStatus(updateAgreementRequest.getAgreementLifeCycleStatusType())){
				handleValidationError(GPAAgreementConstants.CODE_STATUS_INVALID,
						GPAAgreementConstants.DESC_STATUS_INVALID,
						null,
						false,traceId);
			}
			if(StringUtils.isBlank(updateAgreementRequest.getUserId())){
				handleValidationError(GPAAgreementConstants.CODE_USER_ID_MANDATORY,
						GPAAgreementConstants.DESC_USER_ID_MANDATORY,
						null,
						false,traceId);
			}
			if(updateAgreementRequest.getUserId().length()>8 || !StringUtils.isAlphanumeric(updateAgreementRequest.getUserId())){
				handleValidationError(GPAAgreementConstants.CODE_USER_ID_FORMAT_INVALID,
						GPAAgreementConstants.DESC_USER_ID_FORMAT_INVALID,
						null,
						false,traceId);
			}
		}

	}

	/**
	 * This method is used to check if start date is past dated or not
	 * @param date is String
	 * @return flag as boolean
	 */
	public boolean isInvalidAgreementDate(String date) {

			final String LOG_METHOD = "isInvalidAgreementDate():boolean";

			boolean flag= false;

			DateFormat format = new SimpleDateFormat(GPAAgreementConstants.DATE_TIME_FORMAT);
			format.setLenient(false);

			java.util.Date currentDate=new Timestamp(System.currentTimeMillis());
			java.util.Date agreementStartDateTemp=new Timestamp(System.currentTimeMillis());
			try {
				agreementStartDateTemp = format.parse(date);
			} catch (ParseException e) {
				logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_PARSE_DATE, e);
			}
			if(agreementStartDateTemp.compareTo(currentDate)<=0){
				flag=true;
			}
			return flag;
		}

	/**
	 *
	 * This method is used to validate format of date
	 * @param agreementDate is String
	 * @return flag as boolean
	 */
	public boolean isInvalidFormatAgreementDate(String agreementDate) {
		final String LOG_METHOD = "isInvalidFormatAgreementDate():boolean";

		boolean flag= true;
		if(agreementDate!=null){
			try {
				DateFormat format = new SimpleDateFormat(GPAAgreementConstants.DATE_TIME_FORMAT, Locale.getDefault());
				format.setLenient(false);
				format.parse(agreementDate);
				flag = false;
			} catch (ParseException e) {
				logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_PARSE_DATE, e);
			}
		}
		return flag;
	}

	/**
	 *  This Method is used to set response code 204 in case of update agreement.
	 *
	 */

	public void handleUpdateSuccess() {
		Errors errors = new Errors();
		Error error = new Error();
		error.setStatus("204");
		errors.getErrors().add(error);
		throw new WebApplicationException(Response.status(Status.NO_CONTENT).type(GPAAgreementConstants.MEDIA_TYPE).entity(errors).build());

	}
}
