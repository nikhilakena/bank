package com.abnamro.gpa.restservices.gpaagreement.dtos;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



/**
 * @author PA2619
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)

public class TermResponseDTO implements Serializable{
	
	/**
	 * serialization applied
	 */
	
	private static final long serialVersionUID = 1L;
	
	private String attributeValue;
	
	private String attributeName;

	

	/**
	 * @return the attributeValue
	 */
	public String getAttributeValue() {
		return attributeValue;
	}

	/**
	 * @param attributeValue the attributeValue to set
	 */
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	/**
	 * @return the attributeName
	 */
	public String getAttributeName() {
		return attributeName;
	}

	/**
	 * @param attributeName the attributeName to set
	 */
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	
}
