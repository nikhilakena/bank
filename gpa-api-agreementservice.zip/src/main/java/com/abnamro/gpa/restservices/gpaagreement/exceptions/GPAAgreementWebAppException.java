package com.abnamro.gpa.restservices.gpaagreement.exceptions;

import com.abnamro.gpa.generic.exception.BusinessApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.exceptionhandler.RestEntityResponseExceptionHandler;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.Serializable;


public class GPAAgreementWebAppException extends BusinessApplicationException implements Serializable {

    private static final long serialVersionUID = 1L;

    private Errors error;
     private Object response;
    private HttpStatus status;

    public GPAAgreementWebAppException(HttpStatus status, Errors errors) {
        this.error=errors;
        this.status=status;
    }

    public GPAAgreementWebAppException(HttpStatus status,Object response) {
        this.status=status;
        this.response=response;
    }



    public Errors getError() {
        return error;
    }

    public void setError(Errors error) {
        this.error = error;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public void setStatus(HttpStatus status) {
        this.status = status;
    }

    public Object getResponse() {
        return response;
    }

    public void setResponse(Object response) {
        this.response = response;
    }

    /**
     * Default Constructor to set the value to null
     */
    public GPAAgreementWebAppException()
    {
        super();
    }



}
