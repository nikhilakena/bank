/**
 * 
 */
package com.abnamro.gpa.restservices.gpaagreement.helper;

import java.util.ArrayList;
import java.util.List;


import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import com.abnamro.gpa.restservices.gpaagreement.dtos.CreateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import org.springframework.stereotype.Component;

/**
 * @author C45158
 *
 */
@Component
public class GPAAgreementRestMapper {

	
	
	/**
	 * this method is used to convert input DTO to Rest Resource
	 * @param createAgreementRequest DTO as input
	 * @return  generalProductAgreement is GeneralProductAgreement
	 */
	
	public GeneralProductAgreement convertToGPAAgreementRestResource(CreateGPAAgreementRequestDTO createAgreementRequest){
		GeneralProductAgreement generalProductAgreement= new GeneralProductAgreement();
			if(createAgreementRequest!=null){
				generalProductAgreement.setAgreementEndDate(createAgreementRequest.getAgreementEndDateTime());
				generalProductAgreement.setAgreementId(createAgreementRequest.getAgreementId());
				generalProductAgreement.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.valueOf(createAgreementRequest.getAgreementLifeCycleStatusType()));
				generalProductAgreement.setAgreementStartDate(createAgreementRequest.getAgreementStartDateTime());
				generalProductAgreement.setCustomerId(createAgreementRequest.getCustomerId());
				generalProductAgreement.setProductId(createAgreementRequest.getProductId());
				generalProductAgreement.setCreatedBy(createAgreementRequest.getUserId());
				if(createAgreementRequest.getAttributes()!=null){
					List<Term> restDomainTerms=null;
					
					restDomainTerms = new ArrayList<Term>();
					for (Term dtoTerms : createAgreementRequest.getAttributes()) {
						restDomainTerms.add(dtoTerms);
					}
					
					generalProductAgreement.setTerms(restDomainTerms);
				}
				
			}
		
		return generalProductAgreement;
		
		
	}

	/**
	 * this method is used to convert input DTO to Rest Resource
	 * @param updateAgreementRequest is UpdateGPAAgreementRequestDTO
	 * @param agreementId is String
	 * @param gpaAgreementDTO is GPAAgreementDTO
	 * @return
	 */
	public GeneralProductAgreement convertToGPAAgreementRestResourceForUpdate(
			UpdateGPAAgreementRequestDTO updateAgreementRequest, String agreementId, GPAAgreementDTO gpaAgreementDTO) {
		
		GeneralProductAgreement generalProductAgreement= new GeneralProductAgreement();
			generalProductAgreement.setProductId(String.valueOf(gpaAgreementDTO.getProductId()));
			generalProductAgreement.setCustomerId(String.valueOf(gpaAgreementDTO.getCustomerId()));
			generalProductAgreement.setAgreementId(agreementId);
			generalProductAgreement.setAgreementEndDate(updateAgreementRequest.getAgreementEndDateTime());
			generalProductAgreement.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.valueOf(updateAgreementRequest.getAgreementLifeCycleStatusType()));
			generalProductAgreement.setAgreementStartDate(updateAgreementRequest.getAgreementStartDateTime());
			generalProductAgreement.setModifiedBy(updateAgreementRequest.getUserId());
			
			List<Term> restDomainTerms=null;
			
			restDomainTerms = new ArrayList<Term>();
			
			if(updateAgreementRequest.getAttributes()!=null){
				
				for (Term dtoTerms : updateAgreementRequest.getAttributes()) {
					restDomainTerms.add(dtoTerms);
				}
			}
			
			generalProductAgreement.setTerms(restDomainTerms);
			
	
	return generalProductAgreement;
	
	}
	
}
