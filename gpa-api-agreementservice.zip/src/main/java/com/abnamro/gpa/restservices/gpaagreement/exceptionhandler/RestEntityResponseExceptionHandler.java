package com.abnamro.gpa.restservices.gpaagreement.exceptionhandler;

import com.abnamro.gpa.restservices.gpaagreement.exceptions.*;

import com.abnamro.gpa.restservices.gpaagreement.exceptions.Error;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.ArrayList;

/**
 * Controller advice (Spring-AOP) which catches and process any Exception.
 */
@ControllerAdvice
@Slf4j
public class RestEntityResponseExceptionHandler  {





  /**
   * handleException : processes the Exception.
   *
   * @param exception The Exception with exception message.
   * @return Error A Error DTO which contain actual error message
   */
  @ExceptionHandler({RuntimeException.class})
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  @ResponseBody
  public Errors handleRuntimeException(Exception exception) {
    log.error("Error in  :: RestEntityResponseExceptionHandler :  handleRuntimeException() : ", exception);

    Errors errors = new Errors();
    ArrayList<Error> errorMessageList = new ArrayList<>();
    Error error = new Error();
    error.setCode("500");
    error.setMessage(exception.getMessage());
    error.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
    errorMessageList.add(error);
    errors.setErrors(errorMessageList);
    return errors;
  }
  @ExceptionHandler({Exception.class})
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  @ResponseBody
  public Errors handleException(Exception exception) {
    log.error("Error in  :: RestEntityResponseExceptionHandler :  handleException() : ", exception);

    Errors errors = new Errors();
    ArrayList<Error> errorMessageList = new ArrayList<>();
    Error error = new Error();
    error.setCode("500");
    error.setMessage(exception.getMessage());
    error.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
    errorMessageList.add(error);
    errors.setErrors(errorMessageList);
    return errors;
  }

}
