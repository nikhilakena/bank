package com.abnamro.gpa.restservices.gpaagreement.dtos.v2;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.Data;


/**
 * This class is designed for API-v2
 *
 * @author c45158
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TermResponseDTOV2 implements Serializable {

    /**
     * serialization applied
     */

    private static final long serialVersionUID = 1L;

    private String attributeValue;

    private String attributeName;


}
