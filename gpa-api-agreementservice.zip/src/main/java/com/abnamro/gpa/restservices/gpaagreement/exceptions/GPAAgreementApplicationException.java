package com.abnamro.gpa.restservices.gpaagreement.exceptions;


import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.gpa.generic.exception.BusinessApplicationException;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.exception.Messages;

/**
 * @author C45158
 * This class throws exception in case of any 
 * error occurring for GPAAgreementsConfigurationApplication
 */
public class GPAAgreementApplicationException extends BusinessApplicationException {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;

    private Messages messages;

    /**
     * Default constructor.
     */
    public GPAAgreementApplicationException() {
        this.messages = new Messages();
    }

    /**
     * Constructor that will also set messages on the exception.
     *
     * @param messages it takes messages of Message type
     */
    public GPAAgreementApplicationException(Messages messages) {
        this.messages = messages;
    }

    /**
     * Constructor that takes an existing AABException. This will move any messages
     * into the new exception. <br>
     *
     * @param e accepts type of AABException
     */
    public GPAAgreementApplicationException(BusinessApplicationException e) {
        if (e != null) {
            this.messages = e.getMessages();
        } else {
            this.messages = new Messages();
        }
    }

    public GPAAgreementApplicationException(ContractHeaderServiceInvokerException e) {
    }


    @Override
    public String toString() {
        return getClass().getName() + " : " + this.messages.toString();
    }

    public Messages getMessages() {
        return messages;
    }

    public void setMessages(Messages messages) {
        this.messages = messages;
    }

}
