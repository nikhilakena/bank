/**
 *
 */
package com.abnamro.gpa.restservices.gpaagreement.service.v2;


import com.abnamro.gpa.generic.exception.BusinessApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementRequestDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementResponseDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Error;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Errors;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * This class is designed for API-v2
 * @author C45158
 *
 */
@Component
@Slf4j
public class GPAAgreementRestServiceHelperV2 {

  /**
   * this method is used to check agreement Id
   * @param agreementId is input DTO
   * @return flag is boolean value
   */
  public boolean isInvalidAgreementId(String agreementId) {
    boolean flag = true;

    if ((StringUtils.isBlank(agreementId)) || StringUtils.isNotBlank(agreementId)
        && StringUtils.isNumeric(agreementId)
        && agreementId.length() == 10) {
      flag = false;

    }

    return flag;

  }


  /**
   * this method is used to check product Id
   * @param productID is input DTO
   * @return flag is boolean value
   */
  public boolean isInvalidProductId(String productID) {
    final String LOG_METHOD = "isInvalidProductId():response:: ";
    boolean flag = true;
    if (StringUtils.isNotBlank(productID) && StringUtils.isNumeric(productID)
        && productID.length() <= 6) {
      flag = false;
      log.error("{} Validate productId is not blank={} | is a numeric={} | length is less than equal six={} | flag=false ", LOG_METHOD,
          StringUtils.isNotBlank(productID), StringUtils.isNumeric(productID), (productID.length() <= 6));
    }
    return flag;
  }


  /**
   * This Method is used to set parameters in case of validation failure.
   * @param code is String
   * @param traceId is String
   * @param message is String
   * @param paramInfo is list of String
   * @param successIndicator is boolean value
   */
  public void handleValidationError(String code, String message, String[] paramInfo, Boolean successIndicator,
      String traceId) throws WebApplicationException {
    Errors errors = new Errors();
    Error error = new Error();
    error.setCode(code);
    error.setTraceId(traceId);
    error.setMessage(message);
    error.setStatus(GPAAgreementConstantsV2.RESPONSE_STATUS_400);
    error.setParams(paramInfo);
    errors.getErrors().add(error);
    throw new WebApplicationException(
        Response.status(Status.BAD_REQUEST).type(GPAAgreementConstantsV2.MEDIA_TYPE).entity(errors).build());


  }


  /**
   * This Method is used to set parameters in case of authorization failure.
   * @param code is String
   * @param traceId is String
   * @param message is String
   * @param paramInfo is list of String
   * @param successIndicator is boolean value
   */
  public void handleUnAuthorizedError(String code, String message, String[] paramInfo, Boolean successIndicator,
      String traceId) throws WebApplicationException {

    Errors errors = new Errors();
    Error error = new Error();
    error.setCode(code);
    error.setTraceId(traceId);
    error.setMessage(message);
    error.setStatus(GPAAgreementConstantsV2.RESPONSE_STATUS_401);
    error.setParams(paramInfo);
    errors.getErrors().add(error);
    throw new WebApplicationException(
        Response.status(Status.UNAUTHORIZED).type(GPAAgreementConstantsV2.MEDIA_TYPE).entity(errors).build());

  }

  /**
   * This method is used to verify status
   * @param status is enum AgreementLifeCycleStatusType
   * @return boolean value as flag
   */
  public boolean isInvalidStatus(String status) {
    boolean flag = true;
    if (StringUtils.isNotBlank(status) && ("ACTIVE".equals(status) || GPAAgreementConstantsV2.INACTIVE_STATUS.equals(
        status) || "DRAFT".equals(status))) {
      flag = false;
    }
    return flag;
  }

  /**
   * This method is used to verify inactive status
   * @param status is enum AgreementLifeCycleStatusType
   * @return boolean value as flag
   */
  public boolean isInActiveStatus(String status) {
    boolean flag = false;
    if (StringUtils.isNotBlank(status) && (GPAAgreementConstantsV2.INACTIVE_STATUS.equals(status))) {
      flag = true;
    }
    return flag;
  }

  /**
   * This method is used to handel technical error
   * @param code is String
   * @param message is String
   * @param traceId is String
   * @param exception AABException
   */
  public void handleTechnicalError(String code, String message, BusinessApplicationException exception, String traceId)
      throws WebApplicationException {
    Errors errors = new Errors();
    Error error = new Error();
    error.setCode(code);
    error.setTraceId(traceId);
    error.setMessage(message);
    error.setStatus(GPAAgreementConstantsV2.RESPONSE_STATUS_500);

    if (exception.getMessages() != null
        && exception.getMessages().getMessages() != null) {
      String[] params = new String[exception.getMessages().getMessages().size()];
      for (int i = 0; i < exception.getMessages().getMessages().size(); i++) {
        params[i] = String.valueOf(exception.getMessages().getMessages().get(i).getMessageKey().getId());
      }
      error.setParams(params);
    }

    errors.getErrors().add(error);

    throw new WebApplicationException(
        Response.status(Status.INTERNAL_SERVER_ERROR).type(GPAAgreementConstantsV2.MEDIA_TYPE).entity(errors).build());
  }


  /**
   * This Method is used for validating consumer ID
   * @param consumerId is String
   * @return flag as boolean
   */
  public boolean isInvalidFormatConsumerID(String consumerId) {
    boolean flag = true;
    if (consumerId.length() <= 50) {
      flag = false;
    }

    return flag;
  }


  /**
   * This method is used to validate genric details before validating terms
   * @param consumerId is String
   * @param traceId is String
   * @param createAgreementRequest is CreateGPAAgreementRequestDTO
   * @throws WebApplicationException is an exception
   */

  public void isInvalidGenericDetails(String consumerId, String traceId,
      CreateGPAAgreementRequestDTOV2 createAgreementRequest) throws WebApplicationException {
    final String LOG_METHOD = "isInvalidGenericDetails():response:: ";

    log.info("{} consumerId={} | AgreementId={} | ProductId={}", LOG_METHOD, consumerId,
        createAgreementRequest.getAgreementId(), createAgreementRequest.getProductId());
    if (StringUtils.isBlank(consumerId)) {
      handleValidationError(GPAAgreementConstantsV2.CODE_CONSUMER_ID_MANDATORY,
          GPAAgreementConstantsV2.DESC_CONSUMER_ID_MANDATORY,
          null,
          false, traceId);
    }
    if (isInvalidFormatConsumerID(consumerId)) {
      handleValidationError(GPAAgreementConstantsV2.CODE_CONSUMER_ID_LENGTH_EXCEEDED,
          GPAAgreementConstantsV2.DESC_CONSUMER_ID_LENGTH_EXCEEDED,
          null,
          false, traceId);
    }

    if (isInvalidAgreementId(createAgreementRequest.getAgreementId())) {
      handleValidationError(GPAAgreementConstantsV2.CODE_AGREEMENT_ID_INVALID,
          GPAAgreementConstantsV2.DESC_AGREEMENT_ID_INVALID,
          null,
          false, traceId);
    }
    if (createAgreementRequest.getProductId()==GPAAgreementConstantsV2.PRODUCT_ID_ZERO) {
      handleValidationError(GPAAgreementConstantsV2.CODE_PRODUCT_ID_MANDATORY,
          GPAAgreementConstantsV2.DESC_PRODUCT_ID_MANDATORY,
          null,
          false, traceId);
    }
    if (createAgreementRequest.getProductId() < GPAAgreementConstantsV2.PRODUCT_ID_ZERO || isInvalidProductId(
        String.valueOf(createAgreementRequest.getProductId()))) {
      handleValidationError(GPAAgreementConstantsV2.CODE_PRODUCT_ID_FORMAT_INVALID,
          GPAAgreementConstantsV2.DESC_PRODUCT_ID_FORMAT_INVALID,
          null,
          false, traceId);
    }
    if (StringUtils.isBlank(createAgreementRequest.getAgreementLifeCycleStatusType())) {
      handleValidationError(GPAAgreementConstantsV2.CODE_STATUS_MANDATORY,
          GPAAgreementConstantsV2.DESC_STATUS_MANDATORY,
          null,
          false, traceId);
    }
    if (isInvalidStatus(createAgreementRequest.getAgreementLifeCycleStatusType())) {
      handleValidationError(GPAAgreementConstantsV2.CODE_STATUS_INVALID,
          GPAAgreementConstantsV2.DESC_STATUS_INVALID,
          null,
          false, traceId);
    }
    if (isInActiveStatus(createAgreementRequest.getAgreementLifeCycleStatusType())) {
      handleValidationError(GPAAgreementConstantsV2.CODE_STATUS_INVALID,
          GPAAgreementConstantsV2.DESC_INACTIVE_STATUS_INVALID,
          null,
          false, traceId);
    }

    checkUserIDValidation(createAgreementRequest, traceId);

  }


  private void checkUserIDValidation(CreateGPAAgreementRequestDTOV2 createAgreementRequest, String traceId)
      throws WebApplicationException {
    if (StringUtils.isBlank(createAgreementRequest.getUserId())) {

      handleValidationError(GPAAgreementConstantsV2.CODE_USER_ID_MANDATORY,
          GPAAgreementConstantsV2.DESC_USER_ID_MANDATORY,
          null,
          false, traceId);
    }
    if (createAgreementRequest.getUserId().length() > 8 || !StringUtils.isAlphanumeric(
        createAgreementRequest.getUserId())) {
      handleValidationError(GPAAgreementConstantsV2.CODE_USER_ID_FORMAT_INVALID,
          GPAAgreementConstantsV2.DESC_USER_ID_FORMAT_INVALID,
          null,
          false, traceId);
    }

  }


  /**
   * this method is used to check agreement Id
   * @param agreementId is input DTO
   * @return flag is boolean value
   */
  public boolean isInvalidAgreementIdForRead(String agreementId) {
    boolean flag = true;

    if (StringUtils.isNotBlank(agreementId)
        && StringUtils.isNumeric(agreementId)
        && agreementId.length() == 10) {
      flag = false;
    }

    return flag;

  }


  /**
   *
   * This method is to check genric details of agreement
   * @param consumerId is String
   * @param traceId is String
   * @param agreementId is String
   * @param updateAgreementRequest is UpdateGPAAgreementRequestDTO
   */
  public void isInvalidGenericDetailsForUpdate(String consumerId, String traceId,
      UpdateGPAAgreementRequestDTO updateAgreementRequest, String agreementId) throws WebApplicationException {
    if (StringUtils.isBlank(consumerId)) {
      handleValidationError(GPAAgreementConstantsV2.CODE_CONSUMER_ID_MANDATORY,
          GPAAgreementConstantsV2.DESC_CONSUMER_ID_MANDATORY,
          null,
          false, traceId);
    }
    if (isInvalidFormatConsumerID(consumerId)) {
      handleValidationError(GPAAgreementConstantsV2.CODE_CONSUMER_ID_LENGTH_EXCEEDED,
          GPAAgreementConstantsV2.DESC_CONSUMER_ID_LENGTH_EXCEEDED,
          null,
          false, traceId);
    }
    if (updateAgreementRequest != null) {
      if (isInvalidAgreementIdForRead(agreementId)) {
        // throw an exception if agreement id is invalid
        handleValidationError(
            GPAAgreementConstantsV2.CODE_AGREEMENT_ID_INVALID,
            GPAAgreementConstantsV2.DESC_AGREEMENT_ID_INVALID, null, false, traceId);
      }
      if (StringUtils.isBlank(updateAgreementRequest.getAgreementLifeCycleStatusType())) {
        handleValidationError(GPAAgreementConstantsV2.CODE_STATUS_MANDATORY,
            GPAAgreementConstantsV2.DESC_STATUS_MANDATORY,
            null,
            false, traceId);
      }
      if (isInvalidStatus(updateAgreementRequest.getAgreementLifeCycleStatusType())) {
        handleValidationError(GPAAgreementConstantsV2.CODE_STATUS_INVALID,
            GPAAgreementConstantsV2.DESC_STATUS_INVALID,
            null,
            false, traceId);
      }
      if (StringUtils.isBlank(updateAgreementRequest.getUserId())) {
        handleValidationError(GPAAgreementConstantsV2.CODE_USER_ID_MANDATORY,
            GPAAgreementConstantsV2.DESC_USER_ID_MANDATORY,
            null,
            false, traceId);
      }
      if (updateAgreementRequest.getUserId().length() > 8 || !StringUtils.isAlphanumeric(
          updateAgreementRequest.getUserId())) {
        handleValidationError(GPAAgreementConstantsV2.CODE_USER_ID_FORMAT_INVALID,
            GPAAgreementConstantsV2.DESC_USER_ID_FORMAT_INVALID,
            null,
            false, traceId);
      }
    }

  }


  /**
   *  This Method is used to set response code 204 in case of update agreement.
   *
   */

  public void handleUpdateSuccess() {
    Errors errors = new Errors();
    Error error = new Error();
    error.setStatus("204");
    errors.getErrors().add(error);
    throw new WebApplicationException(
        Response.status(Status.NO_CONTENT).type(GPAAgreementConstantsV2.MEDIA_TYPE).entity(errors).build());

  }

  /**
   *  This Method is used to set response code 201 in case of create agreement.
   * @param response is input to this method
   *
   */

  public void handleCreateSuccess(CreateGPAAgreementResponseDTOV2 response) {
    throw new WebApplicationException(
        Response.status(Status.CREATED).type(GPAAgreementConstantsV2.MEDIA_TYPE).entity(response).build());
  }
}
