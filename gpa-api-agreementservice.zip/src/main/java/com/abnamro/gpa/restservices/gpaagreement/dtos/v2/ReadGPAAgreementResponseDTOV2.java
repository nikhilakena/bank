/**
 *
 */
package com.abnamro.gpa.restservices.gpaagreement.dtos.v2;

import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.List;
import lombok.Data;

/**
 * This class is designed for API-v2
 * @author C45158
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_DEFAULT)
public class ReadGPAAgreementResponseDTOV2 {


  private String productId;
  private String customerId;
  private String agreementStartDateTime;
  private String agreementEndDateTime;
  private String createdBy;
  private String createdDateTime;
  private String modifiedBy;
  private String modifiedDateTime;
  private AgreementLifeCycleStatusType agreementLifeCycleStatusType;
  private List<TermResponseDTOV2> attributes;


}
