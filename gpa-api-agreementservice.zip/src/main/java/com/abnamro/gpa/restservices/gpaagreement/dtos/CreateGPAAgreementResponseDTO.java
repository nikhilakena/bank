package com.abnamro.gpa.restservices.gpaagreement.dtos;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author C45158
 *
 */
@JsonInclude(Include.NON_DEFAULT)
public class CreateGPAAgreementResponseDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String agreementId;

	public String getAgreementId() {
		return agreementId;
	}

	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}
	
	
}
