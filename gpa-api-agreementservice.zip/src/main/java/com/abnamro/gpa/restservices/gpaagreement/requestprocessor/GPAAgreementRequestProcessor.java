package com.abnamro.gpa.restservices.gpaagreement.requestprocessor;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

import com.abnamro.gpa.generic.exception.BusinessApplicationException;



import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.gpaagreementdao.dao.GPAAgreementDAO;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementConstants;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementLogConstants;
import com.abnamro.gpa.restservices.gpaagreement.dtos.CreateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.ReadGPAAgreementResponseDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Error;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Errors;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementWebAppException;
import com.abnamro.gpa.restservices.gpaagreement.helper.GPAAgreementRestMapper;
import com.abnamro.gpa.restservices.gpaagreement.helper.GPAAgreementViewMapper;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

/**
 * @author C45158
 * This class is request processor class for the GPAAgreementsConfiguration service operation
 */
@Component
public class GPAAgreementRequestProcessor {

	private static final Logger logger = LoggerFactory.getLogger(GPAAgreementRequestProcessor.class);


	private GPAAgreementRestMapper gpaAgreementRestMapper ;

	private GPAAgreementRequestValidator gpaAgreeementRequestValidator ;
	private GPAAgreementViewMapper gpaAgreementViewMapper ;

	private GPAAgreementDAO gpaAgreementDAO ;

	@Autowired
	public GPAAgreementRequestProcessor(GPAAgreementRestMapper gpaAgreementRestMapper, GPAAgreementRequestValidator gpaAgreeementRequestValidator, GPAAgreementViewMapper gpaAgreementViewMapper, GPAAgreementDAO gpaAgreementDAO) {
		this.gpaAgreementRestMapper = gpaAgreementRestMapper;
		this.gpaAgreeementRequestValidator = gpaAgreeementRequestValidator;
		this.gpaAgreementViewMapper = gpaAgreementViewMapper;
		this.gpaAgreementDAO = gpaAgreementDAO;
	}

	/**
	 *
	 * This method is used to mapp rest domain model calls and validate create
	 * Agreement request
	 *
	 * @param createAgreementRequest
	 *            is CreateGPAAgreementRequestDTO
	 * @param consumerId
	 *            is String
	 * @param traceId
	 *            is String
	 * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
	 * @throws GPAAgreementValidatorException
	 *             is an exception
	 * @throws GPAAdministrationDAOException
	 *             is an exception
	 * @throws GPAAgreementApplicationException
	 *             is an exception
	 * @throws GPAAgreementDAOException
	 *             is an exception
	 */
	public String createGPAAgreement(CreateGPAAgreementRequestDTO createAgreementRequest, String consumerId,
									 String traceId) throws GPAAgreementValidatorException, GPAAdministrationDAOException,
			GPAAgreementApplicationException, GPAAgreementDAOException, GPAAgreementWebAppException {

		final String LOG_METHOD = "createGPAAgreement():response";

		AgreementValidatorResultDTO agreementValidatorResultDTO = null;
		GeneralProductAgreement generalProductAgreement = null;

		GPAAgreementDTO gpaAgreementDTO = null;

		try {

			generalProductAgreement = gpaAgreementRestMapper.convertToGPAAgreementRestResource(createAgreementRequest);
			agreementValidatorResultDTO = gpaAgreeementRequestValidator
					.validateCreateAgreementRequest(generalProductAgreement, consumerId, traceId);

			if (agreementValidatorResultDTO != null) {
				if (agreementValidatorResultDTO.isSuccessIndicator()) {
					generalProductAgreement = reserveCIN(generalProductAgreement);

					gpaAgreementDTO = gpaAgreementViewMapper.convertToGPAAgreementDTO(generalProductAgreement);

					gpaAgreementDAO.createGPAAgreement(gpaAgreementDTO);
				} else {
					handleValidationError(agreementValidatorResultDTO.getCode(),
							agreementValidatorResultDTO.getMessage(), agreementValidatorResultDTO.getParams(),
							traceId);
				}
			}

		} catch (GPAAgreementDAOException gpaAgreementDAOException) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_DAO_EXCEPTION_IN_CREATE_AGREEMENT_REQUEST_PROCESSOR,
					gpaAgreementDAOException);
			if (gpaAgreementDAOException.getMessages() != null
					&& gpaAgreementDAOException.getMessages().getMessages() != null) {
				for (int i = 0; i < gpaAgreementDAOException.getMessages().getMessages().size(); i++) {
					if ("MESSAGE_GPAG_003"
							.equals(gpaAgreementDAOException.getMessages().getMessages().get(i).getMessageKey())) {
						handleValidationError(GPAAgreementConstants.CODE_AGREEMENT_ID_ALREADY_PRESENT,
								GPAAgreementConstants.DESC_AGREEMENT_ID_ALREADY_PRESENT, null, traceId);
					}
				}
			}
			throw new GPAAgreementApplicationException(gpaAgreementDAOException);
		}

		return generalProductAgreement.getAgreementId();

	}

	private GeneralProductAgreement reserveCIN(GeneralProductAgreement generalProductAgreement)
			throws GPAAgreementApplicationException {
		final String LOG_METHOD = "reserveCIN():response";

		if (StringUtils.isBlank(generalProductAgreement.getAgreementId())) {
			long cin;
			/*try {
		//		cin = getReservedCIN();
			} catch (ContractHeaderServiceInvokerException e) {
				logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_RESERVE_CIN_IN_CREATE_AGREEMENT_REQUEST_PROCESSOR,
						e);
				throw new GPAAgreementApplicationException(e);
			}
			generalProductAgreement.setAgreementId(Long.toString(cin));*/
		}
		return generalProductAgreement;

	}

	/**
	 * This Method is used to set parameters in case of validation failure.
	 *
	 * @param code
	 *            is String
	 * @param message
	 *            is String
	 * @param paramInfo
	 *            is list of String
	 * @param successIndicator
	 *            is boolean value
	 */
	private void handleValidationError(String code, String message, String[] paramInfo,
									   String traceId) throws GPAAgreementWebAppException {

		Errors errors = new Errors();
		Error error = new Error();
		error.setCode(code);
		error.setTraceId(traceId);
		error.setMessage(message);
		error.setStatus(GPAAgreementConstants.RESPONSE_STATUS_400);
		error.setParams(paramInfo);
		errors.getErrors().add(error);
		throw new GPAAgreementWebAppException(HttpStatus.BAD_REQUEST,errors);

	}

	/*private long getReservedCIN() throws ContractHeaderServiceInvokerException {
		ReserveCINInputDTO inputDTO = new ReserveCINInputDTO();
		inputDTO.setCreatedTimestamp(new Date());
		inputDTO.setEmpolyeeIdentifier("GPAA");
		inputDTO.setContractIdentifierCode("GPA");
		inputDTO.setProgramIdentifier("BSI632");
		inputDTO.setBoNumber("495062");
		inputDTO.setSystemIdentifier(SystemIdentifier.ONLINE);
		ReserveCINUtil util = new ReserveCINUtil();
		return util.reserveCIN(null, inputDTO);
	}*/

	/**
	 * This operation is used to retrieve existing gpa agreements
	 *
	 * @param agreementId
	 *            in CIN format
	 * @param consumerId
	 *            is consumerId of calling application
	 * @param traceId
	 *            is traceId
	 * @return ReadGPAAgreementResponseDTO containing agreement details
	 */
	public ReadGPAAgreementResponseDTO readGPAAgreement(String agreementId, String consumerId, String traceId) {
		final String LOG_METHOD = "readGPAAgreement():response";

		ReadGPAAgreementResponseDTO gpaAgreement = null;
		try {
			// call to Database to read agreement details
			GPAAgreementDTO gpaAgreementDTO = gpaAgreementDAO.readGPAAgreement(agreementId);

			if (gpaAgreementDTO != null) {

				// call to check authorization for input consumerId and product
				// combination
				gpaAgreeementRequestValidator.isUserAuthorizedForProduct(gpaAgreementDTO.getProductId(), consumerId,
						traceId, GPAAgreementConstants.OPERATION_NAME_READ, GPAAgreementConstants.VERSION_READ);

				// call to mapper to convert to rest DTO
				gpaAgreement = gpaAgreementViewMapper.convertToReadGPAAgreementResponseDTO(gpaAgreementDTO);

			} else {
				handleResourceNotFoundError(GPAAgreementConstants.CODE_AGREEMENT_ID_NOT_FOUND,
						GPAAgreementConstants.DESC_AGREEMENT_ID_NOT_FOUND, null, traceId);
			}

		} catch (GPAAgreementDAOException exception) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_EXCEPTION_IN_DAO_READ_AGREEMENT, exception);
			handleTechnicalError(GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					GPAAgreementConstants.DESC_EXCEPTION_IN_DAO_READ_AGREEMENT, exception, traceId);
		}

		return gpaAgreement;
	}

	/**
	 * This method is used to handel technical error
	 *
	 * @param code
	 *            is String
	 * @param message
	 *            is String
	 * @param traceId
	 *            is String
	 * @param exception
	 *            AABException
	 */
	private void handleTechnicalError(String code, String message, BusinessApplicationException exception, String traceId) {

		Errors errors = new Errors();
		Error error = new Error();
		error.setCode(code);
		error.setTraceId(traceId);
		error.setMessage(message);
		error.setStatus(GPAAgreementConstants.RESPONSE_STATUS_500);

		if (exception.getMessages() != null && exception.getMessages().getMessages() != null) {
			String[] params = new String[exception.getMessages().getMessages().size()];
			for (int i = 0; i < exception.getMessages().getMessages().size(); i++) {
				params[i] = String.valueOf(exception.getMessages().getMessages().get(i).getMessageKey());
			}
			error.setParams(params);
		}

		errors.getErrors().add(error);
		throw new WebApplicationException(Response.status(Status.INTERNAL_SERVER_ERROR)
				.type(GPAAgreementConstants.MEDIA_TYPE).entity(errors).build());

	}

	/**
	 * This Method is used to set parameters in case of validation failure.
	 *
	 * @param code
	 *            is String
	 * @param message
	 *            is String
	 * @param paramInfo
	 *            is list of String
	 * @param successIndicator
	 *            is boolean value
	 */
	private void handleResourceNotFoundError(String code, String message, String[] paramInfo,
											 String traceId) {

		Errors errors = new Errors();
		Error error = new Error();
		error.setCode(code);
		error.setTraceId(traceId);
		error.setMessage(message);
		error.setStatus(GPAAgreementConstants.RESPONSE_STATUS_404);
		error.setParams(paramInfo);
		errors.getErrors().add(error);
		throw new WebApplicationException(
				Response.status(Status.NOT_FOUND).type(GPAAgreementConstants.MEDIA_TYPE).entity(errors).build());

	}

	/**
	 *
	 * this method is used to read amdin data for input as agreement Id
	 *
	 * @param updateAgreementRequest
	 *            is UpdateGPAAgreementRequestDTO
	 * @param agreementId
	 *            is String
	 * @param consumerId
	 *            is String
	 * @param traceId
	 *            is String
	 * @throws GPAAgreementValidatorException
	 *             is an exception for validator
	 * @throws GPAAdministrationDAOException
	 *             is an exception for AdministrationException
	 * @throws GPAAgreementApplicationException
	 *             is an exception for GPAAgreementaApplication
	 */
	public void updateGPAAgreement(UpdateGPAAgreementRequestDTO updateAgreementRequest, String agreementId,
								   String consumerId, String traceId)
			throws GPAAgreementValidatorException, GPAAdministrationDAOException, GPAAgreementApplicationException, GPAAgreementWebAppException {
		final String LOG_METHOD = "readGPAAgreementToUpdate():response";
		GPAAgreementDTO gpaAgreementDTO = null;

		AgreementValidatorResultDTO agreementValidatorResultDTO = null;
		GeneralProductAgreement generalProductAgreement = null;

		try {
			// call to Database to read agreement details
			gpaAgreementDTO = gpaAgreementDAO.readGPAAgreement(agreementId);

			if (gpaAgreementDTO != null && updateAgreementRequest != null) {

				generalProductAgreement = gpaAgreementRestMapper.convertToGPAAgreementRestResourceForUpdate(
						updateAgreementRequest, agreementId, gpaAgreementDTO);

				agreementValidatorResultDTO = gpaAgreeementRequestValidator
						.validateUpdateAgreementRequest(generalProductAgreement, consumerId, traceId);

				invokeDAOForUpdateGPAAgreement(traceId, agreementValidatorResultDTO, generalProductAgreement);
			} else {
				handleResourceNotFoundError(GPAAgreementConstants.CODE_AGREEMENT_ID_NOT_FOUND,
						GPAAgreementConstants.DESC_AGREEMENT_ID_NOT_FOUND, null, traceId);
			}

		} catch (GPAAgreementDAOException exception) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_EXCEPTION_IN_DAO_READ_AGREEMENT, exception);
			handleTechnicalError(GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					GPAAgreementConstants.DESC_EXCEPTION_IN_DAO_READ_AGREEMENT, exception, traceId);
		}

	}

	private void invokeDAOForUpdateGPAAgreement(String traceId, AgreementValidatorResultDTO agreementValidatorResultDTO,
												GeneralProductAgreement generalProductAgreement) throws GPAAgreementDAOException, GPAAgreementWebAppException {
		GPAAgreementDTO gpaAgreementDTO;
		if (agreementValidatorResultDTO != null) {
			if (agreementValidatorResultDTO.isSuccessIndicator()) {
				gpaAgreementDTO = gpaAgreementViewMapper.convertToGPAAgreementDTO(generalProductAgreement);

				gpaAgreementDAO.updateGPAAgreement(gpaAgreementDTO);

			} else {
				handleValidationError(agreementValidatorResultDTO.getCode(),
						agreementValidatorResultDTO.getMessage(), agreementValidatorResultDTO.getParams(),
						traceId);
			}
		}
	}

}
