package com.abnamro.gpa.restservices.gpaagreement.constants;


/**
 * @author C45158
 * This class contains Log constants used for GPAAgreements
 */
public class GPAAgreementLogConstants {

	public static final String LOG_EXCEPTION_IN_CREATE_AGREEMENT = "LOG_BSI632_001";
	public static final String LOG_DAO_EXCEPTION_IN_CREATE_AGREEMENT_REQUEST_PROCESSOR = "LOG_BSI632_002";
	public static final String LOG_EXCEPTION_IN_DAO_READ_ADMINISTRATION = "LOG_BSI632_003";
	public static final String LOG_EXCEPTION_IN_DAO_CREATE_AGREEMENT = "LOG_BSI632_004";
	public static final String LOG_DAO_EXCEPTION_IN_READ_ADMIN_REQUEST_VALIDATOR = "LOG_BSI632_005";
	public static final String MEDIA_TYPE = "application/json";
	public static final String LOG_TIME_TO_STRING_PARSE_EXCEPTION_IN_REQUEST_VIEW_MAPPER = "LOG_BSI632_006";
	public static final String LOG_DAO_EXCEPTION_IN_ISUSERAUTHORIZED_REQUEST_VALIDATOR = "LOG_BSI632_007";
	public static final String LOG_RESERVE_CIN_IN_CREATE_AGREEMENT_REQUEST_PROCESSOR = "LOG_BSI632_008";
	public static final String LOG_EXCEPTION_IN_AGREEMENT_VALIDATOR_CREATE_AGREEMENT = "LOG_BSI632_009";
	public static final String LOG_EXCEPTION_IN_DAO_READ_AGREEMENT = "LOG_BSI632_010";
	public static final String LOG_EXCEPTION_IN_AGREEMENT_VALIDATOR_UPDATE_AGREEMENT = "LOG_BSI632_011";
	public static final String LOG_EXCEPTION_IN_UPDATE_AGREEMENT = "LOG_BSI632_012";
	public static final String LOG_PARSE_DATE = "LOG_BSI632_013";


}
