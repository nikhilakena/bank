package com.abnamro.gpa.restservices.gpaagreement.dao;

/**
* 
* <br>This is used to store constants DAO layer of FAQ service.<br>
* 
* 
* <PRE>
* 
* Developer		Date				Change Reason		Change
* ---------		----				-------------		------
* TCS			APR 12 2017			Initial Version		PA
* </PRE>
* 
* @author TCS
*/
public class GPAAgreementDAOConstants {
	
	public static final String SCHEMA_DATABASE = "SCHEMA_GPA";
	public static final String DEFAULT_DB_SCHEMA = "UU01";
	
	public static final String DATASOURCE_NAME = "GPADATASOURCE";
	public static final String DEFAULT_DATASOURCE = "jdbc/GPA_DataSource";
	


	
}
