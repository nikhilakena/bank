/**
 *
 */
package com.abnamro.gpa.restservices.gpaagreement.exceptions;


import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementConstants;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;

/**
 * @author C45158
 *
 */
public class GPAAgreementExceptionMapper implements ExceptionMapper<Throwable> {

	@Override
	public Response toResponse(Throwable throwable) {
		return handleException(throwable);
	}

	/**
	 * @param throwable is Throwable
	 * @return isObjectOfType is boolean
	 */
	private boolean isWebApplicationException(Throwable throwable) {
		return isObjectOfType(throwable, WebApplicationException.class);
	}

	/**
	 * @param obj is Object
	 * @param clazz is Class
	 * @return boolean value
	 */
	private boolean isObjectOfType(Object obj, Class<?> clazz) {
		return clazz.isInstance(obj);
	}

	/**
	 * This method is used to handel exception
	 * @param throwable is Throwable
	 * @return Response
	 */
	private Response handleException(Throwable throwable) {
		if (isWebApplicationException(throwable)
					&& ((WebApplicationException)throwable).getResponse()!=null
					&& ((WebApplicationException)throwable).getResponse().getEntity() instanceof Errors) {
				return processWebApplicationException((WebApplicationException) throwable);
			}
		return Response.status(Response.Status.INTERNAL_SERVER_ERROR).type(GPAAgreementConstants.MEDIA_TYPE).entity(throwable).build();
	}

	/**
	 * This method is used to process web application exception
	 * @param webApplicationException is WebApplicationException
	 * @return Response
	 */
	private Response processWebApplicationException(WebApplicationException webApplicationException) {
		Errors errors = (Errors)webApplicationException.getResponse().getEntity();
		return Response.status(webApplicationException.getResponse().getStatus()).type(GPAAgreementConstants.MEDIA_TYPE).entity(errors).build();
	}


}
