package com.abnamro.gpa.restservices.gpaagreement.constants;


/**
 * This class contains constants which are used in this application
 */
public class GPAAgreementConstants {


  public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";


  public static final String OPERATION_NAME_CREATE = "createGPAAgreement";
  public static final String VERSION_CREATE = "V1";

  public static final String OPERATION_NAME_READ = "readGPAAgreement";
  public static final String VERSION_READ = "V1";

  public static final String OPERATION_NAME_UPDATE = "updateGPAAgreement";
  public static final String VERSION_UPDATE = "V1";

  public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

  public static final String CODE_AGREEMENT_ID_FORMAT_INVALID = "AGREEMENT_ID_FORMAT_INVALID";
  public static final String DESC_AGREEMENT_ID_FORMAT_INVALID = "Format of agreement ID is invalid";

  public static final String CODE_AGREEMENT_ID_ALREADY_PRESENT = "AGREEMENT_ID_ALREADY_PRESENT";
  public static final String DESC_AGREEMENT_ID_ALREADY_PRESENT = "Agreement ID is already present in the General Product Agreement Administration";

  public static final String CODE_STATUS_MANDATORY = "STATUS_MANDATORY";
  public static final String DESC_STATUS_MANDATORY = "Agreement Lifecycle Status is not provided";

  public static final String CODE_STATUS_INVALID = "STATUS_INVALID";
  public static final String DESC_STATUS_INVALID = "Agreement Lifecycle Status is invalid";
  public static final String DESC_INACTIVE_STATUS_INVALID = "Status INACTIVE is invalid for this operation";

  public static final String CODE_PRODUCT_ID_FORMAT_INVALID = "PRODUCT_ID_FORMAT_INVALID";
  public static final String DESC_PRODUCT_ID_FORMAT_INVALID = "Format of the Product ID is invalid";

  public static final String CODE_PRODUCT_ID_MANDATORY = "PRODUCT_ID_MANDATORY";
  public static final String DESC_PRODUCT_ID_MANDATORY = "Product ID is not provided";

  public static final String CODE_PRODUCT_ID_NOT_REGISTERED = "PRODUCT_ID_NOT_REGISTERED";
  public static final String DESC_PRODUCT_ID_NOT_REGISTERED = "Product ID is not present in the General Product Agreement Administration";

  public static final String CODE_USER_ID_FORMAT_INVALID = "USER_ID_FORMAT_INVALID";
  public static final String DESC_USER_ID_FORMAT_INVALID = "Format of User ID is invalid";

  public static final String CODE_USER_ID_MANDATORY = "USER_ID_MANDATORY";
  public static final String DESC_USER_ID_MANDATORY = "User ID is not provided";

  public static final String CODE_CONSUMER_UNAUTHORIZED = "CONSUMER_UNAUTHORIZED";
  public static final String DESC_CONSUMER_UNAUTHORIZED = "Consumer is not authorized for this operation";

  public static final String CODE_CONSUMER_ID_FORMAT_INVALID = "CONSUMER_ID_FORMAT_INVALID";
  public static final String DESC_CONSUMER_ID_FORMAT_INVALID = "Format of consumer ID is invalid";

  public static final String CODE_CONSUMER_ID_MANDATORY = "CONSUMER_ID_MANDATORY";
  public static final String DESC_CONSUMER_ID_MANDATORY = "Consumer ID is not provided";


  public static final String MEDIA_TYPE = "application/json";
  public static final String RESPONSE_STATUS_400 = "400";
  public static final String RESPONSE_STATUS_500 = "500";
  public static final String RESPONSE_STATUS_401 = "401";


  public static final String CODE_INTERNAL_ERROR = "INTERNAL_ERROR";

  public static final String CODE_TECHNICAL_ERROR = "TECHNICAL_ERROR";

  public static final String DESC_EXCEPTION_IN_DAO_READ_ADMINISTRATION = "Technical error occured";

  public static final String DESC_EXCEPTION_IN_CREATE_AGREEMENT = "Technical error occured";

  public static final String DESC_EXCEPTION_IN_DAO_CREATE_AGREEMENT = "Technical error occured";

  public static final String DESC_EXCEPTION_IN_AGREEMENT_VALIDATOR_CREATE_AGREEMENT = "Technical error occured";

  public static final String DESC_EXCEPTION_IN_DAO_READ_AGREEMENT = "Technical error occured";

  public static final String RESPONSE_STATUS_404 = "404";

  public static final String CODE_AGREEMENT_ID_NOT_FOUND = "AGREEMENT_ID_NOT_FOUND";
  public static final String DESC_AGREEMENT_ID_NOT_FOUND = "Agreement ID is not present in the General Product Agreement Administration";
  public static final String DESC_EXCEPTION_IN_AGREEMENT_VALIDATOR_UPDATE_AGREEMENT = "Technical error occured";
  public static final String DESC_EXCEPTION_IN_UPDATE_AGREEMENT = "Technical error occured";


}
