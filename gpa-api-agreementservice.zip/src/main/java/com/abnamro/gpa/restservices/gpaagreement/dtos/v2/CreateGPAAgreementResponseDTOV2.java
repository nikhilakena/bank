package com.abnamro.gpa.restservices.gpaagreement.dtos.v2;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;
import lombok.Data;

/**
 * This class is designed for API-v2
 *
 * @author C45158
 */
@Data
@JsonInclude(Include.NON_DEFAULT)
public class CreateGPAAgreementResponseDTOV2 implements Serializable {

    private static final long serialVersionUID = 1L;

    private String agreementId;


}
