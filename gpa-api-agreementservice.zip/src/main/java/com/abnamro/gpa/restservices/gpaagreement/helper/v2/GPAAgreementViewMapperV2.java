/**
 *
 */
package com.abnamro.gpa.restservices.gpaagreement.helper.v2;

import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementTermDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementLogConstants;
import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.ReadGPAAgreementResponseDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.TermResponseDTOV2;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;


/**
 * This class is designed for API-v2
 * @author C45158
 *
 */
@Slf4j
@Component
public class GPAAgreementViewMapperV2 {


  /**
   * This method is used to convert into GPAAgreementDTO
   * @param generalProductAgreement DTO as input
   * @return gpaAgreementDTO is GPAAgreementDTO
   */
  public GPAAgreementDTO convertToGPAAgreementDTO(GeneralProductAgreement generalProductAgreement) {
    GPAAgreementDTO gpaAgreementDTO = new GPAAgreementDTO();

    if (StringUtils.isNotBlank(generalProductAgreement.getAgreementId())) {
      gpaAgreementDTO.setAgreementId(Long.parseLong(generalProductAgreement.getAgreementId()));
    }
    if (StringUtils.isNotBlank(generalProductAgreement.getCustomerId())) {
      gpaAgreementDTO.setCustomerId(Long.parseLong(generalProductAgreement.getCustomerId()));
    }
    if (StringUtils.isNotBlank(generalProductAgreement.getProductId())) {
      gpaAgreementDTO.setProductId(Integer.parseInt(generalProductAgreement.getProductId()));
    }

    gpaAgreementDTO.setCreatedBy(generalProductAgreement.getCreatedBy());
    gpaAgreementDTO.setUpdatedBy(generalProductAgreement.getModifiedBy());
    gpaAgreementDTO.setStatus(generalProductAgreement.getAgreementLifeCycleStatusType().name());

    gpaAgreementDTO.setEndDate(convertStringToTimeStamp(generalProductAgreement.getAgreementEndDate()));
    gpaAgreementDTO.setStartDate(convertStringToTimeStamp(generalProductAgreement.getAgreementStartDate()));
    gpaAgreementDTO.setCreatedTimeStamp(convertStringToTimeStamp(generalProductAgreement.getDateCreated()));
    gpaAgreementDTO.setUpdatedTimeStamp(convertStringToTimeStamp(generalProductAgreement.getDateModified()));

    if (generalProductAgreement.getTerms() != null) {
      List<GPAAgreementTermDTO> agreementDTOTerms = null;

      agreementDTOTerms = new ArrayList<>();

      for (Term terms : generalProductAgreement.getTerms()) {
        GPAAgreementTermDTO gpaAgreementTermDTO = null;
        gpaAgreementTermDTO = convertTogpaAgreementTermDTO(terms);
        agreementDTOTerms.add(gpaAgreementTermDTO);
      }

      gpaAgreementDTO.setTerms(agreementDTOTerms);
    }

    return gpaAgreementDTO;


  }


  /**
   * @param terms is Term
   * @return gpaAgreementTermDTO is GPAAgreementTermDTO
   */
  private GPAAgreementTermDTO convertTogpaAgreementTermDTO(Term terms) {

    GPAAgreementTermDTO gpaAgreementTermDTO = new GPAAgreementTermDTO();
    gpaAgreementTermDTO.setTermName(terms.getAttributeName());
    gpaAgreementTermDTO.setTermValue(terms.getAttributeValue());

    return gpaAgreementTermDTO;

  }

  /**
   * This method is used to convert string to timestamp
   * @param agreementEndDate is String
   * @return timestamp is Timestamp
   */
  private Timestamp convertStringToTimeStamp(String agreementEndDate) {
    final String logMethod = "convertStringToTimeStamp():response:: ";
    Timestamp timestamp = null;
    try {
      if (StringUtils.isNotBlank(agreementEndDate)) {

        DateFormat format = new SimpleDateFormat(GPAAgreementConstantsV2.DATE_FORMAT, Locale.getDefault());

        timestamp = new java.sql.Timestamp(format.parse(agreementEndDate).getTime());
      }
    } catch (ParseException e) {
      log.error("{} Exception occurred while string parse in request view mapper={} | ParseException={}", logMethod,
          GPAAgreementLogConstants.LOG_TIME_TO_STRING_PARSE_EXCEPTION_IN_REQUEST_VIEW_MAPPER, e);
    }

    return timestamp;

  }


  /**
   * This method is used to convert timestamo to string
   * @param date is String
   * @return timestamp is Timestamp
   */
  private String convertTimestampToString(Timestamp date) {
    DateFormat format = new SimpleDateFormat(GPAAgreementConstantsV2.DATE_FORMAT, Locale.getDefault());

    String stringdate = null;
    if (date != null) {
      stringdate = format.format(date);
    }
    log.info("convertTimestampToString():response:: " + stringdate);
    return stringdate;
  }


  /**
   * This method is used to convert gpaAgreementDTO into ReadGPAAgreementResponseDTO
   * @param gpaAgreementDTO DAO layer agreement details DTO
   * @return rest response
   */
  public ReadGPAAgreementResponseDTOV2 convertToReadGPAAgreementResponseDTO(GPAAgreementDTO gpaAgreementDTO) {
    ReadGPAAgreementResponseDTOV2 readGPAAgreementResponseDTO = null;

    if (gpaAgreementDTO != null) {
      readGPAAgreementResponseDTO = new ReadGPAAgreementResponseDTOV2();
      readGPAAgreementResponseDTO.setCustomerId(String.valueOf(gpaAgreementDTO.getCustomerId()));
      readGPAAgreementResponseDTO.setProductId(String.valueOf(gpaAgreementDTO.getProductId()));
      readGPAAgreementResponseDTO.setAgreementLifeCycleStatusType(
          AgreementLifeCycleStatusType.valueOf(gpaAgreementDTO.getStatus()));
      readGPAAgreementResponseDTO.setAgreementStartDateTime(convertTimestampToString(gpaAgreementDTO.getStartDate()));
      readGPAAgreementResponseDTO.setAgreementEndDateTime(convertTimestampToString(gpaAgreementDTO.getEndDate()));
      readGPAAgreementResponseDTO.setCreatedDateTime(convertTimestampToString(gpaAgreementDTO.getCreatedTimeStamp()));
      readGPAAgreementResponseDTO.setModifiedDateTime(convertTimestampToString(gpaAgreementDTO.getUpdatedTimeStamp()));
      readGPAAgreementResponseDTO.setCreatedBy(gpaAgreementDTO.getCreatedBy());
      //ModifiedTimeStamp
      readGPAAgreementResponseDTO.setModifiedBy(gpaAgreementDTO.getUpdatedBy());
      if (gpaAgreementDTO.getTerms() != null && !gpaAgreementDTO.getTerms().isEmpty()) {
        List<TermResponseDTOV2> terms = new ArrayList<>();
        for (GPAAgreementTermDTO termDTO : gpaAgreementDTO.getTerms()) {
          TermResponseDTOV2 term = new TermResponseDTOV2();
          term.setAttributeName(termDTO.getTermName());
          term.setAttributeValue(termDTO.getTermValue());
          terms.add(term);
        }
        readGPAAgreementResponseDTO.setAttributes(terms);
      }
    }
    return readGPAAgreementResponseDTO;
  }


}
