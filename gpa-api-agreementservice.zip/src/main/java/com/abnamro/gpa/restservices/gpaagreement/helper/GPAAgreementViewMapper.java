/**
 * 
 */
package com.abnamro.gpa.restservices.gpaagreement.helper;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;



import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementTermDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementConstants;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementLogConstants;
import com.abnamro.gpa.restservices.gpaagreement.dtos.ReadGPAAgreementResponseDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.TermResponseDTO;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @author C45158
 *
 */
@Component
public class GPAAgreementViewMapper {
	private static final Logger logHelper = LoggerFactory.getLogger(GPAAgreementViewMapper.class);


	
	/**
	 * This method is used to convert into GPAAgreementDTO
	 * @param generalProductAgreement DTO as input 
	 * @return gpaAgreementDTO is GPAAgreementDTO
	 */
	public GPAAgreementDTO convertToGPAAgreementDTO(GeneralProductAgreement generalProductAgreement){
		GPAAgreementDTO gpaAgreementDTO= new GPAAgreementDTO();
		
		
		if(StringUtils.isNotBlank(generalProductAgreement.getAgreementId())){
		 gpaAgreementDTO.setAgreementId(Long.parseLong(generalProductAgreement.getAgreementId()));
	    }
		if(StringUtils.isNotBlank(generalProductAgreement.getCustomerId())){
			gpaAgreementDTO.setCustomerId(Long.parseLong(generalProductAgreement.getCustomerId()));
		}
		if(StringUtils.isNotBlank(generalProductAgreement.getProductId())){
			gpaAgreementDTO.setProductId(Integer.parseInt(generalProductAgreement.getProductId()));
		}
		
		gpaAgreementDTO.setCreatedBy(generalProductAgreement.getCreatedBy());
		gpaAgreementDTO.setUpdatedBy(generalProductAgreement.getModifiedBy());
		gpaAgreementDTO.setStatus(generalProductAgreement.getAgreementLifeCycleStatusType().name());

		gpaAgreementDTO.setEndDate(convertTimeStampToString(generalProductAgreement.getAgreementEndDate()));
		gpaAgreementDTO.setStartDate(convertTimeStampToString(generalProductAgreement.getAgreementStartDate()));
		gpaAgreementDTO.setCreatedTimeStamp(convertTimeStampToString(generalProductAgreement.getDateCreated()));
		gpaAgreementDTO.setUpdatedTimeStamp(convertTimeStampToString(generalProductAgreement.getDateModified()));
		
		if(generalProductAgreement.getTerms()!=null){
			List <GPAAgreementTermDTO> agreementDTOTerms=null;
			
			agreementDTOTerms =new ArrayList<GPAAgreementTermDTO>();
			
			for (Term terms : generalProductAgreement.getTerms()) {
				GPAAgreementTermDTO gpaAgreementTermDTO=null;
				gpaAgreementTermDTO= convertTogpaAgreementTermDTO(terms);
				agreementDTOTerms.add(gpaAgreementTermDTO);
			}
			
			gpaAgreementDTO.setTerms(agreementDTOTerms);
		}
		
		return gpaAgreementDTO;
		
		
	}
	

	/**
	 * @param terms is Term
	 * @return  gpaAgreementTermDTO is GPAAgreementTermDTO
	 */
	private GPAAgreementTermDTO convertTogpaAgreementTermDTO(Term terms) {
		
		GPAAgreementTermDTO gpaAgreementTermDTO = new GPAAgreementTermDTO();
		gpaAgreementTermDTO.setTermName(terms.getAttributeName());
		gpaAgreementTermDTO.setTermValue(terms.getAttributeValue());
		
		return gpaAgreementTermDTO;
		
	}

	/**
	 * This method is used to convert timestamo to string
	 * @param agreementEndDate is String
	 * @return timestamp is Timestamp
	 */
	private Timestamp convertTimeStampToString(String agreementEndDate) {
		final String LOG_METHOD = "convertTimeStampToString(): timestamp";
		Timestamp timestamp = null;
		try {
			if(StringUtils.isNotBlank(agreementEndDate)){
				
				DateFormat format = new SimpleDateFormat(GPAAgreementConstants.DATE_FORMAT, Locale.getDefault());
				
				timestamp = new java.sql.Timestamp(format.parse(agreementEndDate).getTime());
			}
		} catch (ParseException e) {
				logHelper.error(LOG_METHOD, GPAAgreementLogConstants.LOG_TIME_TO_STRING_PARSE_EXCEPTION_IN_REQUEST_VIEW_MAPPER, e);
		}
		
		
		
		return timestamp;
		
	}
	
	
	/**
	 * This method is used to convert timestamo to string
	 * @param agreementEndDate is String
	 * @return timestamp is Timestamp
	 */
	private String convertTimestampToString(Timestamp date) {
		
		DateFormat format = new SimpleDateFormat(GPAAgreementConstants.DATE_FORMAT, Locale.getDefault());
		
		String stringdate = null;
		if(date != null){
			stringdate = format.format(date);
		}
		return stringdate;
		
	}


	/**
	 * This method is used to convert gpaAgreementDTO into ReadGPAAgreementResponseDTO
	 * @param gpaAgreementDTO DAO layer agreement details DTO
	 * @return rest response 
	 */
	public ReadGPAAgreementResponseDTO convertToReadGPAAgreementResponseDTO(GPAAgreementDTO gpaAgreementDTO) {
		ReadGPAAgreementResponseDTO readGPAAgreementResponseDTO= null;
		
		if(gpaAgreementDTO!= null){
			readGPAAgreementResponseDTO = new ReadGPAAgreementResponseDTO();
			readGPAAgreementResponseDTO.setCustomerId(String.valueOf(gpaAgreementDTO.getCustomerId()));
			readGPAAgreementResponseDTO.setProductId(String.valueOf(gpaAgreementDTO.getProductId()));
			readGPAAgreementResponseDTO.setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType.valueOf(gpaAgreementDTO.getStatus()));
			readGPAAgreementResponseDTO.setAgreementStartDateTime(convertTimestampToString(gpaAgreementDTO.getStartDate()));
			readGPAAgreementResponseDTO.setAgreementEndDateTime(convertTimestampToString(gpaAgreementDTO.getEndDate()));
			readGPAAgreementResponseDTO.setCreatedDateTime(convertTimestampToString(gpaAgreementDTO.getCreatedTimeStamp()));
			readGPAAgreementResponseDTO.setModifiedDateTime(convertTimestampToString(gpaAgreementDTO.getUpdatedTimeStamp()));
			readGPAAgreementResponseDTO.setCreatedBy(gpaAgreementDTO.getCreatedBy());
			//ModifiedTimeStamp
			readGPAAgreementResponseDTO.setModifiedBy(gpaAgreementDTO.getUpdatedBy());
			if(gpaAgreementDTO.getTerms()!= null && !gpaAgreementDTO.getTerms().isEmpty()){
				List<TermResponseDTO> terms = new ArrayList<TermResponseDTO>();
				for(GPAAgreementTermDTO termDTO:gpaAgreementDTO.getTerms()){
					TermResponseDTO term = new TermResponseDTO();
					term.setAttributeName(termDTO.getTermName());
					term.setAttributeValue(termDTO.getTermValue());
					terms.add(term);
				}
				readGPAAgreementResponseDTO.setAttributes(terms);
			}
		}
		return readGPAAgreementResponseDTO;
	}


	
}
