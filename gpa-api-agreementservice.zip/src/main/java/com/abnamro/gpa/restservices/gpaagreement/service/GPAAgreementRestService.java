package com.abnamro.gpa.restservices.gpaagreement.service;


import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;



import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementConstants;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementLogConstants;
import com.abnamro.gpa.restservices.gpaagreement.dtos.CreateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.CreateGPAAgreementResponseDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.ReadGPAAgreementResponseDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementWebAppException;
import com.abnamro.gpa.restservices.gpaagreement.requestprocessor.GPAAgreementRequestProcessor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @author C45158
 *
 * This is rest service class for the GPAAgreement service.
 */


@Path("/v1")
public class GPAAgreementRestService {


	@Autowired
	private GPAAgreementRestServiceHelper gpaAgreementRestServiceHelper;
	@Autowired
	private GPAAgreementRequestProcessor gpaAgreeementRequestProcessor;

	private static final Logger logger = LoggerFactory.getLogger(GPAAgreementRestService.class);



	/**
	 * This method is used to create gpa agreements
	 * @param request is httpservlet request
	 * @param consumerId is consumerId
	 * @param traceId is traceId
	 * @param servletContext is  ServletContext
	 * @param createAgreementRequest is input DTO
	 * @return  agreementValidatorResultDTO is DTO
	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public CreateGPAAgreementResponseDTO createAgreement(@Context HttpServletRequest request, @HeaderParam("Consumer-Id") String consumerId,
			@HeaderParam("Trace-Id") String traceId, @Context ServletContext servletContext, CreateGPAAgreementRequestDTO createAgreementRequest) throws GPAAgreementWebAppException {

		final String LOG_METHOD = "createAgreement():response";

		CreateGPAAgreementResponseDTO response = null;
		try {

			gpaAgreementRestServiceHelper.isInvalidGenericDetails(consumerId, traceId, createAgreementRequest);
				String agreementId = gpaAgreeementRequestProcessor.createGPAAgreement(createAgreementRequest,consumerId, traceId);
				response = new CreateGPAAgreementResponseDTO();
				response.setAgreementId(agreementId);

		} catch (GPAAdministrationDAOException e) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_EXCEPTION_IN_DAO_READ_ADMINISTRATION, e);
			gpaAgreementRestServiceHelper.handleTechnicalError(GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					GPAAgreementConstants.DESC_EXCEPTION_IN_DAO_READ_ADMINISTRATION,
					e, traceId);
		} catch (GPAAgreementApplicationException e) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_EXCEPTION_IN_CREATE_AGREEMENT, e);
			gpaAgreementRestServiceHelper.handleTechnicalError(GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					GPAAgreementConstants.DESC_EXCEPTION_IN_CREATE_AGREEMENT,
					e,traceId);
		} catch (GPAAgreementDAOException exception) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_EXCEPTION_IN_DAO_CREATE_AGREEMENT, exception);
			gpaAgreementRestServiceHelper.handleTechnicalError(GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					GPAAgreementConstants.DESC_EXCEPTION_IN_DAO_CREATE_AGREEMENT,
					exception,traceId);
		} catch (GPAAgreementValidatorException gpaAGreementValidatorException) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_EXCEPTION_IN_AGREEMENT_VALIDATOR_CREATE_AGREEMENT, gpaAGreementValidatorException);
			gpaAgreementRestServiceHelper.handleTechnicalError(GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					GPAAgreementConstants.DESC_EXCEPTION_IN_AGREEMENT_VALIDATOR_CREATE_AGREEMENT,
					gpaAGreementValidatorException,traceId);
		}

		return response;

	}


	/**
	 * This operation is used to retrieve existing gpa agreements
	 *
	 * @param request is httpservlet request
	 * @param servletContext is  ServletContext
	 * @param consumerId is consumerId of calling application
	 * @param traceId is traceId
	 * @param agreementId in CIN format
	 * @return ReadGPAAgreementResponseDTO containing agreement details
	 */
	@GET
	@Path("/{agreementId}")
	@Produces(MediaType.APPLICATION_JSON)
	public ReadGPAAgreementResponseDTO getGPAAgreement(@Context HttpServletRequest request,
			@Context ServletContext servletContext, @HeaderParam("Consumer-Id") String consumerId,
			@HeaderParam("Trace-Id") String traceId, @PathParam("agreementId") String agreementId){

		ReadGPAAgreementResponseDTO response= null;

		if(StringUtils.isBlank(consumerId)){
			gpaAgreementRestServiceHelper.handleValidationError(GPAAgreementConstants.CODE_CONSUMER_ID_MANDATORY,
					GPAAgreementConstants.DESC_CONSUMER_ID_MANDATORY,
					null,
					false,traceId);
		} else if(gpaAgreementRestServiceHelper.isInvalidFormatConsumerID(consumerId)){
			gpaAgreementRestServiceHelper.handleValidationError(GPAAgreementConstants.CODE_CONSUMER_ID_FORMAT_INVALID,
					GPAAgreementConstants.DESC_CONSUMER_ID_FORMAT_INVALID,
					null,
					false,traceId);
		} else if(gpaAgreementRestServiceHelper.isInvalidAgreementIdForRead(agreementId)){
			//throw an exception if agreement id is invalid
			gpaAgreementRestServiceHelper.handleValidationError(GPAAgreementConstants.CODE_AGREEMENT_ID_FORMAT_INVALID,
					GPAAgreementConstants.DESC_AGREEMENT_ID_FORMAT_INVALID,
					null,
					false,traceId);
		}else {
			//call request processor if format is valid
			response =gpaAgreeementRequestProcessor.readGPAAgreement(agreementId,consumerId, traceId);
		}

		return response;

	}


	/**
	 * This operation is used to update existing gpa agreements
	 * @param request is HttpServletRequest
	 * @param servletContext is ServletContext
	 * @param consumerId is String
	 * @param traceId is TraceId
	 * @param agreementId is agreementId
	 * @param updateAgreementRequest is UpdateGPAAgreementRequestDTO
	 */
	@PUT
	@Path("/{agreementId}")
	@Produces(MediaType.APPLICATION_JSON)
	public void updateGPAAgreement(@Context HttpServletRequest request,
			@Context ServletContext servletContext, @HeaderParam("Consumer-Id") String consumerId,
			@HeaderParam("Trace-Id") String traceId, @PathParam("agreementId") String agreementId, UpdateGPAAgreementRequestDTO updateAgreementRequest){

		final String LOG_METHOD = "updateAgreement():response";

		try {

			gpaAgreementRestServiceHelper.isInvalidGenericDetailsForUpdate(consumerId, traceId,
					updateAgreementRequest,agreementId);

			gpaAgreeementRequestProcessor.updateGPAAgreement(updateAgreementRequest, agreementId, consumerId,
					traceId);

		} catch (GPAAgreementValidatorException gpaAGreementValidatorException) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_EXCEPTION_IN_AGREEMENT_VALIDATOR_UPDATE_AGREEMENT,
					gpaAGreementValidatorException);
			gpaAgreementRestServiceHelper.handleTechnicalError(GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					GPAAgreementConstants.DESC_EXCEPTION_IN_AGREEMENT_VALIDATOR_UPDATE_AGREEMENT,
					gpaAGreementValidatorException, traceId);
		} catch (GPAAdministrationDAOException e) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_EXCEPTION_IN_DAO_READ_ADMINISTRATION, e);
			gpaAgreementRestServiceHelper.handleTechnicalError(GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					GPAAgreementConstants.DESC_EXCEPTION_IN_DAO_READ_ADMINISTRATION, e, traceId);
		} catch (GPAAgreementApplicationException | GPAAgreementWebAppException e) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_EXCEPTION_IN_UPDATE_AGREEMENT, e);
			gpaAgreementRestServiceHelper.handleTechnicalError(GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					GPAAgreementConstants.DESC_EXCEPTION_IN_UPDATE_AGREEMENT, e, traceId);
		}

		gpaAgreementRestServiceHelper.handleUpdateSuccess();


	}


}
