package com.abnamro.gpa.restservices.gpaagreement.requestprocessor.v2;

import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.ReserveCINInputDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.v2.ReserveCINUtilV2;
import com.abnamro.gpa.generic.exception.BusinessApplicationException;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.gpaagreementdao.constants.GPAAgreementDAOMessageKeys;
import com.abnamro.gpa.generic.gpaagreementdao.dao.GPAAgreementDAOV2;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementLogConstants;
import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementRequestDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.ReadGPAAgreementResponseDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Error;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Errors;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.helper.v2.GPAAgreementRestMapperV2;
import com.abnamro.gpa.restservices.gpaagreement.helper.v2.GPAAgreementViewMapperV2;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * This class is request processor class for the GPAAgreementsConfiguration service operation
 */
@Component
@Slf4j
public class GPAAgreementRequestProcessorV2 {


  private final GPAAgreementRestMapperV2 gpaAgreementRestMapperV2;

  private final GPAAgreementRequestValidatorV2 gpaAgreementRequestValidatorV2;

  private final GPAAgreementViewMapperV2 gpaAgreementViewMapperV2;

  private final GPAAgreementDAOV2 gpaAgreementDAO;

  private final ReserveCINUtilV2 reserveCINUtilV2;

  @Autowired
  public GPAAgreementRequestProcessorV2(GPAAgreementRestMapperV2 gpaAgreementRestMapperV2,
      GPAAgreementRequestValidatorV2 gpaAgreementRequestValidatorV2,
      GPAAgreementViewMapperV2 gpaAgreementViewMapperV2, GPAAgreementDAOV2 gpaAgreementDAO,
      ReserveCINUtilV2 reserveCINUtilV2) {
    this.gpaAgreementRestMapperV2 = gpaAgreementRestMapperV2;
    this.gpaAgreementRequestValidatorV2 = gpaAgreementRequestValidatorV2;
    this.gpaAgreementViewMapperV2 = gpaAgreementViewMapperV2;
    this.gpaAgreementDAO = gpaAgreementDAO;
    this.reserveCINUtilV2 = reserveCINUtilV2;
  }

  /**
   * This method is used to mapp rest domain model calls and validate create Agreement request
   *
   * @param createAgreementRequest is CreateGPAAgreementRequestDTOV2
   * @param consumerId             is String
   * @param traceId                is String
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   * @throws GPAAgreementValidatorException   is an exception
   * @throws GPAAdministrationDAOException    is an exception
   * @throws GPAAgreementApplicationException is an exception
   * @throws GPAAgreementDAOException         is an exception
   */
  public String createGPAAgreement(CreateGPAAgreementRequestDTOV2 createAgreementRequest, String consumerId,
      String traceId) throws GPAAgreementValidatorException, GPAAdministrationDAOException,
      GPAAgreementApplicationException, GPAAgreementDAOException, WebApplicationException {

    final String LOG_METHOD = "createGPAAgreement():response:: ";

    AgreementValidatorResultDTO agreementValidatorResultDTO = null;
    GeneralProductAgreement generalProductAgreement = null;
    GPAAgreementDTO gpaAgreementDTO = null;

    try {
      generalProductAgreement = gpaAgreementRestMapperV2
          .convertToGPAAgreementRestResource(createAgreementRequest);
      agreementValidatorResultDTO = gpaAgreementRequestValidatorV2
          .validateCreateAgreementRequest(generalProductAgreement, consumerId, traceId);

      if (agreementValidatorResultDTO != null) {
        if (agreementValidatorResultDTO.isSuccessIndicator()) {
          generalProductAgreement = reserveCIN(traceId, generalProductAgreement);

          gpaAgreementDTO = gpaAgreementViewMapperV2.convertToGPAAgreementDTO(generalProductAgreement);

          gpaAgreementDAO.createGPAAgreement(traceId, gpaAgreementDTO);
        } else {
          handleValidationError(agreementValidatorResultDTO.getCode(),
              agreementValidatorResultDTO.getMessage(), agreementValidatorResultDTO.getParams(),
              traceId);
        }
      }

    } catch (GPAAgreementDAOException gpaAgreementDAOException) {
      log.error("{} DAO exception occurred in create agreement request processor={} | GPAAgreementDAOException={}", LOG_METHOD,
          GPAAgreementLogConstants.LOG_DAO_EXCEPTION_IN_CREATE_AGREEMENT_REQUEST_PROCESSOR, gpaAgreementDAOException);

      if (gpaAgreementDAOException.getMessages() != null
          && gpaAgreementDAOException.getMessages().getMessages() != null) {
        for (int i = 0; i < gpaAgreementDAOException.getMessages().getMessages().size(); i++) {

          if (GPAAgreementDAOMessageKeys.DUPLICATE_KEY_EXCEPTION_WHILE_CREATING_AGREEMENT_DETAILS.getId()
              .equals(gpaAgreementDAOException.getMessages().getMessages().get(i).getMessageKey().getId())) {
            handleValidationError(GPAAgreementConstantsV2.CODE_AGREEMENT_ID_ALREADY_PRESENT,
                GPAAgreementConstantsV2.DESC_AGREEMENT_ID_ALREADY_PRESENT, null, traceId);
          }
        }
      }
      throw new GPAAgreementApplicationException(gpaAgreementDAOException);
    }

    return generalProductAgreement.getAgreementId();

  }

  private GeneralProductAgreement reserveCIN(String traceId, GeneralProductAgreement generalProductAgreement)
      throws GPAAgreementApplicationException {
    final String LOG_METHOD = "reserveCIN():response:: ";

    if (StringUtils.isBlank(generalProductAgreement.getAgreementId())) {
      long cin;
      try {
        cin = getReservedCIN(traceId);
        log.info("{} CIN number is={} ", LOG_METHOD, cin);
      } catch (ContractHeaderServiceInvokerException contractHeaderServiceInvokerException) {
        log.error("{} Exception occurred in reserve CIN create agreement request processor={} | ContractHeaderServiceInvokerException={} ", LOG_METHOD,
            GPAAgreementLogConstants.LOG_RESERVE_CIN_IN_CREATE_AGREEMENT_REQUEST_PROCESSOR,
            contractHeaderServiceInvokerException);
        throw new GPAAgreementApplicationException(contractHeaderServiceInvokerException);
      }
      generalProductAgreement.setAgreementId(Long.toString(cin));
    }
    return generalProductAgreement;

  }

  /**
   * This Method is used to set parameters in case of validation failure.
   *
   * @param code      is String
   * @param message   is String
   * @param paramInfo is list of String
   */
  private void handleValidationError(String code, String message, String[] paramInfo, String traceId)
      throws WebApplicationException {
    Errors errors = new Errors();
    Error error = new Error();
    error.setCode(code);
    error.setTraceId(traceId);
    error.setMessage(message);
    error.setStatus(GPAAgreementConstantsV2.RESPONSE_STATUS_400);
    error.setParams(paramInfo);
    errors.getErrors().add(error);

    throw new WebApplicationException(
        Response.status(Status.BAD_REQUEST).type(GPAAgreementConstantsV2.MEDIA_TYPE).entity(errors).build());
  }

  private long getReservedCIN(String traceId) throws ContractHeaderServiceInvokerException {
    ReserveCINInputDTO inputDTO = new ReserveCINInputDTO();
    inputDTO.setContractIdentifierCode("GPA");
    return reserveCINUtilV2.reserveCIN(traceId, inputDTO);

  }

  /**
   * This operation is used to retrieve existing gpa agreements
   *
   * @param agreementId in CIN format
   * @param consumerId  is consumerId of calling application
   * @param traceId     is traceId
   * @return ReadGPAAgreementResponseDTO containing agreement details
   */
  public ReadGPAAgreementResponseDTOV2 readGPAAgreement(String agreementId, String consumerId, String traceId)
      throws WebApplicationException {
    final String LOG_METHOD = "readGPAAgreement():response:: ";

    ReadGPAAgreementResponseDTOV2 gpaAgreement = null;
    try {
      // call to Database to read agreement details
      GPAAgreementDTO gpaAgreementDTO = gpaAgreementDAO.readGPAAgreement(agreementId);

      if (gpaAgreementDTO != null) {

        // call to check authorization for input consumerId and product
        // combination
        gpaAgreementRequestValidatorV2.isUserAuthorizedForProduct(gpaAgreementDTO.getProductId(), consumerId,
            traceId, GPAAgreementConstantsV2.OPERATION_NAME_READ, GPAAgreementConstantsV2.VERSION_READ);

        // call to mapper to convert to rest DTO
        gpaAgreement = gpaAgreementViewMapperV2.convertToReadGPAAgreementResponseDTO(gpaAgreementDTO);
        log.info("{} Retrieve DTO after mapper conversion for read GPAAgreement={} ", LOG_METHOD, gpaAgreement.getAgreementEndDateTime());
      } else {
        handleResourceNotFoundError(GPAAgreementConstantsV2.CODE_AGREEMENT_ID_NOT_FOUND,
            GPAAgreementConstantsV2.DESC_AGREEMENT_ID_NOT_FOUND, null, traceId);
      }

    } catch (GPAAgreementDAOException gpaAgreementDAOException) {
      log.error("{} Exception occurred in dao read agreement={} | GPAAgreementDAOException={} ", LOG_METHOD,
          GPAAgreementLogConstants.LOG_EXCEPTION_IN_DAO_READ_AGREEMENT, gpaAgreementDAOException);
      handleTechnicalError(GPAAgreementConstantsV2.CODE_TECHNICAL_ERROR,
          GPAAgreementConstantsV2.DESC_TECHNICAL_ERROR, gpaAgreementDAOException, traceId);
    }
    return gpaAgreement;
  }

  /**
   * This method is used to handle technical error
   *
   * @param code      is String
   * @param message   is String
   * @param traceId   is String
   * @param exception AABException
   */
  private void handleTechnicalError(String code, String message, BusinessApplicationException exception, String traceId)
      throws WebApplicationException {
    final String LOG_METHOD = "handleTechnicalError():response:: ";
    Errors errors = new Errors();
    Error error = new Error();
    error.setCode(code);
    error.setTraceId(traceId);
    error.setMessage(message);
    error.setStatus(GPAAgreementConstantsV2.RESPONSE_STATUS_500);

    if (exception.getMessages() != null && exception.getMessages().getMessages() != null) {
      String[] params = new String[exception.getMessages().getMessages().size()];
      for (int i = 0; i < exception.getMessages().getMessages().size(); i++) {
        params[i] = String.valueOf(exception.getMessages().getMessages().get(i).getMessageKey().getId());
        log.error("{} params={} ", LOG_METHOD, params[i]);
      }
      error.setParams(params);
    }
    errors.getErrors().add(error);
    throw new WebApplicationException(
        Response.status(Status.INTERNAL_SERVER_ERROR).type(GPAAgreementConstantsV2.MEDIA_TYPE).entity(errors).build());
  }

  /**
   * This Method is used to set parameters in case of validation failure.
   *
   * @param code      is String
   * @param message   is String
   * @param paramInfo is list of String
   */
  private void handleResourceNotFoundError(String code, String message, String[] paramInfo, String traceId)
      throws WebApplicationException {
    final String LOG_METHOD = "handleResourceNotFoundError:response:: ";
    log.error("{} message={}", LOG_METHOD, message);
    Errors errors = new Errors();
    Error error = new Error();
    error.setCode(code);
    error.setTraceId(traceId);
    error.setMessage(message);
    error.setStatus(GPAAgreementConstantsV2.RESPONSE_STATUS_404);
    error.setParams(paramInfo);
    errors.getErrors().add(error);
    throw new WebApplicationException(
        Response.status(Status.NOT_FOUND).type(GPAAgreementConstantsV2.MEDIA_TYPE).entity(errors).build());
  }

  /**
   * this method is used to read amdin data for input as agreement Id
   *
   * @param updateAgreementRequest is UpdateGPAAgreementRequestDTO
   * @param agreementId            is String
   * @param consumerId             is String
   * @param traceId                is String
   * @throws GPAAgreementValidatorException   is an exception for validator
   * @throws GPAAdministrationDAOException    is an exception for AdministrationException
   * @throws GPAAgreementApplicationException is an exception for GPAAgreementaApplication
   */
  public void updateGPAAgreement(UpdateGPAAgreementRequestDTO updateAgreementRequest, String agreementId,
      String consumerId, String traceId)
      throws GPAAgreementValidatorException, GPAAdministrationDAOException, WebApplicationException {
    final String LOG_METHOD = "updateGPAAgreement():response:: ";
    GPAAgreementDTO gpaAgreementDTO = null;

    AgreementValidatorResultDTO agreementValidatorResultDTO = null;
    GeneralProductAgreement generalProductAgreement = null;

    try {
      // call to Database to read agreement details
      gpaAgreementDTO = gpaAgreementDAO.readGPAAgreement(agreementId);

      if (gpaAgreementDTO != null && updateAgreementRequest != null) {

        generalProductAgreement = gpaAgreementRestMapperV2.convertToGPAAgreementRestResourceForUpdate(
            updateAgreementRequest, agreementId, gpaAgreementDTO);

        agreementValidatorResultDTO = gpaAgreementRequestValidatorV2
            .validateUpdateAgreementRequest(generalProductAgreement, consumerId, traceId);

        invokeDAOForUpdateGPAAgreement(traceId, agreementValidatorResultDTO, generalProductAgreement);
      } else {
        handleResourceNotFoundError(GPAAgreementConstantsV2.CODE_AGREEMENT_ID_NOT_FOUND,
            GPAAgreementConstantsV2.DESC_AGREEMENT_ID_NOT_FOUND, null, traceId);
      }
    } catch (GPAAgreementDAOException gpaAgreementDAOException) {
      log.error("{} Exception occurred in dao reading agreement for update={} | GPAAgreementDAOException={} ", LOG_METHOD,
          GPAAgreementLogConstants.LOG_EXCEPTION_IN_DAO_READ_AGREEMENT, gpaAgreementDAOException);
      handleTechnicalError(GPAAgreementConstantsV2.CODE_TECHNICAL_ERROR,
          GPAAgreementConstantsV2.DESC_TECHNICAL_ERROR, gpaAgreementDAOException, traceId);
    }
  }

  private void invokeDAOForUpdateGPAAgreement(String traceId, AgreementValidatorResultDTO agreementValidatorResultDTO,
      GeneralProductAgreement generalProductAgreement) throws GPAAgreementDAOException, WebApplicationException {
    GPAAgreementDTO gpaAgreementDTO;
    if (agreementValidatorResultDTO != null) {
      if (agreementValidatorResultDTO.isSuccessIndicator()) {

        gpaAgreementDTO = gpaAgreementViewMapperV2.convertToGPAAgreementDTO(generalProductAgreement);

        gpaAgreementDAO.updateGPAAgreement(traceId, gpaAgreementDTO);

      } else {
        handleValidationError(agreementValidatorResultDTO.getCode(),
            agreementValidatorResultDTO.getMessage(), agreementValidatorResultDTO.getParams(),
            traceId);
      }
    }
  }
}
