package com.abnamro.gpa.restservices.gpaagreement.constants;


import com.abnamro.gpa.generic.exception.MessageKey;

/**
 * @author C45158
 * This class contains Message Key constants used for GPAAgreements
 */
public class GPAAgreementMessageKeyConstants {

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION = new MessageKey("MESSAGE_BSI632_001");
	
	public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION = new MessageKey("MESSAGE_BSI632_002");

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION_PRODUCT_ID = new MessageKey("MESSAGE_BSI632_003");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVING_AUTHORIZATION_PRODUCT_ID = new MessageKey("MESSAGE_BSI632_004");
	
	
}
