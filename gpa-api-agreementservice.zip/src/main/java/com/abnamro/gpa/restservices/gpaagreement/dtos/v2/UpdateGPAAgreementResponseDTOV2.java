package com.abnamro.gpa.restservices.gpaagreement.dtos.v2;


import lombok.Data;

/**
 * This class is designed for API-v2
 *
 * @author C45158
 */
@Data
public class UpdateGPAAgreementResponseDTOV2 {

    private static final long serialVersionUID = 1L;

    private String agreementId;

}
