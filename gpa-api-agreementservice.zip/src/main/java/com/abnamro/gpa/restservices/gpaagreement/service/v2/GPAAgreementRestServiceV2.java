package com.abnamro.gpa.restservices.gpaagreement.service.v2;


import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementLogConstants;
import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.UpdateGPAAgreementRequestDTO;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementRequestDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.CreateGPAAgreementResponseDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.dtos.v2.ReadGPAAgreementResponseDTOV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementWebAppException;
import com.abnamro.gpa.restservices.gpaagreement.requestprocessor.v2.GPAAgreementRequestProcessorV2;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


/**
 * This is the controller for GPAAgreement service API-v2.
 */
@RestController
@RequestMapping("/v2")
@Slf4j
@AllArgsConstructor
public class GPAAgreementRestServiceV2 {

  private final GPAAgreementRestServiceHelperV2 gpaAgreementRestServiceHelperV2;

  private final GPAAgreementRequestProcessorV2 gpaAgreementRequestProcessorV2;


  /**
   * This method is used to create gpa agreements
   *
   * @param consumerId             is consumerId
   * @param traceId                is traceId
   * @param createAgreementRequest is input DTO
   * @return ResponseEntity<CreateGPAAgreementResponseDTOV2> is DTO
   * @throws GPAAgreementWebAppException is an exception
   */
  @PostMapping(value = "", produces = "application/json")
  public ResponseEntity<CreateGPAAgreementResponseDTOV2> createAgreement(
      @RequestHeader("Consumer-Id") String consumerId,
      @RequestHeader("Trace-Id") String traceId,
      @RequestBody CreateGPAAgreementRequestDTOV2 createAgreementRequest) throws GPAAgreementWebAppException {

    final String LOG_METHOD = "createAgreement():response:: ";

    CreateGPAAgreementResponseDTOV2 response = null;
    try {

      gpaAgreementRestServiceHelperV2.isInvalidGenericDetails(consumerId, traceId, createAgreementRequest);
      String agreementId = gpaAgreementRequestProcessorV2.createGPAAgreement(createAgreementRequest, consumerId,
          traceId);
      response = new CreateGPAAgreementResponseDTOV2();
      response.setAgreementId(agreementId);

    } catch (GPAAdministrationDAOException gpaAdministrationDAOException) {
      log.error("{} errorCode={} | exception={}", LOG_METHOD,
          GPAAgreementLogConstants.LOG_EXCEPTION_IN_DAO_READ_ADMINISTRATION, gpaAdministrationDAOException);
      gpaAgreementRestServiceHelperV2.handleTechnicalError(GPAAgreementConstantsV2.CODE_TECHNICAL_ERROR,
          GPAAgreementConstantsV2.DESC_TECHNICAL_ERROR,
          gpaAdministrationDAOException, traceId);
    } catch (GPAAgreementApplicationException gpaAgreementApplicationException) {
      log.error("{} errorCode={} | exception={}", LOG_METHOD,
          GPAAgreementLogConstants.LOG_EXCEPTION_IN_CREATE_AGREEMENT, gpaAgreementApplicationException);
      gpaAgreementRestServiceHelperV2.handleTechnicalError(GPAAgreementConstantsV2.CODE_TECHNICAL_ERROR,
          GPAAgreementConstantsV2.DESC_TECHNICAL_ERROR,
          gpaAgreementApplicationException, traceId);
    } catch (GPAAgreementDAOException gpaAgreementDAOException) {
      log.error("{} errorCode={} | exception={}", LOG_METHOD,
          GPAAgreementLogConstants.LOG_EXCEPTION_IN_DAO_CREATE_AGREEMENT, gpaAgreementDAOException);
      gpaAgreementRestServiceHelperV2.handleTechnicalError(GPAAgreementConstantsV2.CODE_TECHNICAL_ERROR,
          GPAAgreementConstantsV2.DESC_TECHNICAL_ERROR,
          gpaAgreementDAOException, traceId);
    } catch (GPAAgreementValidatorException gpaAGreementValidatorException) {
      log.error("{} errorCode={} | exception={}", LOG_METHOD,
          GPAAgreementLogConstants.LOG_EXCEPTION_IN_AGREEMENT_VALIDATOR_CREATE_AGREEMENT,
          gpaAGreementValidatorException);
      gpaAgreementRestServiceHelperV2.handleTechnicalError(GPAAgreementConstantsV2.CODE_TECHNICAL_ERROR,
          GPAAgreementConstantsV2.DESC_TECHNICAL_ERROR,
          gpaAGreementValidatorException, traceId);
    }

    return new ResponseEntity<>(response, HttpStatus.CREATED);

  }

  /**
   * This operation is used to retrieve existing gpa agreements
   *
   * @param consumerId  is consumerId of calling application
   * @param traceId     is traceId
   * @param agreementId in CIN format
   * @return ResponseEntity<ReadGPAAgreementResponseDTOV2> containing agreement details
   * @throws GPAAgreementWebAppException is an exception
   */
  @GetMapping(value = "/{agreementId}", produces = "application/json")
  public ResponseEntity<ReadGPAAgreementResponseDTOV2> getGPAAgreement(@RequestHeader("Consumer-Id") String consumerId,
      @RequestHeader("Trace-Id") String traceId,
      @PathVariable("agreementId") String agreementId) throws GPAAgreementWebAppException {

    ReadGPAAgreementResponseDTOV2 response = null;

    if (StringUtils.isBlank(consumerId)) {
      gpaAgreementRestServiceHelperV2.handleValidationError(GPAAgreementConstantsV2.CODE_CONSUMER_ID_MANDATORY,
          GPAAgreementConstantsV2.DESC_CONSUMER_ID_MANDATORY,
          null,
          false, traceId);
    } else if (gpaAgreementRestServiceHelperV2.isInvalidFormatConsumerID(consumerId)) {
      gpaAgreementRestServiceHelperV2.handleValidationError(GPAAgreementConstantsV2.CODE_CONSUMER_ID_FORMAT_INVALID,
          GPAAgreementConstantsV2.DESC_CONSUMER_ID_FORMAT_INVALID,
          null,
          false, traceId);
    } else if (gpaAgreementRestServiceHelperV2.isInvalidAgreementIdForRead(agreementId)) {
      //throw an exception if agreement id is invalid
      gpaAgreementRestServiceHelperV2.handleValidationError(GPAAgreementConstantsV2.CODE_AGREEMENT_ID_INVALID,
          GPAAgreementConstantsV2.DESC_AGREEMENT_ID_INVALID,
          null,
          false, traceId);
    } else {
      //call request processor if format is valid
      response = gpaAgreementRequestProcessorV2.readGPAAgreement(agreementId, consumerId, traceId);
    }
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  /**
   * This operation is used to update existing gpa agreements
   *
   * @param consumerId             is String
   * @param traceId                is TraceId
   * @param agreementId            is agreementId
   * @param updateAgreementRequest is UpdateGPAAgreementRequestDTO
   * @return ResponseEntity<Void> with No Content
   * @throws GPAAgreementWebAppException is an exception
   */
  @PutMapping(value = "/{agreementId}", produces = "application/json")
  public ResponseEntity<Void> updateGPAAgreement(@RequestHeader("Consumer-Id") String consumerId,
      @RequestHeader("Trace-Id") String traceId,
      @PathVariable("agreementId") String agreementId,
      @RequestBody UpdateGPAAgreementRequestDTO updateAgreementRequest) throws GPAAgreementWebAppException {

    final String LOG_METHOD = "updateAgreement():response:: ";
    try {

      gpaAgreementRestServiceHelperV2.isInvalidGenericDetailsForUpdate(consumerId, traceId,
          updateAgreementRequest, agreementId);

      gpaAgreementRequestProcessorV2.updateGPAAgreement(updateAgreementRequest, agreementId, consumerId,
          traceId);

    } catch (GPAAgreementValidatorException gpaAGreementValidatorException) {
      log.error("{} errorCode={} | exception={}", LOG_METHOD,
          GPAAgreementLogConstants.LOG_EXCEPTION_IN_AGREEMENT_VALIDATOR_UPDATE_AGREEMENT,
          gpaAGreementValidatorException);
      gpaAgreementRestServiceHelperV2.handleTechnicalError(GPAAgreementConstantsV2.CODE_TECHNICAL_ERROR,
          GPAAgreementConstantsV2.DESC_TECHNICAL_ERROR,
          gpaAGreementValidatorException, traceId);
    } catch (GPAAdministrationDAOException e) {
      log.error("{} errorCode={} | exception={}", LOG_METHOD,
          GPAAgreementLogConstants.LOG_EXCEPTION_IN_DAO_READ_ADMINISTRATION, e);
      gpaAgreementRestServiceHelperV2.handleTechnicalError(GPAAgreementConstantsV2.CODE_TECHNICAL_ERROR,
          GPAAgreementConstantsV2.DESC_TECHNICAL_ERROR, e, traceId);
    }
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }
}
