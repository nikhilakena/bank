/**
 * 
 */
package com.abnamro.gpa.restservices.gpaagreement.requestprocessor;



import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.generic.gpaagreementvalidator.GPAAgreementValidator;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementConstants;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementLogConstants;
import com.abnamro.gpa.restservices.gpaagreement.dao.GPAAuthorizationDAO;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.service.GPAAgreementRestServiceHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * @author C45158
 *
 */
@Component
public class GPAAgreementRequestValidator {
	private static final Logger logger = LoggerFactory.getLogger(GPAAgreementRequestValidator.class);


	
	private GPAAuthorizationDAO gpaAuthorizationDAO;
	private GPAAgreementRestServiceHelper gpaAgreementRestServiceHelper ;


	private GPAAgreementValidator gpaAgreementValidator;

	private GPAAdministrationDAO administrationdao ;

	@Autowired
	public GPAAgreementRequestValidator(GPAAuthorizationDAO gpaAuthorizationDAO, GPAAgreementRestServiceHelper gpaAgreementRestServiceHelper, GPAAgreementValidator gpaAgreementValidator, GPAAdministrationDAO administrationdao) {
		this.gpaAuthorizationDAO = gpaAuthorizationDAO;
		this.gpaAgreementRestServiceHelper = gpaAgreementRestServiceHelper;
		this.gpaAgreementValidator = gpaAgreementValidator;
		this.administrationdao = administrationdao;
	}


	/**
	 * this method is used to check authorized user
	 * @param adminId is administration Id
	 * @param consumerId is String
	 * @param version is services- version
	 * @param traceId is String
	 * @param operation is String
	 * @return isAuthorized as boolean value
	 */
	public boolean isAuthorizedConsumerForAdmin(int adminId, String consumerId, String traceId, String operation, String version)  {
		boolean isAuthorized=false;
		final String LOG_METHOD = "isUserAuthorized():response";
		
		try {
			isAuthorized=gpaAuthorizationDAO.isAuthorizedConsumerForAdmin(adminId, consumerId, operation, version);
		} catch (GPAAgreementApplicationException e) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_DAO_EXCEPTION_IN_ISUSERAUTHORIZED_REQUEST_VALIDATOR, e);
			gpaAgreementRestServiceHelper.handleUnAuthorizedError(GPAAgreementConstants.RESPONSE_STATUS_500, 
					GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					null,
					false,traceId);
		}
		
		return isAuthorized;
	}
	
	/**
	 * this method is used to check authorized user
	 * @param productId is product Id
	 * @param consumerId is String
	 * @param version is services- version
	 * @param traceId is String
	 * @param operation is String
	 */
	public void isUserAuthorizedForProduct(int productId, String consumerId, String traceId, String operation, String version)  {
		boolean isAuthorized=false;
		final String LOG_METHOD = "isUserAuthorized():response";
		
		try {
			isAuthorized=gpaAuthorizationDAO.isAuthorizedConsumerForProduct(productId, consumerId, operation, version);
			
			if(!isAuthorized){
				gpaAgreementRestServiceHelper.handleUnAuthorizedError(GPAAgreementConstants.CODE_CONSUMER_UNAUTHORIZED, 
						GPAAgreementConstants.DESC_CONSUMER_UNAUTHORIZED,
						null,
						false,traceId);
			}
		} catch (GPAAgreementApplicationException e) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_DAO_EXCEPTION_IN_ISUSERAUTHORIZED_REQUEST_VALIDATOR, e);
			gpaAgreementRestServiceHelper.handleUnAuthorizedError(GPAAgreementConstants.RESPONSE_STATUS_500, 
					GPAAgreementConstants.CODE_TECHNICAL_ERROR,
					null,
					false,traceId);
		}
		
	}
	
	
	/**
	 * 
	 * This method is used to validate create agreement request
	 * @param generalProductAgreement is GeneralProductAgreement
	 * @param consumerId is String
	 * @param traceId is String
	 * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
	 * @throws GPAAgreementValidatorException is an exception
	 * @throws GPAAdministrationDAOException is an exception
	 * @throws GPAAgreementApplicationException is an exception
	 * @throws GPAAgreementDAOException is an exception
	 */
	public AgreementValidatorResultDTO validateCreateAgreementRequest(GeneralProductAgreement generalProductAgreement, String consumerId, String traceId) throws GPAAgreementValidatorException, GPAAdministrationDAOException, GPAAgreementApplicationException, GPAAgreementDAOException{
		
		final String LOG_METHOD = "validateCreateAgreementRequest():response";
		
		AdministrationView administrationView=null;
		AgreementValidatorResultDTO agreementValidatorResultDTO=null;
		boolean userAuthorized=false;
		
		try {
			if(generalProductAgreement!=null){
				administrationView=readAdministration(generalProductAgreement);
			}
			if(administrationView !=null && administrationView.getId()>0){
				userAuthorized=isAuthorizedConsumerForAdmin(administrationView.getId(), consumerId, traceId, GPAAgreementConstants.OPERATION_NAME_CREATE, GPAAgreementConstants.VERSION_CREATE);
				
				if(userAuthorized){
					agreementValidatorResultDTO=gpaAgreementValidator.validateAgreement(generalProductAgreement);
					
				}else{
					gpaAgreementRestServiceHelper.handleUnAuthorizedError(GPAAgreementConstants.CODE_CONSUMER_UNAUTHORIZED, 
							GPAAgreementConstants.DESC_CONSUMER_UNAUTHORIZED,
							null,
							false,traceId);
				}
			}else{
				gpaAgreementRestServiceHelper.handleValidationError(GPAAgreementConstants.CODE_PRODUCT_ID_NOT_REGISTERED, 
						GPAAgreementConstants.DESC_PRODUCT_ID_NOT_REGISTERED,
						null,
						false,traceId);
			}
			
			
			
		}catch (GPAAgreementDAOException gpaAdministrationDAOException) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_DAO_EXCEPTION_IN_READ_ADMIN_REQUEST_VALIDATOR, gpaAdministrationDAOException);
			throw new GPAAgreementDAOException(gpaAdministrationDAOException);
		}
		
		
		return agreementValidatorResultDTO;
		
	}
	
	/**
	 * This method is used to call read administration data
	 * @param generalProductAgreement is GeneralProductAgreement
	 * @return  administrationView is AdministrationView
	 * @throws GPAAgreementDAOException is an exception
	 */
	public AdministrationView readAdministration(GeneralProductAgreement generalProductAgreement) throws GPAAgreementDAOException{
		final String LOG_METHOD = "readAdministration():response";
		
		AdministrationView administrationView=null;
		try {
			administrationView = administrationdao.readAdministration(0, Integer.parseInt(generalProductAgreement.getProductId()));
		} catch (GPAAdministrationDAOException gpaAdministrationDAOException) {
			logger.error(LOG_METHOD, GPAAgreementLogConstants.LOG_DAO_EXCEPTION_IN_READ_ADMIN_REQUEST_VALIDATOR, gpaAdministrationDAOException);
			throw new GPAAgreementDAOException(gpaAdministrationDAOException);
		}
		return administrationView;
		
	}

	/**
	 * This method is used to validate update agreement request data
	 * @param generalProductAgreement is GeneralProductAgreement
	 * @param consumerId i String
	 * @param traceId is String
	 * @return  agreementValidatorResultDTO is AgreementValidatorResultDTO
	 * @throws GPAAgreementValidatorException is an exception
	 */
	public AgreementValidatorResultDTO validateUpdateAgreementRequest(GeneralProductAgreement generalProductAgreement,
			String consumerId, String traceId) throws GPAAgreementValidatorException {

		AgreementValidatorResultDTO agreementValidatorResultDTO = null;

		isUserAuthorizedForProduct(Integer.valueOf(generalProductAgreement.getProductId()), consumerId, traceId,
				GPAAgreementConstants.OPERATION_NAME_UPDATE, GPAAgreementConstants.VERSION_UPDATE);

		agreementValidatorResultDTO = gpaAgreementValidator.validateAgreement(generalProductAgreement);

		return agreementValidatorResultDTO;
	}
	

}
