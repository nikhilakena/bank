package com.abnamro.gpa.restservices.gpaagreement.exceptionhandler;

import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.APIConnectorException;
import com.abnamro.gpa.restservices.gpaagreement.constants.v2.GPAAgreementConstantsV2;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Error;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.Errors;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementWebAppException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.List;

@ControllerAdvice
@Slf4j
public class AgreementServiceResponseHandler  {

    @ExceptionHandler(GPAAgreementApplicationException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public @ResponseBody
    Errors handleApplicationException(
            GPAAgreementApplicationException gpaAgreementApplicationException) {


        Errors errors = new Errors();
        ArrayList<Error> errorMessageList = new ArrayList<>();
        Error error = new Error();
        error.setCode("500");
        error.setMessage(gpaAgreementApplicationException.getMessage());
        error.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
        errorMessageList.add(error);
        errors.setErrors(errorMessageList);
        return errors;

    }
    @ExceptionHandler(APIConnectorException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public @ResponseBody
    Errors handleAPIConnectorException(
            APIConnectorException apiConnectorException) {


        Errors errors = new Errors();
        ArrayList<Error> errorMessageList = new ArrayList<>();
        Error error = new Error();
        error.setCode("500");
        error.setMessage(apiConnectorException.getMessage());
        error.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
        errorMessageList.add(error);
        errors.setErrors(errorMessageList);
        return errors;

    }

    @ExceptionHandler({GPAAgreementWebAppException.class})
    public ResponseEntity handleWebAppException(GPAAgreementWebAppException exception) {
        log.error("Error in  :: RestEntityResponseExceptionHandler :  handleWebAppException() : ", exception);

        if(null!=exception.getResponse()) {
            log.info("Error in  :: RestEntityResponseExceptionHandler :  handleWebAppException()response : "+ exception.getResponse());

            return ResponseEntity.status(exception.getStatus())
                    .contentType(MediaType.valueOf(GPAAgreementConstantsV2.MEDIA_TYPE)).body(exception.getResponse());

        }    else {
            log.info("Error in  :: RestEntityResponseExceptionHandler :  handleWebAppException()error : "+ exception.getError());
            log.info("Error in  :: RestEntityResponseExceptionHandler :  handleWebAppException()error : "+ ResponseEntity.status(exception.getStatus())
                    .contentType(MediaType.valueOf(GPAAgreementConstantsV2.MEDIA_TYPE)).body(exception.getError().getErrors().get(0).getStatus()));

            return ResponseEntity.status(exception.getStatus())
                    .contentType(MediaType.valueOf(GPAAgreementConstantsV2.MEDIA_TYPE)).body(exception.getError());
        }

    }
}
