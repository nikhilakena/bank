package com.abnamro.gpa.restservices.gpaagreement.dtos;



/**
 * @author C45158
 *
 */
public class UpdateGPAAgreementResponseDTO  {
	
	private static final long serialVersionUID = 1L;
	
	private String agreementId;

	public String getAgreementId() {
		return agreementId;
	}

	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}
	
	
}
