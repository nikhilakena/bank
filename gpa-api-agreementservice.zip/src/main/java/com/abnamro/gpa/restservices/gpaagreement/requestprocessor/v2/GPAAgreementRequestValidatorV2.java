package com.abnamro.gpa.restservices.gpaagreement.requestprocessor.v2;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.generic.gpaagreementvalidator.v2.GPAAgreementValidatorV2;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementConstants;
import com.abnamro.gpa.restservices.gpaagreement.constants.GPAAgreementLogConstants;
import com.abnamro.gpa.restservices.gpaagreement.dao.GPAAuthorizationDAO;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementApplicationException;
import com.abnamro.gpa.restservices.gpaagreement.exceptions.GPAAgreementWebAppException;
import com.abnamro.gpa.restservices.gpaagreement.service.v2.GPAAgreementRestServiceHelperV2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * @author C45158
 */
@Component
@Slf4j
public class GPAAgreementRequestValidatorV2 {


  private GPAAgreementRestServiceHelperV2 gpaAgreementRestServiceHelperV2;

  private GPAAgreementValidatorV2 gpaAgreementValidatorV2;

  private GPAAdministrationDAO administrationdao;

  private AdministrationView administrationView;

  private AgreementValidatorResultDTO agreementValidatorResultDTO;

  private GPAAuthorizationDAO gpaAuthorizationDAO;


  @Autowired
  public GPAAgreementRequestValidatorV2(final GPAAdministrationDAO administrationdao,
      final GPAAgreementValidatorV2 gpaAgreementValidatorV2, final GPAAuthorizationDAO gpaAuthorizationDAO) {

    this.administrationdao = administrationdao;
    this.gpaAgreementValidatorV2 = gpaAgreementValidatorV2;
    this.gpaAuthorizationDAO = gpaAuthorizationDAO;
  }

  /**
   * This method is used to validate create agreement request
   *
   * @param generalProductAgreement is GeneralProductAgreement
   * @param consumerId              is String
   * @param traceId                 is String
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   * @throws GPAAgreementValidatorException   is an exception
   * @throws GPAAdministrationDAOException    is an exception
   * @throws GPAAgreementApplicationException is an exception
   * @throws GPAAgreementDAOException         is an exception
   */
  public AgreementValidatorResultDTO validateCreateAgreementRequest(GeneralProductAgreement generalProductAgreement,
      String consumerId, String traceId) throws GPAAgreementValidatorException, GPAAdministrationDAOException,
      GPAAgreementApplicationException, GPAAgreementDAOException, GPAAgreementWebAppException {

    final String LOG_METHOD = "validateCreateAgreementRequest():response:: ";
    boolean userAuthorized = false;

    try {
      if (generalProductAgreement != null) {
        administrationView = readAdministration(generalProductAgreement);
        log.info(
            "{} administrationView_id={} | consumerId={} | traceId={} | OPERATION_NAME_CREATE={} | VERSION_V2_CREATE={}",
            LOG_METHOD, administrationView.getId(), consumerId, traceId, GPAAgreementConstants.OPERATION_NAME_CREATE,
            GPAAgreementConstants.VERSION_V2_CREATE);

      }
      if (administrationView != null && administrationView.getId() > 0) {
        userAuthorized = isAuthorizedConsumerForAdmin(administrationView.getId(), consumerId, traceId,
            GPAAgreementConstants.OPERATION_NAME_CREATE, GPAAgreementConstants.VERSION_V2_CREATE);
        log.info("{} userAuthorized={}", LOG_METHOD, userAuthorized);
        if (userAuthorized) {
          agreementValidatorResultDTO = gpaAgreementValidatorV2.validateAgreement(generalProductAgreement);

        } else {
          gpaAgreementRestServiceHelperV2.handleUnAuthorizedError(GPAAgreementConstants.CODE_CONSUMER_UNAUTHORIZED,
              GPAAgreementConstants.DESC_CONSUMER_UNAUTHORIZED,
              null,
              false, traceId);
        }


      } else {
        gpaAgreementRestServiceHelperV2.handleValidationError(
            GPAAgreementConstants.CODE_PRODUCT_ID_NOT_REGISTERED,
            GPAAgreementConstants.DESC_PRODUCT_ID_NOT_REGISTERED, null, false, traceId);
      }

    } catch (GPAAgreementDAOException gpaAdministrationDAOException) {
      log.error("{} errorCode={} | exception={}", LOG_METHOD,
          GPAAgreementLogConstants.LOG_DAO_EXCEPTION_IN_READ_ADMIN_REQUEST_VALIDATOR,
          gpaAdministrationDAOException);
      throw new GPAAgreementDAOException(gpaAdministrationDAOException);
    }

    return agreementValidatorResultDTO;

  }

  /**
   * This method is used to call read administration data
   *
   * @param generalProductAgreement is GeneralProductAgreement
   * @return administrationView is AdministrationView
   * @throws GPAAgreementDAOException is an exception
   */
  public AdministrationView readAdministration(GeneralProductAgreement generalProductAgreement)
      throws GPAAgreementDAOException {
    final String LOG_METHOD = "readAdministration():response:: ";

    try {
      administrationView = administrationdao.readAdministration(0,
          Integer.parseInt(generalProductAgreement.getProductId()));
      log.info("{} administrationView_id={} ", LOG_METHOD, administrationView.getId());
    } catch (GPAAdministrationDAOException gpaAdministrationDAOException) {
      log.error("{} errorCode={} | exception={}", LOG_METHOD,
          GPAAgreementLogConstants.LOG_DAO_EXCEPTION_IN_READ_ADMIN_REQUEST_VALIDATOR,
          gpaAdministrationDAOException);
      throw new GPAAgreementDAOException(gpaAdministrationDAOException);
    }
    return administrationView;

  }

  /**
   * This method is used to validate update agreement request data
   *
   * @param generalProductAgreement is GeneralProductAgreement
   * @param consumerId              i String
   * @param traceId                 is String
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   * @throws GPAAgreementValidatorException is an exception
   */
  public AgreementValidatorResultDTO validateUpdateAgreementRequest(GeneralProductAgreement generalProductAgreement,
      String consumerId, String traceId) throws GPAAgreementValidatorException, GPAAgreementWebAppException {

    isUserAuthorizedForProduct(Integer.valueOf(generalProductAgreement.getProductId()), consumerId, traceId,
        GPAAgreementConstants.OPERATION_NAME_UPDATE, GPAAgreementConstants.VERSION_V2_UPDATE);

    agreementValidatorResultDTO = gpaAgreementValidatorV2.validateAgreement(generalProductAgreement);

    return agreementValidatorResultDTO;
  }

  /**
   * this method is used to check authorized user
   *
   * @param adminId    is administration Id
   * @param consumerId is String
   * @param version    is services- version
   * @param traceId    is String
   * @param operation  is String
   * @return isAuthorized as boolean value
   */
  public boolean isAuthorizedConsumerForAdmin(int adminId, String consumerId, String traceId, String operation,
      String version) throws GPAAgreementWebAppException {
    boolean isAuthorized = false;
    final String LOG_METHOD = "isUserAuthorized():response:: ";

    try {
      isAuthorized = gpaAuthorizationDAO.isAuthorizedConsumerForAdmin(adminId, consumerId, operation, version);
    } catch (GPAAgreementApplicationException e) {
      log.error("{} errorCode={} | exception={}  ", LOG_METHOD,
          GPAAgreementLogConstants.LOG_DAO_EXCEPTION_IN_ISUSERAUTHORIZED_REQUEST_VALIDATOR, e);
      gpaAgreementRestServiceHelperV2.handleUnAuthorizedError(GPAAgreementConstants.RESPONSE_STATUS_500,
          GPAAgreementConstants.CODE_TECHNICAL_ERROR,
          null,
          false, traceId);
    }

    return isAuthorized;
  }

  /**
   * this method is used to check authorized user
   *
   * @param productId  is product Id
   * @param consumerId is String
   * @param version    is services- version
   * @param traceId    is String
   * @param operation  is String
   */
  public void isUserAuthorizedForProduct(int productId, String consumerId, String traceId, String operation,
      String version) throws GPAAgreementWebAppException {
    boolean isAuthorized = false;
    final String LOG_METHOD = "isUserAuthorized():response:: ";

    try {
      isAuthorized = gpaAuthorizationDAO.isAuthorizedConsumerForProduct(productId, consumerId, operation, version);
      log.info("{} isAuthorized={} ", LOG_METHOD, isAuthorized);
      if (!isAuthorized) {
        log.info("{} not isAuthorized ", LOG_METHOD);
        gpaAgreementRestServiceHelperV2.handleUnAuthorizedError(GPAAgreementConstants.CODE_CONSUMER_UNAUTHORIZED,
            GPAAgreementConstants.DESC_CONSUMER_UNAUTHORIZED,
            null,
            false, traceId);
      }
    } catch (GPAAgreementApplicationException e) {
      log.error("{} errorCode={} | exception={}  ", LOG_METHOD,
          GPAAgreementLogConstants.LOG_DAO_EXCEPTION_IN_ISUSERAUTHORIZED_REQUEST_VALIDATOR, e);
      gpaAgreementRestServiceHelperV2.handleUnAuthorizedError(GPAAgreementConstants.RESPONSE_STATUS_500,
          GPAAgreementConstants.CODE_TECHNICAL_ERROR,
          null,
          false, traceId);
    }

  }


}
