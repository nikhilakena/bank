package com.abnamro.gpa.restservices.gpaagreement.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author C45158
 * This class is the mapper class for GPAAgreementsDB2DAO with the database
 */
@Mapper
public interface GPAAgreementMybatisMapper {

	
	/**
	 * This method retrieve count of the entries for input consumerId, operation and version.
	 * @param schemaName String value for schemaName of database
	 * @param consumerId unique value for consumer application calling the API
	 * @param adminId unique value 
	 * @param operation name of the operation
	 * @param version of the operation
	 * @return boolean value to check if user is authorized or not.
	 */
	public int isAuthorizedConsumerForAdmin(@Param("consumerId") final String consumerId,
		@Param("adminId") final int adminId, @Param("operation") final  String operation, @Param("version") final  String version);

	/**
	 * This method updates last date used
	 * 
	 * @param schemaName String value for schemaName of database
	 * @param consumerId unique value for consumer application calling the API
	 * @param operation name of the operation
	 * @param version of the operation
	 */
	public void updateLastDateUsedForAdmin(@Param("consumerId") final String consumerId,
		@Param("operation") final  String operation, @Param("version") final  String version);
	
	
	/**
	 * This method retrieve count of the entries for input consumerId, operation and version.
	 * @param dbSchemaPrefix String value for schemaName of database
	 * @param consumerId unique value for consumer application calling the API
	 * @param productId unique product Id 
	 * @param operation name of the operation
	 * @param version of the operation
	 * @return boolean value to check if user is authorized or not.
	 */
	public int isAuthorizedConsumerForProduct( @Param("consumerId") String consumerId, @Param("productId") int productId,
			@Param("operation") String operation, @Param("version") String version);
	
	
	/**
	 * This method updates last date used
	 * 
	 * @param dbSchemaPrefix String value for schemaName of database
	 * @param productId unique product Id 
	 * @param consumerId unique value for consumer application calling the API
	 * @param operation name of the operation
	 * @param version of the operation
	 */
	public void updateLastDateUsedForProduct( @Param("productId") int productId, @Param("consumerId") String consumerId,
			@Param("operation") String operation, @Param("version") String version);


	
}
