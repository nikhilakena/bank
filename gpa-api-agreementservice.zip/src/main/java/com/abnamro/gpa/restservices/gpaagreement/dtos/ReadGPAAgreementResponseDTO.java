/**
 * 
 */
package com.abnamro.gpa.restservices.gpaagreement.dtos;

import java.util.List;

import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author C45158
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_DEFAULT)	
public class ReadGPAAgreementResponseDTO {
	
	
	private String productId;
	private String customerId;
	private String agreementStartDateTime;
	private String agreementEndDateTime;
	private String createdBy;
	private String createdDateTime;
	private String modifiedBy;
	private String modifiedDateTime;
	private AgreementLifeCycleStatusType agreementLifeCycleStatusType; 
	private List<TermResponseDTO> attributes;
	
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	/**
	 * @return agreement Start Date Time
	 */
	public String getAgreementStartDateTime() {
		return agreementStartDateTime;
	}
	/**
	 * @param agreementStartDateTime agreement Start Date Time
	 */
	public void setAgreementStartDateTime(String agreementStartDateTime) {
		this.agreementStartDateTime = agreementStartDateTime;
	}
	/**
	 * @return agreement End Date Time
	 */
	public String getAgreementEndDateTime() {
		return agreementEndDateTime;
	}
	/**
	 * @param agreementEndDateTime agreement End Date Time
	 */
	public void setAgreementEndDateTime(String agreementEndDateTime) {
		this.agreementEndDateTime = agreementEndDateTime;
	}
	
	/**
	 * @return the agreementLifeCycleStatusType
	 */
	public AgreementLifeCycleStatusType getAgreementLifeCycleStatusType() {
		return agreementLifeCycleStatusType;
	}
	/**
	 * @param agreementLifeCycleStatusType the agreementLifeCycleStatusType to set
	 */
	public void setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType agreementLifeCycleStatusType) {
		this.agreementLifeCycleStatusType = agreementLifeCycleStatusType;
	}
	/**
	 * @return product attributes
	 */
	public List<TermResponseDTO> getAttributes() {
		return attributes;
	}
	/**
	 * @param attributes of the product
	 */
	public void setAttributes(List<TermResponseDTO> attributes) {
		this.attributes = attributes;
	}
	
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return Created Date Time
	 */
	public String getCreatedDateTime() {
		return createdDateTime;
	}
	/**
	 * @param createdDateTime Created Date Time
	 */
	public void setCreatedDateTime(String createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}
	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	/**
	 * @return Modified Date Time
	 */
	public String getModifiedDateTime() {
		return modifiedDateTime;
	}
	/**
	 * @param modifiedDateTime Modified Date Time
	 */
	public void setModifiedDateTime(String modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}
	
	

}
