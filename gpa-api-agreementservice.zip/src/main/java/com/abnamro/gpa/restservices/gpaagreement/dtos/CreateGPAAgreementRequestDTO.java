package com.abnamro.gpa.restservices.gpaagreement.dtos;


import java.util.List;


import com.abnamro.gpa.restresource.agreement.Term;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author C45158
 */


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_DEFAULT)	
public class CreateGPAAgreementRequestDTO{
	
	/**
	 * serialization applied
	 */
	private static final long serialVersionUID = 1L;
	
	private String agreementId;
	private String productId;
	private String customerId;
	private String agreementStartDateTime;
	private String agreementEndDateTime;
	private String agreementLifeCycleStatusType;
	private String userId;
	private List<Term> attributes;
	/**
	 * @return the agreementId
	 */
	public String getAgreementId() {
		return agreementId;
	}
	/**
	 * @param agreementId the agreementId to set
	 */
	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return the agreementStartDateTime
	 */
	public String getAgreementStartDateTime() {
		return agreementStartDateTime;
	}
	/**
	 * @param agreementStartDateTime the agreementStartDateTime to set
	 */
	public void setAgreementStartDateTime(String agreementStartDateTime) {
		this.agreementStartDateTime = agreementStartDateTime;
	}
	/**
	 * @return the agreementEndDateTime
	 */
	public String getAgreementEndDateTime() {
		return agreementEndDateTime;
	}
	/**
	 * @param agreementEndDateTime the agreementEndDateTime to set
	 */
	public void setAgreementEndDateTime(String agreementEndDateTime) {
		this.agreementEndDateTime = agreementEndDateTime;
	}
	/**
	 * @return the agreementLifeCycleStatusType
	 */
	public String getAgreementLifeCycleStatusType() {
		return agreementLifeCycleStatusType;
	}
	/**
	 * @param agreementLifeCycleStatusType the agreementLifeCycleStatusType to set
	 */
	public void setAgreementLifeCycleStatusType(String agreementLifeCycleStatusType) {
		this.agreementLifeCycleStatusType = agreementLifeCycleStatusType;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the attributes
	 */
	public List<Term> getAttributes() {
		return attributes;
	}
	/**
	 * @param attributes the attributes to set
	 */
	public void setAttributes(List<Term> attributes) {
		this.attributes = attributes;
	}
	
	
	
}
