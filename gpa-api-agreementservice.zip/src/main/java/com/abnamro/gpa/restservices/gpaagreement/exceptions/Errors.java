package com.abnamro.gpa.restservices.gpaagreement.exceptions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * @author C45158
 * This class contains an array of error messages 
 */
public class Errors implements Serializable {
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void setErrors(List<Error> errors) {
		this.errors = errors;
	}

	/**
	 * List of error messages
	 */
	private List<Error> errors;
	
	  public List<Error> getErrors() {
	        if (errors == null) {
	        	errors = new ArrayList<>();
	        }
	        return this.errors;
	    }


}
