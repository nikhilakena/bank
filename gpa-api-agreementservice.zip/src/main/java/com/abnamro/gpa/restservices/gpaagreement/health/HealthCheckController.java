package com.abnamro.gpa.restservices.gpaagreement.health;

import static org.springframework.http.HttpStatus.OK;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * This servlet will be called by the load balancer to see whether the connections to is healthy.
 */

@RestController
public class HealthCheckController {

  /**
   * This used for serialization purpose
   */
  private static final long serialVersionUID = 1L;

  @GetMapping(path = "/healthcheck")
  @ResponseStatus(OK)
  protected boolean isHealthy() {
    return true;
  }

}

