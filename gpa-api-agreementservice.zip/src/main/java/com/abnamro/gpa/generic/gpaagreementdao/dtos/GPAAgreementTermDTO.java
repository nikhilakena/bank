/**
 * 
 */
package com.abnamro.gpa.generic.gpaagreementdao.dtos;

import java.io.Serializable;


/**
 * This DTO contains term attribute details of an agreement 
 * @author C45158
 *
 */
public class GPAAgreementTermDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String termName;
	
	private String termValue;

	/**
	 * @return the termName
	 */
	public String getTermName() {
		return termName;
	}

	/**
	 * @param termName the termName to set
	 */
	public void setTermName(String termName) {
		this.termName = termName;
	}

	/**
	 * @return the termValue
	 */
	public String getTermValue() {
		return termValue;
	}

	/**
	 * @param termValue the termValue to set
	 */
	public void setTermValue(String termValue) {
		this.termValue = termValue;
	}
	
	

}
