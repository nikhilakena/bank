package com.abnamro.gpa.generic.constant.v2;

/**
 * This class is created for API-V2
 *
 */
public class FacetValidatorConstantsV2 {
	
	public static final String FAILURE="failure";

	public static final String TERM_ID = " Attribute Id : ";

	public static final String TERM_NAME = "Attribute Name : ";

	public static final String INVALID_DATA_IN_TIME_DATATYPE_MSG = "Invalid input in Time facet type";
	
	
	public static final String INVALID_ENUMERATION_MSG = "List value for ";
	
	
	public static final String INVALID_LENGTH_MSG = "Length for ";
	
	
	public static final String INVALID_PATTERN_MSG = "Pattern for ";
	
	
	public static final String INVALID_MAXLENGTH_MSG = "Maximum length for ";
	
	
	public static final String INVALID_MINLENGTH_MSG = "Minimum length for ";
	
	public static final String INVALID_TOTALDIGITS_MSG = "Total digits for ";
	
	
	public static final String INVALID_FRACTIONS_MSG = "Fraction digits for ";

	public static final String INVALID_DECIMAL_VALUE_MSG = "Invalid input in decimal facet category";

	public static final String CODE_INVALID_FACET_VALUE = "ATTRIBUTE_VALUE_INVALID";
	
	public static final String INVALID_MSG = " is invalid";
	
	public static final String INVALID_MIN_MAX_INCLUSIVE_EXCLUSIVE_MSG = " for the defined range is invalid";


}
