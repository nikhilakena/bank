/**
 * This class performs validations based on the facet types & values defined for an administration.
 */
package com.abnamro.gpa.generic.gpaagreementvalidator.v2;

import com.abnamro.gpa.generic.constant.v2.FacetValidatorConstantsV2;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.glossary.TermFacetRestResource;
import com.abnamro.gpa.restresource.glossary.TermRestResource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is created for API-V2
 */
@Component
public class FacetValidatorV2 {


  /**
   * This method validates the term value received in the input agreement with the facets defined in database for the
   * specific administration. ENUMERATION, LENGTH, PATTERN, MAXLENGTH, MINLENGTH, MININCLUSIVE, MAXINCLUSIVE,
   * MINEXCLUSIVE, MAXEXCLUSIVE, TOTALDIGITS, FRACTIONS
   *
   * @param termDetails Details of Term Rest Resource
   * @param termValue   term value from input agreement
   * @return AgreementValidatorResultDTO DTO which indicates success or failure in validation
   */
  public AgreementValidatorResultDTO validateFacet(TermRestResource termDetails, String termValue) {
    AgreementValidatorResultDTO resultDTO = new AgreementValidatorResultDTO();
    resultDTO.setSuccessIndicator(true);
    AgreementValidatorResultDTO facetTypeValidatorResultDTO = validateFacetType(termDetails, termValue);
    if (null != facetTypeValidatorResultDTO && !facetTypeValidatorResultDTO.isSuccessIndicator()) {
      return facetTypeValidatorResultDTO;
    }
    return resultDTO;
  }


  /**
   * This method is used to validate the facet types
   *
   * @param termDetails is TermRestResource
   * @param termValue   is String
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   */
  private AgreementValidatorResultDTO validateFacetType(TermRestResource termDetails, String termValue) {

    AgreementValidatorResultDTO agreementValidatorResultDTO = null;

    if (termDetails != null && StringUtils.isNotEmpty(termValue) && termDetails.getFacets() != null) {
      for (TermFacetRestResource facet : termDetails.getFacets()) {

        agreementValidatorResultDTO = validateEachFacetType(facet, termValue, termDetails);
        if (null != agreementValidatorResultDTO && !agreementValidatorResultDTO.isSuccessIndicator()) {
          return agreementValidatorResultDTO;
        }
      }
    }
    return agreementValidatorResultDTO;
  }

  private boolean checkValidFacetTypeRange(TermFacetRestResource facet) {
    boolean flag = false;
    if (facet.getFacetType().equals(FacetTypes.MININCLUSIVE)
        || facet.getFacetType().equals(FacetTypes.MAXINCLUSIVE)
        || facet.getFacetType().equals(FacetTypes.MINEXCLUSIVE)
        || facet.getFacetType().equals(FacetTypes.MAXEXCLUSIVE)) {
      flag = true;

    }

    return flag;
  }

  private boolean checkValidSingleValue(TermFacetRestResource facet) {
    boolean flag = false;
    if (facet.getFacetType().equals(FacetTypes.MAXLENGTH)
        || facet.getFacetType().equals(FacetTypes.MINLENGTH)
        || facet.getFacetType().equals(FacetTypes.LENGTH)
        || facet.getFacetType().equals(FacetTypes.PATTERN)) {
      flag = true;

    }

    return flag;
  }

  private boolean checkValidSingleValueNumeric(TermFacetRestResource facet) {
    boolean flag = false;
    if (facet.getFacetType().equals(FacetTypes.FRACTIONS)
        || facet.getFacetType().equals(FacetTypes.TOTALDIGITS)) {
      flag = true;

    }

    return flag;
  }


  private AgreementValidatorResultDTO validateEachFacetType(TermFacetRestResource facet, String termValue,
      TermRestResource termDetails) {
    AgreementValidatorResultDTO agreementValidatorResultDTO = null;
    if (null != facet && null != facet.getFacetType()) {
      // checks if the facet type is range
      if (checkValidFacetTypeRange(facet)) {
        agreementValidatorResultDTO = validateRangeFacetCategoty(facet, termValue.trim(), termDetails);
      }
      // checks if the facet type is single value
      if (checkValidSingleValue(facet)) {
        agreementValidatorResultDTO = validateSingleValueFacetCategoty(facet, termValue.trim(), termDetails);
      }
      // checks if the facet type is single value of numeric data type
      if (checkValidSingleValueNumeric(facet)) {
        agreementValidatorResultDTO = validateSingleNumericValueFacetCategoty(facet, termValue.trim(), termDetails);
      }
      //checks if the facet is list
      if (facet.getFacetType().equals(FacetTypes.ENUMERATION)) {
        agreementValidatorResultDTO = validateListFacetCategory(facet, termValue.trim(), termDetails);
      }

    }
    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO checkDecimalPresence(AgreementValidatorResultDTO agreementValidatorResultDTO,
      TermRestResource termDetails) {
    agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
    agreementValidatorResultDTO
        .setMessage(FacetValidatorConstantsV2.INVALID_DECIMAL_VALUE_MSG + FacetValidatorConstantsV2.TERM_NAME
            + termDetails.getName() + FacetValidatorConstantsV2.INVALID_MSG);
    agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
    agreementValidatorResultDTO.setSuccessIndicator(false);
    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO checkFractionPresence(AgreementValidatorResultDTO agreementValidatorResultDTO,
      TermRestResource termDetails) {
    agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
    agreementValidatorResultDTO.setMessage(
        FacetValidatorConstantsV2.INVALID_FRACTIONS_MSG + FacetValidatorConstantsV2.TERM_NAME + termDetails.getName()
            + FacetValidatorConstantsV2.INVALID_MSG);
    agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
    agreementValidatorResultDTO.setSuccessIndicator(false);
    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO checkTotalDigitPresence(AgreementValidatorResultDTO agreementValidatorResultDTO,
      TermRestResource termDetails) {
    agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
    agreementValidatorResultDTO.setMessage(
        FacetValidatorConstantsV2.INVALID_TOTALDIGITS_MSG + FacetValidatorConstantsV2.TERM_NAME + termDetails.getName()
            + FacetValidatorConstantsV2.INVALID_MSG);
    agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
    agreementValidatorResultDTO.setSuccessIndicator(false);
    return agreementValidatorResultDTO;
  }


  /**
   * This method is used to validate the fraction and total digits in term value
   *
   * @param facet
   * @param termValue
   * @param termDetails
   * @return ggreementValidatorResultDTO
   */
  private AgreementValidatorResultDTO validateSingleNumericValueFacetCategoty(TermFacetRestResource facet,
      String termValue, TermRestResource termDetails) {

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    if (null != facet) {
      FacetTypes facetType = facet.getFacetType();
      String facetValue = facet.getFacetValue();
      // checks if the input value contains decimal or not
      if (StringUtils.isEmpty(termValue) || StringUtils.countMatches(termValue, ".") != 1) {
        agreementValidatorResultDTO = checkDecimalPresence(agreementValidatorResultDTO, termDetails);
      }
      String fractionValue[] = termValue.split("\\.");
      if (FacetTypes.FRACTIONS.equals(facetType)) {
        if (fractionValue[1].length() > Integer.parseInt(facetValue)) {
          agreementValidatorResultDTO = checkFractionPresence(agreementValidatorResultDTO, termDetails);
        }
      }
      if (FacetTypes.TOTALDIGITS.equals(facetType)) {
        if ((fractionValue[0].length() + fractionValue[1].length()) > Integer.parseInt(facetValue)) {
          agreementValidatorResultDTO = checkTotalDigitPresence(agreementValidatorResultDTO, termDetails);
        }
      }
    }
    return agreementValidatorResultDTO;
  }


  private AgreementValidatorResultDTO validateListFacetCategory(TermFacetRestResource facet, String termValue,
      TermRestResource termDetails) {

    AgreementValidatorResultDTO agreementValidatorResultDTO = null;

    if (null != facet) {
      String facetValue = facet.getFacetValue();
      if (null != facetValue && !facetValue.contains(termValue)) {
        agreementValidatorResultDTO = new AgreementValidatorResultDTO();
        agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
        agreementValidatorResultDTO
            .setMessage(FacetValidatorConstantsV2.INVALID_ENUMERATION_MSG + FacetValidatorConstantsV2.TERM_NAME
                + termDetails.getName() + FacetValidatorConstantsV2.INVALID_MSG);
        agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
        agreementValidatorResultDTO.setSuccessIndicator(false);
        return agreementValidatorResultDTO;
      }
    }
    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO singleValueLengthValidation(
      AgreementValidatorResultDTO agreementValidatorResultDTO, TermRestResource termDetails) {
    agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
    agreementValidatorResultDTO.setMessage(
        FacetValidatorConstantsV2.INVALID_LENGTH_MSG + FacetValidatorConstantsV2.TERM_NAME + termDetails.getName()
            + FacetValidatorConstantsV2.INVALID_MSG);
    agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
    agreementValidatorResultDTO.setSuccessIndicator(false);
    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO singleValueMinLengthValidation(
      AgreementValidatorResultDTO agreementValidatorResultDTO, TermRestResource termDetails) {
    agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
    agreementValidatorResultDTO.setMessage(
        FacetValidatorConstantsV2.INVALID_LENGTH_MSG + FacetValidatorConstantsV2.TERM_NAME + termDetails.getName()
            + FacetValidatorConstantsV2.INVALID_MSG);
    agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
    agreementValidatorResultDTO.setSuccessIndicator(false);
    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO singleValueMaxLengthValidation(
      AgreementValidatorResultDTO agreementValidatorResultDTO, TermRestResource termDetails) {
    agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
    agreementValidatorResultDTO.setMessage(
        FacetValidatorConstantsV2.INVALID_MAXLENGTH_MSG + FacetValidatorConstantsV2.TERM_NAME + termDetails.getName()
            + FacetValidatorConstantsV2.INVALID_MSG);
    agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
    agreementValidatorResultDTO.setSuccessIndicator(false);
    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO singleValuePatternValidation(
      AgreementValidatorResultDTO agreementValidatorResultDTO, TermRestResource termDetails) {
    agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
    agreementValidatorResultDTO.setMessage(
        FacetValidatorConstantsV2.INVALID_PATTERN_MSG + FacetValidatorConstantsV2.TERM_NAME + termDetails.getName()
            + FacetValidatorConstantsV2.INVALID_MSG);
    agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
    agreementValidatorResultDTO.setSuccessIndicator(false);
    return agreementValidatorResultDTO;
  }


  /**
   * This method is used to validate single value facet category
   *
   * @param facet
   * @param termValue
   * @param termDetails
   * @return agreementValidatorResultDTO
   */
  private AgreementValidatorResultDTO validateSingleValueFacetCategoty(TermFacetRestResource facet, String termValue,
      TermRestResource termDetails) {
    AgreementValidatorResultDTO agreementValidatorResultDTO = null;
    if (null != facet) {
      FacetTypes facetType = facet.getFacetType();
      String facetValue = facet.getFacetValue();

      if (FacetTypes.LENGTH.equals(facetType)) {
        if (termValue.length() != Integer.parseInt(facetValue)) {
          agreementValidatorResultDTO = singleValueLengthValidation(agreementValidatorResultDTO, termDetails);
        }
      }
      if (FacetTypes.MINLENGTH.equals(facetType)) {
        if (termValue.length() < Integer.parseInt(facetValue)) {
          agreementValidatorResultDTO = singleValueMinLengthValidation(agreementValidatorResultDTO, termDetails);
        }
      }
      if (FacetTypes.MAXLENGTH.equals(facetType)) {
        if (termValue.length() > Integer.parseInt(facetValue)) {
          agreementValidatorResultDTO = singleValueMaxLengthValidation(agreementValidatorResultDTO, termDetails);
        }
      }
      if (FacetTypes.PATTERN.equals(facetType)) {
        Pattern pattern = Pattern.compile(facetValue);

        Matcher matcher = pattern.matcher(termValue);
        if (!matcher.matches()) {
          agreementValidatorResultDTO = singleValuePatternValidation(agreementValidatorResultDTO, termDetails);
        }
      }
    }
    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO rangeFacetMaxExcValidation(
      AgreementValidatorResultDTO agreementValidatorResultDTO, TermRestResource termDetails, String termValue,
      String facetValue) {

    agreementValidatorResultDTO = new AgreementValidatorResultDTO();

    if (!StringUtils.isNumeric(termValue) || Long.parseLong(termValue) >= Long.parseLong(facetValue)) {
      agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
      agreementValidatorResultDTO.setMessage(FacetValidatorConstantsV2.TERM_NAME + termDetails.getName()
          + FacetValidatorConstantsV2.INVALID_MIN_MAX_INCLUSIVE_EXCLUSIVE_MSG);

      agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
      agreementValidatorResultDTO.setSuccessIndicator(false);
    }
    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO rangeFacetMinExcValidation(
      AgreementValidatorResultDTO agreementValidatorResultDTO, TermRestResource termDetails, String termValue,
      String facetValue) {
    agreementValidatorResultDTO = new AgreementValidatorResultDTO();

    if (!StringUtils.isNumeric(termValue) || Long.parseLong(termValue) <= Long.parseLong(facetValue)) {
      agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
      agreementValidatorResultDTO.setMessage(FacetValidatorConstantsV2.TERM_NAME + termDetails.getName()
          + FacetValidatorConstantsV2.INVALID_MIN_MAX_INCLUSIVE_EXCLUSIVE_MSG);

      agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
      agreementValidatorResultDTO.setSuccessIndicator(false);
    }

    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO rangeFacetMinIncValidation(
      AgreementValidatorResultDTO agreementValidatorResultDTO, TermRestResource termDetails, String termValue,
      String facetValue) {

    agreementValidatorResultDTO = new AgreementValidatorResultDTO();

    if (!StringUtils.isNumeric(termValue) || Long.parseLong(termValue) < Long.parseLong(facetValue)) {
      agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
      agreementValidatorResultDTO.setMessage(FacetValidatorConstantsV2.TERM_NAME + termDetails.getName()
          + FacetValidatorConstantsV2.INVALID_MIN_MAX_INCLUSIVE_EXCLUSIVE_MSG);

      agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
      agreementValidatorResultDTO.setSuccessIndicator(false);
    }

    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO rangeFacetMaxIncValidation(
      AgreementValidatorResultDTO agreementValidatorResultDTO, TermRestResource termDetails, String termValue,
      String facetValue) {

    agreementValidatorResultDTO = new AgreementValidatorResultDTO();

    if (!StringUtils.isNumeric(termValue) || Long.parseLong(termValue) > Long.parseLong(facetValue)) {
      agreementValidatorResultDTO.setCode(FacetValidatorConstantsV2.CODE_INVALID_FACET_VALUE);
      agreementValidatorResultDTO.setMessage(FacetValidatorConstantsV2.TERM_NAME + termDetails.getName()
          + FacetValidatorConstantsV2.INVALID_MIN_MAX_INCLUSIVE_EXCLUSIVE_MSG);

      agreementValidatorResultDTO.setStatus(FacetValidatorConstantsV2.FAILURE);
      agreementValidatorResultDTO.setSuccessIndicator(false);
    }

    return agreementValidatorResultDTO;
  }


  /**
   * This method is used to validate the range facet category
   *
   * @param facet
   * @param termValue
   * @param termDetails
   * @return agreementValidatorResultDTO
   */
  private AgreementValidatorResultDTO validateRangeFacetCategoty(TermFacetRestResource facet, String termValue,
      TermRestResource termDetails) {

    AgreementValidatorResultDTO agreementValidatorResultDTO = null;
    if (null != facet) {
      FacetTypes facetType = facet.getFacetType();
      String facetValue = facet.getFacetValue();

      if (FacetTypes.MAXEXCLUSIVE.equals(facetType)) {
        agreementValidatorResultDTO = rangeFacetMaxExcValidation(agreementValidatorResultDTO, termDetails, termValue,
            facetValue);
      }
      if (FacetTypes.MINEXCLUSIVE.equals(facetType)) {
        agreementValidatorResultDTO = rangeFacetMinExcValidation(agreementValidatorResultDTO, termDetails, termValue,
            facetValue);
      }

      if (FacetTypes.MININCLUSIVE.equals(facetType)) {
        agreementValidatorResultDTO = rangeFacetMinIncValidation(agreementValidatorResultDTO, termDetails, termValue,
            facetValue);
      }
      if (FacetTypes.MAXINCLUSIVE.equals(facetType)) {
        agreementValidatorResultDTO = rangeFacetMaxIncValidation(agreementValidatorResultDTO, termDetails, termValue,
            facetValue);
      }

    }
    return agreementValidatorResultDTO;
  }
}
