package com.abnamro.gpa.generic.gpaagreementvalidator.helper;

import com.abnamro.gpa.generic.administrationdao.dtos.AdminTermView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.dtos.FacetView;
import com.abnamro.gpa.generic.administrationdao.dtos.ProductAdminMapView;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermFacetRestResource;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * @author C45158
 */
@Component
public class GPAAgreementMapper {

  /**
   * This method is used to convert AdministrationView to the AdministrationRestResource
   *
   * @param administrationView retrieved from database
   * @return AdministrationRestResource details
   */
  public AdministrationRestResource convertToAdministrationRestResource(AdministrationView administrationView) {
    AdministrationRestResource administrationRestResource = null;
    if (administrationView != null) {
      administrationRestResource = new AdministrationRestResource();
      administrationRestResource.setId(administrationView.getId());
      if (administrationView.getName() != null && StringUtils.isNotEmpty(administrationView.getName())) {
        administrationRestResource.setName(administrationView.getName().trim());
      }
      if (administrationView.getDescription() != null
          && StringUtils.isNotEmpty(administrationView.getDescription())) {
        administrationRestResource.setDescription(administrationView.getDescription().trim());
      }
      if (administrationView.getOarId() != null && StringUtils.isNotEmpty(administrationView.getOarId())) {
        administrationRestResource.setOarId(administrationView.getOarId().trim());
      }
      if (administrationView.getName() != null && StringUtils.isNotEmpty(administrationView.getName())) {
        administrationRestResource.setName(administrationView.getName().trim());
      }
      administrationRestResource.setAuditDetails(getPopulatedAuditDetails(administrationView.getCreatedBy(),
          administrationView.getCreatedTimeStamp(), administrationView.getModifiedBy(),
          administrationView.getModifiedTimeStamp()));

      populateAdminProductMappingResource(administrationRestResource, administrationView);
      populateAdminTermResource(administrationRestResource, administrationView);
    }
    return administrationRestResource;
  }

  private void populateAdminTermResource(AdministrationRestResource administrationRestResource,
      AdministrationView administrationView) {
    List<TermRestResource> terms = new ArrayList<TermRestResource>();
    if (administrationView.getAdminTermViews() != null && !administrationView.getAdminTermViews().isEmpty()) {
      for (AdminTermView adminTermView : administrationView.getAdminTermViews()) {
        TermRestResource termRestResource = convertToTermRestResource(adminTermView);
        terms.add(termRestResource);
      }
    }
    administrationRestResource.setTerms(terms);
  }

  private TermRestResource convertToTermRestResource(AdminTermView adminTermView) {
    TermRestResource termRestResource = new TermRestResource();
    termRestResource.setId(adminTermView.getTermId());
    if (adminTermView.getName() != null) {
      termRestResource.setName(adminTermView.getName().trim());
    }
    if (adminTermView.getDescription() != null) {
      termRestResource.setDescription(adminTermView.getDescription().trim());
    }
    if (adminTermView.getDataType() != null && !"".equals(adminTermView.getDataType())) {
      termRestResource.setDataType(TermDataType.valueOf(adminTermView.getDataType().trim()));
    }
    if (adminTermView.getMandatoryIndicator() != null && ("Y").equals(adminTermView.getMandatoryIndicator())) {
      termRestResource.setMandatory(true);
    }
    AuditDetails auditDetails = getPopulatedAuditDetails(adminTermView.getCreatedBy(),
        adminTermView.getCreatedTimeStamp(),
        adminTermView.getModifiedBy(), adminTermView.getModifiedTimeStamp());
    termRestResource.setAuditDetails(auditDetails);

    populateTermFacetResource(termRestResource, adminTermView);
    return termRestResource;
  }

  private void populateTermFacetResource(TermRestResource termRestResource, AdminTermView adminTermView) {

    List<TermFacetRestResource> facets = null;
    if (adminTermView.getFacetView() != null && !adminTermView.getFacetView().isEmpty()) {
      facets = new ArrayList<TermFacetRestResource>();
      for (FacetView facetView : adminTermView.getFacetView()) {
        TermFacetRestResource termFacetRestResource = new TermFacetRestResource();
        if (facetView.getType() != null && !("").equals(facetView.getType().trim())) {
          termFacetRestResource.setFacetType(FacetTypes.valueOf(facetView.getType().trim()));
        }
        termFacetRestResource.setFacetValue(facetView.getValue());
        AuditDetails auditDetails = getPopulatedAuditDetails(facetView.getCreatedBy(), facetView.getCreatedTimeStamp(),
            facetView.getModifiedBy(), facetView.getModifiedTimeStamp());
        termFacetRestResource.setAuditDetails(auditDetails);
        facets.add(termFacetRestResource);
      }
    }
    termRestResource.setFacets(facets);
  }

  private void populateAdminProductMappingResource(AdministrationRestResource administrationRestResource,
      AdministrationView administrationView) {
    List<Integer> products = null;
    if (administrationView.getProductAdminMapViews() != null && !administrationView.getProductAdminMapViews()
        .isEmpty()) {
      products = new ArrayList<Integer>();
      for (ProductAdminMapView productAdminMapView : administrationView.getProductAdminMapViews()) {
        products.add(productAdminMapView.getProductId());
      }
    }
    administrationRestResource.setProducts(products);
  }

  private AuditDetails getPopulatedAuditDetails(String createdBy, Timestamp createdTimeStamp, String modifiedBy,
      Timestamp modifiedTimeStamp) {
    AuditDetails auditDetails = new AuditDetails();
    if (createdBy != null && StringUtils.isNotEmpty(createdBy)) {
      auditDetails.setCreatedBy(createdBy.trim());
    }
    if (createdTimeStamp != null) {
      auditDetails.setCreatedTimeStamp(createdTimeStamp);
    }
    if (modifiedBy != null && StringUtils.isNotEmpty(modifiedBy)) {
      auditDetails.setModifiedBy(modifiedBy.trim());
    }
    if (modifiedTimeStamp != null) {
      auditDetails.setModifiedTimeStamp(modifiedTimeStamp);
    }
    return auditDetails;
  }


}
