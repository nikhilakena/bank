/**
 *
 */
package com.abnamro.gpa.generic.gpaagreementdao.helper;

import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.generic.gpaagreementdao.constants.GPAAgreementDAOConstants;
import com.abnamro.gpa.generic.gpaagreementdao.constants.GPAAgreementDAOLogConstants;
import com.abnamro.gpa.generic.gpaagreementdao.constants.GPAAgreementDAOMessageKeys;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementTermDTO;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.generic.gpaagreementdao.view.GPAAgreementTermView;
import com.abnamro.gpa.generic.gpaagreementdao.view.GPAAgreementTermViewComparator;
import com.abnamro.gpa.generic.gpaagreementdao.view.GPAAgreementView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This mapper class converts database views into DTO and vice versa.
 * @author C45158
 *
 */
@Component
public class GPAAgreementDaoViewMapper {


  private static final Logger logHelper = LoggerFactory.getLogger(GPAAgreementDaoViewMapper.class);

  /**
   *
   * This Method is used to mapp DTO into view
   * @param agreementDTO is GPAAgreementDTO
   * @return agreementView DTO is GPAAgreementView
   * @throws GPAAgreementDAOException is an exception
   */

  public GPAAgreementView covertToAgreementView(GPAAgreementDTO agreementDTO) throws GPAAgreementDAOException {

    GPAAgreementView agreementView = new GPAAgreementView();
    agreementView.setAgreementId(agreementDTO.getAgreementId());
    agreementView.setProductId(agreementDTO.getProductId());
    agreementView.setCustomerId(agreementDTO.getCustomerId());
    agreementView.setStartDate(agreementDTO.getStartDate());
    agreementView.setEndDate(agreementDTO.getEndDate());
    agreementView.setStatus(agreementDTO.getStatus());
    agreementView.setCreatedTimeStamp(agreementDTO.getCreatedTimeStamp());
    agreementView.setCreatedBy(agreementDTO.getCreatedBy());
    agreementView.setUpdatedBy(agreementDTO.getUpdatedBy());
    agreementView.setUpdatedTimeStamp(agreementDTO.getUpdatedTimeStamp());
    populateAgreementData(agreementView, agreementDTO);
    return agreementView;
  }

  private void populateAgreementData(GPAAgreementView agreementView, GPAAgreementDTO agreementDTO)
      throws GPAAgreementDAOException {
    final String LOG_METHOD = "populateAgreementData()::";
    String jsonString = null;
    List<String> slicedData = null;
    List<GPAAgreementTermView> terms = new ArrayList<GPAAgreementTermView>();
    GPAAgreementTermView agreementTermView = null;

    jsonString = new Gson().toJson(agreementDTO.getTerms());
    logHelper.info(String.format("%s: %s %s ", LOG_METHOD, " jsonString is  ", jsonString));

    if (jsonString != null) {
      slicedData = getSlicedDataMessage(jsonString);
    }
    if (slicedData != null && !slicedData.isEmpty()) {
      int i = 0;
      for (String data : slicedData) {
        agreementTermView = new GPAAgreementTermView();
        agreementTermView.setSequence(i);
        agreementTermView.setData(data);
        agreementTermView.setCreatedTimeStamp(agreementDTO.getCreatedTimeStamp());
        agreementTermView.setCreatedBy(agreementDTO.getCreatedBy());
        agreementTermView.setUpdatedBy(agreementDTO.getUpdatedBy());
        agreementTermView.setUpdatedTimeStamp(agreementDTO.getUpdatedTimeStamp());
        terms.add(agreementTermView);
        i++;
      }
    }
    agreementView.setTerms(terms);

  }

  private List<String> getSlicedDataMessage(String jsonString) throws GPAAgreementDAOException {
    final String logMethod = "getSlicedDataMessage(String):List<String>";
    int dataSize = 32000;
    int actualsize = 0;
    List<String> slicedData = new ArrayList<String>();
    try {
      // get size of message
      if (jsonString != null) {
        actualsize = jsonString.getBytes(GPAAgreementDAOConstants.ENCODING_UTF8).length;

        if (actualsize < dataSize) {
          dataSize = (int) actualsize;
        }

        byte[] dataPart = null;
        int startIndex = 0;
        int copySize = 0;

        // in below loop message is divided into  messagePart
        while (startIndex < actualsize) {
          if ((actualsize - startIndex) < dataSize) {
            copySize = (int) actualsize - startIndex;
          } else {
            copySize = dataSize;
          }
          dataPart = new byte[copySize];
          System.arraycopy(jsonString.getBytes(GPAAgreementDAOConstants.ENCODING_UTF8), startIndex, dataPart, 0,
              copySize);

          slicedData.add(new String(dataPart));
          startIndex = startIndex + dataSize;
        }
      }
    } catch (UnsupportedEncodingException e) {
      logHelper.error(logMethod, GPAAgreementDAOLogConstants.LOG_ERROR_POPULATE_TERM_DATA, e);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAgreementDAOMessageKeys.UNSUPPORTED_ENCODING_EXCEPTION_WHILE_TERMDATA_POPULATE),
          MessageType.getError());
      throw new GPAAgreementDAOException(messages);
    }

    return slicedData;
  }

  /**
   * It converts  GPAAgreementView to the GPAAgreementDTO
   *
   * @param agreementView is GPAAgreementView
   * @return GPAAgreementDTO
   */
  public GPAAgreementDTO covertToGPAAgreementDTO(GPAAgreementView agreementView) {
    GPAAgreementDTO gpaAgreementDTO = null;
    if (agreementView != null) {
      gpaAgreementDTO = new GPAAgreementDTO();
      gpaAgreementDTO.setAgreementId(agreementView.getAgreementId());
      gpaAgreementDTO.setCustomerId(agreementView.getCustomerId());
      gpaAgreementDTO.setProductId(agreementView.getProductId());

      if (StringUtils.isNotEmpty(agreementView.getStatus())) {
        gpaAgreementDTO.setStatus(agreementView.getStatus().trim());
      }
      gpaAgreementDTO.setStartDate(agreementView.getStartDate());
      gpaAgreementDTO.setEndDate(agreementView.getEndDate());

      if (StringUtils.isNotEmpty(agreementView.getCreatedBy())) {
        gpaAgreementDTO.setCreatedBy(agreementView.getCreatedBy().trim());
      }
      gpaAgreementDTO.setCreatedTimeStamp(agreementView.getCreatedTimeStamp());

      populateUpdateDetails(gpaAgreementDTO, agreementView);

      gpaAgreementDTO.setTerms(convertToAgreementTermDTOList(agreementView.getTerms()));
    }
    return gpaAgreementDTO;
  }

  private void populateUpdateDetails(GPAAgreementDTO gpaAgreementDTO, GPAAgreementView agreementView) {

    List<GPAAgreementTermView> terms = agreementView.getTerms();
    Timestamp updatedTimeStamp = null;
    String updatedBy = null;

    if (terms != null && !terms.isEmpty()) {
      //sort
      Collections.sort(terms, new GPAAgreementTermViewComparator());
      if (terms.get(terms.size() - 1).getUpdatedTimeStamp() != null
          && agreementView.getUpdatedTimeStamp() != null
          && StringUtils.isNotEmpty(terms.get(terms.size() - 1).getUpdatedBy())) {
        if (terms.get(terms.size() - 1).getUpdatedTimeStamp().getTime() > agreementView.getUpdatedTimeStamp()
            .getTime()) {
          updatedTimeStamp = terms.get(terms.size() - 1).getUpdatedTimeStamp();
          updatedBy = terms.get(terms.size() - 1).getUpdatedBy().trim();
        }
      } else if (StringUtils.isNotEmpty(agreementView.getUpdatedBy())) {
        updatedTimeStamp = agreementView.getUpdatedTimeStamp();
        updatedBy = agreementView.getUpdatedBy().trim();
      }
    } else {
      updatedTimeStamp = agreementView.getUpdatedTimeStamp();
      updatedBy = agreementView.getUpdatedBy().trim();
    }

    gpaAgreementDTO.setUpdatedBy(updatedBy);
    gpaAgreementDTO.setUpdatedTimeStamp(updatedTimeStamp);
  }

  private List<GPAAgreementTermDTO> convertToAgreementTermDTOList(List<GPAAgreementTermView> terms) {

    ArrayList<GPAAgreementTermDTO> termDTOList = null;

    if (terms != null && !terms.isEmpty()) {

      termDTOList = new ArrayList<GPAAgreementTermDTO>();

      //sort by sequence
      Collections.sort(terms, new GPAAgreementTermViewComparator());

      //Join the String data
      String jsonString = "";
      for (GPAAgreementTermView termView : terms) {
        if (StringUtils.isNotEmpty(termView.getData())) {
          jsonString = jsonString + termView.getData().trim();
        }
      }

      if (StringUtils.isNotBlank(jsonString)) {
        Gson gson = new GsonBuilder().setLenient().create();
        termDTOList = gson.fromJson(jsonString, new TypeToken<List<GPAAgreementTermDTO>>() {
        }.getType());
      }
    }

    return termDTOList;
  }
}
