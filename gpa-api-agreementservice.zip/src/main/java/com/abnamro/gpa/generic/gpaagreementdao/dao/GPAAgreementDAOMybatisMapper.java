package com.abnamro.gpa.generic.gpaagreementdao.dao;


import com.abnamro.gpa.generic.gpaagreementdao.view.GPAAgreementTermView;
import com.abnamro.gpa.generic.gpaagreementdao.view.GPAAgreementView;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;


/**
 * This is the mybatis query mapper interface class for GPAAdministrationDAO
 * @author C45158
 *  
 */
@Mapper
public interface GPAAgreementDAOMybatisMapper {

	
	  /**
	   * This method is used to send query params
	 * @param schemaName is  string
	 * @param gpaAgreementView is GPAAgreementDTO
	 */
	public void insertAgreement( @Param("agreementDTO") final GPAAgreementView gpaAgreementView);

	  /**
	   * This method is used to send query params
	 * @param schemaName is  string
	 * @param agreementId is long
	 * @param agreementTermView is GPAAgreementTermView
	 */
	public void insertAgreementTermData( @Param("agreementId") final long agreementId, @Param("agreementTermView") final GPAAgreementTermView agreementTermView);

	/**
	 * This method is used to  agreement details
	 * @param schemaName  is  string
	 * @param agreementId is long
	 * @return GPAAgreementTermView
	 */
	public GPAAgreementView readGPAAgreement( @Param("agreementId") final Long agreementId);
		
	
	/**
	   * This method is used to send query params
	 * @param schemaName is  string
	 * @param agreementView is GPAAgreementDTO
	 */
	public void updateAgreement( @Param("agreementDTO") final GPAAgreementView agreementView);

	  /**
	   * This method is used to send query params
	 * @param schemaName is  string
	 * @param agreementId is long
	 * @param agreementTermView is GPAAgreementTermView
	 */
	public void updateAgreementTermData( @Param("agreementId") final long agreementId, @Param("agreementTermView") final GPAAgreementTermView agreementTermView);

	/** It return no of data records from the database for input agreement Id
	 * 
	 * @param dbSchemaPrefix is  string
	 * @param agreementId is long
	 * @return no of data records from the database for input agreement Id
	 */
	public int getNoOfDataRecords( @Param("agreementId") final long agreementId);
	
	/**
	   * This method is used to send query params
	 * @param schemaName is  string
	 * @param agreementId is long
	 * @param sequence is integer
	 */
	public void deleteAgreementTermData( @Param("agreementId") final long agreementId, @Param("sequence") final int sequence);

}
