package com.abnamro.gpa.generic.gpaagreementdao.view;

import java.util.Comparator;


/**
 * This is the Comparator class for the GPA agreements
 * @author C23597
 * 
 */
public class GPAAgreementTermViewComparator implements Comparator<GPAAgreementTermView> {

	@Override
	  public int compare(GPAAgreementTermView atv1, GPAAgreementTermView atv2)
	  {
	      return atv1.getSequence()- atv2.getSequence();
	  } 
}
