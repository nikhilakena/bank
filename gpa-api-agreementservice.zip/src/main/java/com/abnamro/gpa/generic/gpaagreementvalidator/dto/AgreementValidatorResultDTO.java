/**
 *
 */
package com.abnamro.gpa.generic.gpaagreementvalidator.dto;

/**
 * @author C45158
 *
 */
public class AgreementValidatorResultDTO {

  private boolean successIndicator;
  private String code;
  private String message;
  private String status;
  private String[] params;

  /**
   * @return the successIndicator
   */
  public boolean isSuccessIndicator() {
    return successIndicator;
  }

  /**
   * @param successIndicator the successIndicator to set
   */
  public void setSuccessIndicator(boolean successIndicator) {
    this.successIndicator = successIndicator;
  }

  /**
   * @return the code
   */
  public String getCode() {
    return code;
  }

  /**
   * @param code the code to set
   */
  public void setCode(String code) {
    this.code = code;
  }

  /**
   * @return the message
   */
  public String getMessage() {
    return message;
  }

  /**
   * @param message the message to set
   */
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * @param status the status to set
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * @return the params
   */
  public String[] getParams() {
    return params;
  }

  /**
   * @param params the params to set
   */
  public void setParams(String[] params) {
    this.params = params;
  }

}
