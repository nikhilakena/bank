package com.abnamro.gpa.generic.constant;

/**
 * 
 * @author C45158
 *
 */
public class GPAAgreementValidatorLogConstants {

	public static final String LOG_TECHNICAL_EXCEPTION_IN_READ_ADMIN = "LOG_GPAAGVAL_001";
	public static final String LOG_INVALID_TIME = "LOG_GPAAGVAL_002";
	public static final String LOG_INVALID_DATE_TIME = "LOG_GPAAGVAL_003";
	public static final String LOG_INVALID_DATE = "LOG_GPAAGVAL_004";
	public static final String LOG_PARSE_DATE = "LOG_GPAAGVAL_005";
	public static final String LOG_INVALID_CUSTOMER_ID = "LOG_GPAAGVAL_006";
	public static final String LOG_INVALID_AGREEMENT_ID = "LOG_GPAAGVAL_007";
	public static final String LOG_INVALID_TERM_NAME = "LOG_GPAAGVAL_008";
	public static final String LOG_INVALID_TERM_ID = "LOG_GPAAGVAL_009";
	
	
}
