package com.abnamro.gpa.generic.exception;

import com.abnamro.gpa.generic.gpaagreementdao.exception.DAOException;

public class BusinessApplicationException extends Exception{

    private Messages messages;
    public BusinessApplicationException() {
        this.messages = new Messages();
    }

    /**
     * Constructor that will also set messages on the exception.
     *
     * @param messages it takes messages of Message type
     */
    public BusinessApplicationException(Messages messages) {
        this.messages = messages;
    }

    /**
     * Constructor that takes an existing AABException. This will move any messages
     * into the new exception. <br>
     *
     * @param e accepts type of AABException
     */
    public BusinessApplicationException(BusinessApplicationException e) {
        if (e != null) {
            this.messages = e.getMessages();
        } else {
            this.messages = new Messages();
        }
    }

    @Override
    public String toString() {
        return getClass().getName() + " : " + this.messages.toString();
    }

    public Messages getMessages() {
        return messages;
    }

    public void setMessages(Messages messages) {
        this.messages = messages;
    }
}
