/**
 * 
 */
package com.abnamro.gpa.generic.gpaagreementdao.dtos;




import java.sql.Timestamp;
import java.util.List;

/**
 * This is a view class which holds the details of agreement 
 * @author C45158
 *
 */
public class GPAAgreementDTO  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long agreementId;
	
	private int productId;
	
	private long customerId;
	
	private String status;
	
	private Timestamp startDate;
	
	private Timestamp endDate;
	
	private String createdBy;
	
	private Timestamp createdTimeStamp;
	
	private String updatedBy;
	
	private Timestamp updatedTimeStamp;
	
	private List<GPAAgreementTermDTO> terms ;

	/**
	 * @return the agreementId
	 */
	public long getAgreementId() {
		return agreementId;
	}

	/**
	 * @param agreementId the agreementId to set
	 */
	public void setAgreementId(long agreementId) {
		this.agreementId = agreementId;
	}

	/**
	 * @return the productId
	 */
	public int getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(int productId) {
		this.productId = productId;
	}

	/**
	 * @return the customerId
	 */
	public long getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the startDate
	 */
	public Timestamp getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public Timestamp getEndDate() {
		return endDate;
	}

	/**
	 * @param timestamp the endDate to set
	 */
	public void setEndDate(Timestamp timestamp) {
		this.endDate = timestamp;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdTimeStamp
	 */
	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	/**
	 * @param createdTimeStamp the createdTimeStamp to set
	 */
	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the updatedTimeStamp
	 */
	public Timestamp getUpdatedTimeStamp() {
		return updatedTimeStamp;
	}

	/**
	 * @param updatedTimeStamp the updatedTimeStamp to set
	 */
	public void setUpdatedTimeStamp(Timestamp updatedTimeStamp) {
		this.updatedTimeStamp = updatedTimeStamp;
	}

	/**
	 * @return the terms
	 */
	public List<GPAAgreementTermDTO> getTerms() {
		return terms;
	}

	/**
	 * @param terms the terms to set
	 */
	public void setTerms(List<GPAAgreementTermDTO> terms) {
		this.terms = terms;
	}
	
	
	
	
}
