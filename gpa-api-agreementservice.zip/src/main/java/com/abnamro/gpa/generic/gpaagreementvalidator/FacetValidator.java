/**
 * This class performs validations based on the facet types & values defined for an administration.
 */
package com.abnamro.gpa.generic.gpaagreementvalidator;

import com.abnamro.gpa.generic.constant.FacetValidatorConstants;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.glossary.TermFacetRestResource;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author pa2619
 *
 */
@Component
public class FacetValidator {
	
	
	/**
	 * This method validates the term value received in the input agreement with the facets defined 
	 * in database for the specific administration.
	 *  ENUMERATION, 
		LENGTH, 
		PATTERN, 
		MAXLENGTH, 
		MINLENGTH, 
		MININCLUSIVE, 
		MAXINCLUSIVE,
		MINEXCLUSIVE, 
		MAXEXCLUSIVE,
		TOTALDIGITS,
		FRACTIONS
	 * @param termDetails Details of Term Rest Resource
	 * @param termValue term value from input agreement
	 * @return AgreementValidatorResultDTO DTO which indicates success or failure in validation
	 */
	public AgreementValidatorResultDTO validateFacet(TermRestResource termDetails, String termValue) {
		AgreementValidatorResultDTO resultDTO = new AgreementValidatorResultDTO();
		resultDTO.setSuccessIndicator(true);
		AgreementValidatorResultDTO facetTypeValidatorResultDTO = validateFacetType(termDetails, termValue);
		if (null != facetTypeValidatorResultDTO && !facetTypeValidatorResultDTO.isSuccessIndicator()) {
			return facetTypeValidatorResultDTO;
		}
		return resultDTO;
	}
	 

	/**
	 * This method is used to validate the facet types
	 * @param termDetails is TermRestResource
	 * @param termValue is String
	 * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
	 */
	private AgreementValidatorResultDTO validateFacetType(TermRestResource termDetails, String termValue) {
		
		AgreementValidatorResultDTO agreementValidatorResultDTO=null;
		
		if (termDetails != null && StringUtils.isNotEmpty(termValue) && termDetails.getFacets()!=null) {
			for (TermFacetRestResource facet : termDetails.getFacets()) {
				
				agreementValidatorResultDTO=validateEachFacetType(facet,termValue,termDetails);
				if(null!=agreementValidatorResultDTO && !agreementValidatorResultDTO.isSuccessIndicator()){
					return agreementValidatorResultDTO;
				}
			}
		}
		return agreementValidatorResultDTO;
	}


	private AgreementValidatorResultDTO validateEachFacetType(TermFacetRestResource facet, String termValue, TermRestResource termDetails) {
		AgreementValidatorResultDTO agreementValidatorResultDTO=null;
		if (null!=facet && null != facet.getFacetType()) {
			// checks if the facet type is range
			if (facet.getFacetType().equals(FacetTypes.MININCLUSIVE)
					|| facet.getFacetType().equals(FacetTypes.MAXINCLUSIVE)
					|| facet.getFacetType().equals(FacetTypes.MINEXCLUSIVE)
					|| facet.getFacetType().equals(FacetTypes.MAXEXCLUSIVE)) {
				agreementValidatorResultDTO=validateRangeFacetCategoty(facet, termValue.trim(),termDetails);
			}
			// checks if the facet type is single value
			if (facet.getFacetType().equals(FacetTypes.MAXLENGTH)
					|| facet.getFacetType().equals(FacetTypes.MINLENGTH)
					|| facet.getFacetType().equals(FacetTypes.LENGTH)
					|| facet.getFacetType().equals(FacetTypes.PATTERN)) {
				agreementValidatorResultDTO=validateSingleValueFacetCategoty(facet, termValue.trim(),termDetails);
			}
			// checks if the facet type is single value of numeric data type
			if (facet.getFacetType().equals(FacetTypes.FRACTIONS)
					|| facet.getFacetType().equals(FacetTypes.TOTALDIGITS)) {
				agreementValidatorResultDTO=validateSingleNumericValueFacetCategoty(facet, termValue.trim(),termDetails);
			}
			//checks if the facet is list
			if (facet.getFacetType().equals(FacetTypes.ENUMERATION)) {
				agreementValidatorResultDTO=validateListFacetCategory(facet,termValue.trim(),termDetails);
			}
			
		}
		return agreementValidatorResultDTO;
	}

	

	/**
	 * This method is used to validate the fraction and total digits in term value
	 * @param facet
	 * @param termValue
	 * @param termDetails 
	 * @return ggreementValidatorResultDTO
	 */
	private AgreementValidatorResultDTO validateSingleNumericValueFacetCategoty(TermFacetRestResource facet, String termValue, TermRestResource termDetails) {
		
		AgreementValidatorResultDTO agreementValidatorResultDTO=new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(true);
		
		if(null!=facet){
			FacetTypes facetType=facet.getFacetType();
			String facetValue=facet.getFacetValue();
			// checks if the input value contains decimal or not
			if (StringUtils.isEmpty(termValue) || StringUtils.countMatches(termValue, ".") != 1) {
				agreementValidatorResultDTO = new AgreementValidatorResultDTO();
				agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
				agreementValidatorResultDTO
						.setMessage(FacetValidatorConstants.INVALID_DECIMAL_VALUE_MSG + FacetValidatorConstants.TERM_NAME + termDetails.getName() + FacetValidatorConstants.INVALID_MSG);
				agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
				agreementValidatorResultDTO.setSuccessIndicator(false);
				return agreementValidatorResultDTO;
			}
			String[] fractionValue = termValue.split("\\.");
			if (FacetTypes.FRACTIONS.equals(facetType)) {
				if (fractionValue[1].length() > Integer.parseInt(facetValue)) {
					agreementValidatorResultDTO = new AgreementValidatorResultDTO();
					agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
					agreementValidatorResultDTO.setMessage(
							FacetValidatorConstants.INVALID_FRACTIONS_MSG + FacetValidatorConstants.TERM_NAME + termDetails.getName() + FacetValidatorConstants.INVALID_MSG);
					agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
					agreementValidatorResultDTO.setSuccessIndicator(false);
					return agreementValidatorResultDTO;
				}
			}
			if (FacetTypes.TOTALDIGITS.equals(facetType)) {
				if ((fractionValue[0].length() + fractionValue[1].length()) > Integer.parseInt(facetValue)) {
					agreementValidatorResultDTO = new AgreementValidatorResultDTO();
					agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
					agreementValidatorResultDTO.setMessage(
							FacetValidatorConstants.INVALID_TOTALDIGITS_MSG +  FacetValidatorConstants.TERM_NAME + termDetails.getName() + FacetValidatorConstants.INVALID_MSG);
					agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
					agreementValidatorResultDTO.setSuccessIndicator(false);
					return agreementValidatorResultDTO;
				}
			}
		}
		return agreementValidatorResultDTO;
	}


	private AgreementValidatorResultDTO validateListFacetCategory(TermFacetRestResource facet,String termValue, TermRestResource termDetails) {
		
		AgreementValidatorResultDTO agreementValidatorResultDTO=null;
		
		if(null!=facet){
			String facetValue=facet.getFacetValue();
			if (null != facetValue && !facetValue.contains(termValue)) {
				agreementValidatorResultDTO = new AgreementValidatorResultDTO();
				agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
				agreementValidatorResultDTO
						.setMessage(FacetValidatorConstants.INVALID_ENUMERATION_MSG + FacetValidatorConstants.TERM_NAME + termDetails.getName() + FacetValidatorConstants.INVALID_MSG);
				agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
				agreementValidatorResultDTO.setSuccessIndicator(false);
				return agreementValidatorResultDTO;
			}
		}
		return agreementValidatorResultDTO;
	}

	


	/**
	 * This method is used to validate single value facet category
	 * @param facet
	 * @param termValue
	 * @param termDetails 
	 * @return agreementValidatorResultDTO
	 */
	private AgreementValidatorResultDTO validateSingleValueFacetCategoty(TermFacetRestResource facet, String termValue, TermRestResource termDetails) {
		AgreementValidatorResultDTO agreementValidatorResultDTO=null;
		if(null!=facet){
			FacetTypes facetType=facet.getFacetType();
			String facetValue=facet.getFacetValue();
			
			if(FacetTypes.LENGTH.equals(facetType)){
				if(termValue.length() != Integer.parseInt(facetValue)){
					agreementValidatorResultDTO = new  AgreementValidatorResultDTO();
					agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
					agreementValidatorResultDTO.setMessage(FacetValidatorConstants.INVALID_LENGTH_MSG + FacetValidatorConstants.TERM_NAME + termDetails.getName() + FacetValidatorConstants.INVALID_MSG);
					agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
					agreementValidatorResultDTO.setSuccessIndicator(false);
					return agreementValidatorResultDTO;
				}
			}
			if(FacetTypes.MINLENGTH.equals(facetType)){
				if(termValue.length() < Integer.parseInt(facetValue)){
					agreementValidatorResultDTO = new  AgreementValidatorResultDTO();
					agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
					agreementValidatorResultDTO.setMessage(FacetValidatorConstants.INVALID_MINLENGTH_MSG + FacetValidatorConstants.TERM_NAME + termDetails.getName() + FacetValidatorConstants.INVALID_MSG);
					agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
					agreementValidatorResultDTO.setSuccessIndicator(false);
					return agreementValidatorResultDTO;
				}
			}
			if(FacetTypes.MAXLENGTH.equals(facetType)){
				if(termValue.length() > Integer.parseInt(facetValue)){
					agreementValidatorResultDTO = new  AgreementValidatorResultDTO();
					agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
					agreementValidatorResultDTO.setMessage(FacetValidatorConstants.INVALID_MAXLENGTH_MSG +FacetValidatorConstants.TERM_NAME + termDetails.getName() + FacetValidatorConstants.INVALID_MSG);
					agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
					agreementValidatorResultDTO.setSuccessIndicator(false);
					return agreementValidatorResultDTO;
				}
			}
			if(FacetTypes.PATTERN.equals(facetType)){
				Pattern pattern = Pattern.compile(facetValue);
				
				Matcher matcher = pattern.matcher(termValue);
				if(!matcher.matches()){
					agreementValidatorResultDTO = new  AgreementValidatorResultDTO();
					agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
					agreementValidatorResultDTO.setMessage(FacetValidatorConstants.INVALID_PATTERN_MSG +FacetValidatorConstants.TERM_NAME + termDetails.getName() + FacetValidatorConstants.INVALID_MSG);
					agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
					agreementValidatorResultDTO.setSuccessIndicator(false);
					return agreementValidatorResultDTO;
				}
			}
		}
		return agreementValidatorResultDTO;
	}


	/** 
	 * This method is used to validate the range facet category
	 * @param facet
	 * @param termValue
	 * @param termDetails 
	 * @return agreementValidatorResultDTO
	 */
	private AgreementValidatorResultDTO validateRangeFacetCategoty(TermFacetRestResource facet, String termValue, TermRestResource termDetails) {
		
		AgreementValidatorResultDTO agreementValidatorResultDTO=null;
		if(null!=facet){
			FacetTypes facetType=facet.getFacetType();
			String facetValue=facet.getFacetValue();
			
			if(FacetTypes.MAXEXCLUSIVE.equals(facetType)){
				
				if( !StringUtils.isNumeric(termValue) || Long.parseLong(termValue) >= Long.parseLong(facetValue)){
					agreementValidatorResultDTO = new  AgreementValidatorResultDTO();
					agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
					agreementValidatorResultDTO.setMessage(FacetValidatorConstants.TERM_NAME + termDetails.getName()+ FacetValidatorConstants.INVALID_MIN_MAX_INCLUSIVE_EXCLUSIVE_MSG);
					
					agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
					agreementValidatorResultDTO.setSuccessIndicator(false);
					return agreementValidatorResultDTO;
				}
			}
			if(FacetTypes.MINEXCLUSIVE.equals(facetType)){
				if(!StringUtils.isNumeric(termValue) || Long.parseLong(termValue) <= Long.parseLong(facetValue)){
					agreementValidatorResultDTO = new  AgreementValidatorResultDTO();
					agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
					agreementValidatorResultDTO.setMessage(FacetValidatorConstants.TERM_NAME + termDetails.getName()+ FacetValidatorConstants.INVALID_MIN_MAX_INCLUSIVE_EXCLUSIVE_MSG);
					
					agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
					agreementValidatorResultDTO.setSuccessIndicator(false);
					return agreementValidatorResultDTO;
				}			
			}
			
			if(FacetTypes.MININCLUSIVE.equals(facetType)){
				if(!StringUtils.isNumeric(termValue) || Long.parseLong(termValue) < Long.parseLong(facetValue)){
					agreementValidatorResultDTO = new  AgreementValidatorResultDTO();
					agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
					agreementValidatorResultDTO.setMessage(FacetValidatorConstants.TERM_NAME + termDetails.getName()+ FacetValidatorConstants.INVALID_MIN_MAX_INCLUSIVE_EXCLUSIVE_MSG);
					
					agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
					agreementValidatorResultDTO.setSuccessIndicator(false);
					return agreementValidatorResultDTO;
				}	
			}
			if(FacetTypes.MAXINCLUSIVE.equals(facetType)){
				if(!StringUtils.isNumeric(termValue) || Long.parseLong(termValue) > Long.parseLong(facetValue)){
					agreementValidatorResultDTO = new  AgreementValidatorResultDTO();
					agreementValidatorResultDTO.setCode(FacetValidatorConstants.CODE_INVALID_FACET_VALUE);
					agreementValidatorResultDTO.setMessage(FacetValidatorConstants.TERM_NAME + termDetails.getName()+ FacetValidatorConstants.INVALID_MIN_MAX_INCLUSIVE_EXCLUSIVE_MSG);
					
					agreementValidatorResultDTO.setStatus(FacetValidatorConstants.FAILURE);
					agreementValidatorResultDTO.setSuccessIndicator(false);
					return agreementValidatorResultDTO;
				}	
			}
			
		}
		return agreementValidatorResultDTO;
	}
}
