package com.abnamro.gpa.generic.gpaagreementdao.constants;


import com.abnamro.gpa.generic.exception.MessageKey;

/**
 * This is the DAO layer Message key constant file for GPAAgreementConfigurationDAO
 * @author C45158
 * 
 */
public class GPAAgreementDAOMessageKeys {

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_CREATING_AGREEMENT = new MessageKey("MESSAGE_GPAG_001");
	
	public static final MessageKey DATABASE_EXCEPTION_WHILE_CREATING_AGREEMENT = new MessageKey("MESSAGE_GPAG_002");

	public static final MessageKey DUPLICATE_KEY_EXCEPTION_WHILE_CREATING_AGREEMENT_DETAILS = new MessageKey("MESSAGE_GPAG_003");

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_READING_AGREEMENT = new MessageKey("MESSAGE_GPAG_004");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_READING_AGREEMENT = new MessageKey("MESSAGE_GPAG_005");
	
	public static final MessageKey INVALID_LENGTH_PARAMS_EXCEPTION_WHILE_CREATING_AGREEMENT = new MessageKey("MESSAGE_GPAG_006");

	public static final MessageKey IO_EXCEPTION_WHILE_CONVERTING_DATA_VIEW = new MessageKey("MESSAGE_GPAG_007");

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_UPATING_AGREEMENT = new MessageKey("MESSAGE_GPAG_008");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_UPDATING_AGREEMENT = new MessageKey("MESSAGE_GPAG_009");

	public static final MessageKey INVALID_LENGTH_PARAMS_EXCEPTION_WHILE_UPDATING_TERM = new MessageKey("MESSAGE_GPAG_010");

	public static final MessageKey INVALID_LENGTH_PARAMS_EXCEPTION_WHILE_UPDATING_AGREEMENT = new MessageKey("MESSAGE_GPAG_011");

	public static final MessageKey DUPLICATE_KEY_EXCEPTION_WHILE_UPDATING_AGREEMENT_DETAILS = new MessageKey("MESSAGE_GPAG_012");
	
	public static final MessageKey DATABASE_EXCEPTION_WHILE_CREATING_CONTRACTHEADER = new MessageKey("MESSAGE_GPAG_013");
	
	public static final MessageKey DATABASE_EXCEPTION_WHILE_UPDATING_CONTRACTHEADER = new MessageKey("MESSAGE_GPAG_014");
	
	public static final MessageKey UNSUPPORTED_ENCODING_EXCEPTION_WHILE_TERMDATA_POPULATE = new MessageKey("MESSAGE_GPAG_015");

	public static final MessageKey TECHNICAL_ERROR_OCCURED_CONNECTING_MYBATIS = new MessageKey("MESSAGE_GPAG_016");

}
