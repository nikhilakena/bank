/**
 * 
 */
package com.abnamro.gpa.generic.constant.v2;

/**
 * This class is created for API-V2
 * @author C45158
 *
 */
public class GPAAgreementValidatorConstantsV2 {
	
	public static final String DATE_TIME_FORMAT="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"; 
	
	public static final String FACET_DATE_TIME_FORMAT="yyyy-MM-dd HH:mm:ss"; 
	
	public static final String DATE_FORMAT="yyyy-MM-dd";
	
	public static final String TIME_FORMAT="HH:mm:ss";
	
	public static final String CODE_CONSUMER_UNAUTHORIZED = "CONSUMER_UNAUTHORIZED";
	public static final String DESC_CONSUMER_UNAUTHORIZED = "Consumer is not authorized for this operation";

	public static final String CODE_PRODUCT_ID_FORMAT_INVALID = "PRODUCT_ID_INVALID";
	public static final String DESC_PRODUCT_ID_FORMAT_INVALID = "Product Id is invalid";
	
	public static final String CODE_PRODUCT_ID_MANDATORY = "PRODUCT_ID_MANDATORY";
	public static final String DESC_PRODUCT_ID_MANDATORY = "Product ID is not provided";
	
	public static final String CODE_PRODUCT_ID_NOT_REGISTERED = "PRODUCT_ID_NOT_REGISTERED";
	public static final String DESC_PRODUCT_ID_NOT_REGISTERED = "Product ID is not present in the General Product Agreement Administration";
	
	public static final String CODE_CUSTOMER_ID_FORMAT_INVALID = "CUSTOMER_ID_INVALID";
	public static final String DESC_CUSTOMER_ID_FORMAT_INVALID = "Customer Id is invalid.";
	
	public static final String CODE_CUSTOMER_ID_MANDATORY = "CUSTOMER_ID_MANDATORY";
	public static final String DESC_CUSTOMER_ID_MANDATORY = "Customer ID is not provided";
	
	public static final String CODE_CONSUMER_ID_FORMAT_INVALID = "CONSUMER_ID_FORMAT_INVALID";
	public static final String DESC_CONSUMER_ID_FORMAT_INVALID = "Format of consumer ID is invalid";
	
	public static final String CODE_CONSUMER_ID_MANDATORY = "CONSUMER_ID_MANDATORY";
	public static final String DESC_CONSUMER_ID_MANDATORY = "Consumer ID is not provided";

	public static final String CODE_AGREEMENT_START_DATE_FORMAT_INVALID = "AGREEMENT_START_DATE_TIME_FORMAT_INVALID";
	public static final String DESC_AGREEMENT_START_DATE_FORMAT_INVALID = "Agreement start dateTime is invalid";
	
	public static final String CODE_AGREEMENT_START_DATE_MANDATORY = "AGREEMENT_START_DATE_TIME_MANDATORY";
	public static final String DESC_AGREEMENT_START_DATE_MANDATORY = "Agreement start date time is not provided";
	
	public static final String CODE_AGREEMENT_START_DATE_IN_PAST = "AGREEMENT_START_DATE_IN_PAST";
	public static final String DESC_AGREEMENT_START_DATE_IN_PAST = "Agreement start date is in the past";
	
	public static final String CODE_AGREEMENT_END_DATE_FORMAT_INVALID = "AGREEMENT_END_DATE_TIME_FORMAT_INVALID";
	public static final String DESC_AGREEMENT_END_DATE_FORMAT_INVALID = "Agreement end dateTime is invalid";
	
	public static final String CODE_AGREEMENT_END_DATE_MANDATORY = "AGREEMENT_END_DATE_TIME_MANDATORY";
	public static final String DESC_AGREEMENT_END_DATE_MANDATORY = "Agreement end dateTime is not provided";
		
	public static final String CODE_AGREEMENT_END_DATE_IN_PAST = "AGREEMENT_END_DATE_IN_PAST";
	public static final String DESC_AGREEMENT_END_DATE_IN_PAST = "Agreement end date is in the past";
	
	public static final String CODE_AGREEMENT_START_DATE_END_DATE_COMBINATION_INVALID = "AGREEMENT_START_END_DATE_TIME_COMBINATION_INVALID";
	public static final String DESC_AGREEMENT_START_DATE_END_DATE_COMBINATION_INVALID = "Agreement end dateTime is less than or equal to Agreement start dateTime";
	
	public static final String CODE_STATUS_INVALID = "AGREEMENT_LIFECYCLE_STATUS_TYPE_INVALID";
	public static final String DESC_STATUS_INVALID = "Agreement Lifecycle Status is invalid";

	public static final String CODE_STATUS_MANDATORY = "AGREEMENT_LIFECYCLE_STATUS_TYPE_MANDATORY";
	public static final String DESC_STATUS_MANDATORY = "Agreement Lifecycle Status is not provided";
	
	public static final String CODE_ATTRIBUTE_NAME_INVALID = "ATTRIBUTE_NAME_INVALID";
	public static final String DESC_ATTRIBUTE_NAME_INVALID = "Attribute name % is invalid";
	
	public static final String CODE_ATTRIBUTE_NAME_NOT_APPLICABLE = "ATTRIBUTE_NAME_NOT_APPLICABLE";
	public static final String DESC_ATTRIBUTE_NAME_NOT_APPLICABLE = "Attribute Name % is not applicable for input Product.";
	
	public static final String CODE_MANDATORY_ATTRIBUTE_NOT_PROVIDED = "MANDATORY_ATTRIBUTE_NOT_PROVIDED";
	public static final String DESC_MANDATORY_ATTRIBUTE_NOT_PROVIDED = "Mandatory Attribute is not provided for input Product";
	
	public static final String CODE_ATTRIBUTE_VALUE_INVALID = "ATTRIBUTE_VALUE_INVALID";
	public static final String DESC_ATTRIBUTE_VALUE_INVALID = "Attribute value % is invalid.";
	
	public static final String CODE_AGREEMENT_ID_FORMAT_INVALID = "AGREEMENT_ID_INVALID";
	public static final String DESC_AGREEMENT_ID_FORMAT_INVALID = "Agreement ID is invalid";
	
	public static final String CODE_AGREEMENT_ID_ALREADY_PRESENT = "AGREEMENT_ID_ALREADY_PRESENT";
	public static final String DESC_AGREEMENT_ID_ALREADY_PRESENT = "Agreement ID is already present in the General Product Agreement Administration";
		
	public static final String CODE_USER_ID_FORMAT_INVALID = "USER_ID_INVALID";
	public static final String DESC_USER_ID_FORMAT_INVALID = "User Id is invalid";
	
	public static final String CODE_USER_ID_MANDATORY = "USER_ID_MANDATORY";
	public static final String DESC_USER_ID_MANDATORY = "User ID is not provided";
	
	public static final String CODE_MANDATORY_ATTRIBUTE_VALUE_NOT_PROVIDED = "MANDATORY_ATTRIBUTE_VALUE_NOT_PROVIDED";
	public static final String DESC_MANDATORY_ATTRIBUTE_VALUE_NOT_PROVIDED = "Attribute value is not provided for ";
	
	public static final String RESPONSE_STATUS_400 = "400";
	
	public static final String RESPONSE_STATUS_401 = "401";
	
	public static final String RESPONSE_STATUS_500 = "500";
	
	public static final String CODE_INTERNAL_ERROR = "INTERNAL_SERVER_ERROR";
	
	public static final String CODE_TECHNICAL_ERROR = "INTERNAL_SERVER_ERROR";
	
	public static final String DESC_INTERNAL_ERROR = "Internal Server Error occured.";
	
	public static final String DESC_TECHNICAL_ERROR = "Internal Server Error occured.";
	
	public static final String INVALID_MSG = " is invalid";
	
	public static final String INVALID_DATE_TIME_FORMAT = "Format of the value of the ";
	
	public static final String TERM_NAME = "Attribute : ";
		
	

	

}
