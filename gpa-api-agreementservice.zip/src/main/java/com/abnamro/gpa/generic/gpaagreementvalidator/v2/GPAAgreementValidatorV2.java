/**
 *
 */
package com.abnamro.gpa.generic.gpaagreementvalidator.v2;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.dtos.AdminTermView;
import com.abnamro.gpa.generic.administrationdao.dtos.AdministrationView;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.constant.GPAAgreementValidatorLogConstants;
import com.abnamro.gpa.generic.constant.GPAAgreementValidatorMessageKeys;
import com.abnamro.gpa.generic.constant.v2.GPAAgreementValidatorConstantsV2;
import com.abnamro.gpa.generic.exception.GPAAgreementValidatorException;
import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.generic.gpaagreementvalidator.helper.GPAAgreementMapper;
import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This class is designed for API-v2
 * @author C45158
 *
 */
@Slf4j
@Component
public class GPAAgreementValidatorV2 {

  private GPAAdministrationDAO administrationdao;

  private GPAAgreementMapper mapper;

  private FacetValidatorV2 facetValidatorV2;

  @Autowired
  public GPAAgreementValidatorV2(GPAAdministrationDAO administrationdao, GPAAgreementMapper mapper,
      FacetValidatorV2 facetValidatorV2) {
    this.administrationdao = administrationdao;
    this.mapper = mapper;
    this.facetValidatorV2 = facetValidatorV2;
  }

  /**
   * this method is used to validate agreement Id and product Id
   * @param agreement is GeneralProductAgreement
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   * @throws GPAAgreementValidatorException is agreement validator exception
   */
  public AgreementValidatorResultDTO validateAgreement(GeneralProductAgreement agreement)
      throws GPAAgreementValidatorException {
    final String LOG_METHOD = "validateAgreement():response:: ";
    AgreementValidatorResultDTO agreementValidatorResultDTO = null;
    AdministrationView administrationView = null;

    GenericAgreementDetailsValidatorV2 genericAgreementDetailsValidatorV2 = new GenericAgreementDetailsValidatorV2();
    agreementValidatorResultDTO = genericAgreementDetailsValidatorV2.validateGenericDetails(agreement);
    log.info("{} SuccessIndicator_value={}", LOG_METHOD, agreementValidatorResultDTO.isSuccessIndicator());
    if (agreementValidatorResultDTO.isSuccessIndicator()) {
      administrationView = readAdministration(agreement);
      agreement = termDataMapper(administrationView, agreement);

      agreementValidatorResultDTO = validateAdministration(administrationView, agreement);
    }
    return agreementValidatorResultDTO;
  }

  private void termDataDetailMapping(Term agreementTerms, AdministrationView administrationView) {
    for (AdminTermView termView : administrationView.getAdminTermViews()) {
      if (termView.getName() != null
          && termView.getName().trim().equalsIgnoreCase(agreementTerms.getAttributeName())) {
        agreementTerms.setTermId(Integer.toString(termView.getTermId()));
      }

    }
  }

  /**
   * @param administrationView
   * @param agreement
   * @return agreement
   */
  private GeneralProductAgreement termDataMapper(AdministrationView administrationView,
      GeneralProductAgreement agreement) {

    if (agreement.getTerms() != null) {
      for (Term agreementTerms : agreement.getTerms()) {
        termDataDetailMapping(agreementTerms, administrationView);
      }
    }

    return agreement;

  }


  /**
   *
   * This method is used to validate administration retrieved
   * @param administrationView is AdministrationView
   * @param agreement is input to validate administration for agreement
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   * @throws GPAAgreementValidatorException is agreemnt validator exception
   */
  public AgreementValidatorResultDTO validateAdministration(AdministrationView administrationView,
      GeneralProductAgreement agreement) throws GPAAgreementValidatorException {
    final String LOG_METHOD = "validateAdministration():response:: ";
    AgreementValidatorResultDTO agreementValidatorResultDTO = null;
    if (null != administrationView) {
      agreementValidatorResultDTO = validateMandatoryTerms(administrationView, agreement);
      log.info("{} SuccessIndicator={}", LOG_METHOD, agreementValidatorResultDTO.isSuccessIndicator());
      if (agreementValidatorResultDTO.isSuccessIndicator()) {
        agreementValidatorResultDTO = validateAllTerms(administrationView, agreement);
      }
    } else {
      agreementValidatorResultDTO = handleValidationError(
          GPAAgreementValidatorConstantsV2.CODE_PRODUCT_ID_NOT_REGISTERED,
          GPAAgreementValidatorConstantsV2.DESC_PRODUCT_ID_NOT_REGISTERED,
          null,
          false);
    }
    return agreementValidatorResultDTO;
  }

  /**
   *
   * This method is used to validate all terms present in administration and provided in agreement.
   * @param administrationView is AdministrationView
   * @param agreement is input to validate all terms present in administration
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   * @throws GPAAgreementValidatorException is agreement validator exception
   */
  public AgreementValidatorResultDTO validateAllTerms(AdministrationView administrationView,
      GeneralProductAgreement agreement) throws GPAAgreementValidatorException {
    final String LOG_METHOD = "validateAllTerms():response:: ";
    AgreementValidatorResultDTO agreementValidatorResultDTO;
    agreementValidatorResultDTO = checkValidAgreementTermsForAdministration(administrationView, agreement);
    log.info("{} SuccessIndicator={} | agreement={}", LOG_METHOD,
        agreementValidatorResultDTO.isSuccessIndicator(), agreement);
    if (agreementValidatorResultDTO.isSuccessIndicator()) {
      agreementValidatorResultDTO = validateDataTypes(administrationView, agreement);
    }
    return agreementValidatorResultDTO;
  }

  private AgreementValidatorResultDTO checkValidAgreementTermsForAdministration(AdministrationView administrationView,
      GeneralProductAgreement agreement) {
    final String LOG_METHOD = "checkValidAgreementTermsForAdministration():response:: ";
    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);
    if (agreement.getTerms() != null) {
      for (Term terms : agreement.getTerms()) {
        boolean flag = false;
        for (AdminTermView adminTermView : administrationView.getAdminTermViews()) {
          if (terms.getTermId() != null && Integer.parseInt(terms.getTermId()) == adminTermView.getTermId()) {
            flag = true;
            log.info("{} termId={} | adminTermView_termId={}", LOG_METHOD,
                Integer.parseInt(terms.getTermId()), adminTermView.getTermId());
          }
        }
        if (!flag) {
          agreementValidatorResultDTO = handleValidationError(
              GPAAgreementValidatorConstantsV2.CODE_ATTRIBUTE_NAME_NOT_APPLICABLE,
              GPAAgreementValidatorConstantsV2.DESC_ATTRIBUTE_NAME_NOT_APPLICABLE,
              new String[]{terms.getAttributeName()},
              false);
          break;
        }
      }
    }
    return agreementValidatorResultDTO;
  }


  /**
   *
   * This method is used to check data types of terms and value provided in agreement.
   * @param administrationView is AdministrationView
   * @param agreement is GeneralProductAgreement
   * @return agreementValidatorResultDTO  is AgreementValidatorResultDTO
   * @throws GPAAgreementValidatorException is agreemnt validator exception
   */
  private AgreementValidatorResultDTO validateDataTypes(AdministrationView administrationView,
      GeneralProductAgreement agreement) throws GPAAgreementValidatorException {
    AgreementValidatorResultDTO agreementValidatorResultDTO = null;
    AdministrationRestResource administrationRestResource = null;

    agreementValidatorResultDTO = checkDataTypesInAgreement(administrationView, agreement);
    if (agreementValidatorResultDTO.isSuccessIndicator() && agreement.getTerms() != null) {
      administrationRestResource = mapper.convertToAdministrationRestResource(administrationView);
      for (TermRestResource administrationRestResourceObj : administrationRestResource.getTerms()) {
        for (Term terms : agreement.getTerms()) {
          if (Integer.parseInt(terms.getTermId())
              == administrationRestResourceObj.getId()) { // && administrationRestResourceObj.isMandatory() : its removed
            agreementValidatorResultDTO = facetValidatorV2.validateFacet(administrationRestResourceObj,
                terms.getAttributeValue());
            if (!agreementValidatorResultDTO.isSuccessIndicator()) {
              break;
            }
          }
        }
        if (!agreementValidatorResultDTO.isSuccessIndicator()) {
          break;
        }
      }
    }
    return agreementValidatorResultDTO;
  }

  /**
   *
   * This method is used to compare Term id of Administration and agreement.
   * @param administrationView is AdministrationView
   * @param agreement is GeneralProductAgreement
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   * @throws GPAAgreementValidatorException is agreement validator exception
   */
  private AgreementValidatorResultDTO checkDataTypesInAgreement(AdministrationView administrationView,
      GeneralProductAgreement agreement) throws GPAAgreementValidatorException {

    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);
    if (agreement.getTerms() != null) {
      for (AdminTermView adminTermView : administrationView.getAdminTermViews()) {
        for (Term terms : agreement.getTerms()) {
          if (Integer.parseInt(terms.getTermId()) == adminTermView.getTermId()) {
            agreementValidatorResultDTO = validateDataTypeValue(adminTermView.getDataType(), terms.getAttributeValue(),
                adminTermView, adminTermView.getMandatoryIndicator());
            if (!agreementValidatorResultDTO.isSuccessIndicator()) {
              break;
            }
          }
        }
        if (!agreementValidatorResultDTO.isSuccessIndicator()) {
          break;
        }
      }
    }
    return agreementValidatorResultDTO;
  }

  /**
   *
   * This Method is used to validate data type of term and value provided in agreement.
   * @param dataType is String
   * @param adminTermView
   * @param mandatoryIndicator
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   * @throws GPAAgreementValidatorException is agreement validator exception
   */
  private AgreementValidatorResultDTO validateDataTypeValue(String dataType, String termValue,
      AdminTermView adminTermView, String mandatoryIndicator) throws GPAAgreementValidatorException {
    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);
    if ("Y".equalsIgnoreCase(mandatoryIndicator) && (termValue == null || termValue.isEmpty())) {
      agreementValidatorResultDTO = handleValidationError(
          GPAAgreementValidatorConstantsV2.CODE_MANDATORY_ATTRIBUTE_VALUE_NOT_PROVIDED,
          GPAAgreementValidatorConstantsV2.DESC_MANDATORY_ATTRIBUTE_VALUE_NOT_PROVIDED
              + GPAAgreementValidatorConstantsV2.TERM_NAME + adminTermView.getName(),
          new String[]{String.valueOf(adminTermView.getTermId())},
          false);
    } else if (!("Y".equalsIgnoreCase(mandatoryIndicator)) && (termValue == null || termValue.isEmpty())) {
      agreementValidatorResultDTO.setSuccessIndicator(true);
    } else {
      agreementValidatorResultDTO = validateDataTypeWithValue(dataType, termValue, adminTermView);
    }
    return agreementValidatorResultDTO;
  }

  private boolean isNumeric(String s) {
    return s != null && s.matches("-?\\d*\\.?\\d+");
  }

  /**
   * @param dataType is String value
   * @param termValue is TermFacetRestResource
   * @param adminTermView
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   * @throws GPAAgreementValidatorException is agreement validator exception
   */
  private AgreementValidatorResultDTO validateDataTypeWithValue(String dataType, String termValue,
      AdminTermView adminTermView) throws GPAAgreementValidatorException {
    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    agreementValidatorResultDTO.setSuccessIndicator(true);

    if (TermDataType.valueOf(dataType.trim()) == TermDataType.NUMERIC
        && !isNumeric(termValue)) {
      agreementValidatorResultDTO = handleValidationError(GPAAgreementValidatorConstantsV2.CODE_ATTRIBUTE_VALUE_INVALID,
          GPAAgreementValidatorConstantsV2.INVALID_DATE_TIME_FORMAT + GPAAgreementValidatorConstantsV2.TERM_NAME
              + adminTermView.getName() + GPAAgreementValidatorConstantsV2.INVALID_MSG,
          new String[]{String.valueOf(adminTermView.getTermId())},
          false);
    }

    if (StringUtils.isNotBlank(termValue)) {
      if (TermDataType.valueOf(dataType.trim()) == TermDataType.DATE) {
        agreementValidatorResultDTO = validateDate(termValue, adminTermView);
      }
      if (TermDataType.valueOf(dataType.trim()) == TermDataType.DATETIME) {
        agreementValidatorResultDTO = validateDateTime(termValue, adminTermView);
      }
      if (TermDataType.valueOf(dataType.trim()) == TermDataType.TIME) {
        agreementValidatorResultDTO = validateTime(termValue, adminTermView);
      }
    } else {
      agreementValidatorResultDTO = handleValidationError(GPAAgreementValidatorConstantsV2.CODE_ATTRIBUTE_VALUE_INVALID,
          GPAAgreementValidatorConstantsV2.DESC_ATTRIBUTE_VALUE_INVALID,
          new String[]{String.valueOf(adminTermView.getTermId())},
          false);
    }
    return agreementValidatorResultDTO;
  }

  /**
   *
   * This method is used to validate Time
   * @param facetValue is String
   * @param adminTermView
   * @return agreementValidatorResultDTO is  AgreementValidatorResultDTO
   */
  private AgreementValidatorResultDTO validateTime(String facetValue, AdminTermView adminTermView)
      throws GPAAgreementValidatorException {
    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    DateFormat format = new SimpleDateFormat(GPAAgreementValidatorConstantsV2.TIME_FORMAT, Locale.getDefault());
    format.setLenient(false);
    try {
      if (facetValue.trim().length() == 8) {
        format.parse(facetValue);
        agreementValidatorResultDTO.setSuccessIndicator(true);
      } else {
        agreementValidatorResultDTO = handleValidationError(
            GPAAgreementValidatorConstantsV2.CODE_ATTRIBUTE_VALUE_INVALID,
            GPAAgreementValidatorConstantsV2.INVALID_DATE_TIME_FORMAT + GPAAgreementValidatorConstantsV2.TERM_NAME
                + adminTermView.getName() + GPAAgreementValidatorConstantsV2.INVALID_MSG,
            new String[]{String.valueOf(adminTermView.getTermId())},
            false);
      }
    } catch (ParseException e) {
      agreementValidatorResultDTO = handleValidationError(GPAAgreementValidatorConstantsV2.CODE_ATTRIBUTE_VALUE_INVALID,
          GPAAgreementValidatorConstantsV2.INVALID_DATE_TIME_FORMAT + GPAAgreementValidatorConstantsV2.TERM_NAME
              + adminTermView.getName() + GPAAgreementValidatorConstantsV2.INVALID_MSG,
          new String[]{String.valueOf(adminTermView.getTermId())},
          false);
    }
    return agreementValidatorResultDTO;
  }

  /**
   *
   * This method is used to validate DateTime
   * @param facetValue is String
   * @param adminTermView
   * @return agreementValidatorResultDTO is  AgreementValidatorResultDTO
   */
  private AgreementValidatorResultDTO validateDateTime(String facetValue, AdminTermView adminTermView)
      throws GPAAgreementValidatorException {
    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    DateFormat format = new SimpleDateFormat(GPAAgreementValidatorConstantsV2.FACET_DATE_TIME_FORMAT,
        Locale.getDefault());
    format.setLenient(false);
    try {
      if (facetValue.trim().length() == 19) {
        format.parse(facetValue);
        agreementValidatorResultDTO.setSuccessIndicator(true);
      } else {
        agreementValidatorResultDTO = handleValidationError(
            GPAAgreementValidatorConstantsV2.CODE_ATTRIBUTE_VALUE_INVALID,
            GPAAgreementValidatorConstantsV2.INVALID_DATE_TIME_FORMAT + GPAAgreementValidatorConstantsV2.TERM_NAME
                + adminTermView.getName() + GPAAgreementValidatorConstantsV2.INVALID_MSG,
            new String[]{String.valueOf(adminTermView.getTermId())},
            false);
      }
    } catch (ParseException e) {
      agreementValidatorResultDTO = handleValidationError(GPAAgreementValidatorConstantsV2.CODE_ATTRIBUTE_VALUE_INVALID,
          GPAAgreementValidatorConstantsV2.INVALID_DATE_TIME_FORMAT + GPAAgreementValidatorConstantsV2.TERM_NAME
              + adminTermView.getName() + GPAAgreementValidatorConstantsV2.INVALID_MSG,
          new String[]{String.valueOf(adminTermView.getTermId())},
          false);
    }
    return agreementValidatorResultDTO;
  }

  /**
   * This method is used to validate Date
   * @param facetValue is String
   * @param adminTermView
   * @return agreementValidatorResultDTO is  AgreementValidatorResultDTO
   */
  private AgreementValidatorResultDTO validateDate(String facetValue, AdminTermView adminTermView)
      throws GPAAgreementValidatorException {
    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    DateFormat format = new SimpleDateFormat(GPAAgreementValidatorConstantsV2.DATE_FORMAT, Locale.getDefault());
    format.setLenient(false);
    try {
      if (facetValue.trim().length() == 10) {
        format.parse(facetValue);
        agreementValidatorResultDTO.setSuccessIndicator(true);
      } else {
        agreementValidatorResultDTO = handleValidationError(
            GPAAgreementValidatorConstantsV2.CODE_ATTRIBUTE_VALUE_INVALID,
            GPAAgreementValidatorConstantsV2.INVALID_DATE_TIME_FORMAT + GPAAgreementValidatorConstantsV2.TERM_NAME
                + adminTermView.getName() + GPAAgreementValidatorConstantsV2.INVALID_MSG,
            new String[]{String.valueOf(adminTermView.getTermId())},
            false);
      }
    } catch (ParseException e) {
      agreementValidatorResultDTO = handleValidationError(GPAAgreementValidatorConstantsV2.CODE_ATTRIBUTE_VALUE_INVALID,
          GPAAgreementValidatorConstantsV2.INVALID_DATE_TIME_FORMAT + GPAAgreementValidatorConstantsV2.TERM_NAME
              + adminTermView.getName() + GPAAgreementValidatorConstantsV2.INVALID_MSG,
          new String[]{String.valueOf(adminTermView.getTermId())},
          false);
    }
    return agreementValidatorResultDTO;
  }

  /**
   * This method is used to validate mandatory terms present in administration and provided in agreement.
   * @param administrationView is AdministrationView
   * @param agreement is GeneralProductAgreement
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   */
  public AgreementValidatorResultDTO validateMandatoryTerms(AdministrationView administrationView,
      GeneralProductAgreement agreement) {
    final String LOG_METHOD = "validateMandatoryTerms():response:: ";
    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();
    boolean mandatoryTermsPresent = false;
    agreementValidatorResultDTO.setSuccessIndicator(true);
    if (administrationView.getAdminTermViews() != null) {
      for (AdminTermView adminTermView : administrationView.getAdminTermViews()) {
        log.info("{} MandatoryIndicator={}", LOG_METHOD, adminTermView.getMandatoryIndicator());
        if ("Y".equalsIgnoreCase(adminTermView.getMandatoryIndicator())) {
          mandatoryTermsPresent = compareTermIdWithAdministrationTermId(adminTermView, agreement);
        } else {
          mandatoryTermsPresent = true;
        }
        log.info("{} mandatoryTermsPresent={}", LOG_METHOD, mandatoryTermsPresent);
        if (!mandatoryTermsPresent) {
          agreementValidatorResultDTO = handleValidationError(
              GPAAgreementValidatorConstantsV2.CODE_MANDATORY_ATTRIBUTE_NOT_PROVIDED,
              GPAAgreementValidatorConstantsV2.DESC_MANDATORY_ATTRIBUTE_NOT_PROVIDED,
              new String[]{adminTermView.getName()},
              false);
          break;
        }
      }
    }
    return agreementValidatorResultDTO;
  }

  /**
   * @param adminTermView is AdminTermView
   * @param agreement is  GeneralProductAgreement
   * @return boolean value
   */
  private boolean compareTermIdWithAdministrationTermId(AdminTermView adminTermView,
      GeneralProductAgreement agreement) {
    boolean mandatoryTermsPresent = false;
    if (agreement.getTerms() != null) {
      for (Term terms : agreement.getTerms()) {
        if (adminTermView.getMandatoryIndicator() != null
            && terms.getTermId() != null
            && adminTermView.getTermId() == Integer.parseInt(terms.getTermId())
        ) {
          mandatoryTermsPresent = true;
        }
      }
    }
		/*&& terms.getAttributeValue()!=null
		&& !terms.getAttributeValue().trim().isEmpty()*/
    return mandatoryTermsPresent;
  }

  /**
   *
   * This Method is used to fetch details of administration
   * @param agreement is GeneralProductAgreement
   * @return administrationView is AdministrationView
   * @throws GPAAgreementValidatorException is agreement validator exception
   */
  public AdministrationView readAdministration(GeneralProductAgreement agreement)
      throws GPAAgreementValidatorException {
    final String LOG_METHOD = "readAdministration():response:: ";
    AdministrationView administrationView = null;
    try {
      administrationView = administrationdao.readAdministration(0, Integer.parseInt(agreement.getProductId()));
    } catch (GPAAdministrationDAOException gpaAdministrationDAOException) {
      log.error("{} code={} | GPAAdministrationDAOException={}", LOG_METHOD,
          GPAAgreementValidatorLogConstants.LOG_TECHNICAL_EXCEPTION_IN_READ_ADMIN, gpaAdministrationDAOException);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAgreementValidatorMessageKeys.TECHNICAL_EXCEPTION_IN_READ_ADMIN),
          MessageType.getError());
      throw new GPAAgreementValidatorException(messages);
    }
    return administrationView;
  }


  /**
   *
   * This Method is used to set parameters in case of validation failure.
   * @param code is String
   * @param message is String
   * @param paramInfo is list of String
   * @param successIndicator is boolean value
   * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
   */
  public AgreementValidatorResultDTO handleValidationError(String code, String message, String[] paramInfo,
      Boolean successIndicator) {
    AgreementValidatorResultDTO agreementValidatorResultDTO = new AgreementValidatorResultDTO();

    agreementValidatorResultDTO.setCode(code);
    agreementValidatorResultDTO.setMessage(message);
    agreementValidatorResultDTO.setParams(paramInfo);
    agreementValidatorResultDTO.setSuccessIndicator(successIndicator);
    return agreementValidatorResultDTO;
  }

}
