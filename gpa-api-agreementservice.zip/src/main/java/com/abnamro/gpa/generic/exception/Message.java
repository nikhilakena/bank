package com.abnamro.gpa.generic.exception;

import java.io.Serializable;

public final class Message implements Serializable {

    private static final long serialVersionUID = 1L;
    private MessageKey messageKey;
    private String traceId;

    /**
     * Message(MessageKey aMessageKey, String aTraceId) : Constructor with trace id and message key
     *
     * @param aMessageKey : message key being passed
     * @param aTraceId : trace id sent from the service
     */
    public Message(MessageKey aMessageKey, String aTraceId) {
        this.messageKey = aMessageKey;
        this.traceId = aTraceId;
    }

    /**
     * Message(MessageKey aMessageKey) : Constructor without trace id and only with message key
     *
     * @param aMessageKey : message key being passed
     */
    public Message(MessageKey aMessageKey) {
        this.messageKey = aMessageKey;
    }

    public Message(MessageKey validationExceptionInAdminExistingProdInsertNotAllowed, Object[] objects) {
    }

    public MessageKey getMessageKey() {
        return this.messageKey;
    }

    public String toString() {
        return getClass().getName() + "[" + this.messageKey + "]";
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public void setMessageKey(MessageKey messageKey) {
        this.messageKey = messageKey;
    }
}
