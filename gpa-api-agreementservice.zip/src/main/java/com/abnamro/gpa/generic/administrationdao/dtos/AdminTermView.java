/**
 *
 */
package com.abnamro.gpa.generic.administrationdao.dtos;



import java.sql.Timestamp;
import java.util.List;

/**
 * This is a view class which holds the details of Facet
 * @author C45410
 *
 */
public class AdminTermView   {

	/**
	 * This is default serialVersionID
	 */
	private static final long serialVersionUID = 1L;

	private int termId;
	private String name;
	private String dataType;
	private String description ;

	private String mandatoryIndicator;

	private String createdBy;
	private Timestamp createdTimeStamp;
	private String modifiedBy;
	private Timestamp modifiedTimeStamp;

	private List<FacetView> facetView;

	public int getTermId() {
		return termId;
	}

	public void setTermId(int termId) {
		this.termId = termId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMandatoryIndicator() {
		return mandatoryIndicator;
	}

	public void setMandatoryIndicator(String mandatoryIndicator) {
		this.mandatoryIndicator = mandatoryIndicator;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedTimeStamp() {
		return modifiedTimeStamp;
	}

	public void setModifiedTimeStamp(Timestamp modifiedTimeStamp) {
		this.modifiedTimeStamp = modifiedTimeStamp;
	}

	public List<FacetView> getFacetView() {
		return facetView;
	}

	public void setFacetView(List<FacetView> facetView) {
		this.facetView = facetView;
	}
}
