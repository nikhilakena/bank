package com.abnamro.gpa.generic.constant;


import com.abnamro.gpa.generic.exception.MessageKey;

/**
 * @author C45158
 *
 */
public class GPAAgreementValidatorMessageKeys {

	public static final MessageKey TECHNICAL_EXCEPTION_IN_READ_ADMIN = new MessageKey("MESSAGE_AGVAL_001");
	public static final MessageKey INVALID_TIME = new MessageKey("MESSAGE_AGVAL_002");
	public static final MessageKey INVALID_DATE_TIME = new MessageKey("MESSAGE_AGVAL_003");
	public static final MessageKey INVALID_DATE = new MessageKey("MESSAGE_AGVAL_004");
	
	
}
