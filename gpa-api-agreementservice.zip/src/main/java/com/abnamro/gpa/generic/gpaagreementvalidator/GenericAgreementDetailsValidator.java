package com.abnamro.gpa.generic.gpaagreementvalidator;

import com.abnamro.gpa.generic.constant.GPAAgreementValidatorConstants;
import com.abnamro.gpa.generic.constant.GPAAgreementValidatorLogConstants;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class GenericAgreementDetailsValidator {
	private static final Logger logger = LoggerFactory.getLogger(GenericAgreementDetailsValidator.class);


	
	public AgreementValidatorResultDTO validateGenericDetails(GeneralProductAgreement agreement) {
		
		AgreementValidatorResultDTO agreementValidatorResultDTO= new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(true);
		if(StringUtils.isBlank(agreement.getProductId())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_PRODUCT_ID_MANDATORY, 
					GPAAgreementValidatorConstants.DESC_PRODUCT_ID_MANDATORY,
					null,
					false);
			
		}else if(isInvalidProductId(agreement.getProductId())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_PRODUCT_ID_FORMAT_INVALID, 
					GPAAgreementValidatorConstants.DESC_PRODUCT_ID_FORMAT_INVALID,
					null,
					false);
		}else if(StringUtils.isBlank(agreement.getCustomerId())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_CUSTOMER_ID_MANDATORY, 
					GPAAgreementValidatorConstants.DESC_CUSTOMER_ID_MANDATORY,
					null,
					false);
		}else if(isInvalidCustomerId(agreement.getCustomerId())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_CUSTOMER_ID_FORMAT_INVALID, 
					GPAAgreementValidatorConstants.DESC_CUSTOMER_ID_FORMAT_INVALID,
					null,
					false);
		}else if(StringUtils.isBlank(agreement.getAgreementStartDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_AGREEMENT_START_DATE_MANDATORY, 
					GPAAgreementValidatorConstants.DESC_AGREEMENT_START_DATE_MANDATORY,
					null,
					false);
		}else if(agreement.getAgreementStartDate().trim().length()!=19 || isInvalidFormatAgreementDate(agreement.getAgreementStartDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_AGREEMENT_START_DATE_FORMAT_INVALID, 
					GPAAgreementValidatorConstants.DESC_AGREEMENT_START_DATE_FORMAT_INVALID,
					null,
					false);
		}else if(StringUtils.isBlank(agreement.getAgreementEndDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_AGREEMENT_END_DATE_MANDATORY, 
					GPAAgreementValidatorConstants.DESC_AGREEMENT_END_DATE_MANDATORY,
					null,
					false);
		}else if(agreement.getAgreementEndDate().trim().length()!=19 || isInvalidFormatAgreementDate(agreement.getAgreementEndDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_AGREEMENT_END_DATE_FORMAT_INVALID, 
					GPAAgreementValidatorConstants.DESC_AGREEMENT_END_DATE_FORMAT_INVALID,
					null,
					false);
		}/*else if(isInvalidAgreementDate(agreement.getAgreementEndDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_AGREEMENT_END_DATE_IN_PAST, 
					GPAAgreementValidatorConstants.DESC_AGREEMENT_END_DATE_IN_PAST,
					null,
					false);
		}*/else if(isGreaterAgreementEndDate(agreement.getAgreementEndDate(), agreement.getAgreementStartDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_AGREEMENT_START_DATE_END_DATE_COMBINATION_INVALID, 
					GPAAgreementValidatorConstants.DESC_AGREEMENT_START_DATE_END_DATE_COMBINATION_INVALID,
					null,
					false);
		}else {
			agreementValidatorResultDTO = validateTermName(agreement.getTerms());
		}
		return agreementValidatorResultDTO;
	}
	
	
	


	private AgreementValidatorResultDTO validateTermName(List<Term> terms) {

		final String LOG_METHOD = "validateTermName():agreementValidatorResultDTO";
		
		AgreementValidatorResultDTO agreementValidatorResultDTO= new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(true);
		if(terms!=null){
			for(Term term:terms){
				boolean flag = false;
				try {
					if(StringUtils.isBlank(term.getAttributeName())){
						flag= true;
					}
				}catch(NumberFormatException nfe){
					flag= true;
					logger.error(LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_INVALID_TERM_NAME, nfe);
				}
				if(flag){
					agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstants.CODE_ATTRIBUTE_NAME_INVALID, 
							GPAAgreementValidatorConstants.DESC_ATTRIBUTE_NAME_INVALID,
							new String[]{term.getTermId()},
							false);
					break;
				}
			}
		}
		
		return agreementValidatorResultDTO;
	
	}


	private boolean isGreaterAgreementEndDate(String agreementEndDate, String agreementStartDate) {
		
		final String LOG_METHOD = "isGreaterAgreementEndDate():response";
		
		boolean flag= false;
		
		DateFormat format = new SimpleDateFormat(GPAAgreementValidatorConstants.DATE_TIME_FORMAT);
		
		java.util.Date startDate=new Timestamp(System.currentTimeMillis());
		java.util.Date endDate=new Timestamp(System.currentTimeMillis());
		
		
		try {
			startDate = format.parse(agreementStartDate);
		} catch (ParseException e) {
			logger.error(LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_PARSE_DATE, e);
		}
		try {
			endDate = format.parse(agreementEndDate);
		} catch (ParseException e) {
			logger.error(LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_PARSE_DATE, e);
		}
		
		if(endDate.compareTo(startDate)<=0){
			flag=true;
		}
		
		
		return flag;
	}



	private boolean isInvalidFormatAgreementDate(String agreementDate) {
		final String LOG_METHOD = "isInvalidFormatAgreementDate():boolean";
		
		boolean flag= true;
		if(agreementDate!=null){
			try {
				DateFormat format = new SimpleDateFormat(GPAAgreementValidatorConstants.DATE_TIME_FORMAT, Locale.getDefault());
				format.setLenient(false);
				format.parse(agreementDate);
				flag = false;
			} catch (ParseException e) {
				logger.error(LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_PARSE_DATE, e);
			}
		}
		return flag;
	}
	
	private boolean isInvalidAgreementDate(String date) {
		
		final String LOG_METHOD = "isInvalidAgreementDate():boolean";
		
		boolean flag= false;
		
		DateFormat format = new SimpleDateFormat(GPAAgreementValidatorConstants.DATE_TIME_FORMAT);
		format.setLenient(false);
		
		java.util.Date currentDate=new Timestamp(System.currentTimeMillis());
		java.util.Date agreementStartDateTemp=new Timestamp(System.currentTimeMillis());
		try {
			agreementStartDateTemp = format.parse(date);
		} catch (ParseException e) {
			
			logger.error(LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_PARSE_DATE, e);
		}
		if(agreementStartDateTemp.compareTo(currentDate)<=0){
			flag=true;
		}
		return flag;
	}


	private boolean isInvalidCustomerId(String customerId) {
		final String LOG_METHOD = "isInvalidCustomerId():boolean";
		boolean flag= true;
		if(customerId!=null
				&& StringUtils.isNumeric(customerId)
				&& customerId.length()<=12){
			try{
				if(Long.parseLong(customerId)>0){
					flag = false;
				}
			}catch(NumberFormatException nfe){
				logger.error(LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_INVALID_CUSTOMER_ID, nfe);
			}
		}
		return flag;
	}


	private boolean isInvalidProductId(String productId) {
		boolean flag= true;
		if(StringUtils.isNumeric(productId)){
			flag = false;
		}
		return flag;
	}


	/**
	 * 
	 * This Method is used to set parameters in case of validation failure.
	 * @param code is String
	 * @param message is String
	 * @param paramInfo is list of String
	 * @param successIndicator is boolean value
	 * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
	 */
	public AgreementValidatorResultDTO handleValidationError(String code, String message, String[] paramInfo, Boolean successIndicator) {
		AgreementValidatorResultDTO agreementValidatorResultDTO= new AgreementValidatorResultDTO();
		
		agreementValidatorResultDTO.setCode(code);
		agreementValidatorResultDTO.setMessage(message);
		agreementValidatorResultDTO.setParams(paramInfo);
		agreementValidatorResultDTO.setSuccessIndicator(successIndicator);
		
		return agreementValidatorResultDTO;
		
	}
}
