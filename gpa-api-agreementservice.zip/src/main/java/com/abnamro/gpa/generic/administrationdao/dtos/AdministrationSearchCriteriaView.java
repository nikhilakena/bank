package com.abnamro.gpa.generic.administrationdao.dtos;

import java.sql.Timestamp;

/**
 * This is a Search Criteria DTO class used as input in administration Search
 * @author C45410
 *
 */
public class AdministrationSearchCriteriaView {

	private int administrationId;

	private String administrationName;

	private String oarId;

	private String createdBy;

	private Timestamp createdTimestampFrom;

	private Timestamp createdTimestampTo ;

	public int getAdministrationId() {
		return administrationId;
	}

	public void setAdministrationId(int administrationId) {
		this.administrationId = administrationId;
	}

	public String getAdministrationName() {
		return administrationName;
	}

	public void setAdministrationName(String administrationName) {
		this.administrationName = administrationName;
	}

	public String getOarId() {
		return oarId;
	}

	public void setOarId(String oarId) {
		this.oarId = oarId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedTimestampFrom() {
		return createdTimestampFrom;
	}

	public void setCreatedTimestampFrom(Timestamp createdTimestampFrom) {
		this.createdTimestampFrom = createdTimestampFrom;
	}

	public Timestamp getCreatedTimestampTo() {
		return createdTimestampTo;
	}

	public void setCreatedTimestampTo(Timestamp createdTimestampTo) {
		this.createdTimestampTo = createdTimestampTo;
	}
}
