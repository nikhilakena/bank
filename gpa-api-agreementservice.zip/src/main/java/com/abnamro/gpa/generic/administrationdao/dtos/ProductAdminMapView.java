/**
 *
 */
package com.abnamro.gpa.generic.administrationdao.dtos;



import java.sql.Timestamp;

/**
 * This is a view class which holds the details of Facet
 * @author C45410
 *
 */
public class ProductAdminMapView   {

	/**
	 * This is default serialVersionID
	 */
	private static final long serialVersionUID = 1L;

	private int productId;
	private String createdBy;
	private Timestamp createdTimeStamp;
	private String modifiedBy;
	private Timestamp modifiedTimeStamp;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedTimeStamp() {
		return modifiedTimeStamp;
	}

	public void setModifiedTimeStamp(Timestamp modifiedTimeStamp) {
		this.modifiedTimeStamp = modifiedTimeStamp;
	}
}
