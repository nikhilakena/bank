package com.abnamro.gpa.generic.gpaagreementdao.dao;

import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.ContractHeaderStatusType;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.CreateContractHeaderInputDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.dto.UpdateContractHeaderInputDTO;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.exceptions.ContractHeaderServiceInvokerException;
import com.abnamro.gpa.generic.contractheaderserviceinvoker.v2.ContractHeaderUtilV2;
import com.abnamro.gpa.generic.exception.Message;
import com.abnamro.gpa.generic.exception.MessageType;
import com.abnamro.gpa.generic.exception.Messages;
import com.abnamro.gpa.generic.gpaagreementdao.constants.GPAAgreementDAOConstants;
import com.abnamro.gpa.generic.gpaagreementdao.constants.GPAAgreementDAOLogConstants;
import com.abnamro.gpa.generic.gpaagreementdao.constants.GPAAgreementDAOMessageKeys;
import com.abnamro.gpa.generic.gpaagreementdao.dtos.GPAAgreementDTO;
import com.abnamro.gpa.generic.gpaagreementdao.exception.GPAAgreementDAOException;
import com.abnamro.gpa.generic.gpaagreementdao.helper.GPAAgreementDaoViewMapper;
import com.abnamro.gpa.generic.gpaagreementdao.view.GPAAgreementTermView;
import com.abnamro.gpa.generic.gpaagreementdao.view.GPAAgreementView;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This is dao layer class for GPA Agreement and has operation related to Agreement.
 */
@Slf4j
@Component
public class GPAAgreementDAOV2 {

  @Autowired
  private GPAAgreementDaoViewMapper gpaAgreementViewMapper;

  @Autowired
  private ContractHeaderUtilV2 util;

  @Autowired
  private SqlSessionFactory sessionFactory;


  /**
   * This method is used to create Agreement
   *
   * @param traceId      for tracing purpose
   * @param agreementDTO is GPAAgreementDTO
   * @throws GPAAgreementDAOException is an exception
   */
  public void createGPAAgreement(String traceId, GPAAgreementDTO agreementDTO) throws GPAAgreementDAOException {

    final String LOG_METHOD = "createGPAAgreement():response:: ";
    agreementDTO.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
    if (validateAttributesLength(agreementDTO)) {
      try (SqlSession sqlSession = sessionFactory.openSession()) {

        GPAAgreementView agreementView = gpaAgreementViewMapper.covertToAgreementView(agreementDTO);

        sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class).insertAgreement(agreementView);

        for (GPAAgreementTermView agreementTermView : agreementView.getTerms()) {
          sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class).insertAgreementTermData(
              agreementDTO.getAgreementId(), agreementTermView);
        }

        createContractHeader(agreementDTO, traceId);


      } catch (PersistenceException exception) {
        Messages messages = handleDuplicateKeyExceptionInCreateAgreement(LOG_METHOD, exception);
        throw new GPAAgreementDAOException(messages);
      }
    } else {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAgreementDAOMessageKeys.INVALID_LENGTH_PARAMS_EXCEPTION_WHILE_CREATING_AGREEMENT),
          MessageType.getError());
      log.error("{} Invalid params length exception occurred while create agreement ={}", LOG_METHOD,
          GPAAgreementDAOLogConstants.LOG_ERROR_INVALID_LENGTH_PARAMS);
      throw new GPAAgreementDAOException(messages);
    }

  }

  private Messages handleDuplicateKeyExceptionInCreateAgreement(String logMethod, Exception exception) {
    Messages messages = new Messages();

    if (exception.getCause() instanceof SQLServerException) {
      SQLException sqlException = (SQLException) exception.getCause();
      log.error("{} Exception occurred with error code={}", logMethod, sqlException.getErrorCode());
      if (sqlException.getErrorCode() == 2627) {
        messages.addMessage(
            new Message(GPAAgreementDAOMessageKeys.DUPLICATE_KEY_EXCEPTION_WHILE_CREATING_AGREEMENT_DETAILS),
            MessageType.getError());
        log.error("{} Duplicate key exception occurred while creating agreement details={} | exception={}", logMethod,
            GPAAgreementDAOLogConstants.LOG_ERROR_DUPLICATE_AGREEMENTID_CREATE_AGREEMENT, exception);
      }
    } else {
      messages.addMessage(new Message(GPAAgreementDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_CREATING_AGREEMENT),
          MessageType.getError());
      log.error("{} Exception occurred while creating agreement={} | exception={}", logMethod, GPAAgreementDAOLogConstants.LOG_ERROR_DATA_CREATE,
          exception);
    }
    return messages;
  }

  private void createContractHeader(GPAAgreementDTO agreementDTO, String traceId) throws GPAAgreementDAOException {
    final String LOG_METHOD = "createContractHeader():response:: ";
    try {
      // Call ContractHeaderServiceInvoker(MO503) for creating con//tract
      // header
      CreateContractHeaderInputDTO contractHeaderInputDTO = setCreateContractHeaderInput(agreementDTO);
      String chCreateDetails = util.createContractHeader(traceId, contractHeaderInputDTO);
      log.info("{} Retrieving contractHeaderId from connector createAgreementCustomerReference method={}", LOG_METHOD, chCreateDetails);
    } catch (ContractHeaderServiceInvokerException contractHeaderServiceInvokerException) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAgreementDAOMessageKeys.DATABASE_EXCEPTION_WHILE_CREATING_CONTRACTHEADER),
          MessageType.getError());
      log.error("{} Exception occurred while creating contract header={} | ContractHeaderServiceInvokerException={}", LOG_METHOD,
          GPAAgreementDAOLogConstants.LOG_ERROR_DB_CONNECTION, contractHeaderServiceInvokerException);
      throw new GPAAgreementDAOException(messages);
    }
  }

  private CreateContractHeaderInputDTO setCreateContractHeaderInput(GPAAgreementDTO agreementDTO) {
    CreateContractHeaderInputDTO contractHeaderInputDTO = new CreateContractHeaderInputDTO();
    contractHeaderInputDTO.setBcNumber(agreementDTO.getCustomerId());
    contractHeaderInputDTO.setCommercialContractNumber(String.valueOf(agreementDTO.getAgreementId()));
    contractHeaderInputDTO.setProductId(agreementDTO.getProductId());

    // If status of an GPA agreement is active & startdate is less or equal
    // then current date
    // then set status as active else set status as inActive
    // compare date instead of Timestamp
    if (GPAAgreementDAOConstants.AGREEMENT_STATUS_ACTIVE.equals(agreementDTO.getStatus())
        && isDateBeforeCurrentDate(new Date(agreementDTO.getStartDate().getTime()), new Date())) {
      contractHeaderInputDTO.setContractStatus(ContractHeaderStatusType.ACTIVE);
    } else {
      contractHeaderInputDTO.setContractStatus(ContractHeaderStatusType.INACTIVE);
    }
    return contractHeaderInputDTO;
  }

  private boolean isDateBeforeCurrentDate(Date date1, Date date2) {
    return (DateUtils.isSameDay(date1, date2) || date1.before(date2));
  }

  /**
   * This method is used to validate length of all attributes
   *
   * @param agreementDTO is GPAAgreementDTO
   * @return lengthValidated is boolean value
   */
  private boolean validateAttributesLength(GPAAgreementDTO agreementDTO) {
    boolean lengthValidated = true;
    boolean validateAuditParamsLength = validateStringParamLength(agreementDTO.getCreatedBy(), 8)
        || validateStringParamLength(agreementDTO.getUpdatedBy(), 8);
    boolean validateProductAndCustomerId = Integer.toString(agreementDTO.getProductId()).length() > 9
        || Long.toString(agreementDTO.getCustomerId()).length() > 12;
    if (Long.toString(agreementDTO.getAgreementId()).length() > 10 || validateProductAndCustomerId
        || validateStringParamLength(agreementDTO.getStatus(), 10) || validateAuditParamsLength) {
      lengthValidated = false;
    }
    return lengthValidated;
  }

  private boolean validateStringParamLength(String param, int maxLength) {
    boolean stringValidated = false;
    if (StringUtils.isNotBlank(param) && param.length() > maxLength) {
      stringValidated = true;
    }
    return stringValidated;
  }

  /**
   * This operation is used to retrieve existing gpa agreements from database
   *
   * @param agreementId in CIN format
   * @return GPAAgreementDTO containing agreement details
   * @throws GPAAgreementDAOException in case of errors
   */
  public GPAAgreementDTO readGPAAgreement(String agreementId) throws GPAAgreementDAOException {

    final String LOG_METHOD = "readGPAAgreement():response:: ";
    GPAAgreementDTO gPAAgreementDTO = null;
    try (SqlSession sqlSession = sessionFactory.openSession()) {

      GPAAgreementView agreementView = sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)
          .readGPAAgreement(Long.valueOf(agreementId));

      gPAAgreementDTO = gpaAgreementViewMapper.covertToGPAAgreementDTO(agreementView);


    } catch (PersistenceException exception) {

      Messages messages = new Messages();
      messages.addMessage(new Message(GPAAgreementDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_READING_AGREEMENT),
          MessageType.getError());
      log.error("{} Exception occurred while reading agreement={} | PersistenceException={}", LOG_METHOD,
          GPAAgreementDAOLogConstants.LOG_ERROR_DATA_READ, exception);
      throw new GPAAgreementDAOException(messages);
    }
    return gPAAgreementDTO;
  }

  /**
   * This method is used to update Agreement
   *
   * @param traceId      used for tracing purpose
   * @param agreementDTO is GPAAgreementDTO
   * @throws GPAAgreementDAOException is an exception
   */
  public void updateGPAAgreement(String traceId, GPAAgreementDTO agreementDTO) throws GPAAgreementDAOException {

    final String LOG_METHOD = "updateGPAAgreement():response:: ";
    agreementDTO.setUpdatedTimeStamp(new Timestamp(System.currentTimeMillis()));
    if (validateAttributesLength(agreementDTO)) {
      try (SqlSession sqlSession = sessionFactory.openSession()) {

        boolean moTobeUpdated = checkIfStatusUpdated(agreementDTO);

        GPAAgreementView agreementView = gpaAgreementViewMapper.covertToAgreementView(agreementDTO);

        sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class).updateAgreement(agreementView);

        updateAgreementTermData(sqlSession, agreementView);

        // update contract header only if agreement status is changed
        if (moTobeUpdated) {
          updateContractHeader(agreementDTO, traceId);
        }


      } catch (PersistenceException exception) {
        Messages messages = handleDuplicateKeyExceptionInUpdateAgreement(LOG_METHOD, exception);
        throw new GPAAgreementDAOException(messages);
      }
    } else {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAgreementDAOMessageKeys.INVALID_LENGTH_PARAMS_EXCEPTION_WHILE_UPDATING_AGREEMENT),
          MessageType.getError());
      log.error("{} Invalid param length exception occurred while updating agreement={}", LOG_METHOD,
          GPAAgreementDAOLogConstants.LOG_ERROR_INVALID_LENGTH_PARAMS);
      throw new GPAAgreementDAOException(messages);
    }

  }

  private Messages handleDuplicateKeyExceptionInUpdateAgreement(String logMethod, Exception exception) {
    Messages messages = new Messages();
    if (exception.getCause() instanceof SQLServerException) {
      SQLException sqlException = (SQLException) exception.getCause();
      log.error("{} SQLException occurred  with ErrorCode={}", logMethod, sqlException.getErrorCode());
      if (sqlException.getErrorCode() == 2627) {
        messages.addMessage(
            new Message(GPAAgreementDAOMessageKeys.DUPLICATE_KEY_EXCEPTION_WHILE_UPDATING_AGREEMENT_DETAILS),
            MessageType.getError());
        log.error("{} Duplicate key exception occurred while updating agreement details={} | exception={}", logMethod,
            GPAAgreementDAOLogConstants.LOG_ERROR_DUPLICATE_AGREEMENTID_UPATE_AGREEMENT, exception);
      }
    } else {
      messages.addMessage(new Message(GPAAgreementDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_UPATING_AGREEMENT),
          MessageType.getError());
      log.error("{} Mybatis exception occurred while updating agreement={} | exception={}", logMethod, GPAAgreementDAOLogConstants.LOG_ERROR_DATA_UPDATE,
          exception);
    }
    return messages;
  }

  private boolean checkIfStatusUpdated(GPAAgreementDTO agreementDTO) throws GPAAgreementDAOException {
    final String LOG_METHOD = "checkIfStatusUpdated():response:: ";
    boolean indicatorStatusUpdated = false;
    ContractHeaderStatusType contractStatusDB;
    ContractHeaderStatusType contractStatusInput;
    try {
      // read agreement status from database
      GPAAgreementDTO agreement = readGPAAgreement(String.valueOf(agreementDTO.getAgreementId()));

      // convert agreement status to MO mapped status
      // If status of an GPA agreement is active & start date is less or
      // equal then current date
      // then set status as active else set status as inActive
      if (agreement != null) {
        if (GPAAgreementDAOConstants.AGREEMENT_STATUS_ACTIVE.equals(agreement.getStatus())
            && (agreement.getStartDate().before(new Timestamp(System.currentTimeMillis())) || DateUtils
            .isSameDay(agreement.getStartDate(), new Timestamp(System.currentTimeMillis())))) {
          contractStatusDB = ContractHeaderStatusType.ACTIVE;
        } else {
          contractStatusDB = ContractHeaderStatusType.INACTIVE;
        }

        // get the status from update input and convert it to MO mapped
        // status
        if (GPAAgreementDAOConstants.AGREEMENT_STATUS_ACTIVE.equals(agreementDTO.getStatus())
            && (agreementDTO.getStartDate().before(new Timestamp(System.currentTimeMillis())) || DateUtils
            .isSameDay(agreementDTO.getStartDate(), new Timestamp(System.currentTimeMillis())))) {
          contractStatusInput = ContractHeaderStatusType.ACTIVE;
        } else {
          contractStatusInput = ContractHeaderStatusType.INACTIVE;
        }

        // If both the status are equal then return false else true
        if (!contractStatusDB.getValue().equalsIgnoreCase(contractStatusInput.getValue())) {
          indicatorStatusUpdated = true;
        }
      }
    } catch (GPAAgreementDAOException gpaAgreementDAOException) {
      Messages messages = new Messages();
      messages.addMessage(new Message(GPAAgreementDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_READING_AGREEMENT),
          MessageType.getError());
      log.error("{} Mybatis exception occurred while reading agreement={} | GPAAgreementDAOException={}", LOG_METHOD,
          GPAAgreementDAOLogConstants.LOG_ERROR_DB_CONNECTION, gpaAgreementDAOException);
      throw new GPAAgreementDAOException(messages);
    }
    return indicatorStatusUpdated;
  }

  private void updateContractHeader(GPAAgreementDTO agreementDTO, String traceId) throws GPAAgreementDAOException {
    final String LOG_METHOD = "updateContractHeader():response:: ";
    try {
      // Call ContractHeaderServiceInvoker(MO504) for updating contract
      // header

      UpdateContractHeaderInputDTO contractHeaderInputDTO = setUpdateContractHeaderInput(agreementDTO);
      util.updateContractHeader(traceId, contractHeaderInputDTO);
    } catch (ContractHeaderServiceInvokerException contractHeaderServiceInvokerException) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAgreementDAOMessageKeys.DATABASE_EXCEPTION_WHILE_UPDATING_CONTRACTHEADER),
          MessageType.getError());
      log.error("{} Database exception occurred while updating contract header={} | ContractHeaderServiceInvokerException={}", LOG_METHOD,
          GPAAgreementDAOLogConstants.LOG_ERROR_DB_CONNECTION, contractHeaderServiceInvokerException);
      throw new GPAAgreementDAOException(messages);
    }
  }

  private UpdateContractHeaderInputDTO setUpdateContractHeaderInput(GPAAgreementDTO agreementDTO) {
    UpdateContractHeaderInputDTO contractHeaderInputDTO = new UpdateContractHeaderInputDTO();
    contractHeaderInputDTO.setBcNumber(agreementDTO.getCustomerId());
    contractHeaderInputDTO.setCommercialContractNumber(String.valueOf(agreementDTO.getAgreementId()));
    contractHeaderInputDTO.setProductId(agreementDTO.getProductId());

    // If status of an GPA agreement is active & startdate is less or equal
    // then current date
    // then set status as active else set status as inActive
    if (GPAAgreementDAOConstants.AGREEMENT_STATUS_ACTIVE.equals(agreementDTO.getStatus())
        && (agreementDTO.getStartDate().before(new Timestamp(System.currentTimeMillis())) || DateUtils
        .isSameDay(agreementDTO.getStartDate(), new Timestamp(System.currentTimeMillis())))) {
      contractHeaderInputDTO.setContractStatus(ContractHeaderStatusType.ACTIVE);
    } else {
      contractHeaderInputDTO.setContractStatus(ContractHeaderStatusType.INACTIVE);
    }
    return contractHeaderInputDTO;
  }

  private void updateAgreementTermData(SqlSession sqlSession, GPAAgreementView agreementView) {
    int currentRecordCount = sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)
        .getNoOfDataRecords(agreementView.getAgreementId());

    if (agreementView.getTerms() != null) {
      if (currentRecordCount <= agreementView.getTerms().size()) {
        for (int i = 0; i < currentRecordCount; i++) {
          sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class).updateAgreementTermData(
              agreementView.getAgreementId(), agreementView.getTerms().get(i));
        }
        for (int j = currentRecordCount; j < agreementView.getTerms().size(); j++) {
          agreementView.getTerms().get(j).setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));
          agreementView.getTerms().get(j).setCreatedBy(agreementView.getTerms().get(j).getUpdatedBy());
          sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class).insertAgreementTermData(
              agreementView.getAgreementId(), agreementView.getTerms().get(j));
        }
      }
      if (currentRecordCount > agreementView.getTerms().size()) {
        for (int i = 0; i < agreementView.getTerms().size(); i++) {
          sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class).updateAgreementTermData(
              agreementView.getAgreementId(), agreementView.getTerms().get(i));
        }
        for (int j = agreementView.getTerms().size(); j < currentRecordCount; j++) {
          sqlSession.getMapper(GPAAgreementDAOMybatisMapper.class)
              .deleteAgreementTermData(agreementView.getAgreementId(), j);
        }
      }
    }

  }

}
