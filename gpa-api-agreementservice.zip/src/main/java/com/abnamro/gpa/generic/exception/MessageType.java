package com.abnamro.gpa.generic.exception;

public enum MessageType {

    WARNING("WARNING", 0), ERROR("ERROR", 1), INFO("INFO", 2), AUDIT("AUDIT",
            3), UNDEFINED("UNDEFINED", 4);

    private int code;
    private String codeLabel;

    MessageType(String codeLabel, int code) {
        this.code = code;
        this.codeLabel = codeLabel;
    }

    public static MessageType getWarning() {
        return MessageType.WARNING;
    }

    public static MessageType getError() {
        return MessageType.ERROR;
    }

    public static MessageType getInfo() {
        return MessageType.INFO;
    }

    public static MessageType getAudit() {
        return MessageType.AUDIT;
    }

    public static MessageType getUndefined() {
        return MessageType.UNDEFINED;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getCodeLabel() {
        return codeLabel;
    }

    public void setCodeLabel(String codeLabel) {
        this.codeLabel = codeLabel;
    }
}

