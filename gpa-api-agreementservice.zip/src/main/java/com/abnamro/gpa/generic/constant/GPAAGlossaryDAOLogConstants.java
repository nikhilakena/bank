package com.abnamro.gpa.generic.constant;

public class GPAAGlossaryDAOLogConstants {	public static final String LOG_ERROR_IBATIS_INITIALIZATION = "LOG_GPGLDA_001";

    public static final String LOG_ERROR_DATA_CREATE = "LOG_GPGLDA_002";

    public static final String LOG_ERROR_DB_CONNECTION = "LOG_GPGLDA_003";

    public static final String LOG_ERROR_SQL_ERROR = "LOG_GPGLDA_004";

    public static final String LOG_ERROR_DATA_RETRIEVE_MAX_TERM_ID = "LOG_GPGLDA_005";

    public static final String LOG_ERROR_DATA_DELETION = "LOG_GPGLDA_006";

    public static final String LOG_PERSISTENCE_EXCEPTION_ERROR_SERVICE_DELETE="LOG_GPGLDA_007";

    public static final String LOG_ERROR_THIS_TERM_IS_ALREADY_USED_BY_AN_ADMINISTRATION="LOG_GPGLDA_008";

    public static final String LOG_ERROR_DATA_UPDATE = "LOG_GPGLDA_009";

}
