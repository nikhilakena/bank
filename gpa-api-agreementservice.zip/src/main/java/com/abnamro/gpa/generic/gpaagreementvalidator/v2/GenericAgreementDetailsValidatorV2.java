package com.abnamro.gpa.generic.gpaagreementvalidator.v2;

import com.abnamro.gpa.generic.constant.GPAAgreementValidatorLogConstants;
import com.abnamro.gpa.generic.constant.v2.GPAAgreementValidatorConstantsV2;
import com.abnamro.gpa.generic.gpaagreementvalidator.dto.AgreementValidatorResultDTO;
import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * This class is designed for API-V2
 * @author C45158
 *
 */
@Slf4j
public class GenericAgreementDetailsValidatorV2 {

	/**
	 * This method is used to perform generic validations
	 * @param agreement as GeneralProductAgreement
	 * @return agreementValidatorResultDTO as AgreementValidatorResultDTO
	 */
	public AgreementValidatorResultDTO validateGenericDetails(GeneralProductAgreement agreement) {

		AgreementValidatorResultDTO agreementValidatorResultDTO= new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(true);
		if(StringUtils.isBlank(agreement.getProductId())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstantsV2.CODE_PRODUCT_ID_MANDATORY,
					GPAAgreementValidatorConstantsV2.DESC_PRODUCT_ID_MANDATORY,
					null,
					false);

		}else if(isInvalidProductId(agreement.getProductId())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstantsV2.CODE_PRODUCT_ID_FORMAT_INVALID,
					GPAAgreementValidatorConstantsV2.DESC_PRODUCT_ID_FORMAT_INVALID,
					null,
					false);
		}else if(StringUtils.isBlank(agreement.getCustomerId())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstantsV2.CODE_CUSTOMER_ID_MANDATORY,
					GPAAgreementValidatorConstantsV2.DESC_CUSTOMER_ID_MANDATORY,
					null,
					false);
		}else if(isInvalidCustomerId(agreement.getCustomerId())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstantsV2.CODE_CUSTOMER_ID_FORMAT_INVALID,
					GPAAgreementValidatorConstantsV2.DESC_CUSTOMER_ID_FORMAT_INVALID,
					null,
					false);
		}else if(StringUtils.isBlank(agreement.getAgreementStartDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstantsV2.CODE_AGREEMENT_START_DATE_MANDATORY,
					GPAAgreementValidatorConstantsV2.DESC_AGREEMENT_START_DATE_MANDATORY,
					null,
					false);
		}else if(agreement.getAgreementStartDate().trim().length()!=24 || isInvalidFormatAgreementDate(agreement.getAgreementStartDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstantsV2.CODE_AGREEMENT_START_DATE_FORMAT_INVALID,
					GPAAgreementValidatorConstantsV2.DESC_AGREEMENT_START_DATE_FORMAT_INVALID,
					null,
					false);
		}else if(StringUtils.isBlank(agreement.getAgreementEndDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstantsV2.CODE_AGREEMENT_END_DATE_MANDATORY,
					GPAAgreementValidatorConstantsV2.DESC_AGREEMENT_END_DATE_MANDATORY,
					null,
					false);
		}else if(agreement.getAgreementEndDate().trim().length()!=24 || isInvalidFormatAgreementDate(agreement.getAgreementEndDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstantsV2.CODE_AGREEMENT_END_DATE_FORMAT_INVALID,
					GPAAgreementValidatorConstantsV2.DESC_AGREEMENT_END_DATE_FORMAT_INVALID,
					null,
					false);
		}else if(isGreaterAgreementEndDate(agreement.getAgreementEndDate(), agreement.getAgreementStartDate())){
			agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstantsV2.CODE_AGREEMENT_START_DATE_END_DATE_COMBINATION_INVALID,
					GPAAgreementValidatorConstantsV2.DESC_AGREEMENT_START_DATE_END_DATE_COMBINATION_INVALID,
					null,
					false);
		}else {
			agreementValidatorResultDTO = validateTermName(agreement.getTerms());
		}
		return agreementValidatorResultDTO;
	}





	private AgreementValidatorResultDTO validateTermName(List<Term> terms) {
		final String LOG_METHOD = "validateTermName():response:: ";
		AgreementValidatorResultDTO agreementValidatorResultDTO= new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setSuccessIndicator(true);
		if(terms!=null){
			for(Term term:terms){
				boolean flag = false;
				try {
					if(StringUtils.isBlank(term.getAttributeName())){
						flag= true;
					}
				}catch(NumberFormatException nfe){
					flag= true;
					log.error("{} Exception occurred when invalid term name={} | NumberFormatException={}",LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_INVALID_TERM_NAME, nfe);
				}
				if(flag){
					agreementValidatorResultDTO =handleValidationError(GPAAgreementValidatorConstantsV2.CODE_ATTRIBUTE_NAME_INVALID,
							GPAAgreementValidatorConstantsV2.DESC_ATTRIBUTE_NAME_INVALID,
							new String[]{term.getTermId()},
							false);
					break;
				}
			}
		}
		return agreementValidatorResultDTO;
	}


	private boolean isGreaterAgreementEndDate(String agreementEndDate, String agreementStartDate) {
		final String LOG_METHOD = "isGreaterAgreementEndDate():response:: ";
		boolean flag= false;
		DateFormat format = new SimpleDateFormat(GPAAgreementValidatorConstantsV2.DATE_TIME_FORMAT, Locale.getDefault());
		java.util.Date startDate=new Timestamp(System.currentTimeMillis());
		java.util.Date endDate=new Timestamp(System.currentTimeMillis());
		try {
			startDate = format.parse(agreementStartDate);
		} catch (ParseException e) {
			log.error("{} Exception occurred while parsing start date={} | ParseException for agreementStartDate={}",LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_PARSE_DATE, e);
		}
		try {
			endDate = format.parse(agreementEndDate);
		} catch (ParseException e) {
			log.error("{} Exception occurred while parsing end date={} | ParseException for agreementEndDate={}",LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_PARSE_DATE, e);
		}
		if(endDate.compareTo(startDate)<=0){
			flag=true;
		}
		return flag;
	}



	private boolean isInvalidFormatAgreementDate(String agreementDate) {
		final String LOG_METHOD = "isInvalidFormatAgreementDate():response:: ";
		boolean flag= true;
		Pattern pattern = Pattern.compile("\\s");
		Matcher matcher = pattern.matcher(agreementDate);
		boolean whiteSpaceFound = matcher.find();
		if(!whiteSpaceFound){
		    flag = false;
		}
		if(agreementDate!=null){
			try {
				DateFormat format = new SimpleDateFormat(GPAAgreementValidatorConstantsV2.DATE_TIME_FORMAT, Locale.getDefault());
				format.setLenient(false);
				format.parse(agreementDate.replaceAll("\\s+",""));
				flag = false;
			} catch (ParseException e) {
				log.error("{} Exception occurred while checking agreement date format={} | ParseException={}",LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_PARSE_DATE, e);
			}
		}
		return flag;
	}

	private boolean isInvalidCustomerId(String customerId) {
		final String LOG_METHOD = "isInvalidCustomerId():response:: ";
		boolean flag= true;
		if(customerId!=null
				&& StringUtils.isNumeric(customerId)
				&& customerId.length()<=12){
			try{
				if(Long.parseLong(customerId)>0){
					flag = false;
				}
			}catch(NumberFormatException nfe){
				log.error("{} Exception occurred while invalid consumer id={} | NumberFormatException={}",LOG_METHOD, GPAAgreementValidatorLogConstants.LOG_INVALID_CUSTOMER_ID, nfe);
			}
		}
		return flag;
	}


	private boolean isInvalidProductId(String productId) {
		boolean flag= true;
		if(StringUtils.isNumeric(productId)){
			flag = false;
		}
		return flag;
	}


	/**
	 *
	 * This Method is used to set parameters in case of validation failure.
	 * @param code is String
	 * @param message is String
	 * @param paramInfo is list of String
	 * @param successIndicator is boolean value
	 * @return agreementValidatorResultDTO is AgreementValidatorResultDTO
	 */
	public AgreementValidatorResultDTO handleValidationError(String code, String message, String[] paramInfo, Boolean successIndicator) {
		AgreementValidatorResultDTO agreementValidatorResultDTO= new AgreementValidatorResultDTO();
		agreementValidatorResultDTO.setCode(code);
		agreementValidatorResultDTO.setMessage(message);
		agreementValidatorResultDTO.setParams(paramInfo);
		agreementValidatorResultDTO.setSuccessIndicator(successIndicator);
		return agreementValidatorResultDTO;
	}
}
