/**
 *
 */
package com.abnamro.gpa.generic.administrationdao.dtos;


import java.sql.Timestamp;
import java.util.List;

/**
 * This is a view class which holds the details of administration
 * @author C45410
 *
 */
public class AdministrationView {

  /**
   * This is default serialVersionID
   */
  private static final long serialVersionUID = 1L;

  private int id;
  private String name;
  private String oarId;
  private String description;
  private String createdBy;
  private Timestamp createdTimeStamp;
  private String modifiedBy;
  private Timestamp modifiedTimeStamp;

  private List<ProductAdminMapView> ProductAdminMapViews;

  private List<AdminTermView> adminTermViews;

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getOarId() {
    return oarId;
  }

  public void setOarId(String oarId) {
    this.oarId = oarId;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Timestamp getCreatedTimeStamp() {
    return createdTimeStamp;
  }

  public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
    this.createdTimeStamp = createdTimeStamp;
  }

  public String getModifiedBy() {
    return modifiedBy;
  }

  public void setModifiedBy(String modifiedBy) {
    this.modifiedBy = modifiedBy;
  }

  public Timestamp getModifiedTimeStamp() {
    return modifiedTimeStamp;
  }

  public void setModifiedTimeStamp(Timestamp modifiedTimeStamp) {
    this.modifiedTimeStamp = modifiedTimeStamp;
  }

  public List<ProductAdminMapView> getProductAdminMapViews() {
    return ProductAdminMapViews;
  }

  public void setProductAdminMapViews(List<ProductAdminMapView> productAdminMapViews) {
    ProductAdminMapViews = productAdminMapViews;
  }

  public List<AdminTermView> getAdminTermViews() {
    return adminTermViews;
  }

  public void setAdminTermViews(List<AdminTermView> adminTermViews) {
    this.adminTermViews = adminTermViews;
  }
}
