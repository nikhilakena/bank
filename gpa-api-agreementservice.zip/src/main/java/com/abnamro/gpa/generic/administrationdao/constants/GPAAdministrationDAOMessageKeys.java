package com.abnamro.gpa.generic.administrationdao.constants;


import com.abnamro.gpa.generic.exception.MessageKey;

/**
 * This is the DAO layer Message key constant file for GPAAdministrationDAO
 */
public class GPAAdministrationDAOMessageKeys {

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_SEARCHING_ADMINISTRATION_DETAILS = new MessageKey("MESSAGE_ADDA_001");
	
	public static final MessageKey DATABASE_EXCEPTION_WHILE_SEARCHING_ADMINISTRATION_DETAILS = new MessageKey("MESSAGE_ADDA_002");

	public static final MessageKey INVALID_LENGTH_WHILE_SEARCHING_ADMINISTRATION = new MessageKey("MESSAGE_ADDA_003");
	
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVE_MAX_ADMINISTRATION_ID = new MessageKey("MESSAGE_ADDA_004");
	
	public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVE_MAX_ADMINISTRATION_ID = new MessageKey("MESSAGE_ADDA_005");

	public static final MessageKey INVALID_LENGTH_WHILE_CREATING_ADMINISTRATION = new MessageKey("MESSAGE_ADDA_006");
	
	public static final MessageKey DUPLICATE_KEY_EXCEPTION_WHILE_CREATING_ADMINISTRATION_DETAILS = new MessageKey("MESSAGE_ADDA_007");

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_READ_ADMINISTRATION = new MessageKey("MESSAGE_ADDA_008");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_READ_ADMINISTRATION = new MessageKey("MESSAGE_ADDA_009");

	public static final MessageKey INVALID_LENGTH_WHILE_READ_ADMINISTRATION = new MessageKey("MESSAGE_ADDA_010");

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_READ_ADMINISTRATION_COUNT_FOR_TERM = new MessageKey("MESSAGE_ADDA_011");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_READ_ADMINISTRATION_COUNT_FOR_TERM = new MessageKey("MESSAGE_ADDA_012");

	public static final MessageKey DUPLICATE_KEY_EXCEPTION_WHILE_UPDATING_ADMINISTRATION_DETAILS = new MessageKey("MESSAGE_ADDA_013");

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_READ_AGREEMENT_COUNT_FOR_ADMIN = new MessageKey("MESSAGE_ADDA_014");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_READ_AGREEMENT_COUNT_FOR_ADMIN = new MessageKey("MESSAGE_ADDA_015");

	public static final MessageKey MYBATIS_EXCEPTION_WHILE_READ_AGREEMENT_COUNT_FOR_PRODUCT = new MessageKey("MESSAGE_ADDA_016");

	public static final MessageKey DATABASE_EXCEPTION_WHILE_READ_AGREEMENT_COUNT_FOR_PRODUCT = new MessageKey("MESSAGE_ADDA_017");
	
	public static final MessageKey MYBATIS_EXCEPTION_WHILE_DELETING_ADMINISTRATION_DETAILS = new MessageKey("MESSAGE_ADDA_018");
	
	public static final MessageKey DATABASE_EXCEPTION_WHILE_DELETING_ADMINISTRATION_DETAILS = new MessageKey("MESSAGE_ADDA_019");
	
	public static final MessageKey VALIDATION_EXCEPTION_NO_DATA_FOUND_IN_DELETE_ADMINISTRATION = new MessageKey("MESSAGE_ADDA_020");

	public static final MessageKey VALIDATION_EXCEPTION_IN_ADMIN_EXISTING_PROD_INSERT_NOT_ALLOWED = new MessageKey("MESSAGE_ADDA_021");
}
