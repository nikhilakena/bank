/**
 *
 */
package com.abnamro.gpa.generic.administrationdao.dtos;



import java.sql.Timestamp;

/**
 * This is a view class which holds the details of Facet
 * @author C45410
 *
 */
public class FacetView   {

	/**
	 * This is default serialVersionID
	 */
	private static final long serialVersionUID = 1L;

	private String type;
	private String value;
	private String createdBy;
	private Timestamp createdTimeStamp;
	private String modifiedBy;
	private Timestamp modifiedTimeStamp;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedTimeStamp() {
		return modifiedTimeStamp;
	}

	public void setModifiedTimeStamp(Timestamp modifiedTimeStamp) {
		this.modifiedTimeStamp = modifiedTimeStamp;
	}
}
