package com.abnamro.gpa.generic.gpaagreementdao.constants;

/**
 * This is the DAO layer constant file for GPAAgreementConfigurationDAO
 * @author C45158
 * 
 */
public class GPAAgreementDAOConstants {
	
	public static final String SCHEMA_DATABASE = "SCHEMA_GPA";
	public static final String DEFAULT_DB_SCHEMA = "UU01";
	
	public static final String DATASOURCE_NAME = "GPADATASOURCE";
	public static final String DEFAULT_DATASOURCE = "jdbc/GPA_DataSource";
	
	public static final String TERM_MANDATORY_YES = "Y";
	public static final String TERM_MANDATORY_NO = "N";

	public static final String AGREEMENT_STATUS_ACTIVE = "ACTIVE";
	
	public static final String CONTRACTHEADER_STATUS_ACTIVE = "2";
	public static final String CONTRACTHEADER_STATUS_INACTIVE = "3";
	
	public static final String ENCODING_UTF8 = "UTF-8";
}
