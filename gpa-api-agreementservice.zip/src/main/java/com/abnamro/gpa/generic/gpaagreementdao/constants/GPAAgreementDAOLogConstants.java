package com.abnamro.gpa.generic.gpaagreementdao.constants;

/**
 * This is the DAO layer log constant file for GPAAgreementConfigurationDAO
 * @author C45158
 * 
 */
public class GPAAgreementDAOLogConstants {

	public static final String LOG_ERROR_IBATIS_INITIALIZATION = "LOG_GPAG_001";
	public static final String LOG_ERROR_DATA_CREATE = "LOG_GPAG_002";
	public static final String LOG_ERROR_DB_CONNECTION = "LOG_GPAG_003";
	public static final String LOG_ERROR_DUPLICATE_AGREEMENTID_CREATE_AGREEMENT = "LOG_GPAG_004";
	public static final String LOG_ERROR_DATA_READ = "LOG_GPAG_005";
	public static final String LOG_ERROR_DB_CONNECTION_READ = "LOG_GPAG_006";
	public static final String LOG_ERROR_INVALID_LENGTH_PARAMS = "LOG_GPAG_007";
	public static final String LOG_ERROR_DUPLICATE_AGREEMENTID_UPATE_AGREEMENT = "LOG_GPAG_008";
	public static final String LOG_ERROR_DATA_UPDATE = "LOG_GPAG_009";
	public static final String LOG_ERROR_POPULATE_TERM_DATA = "LOG_GPAG_010";
	
}
