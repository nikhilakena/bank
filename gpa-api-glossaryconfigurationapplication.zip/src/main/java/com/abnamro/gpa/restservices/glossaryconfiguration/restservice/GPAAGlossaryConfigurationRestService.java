package com.abnamro.gpa.restservices.glossaryconfiguration.restservice;

import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationLogConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossaryConfigurationResultDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossarySearchCriteriaDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Message;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.MessageType;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Messages;
import com.abnamro.gpa.restservices.glossaryconfiguration.helper.GPAAGlossaryConfigurationHelper;
import com.abnamro.gpa.restservices.glossaryconfiguration.helper.GPAAGlossaryValidator;
import com.abnamro.gpa.restservices.glossaryconfiguration.requestprocessor.GPAAGlossaryConfigurationRequestProcessor;
import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Rest service class for the GlossaryConfiguration Application
 */
@RequestMapping("/api/v1/")
@RestController
@Slf4j
public class GPAAGlossaryConfigurationRestService {

  @Autowired
  private GPAAGlossaryConfigurationRequestProcessor requestProcessor;

  @Autowired
  private GPAAGlossaryConfigurationHelper glossaryConfigurationHelper;

  @Autowired
  private GPAAGlossaryValidator util;

  /**
   * Parameterized constructor.
   *
   * @param requestProcessor            GPAAGlossaryConfigurationRequestProcessor : request processor class
   * @param glossaryConfigurationHelper GPAAGlossaryConfigurationHelper:  helper class
   * @param util                        This constructor will only be used by the junit tests.
   */
  public GPAAGlossaryConfigurationRestService(
      GPAAGlossaryConfigurationRequestProcessor requestProcessor,
      GPAAGlossaryConfigurationHelper glossaryConfigurationHelper,
      GPAAGlossaryValidator util) {
    this.requestProcessor = requestProcessor;
    this.glossaryConfigurationHelper = glossaryConfigurationHelper;
    this.util = util;
  }

  /**
   * Default constructor.
   */
  public GPAAGlossaryConfigurationRestService() {
  }

  /**
   * This method is used to search the glossary details
   *
   * @param request              is HttpServletRequest
   * @param termId               is String
   * @param termName             is String
   * @param createdBy            is String
   * @param createdTimeStampFrom is String
   * @param createdTimeStampTo   is String
   * @return response is Response
   * @throws GPAAGlossaryApplicationException the gpaa glossary application exception
   */
  @GetMapping(value = "/terms/retrieve", produces = "application/json")
  public ResponseEntity<List<TermRestResource>> searchGlossary(HttpServletRequest request,
      @RequestParam(name = "id", required = false) String termId,
      @RequestParam(name = "termName", required = false) String termName,
      @RequestParam(name = "createdBy", required = false) String createdBy,
      @RequestParam(name = "createdFrom", required = false) String createdTimeStampFrom,
      @RequestParam(name = "createdTo", required = false) String createdTimeStampTo)
      throws GPAAGlossaryApplicationException {

    final String LOG_METHOD = "searchGlossary(HttpServletRequest,ServletContext,"
        + "String,String,String,String,String):response";
    List<TermRestResource> result = null;

    util.validateGlossarySearchCriteria(termId, termName, createdBy, createdTimeStampFrom, createdTimeStampTo);

    GlossarySearchCriteriaDTO glossarySearchCriteriaDTO = glossaryConfigurationHelper
        .convertToGlossarySearchCriteriaDTO(termId, termName, createdBy, createdTimeStampFrom,
            createdTimeStampTo);
    // Forwarding request to request processor
    result = requestProcessor.searchGlossary(glossarySearchCriteriaDTO);
    return new ResponseEntity<>(result, HttpStatus.OK);
  }

  /**
   * This method is used to create a term
   *
   * @param request          is HttpServletRequest
   * @param termRestResource is TermRestResource
   * @return glossaryConfigurationResultDTO is GlossaryConfigurationResultDTO
   * @throws GPAAGlossaryApplicationException in case of exception
   */
  @PostMapping(value = "/terms/", produces = "Application/json")
  public ResponseEntity<GlossaryConfigurationResultDTO> createTerm(HttpServletRequest request,
      @RequestBody TermRestResource termRestResource)
      throws GPAAGlossaryApplicationException {
    GlossaryConfigurationResultDTO glossaryConfigurationResultDTO = null;
    String createdBy = "GPAGLO";

    util.isTermDataEmpty(termRestResource);
    AuditDetails auditDtls = new AuditDetails();
    auditDtls.setCreatedBy(createdBy);
    termRestResource.setAuditDetails(auditDtls);
    // Forwarding request to request processor
    glossaryConfigurationResultDTO = requestProcessor.createTerm(termRestResource);

    return new ResponseEntity<>(glossaryConfigurationResultDTO, HttpStatus.OK);
  }

  /**
   * This operation is used to delete an existing Term in GPA administration.
   *
   * @param request HttpServletRequest
   * @param termId  unique Identifier of the term
   * @return GlossaryConfigurationResultDTO containing result
   * @throws GPAAGlossaryApplicationException the gpaa glossary application exception
   */
  @DeleteMapping(value = "/terms/delete/{id:[0-9]{1,6}}", produces = "application/json")
  public ResponseEntity<GlossaryConfigurationResultDTO> deleteTerm(HttpServletRequest request,
      @PathVariable(name = "id") int termId) throws GPAAGlossaryApplicationException {

    final String LOG_METHOD = "deleteTerm ";
    GlossaryConfigurationResultDTO glossaryConfigurationResultDTO = null;

    if (termId > 0) {
      glossaryConfigurationResultDTO = requestProcessor.deleteTerm(termId);
    } else {
      log.error(LOG_METHOD + GPAAGlossaryConfigurationLogConstants.LOG_INVALID_TERM_ID_DELETE_GLOSSARY);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAGlossaryConfigurationMessageKeyConstants.INVALID_INPUT_PARAMETER_ERROR_IN_DELETE_TERM),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    }
    return new ResponseEntity<>(glossaryConfigurationResultDTO, HttpStatus.OK);
  }

  /**
   * This operation is used to read the details of an existing Term in GPA administration.
   *
   * @param request HttpServletRequest
   * @param termId  unique Identifier of the term
   * @return term rest resource
   * @throws GPAAGlossaryApplicationException in case of exception
   */
  @GetMapping(value = "/terms/{termId:[0-9]{1,6}}", produces = "application/json")
  public ResponseEntity<TermRestResource> readTerm(HttpServletRequest request,
      @PathVariable(name = "termId") String termId) throws GPAAGlossaryApplicationException {

    final String LOG_METHOD = "readTerm ";
    TermRestResource result = null;
    int id;

    id = Integer.parseInt(termId);
    if (id > 0) {
      // Forwarding request to request processor
      result = requestProcessor.readTerm(id);
    } else {
      log.error(LOG_METHOD + GPAAGlossaryConfigurationLogConstants.LOG_INVALID_INPUT_IN_READ_TERM);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(
              GPAAGlossaryConfigurationMessageKeyConstants.INVALID_INPUT_PARAMETER_ERROR_IN_READ_TERM),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    }
    return new ResponseEntity<>(result, HttpStatus.OK);
  }

  /**
   * This operation is used to update an existing Term in GPA administration
   *
   * @param request          HttpServletRequest
   * @param termRestResource term rest resource
   * @return GlossaryConfigurationResultDTO containing result
   * @throws GPAAGlossaryApplicationException in case of exception
   */
  @PutMapping(value = "/terms/", consumes = "application/json", produces = "application/json")
  public ResponseEntity<GlossaryConfigurationResultDTO> updateTerm(HttpServletRequest request,
      @RequestBody TermRestResource termRestResource)
      throws GPAAGlossaryApplicationException {
    GlossaryConfigurationResultDTO glossaryConfigurationResultDTO = null;

    final String LOG_METHOD = "updateTerm ";
    String modifiedBy = "GPAGLO";

    AuditDetails auditDtls = new AuditDetails();
    auditDtls.setModifiedBy(modifiedBy);
    termRestResource.setAuditDetails(auditDtls);

    util.validateUpdateTerm(termRestResource);

    //Forwarding request to request processor
    glossaryConfigurationResultDTO = requestProcessor.updateTerm(termRestResource);
    log.debug("{} {}", LOG_METHOD, "updated the term in GPA administration");
    return new ResponseEntity<>(glossaryConfigurationResultDTO, HttpStatus.OK);
  }

  /**
   * This method is used to search the glossary details
   *
   * @param request is HttpServletRequest
   * @return response is Response
   * @throws GPAAGlossaryApplicationException the gpaa glossary application exception
   */
  @GetMapping(value = "/terms/retrieveall", produces = "application/json")
  public ResponseEntity<List<TermRestResource>> retrieveAllTerms(HttpServletRequest request)
      throws GPAAGlossaryApplicationException {

    List<TermRestResource> result = null;

    // Forwarding request to request processor
    result = requestProcessor.retrieveAllTerms();
    log.debug("Retrieved all the terms");
    return new ResponseEntity<>(result, HttpStatus.OK);
  }

}
