/**
 *
 */
package com.abnamro.gpa.restservices.glossaryconfiguration.dtos;

import lombok.Data;

/**
 * This is a Search Criteria DTO class used as input in Glossary Search
 */
@Data
public class GlossarySearchCriteriaDTO {

  private int termId;

  private String termName;

  private String createdBy;

  private String createdTimestampFrom;

  private String createdTimestampTo;
}
