package com.abnamro.gpa.restservices.glossaryconfiguration.health;

import static org.springframework.http.HttpStatus.OK;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * The type Health check controller.
 */
@RestController
@RequestMapping("/")
public class HealthCheckController {

  /**
   * This method returns the health of the application
   *
   * @return boolean boolean
   */
  @GetMapping("healthcheck")
  @ResponseStatus(OK)
  public boolean healthCheck() {
    return true;
  }
}
