/**
 *
 */
package com.abnamro.gpa.restservices.glossaryconfiguration.constant;

import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.MessageKey;

/**
 * This class contains the Glossary Configuration MessageKey Constants
 */
public class GPAAGlossaryConfigurationMessageKeyConstants {

  /**
   * The constant PARSING_EXCEPTION.
   */
  public static final MessageKey PARSING_EXCEPTION = new MessageKey("MESSAGE_GLSC_003");

  /**
   * The constant ATLEAST_ONE_SEARCH_CRITERIA_IS_REQUIRED_IN_GLOSSARY_SEARCH.
   */
  public static final MessageKey ATLEAST_ONE_SEARCH_CRITERIA_IS_REQUIRED_IN_GLOSSARY_SEARCH = new MessageKey(
      "MESSAGE_GLSC_004");

  /**
   * The constant VALIDATION_EXCEPTION_TERM_ID_IS_NOT_NUMERIC.
   */
  public static final MessageKey VALIDATION_EXCEPTION_TERM_ID_IS_NOT_NUMERIC = new MessageKey("MESSAGE_GLSC_006");

  /**
   * The constant VALIDATION_EXCEPTION_IN_GLOSSARY_SEARCH_FROM_DATE_CAN_NOT_BE_GREATER_THAN_TO_DATE.
   */
  public static final MessageKey VALIDATION_EXCEPTION_IN_GLOSSARY_SEARCH_FROM_DATE_CAN_NOT_BE_GREATER_THAN_TO_DATE = new MessageKey(
      "MESSAGE_GLSC_007");

  /**
   * The constant VALIDATION_EXCEPTION_IN_GLOSSARY_CREATE.
   */
  public static final MessageKey VALIDATION_EXCEPTION_IN_GLOSSARY_CREATE = new MessageKey("MESSAGE_GLSC_008");

  /**
   * The constant INVALID_INPUT_PARAMETER_ERROR_IN_READ_TERM.
   */
  public static final MessageKey INVALID_INPUT_PARAMETER_ERROR_IN_READ_TERM = new MessageKey("MESSAGE_GLSC_014");

  /**
   * The constant INVALID_INPUT_PARAMETER_ERROR_IN_DELETE_TERM.
   */
  public static final MessageKey INVALID_INPUT_PARAMETER_ERROR_IN_DELETE_TERM = new MessageKey("MESSAGE_GLSC_015");

  /**
   * The constant VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE.
   */
  public static final MessageKey VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE = new MessageKey("MESSAGE_GLSC_016");

  /**
   * The constant VALIDATION_EXCEPTION_IN_GLOSSARY_NO_UPDATES.
   */
  public static final MessageKey VALIDATION_EXCEPTION_IN_GLOSSARY_NO_UPDATES = new MessageKey("MESSAGE_GLSC_017");

  /**
   * The constant EXCEPTION_IN_GLOSSARY_TERM_NAME_UPDATE_NOT_ALLOWED.
   */
  public static final MessageKey EXCEPTION_IN_GLOSSARY_TERM_NAME_UPDATE_NOT_ALLOWED = new MessageKey(
      "MESSAGE_GLSC_018");

  /**
   * The constant DATABASE_EXCEPTION_WHILE_RETRIEVE_ADMINID_FOR_TERM.
   */
  public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVE_ADMINID_FOR_TERM = new MessageKey(
      "MESSAGE_GLSC_021");

}
