package com.abnamro.gpa.restservices.glossaryconfiguration.exceptions;

import java.io.Serializable;

/**
 * The type Message.
 */
public final class Message implements Serializable {

  private static final long serialVersionUID = 1L;
  private MessageKey messageKey;
  private String traceId;
  private transient Object[] params = null;

  /**
   * Message(MessageKey aMessageKey, String aTraceId) : Constructor with trace id and message key
   *
   * @param aMessageKey : message key being passed
   * @param aTraceId    : trace id sent from the service
   */
  public Message(MessageKey aMessageKey, String aTraceId) {
    this.messageKey = aMessageKey;
    this.traceId = aTraceId;
  }

  /**
   * Instantiates a new Message.
   *
   * @param aMessageKey the aMessage key
   * @param aParms      the aParams
   */
  public Message(MessageKey aMessageKey, Object[] aParms) {
    this.messageKey = aMessageKey;
    this.params = aParms;
  }

  /**
   * Instantiates a new Message.
   *
   * @param aMessageKey the aMessage key
   * @param aTraceId    the aTrace id
   * @param aParams     the aParams
   */
  public Message(MessageKey aMessageKey, String aTraceId, Object[] aParams) {
    this.messageKey = aMessageKey;
    this.traceId = aTraceId;
    this.params = aParams;
  }

  /**
   * Message(MessageKey aMessageKey) : Constructor without trace id and only with message key
   *
   * @param aMessageKey : message key being passed
   */
  public Message(MessageKey aMessageKey) {
    this.messageKey = aMessageKey;
  }


  /**
   * Gets message key.
   *
   * @return the message key
   */
  public MessageKey getMessageKey() {
    return this.messageKey;
  }

  public String toString() {
    return getClass().getName() + "[" + this.messageKey + "]";
  }

  /**
   * Get params object [ ].
   *
   * @return the object [ ]
   */
  public Object[] getParams() {
    return this.params;
  }

  /**
   * Gets trace id.
   *
   * @return the trace id
   */
  public String getTraceId() {
    return traceId;
  }

  /**
   * Sets trace id.
   *
   * @param traceId the trace id
   */
  public void setTraceId(String traceId) {
    this.traceId = traceId;
  }

  /**
   * Sets message key.
   *
   * @param messageKey the message key
   */
  public void setMessageKey(MessageKey messageKey) {
    this.messageKey = messageKey;
  }
}
