/**
 *
 */
package com.abnamro.gpa.restservices.glossaryconfiguration.helper;

import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationLogConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossarySearchCriteriaDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Message;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.MessageType;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Messages;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;


/**
 * This is a helper class used in Glossary Configuration
 */
@Component
@Slf4j
public class GPAAGlossaryConfigurationHelper {

  /**
   * This method is used to convert the input string values of search criteria in a object of GlossarySearchCriteriaDTO
   *
   * @param termId          is String
   * @param termName        is String
   * @param createdBy       is String
   * @param createdDateFrom is String
   * @param createdDateTo   is String
   * @return glossarySearchCriteriaDTO is GlossarySearchCriteriaDTO object
   * @throws GPAAGlossaryApplicationException is a validation exception
   */
  public GlossarySearchCriteriaDTO convertToGlossarySearchCriteriaDTO(String termId, String termName,
      String createdBy, String createdDateFrom, String createdDateTo) throws GPAAGlossaryApplicationException {
    GlossarySearchCriteriaDTO glossarySearchCriteriaDTO = new GlossarySearchCriteriaDTO();
    if (StringUtils.isNotEmpty(termId)) {
      glossarySearchCriteriaDTO.setTermId(getIntFromString(termId));
    }

    if (StringUtils.isNotEmpty(termName)) {
      glossarySearchCriteriaDTO.setTermName(termName.trim());
    }
    if (StringUtils.isNotEmpty(createdBy)) {
      glossarySearchCriteriaDTO.setCreatedBy(createdBy.trim());
    }
    if (StringUtils.isNotEmpty(createdDateFrom)) {
      glossarySearchCriteriaDTO.setCreatedTimestampFrom(createdDateFrom.trim());
    }
    if (StringUtils.isNotEmpty(createdDateTo)) {
      glossarySearchCriteriaDTO.setCreatedTimestampTo(createdDateTo.trim());
    }
    return glossarySearchCriteriaDTO;
  }

  private int getIntFromString(String strTermId) throws GPAAGlossaryApplicationException {
    final String LOG_METHOD = "getIntFromString(String strTermId):int ";
    int termId;
    try {
      termId = Integer.parseInt(strTermId);
    } catch (NumberFormatException e) {
      log.error(LOG_METHOD, GPAAGlossaryConfigurationLogConstants.LOG_INVALID_TERM_ID_SEARCH_GLOSSARY,
          e);
      Messages messages = new Messages();
      messages.addMessage(new Message(GPAAGlossaryConfigurationMessageKeyConstants.PARSING_EXCEPTION),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    }
    return termId;
  }
}
