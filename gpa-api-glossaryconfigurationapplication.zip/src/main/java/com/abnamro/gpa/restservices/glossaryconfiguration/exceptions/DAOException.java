package com.abnamro.gpa.restservices.glossaryconfiguration.exceptions;

/**
 * The type Dao exception.
 */
public class DAOException extends BusinessApplicationException {

  private Messages messages;

  /**
   * Instantiates a new Dao exception.
   */
  public DAOException() {
    this.messages = new Messages();
  }

  /**
   * Constructor that will also set messages on the exception.
   *
   * @param messages it takes messages of Message type
   */
  public DAOException(Messages messages) {
    super(messages);

  }

  /**
   * Constructor that takes an existing AABException. This will move any messages into the new exception. <br>
   *
   * @param e accepts type of AABException
   */
  public DAOException(DAOException e) {
    if (e != null) {
      this.messages = e.getMessages();
    } else {
      this.messages = new Messages();
    }
  }

  /**
   * @return name
   */
  @Override
  public String toString() {
    return getClass().getName() + " : " + this.messages.toString();
  }


  /**
   * @param messages
   */
  public void setMessages(Messages messages) {
    this.messages = messages;
  }
}
