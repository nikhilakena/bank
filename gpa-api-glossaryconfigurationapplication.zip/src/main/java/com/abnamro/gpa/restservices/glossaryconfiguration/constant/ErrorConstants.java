package com.abnamro.gpa.restservices.glossaryconfiguration.constant;


/**
 * Generic constants for the BrokerageOrderManagementBffApplication.
 */
public final class ErrorConstants {

  /**
   * The constant TECHNICAL_EXCEPTION.
   */
  public static final String TECHNICAL_EXCEPTION = "TECHNICAL_EXCEPTION";
  /**
   * The constant TECHNICAL_ERROR.
   */
  public static final String TECHNICAL_ERROR = "Technical error.";

  /**
   * Make the constructor private to avoid instantiation
   */
  private ErrorConstants() {

  }

}

