package com.abnamro.gpa.restservices.glossaryconfiguration.exceptions;

import lombok.extern.slf4j.Slf4j;

/**
 * The type Business application exception.
 */
@Slf4j
public class BusinessApplicationException extends Exception {

  private Messages messages;

  /**
   * Instantiates a new Business application exception.
   */
  public BusinessApplicationException() {
    this.messages = new Messages();
  }

  /**
   * Constructor that will also set messages on the exception.
   *
   * @param messages it takes messages of Message type
   */
  public BusinessApplicationException(Messages messages) {
    this.messages = messages;
  }

  /**
   * Constructor that takes an existing AABException. This will move any messages into the new exception. <br>
   *
   * @param e accepts type of AABException
   */
  public BusinessApplicationException(BusinessApplicationException e) {

    log.info("BusinessApplicationException 1>>");
    if (e != null) {
      log.info("BusinessApplicationException occurred: {} ", e.getMessages().getMessages().get(0).getMessageKey());
      this.messages = e.getMessages();
    } else {
      this.messages = new Messages();
    }
  }

  @Override
  public String toString() {
    return getClass().getName() + " : " + this.messages.toString();
  }

  /**
   * Gets messages.
   *
   * @return the messages
   */
  public Messages getMessages() {
    return messages;
  }

  /**
   * Sets messages.
   *
   * @param messages the messages
   */
  public void setMessages(Messages messages) {
    this.messages = messages;
  }
}
