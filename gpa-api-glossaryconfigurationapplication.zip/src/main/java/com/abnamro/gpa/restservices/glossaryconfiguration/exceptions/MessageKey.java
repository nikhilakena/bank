package com.abnamro.gpa.restservices.glossaryconfiguration.exceptions;

import java.io.Serializable;

/**
 * The type Message key.
 */
public final class MessageKey implements Serializable {

  /**
   * default
   */
  private static final long serialVersionUID = -5520590912146264764L;
  private final String id;

  /**
   * Gets id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * MessageKey(String aId) : Constructor with id
   *
   * @param aId : Id of the message key
   */
  public MessageKey(String aId) {
    this.id = aId;
  }

  public String toString() {
    return getClass().getName() + "[" + this.id + "]";
  }
}
