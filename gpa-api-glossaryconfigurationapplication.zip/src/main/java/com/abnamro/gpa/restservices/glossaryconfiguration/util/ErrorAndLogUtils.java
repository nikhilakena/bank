package com.abnamro.gpa.restservices.glossaryconfiguration.util;


import com.abnamro.gpa.restresource.exception.Error;
import com.abnamro.gpa.restresource.exception.Errors;
import java.util.ArrayList;


/**
 * Generic utilities for the BrokerageOrderManagementBff application.
 */
public class ErrorAndLogUtils {

  /**
   * setError : This function will set attributes in ERROR DTO
   *
   * @param errors  A Error DTO need to filled
   * @param code    A unique code for error
   * @param message A message description of code
   */
  public static void setError(Errors errors, String code, String message) {
    ArrayList<Error> errorMessageList = new ArrayList<>();
    Error error = new Error();
    error.setCode(code);
    error.setMessage(message);
    errorMessageList.add(error);
    errors.setErrors(errorMessageList);
  }

  /**
   * Sets error.
   *
   * @param code    the code
   * @param message the message
   * @return the error
   */
  public static Errors setError(String code, String message) {
    Errors errors = new Errors();
    ArrayList<Error> errorMessageList = new ArrayList<>();
    Error error = new Error();
    error.setCode(code);
    error.setMessage(message);
    errorMessageList.add(error);
    errors.setErrors(errorMessageList);
    return errors;
  }

}

