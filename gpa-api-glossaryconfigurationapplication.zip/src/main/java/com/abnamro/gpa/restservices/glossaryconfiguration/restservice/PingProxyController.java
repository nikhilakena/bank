package com.abnamro.gpa.restservices.glossaryconfiguration.restservice;


import com.abnamro.gpa.generic.security.JwtAuthHelper;
import com.abnamro.gpa.generic.security.PingFederateValidateUserInfo;
import com.abnamro.gpa.restservices.glossaryconfiguration.config.ping.PingClientConfig;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.AuthenticationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * The type Ping proxy controller.
 */
@RestController
@Produces(MediaType.APPLICATION_JSON)
@RequestMapping("/v1/authencationcheck")
public class PingProxyController {

  @Autowired
  private JwtAuthHelper jwtAuthHelper;

  @Autowired
  private PingClientConfig pingClientConfig;

  /**
   * Gets ping access token.
   *
   * @param code         the code
   * @param grant_type   the grant type
   * @param redirect_uri the redirect uri
   * @return BrokerageAuthTokens with PingAccessToken and SmSession
   * @throws GPAAGlossaryApplicationException the gpaa glossary application exception
   * @throws AuthenticationException          the authentication exception
   */
  @PostMapping("/checkAccess")
  public ResponseEntity<String> getPingAccessToken(@RequestParam(value = "code") String code,
      @RequestParam(value = "grant_type") String grant_type, @RequestParam(value = "redirect_uri") String redirect_uri)
      throws GPAAGlossaryApplicationException, AuthenticationException {
    Map<String, String> tokenMap = pingClientConfig.callPingAPI(code, grant_type, redirect_uri);
    String userJwtSession = jwtAuthHelper.createUserJwtSession(tokenMap.get("id_token"));

    return new ResponseEntity<>(userJwtSession, HttpStatus.OK);
  }

  /**
   * Validate token response entity.
   *
   * @param request  the request
   * @param response the response
   * @return PingFederateValidateUserInfo response entity
   * @throws AuthenticationException
   */
  @PostMapping("/validateToken")
  public ResponseEntity<PingFederateValidateUserInfo> validateToken(HttpServletRequest request,
      HttpServletResponse response) {

    PingFederateValidateUserInfo pingDTO = new PingFederateValidateUserInfo();
    String authHeaderValue = request.getHeader(HttpHeaders.AUTHORIZATION);
    if (!(authHeaderValue.startsWith("Bearer"))) {
      response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
    } else {
      pingDTO = jwtAuthHelper.verifyUserJwtSession(authHeaderValue.substring(7));
    }
    if (!pingDTO.isActive()) {
      return new ResponseEntity<>(pingDTO, HttpStatus.UNAUTHORIZED);
    }
    return new ResponseEntity<>(pingDTO, HttpStatus.OK);
  }
}
