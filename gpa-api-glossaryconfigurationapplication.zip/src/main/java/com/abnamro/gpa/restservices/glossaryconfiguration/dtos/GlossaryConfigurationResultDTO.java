package com.abnamro.gpa.restservices.glossaryconfiguration.dtos;

import lombok.Data;

/**
 * The type Glossary configuration result dto.
 * <p>
 * This is custom result DTO for GlossaryConfiguration Application
 */
@Data
public class GlossaryConfigurationResultDTO {

  private int identifier;
  private boolean indicatorSuccess;

}
