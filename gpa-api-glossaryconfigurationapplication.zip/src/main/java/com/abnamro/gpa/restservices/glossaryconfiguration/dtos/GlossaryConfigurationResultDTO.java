package com.abnamro.gpa.restservices.glossaryconfiguration.dtos;

/**
 * The type Glossary configuration result dto.
 *
 * @author C23597 This is custom result DTO for GlossaryConfiguration Application
 */
public class GlossaryConfigurationResultDTO {

  private int identifier;
  private boolean indicatorSuccess;


  /**
   * Gets identifier.
   *
   * @return the identifier
   */
  public int getIdentifier() {
    return identifier;
  }

  /**
   * Sets identifier.
   *
   * @param identifier the identifier to set
   */
  public void setIdentifier(int identifier) {
    this.identifier = identifier;
  }

  /**
   * Is indicator success boolean.
   *
   * @return the indicatorSuccess
   */
  public boolean isIndicatorSuccess() {
    return indicatorSuccess;
  }

  /**
   * Sets indicator success.
   *
   * @param indicatorSuccess the indicatorSuccess to set
   */
  public void setIndicatorSuccess(boolean indicatorSuccess) {
    this.indicatorSuccess = indicatorSuccess;
  }


}
