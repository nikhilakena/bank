package com.abnamro.gpa.restservices.glossaryconfiguration.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.IOException;
import lombok.experimental.UtilityClass;

/**
 * The type Json util.
 */
@UtilityClass
public class JSONUtil {

  /**
   * Init object mapper object mapper.
   *
   * @return the object mapper
   */
  ObjectMapper initObjectMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
    mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    return mapper;
  }

  /**
   * Covert json to object t.
   *
   * @param <T>    the type parameter
   * @param json   the json
   * @param varVal the var val
   * @return the t
   * @throws IOException the io exception
   */
// convert JSON into Object
  public static <T> T covertJsonToObject(String json, Class<T> varVal) throws IOException {
    return initObjectMapper().readValue(json, varVal); // Convert Json into object of Specific Type
  }

  /**
   * Covert object to json string.
   *
   * @param obj the obj
   * @return the string
   * @throws JsonProcessingException the json processing exception
   */
  public static String covertObjectToJson(Object obj) throws JsonProcessingException {
    return initObjectMapper().writeValueAsString(obj);
  }
}
