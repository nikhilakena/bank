package com.abnamro.gpa.restservices.glossaryconfiguration.exceptions;


import com.abnamro.gpa.restresource.exception.Errors;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * The type Authentication exception.
 */
@ResponseStatus(code = HttpStatus.UNAUTHORIZED)
public class AuthenticationException extends BusinessApplicationException {

  private static final long serialVersionUID = -5071037813944099099L;

  private transient Errors errors = null;


  /**
   * constructor will set the value to error local varible
   *
   * @param errors A Error object
   */
  public AuthenticationException(Errors errors) {
    this.errors = errors;
  }

  /**
   * Gets error message wrapper.
   *
   * @return the errorMessageWrapper
   */
  public Errors getErrorMessageWrapper() {
    return errors;
  }

}

