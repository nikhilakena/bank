package com.abnamro.gpa.restservices.glossaryconfiguration.exceptions;

import com.abnamro.gpa.restresource.exception.Error;
import com.abnamro.gpa.restresource.exception.Errors;
import com.abnamro.gpa.restresource.exception.RequestScopeBeans;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * This is the exception handler class for the GPA Glossary Configuration API
 */
@Configuration
@PropertySource("classpath:errormessage.properties")
@ControllerAdvice
@Slf4j
public class GPAGlossaryConfigurationExceptionHandler extends ResponseEntityExceptionHandler {

  @Autowired
  private Environment env;

  @Autowired
  private RequestScopeBeans requestScopeBeans;

  /**
   * This is the method which will be called in case MethodArgumentNotValidException is thrown from application.
   *
   * @param ex      MethodArgumentNotValidException this will be thrown in case validation mentioned on the rest service
   *                input is failed
   * @param headers http headers
   * @param status  https status
   * @param request WebRequest
   * @return response entity containing error details
   */
  public final ResponseEntity<Object> handleMethodArgumentNotValid(
      MethodArgumentNotValidException ex,
      HttpHeaders headers, HttpStatus status, WebRequest request) {

    log.error("handleMethodArgumentNotValid", ex);
    Errors errorDetails = new Errors();
    List<Error> errors = new ArrayList<>();
    if (ex != null && !ex.getBindingResult().getAllErrors().isEmpty()) {
      for (ObjectError objectError : ex.getBindingResult().getAllErrors()) {
        List<String> params = null;
        if (objectError instanceof FieldError) {
          params = getParamsForArrayField(objectError);
        }
        String messageId = objectError.getDefaultMessage();
        errors.add(populateErrorDetails(messageId, HttpStatus.BAD_REQUEST, params));
      }
    } else {
      errors.add(populateErrorDetails(null, HttpStatus.BAD_REQUEST, null));
    }

    errorDetails.setErrors(errors);
    return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
  }

  private List<String> getParamsForArrayField(ObjectError objectError) {
    FieldError fieldError = (FieldError) objectError;
    List<String> params = null;
    if (fieldError.getField() != null && fieldError.getField().contains("[") && fieldError.getField().contains("]")) {
      String[] splitedValue = fieldError.getField().split("\\[");
      if (splitedValue.length == 2) {
        params = new ArrayList<>();
        Integer occurrence = Integer.valueOf(splitedValue[1].split("]")[0]);
        params.add(String.valueOf(occurrence + 1));
      }
    }
    return params;
  }

  /**
   * This is the method which will be called in case HttpConstraintViolation is thrown from application.
   *
   * @param ex      HttpConstraintViolation this will be thrown in case input Json format is not valid
   * @param request WebRequest
   * @return response entity containing error details
   */
  @ExceptionHandler({ConstraintViolationException.class})
  public ResponseEntity<Object> handleConstraintViolation(
      ConstraintViolationException ex, WebRequest request) {
    log.error("handleConstraintViolation", ex);
    Errors errorDetails = new Errors();
    List<Error> errors = new ArrayList<>();
    if (ex != null) {
      for (ConstraintViolation<?> violation : ex.getConstraintViolations()) {
        errors.add(populateErrorDetails(violation.getMessage(), HttpStatus.BAD_REQUEST, null));
      }
    } else {
      errors.add(populateErrorDetails(null, HttpStatus.BAD_REQUEST, null));
    }
    errorDetails.setErrors(errors);
    return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
  }

  /**
   * This is the method which will be called in case HttpMessageNotReadableException is thrown from application.
   *
   * @param ex      HttpMessageNotReadableException this will be thrown in case input Json format is not valid i.e
   *                invalid Enum or date
   * @param headers http headers
   * @param status  https status
   * @param request WebRequest
   * @return response entity containing error details
   */
  public final ResponseEntity<Object> handleHttpMessageNotReadable(
      HttpMessageNotReadableException ex,
      HttpHeaders headers, HttpStatus status, WebRequest request) {
    log.error("handleHttpMessageNotReadable", ex);
    Errors errorDetails = new Errors();
    List<Error> errors = new ArrayList<>();
    Error error = new Error();
    error.setMessage(ex.getMessage());
    error.setCode("JSON_PARSE_ERROR");
    error.setStatus(HttpStatus.BAD_REQUEST.toString());
    errors.add(error);
    errorDetails.setErrors(errors);
    return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
  }

  /**
   * This is the method which will be called in case GPAAGlossaryApplicationException is thrown from application.
   *
   * @param ex GPAAGlossaryApplicationException this will be thrown in case customised validation or exception
   * @return response entity containing error details
   */
  @ExceptionHandler(GPAAGlossaryApplicationException.class)
  public final ResponseEntity<Object> handleGPAAGlossaryApplicationException(
      GPAAGlossaryApplicationException ex) {
    log.info("handleGPAAGlossaryApplicationException " + ex.getMessages().getMessages().size(), ex);

    Errors errorDetails = new Errors();
    List<Error> errors = new ArrayList<>();

    if (ex.getMessages().getMessages().size() != 0) {
      Error error = new Error();
      error.setCode(ex.getMessages().getMessages().get(0).getMessageKey().getId());
      error.setTraceId(Encode.forHtmlContent(requestScopeBeans.getTraceId()));
      error.setMessage(MessageType.getError().getCodeLabel());
      if (ex.getParams() != null) {
        error.setParams(ex.getParams().stream().map(Encode::forHtmlContent).collect(Collectors.toList()));
      }
      error.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR));
      errors.add(error);
    } else {
      errors.add(populateErrorDetails(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, ex.getParams()));
    }
    errorDetails.setErrors(errors);
    return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * Handle bad credentials application exception response entity.
   *
   * @param ex the ex
   * @return the response entity
   */
  @ExceptionHandler(BadCredentialsException.class)
  public final ResponseEntity<Object> handleBadCredentialsApplicationException(
      BadCredentialsException ex) {
    log.info("handleBadCredentialsApplicationException", ex);
    Errors errorDetails = new Errors();
    List<Error> errors = new ArrayList<>();
    errors.add(populateErrorDetails(ex.getMessage(), HttpStatus.UNAUTHORIZED, null));
    errorDetails.setErrors(errors);
    return new ResponseEntity<>(errorDetails, HttpStatus.UNAUTHORIZED);
  }

  /**
   * Handle authentication general exception response entity.
   *
   * @param ex the ex
   * @return response entity
   */
  @ExceptionHandler(AuthenticationException.class)
  public final ResponseEntity<Errors> handleAuthenticationGeneralException(AuthenticationException ex) {
    log.error("handleAuthenticationGeneralException: ", ex);
    Errors errorDetails = new Errors();
    List<Error> errors = new ArrayList<>();
    errors.add(populateErrorDetails(null, HttpStatus.BAD_REQUEST, null));
    errorDetails.setErrors(errors);
    return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
  }

  /**
   * This is the method which will be called in case GPAAGlossaryApplicationException is thrown from application.
   *
   * @param ex Exception this will be thrown in case generic exception
   * @return response entity containing error details
   */
  @ExceptionHandler(Exception.class)
  public final ResponseEntity<Errors> handleGeneralException(Exception ex
  ) {
    log.error("handleGeneralException", ex);
    Errors errorDetails = new Errors();
    List<Error> errors = new ArrayList<>();
    errors.add(populateErrorDetails(null, HttpStatus.INTERNAL_SERVER_ERROR, null));
    errorDetails.setErrors(errors);
    return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  private Error populateErrorDetails(String messageId, HttpStatus httpStatus, List<String> params) {
    Error error = new Error();
    String str = "_code";
    if (messageId == null || env.getProperty(messageId + str) == null) {
      messageId = String.valueOf(httpStatus.value());
    }
    log.info("populateErrorDetails: " + env.getProperty(messageId + str));
    error.setCode(env.getProperty(messageId + str));
    error.setTraceId(Encode.forHtmlContent(requestScopeBeans.getTraceId()));
    error.setMessage(env.getProperty(messageId + "_message"));
    if (params != null) {
      error.setParams(params.stream().map(Encode::forHtmlContent).collect(Collectors.toList()));
    }
    error.setStatus(String.valueOf(httpStatus.value()));
    return error;
  }
}
