package com.abnamro.gpa.restservices.glossaryconfiguration.exceptions;

/**
 * The enum Message type.
 */
public enum MessageType {

  /**
   * Warning message type.
   */
  WARNING("WARNING", 0),
  /**
   * Error message type.
   */
  ERROR("ERROR", 1),
  /**
   * Info message type.
   */
  INFO("INFO", 2),
  /**
   * Audit message type.
   */
  AUDIT("AUDIT",
      3),
  /**
   * Undefined message type.
   */
  UNDEFINED("UNDEFINED", 4);

  private int code;
  private String codeLabel;

  MessageType(String codeLabel, int code) {
    this.code = code;
    this.codeLabel = codeLabel;
  }

  /**
   * Gets warning.
   *
   * @return the warning
   */
  public static MessageType getWarning() {
    return MessageType.WARNING;
  }

  /**
   * Gets error.
   *
   * @return the error
   */
  public static MessageType getError() {
    return MessageType.ERROR;
  }

  /**
   * Gets info.
   *
   * @return the info
   */
  public static MessageType getInfo() {
    return MessageType.INFO;
  }

  /**
   * Gets audit.
   *
   * @return the audit
   */
  public static MessageType getAudit() {
    return MessageType.AUDIT;
  }

  /**
   * Gets undefined.
   *
   * @return the undefined
   */
  public static MessageType getUndefined() {
    return MessageType.UNDEFINED;
  }

  /**
   * Gets code.
   *
   * @return the code
   */
  public int getCode() {
    return code;
  }

  /**
   * Sets code.
   *
   * @param code the code
   */
  public void setCode(int code) {
    this.code = code;
  }

  /**
   * Gets code label.
   *
   * @return the code label
   */
  public String getCodeLabel() {
    return codeLabel;
  }

  /**
   * Sets code label.
   *
   * @param codeLabel the code label
   */
  public void setCodeLabel(String codeLabel) {
    this.codeLabel = codeLabel;
  }
}

