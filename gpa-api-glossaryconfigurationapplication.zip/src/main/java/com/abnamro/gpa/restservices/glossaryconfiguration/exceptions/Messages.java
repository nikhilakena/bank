package com.abnamro.gpa.restservices.glossaryconfiguration.exceptions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Messages: Messages class for storing List of Message Class object <B>History : </B>
 */
public final class Messages implements Serializable {

  /**
   * default value
   */
  private static final long serialVersionUID = -2006093178894343002L;
  private List<Message> messages;

  /**
   * Gets messages.
   *
   * @return the messages
   */
  public List<Message> getMessages() {
    return messages;
  }

  /**
   * Sets messages.
   *
   * @param messages the messages
   */
  public void setMessages(List<Message> messages) {
    this.messages = messages;
  }

  /**
   * Messages() This constructor initialises array list of message
   */
  public Messages() {
    this.messages = new ArrayList<>();
  }

  /**
   * addMessage : this method adds messages to the list of messages in case it does not exist
   *
   * @param message : The Message object
   * @param type    : The MessageType object
   */
  public void addMessage(Message message, MessageType type) {
    if ((hasMessage(message.getMessageKey(), type))) {
      return;
    }
    if (type != null) {
      getMessages().add(message);
    }
  }

  /**
   * hasMessage : this method checks if the message is already present on the list
   *
   * @param key  : The MessageKey object
   * @param type : The MessageType object
   * @return true if list already has message and false if its not present
   */
  public boolean hasMessage(MessageKey key, MessageType type) {
    boolean messagePresent = false;
    if (type != null) {
      for (Message message : messages) {
        if (key.equals(message.getMessageKey())) {
          messagePresent = true;
          break;
        }
      }
    }
    return messagePresent;
  }

}