/**
 *
 */
package com.abnamro.gpa.restservices.glossaryconfiguration.constant;

/**
 * This is class contains the Glossary Configuration Log Constants
 */
public class GPAAGlossaryConfigurationLogConstants {

  /**
   * The constant LOG_INVALID_DATE_IN_SEARCH_GLOSSARY.
   */
  public static final String LOG_INVALID_DATE_IN_SEARCH_GLOSSARY = "LOG_BAI692_003";

  /**
   * The constant LOG_INVALID_TERM_ID_SEARCH_GLOSSARY.
   */
  public static final String LOG_INVALID_TERM_ID_SEARCH_GLOSSARY = "LOG_BAI692_004";

  /**
   * The constant LOG_DAO_EXCEPTION_IN_SEARCH_GLOSSARY_REQUEST_PROCESSOR.
   */
  public static final String LOG_DAO_EXCEPTION_IN_SEARCH_GLOSSARY_REQUEST_PROCESSOR = "LOG_BAI692_006";

  /**
   * The constant LOG_DAO_EXCEPTION_IN_CREATE_TERM_REQUEST_PROCESSOR.
   */
  public static final String LOG_DAO_EXCEPTION_IN_CREATE_TERM_REQUEST_PROCESSOR = "LOG_BAI692_007";

  /**
   * The constant LOG_DAO_EXCEPTION_IN_READ_TERM_REQUEST_PROCESSOR.
   */
  public static final String LOG_DAO_EXCEPTION_IN_READ_TERM_REQUEST_PROCESSOR = "LOG_BAI692_010";

  /**
   * The constant LOG_INVALID_INPUT_IN_READ_TERM.
   */
  public static final String LOG_INVALID_INPUT_IN_READ_TERM = "LOG_BAI692_011";

  /**
   * The constant LOG_DAO_EXCEPTION_IN_DELETE_GLOSSARY_REQUEST_PROCESSOR.
   */
  public static final String LOG_DAO_EXCEPTION_IN_DELETE_GLOSSARY_REQUEST_PROCESSOR = "LOG_BAI692_012";

  /**
   * The constant LOG_INVALID_TERM_ID_DELETE_GLOSSARY.
   */
  public static final String LOG_INVALID_TERM_ID_DELETE_GLOSSARY = "LOG_BAI692_013";

  /**
   * The constant LOG_DAO_EXCEPTION_IN_UPDATE_TERM_REQUEST_PROCESSOR.
   */
  public static final String LOG_DAO_EXCEPTION_IN_UPDATE_TERM_REQUEST_PROCESSOR = "LOG_BAI692_015";

  /**
   * The constant LOG_DAO_EXCEPTION_IN_RETRIEVE_ALL_TERMS_REQUEST_PROCESSOR.
   */
  public static final String LOG_DAO_EXCEPTION_IN_RETRIEVE_ALL_TERMS_REQUEST_PROCESSOR = "LOG_BAI692_016";

  /**
   * The constant LOG_DAO_EXCEPTION_IN_UPDATE_TERM_READ_ADMIN_COUNT.
   */
  public static final String LOG_DAO_EXCEPTION_IN_UPDATE_TERM_READ_ADMIN_COUNT = "LOG_BAI692_018";

}
