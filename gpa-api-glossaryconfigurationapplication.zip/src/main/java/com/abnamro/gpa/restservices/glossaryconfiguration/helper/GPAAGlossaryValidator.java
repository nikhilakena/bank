/**
 *
 */
package com.abnamro.gpa.restservices.glossaryconfiguration.helper;

import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationLogConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Message;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.MessageType;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Messages;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;


/**
 * This is a Validator class used to validate the input provided in rest service
 */
@Component
@Slf4j
public class GPAAGlossaryValidator {

  private static final String GLOSSARY_SEARCH_DATE_FORMAT = "dd-MM-yyyy";

  /**
   * This method validates the data provided in search criteria of glossary
   *
   * @param termId          is String value of term id
   * @param termName        is String
   * @param createdBy       is String
   * @param createdDateFrom is String
   * @param createdDateTo   is String
   * @throws GPAAGlossaryApplicationException is used to throw the validation exception
   */
  public void validateGlossarySearchCriteria(String termId, String termName, String createdBy,
      String createdDateFrom, String createdDateTo) throws GPAAGlossaryApplicationException {
    if (isGlossarySearchDataEmpty(termId, termName, createdBy, createdDateFrom, createdDateTo)) {
      log.info("Glossary search data is empty");
      Messages messages = new Messages();
      messages.addMessage(new Message(
              GPAAGlossaryConfigurationMessageKeyConstants.ATLEAST_ONE_SEARCH_CRITERIA_IS_REQUIRED_IN_GLOSSARY_SEARCH),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    }
    validateDate(createdDateFrom, createdDateTo);
    validateTermId(termId);
  }

  /**
   * This Method is used to check null value of search data
   *
   * @param termId          unique identifier of the term
   * @param termName        term name
   * @param createdBy       user id of created user
   * @param createdDateFrom from part of created Date
   * @param createdDateTo   to part of created Date
   * @return true if search data is empty else false
   */
  private boolean isGlossarySearchDataEmpty(String termId, String termName, String createdBy, String createdDateFrom,
      String createdDateTo) {

    return (StringUtils.isEmpty(termId) && StringUtils.isEmpty(termName)
        && StringUtils.isEmpty(createdBy)
        && isDateEmpty(createdDateFrom, createdDateTo));
  }

  /**
   * This Method is used to check empty date
   *
   * @param createdDateFrom from part of created Date
   * @param createdDateTo   to part of created Date
   * @return returns true if dates are empty
   */
  private boolean isDateEmpty(String createdDateFrom, String createdDateTo) {
    return StringUtils.isEmpty(createdDateFrom)
        && StringUtils.isEmpty(createdDateTo);
  }

  /**
   * This Method is used to validate created from  and created until date
   *
   * @param createdDateFrom from part of created Date
   * @param createdDateTo   to part of created Date
   * @throws GPAAGlossaryApplicationException
   */
  private void validateDate(String createdDateFrom, String createdDateTo)
      throws GPAAGlossaryApplicationException {
    Date createdToDate = null;
    Date createdFromDate = null;
    if (StringUtils.isNotEmpty(createdDateFrom)) {
      createdFromDate = validateStringDate(createdDateFrom.trim());
    }
    if (StringUtils.isNotEmpty(createdDateTo)) {
      createdToDate = validateStringDate(createdDateTo.trim());
    }
    if (null != createdFromDate && null != createdToDate) {
      if (createdFromDate.after(createdToDate)) {
        log.info("Created from date is after the created to date");
        Messages messages = new Messages();
        messages.addMessage(new Message(
                GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_SEARCH_FROM_DATE_CAN_NOT_BE_GREATER_THAN_TO_DATE),
            MessageType.getError());
        throw new GPAAGlossaryApplicationException(messages);
      }
    }
  }

  /**
   * This method validates the input date format
   *
   * @param inputDate date in string format
   * @return converted Date
   * @throws GPAAGlossaryApplicationException
   */
  private Date validateStringDate(String inputDate) throws GPAAGlossaryApplicationException {
    final String LOG_METHOD = "validateStringDate(String inputDate):Date";
    DateFormat format = new SimpleDateFormat(GLOSSARY_SEARCH_DATE_FORMAT, Locale.getDefault());
    Date date = null;
    try {
      date = format.parse(inputDate);
    } catch (ParseException e) {
      log.error(LOG_METHOD + GPAAGlossaryConfigurationLogConstants.LOG_INVALID_DATE_IN_SEARCH_GLOSSARY, e);
      Messages messages = new Messages();
      messages.addMessage(new Message(GPAAGlossaryConfigurationMessageKeyConstants.PARSING_EXCEPTION),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    }
    return date;

  }

  /**
   * This Method is used to check empty termId
   *
   * @param termId unique Identifier of term
   * @throws GPAAGlossaryApplicationException in case validation fails
   */
  private void validateTermId(String termId) throws GPAAGlossaryApplicationException {
    final String LOG_METHOD = "validateTermId(String termId):void";
    if (StringUtils.isNotEmpty(termId) && getIntFromString(termId) <= 0) {
      log.error(LOG_METHOD + GPAAGlossaryConfigurationLogConstants.LOG_INVALID_TERM_ID_SEARCH_GLOSSARY);
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_TERM_ID_IS_NOT_NUMERIC),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    }
  }

  /**
   * This Method is used to get int value from string for termId
   *
   * @param termId unique Identifier of term
   * @return integer value of termid
   * @throws GPAAGlossaryApplicationException in caseof invalid numeric value
   */
  private int getIntFromString(String termId) throws GPAAGlossaryApplicationException {
    final String LOG_METHOD = "getIntFromString(String termId):int";
    int termIdValue;
    try {
      termIdValue = Integer.parseInt(termId);
    } catch (NumberFormatException e) {
      log.error(LOG_METHOD + GPAAGlossaryConfigurationLogConstants.LOG_INVALID_TERM_ID_SEARCH_GLOSSARY,
          e);
      Messages messages = new Messages();
      messages.addMessage(new Message(GPAAGlossaryConfigurationMessageKeyConstants.PARSING_EXCEPTION),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    }
    return termIdValue;
  }

  /**
   * This method is used to validate if the input term data is empty or not
   *
   * @param termRestResource is TermRestResource
   * @throws GPAAGlossaryApplicationException is used to throw validation exception
   */
  public void isTermDataEmpty(TermRestResource termRestResource) throws GPAAGlossaryApplicationException {
    if (null == termRestResource || StringUtils.isEmpty(termRestResource.getName())
        || StringUtils.isEmpty(termRestResource.getDescription())) {
      log.info("Term data is empty");
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_CREATE),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    }
  }

  /**
   * This Method is used to validate input provided for updating term
   *
   * @param termRestResource is TermRestResource
   * @throws GPAAGlossaryApplicationException in case calidation fails
   */
  public void validateUpdateTerm(TermRestResource termRestResource) throws GPAAGlossaryApplicationException {
    if (termRestResource.getId() < 1 || StringUtils.isEmpty(termRestResource.getName())
        || StringUtils.isEmpty(termRestResource.getDescription())
        || StringUtils.isEmpty(termRestResource.getDataType().name())) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    }
  }
}
