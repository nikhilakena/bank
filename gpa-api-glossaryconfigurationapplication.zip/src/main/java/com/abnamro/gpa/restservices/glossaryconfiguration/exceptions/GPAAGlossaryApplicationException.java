/**
 *
 */
package com.abnamro.gpa.restservices.glossaryconfiguration.exceptions;

import com.abnamro.gpa.restresource.exception.Errors;
import java.util.List;
import org.springframework.http.HttpStatus;

/**
 * This is custom exception class for the GPAAGlossaryApplication
 */
public class GPAAGlossaryApplicationException extends BusinessApplicationException {

  private transient Errors errors = null;

  private HttpStatus status;

  private List<String> params;

  /**
   * Instantiates a new Gpaa glossary application exception.
   */
  public GPAAGlossaryApplicationException() {
    super();
  }

  /**
   * Instantiates a new Gpaa glossary application exception.
   *
   * @param exception the exception
   */
  public GPAAGlossaryApplicationException(BusinessApplicationException exception) {
    super(exception);
  }

  /**
   * Instantiates a new Gpaa glossary application exception.
   *
   * @param messages the messages
   */
  public GPAAGlossaryApplicationException(Messages messages) {
    super(messages);
  }

  /**
   * Instantiates a new Gpaa glossary application exception.
   *
   * @param errors the errors
   */
  public GPAAGlossaryApplicationException(Errors errors) {
    this.errors = errors;
  }

  /**
   * Gets error message wrapper.
   *
   * @return the errormessageWrapper
   */
  public Errors getErrorMessageWrapper() {
    return errors;
  }


  /**
   * Gets status.
   *
   * @return the status
   */
  public HttpStatus getStatus() {
    return this.status;
  }

  /**
   * Gets params.
   *
   * @return the params
   */
  public List<String> getParams() {
    return params;
  }


}
