/**
 *
 */
package com.abnamro.gpa.restservices.glossaryconfiguration.helper;

import com.abnamro.gpa.generic.glossarydao.dtos.GlossarySearchCriteriaView;
import com.abnamro.gpa.generic.glossarydao.dtos.TermView;
import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossaryConfigurationResultDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossarySearchCriteriaDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Message;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.MessageType;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Messages;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * This is a mapper class for the Glossary Configuration
 */
@Component
public class TermRestViewMapper {

  /**
   * The constant GLOSSARY_SEARCH_DATE_FORMAT.
   */
  public static final String GLOSSARY_SEARCH_DATE_FORMAT = "dd-MM-yyyy";

  /**
   * This method maps the GlossarySearchCriteriaDTO of rest layer to GlossarySearchCriteriaView of DAO layer
   *
   * @param glossarySearchCriteraDTO is GlossarySearchCriteriaDTO
   * @return glossarySearchCriteriaView is GlossarySearchCriteriaView
   * @throws GPAAGlossaryApplicationException is used to throw validation exception of date
   */
  public GlossarySearchCriteriaView populateGlossarySearchCriteraView(
      GlossarySearchCriteriaDTO glossarySearchCriteraDTO) throws GPAAGlossaryApplicationException {
    GlossarySearchCriteriaView glossarySearchCriteriaView = new GlossarySearchCriteriaView();

    if (null != glossarySearchCriteraDTO) {
      glossarySearchCriteriaView.setTermId(glossarySearchCriteraDTO.getTermId());
      if (StringUtils.isNotEmpty(glossarySearchCriteraDTO.getTermName())) {
        glossarySearchCriteriaView.setTermName(glossarySearchCriteraDTO.getTermName().trim());
      }
      if (StringUtils.isNotEmpty(glossarySearchCriteraDTO.getCreatedBy())) {
        glossarySearchCriteriaView.setCreatedBy(glossarySearchCriteraDTO.getCreatedBy().trim());
      }
      if (StringUtils.isNotEmpty(glossarySearchCriteraDTO.getCreatedTimestampFrom())) {
        Timestamp ts = convertStringDatetoTimestamp(glossarySearchCriteraDTO.getCreatedTimestampFrom().trim(), true);
        glossarySearchCriteriaView.setCreatedTimestampFrom(ts);
      }
      if (StringUtils.isNotEmpty(glossarySearchCriteraDTO.getCreatedTimestampTo())) {
        Timestamp ts = convertStringDatetoTimestamp(glossarySearchCriteraDTO.getCreatedTimestampTo().trim(), false);
        glossarySearchCriteriaView.setCreatedTimestampTo(ts);
      }
    }
    return glossarySearchCriteriaView;
  }


  private Timestamp convertStringDatetoTimestamp(String inputDate, boolean isFromDate)
      throws GPAAGlossaryApplicationException {
    Date date = getDateFromString(inputDate);
    Timestamp ts = null;
    if (null != date) {
      if (!isFromDate) {
        ts = new Timestamp(setMaxTime(date).getTime());
      } else {
        ts = new Timestamp(date.getTime());
      }
    }
    return ts;
  }

  private Date getDateFromString(String sDate) throws GPAAGlossaryApplicationException {
    DateFormat format = new SimpleDateFormat(GLOSSARY_SEARCH_DATE_FORMAT, Locale.getDefault());
    java.util.Date date = null;
    try {
      date = format.parse(sDate);
    } catch (ParseException e) {
      Messages messages = new Messages();
      messages.addMessage(new Message(GPAAGlossaryConfigurationMessageKeyConstants.PARSING_EXCEPTION),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    }
    return date;
  }

  private static Date setMaxTime(Date date) {
    Calendar cal = Calendar.getInstance();
    cal.setTime(date);
    cal.set(Calendar.HOUR_OF_DAY, 23);
    cal.set(Calendar.MINUTE, 59);
    cal.set(Calendar.SECOND, 59);
    cal.set(Calendar.MILLISECOND, 59);
    return cal.getTime();
  }

  /**
   * This Method is used to convert Glossary view to rest resource
   *
   * @param termList input list of terms
   * @return list of TermRestResource
   */
  public List<TermRestResource> convertGlossaryViewToTermRestResource(List<TermView> termList) {
    List<TermRestResource> termRestResourceList = null;

    if (null != termList && !termList.isEmpty()) {
      termRestResourceList = new ArrayList<TermRestResource>();
      for (TermView termView : termList) {

        TermRestResource termRestResource = convertTermViewToTermRestResource(termView);
        termRestResourceList.add(termRestResource);
      }
    }

    return termRestResourceList;
  }

  private AuditDetails setAuditDetails(String createdBy, Timestamp createdDate, String updatedBy,
      Timestamp updatedDate) {
    AuditDetails auditDetails = new AuditDetails();
    if (StringUtils.isNotEmpty(createdBy)) {
      auditDetails.setCreatedBy(createdBy.trim());
    }
    if (StringUtils.isNotEmpty(updatedBy)) {
      auditDetails.setModifiedBy(updatedBy.trim());
    }
    if (null != createdDate) {
      auditDetails.setCreatedTimeStamp(createdDate);
    }
    if (null != updatedDate) {
      auditDetails.setModifiedTimeStamp(updatedDate);
    }
    return auditDetails;

  }

  /**
   * This Method is used to rest resource to Glossary view
   *
   * @param termRestResource is term rest resource
   * @return converted TermView
   */
  public TermView convertTermRestResourceToTermView(TermRestResource termRestResource) {
    TermView termView = new TermView();
    termView.setId(termRestResource.getId());
    termView.setName(termRestResource.getName());
    termView.setDescription(termRestResource.getDescription());
    termView.setDataType(termRestResource.getDataType().name());

    termView.setCreatedBy(termRestResource.getAuditDetails().getCreatedBy());
    termView.setModifiedBy(termRestResource.getAuditDetails().getModifiedBy());

    return termView;
  }

  /**
   * This Method is used to set term Id in Result DTO
   *
   * @param termId unique identifier of the term
   * @return GlossaryConfigurationResultDTO glossary configuration result dto
   */
  public GlossaryConfigurationResultDTO convertToResultDTO(int termId) {
    GlossaryConfigurationResultDTO glossaryConfigurationResultDTO = new GlossaryConfigurationResultDTO();

    glossaryConfigurationResultDTO.setIdentifier(termId);
    glossaryConfigurationResultDTO.setIndicatorSuccess(true);

    return glossaryConfigurationResultDTO;
  }

  /**
   * This Method is used to convert Term view into Term rest resource
   *
   * @param termView input term view for conversion
   * @return Term Rest Resource
   */
  public TermRestResource convertTermViewToTermRestResource(TermView termView) {
    TermRestResource termRestResource = new TermRestResource();
    termRestResource.setId(termView.getId());

    if (StringUtils.isNotEmpty(termView.getName())) {
      termRestResource.setName(termView.getName().trim());
    }
    if (StringUtils.isNotEmpty(termView.getDescription())) {
      termRestResource.setDescription(termView.getDescription().trim());
    }
    if (StringUtils.isNotEmpty(termView.getDataType())) {
      termRestResource.setDataType(convertStringDataTypeToEnumValue(termView.getDataType()));
    }

    AuditDetails auditDetails = setAuditDetails(termView.getCreatedBy(), termView.getCreatedTimeStamp(),
        termView.getModifiedBy(), termView.getModifiedTimeStamp());

    termRestResource.setAuditDetails(auditDetails);

    return termRestResource;
  }

  private TermDataType convertStringDataTypeToEnumValue(String dataType) {
    TermDataType enumValueOfDataType = null;

    if (StringUtils.isNotEmpty(dataType)) {
      enumValueOfDataType = TermDataType.valueOf(dataType.trim());
    }
    return enumValueOfDataType;
  }

}
