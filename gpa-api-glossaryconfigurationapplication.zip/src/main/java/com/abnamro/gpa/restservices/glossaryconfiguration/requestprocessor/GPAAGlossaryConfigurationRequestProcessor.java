/**
 *
 */
package com.abnamro.gpa.restservices.glossaryconfiguration.requestprocessor;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.glossarydao.dao.GPAAGlossaryDAO;
import com.abnamro.gpa.generic.glossarydao.dtos.GlossarySearchCriteriaView;
import com.abnamro.gpa.generic.glossarydao.dtos.TermView;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryDAOException;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationLogConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossaryConfigurationResultDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossarySearchCriteriaDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Message;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.MessageType;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Messages;
import com.abnamro.gpa.restservices.glossaryconfiguration.helper.TermRestViewMapper;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Request processor class for the GlossaryConfiguration Application
 */
@Component
@Slf4j
public class GPAAGlossaryConfigurationRequestProcessor {

  private GPAAGlossaryDAO glossaryDetailsDB2DAO;

  private TermRestViewMapper termRestViewMapper;

  private GPAAdministrationDAO gpaAdministrationDAO;

  /**
   * Parameterized constructor.
   *
   * @param glossaryDetailsDB2DAO GPAAGlossaryDAO : dbProcessor class
   * @param termRestViewMapper    the term rest view mapper
   * @param gpaAdministrationDAO  This constructor will only be used by the junit tests.
   */
  @Autowired
  public GPAAGlossaryConfigurationRequestProcessor(
      GPAAGlossaryDAO glossaryDetailsDB2DAO,
      TermRestViewMapper termRestViewMapper, GPAAdministrationDAO gpaAdministrationDAO) {
    this.glossaryDetailsDB2DAO = glossaryDetailsDB2DAO;
    this.termRestViewMapper = termRestViewMapper;
    this.gpaAdministrationDAO = gpaAdministrationDAO;
  }

  /**
   * Default constructor.
   */
  public GPAAGlossaryConfigurationRequestProcessor() {
  }


  /**
   * This method processes the searchGlossary request from rest layer and calls the DAO service
   *
   * @param glossarySearchCriteriaDTO is  GlossarySearchCriteriaDTO
   * @return list of TermRestResource
   * @throws GPAAGlossaryApplicationException is used to throw the glossaryDAOException
   */
  public List<TermRestResource> searchGlossary(GlossarySearchCriteriaDTO glossarySearchCriteriaDTO)
      throws GPAAGlossaryApplicationException {
    final String LOG_METHOD = "searchGlossary(GlossarySearchCriteriaDTO):List<TermRestResource>";
    List<TermView> termViewList;
    List<TermRestResource> termRestResourceList = null;
    try {
      if (null != glossarySearchCriteriaDTO) {
        GlossarySearchCriteriaView glossarySearchCriteriaView = termRestViewMapper
            .populateGlossarySearchCriteraView(glossarySearchCriteriaDTO);
        log.info("{}: TermId: {}", LOG_METHOD, glossarySearchCriteriaView.getTermId());
        termViewList = glossaryDetailsDB2DAO.searchGlossary(glossarySearchCriteriaView);
        log.info("{}: Size of termViewList: {}", LOG_METHOD, termViewList != null ? termViewList.size() : 0);

        termRestResourceList = termRestViewMapper.convertGlossaryViewToTermRestResource(termViewList);
      }
    } catch (GPAAGlossaryDAOException glossaryDAOException) {
      log.error("{} {}", LOG_METHOD,
          GPAAGlossaryConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_SEARCH_GLOSSARY_REQUEST_PROCESSOR,
          glossaryDAOException);
      throw new GPAAGlossaryApplicationException(glossaryDAOException);
    }
    return termRestResourceList;
  }

  /**
   * This method is used to create a term
   *
   * @param termRestResource is TermRestResource
   * @return glossaryConfigurationResultDTO is GlossaryConfigurationResultDTO
   * @throws GPAAGlossaryApplicationException is used to throw the glossaryDAOException
   */
  public GlossaryConfigurationResultDTO createTerm(TermRestResource termRestResource)
      throws GPAAGlossaryApplicationException {
    final String LOG_METHOD = "createTerm(TermRestResource) ";
    log.info("Creating term");
    TermView termView = termRestViewMapper.convertTermRestResourceToTermView(termRestResource);
    GlossaryConfigurationResultDTO glossaryConfigurationResultDTO = null;
    try {
      int termId = glossaryDetailsDB2DAO.createTerm(termView);
      glossaryConfigurationResultDTO = termRestViewMapper.convertToResultDTO(termId);

    } catch (GPAAGlossaryDAOException glossaryDAOException) {
      log.error(
          LOG_METHOD + GPAAGlossaryConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_CREATE_TERM_REQUEST_PROCESSOR,
          glossaryDAOException);
      throw new GPAAGlossaryApplicationException(glossaryDAOException);
    }
    return glossaryConfigurationResultDTO;
  }

  /**
   * This method is used to delete a term
   *
   * @param termId unique Identifier of the term
   * @return glossaryConfigurationResultDTO is GlossaryConfigurationResultDTO
   * @throws GPAAGlossaryApplicationException in case of exception
   */
  public GlossaryConfigurationResultDTO deleteTerm(int termId) throws GPAAGlossaryApplicationException {
    final String LOG_METHOD = "deleteGlossary(int):termId ";
    GlossaryConfigurationResultDTO result = null;
    try {
      boolean deletionStatus = glossaryDetailsDB2DAO.deleteTerm(termId);
      result = new GlossaryConfigurationResultDTO();
      result.setIndicatorSuccess(deletionStatus);

    } catch (GPAAGlossaryDAOException glossaryDAOException) {
      log.error("{} {}", LOG_METHOD,
          GPAAGlossaryConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_DELETE_GLOSSARY_REQUEST_PROCESSOR,
          glossaryDAOException);
      throw new GPAAGlossaryApplicationException(glossaryDAOException);
    }
    return result;
  }

  /**
   * This method is used to read a term
   *
   * @param termId unique Identifier of the term
   * @return term rest resource
   * @throws GPAAGlossaryApplicationException in case of exception
   */
  public TermRestResource readTerm(int termId) throws GPAAGlossaryApplicationException {
    final String LOG_METHOD = "readGlossary(int):termId ";
    TermView termView = null;
    TermRestResource termRestResource = null;
    try {
      termView = glossaryDetailsDB2DAO.readTerm(termId);
      termRestResource = termRestViewMapper.convertTermViewToTermRestResource(termView);

    } catch (GPAAGlossaryDAOException glossaryDAOException) {
      log.error(LOG_METHOD + GPAAGlossaryConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_READ_TERM_REQUEST_PROCESSOR,
          glossaryDAOException);
      throw new GPAAGlossaryApplicationException(glossaryDAOException);
    }
    return termRestResource;
  }

  /**
   * This method is used to retrieve all term details
   *
   * @return List of TermRestResource
   * @throws GPAAGlossaryApplicationException GPAAGlossaryApplicationException Exception thrown at application layer
   */
  public List<TermRestResource> retrieveAllTerms() throws GPAAGlossaryApplicationException {
    final String LOG_METHOD = "retrieveAllTerms() ";
    List<TermView> termViewList = null;
    List<TermRestResource> termRestResourceList = null;
    try {
      termViewList = glossaryDetailsDB2DAO.retrieveAllTerms();
      if (termViewList != null && !termViewList.isEmpty()) {
        termRestResourceList = new ArrayList<TermRestResource>();
        for (TermView termView : termViewList) {
          TermRestResource termRestResource = termRestViewMapper.convertTermViewToTermRestResource(termView);
          termRestResourceList.add(termRestResource);
        }
      }
    } catch (GPAAGlossaryDAOException glossaryDAOException) {
      log.error(
          LOG_METHOD + GPAAGlossaryConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_RETRIEVE_ALL_TERMS_REQUEST_PROCESSOR,
          glossaryDAOException);
      throw new GPAAGlossaryApplicationException(glossaryDAOException);
    }
    return termRestResourceList;
  }

  /**
   * This method is used to update a term
   *
   * @param termRestResource input Term rest resource
   * @return glossaryConfigurationResultDTO containing result
   * @throws GPAAGlossaryApplicationException in case of exception
   */
  public GlossaryConfigurationResultDTO updateTerm(TermRestResource termRestResource)
      throws GPAAGlossaryApplicationException {
    final String LOG_METHOD = "updateTerm(TermRestResource):List<TermRestResource> ";

    TermView termView = termRestViewMapper.convertTermRestResourceToTermView(termRestResource);
    GlossaryConfigurationResultDTO glossaryConfigurationResultDTO = new GlossaryConfigurationResultDTO();
    try {
      TermView currentTermView = glossaryDetailsDB2DAO.readTerm(termRestResource.getId());
      validateTermDataUpdates(termView, currentTermView);

      boolean indicatorSuccess = glossaryDetailsDB2DAO.updateTerm(termView);
      glossaryConfigurationResultDTO.setIndicatorSuccess(indicatorSuccess);
      glossaryConfigurationResultDTO.setIdentifier(termRestResource.getId());

    } catch (GPAAGlossaryDAOException glossaryDAOException) {
      log.error(
          LOG_METHOD + GPAAGlossaryConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_UPDATE_TERM_REQUEST_PROCESSOR,
          glossaryDAOException);
      throw new GPAAGlossaryApplicationException(glossaryDAOException);

    } catch (GPAAdministrationDAOException e) {
      log.error(LOG_METHOD + GPAAGlossaryConfigurationLogConstants.LOG_DAO_EXCEPTION_IN_UPDATE_TERM_READ_ADMIN_COUNT,
          e);
      throw new GPAAGlossaryApplicationException(e);
    }
    return glossaryConfigurationResultDTO;
  }

  /**
   * This method is used to compare term data with provided in input and latest in database
   *
   * @param termView        updated term view
   * @param currentTermView current term view
   * @throws GPAAGlossaryApplicationException in case of exception
   * @throws GPAAdministrationDAOException    in case of administration exception
   */
  private void validateTermDataUpdates(TermView termView, TermView currentTermView)
      throws GPAAGlossaryApplicationException, GPAAdministrationDAOException {
    if (termView.getName().equals(currentTermView.getName())
        && termView.getDescription().equalsIgnoreCase(currentTermView.getDescription())
        && termView.getDataType().equalsIgnoreCase(currentTermView.getDataType())) {

      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_NO_UPDATES),
          MessageType.getError());
      throw new GPAAGlossaryApplicationException(messages);
    } else if (!termView.getName().equals(currentTermView.getName())) {
      try {
        //Call administration dao to check if there is any administration present for the term to be updated.
        boolean flag = gpaAdministrationDAO.isAdministrationPresentForTerm(termView.getId());

        log.info("validateTermDataUpdates {}", flag);

        if (flag) {
          Messages messages = new Messages();
          messages.addMessage(new Message(
                  GPAAGlossaryConfigurationMessageKeyConstants.EXCEPTION_IN_GLOSSARY_TERM_NAME_UPDATE_NOT_ALLOWED),
              MessageType.getError());
          throw new GPAAGlossaryApplicationException(messages);
        }
      } catch (GPAAGlossaryDAOException exception) {
        Messages messages = new Messages();
        messages.addMessage(new Message(
                GPAAGlossaryConfigurationMessageKeyConstants.DATABASE_EXCEPTION_WHILE_RETRIEVE_ADMINID_FOR_TERM),
            MessageType.getError());
        throw new GPAAGlossaryApplicationException(messages);
      }
    }
  }
}
