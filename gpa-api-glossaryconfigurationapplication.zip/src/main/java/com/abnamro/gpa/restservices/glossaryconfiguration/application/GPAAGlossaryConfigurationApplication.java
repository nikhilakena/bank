package com.abnamro.gpa.restservices.glossaryconfiguration.application;


import jakarta.annotation.PostConstruct;
import java.util.TimeZone;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.web.bind.annotation.CrossOrigin;


/**
 * The type Gpaa glossary configuration application.
 */
@SpringBootApplication(scanBasePackages = "com.abnamro.gpa")
@MapperScan({"com.abnamro.gpa.generic.administrationdao.dao", "com.abnamro.gpa.generic.glossarydao.dao"})
@CrossOrigin
public class GPAAGlossaryConfigurationApplication extends SpringBootServletInitializer {

  /**
   * The entry point of application.
   *
   * @param args the input arguments
   */
  public static void main(String[] args) {
    SpringApplication.run(GPAAGlossaryConfigurationApplication.class, args);
  }

  /**
   * Set the timezone to Europe/Amsterdam
   */
  @PostConstruct
  public void setTimeZoneToDutch() {
    TimeZone.setDefault(TimeZone.getTimeZone("Europe/Amsterdam"));
  }
}
