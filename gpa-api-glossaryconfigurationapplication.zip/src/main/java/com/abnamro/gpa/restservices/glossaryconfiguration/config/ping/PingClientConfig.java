package com.abnamro.gpa.restservices.glossaryconfiguration.config.ping;


import com.abnamro.gpa.generic.security.PingFederateValidateUserInfo;
import com.abnamro.gpa.restresource.exception.Errors;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.ErrorKeys;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.AuthenticationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.util.ErrorAndLogUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClientException;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * The type Ping client config.
 */
@Configuration
@Slf4j
public class PingClientConfig {

  @Autowired
  @Qualifier("pingHttpClient")
  private HttpClient httpClient;

  @Autowired
  private ObjectMapper mapper;

  @Value("${ping.abn.http.host}")
  private String pingURL;

  @Value("${ping.abn.token}")
  private String pingToken;

  /**
   * The Ping introspect url.
   */
  @Value("${ping.introspect.url}")
  protected String pingIntrospectURL;

  /**
   * The Ping introspect client id.
   */
  @Value("${ping.introspect.client.id}")
  protected String pingIntrospectClientId;

  /**
   * The Ping introspect client secret.
   */
  @Value("${ping.introspect.client.secret}")
  protected String pingIntrospectClientSecret;

  /**
   * Gets access token.
   *
   * @param token the token
   * @return the access token
   * @throws AuthenticationException the authentication exception
   */
  public PingFederateValidateUserInfo getAccessToken(String token) throws AuthenticationException {
    PingFederateValidateUserInfo pingFederateUserInfoDTO;

    try {
      final String charSet = "ASCII";
      String pingIntrospectCreds = pingIntrospectClientId + ":" + pingIntrospectClientSecret;
      byte[] plainCredsBytes = pingIntrospectCreds.getBytes(Charset.forName(charSet));
      byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
      String base64Creds = new String(base64CredsBytes, charSet);
      UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(pingURL + pingIntrospectURL)
          .queryParam("token", token);

      HttpRequest request =
          HttpRequest.newBuilder()
              .uri(URI.create(builder.toUriString()))
              .setHeader("Authorization", "Basic " + base64Creds)
              .setHeader(HttpHeaders.CONTENT_TYPE, "application/x-www-form-urlencoded")
              .setHeader(HttpHeaders.ACCEPT, MediaType.ALL_VALUE)
              .POST(HttpRequest.BodyPublishers.noBody())
              .build();

      HttpResponse<String> response =
          httpClient.send(request, HttpResponse.BodyHandlers.ofString());
      log.info("getAccessToken  " + response.statusCode());
      if (response.statusCode() == HttpStatus.OK.value()) {
        ObjectMapper objectMapper = new ObjectMapper();
        pingFederateUserInfoDTO = objectMapper.setPropertyNamingStrategy(PropertyNamingStrategy.LOWER_CASE)
            .readValue(response.body(), PingFederateValidateUserInfo.class);
        return pingFederateUserInfoDTO;
      } else {
        log.error("getAccessToken  " + response.statusCode());
        Errors errors = new Errors();
        ErrorAndLogUtils.setError(errors, ErrorKeys.AUTHENTICATION_EXCEPTION.getCode(),
            ErrorKeys.AUTHENTICATION_EXCEPTION.getMessage());
        throw new AuthenticationException(errors);
      }
    } catch (RestClientException | IOException | InterruptedException e) {
      log.error("getAccessToken  ", e);
      Errors errors = new Errors();
      ErrorAndLogUtils.setError(errors, ErrorKeys.AUTHENTICATION_EXCEPTION.getCode(),
          ErrorKeys.AUTHENTICATION_EXCEPTION.getMessage());
      throw new AuthenticationException(errors);
    }
  }

  /**
   * Call ping api map.
   *
   * @param code         the code
   * @param grant_type   the grant type
   * @param redirect_uri the redirect uri
   * @return the map
   * @throws AuthenticationException          the authentication exception
   * @throws GPAAGlossaryApplicationException the GPA glossary application exception
   */
  public Map<String, String> callPingAPI(String code, String grant_type,
      String redirect_uri) throws AuthenticationException, GPAAGlossaryApplicationException {

    try {
      final String charSet = "ASCII";
      String pingIntrospectCreds = pingIntrospectClientId + ":" + pingIntrospectClientSecret;
      byte[] plainCredsBytes = pingIntrospectCreds.getBytes(Charset.forName(charSet));
      byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
      String base64Creds = new String(base64CredsBytes, charSet);
      Map<String, String> params = new HashMap<>();
      params.put("client_id", pingIntrospectClientId);
      params.put("code", code);
      params.put("grant_type", "authorization_code");
      params.put("redirect_uri", redirect_uri);

      UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(pingURL + pingToken);
      String urlEncoded = params.entrySet()
          .stream()
          .map(e -> e.getKey() + "=" + URLEncoder.encode(e.getValue(), StandardCharsets.UTF_8))
          .collect(Collectors.joining("&"));
      HttpRequest request =
          HttpRequest.newBuilder()
              .uri(URI.create(builder.toUriString()))

              .setHeader("Authorization", "Basic " + base64Creds)
              .setHeader(HttpHeaders.CONTENT_TYPE, "application/x-www-form-urlencoded")
              .setHeader(HttpHeaders.ACCEPT, MediaType.ALL_VALUE)
              .POST(HttpRequest.BodyPublishers.ofString(urlEncoded))
              .build();
      log.debug(
          "HttpRequest for calling ping API: {} using the httpClient version {} and context provider {}, SSL Parameters {}",
          request, httpClient.version(), httpClient.sslContext().getProvider(), httpClient.sslParameters());
      HttpResponse<String> httpsResponse =
          httpClient.send(request, HttpResponse.BodyHandlers.ofString());

      log.info("callPingAPI: status code " + httpsResponse.statusCode());
      if (httpsResponse.statusCode() != HttpStatus.OK.value()) {

        log.error("Response Body: {}", httpsResponse.body().toString());
        Errors errors = mapper.readValue(httpsResponse.body().toString(), Errors.class);
        throw new AuthenticationException(errors);
      }

      JSONObject responseObject = mapper.readValue(httpsResponse.body().toString(), JSONObject.class);

      Map<String, String> tokenMap = new HashMap<>();

      String access_token = Optional.ofNullable(responseObject.getAsString("access_token"))
          .orElseThrow(
              () -> {
                Errors errors = new Errors();

                ErrorAndLogUtils.setError(errors, ErrorKeys.OTHER_EXCEPTION.getCode(),
                    ErrorKeys.OTHER_EXCEPTION.getMessage());

                return new GPAAGlossaryApplicationException(
                    errors);
              });
      String id_token = Optional.ofNullable(responseObject.getAsString("id_token")).orElseThrow(
          () -> {
            Errors errors = new Errors();
            ErrorAndLogUtils.setError(errors, ErrorKeys.OTHER_EXCEPTION.getCode(),
                ErrorKeys.OTHER_EXCEPTION.getMessage());

            return new GPAAGlossaryApplicationException(
                errors);
          });

      tokenMap.put("access_token", access_token);
      tokenMap.put("id_token", id_token);

      return tokenMap;
    } catch (RestClientException | IOException | InterruptedException e) {
      log.error("callPingAPI: " + e.getMessage(), e);
      Errors errors = new Errors();
      ErrorAndLogUtils.setError(errors, ErrorKeys.AUTHENTICATION_EXCEPTION.getCode(),
          ErrorKeys.AUTHENTICATION_EXCEPTION.getMessage());
      throw new AuthenticationException(errors);
    }
  }
}
