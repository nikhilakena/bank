/**
 *
 */
package com.abnamro.gpa.generic.glossarydao.dao;

import com.abnamro.gpa.generic.glossarydao.dtos.GlossarySearchCriteriaView;
import com.abnamro.gpa.generic.glossarydao.dtos.TermView;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryConfigurationMessageKeys;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryDAOException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Message;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.MessageType;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Messages;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This is dao layer class for GPA Glossary and has operation related to Glossary.
 */
@Component
@Slf4j
public class GPAAGlossaryDAO {

  @Autowired
  private SqlSessionFactory sessionFactory;

  /**
   * This is method calls the searchGlossary method at DAO layer
   *
   * @param glossarySearchCriteriaView is GlossarySearchCriteriaView
   * @return termViewList List of TermView
   * @throws GPAAGlossaryDAOException is DAO exception
   */
  public List<TermView> searchGlossary(GlossarySearchCriteriaView glossarySearchCriteriaView)
      throws GPAAGlossaryDAOException {
    String logMethod = "searchGlossary";
    List<TermView> termViewList = null;

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      if (null != glossarySearchCriteriaView && StringUtils.isNotEmpty(glossarySearchCriteriaView.getTermName())) {
        glossarySearchCriteriaView.setTermName(glossarySearchCriteriaView.getTermName().toLowerCase());
      }
      if (null != glossarySearchCriteriaView && StringUtils.isNotEmpty(glossarySearchCriteriaView.getCreatedBy())) {
        glossarySearchCriteriaView.setCreatedBy(glossarySearchCriteriaView.getCreatedBy().toLowerCase());
      }

      termViewList = sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class)
          .searchGlossary(glossarySearchCriteriaView);
    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAGlossaryConfigurationMessageKeys.MYBATIS_EXCEPTION_WHILE_READING_GLOSSARY_DETAILS),
          MessageType.getError());
      log.error(logMethod + GPAAGlossaryDAOLogConstants.LOG_ERROR_DATA_CREATE, exception);
      throw new GPAAGlossaryDAOException(messages);

    }
    return termViewList;
  }

  /**
   * This is method calls the createTerm method at DAO layer
   *
   * @param termView Term details
   * @return newly created term id
   * @throws GPAAGlossaryDAOException Exception thrown while creating term at DAO layer
   */
  public int createTerm(TermView termView) throws GPAAGlossaryDAOException {
    String logMethod = "createTerm(TermView) ";
    // call for retrieving max termId
    int termId = getMaxTermId();
    termView.setId(termId + 1);
    termView.setCreatedTimeStamp(new Timestamp(System.currentTimeMillis()));

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class).insertTerm(termView);
      sqlSession.commit();
    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAGlossaryConfigurationMessageKeys.MYBATIS_EXCEPTION_WHILE_CREATING_TERM),
          MessageType.getError());
      log.error(logMethod + GPAAGlossaryDAOLogConstants.LOG_ERROR_DATA_CREATE, exception);
      throw new GPAAGlossaryDAOException(messages);
    }
    return termId + 1;
  }

  /**
   * This is method is used to get max term id
   *
   * @return maximum term id from database
   * @throws GPAAGlossaryDAOException Exception thrown while getting maximum term id from database
   */
  public int getMaxTermId() throws GPAAGlossaryDAOException {
    final String logMethod = "getMaxTermId()";
    int termId = 0;

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      termId = sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class).getMaxTermId();
    } catch (PersistenceException exception) {
      // TODO to handle empty table
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAGlossaryConfigurationMessageKeys.MYBATIS_EXCEPTION_WHILE_RETRIEVE_MAX_TERM_ID),
          MessageType.getError());
      log.error(logMethod + GPAAGlossaryDAOLogConstants.LOG_ERROR_DATA_RETRIEVE_MAX_TERM_ID, exception);
      throw new GPAAGlossaryDAOException(messages);
    }
    return termId;
  }

  /**
   * This is method calls the readTerm method at DAO layer
   *
   * @param termId Unique id for term identification
   * @return term view
   * @throws GPAAGlossaryDAOException Exception thrown at DAO layer while reading term
   */
  public TermView readTerm(int termId) throws GPAAGlossaryDAOException {
    String logMethod = "readTerm(int)";
    TermView termView = null;

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      termView = sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class).readTerm(termId);
    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAGlossaryConfigurationMessageKeys.MYBATIS_EXCEPTION_WHILE_READING_TERM),
          MessageType.getError());
      log.error(logMethod + GPAAGlossaryDAOLogConstants.LOG_ERROR_DATA_CREATE, exception);
      throw new GPAAGlossaryDAOException(messages);

    }
    return termView;
  }

  /**
   * This method is used to delete the term id from glossary
   *
   * @param termId is integer
   * @return boolean value of result
   * @throws GPAAGlossaryDAOException is a DAO exception
   */
  public boolean deleteTerm(int termId) throws GPAAGlossaryDAOException {

    final String LOG_METHOD = "deleteTerm(int)";
    boolean result = false;
    GPAAGlossaryDAOHelper helper = new GPAAGlossaryDAOHelper();

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      helper.validateTermID(termId);
      int rowsAffected = sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class)
          .deleteTerm(termId);
      if (rowsAffected == 0) {
        Messages messages = new Messages();
        messages.addMessage(
            new Message(GPAAGlossaryConfigurationMessageKeys.VALIDATION_EXCEPTION_NO_DATA_FOUND_IN_DELETE_GLOSSARY),
            MessageType.getError());
        log.error(LOG_METHOD + GPAAGlossaryDAOLogConstants.LOG_ERROR_DATA_DELETION,
            null, null, null);
        throw new GPAAGlossaryDAOException(messages);
      }
      result = true;
      sqlSession.commit();
    } catch (PersistenceException exception) {
      log.error(LOG_METHOD + GPAAGlossaryDAOLogConstants.LOG_PERSISTENCE_EXCEPTION_ERROR_SERVICE_DELETE, null,
          exception);
      handlePersistenceExceptionForDeleteService(LOG_METHOD, exception);
    }
    return result;
  }

  private void handlePersistenceExceptionForDeleteService(String LOG_METHOD, PersistenceException exception)
      throws GPAAGlossaryDAOException {
    if (exception.getCause() instanceof SQLException) {
      SQLException sqlException = (SQLException) exception.getCause();
      log.info("handlePersistenceExceptionForDeleteService " + sqlException.getErrorCode());
      if (sqlException.getErrorCode() == 547) {
        log.error(
            LOG_METHOD + GPAAGlossaryDAOLogConstants.LOG_ERROR_THIS_TERM_IS_ALREADY_USED_BY_AN_ADMINISTRATION,
            sqlException);
        Messages messages = new Messages();
        messages.addMessage(
            new Message(GPAAGlossaryConfigurationMessageKeys.ERROR_THIS_TERM_IS_ALREADY_USED_BY_AN_ADMINISTRATION),
            MessageType.getError());
        throw new GPAAGlossaryDAOException(messages);

      } else {
        log.error(LOG_METHOD + GPAAGlossaryDAOLogConstants.LOG_ERROR_SQL_ERROR, exception);
        throw new GPAAGlossaryDAOException();
      }
    } else {
      log.error(LOG_METHOD + GPAAGlossaryDAOLogConstants.LOG_ERROR_SQL_ERROR, exception);
      throw new GPAAGlossaryDAOException();
    }
  }

  /**
   * This method calls the updateTerm method at DAO layer
   *
   * @param termView Term details
   * @return result of update operation
   * @throws GPAAGlossaryDAOException Exception thrown at DAO layer while reading term
   */
  public boolean updateTerm(TermView termView) throws GPAAGlossaryDAOException {
    String logMethod = "updateTerm";
    try (SqlSession sqlSession = sessionFactory.openSession()) {
      sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class).updateTerm(termView);
      sqlSession.commit();
    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAGlossaryConfigurationMessageKeys.MYBATIS_EXCEPTION_WHILE_UPDATING_TERM),
          MessageType.getError());
      log.error(logMethod + GPAAGlossaryDAOLogConstants.LOG_ERROR_DATA_UPDATE, exception);
      throw new GPAAGlossaryDAOException(messages);
    }
    return true;
  }

  /**
   * This is method retrieves all terms from the database
   *
   * @return TermViewList List of TermView contains list of term details
   * @throws GPAAGlossaryDAOException GPAAGlossaryDAOException Exception thrown at DAO layer
   */
  public List<TermView> retrieveAllTerms() throws GPAAGlossaryDAOException {
    Connection connection = null;
    String logMethod = "retrieveAllTerms:List<TermView>";
    List<TermView> termViewList = null;

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      termViewList = sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class).retrieveAllTerms();
    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      messages.addMessage(
          new Message(GPAAGlossaryConfigurationMessageKeys.MYBATIS_EXCEPTION_WHILE_RETRIEVING_ALL_TERMS),
          MessageType.getError());
      log.error(logMethod + GPAAGlossaryDAOLogConstants.LOG_ERROR_DATA_CREATE, exception);
      throw new GPAAGlossaryDAOException(messages);
    }
    return termViewList;
  }
}