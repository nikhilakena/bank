package com.abnamro.gpa.generic.glossarydao.dao;

import com.abnamro.gpa.generic.glossarydao.dtos.GlossarySearchCriteriaView;
import com.abnamro.gpa.generic.glossarydao.dtos.TermView;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * This is a mybatis mapper class
 */
@Mapper
public interface GPAAGlossaryDAOMybatisMapper {

  /**
   * This is method is used to search the term details depending on provided search criteria in input
   *
   * @param glossarySearchCriteriaView is the search criteria input
   * @return termViewList is a List of terms
   */
  public List<TermView> searchGlossary(
      @Param("glossarySearchCriteriaView") final GlossarySearchCriteriaView glossarySearchCriteriaView);

  /**
   * This is method is used to create the term
   *
   * @param termView Term Details
   */
  public void insertTerm(@Param("termView") final TermView termView);

  /**
   * This is method is used to get max term Id
   *
   * @return maximum id of term from database
   */
  public int getMaxTermId();

  /**
   * This is method is used to get all details of term
   *
   * @param termId unique id for term identification
   * @return term view containing term details
   */
  public TermView readTerm(@Param("termId") final int termId);

  /**
   * This method is used to delete the term from glossary
   *
   * @param termId is integer
   * @return number of rows affected
   */
  public int deleteTerm(@Param("termId") int termId);

  /**
   * This method is used to update the term
   *
   * @param termView term details
   * @return result of update operation
   */
  public int updateTerm(@Param("termView") final TermView termView);

  /**
   * This method is used to retrieve all terms details.
   *
   * @return termViewList List of Terms
   */
  public List<TermView> retrieveAllTerms();
}
