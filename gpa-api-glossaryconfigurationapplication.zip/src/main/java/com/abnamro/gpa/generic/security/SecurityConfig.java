package com.abnamro.gpa.generic.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.firewall.HttpFirewall;
import org.springframework.security.web.firewall.StrictHttpFirewall;

/**
 * The type Security config.
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

  private final PreAuthenticationFilter preAuthenticationFilter;

  private final PingFederateAuthenticationProvider pingFederateAuthenticationProvider;

  private final RequestSecurityPropertyConfig requestSecurityPropertyConfig;

  /**
   * Instantiates a new Security config.
   *
   * @param preAuthenticationFilter            the pre authentication filter
   * @param pingFederateAuthenticationProvider the ping federate authentication provider
   * @param requestSecurityPropertyConfig      the request security property config
   */
  @Autowired
  public SecurityConfig(PreAuthenticationFilter preAuthenticationFilter,
      PingFederateAuthenticationProvider pingFederateAuthenticationProvider,
      RequestSecurityPropertyConfig requestSecurityPropertyConfig) {
    this.preAuthenticationFilter = preAuthenticationFilter;
    this.pingFederateAuthenticationProvider = pingFederateAuthenticationProvider;
    this.requestSecurityPropertyConfig = requestSecurityPropertyConfig;
  }

  /**
   * configuration specific for the security static routes.
   *
   * @return the web security customizer
   */
  @Bean
  public WebSecurityCustomizer webSecurityCustomizer() {
    return (web) -> web.ignoring().requestMatchers(
            HttpMethod.GET,
            "/healthcheck",
            "/error")
        .requestMatchers(HttpMethod.POST, "/v1/authencationcheck/checkAccess")
        .requestMatchers(HttpMethod.POST, "/v1/authencationcheck/validateToken");
  }

  /**
   * Filter chain security filter chain.
   *
   * @param httpSecurity the http security
   * @return the security filter chain
   * @throws Exception the exception
   */
  @Bean
  public SecurityFilterChain filterChain(HttpSecurity httpSecurity) throws Exception {
    httpSecurity
        .httpBasic()
        .disable()
        .formLogin()
        .disable()
        .csrf()
        .disable()

        .authorizeRequests()
        .requestMatchers(HttpMethod.GET, "/healthcheck").permitAll()
        .requestMatchers(HttpMethod.POST, "/v1/authencationcheck/checkAccess").permitAll()
        .requestMatchers(HttpMethod.POST, "/v1/authencationcheck/validateToken").permitAll()
        .and()
        .authorizeRequests()
        .requestMatchers(HttpMethod.GET, requestSecurityPropertyConfig.getGetrequests()
        ).hasAnyAuthority(requestSecurityPropertyConfig.getReadRoles())

        .requestMatchers(HttpMethod.POST, requestSecurityPropertyConfig.getPostrequests()
        )
        .hasAnyAuthority(requestSecurityPropertyConfig.getManageRoles())
        .requestMatchers(HttpMethod.PUT, requestSecurityPropertyConfig.getPutrequests()
        )
        .hasAnyAuthority(requestSecurityPropertyConfig.getManageRoles())
        .requestMatchers(HttpMethod.DELETE, requestSecurityPropertyConfig.getDeleterequests()
        )
        .hasAnyAuthority(requestSecurityPropertyConfig.getManageRoles())
        .and()
        .sessionManagement()
        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and()
        .addFilterBefore(preAuthenticationFilter, BasicAuthenticationFilter.class)
        .exceptionHandling()
        .authenticationEntryPoint(pingAuthenticationEntryPoint());
    return httpSecurity.build();
  }

	/*@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
	httpSecurity
			.httpBasic()
			.disable()
			.formLogin()
			.disable()
			.csrf()
			.disable()

			.authorizeRequests()
			.antMatchers(HttpMethod.GET,"/healthcheck").permitAll()
			.antMatchers(HttpMethod.POST,"/v1/authencationcheck/checkAccess").permitAll()
			.antMatchers(HttpMethod.POST,"/v1/authencationcheck/validateToken").permitAll()
			.and()
			.authorizeRequests()
			.antMatchers(HttpMethod.GET,requestSecurityPropertyConfig.getGetrequests()
					).hasAnyAuthority(requestSecurityPropertyConfig.getReadRoles())

			.antMatchers(HttpMethod.POST,requestSecurityPropertyConfig.getPostrequests()
					)
			.hasAnyAuthority(requestSecurityPropertyConfig.getManageRoles() )
			.antMatchers(HttpMethod.PUT,requestSecurityPropertyConfig.getPutrequests()
			)
			.hasAnyAuthority(requestSecurityPropertyConfig.getManageRoles() )
			.antMatchers(HttpMethod.DELETE,requestSecurityPropertyConfig.getDeleterequests()
			)
			.hasAnyAuthority(requestSecurityPropertyConfig.getManageRoles() )
			.and()
			.sessionManagement()
			.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
			.and()
			.addFilterBefore(preAuthenticationFilter, BasicAuthenticationFilter.class)
			.exceptionHandling()
			.authenticationEntryPoint(pingAuthenticationEntryPoint());
	}*/

  /**
   * Configure.
   *
   * @param auth the auth
   */
  protected void configure(AuthenticationManagerBuilder auth) {
    auth.authenticationProvider(pingFederateAuthenticationProvider);
  }

  /**
   * Ping authentication entry point authentication entry point.
   *
   * @return the authentication entry point
   */
  @Bean
  public AuthenticationEntryPoint pingAuthenticationEntryPoint() {
    return new PingAuthenticationEntryPoint();
  }

  /**
   * Gets http firewall.
   *
   * @return the http firewall
   */
  @Bean
  public HttpFirewall getHttpFirewall() {
    StrictHttpFirewall strictHttpFirewall = new StrictHttpFirewall();
    strictHttpFirewall.setAllowSemicolon(true);
    return strictHttpFirewall;
  }

	/*public static CloseableHttpClient getHttpClient() throws GeneralSecurityException, IOException {

		TrustStrategy acceptTrustStrategy = (X509Certificate[] chain, String authenticationType) -> true;
		SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptTrustStrategy)
				.build();
		SSLContext.setDefault(sslContext);

		SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(
				sslContext, new String[]{"TLSv1.2"}, null, new NoopHostnameVerifier());

		Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
				.register("http", new PlainConnectionSocketFactory())
				.register("https", sslConnectionSocketFactory)
				.build();

		PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
		cm.setDefaultMaxPerRoute(100);
		cm.setMaxTotal(100);
		return HttpClients.custom()
				.setConnectionReuseStrategy(new DefaultConnectionReuseStrategy())
				.setSSLSocketFactory(sslConnectionSocketFactory)
				.setConnectionManager(cm)
				.setConnectionTimeToLive(5000, TimeUnit.MILLISECONDS)
				.build();


	}

	public static CloseableHttpClient getHttpClientLocal()
			throws GeneralSecurityException, IOException {
		TrustStrategy acceptTrustStrategy = (X509Certificate[] chain, String authenticationType) -> true;
		SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptTrustStrategy)
				.build();
		SSLContext.setDefault(sslContext);

		SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(
				sslContext, new String[]{"TLSv1.2"}, null, new NoopHostnameVerifier());

		Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
				.register("http", new PlainConnectionSocketFactory())
				.register("https", sslConnectionSocketFactory)
				.build();

		PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
		cm.setDefaultMaxPerRoute(100);
		cm.setMaxTotal(100);
		return HttpClients.custom()
				.setConnectionReuseStrategy(new DefaultConnectionReuseStrategy())
				.setSSLSocketFactory(sslConnectionSocketFactory)
				.setConnectionManager(cm)
				.setConnectionTimeToLive(5000, TimeUnit.MILLISECONDS)
				.build();
	}*/
}
