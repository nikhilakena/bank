/**
 *
 */
package com.abnamro.gpa.generic.glossarydao.dao;

/**
 * This is a DAO constant class
 */
public class GPAAGlossaryDAOLogConstants {

  /**
   * The constant LOG_ERROR_DATA_CREATE.
   */
  public static final String LOG_ERROR_DATA_CREATE = "LOG_GPGLDA_002";

  /**
   * The constant LOG_ERROR_SQL_ERROR.
   */
  public static final String LOG_ERROR_SQL_ERROR = "LOG_GPGLDA_004";

  /**
   * The constant LOG_ERROR_DATA_RETRIEVE_MAX_TERM_ID.
   */
  public static final String LOG_ERROR_DATA_RETRIEVE_MAX_TERM_ID = "LOG_GPGLDA_005";

  /**
   * The constant LOG_ERROR_DATA_DELETION.
   */
  public static final String LOG_ERROR_DATA_DELETION = "LOG_GPGLDA_006";

  /**
   * The constant LOG_PERSISTENCE_EXCEPTION_ERROR_SERVICE_DELETE.
   */
  public static final String LOG_PERSISTENCE_EXCEPTION_ERROR_SERVICE_DELETE = "LOG_GPGLDA_007";

  /**
   * The constant LOG_ERROR_THIS_TERM_IS_ALREADY_USED_BY_AN_ADMINISTRATION.
   */
  public static final String LOG_ERROR_THIS_TERM_IS_ALREADY_USED_BY_AN_ADMINISTRATION = "LOG_GPGLDA_008";

  /**
   * The constant LOG_ERROR_DATA_UPDATE.
   */
  public static final String LOG_ERROR_DATA_UPDATE = "LOG_GPGLDA_009";

}
