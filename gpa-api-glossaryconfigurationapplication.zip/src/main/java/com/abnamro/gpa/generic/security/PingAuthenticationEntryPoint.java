package com.abnamro.gpa.generic.security;


import com.abnamro.gpa.restresource.exception.Error;
import com.abnamro.gpa.restresource.exception.Errors;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;


/**
 * The type Ping authentication entry point.
 */
@Slf4j
public class PingAuthenticationEntryPoint implements AuthenticationEntryPoint {

  @Autowired
  private ObjectMapper mapper;

  @Autowired
  private Environment env;

  @Override
  public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException)
      throws IOException, ServletException {
    log.info("AuthenticationException: {}", authException.getMessage());

    if (authException instanceof BadCredentialsException) {
      response.setStatus(HttpStatus.UNAUTHORIZED.value());
      response.setContentType(MediaType.APPLICATION_JSON_VALUE);
      Errors errorDetails = new Errors();
      List<Error> errors = new ArrayList<>();
      errors.add(populateErrorDetails(authException.getMessage(), HttpStatus.UNAUTHORIZED, null));
      errorDetails.setErrors(errors);

      mapper.writeValue(
          response.getWriter(),
          errorDetails);
      return;
    } else {
      response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
      response.setContentType(MediaType.APPLICATION_JSON_VALUE);
      Errors errorDetails = new Errors();
      List<Error> errors = new ArrayList<>();
      errors.add(populateErrorDetails(authException.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, null));
      errorDetails.setErrors(errors);
      mapper.writeValue(
          response.getWriter(), errorDetails);
    }
  }

  private Error populateErrorDetails(String messageId, HttpStatus httpStatus, List<String> params) {
    Error error = new Error();
    String str = "_code";
    if (messageId == null || env.getProperty(messageId + str) == null) {
      messageId = String.valueOf(httpStatus.value());
    }

    error.setCode(env.getProperty(messageId + str));
    error.setMessage(env.getProperty(messageId + "_message"));
    if (params != null) {
      error.setParams(params.stream().map(Encode::forHtmlContent).collect(Collectors.toList()));
    }
    error.setStatus(String.valueOf(httpStatus.value()));
    return error;
  }
}
