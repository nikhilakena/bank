/**
 *
 */
package com.abnamro.gpa.generic.glossarydao.exception;

import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.DAOException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Messages;

/**
 * This is Exception class for GPA Glossary.
 */
public class GPAAGlossaryDAOException extends DAOException {//extends DAOException

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * This is a default constructor
   */
  public GPAAGlossaryDAOException() {
    super();

  }

  /**
   * Instantiates a new Gpaa glossary dao exception.
   *
   * @param messages the messages
   */
  public GPAAGlossaryDAOException(Messages messages) {
    super(messages);
  }

}
