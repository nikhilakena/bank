package com.abnamro.gpa.generic.security;

import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Service;


/**
 * The type Ping federate authentication service.
 */
@Service
@Slf4j
public class PingFederateAuthenticationService {

  @Autowired
  private JwtAuthHelper jwtAuthHelper;

  /**
   * Validate ping access token ping federate validate user info.
   *
   * @param accessToken the access token
   * @return the ping federate validate user info
   * @throws AuthenticationException the authentication exception
   * @throws IOException             the io exception
   */
  public PingFederateValidateUserInfo validatePingAccessToken(String accessToken)
      throws AuthenticationException, IOException {

    PingFederateValidateUserInfo userInfo;
    userInfo = jwtAuthHelper.verifyUserJwtSession(accessToken);
    log.debug("Verified UserInfo");
    return userInfo;
  }

}
