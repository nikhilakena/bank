/**
 *
 */
package com.abnamro.gpa.generic.glossarydao.dao;

import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryConfigurationMessageKeys;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryDAOException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Message;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.MessageType;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Messages;

/**
 * This is helper class for DAO layer validations
 */
public class GPAAGlossaryDAOHelper {

  /**
   * This is method validates the if term id greater than 6 digits or not
   *
   * @param termId is integer
   * @throws GPAAGlossaryDAOException is an exception for validation failure
   */
  public void validateTermID(int termId) throws GPAAGlossaryDAOException {
    if (termId > 0) {
      int length = (int) (Math.log10(termId) + 1);
      if (length > 6) {
        Messages messages = new Messages();
        messages.addMessage(new Message(GPAAGlossaryConfigurationMessageKeys.VALIDATION_EXCEPTION_IN_DELETE_GLOSSARY),
            MessageType.getError());
        throw new GPAAGlossaryDAOException(messages);
      }
    }
  }

}
