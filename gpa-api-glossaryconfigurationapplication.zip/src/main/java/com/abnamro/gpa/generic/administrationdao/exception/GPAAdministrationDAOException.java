/**
 *
 */
package com.abnamro.gpa.generic.administrationdao.exception;


import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.DAOException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Messages;

/**
 * This is DAO layer exception class for the GPAAdministrationDAO.
 */
public class GPAAdministrationDAOException extends DAOException {//extends DAOException

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * This is a default constructor
   */
  public GPAAdministrationDAOException() {
    super();

  }

  /**
   * Instantiates a new Gpa administration dao exception.
   *
   * @param messages the messages
   */
  public GPAAdministrationDAOException(Messages messages) {
    super(messages);
  }

}
