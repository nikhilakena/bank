/**
 *
 */
package com.abnamro.gpa.generic.glossarydao.dtos;

import java.sql.Timestamp;
import lombok.Data;


/**
 * This is a view class which holds the details of term
 */
@Data
public class TermView {

  /**
   * This is default serialVersionID
   */
  private static final long serialVersionUID = 1L;

  private int id;
  private String name;
  private String dataType;
  private String description;
  private String createdBy;
  private Timestamp createdTimeStamp;
  private String modifiedBy;
  private Timestamp modifiedTimeStamp;
}
