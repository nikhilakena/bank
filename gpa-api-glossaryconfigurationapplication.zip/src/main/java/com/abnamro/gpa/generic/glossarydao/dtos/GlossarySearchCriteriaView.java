/**
 *
 */
package com.abnamro.gpa.generic.glossarydao.dtos;

import java.sql.Timestamp;
import lombok.Data;

/**
 * This is a view class which contains the attributes of a term, an output of search glossary
 */
@Data
public class GlossarySearchCriteriaView {

  private int termId;

  private String termName;

  private String createdBy;

  private Timestamp createdTimestampFrom;

  private Timestamp createdTimestampTo;

}
