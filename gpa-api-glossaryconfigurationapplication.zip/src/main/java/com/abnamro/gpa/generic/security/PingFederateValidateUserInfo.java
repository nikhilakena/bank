package com.abnamro.gpa.generic.security;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.AuthenticatedPrincipal;

/**
 * The type Ping federate validate user info.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class PingFederateValidateUserInfo implements AuthenticatedPrincipal {

  @JsonProperty("userid")
  private String userId;

  @JsonProperty("department_number")
  private Object departmentNumber;

  @JsonProperty("roles")
  private Object roles;

  private boolean active;

  @Override
  public String getName() {
    return userId;
  }
}
