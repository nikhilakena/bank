package com.abnamro.gpa.generic.administrationdao.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * This is the mybatis query mapper interface class for GPAAdministrationDAO
 */
@Mapper
public interface GPAAdministrationDAOMybatisMapper {

  /**
   * Administration count for terms int.
   *
   * @param termId the term id
   * @return the int
   */
  public int administrationCountForTerms(@Param("termId") final int termId);
}
