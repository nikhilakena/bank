package com.abnamro.gpa.generic.administrationdao.dao;

import com.abnamro.gpa.generic.administrationdao.constants.GPAAdministrationDAOLogConstants;
import com.abnamro.gpa.generic.administrationdao.constants.GPAAdministrationDAOMessageKeys;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryDAOException;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Message;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.MessageType;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.Messages;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This is dao layer class for GPA Administration and has operation related to maintains of Administration.
 */
@Component
@Slf4j
public class GPAAdministrationDAO {

  @Autowired
  private SqlSessionFactory sessionFactory;

  /**
   * This operation is used to check if Administrations are present for term
   *
   * @param termId unique identifier of the term
   * @return true if administration is present else false
   * @throws GPAAGlossaryDAOException      the gpaa glossary dao exception
   * @throws GPAAdministrationDAOException Exception thrown at DAO layer
   */
  public boolean isAdministrationPresentForTerm(int termId)
      throws GPAAGlossaryDAOException, GPAAdministrationDAOException {
    final String logMethod = "isAdministrationPresentForTerm()";
    boolean flag = false;

    try (SqlSession sqlSession = sessionFactory.openSession()) {
      int count = sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)
          .administrationCountForTerms(termId);

      log.info("{} - {} administrations are present for the termId {}", logMethod, count, termId);

      if (count > 0) {
        flag = true;
      }

    } catch (PersistenceException exception) {
      Messages messages = new Messages();
      messages.addMessage(new Message(
              GPAAdministrationDAOMessageKeys.MYBATIS_EXCEPTION_WHILE_SEARCHING_ADMINISTRATION_DETAILS),
          MessageType.getError());
      log.error(logMethod + GPAAdministrationDAOLogConstants.LOG_ERROR_SEARCH_ADMINISTRATION, exception);
      throw new GPAAdministrationDAOException(messages);
    }
    return flag;
  }
}
