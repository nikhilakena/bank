/**
 *
 */
package com.abnamro.gpa.generic.glossarydao.exception;


import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.MessageKey;

/**
 * This class contains Glossary Configuration the message keys
 */
public class GPAAGlossaryConfigurationMessageKeys {

  /**
   * The constant MYBATIS_EXCEPTION_WHILE_READING_GLOSSARY_DETAILS.
   */
  public static final MessageKey MYBATIS_EXCEPTION_WHILE_READING_GLOSSARY_DETAILS = new MessageKey("MESSAGE_GLSC_001");

  /**
   * The constant DATABASE_EXCEPTION_WHILE_READING_GLOSSARY_DETAILS.
   */
  public static final MessageKey DATABASE_EXCEPTION_WHILE_READING_GLOSSARY_DETAILS = new MessageKey("MESSAGE_GLSC_002");

  /**
   * The constant PARSING_EXCEPTION.
   */
  public static final MessageKey PARSING_EXCEPTION = new MessageKey("MESSAGE_GLSC_003");

  /**
   * The constant ATLEAST_ONE_REQUIRED_IN_GLOSSARY_SEARCH.
   */
  public static final MessageKey ATLEAST_ONE_REQUIRED_IN_GLOSSARY_SEARCH = new MessageKey("MESSAGE_GLSC_004");

  /**
   * The constant VALIDATION_EXCEPTION_IN_GLOSSARY_SEARCH.
   */
  public static final MessageKey VALIDATION_EXCEPTION_IN_GLOSSARY_SEARCH = new MessageKey("MESSAGE_GLSC_005");

  /**
   * The constant VALIDATION_EXCEPTION_IN_GLOSSARY_SEARCH_FROM_DATE_CAN_NOT_BE_GREATER_THAN_TO_DATE.
   */
  public static final MessageKey VALIDATION_EXCEPTION_IN_GLOSSARY_SEARCH_FROM_DATE_CAN_NOT_BE_GREATER_THAN_TO_DATE = new MessageKey(
      "MESSAGE_GLSC_006");

  /**
   * The constant VALIDATION_EXCEPTION_IN_GLOSSARY_CREATE.
   */
  public static final MessageKey VALIDATION_EXCEPTION_IN_GLOSSARY_CREATE = new MessageKey("MESSAGE_GLSC_007");

  /**
   * The constant MYBATIS_EXCEPTION_WHILE_CREATING_TERM.
   */
  public static final MessageKey MYBATIS_EXCEPTION_WHILE_CREATING_TERM = new MessageKey("MESSAGE_GLSC_008");

  /**
   * The constant DATABASE_EXCEPTION_WHILE_CREATING_TERM.
   */
  public static final MessageKey DATABASE_EXCEPTION_WHILE_CREATING_TERM = new MessageKey("MESSAGE_GLSC_009");

  /**
   * The constant MYBATIS_EXCEPTION_WHILE_RETRIEVE_MAX_TERM_ID.
   */
  public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVE_MAX_TERM_ID = new MessageKey("MESSAGE_GLSC_010");

  /**
   * The constant DATABASE_EXCEPTION_WHILE_RETRIEVE_MAX_TERM_ID.
   */
  public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVE_MAX_TERM_ID = new MessageKey("MESSAGE_GLSC_011");

  /**
   * The constant MYBATIS_EXCEPTION_WHILE_READING_TERM.
   */
  public static final MessageKey MYBATIS_EXCEPTION_WHILE_READING_TERM = new MessageKey("MESSAGE_GLSC_012");

  /**
   * The constant DATABASE_EXCEPTION_WHILE_READING_TERM.
   */
  public static final MessageKey DATABASE_EXCEPTION_WHILE_READING_TERM = new MessageKey("MESSAGE_GLSC_013");

  /**
   * The constant ERROR_THIS_TERM_IS_ALREADY_USED_BY_AN_ADMINISTRATION.
   */
  public static final MessageKey ERROR_THIS_TERM_IS_ALREADY_USED_BY_AN_ADMINISTRATION = new MessageKey(
      "MESSAGE_GLSC_014");

  /**
   * The constant VALIDATION_EXCEPTION_IN_DELETE_GLOSSARY.
   */
  public static final MessageKey VALIDATION_EXCEPTION_IN_DELETE_GLOSSARY = new MessageKey("MESSAGE_GLSC_015");

  /**
   * The constant VALIDATION_EXCEPTION_NO_DATA_FOUND_IN_DELETE_GLOSSARY.
   */
  public static final MessageKey VALIDATION_EXCEPTION_NO_DATA_FOUND_IN_DELETE_GLOSSARY = new MessageKey(
      "MESSAGE_GLSC_016");

  /**
   * The constant MYBATIS_EXCEPTION_WHILE_UPDATING_TERM.
   */
  public static final MessageKey MYBATIS_EXCEPTION_WHILE_UPDATING_TERM = new MessageKey("MESSAGE_GLSC_017");

  /**
   * The constant DATABASE_EXCEPTION_WHILE_UPDATING_TERM.
   */
  public static final MessageKey DATABASE_EXCEPTION_WHILE_UPDATING_TERM = new MessageKey("MESSAGE_GLSC_018");

  /**
   * The constant MYBATIS_EXCEPTION_WHILE_RETRIEVING_ALL_TERMS.
   */
  public static final MessageKey MYBATIS_EXCEPTION_WHILE_RETRIEVING_ALL_TERMS = new MessageKey("MESSAGE_GLSC_019");

  /**
   * The constant DATABASE_EXCEPTION_WHILE_RETRIEVING_ALL_TERMS.
   */
  public static final MessageKey DATABASE_EXCEPTION_WHILE_RETRIEVING_ALL_TERMS = new MessageKey("MESSAGE_GLSC_020");


}
