/**
 *
 */
package com.abnamro.gpa.restresource.enumeration;

/**
 * The enum Agreement life cycle status type.
 */
public enum AgreementLifeCycleStatusType {
  /**
   * Active agreement life cycle status type.
   */
  ACTIVE,
  /**
   * Inactive agreement life cycle status type.
   */
  INACTIVE,
  /**
   * Draft agreement life cycle status type.
   */
  DRAFT

}
