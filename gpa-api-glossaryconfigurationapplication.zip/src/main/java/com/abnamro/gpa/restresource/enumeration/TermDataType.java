/**
 *
 */
package com.abnamro.gpa.restresource.enumeration;

/**
 * The enum Term data type.
 *
 * @author C45410
 */
public enum TermDataType {
  /**
   * String term data type.
   */
  STRING,
  /**
   * Numeric term data type.
   */
  NUMERIC,
  /**
   * Boolean term data type.
   */
  BOOLEAN,
  /**
   * Date term data type.
   */
  DATE,
  /**
   * Time term data type.
   */
  TIME,
  /**
   * Datetime term data type.
   */
  DATETIME
}
