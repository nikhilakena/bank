/**
 *
 */
package com.abnamro.gpa.restresource.glossary;

import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import lombok.Data;

/**
 * The type Term facet rest resource.
 */
@Data
public class TermFacetRestResource {

  private FacetTypes facetType;

  private String facetValue;

  private AuditDetails auditDetails;

}
