/**
 *
 */
package com.abnamro.gpa.restresource.glossary;

import com.abnamro.gpa.restresource.enumeration.FacetTypes;
import com.abnamro.gpa.restresource.helper.AuditDetails;

/**
 * The type Term facet rest resource.
 */
public class TermFacetRestResource {

  private FacetTypes facetType;

  private String facetValue;

  private AuditDetails auditDetails;

  /**
   * Gets facet type.
   *
   * @return the facetType
   */
  public FacetTypes getFacetType() {
    return facetType;
  }

  /**
   * Sets facet type.
   *
   * @param facetType the facetType to set
   */
  public void setFacetType(FacetTypes facetType) {
    this.facetType = facetType;
  }

  /**
   * Gets facet value.
   *
   * @return the facetValue
   */
  public String getFacetValue() {
    return facetValue;
  }

  /**
   * Sets facet value.
   *
   * @param facetValue the facetValue to set
   */
  public void setFacetValue(String facetValue) {
    this.facetValue = facetValue;
  }

  /**
   * Gets audit details.
   *
   * @return the auditDetails
   */
  public AuditDetails getAuditDetails() {
    return auditDetails;
  }

  /**
   * Sets audit details.
   *
   * @param auditDetails the auditDetails to set
   */
  public void setAuditDetails(AuditDetails auditDetails) {
    this.auditDetails = auditDetails;
  }


}
