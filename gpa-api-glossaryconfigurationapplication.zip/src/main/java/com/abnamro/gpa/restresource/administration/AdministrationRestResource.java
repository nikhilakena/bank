/**
 *
 */
package com.abnamro.gpa.restresource.administration;

import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import java.util.List;

/**
 * Rest resource
 */
public class AdministrationRestResource {

  private int id;

  private String name;

  private String description;

  private String oarId;

  private List<TermRestResource> terms;

  private AuditDetails auditDetails;

  private List<Integer> products;

  /**
   * Gets id.
   *
   * @return the id
   */
  public int getId() {
    return id;
  }

  /**
   * Sets id.
   *
   * @param id the id to set
   */
  public void setId(int id) {
    this.id = id;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Sets name.
   *
   * @param name the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Sets description.
   *
   * @param description the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * Gets oar id.
   *
   * @return the oarId
   */
  public String getOarId() {
    return oarId;
  }

  /**
   * Sets oar id.
   *
   * @param oarId the oarId to set
   */
  public void setOarId(String oarId) {
    this.oarId = oarId;
  }

  /**
   * Gets terms.
   *
   * @return the terms
   */
  public List<TermRestResource> getTerms() {
    return terms;
  }

  /**
   * Sets terms.
   *
   * @param terms the terms to set
   */
  public void setTerms(List<TermRestResource> terms) {
    this.terms = terms;
  }

  /**
   * Gets audit details.
   *
   * @return the auditDetails
   */
  public AuditDetails getAuditDetails() {
    return auditDetails;
  }

  /**
   * Sets audit details.
   *
   * @param auditDetails the auditDetails to set
   */
  public void setAuditDetails(AuditDetails auditDetails) {
    this.auditDetails = auditDetails;
  }

  /**
   * Gets products.
   *
   * @return the products
   */
  public List<Integer> getProducts() {
    return products;
  }

  /**
   * Sets products.
   *
   * @param products the products to set
   */
  public void setProducts(List<Integer> products) {
    this.products = products;
  }


}
