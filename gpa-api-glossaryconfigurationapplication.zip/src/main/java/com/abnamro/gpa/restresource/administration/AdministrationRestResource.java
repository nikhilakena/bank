/**
 *
 */
package com.abnamro.gpa.restresource.administration;

import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import java.util.List;
import lombok.Data;

/**
 * Rest resource
 */
@Data
public class AdministrationRestResource {

  private int id;

  private String name;

  private String description;

  private String oarId;

  private List<TermRestResource> terms;

  private AuditDetails auditDetails;

  private List<Integer> products;

}
