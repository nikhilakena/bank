/**
 *
 */
package com.abnamro.gpa.restresource.enumeration;

/**
 * The enum Facet types.
 */
public enum FacetTypes {
  /**
   * Enumeration facet types.
   */
  ENUMERATION,
  /**
   * Length facet types.
   */
  LENGTH,
  /**
   * Pattern facet types.
   */
  PATTERN,
  /**
   * Maxlength facet types.
   */
  MAXLENGTH,
  /**
   * Minlength facet types.
   */
  MINLENGTH,
  /**
   * Mininclusive facet types.
   */
  MININCLUSIVE,
  /**
   * Maxinclusive facet types.
   */
  MAXINCLUSIVE,
  /**
   * Minexclusive facet types.
   */
  MINEXCLUSIVE,
  /**
   * Maxexclusive facet types.
   */
  MAXEXCLUSIVE,
  /**
   * Totaldigits facet types.
   */
  TOTALDIGITS,
  /**
   * Fractions facet types.
   */
  FRACTIONS
}
