/**
 *
 */
package com.abnamro.gpa.restresource.agreement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The type Term.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Term {

  private String termId;

  private String attributeValue;

  private String attributeName;

  /**
   * Gets attribute value.
   *
   * @return the attributeValue
   */
  public String getAttributeValue() {
    return attributeValue;
  }

  /**
   * Sets attribute value.
   *
   * @param attributeValue the attributeValue to set
   */
  public void setAttributeValue(String attributeValue) {
    this.attributeValue = attributeValue;
  }

  /**
   * Gets attribute name.
   *
   * @return the attributeName
   */
  public String getAttributeName() {
    return attributeName;
  }

  /**
   * Sets attribute name.
   *
   * @param attributeName the attributeName to set
   */
  public void setAttributeName(String attributeName) {
    this.attributeName = attributeName;
  }

  /**
   * Gets term id.
   *
   * @return the termId
   */
  public String getTermId() {
    return termId;
  }

  /**
   * Sets term id.
   *
   * @param termId the termId to set
   */
  public void setTermId(String termId) {
    this.termId = termId;
  }


}
