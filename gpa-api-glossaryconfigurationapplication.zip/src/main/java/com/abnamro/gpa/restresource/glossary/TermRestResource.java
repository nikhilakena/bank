/**
 *
 */
package com.abnamro.gpa.restresource.glossary;

import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import java.util.List;

/**
 * The type Term rest resource.
 */
public class TermRestResource {

  private int id;

  private String name;

  private TermDataType dataType;

  private String description;

  private boolean isMandatory;

  private List<TermFacetRestResource> facets;

  private AuditDetails auditDetails;

  /**
   * Gets id.
   *
   * @return the id
   */
  public int getId() {
    return id;
  }

  /**
   * Sets id.
   *
   * @param id the id to set
   */
  public void setId(int id) {
    this.id = id;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Sets name.
   *
   * @param name the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets data type.
   *
   * @return the dataType
   */
  public TermDataType getDataType() {
    return dataType;
  }

  /**
   * Sets data type.
   *
   * @param dataType the dataType to set
   */
  public void setDataType(TermDataType dataType) {
    this.dataType = dataType;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Sets description.
   *
   * @param description the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * Is mandatory boolean.
   *
   * @return the isMandatory
   */
  public boolean isMandatory() {
    return isMandatory;
  }

  /**
   * Sets mandatory.
   *
   * @param isMandatory the isMandatory to set
   */
  public void setMandatory(boolean isMandatory) {
    this.isMandatory = isMandatory;
  }

  /**
   * Gets facets.
   *
   * @return the facets
   */
  public List<TermFacetRestResource> getFacets() {
    return facets;
  }

  /**
   * Sets facets.
   *
   * @param facets the facets to set
   */
  public void setFacets(List<TermFacetRestResource> facets) {
    this.facets = facets;
  }

  /**
   * Gets audit details.
   *
   * @return the auditDetails
   */
  public AuditDetails getAuditDetails() {
    return auditDetails;
  }

  /**
   * Sets audit details.
   *
   * @param auditDetails the auditDetails to set
   */
  public void setAuditDetails(AuditDetails auditDetails) {
    this.auditDetails = auditDetails;
  }


}
