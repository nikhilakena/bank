/**
 *
 */
package com.abnamro.gpa.restresource.glossary;

import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import java.util.List;
import lombok.Data;

/**
 * The type Term rest resource.
 */
@Data
public class TermRestResource {

  private int id;

  private String name;

  private TermDataType dataType;

  private String description;

  private boolean isMandatory;

  private List<TermFacetRestResource> facets;

  private AuditDetails auditDetails;

}
