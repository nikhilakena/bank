/**
 *
 */
package com.abnamro.gpa.restresource.helper;

import java.util.Date;
import lombok.Data;

/**
 * The type Audit details.
 */
@Data
public class AuditDetails {

  private String createdBy;

  private Date createdTimeStamp;

  private String modifiedBy;

  private Date modifiedTimeStamp;

}
