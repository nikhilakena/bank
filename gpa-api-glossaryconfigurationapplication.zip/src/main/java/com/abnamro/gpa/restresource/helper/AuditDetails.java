/**
 *
 */
package com.abnamro.gpa.restresource.helper;

import java.util.Date;

/**
 * The type Audit details.
 */
public class AuditDetails {

  private String createdBy;

  private Date createdTimeStamp;

  private String modifiedBy;

  private Date modifiedTimeStamp;

  /**
   * Gets created by.
   *
   * @return the createdBy
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * Sets created by.
   *
   * @param createdBy the createdBy to set
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  /**
   * Gets created time stamp.
   *
   * @return the createdTimeStamp
   */
  public Date getCreatedTimeStamp() {
    return createdTimeStamp;
  }

  /**
   * Sets created time stamp.
   *
   * @param createdTimeStamp the createdTimeStamp to set
   */
  public void setCreatedTimeStamp(Date createdTimeStamp) {
    this.createdTimeStamp = createdTimeStamp;
  }

  /**
   * Gets modified by.
   *
   * @return the modifiedBy
   */
  public String getModifiedBy() {
    return modifiedBy;
  }

  /**
   * Sets modified by.
   *
   * @param modifiedBy the modifiedBy to set
   */
  public void setModifiedBy(String modifiedBy) {
    this.modifiedBy = modifiedBy;
  }

  /**
   * Gets modified time stamp.
   *
   * @return the modifiedTimeStamp
   */
  public Date getModifiedTimeStamp() {
    return modifiedTimeStamp;
  }

  /**
   * Sets modified time stamp.
   *
   * @param modifiedTimeStamp the modifiedTimeStamp to set
   */
  public void setModifiedTimeStamp(Date modifiedTimeStamp) {
    this.modifiedTimeStamp = modifiedTimeStamp;
  }


}
