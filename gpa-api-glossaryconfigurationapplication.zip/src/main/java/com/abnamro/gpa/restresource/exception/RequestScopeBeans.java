package com.abnamro.gpa.restresource.exception;


import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

/**
 * This is a bean to store request scope objects
 */
@Component
@RequestScope
@Getter
@Setter
public class RequestScopeBeans {

  private String traceId;

  private String consumerId;

  private String tokenType;

  private String token;
}
