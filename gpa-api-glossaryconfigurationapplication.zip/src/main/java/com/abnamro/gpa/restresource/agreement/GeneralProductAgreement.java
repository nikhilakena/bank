/**
 *
 */
package com.abnamro.gpa.restresource.agreement;

import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import java.util.List;
import lombok.Data;

/**
 * The type General product agreement.
 */
@Data
public class GeneralProductAgreement {

  private String productId;
  private String customerId;
  private String agreementStartDate;
  private String agreementEndDate;
  private String createdBy;
  private String dateCreated;
  private String modifiedBy;
  private String dateModified;
  private AgreementLifeCycleStatusType agreementLifeCycleStatusType;
  private String agreementId;
  private List<Term> terms;
}
