/**
 *
 */
package com.abnamro.gpa.restresource.agreement;

import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
import java.util.List;

/**
 * The type General product agreement.
 */
public class GeneralProductAgreement {

  private String productId;
  private String customerId;
  private String agreementStartDate;
  private String agreementEndDate;
  private String createdBy;
  private String dateCreated;
  private String modifiedBy;
  private String dateModified;
  private AgreementLifeCycleStatusType agreementLifeCycleStatusType;
  private String agreementId;
  private List<Term> terms;

  /**
   * Gets product id.
   *
   * @return the product id
   */
  public String getProductId() {
    return productId;
  }

  /**
   * Sets product id.
   *
   * @param productId the productId to set
   */
  public void setProductId(String productId) {
    this.productId = productId;
  }

  /**
   * Gets terms.
   *
   * @return the terms
   */
  public List<Term> getTerms() {
    return terms;
  }

  /**
   * Sets terms.
   *
   * @param terms the terms to set
   */
  public void setTerms(List<Term> terms) {
    this.terms = terms;
  }

  /**
   * Gets customer id.
   *
   * @return the customerId
   */
  public String getCustomerId() {
    return customerId;
  }

  /**
   * Gets agreement id.
   *
   * @return the agreementId
   */
  public String getAgreementId() {
    return agreementId;
  }

  /**
   * Sets agreement id.
   *
   * @param agreementId the agreementId to set
   */
  public void setAgreementId(String agreementId) {
    this.agreementId = agreementId;
  }

  /**
   * Sets customer id.
   *
   * @param customerId the customerId to set
   */
  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  /**
   * Gets agreement start date.
   *
   * @return the agreementStartDate
   */
  public String getAgreementStartDate() {
    return agreementStartDate;
  }

  /**
   * Sets agreement start date.
   *
   * @param agreementStartDate the agreementStartDate to set
   */
  public void setAgreementStartDate(String agreementStartDate) {
    this.agreementStartDate = agreementStartDate;
  }

  /**
   * Gets agreement end date.
   *
   * @return the agreementEndDate
   */
  public String getAgreementEndDate() {
    return agreementEndDate;
  }

  /**
   * Sets agreement end date.
   *
   * @param agreementEndDate the agreementEndDate to set
   */
  public void setAgreementEndDate(String agreementEndDate) {
    this.agreementEndDate = agreementEndDate;
  }

  /**
   * Gets created by.
   *
   * @return the createdBy
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * Sets created by.
   *
   * @param createdBy the createdBy to set
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  /**
   * Gets date created.
   *
   * @return the dateCreated
   */
  public String getDateCreated() {
    return dateCreated;
  }

  /**
   * Sets date created.
   *
   * @param dateCreated the dateCreated to set
   */
  public void setDateCreated(String dateCreated) {
    this.dateCreated = dateCreated;
  }

  /**
   * Gets modified by.
   *
   * @return the modifiedBy
   */
  public String getModifiedBy() {
    return modifiedBy;
  }

  /**
   * Sets modified by.
   *
   * @param modifiedBy the modifiedBy to set
   */
  public void setModifiedBy(String modifiedBy) {
    this.modifiedBy = modifiedBy;
  }

  /**
   * Gets date modified.
   *
   * @return the dateModified
   */
  public String getDateModified() {
    return dateModified;
  }

  /**
   * Sets date modified.
   *
   * @param dateModified the dateModified to set
   */
  public void setDateModified(String dateModified) {
    this.dateModified = dateModified;
  }

  /**
   * Gets agreement life cycle status type.
   *
   * @return the agreementLifeCycleStatusType
   */
  public AgreementLifeCycleStatusType getAgreementLifeCycleStatusType() {
    return agreementLifeCycleStatusType;
  }

  /**
   * Sets agreement life cycle status type.
   *
   * @param agreementLifeCycleStatusType the agreementLifeCycleStatusType to set
   */
  public void setAgreementLifeCycleStatusType(AgreementLifeCycleStatusType agreementLifeCycleStatusType) {
    this.agreementLifeCycleStatusType = agreementLifeCycleStatusType;
  }
  /**
   * @return the productId
   */


}
