package com.abnamro.gpa.generic.glossarydao;


import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.util.AssertionErrors.assertEquals;

import com.abnamro.gpa.generic.glossarydao.dao.GPAAGlossaryDAO;
import com.abnamro.gpa.generic.glossarydao.dao.GPAAGlossaryDAOMybatisMapper;
import com.abnamro.gpa.generic.glossarydao.dtos.GlossarySearchCriteriaView;
import com.abnamro.gpa.generic.glossarydao.dtos.TermView;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryConfigurationMessageKeys;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryDAOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
public class GPAAGlossaryDAOTest {

  @InjectMocks
  private GPAAGlossaryDAO underTest;

  @Mock
  GPAAGlossaryDAOMybatisMapper myBatisMapper;

  @Mock
  private SqlSession sqlSession;

  @Mock
  private SqlSessionFactory sessionFactory;

  @Test
  public void testSearchGlossary() throws GPAAGlossaryDAOException {
    GlossarySearchCriteriaView glossarySearchCriteriaView = new GlossarySearchCriteriaView();
    glossarySearchCriteriaView.setCreatedBy("C36098");
    glossarySearchCriteriaView.setTermName("TermName");
    List<TermView> termViewList = new ArrayList<>();

    when(sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    when(myBatisMapper.searchGlossary(glossarySearchCriteriaView)).thenReturn(termViewList);
    when(sessionFactory.openSession()).thenReturn(sqlSession);
    try {
      assertEquals("This method searches for Glossary details", termViewList,
          underTest.searchGlossary(glossarySearchCriteriaView));
    } catch (GPAAGlossaryDAOException e) {
      fail("No Exception expected");
    }
  }

  @Test
  public void testViewGlossaryDetails() throws GPAAGlossaryDAOException {
    List<TermView> termViewList = new ArrayList<>();

    when(sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    when(myBatisMapper.retrieveAllTerms()).thenReturn(termViewList);
    when(sessionFactory.openSession()).thenReturn(sqlSession);
    try {
      assertEquals("This method view term details", termViewList, underTest.retrieveAllTerms());
    } catch (GPAAGlossaryDAOException e) {
      fail("No Exception expected");
    }
  }

  @Test
  public void testGetMaxTermId() throws GPAAGlossaryDAOException {
    when(sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    when(myBatisMapper.getMaxTermId()).thenReturn(56);
    when(sessionFactory.openSession()).thenReturn(sqlSession);
    try {
      assertEquals("This method retrieves the maximum Term Id", 56, underTest.getMaxTermId());
    } catch (GPAAGlossaryDAOException e) {
      fail("No Exception expected");
    }
  }

  @Test
  void testGetMaxTermIdExcception() throws GPAAGlossaryDAOException {
    when(sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class)).thenThrow(new PersistenceException());
    when(sessionFactory.openSession()).thenReturn(sqlSession);
    Assertions.assertThrows(GPAAGlossaryDAOException.class, () -> underTest.getMaxTermId());
  }

  @Test
  void testReadTerm() {
    TermView termView = new TermView();
    when(sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    when(myBatisMapper.readTerm(12)).thenReturn(termView);
    when(sessionFactory.openSession()).thenReturn(sqlSession);
    try {
      assertEquals("This method reads Term with provided Term Id", termView, underTest.readTerm(12));
    } catch (GPAAGlossaryDAOException e) {
      fail("No Exception expected");
    }
  }

  @Test
  void testDeleteTerm() {
    when(sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    when(myBatisMapper.deleteTerm(12)).thenReturn(0);
    when(sessionFactory.openSession()).thenReturn(sqlSession);
    try {
      underTest.deleteTerm(12);
    } catch (GPAAGlossaryDAOException e) {
      assertEquals("Exception in Delete Term ",
          GPAAGlossaryConfigurationMessageKeys.VALIDATION_EXCEPTION_NO_DATA_FOUND_IN_DELETE_GLOSSARY,
          e.getMessages().getMessages().get(0).getMessageKey());
    }
  }

  @Test
  void testUpdateTerm() {
    TermView termView = new TermView();
    when(sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    when(sessionFactory.openSession()).thenReturn(sqlSession);
    when(myBatisMapper.updateTerm(Mockito.any(TermView.class))).thenReturn(0);
    try {
      underTest.updateTerm(termView);
    } catch (GPAAGlossaryDAOException e) {
      assertEquals("Exception in updateTerm ",
          GPAAGlossaryConfigurationMessageKeys.VALIDATION_EXCEPTION_NO_DATA_FOUND_IN_DELETE_GLOSSARY,
          e.getMessages().getMessages().get(0).getMessageKey());
    }
  }

  @Test
  void testCreateTerm() {
    TermView termView = new TermView();
    when(sqlSession.getMapper(GPAAGlossaryDAOMybatisMapper.class)).thenReturn(myBatisMapper);
    doNothing().when(myBatisMapper).insertTerm(termView);
    when(sessionFactory.openSession()).thenReturn(sqlSession);

    try {
      assertEquals("This method create Term with provided Term Id", termView.getId(),
          underTest.createTerm(termView) - 1);
    } catch (GPAAGlossaryDAOException e) {
      fail("No Exception expected");
    }
  }
}
