package com.abnamro.gpa.generic.security;


import com.abnamro.gpa.generic.security.JwtAuthHelper;
import com.abnamro.gpa.generic.security.PingFederateValidateUserInfo;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class JwtAuthHelperTest {

  @BeforeAll
  static void initAll() {
  }

  @AfterAll
  static void tearDownAll() {
  }

  @BeforeEach
  void init() {
  }

  @Test
  public void createUserJwtSession() {
    try {
      String expectedValue = "";
      String pingIdToken = "";

      JwtAuthHelper jwtauthhelper = new JwtAuthHelper();
      String actualValue = jwtauthhelper.createUserJwtSession(pingIdToken);

      Assertions.assertEquals(expectedValue, actualValue);
    } catch (Exception exception) {
      Assertions.assertFalse(false);
    }
  }

  @Test

  public void verifyUserJwtSession() {
    try {
      PingFederateValidateUserInfo expectedValue = null;
      String token = "";

      JwtAuthHelper jwtauthhelper = new JwtAuthHelper();
      PingFederateValidateUserInfo actualValue = jwtauthhelper.verifyUserJwtSession(token);

      Assertions.assertEquals(expectedValue, actualValue);
    } catch (Exception exception) {
      Assertions.assertFalse(false);
    }
  }

  @Test

  public void decodeJWTWithoutVerifying() {
    try {
      DecodedJWT expectedValue = null;
      String token = "";

      JwtAuthHelper jwtauthhelper = new JwtAuthHelper();
      DecodedJWT actualValue = jwtauthhelper.decodeJWTWithoutVerifying(token);

      Assertions.assertEquals(expectedValue, actualValue);
    } catch (Exception exception) {
      Assertions.assertFalse(false);
    }
  }

  @AfterEach
  void tearDown() {
  }
}

