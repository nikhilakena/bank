package com.abnamro.gpa.generic.security;


import com.abnamro.gpa.generic.security.AuthenticationToken;
import com.abnamro.gpa.generic.security.PingFederateValidateUserInfo;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AuthenticationTokenTest {

  @BeforeAll
  static void initAll() {
  }

  @AfterAll
  static void tearDownAll() {
  }

  @BeforeEach
  void init() {
  }

  @Test
  @DisplayName("get Credentials")
  public void getCredentials() {
    try {

      Object expectedValue = null;

      String accessTokenc = "";
      PingFederateValidateUserInfo userInfoc = null;

      AuthenticationToken authenticationtoken = new AuthenticationToken(accessTokenc, userInfoc);
      Object actualValue = authenticationtoken.getCredentials();

      Assertions.assertEquals(expectedValue, actualValue);
    } catch (Exception exception) {
      Assertions.assertFalse(false);
    }
  }

  @Test
  @DisplayName("get Principal")
  public void getPrincipal() {
    try {

      Object expectedValue = null;

      String accessTokenc = "";
      PingFederateValidateUserInfo userInfoc = null;

      AuthenticationToken authenticationtoken = new AuthenticationToken(accessTokenc, userInfoc);
      Object actualValue = authenticationtoken.getPrincipal();

      Assertions.assertEquals(expectedValue, actualValue);
    } catch (Exception exception) {
      Assertions.assertFalse(false);
    }
  }

  @Test
  @DisplayName("get Access Token")
  public void getAccessToken() {
    try {
      String expectedValue = "";
      String accessTokenc = "";
      PingFederateValidateUserInfo userInfoc = null;

      AuthenticationToken authenticationtoken = new AuthenticationToken(accessTokenc, userInfoc);
      String actualValue = authenticationtoken.getAccessToken();

      Assertions.assertEquals(expectedValue, actualValue);
    } catch (Exception exception) {
      Assertions.assertFalse(false);
    }
  }

  @Test
  @DisplayName("get User Info")
  public void getUserInfo() {
    try {
      PingFederateValidateUserInfo expectedValue = null;

      String accessTokenc = "";
      PingFederateValidateUserInfo userInfoc = null;

      AuthenticationToken authenticationtoken = new AuthenticationToken(accessTokenc, userInfoc);
      PingFederateValidateUserInfo actualValue = authenticationtoken.getUserInfo();

      Assertions.assertEquals(expectedValue, actualValue);
    } catch (Exception exception) {
      Assertions.assertFalse(false);
    }
  }

  @AfterEach
  void tearDown() {
  }
}

