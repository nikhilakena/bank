/**
 *
 */
package com.abnamro.gpa.generic.glossarydao;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.abnamro.gpa.generic.glossarydao.dao.GPAAGlossaryDAOHelper;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryConfigurationMessageKeys;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryDAOException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class GPAAGlossaryDAOHelperTest {

  @InjectMocks
  private GPAAGlossaryDAOHelper underTest;

  @Test
  public void testValidateTermIDWithInvalidLength() {
    try {
      underTest.validateTermID(1000000);
    } catch (GPAAGlossaryDAOException e) {
      assertEquals(GPAAGlossaryConfigurationMessageKeys.VALIDATION_EXCEPTION_IN_DELETE_GLOSSARY,
          e.getMessages().getMessages().get(0).getMessageKey());
    }
  }

}
