package com.abnamro.gpa.generic.administrationdao.dao;

import static org.mockito.Mockito.when;

import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryDAOException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GPAAdministrationDAOTest {

  @InjectMocks
  private GPAAdministrationDAO testSubject;

  @Mock
  GPAAdministrationDAOMybatisMapper mapper;

  @Mock
  private SqlSession sqlSession;

  @Mock
  private SqlSessionFactory sessionFactory;

  @Test
  void testIsAdministrationPresentForTermWhenNoAdministrationisPresent()
      throws GPAAGlossaryDAOException, GPAAdministrationDAOException {
    int count = 0;
    when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(mapper);
    when(mapper.administrationCountForTerms(Mockito.anyInt())).thenReturn(count);
    when(sessionFactory.openSession()).thenReturn(sqlSession);
    Assertions.assertFalse(testSubject.isAdministrationPresentForTerm(12));
  }

  @Test
  void testIsAdministrationPresentForTermWhenOneAdministrationisPresent()
      throws GPAAGlossaryDAOException, GPAAdministrationDAOException {
    int count = 1;
    when(sqlSession.getMapper(GPAAdministrationDAOMybatisMapper.class)).thenReturn(mapper);
    when(mapper.administrationCountForTerms(Mockito.anyInt())).thenReturn(count);
    when(sessionFactory.openSession()).thenReturn(sqlSession);
    Assertions.assertTrue(testSubject.isAdministrationPresentForTerm(12));
  }
}