package com.abnamro.gpa.restservices.glossaryconfiguration.application;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GPAAGlossaryConfigurationApplicationTest {

  @InjectMocks
  private GPAAGlossaryConfigurationApplication testSubject;

  @Test
  void testSetTimeZoneToDutch() {
    testSubject.setTimeZoneToDutch();
  }

}