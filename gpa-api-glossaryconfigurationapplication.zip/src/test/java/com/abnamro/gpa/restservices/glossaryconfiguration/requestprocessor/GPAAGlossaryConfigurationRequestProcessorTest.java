package com.abnamro.gpa.restservices.glossaryconfiguration.requestprocessor;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.abnamro.gpa.generic.administrationdao.dao.GPAAdministrationDAO;
import com.abnamro.gpa.generic.administrationdao.exception.GPAAdministrationDAOException;
import com.abnamro.gpa.generic.glossarydao.dao.GPAAGlossaryDAO;
import com.abnamro.gpa.generic.glossarydao.dtos.GlossarySearchCriteriaView;
import com.abnamro.gpa.generic.glossarydao.dtos.TermView;
import com.abnamro.gpa.generic.glossarydao.exception.GPAAGlossaryDAOException;
import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossaryConfigurationResultDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossarySearchCriteriaDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.helper.TermRestViewMapper;
import com.abnamro.gpa.restservices.glossaryconfiguration.requestprocessor.GPAAGlossaryConfigurationRequestProcessor;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GPAAGlossaryConfigurationRequestProcessorTest {

    GPAAGlossaryConfigurationRequestProcessor underTest;
    @Mock
    GPAAGlossaryDAO mockDAO;
    @Mock
    TermRestViewMapper mapper;
    @Mock
    GPAAdministrationDAO gpaAdministrationDAO;



    @BeforeEach
    void setup() {
        underTest = new GPAAGlossaryConfigurationRequestProcessor(mockDAO,
                mapper, gpaAdministrationDAO);
    }


    @Test
    public void testSearchGlossary() {
        GlossarySearchCriteriaDTO glossarySearchCriteriaDTO = new GlossarySearchCriteriaDTO();
        glossarySearchCriteriaDTO.setTermId(123);
        glossarySearchCriteriaDTO.setTermName("Name");
        glossarySearchCriteriaDTO.setCreatedBy("C36098");
        glossarySearchCriteriaDTO.setCreatedTimestampFrom("21-09-2017");
        glossarySearchCriteriaDTO.setCreatedTimestampTo("06-07-9999");
        List<TermView> termViewList = new ArrayList<TermView>();
        GlossarySearchCriteriaView glossarySearchCriteriaView = new GlossarySearchCriteriaView();
        List<TermRestResource> termRestResourceList = new ArrayList<TermRestResource>();
        try {
            when(mapper.populateGlossarySearchCriteraView(glossarySearchCriteriaDTO))
                    .thenReturn(glossarySearchCriteriaView);
            when(mockDAO.searchGlossary(glossarySearchCriteriaView)).thenReturn(termViewList);
            when(mapper.convertGlossaryViewToTermRestResource(termViewList))
                    .thenReturn(termRestResourceList);
            assertEquals(termRestResourceList,
                    underTest.searchGlossary(glossarySearchCriteriaDTO));
        } catch (GPAAGlossaryApplicationException | GPAAGlossaryDAOException e) {
            fail("No Exception expected");
        }
    }

    @Test
    public void testCreateTerm() {
        TermRestResource termRestResource = new TermRestResource();
        TermView termView = new TermView();
        GlossaryConfigurationResultDTO glossaryConfigurationResultDTO = new GlossaryConfigurationResultDTO();
        try {
            when(mapper.convertTermRestResourceToTermView(Mockito.any())).thenReturn(termView);
            when(mockDAO.createTerm(Mockito.any())).thenReturn(12);
            when(mapper.convertToResultDTO(Mockito.anyInt())).thenReturn(glossaryConfigurationResultDTO);
            assertEquals(glossaryConfigurationResultDTO,
                    underTest.createTerm(termRestResource));
        } catch (GPAAGlossaryApplicationException | GPAAGlossaryDAOException e) {
            fail("No Exception expected");
        }

    }

    @Test
    public void testReadTerm() {
        TermView termView = new TermView();
        TermRestResource termRestResource = new TermRestResource();
        try {
            when(mockDAO.readTerm(11)).thenReturn(termView);
            when(mapper.convertTermViewToTermRestResource(termView)).thenReturn(termRestResource);
            assertEquals(termRestResource,
                    underTest.readTerm(11));
        } catch (GPAAGlossaryApplicationException | GPAAGlossaryDAOException e) {
            fail("No Exception expected");
        }
    }


    @Test
    @DisplayName("This method reads all the Terms")
    void testRetrieveAllTerm() {
        TermView termView = new TermView();
        termView.setId(1);
        ArrayList<TermView> termViews = new ArrayList<>();
        termViews.add(termView);
        TermRestResource termRestResource = new TermRestResource();
        termRestResource.setId(1);
        ArrayList<TermRestResource> termRestResources = new ArrayList<>();
        termRestResources.add(termRestResource);
        try {
            when(mockDAO.retrieveAllTerms()).thenReturn(termViews);
            List<TermRestResource> result = underTest.retrieveAllTerms();
            assertEquals(termRestResources.size(), result.size());
        } catch (GPAAGlossaryApplicationException | GPAAGlossaryDAOException e) {
            fail("No Exception expected");
        }
    }

    @Test
    public void testUpdateTermWithNoUpdates() {
        TermRestResource termRestResource = new TermRestResource();
        termRestResource.setId(1);
        termRestResource.setName("Test Term");
        termRestResource.setDescription("Test description");
        termRestResource.setDataType(TermDataType.STRING);

        TermView termView = new TermView();
        termView.setId(1);
        termView.setName("Test Term");
        termView.setDescription("Test description");
        termView.setDataType("STRING");
        GlossaryConfigurationResultDTO glossaryConfigurationResultDTO = new GlossaryConfigurationResultDTO();
        glossaryConfigurationResultDTO.setIndicatorSuccess(true);
        glossaryConfigurationResultDTO.setIdentifier(1);
        try {
            when(mapper.convertTermRestResourceToTermView(termRestResource)).thenReturn(termView);
            when(mockDAO.readTerm(1)).thenReturn(termView);
            Mockito.lenient().when(mockDAO.updateTerm(termView)).thenReturn(true);

            glossaryConfigurationResultDTO = underTest.updateTerm(termRestResource);
        } catch (GPAAGlossaryApplicationException | GPAAGlossaryDAOException e) {
            assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_NO_UPDATES, e.getMessages().getMessages().get(0).getMessageKey());
            //assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_NO_UPDATES, e.getMessage());
          //  assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_NO_UPDATES, "MESSAGE_GLSC_017");
        }

    }


    @Test
    public void testUpdateTerm() {
        TermRestResource termRestResource = new TermRestResource();
        termRestResource.setId(1);
        termRestResource.setName("Test Term Updated");
        termRestResource.setDescription("Test description");
        termRestResource.setDataType(TermDataType.STRING);

        AuditDetails auditDetails = new AuditDetails();
        auditDetails.setCreatedBy("PA2619");
        auditDetails.setModifiedBy("SE1290");
        termRestResource.setAuditDetails(auditDetails);

        TermView termView = new TermView();
        termView.setId(1);
        termView.setName("Test Term");
        termView.setDescription("Test description");
        termView.setDataType("STRING");

        TermView termViewToBeUpdated = new TermView();
        termViewToBeUpdated.setId(1);
        termViewToBeUpdated.setName("Test Term Updated");
        termViewToBeUpdated.setDescription("Test description");
        termViewToBeUpdated.setDataType("STRING");
        termViewToBeUpdated.setCreatedBy("PA2619");
        termViewToBeUpdated.setModifiedBy("SE1290");

        try {
            when(mapper.convertTermRestResourceToTermView(termRestResource)).thenReturn(termViewToBeUpdated);
            when(mockDAO.readTerm(1)).thenReturn(termView);
            Mockito.lenient().when(mockDAO.updateTerm(termViewToBeUpdated)).thenReturn(true);

            GlossaryConfigurationResultDTO glossaryConfigurationResultDTO = underTest.updateTerm(termRestResource);
            assertTrue(glossaryConfigurationResultDTO.isIndicatorSuccess());
        } catch (GPAAGlossaryApplicationException | GPAAGlossaryDAOException e) {
            fail("No Exception expected");
        }

    }


    @Test
    public void testUpdateTermIfAttachedToAdministration() {
        TermRestResource termRestResource = new TermRestResource();
        termRestResource.setId(1);
        termRestResource.setName("Test Term Updated");
        termRestResource.setDescription("Test description");
        termRestResource.setDataType(TermDataType.STRING);

        AuditDetails auditDetails = new AuditDetails();
        auditDetails.setCreatedBy("PA2619");
        auditDetails.setModifiedBy("SE1290");
        termRestResource.setAuditDetails(auditDetails);

        TermView termView = new TermView();
        termView.setId(1);
        termView.setName("Test Term");
        termView.setDescription("Test description");
        termView.setDataType("STRING");

        TermView termViewToBeUpdated = new TermView();
        termViewToBeUpdated.setId(1);
        termViewToBeUpdated.setName("Test Term Updated");
        termViewToBeUpdated.setDescription("Test description");
        termViewToBeUpdated.setDataType("STRING");
        termViewToBeUpdated.setCreatedBy("PA2619");
        termViewToBeUpdated.setModifiedBy("SE1290");

        try {
            when(mapper.convertTermRestResourceToTermView(termRestResource)).thenReturn(termViewToBeUpdated);
            when(mockDAO.readTerm(1)).thenReturn(termView);
            when(gpaAdministrationDAO.isAdministrationPresentForTerm(1)).thenReturn(true);
            Mockito.lenient().when(mockDAO.updateTerm(termViewToBeUpdated)).thenReturn(true);

            GlossaryConfigurationResultDTO glossaryConfigurationResultDTO = underTest.updateTerm(termRestResource);
        } catch (GPAAGlossaryApplicationException | GPAAGlossaryDAOException | GPAAdministrationDAOException e) {
            assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.EXCEPTION_IN_GLOSSARY_TERM_NAME_UPDATE_NOT_ALLOWED, e.getMessages().getMessages().get(0).getMessageKey());
            //assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.EXCEPTION_IN_GLOSSARY_TERM_NAME_UPDATE_NOT_ALLOWED, e.getMessage());
            //assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.EXCEPTION_IN_GLOSSARY_TERM_NAME_UPDATE_NOT_ALLOWED, "MESSAGE_GLSC_018");
        }

    }


}
