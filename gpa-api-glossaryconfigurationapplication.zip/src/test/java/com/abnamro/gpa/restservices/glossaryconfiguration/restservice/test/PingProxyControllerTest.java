package com.abnamro.gpa.restservices.glossaryconfiguration.restservice.test;

import com.abnamro.gpa.generic.security.*;
import com.abnamro.gpa.generic.security.JwtAuthHelper;
import com.abnamro.gpa.restservices.glossaryconfiguration.config.ping.PingClientConfig;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.AuthenticationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.restservice.PingProxyController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ActiveProfiles("local")
@Import(PingProxyController.class)
@WebMvcTest(PingProxyController.class)
@ContextConfiguration(classes = {
        SecurityConfig.class,
        PreAuthenticationFilter.class,
        PingFederateAuthenticationProvider.class,
        PingFederateAuthenticationService.class,
        JwtAuthHelper.class,
        RequestSecurityPropertyConfig.class
})
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class PingProxyControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    private PingClientConfig pingClientConfig;

    @MockBean
    private  JwtAuthHelper jwtAuthHelper;

    @Mock
    PingFederateValidateUserInfo pingFederateValidateUserInfo;

    @BeforeEach
    void setUp() throws AuthenticationException {
        Mockito.when(pingClientConfig.getAccessToken(Mockito.anyString())).thenReturn(pingFederateValidateUserInfo);
        Mockito.when(pingFederateValidateUserInfo.isActive()).thenReturn(true);
        Mockito.when(pingFederateValidateUserInfo.getUserId()).thenReturn("SF2001");
        Mockito.when(pingFederateValidateUserInfo.getRoles()).thenReturn("[\"SG_APP_GPA_READ_MODIFY\"]");
        Mockito.when(pingFederateValidateUserInfo.getDepartmentNumber()).thenReturn("399339");
    }

    @Test
    void testGetPingAccessToken() throws Exception {
        Map<String, String> tokenMap = new HashMap<>();
        tokenMap.put("access_token","token");
        tokenMap.put("id_token","eyJhbGciOiJIUzI1NiIsImtpZCI6IjJnb2ZNS1I0Q195WXp4TkJ4cDFvelJNa0hlbyJ9.eyJzdWIiOiJTRjIwMDEiLCJhdWQiOiJPRUlPIiwianRpIjoiZ0V2VTE1S2FxVTI4a2ZiSnFPVjU5VSIsImlzcyI6Imh0dHBzOi8vc2VjdXJpdHktaWZzLXRlc3QuY29ubmVjdC5hYm5hbXJvLmNvbTo5MDMxIiwiaWF0IjoxNjY1ODE5NjE5LCJleHAiOjE2NjU4MjMyMTksImF1dGhfdGltZSI6MTY2NTgxOTYxOSwicm9sZXMiOiJTR19BUFBfT0VJT19BQlIiLCJhdG0iOiJNU2VjRW1wbG95ZWVPSURDIiwidXNlcmlkIjoiU0YyMDAxIiwiYXV0aHR5cGUiOiJrZXJiIn0.4ItcdTk1gFjXjrZccWSjgpDQL9u6zd63a7A-xT435zk");
        Mockito.when(pingClientConfig.callPingAPI(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(tokenMap);
        Mockito.when(pingFederateValidateUserInfo.isActive()).thenReturn(false);
        Mockito.when(jwtAuthHelper.verifyUserJwtSession(any())).thenReturn(pingFederateValidateUserInfo);
        Mockito.when(jwtAuthHelper.createUserJwtSession(any())).thenReturn("token");

        mockMvc.perform(post("/v1/authencationcheck/checkAccess")
                .header("Authorization","Bearer token")

                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .content("code=hmXndU0NR6eeEwXZnCxSC0oH9sVjZjMq4-JD4J1y&grant_type=authorization_code&redirect_uri=http%3A%2F%2Flocalhost%3A8080%2Fbrokerage-order%2F")
        )
                .andExpect(status().is2xxSuccessful());
    }

    @Test
    void testValidatePingToken() throws Exception {
        //Mockito.when(pingFederateValidateUserInfo.isActive()).thenReturn(false);
        PingFederateValidateUserInfo pingDTO = new PingFederateValidateUserInfo();
        pingDTO.setActive(false);
        Mockito.when(jwtAuthHelper.verifyUserJwtSession(Mockito.anyString())).thenReturn(pingDTO);

        mockMvc.perform(post("/v1/authencationcheck/validateToken")
                .header("Authorization","Bearer token")

        )
                .andExpect(status().is4xxClientError());
    }

    @Test
    void testInvalidatePingToken() throws Exception {
        PingFederateValidateUserInfo pingDTO = new PingFederateValidateUserInfo();
        pingDTO.setActive(false);
        Mockito.when(jwtAuthHelper.verifyUserJwtSession(Mockito.anyString())).thenReturn(pingDTO);
        mockMvc.perform(post("/v1/authencationcheck/validateToken")
                .header("Authorization","Bearer token")

        )
                .andExpect(status().isUnauthorized());
    }
}
