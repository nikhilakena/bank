package com.abnamro.gpa.restservices.glossaryconfiguration.restresource.administration;

import com.abnamro.gpa.restresource.administration.AdministrationRestResource;
import com.abnamro.gpa.restservices.glossaryconfiguration.restresource.util.UtilityClass;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AdministrationRestResourceTest {

  AdministrationRestResource underTest;
  AdministrationRestResource testAdministrationRestResource;

  UtilityClass utilityClass = new UtilityClass();

  @BeforeEach
  public void startUp() {
    underTest = new AdministrationRestResource();

    //set default
    testAdministrationRestResource = new AdministrationRestResource();
    testAdministrationRestResource = utilityClass.setterAdministrationRestResource();
  }

  @Test
  void testGettersSetterAdministrationRestResource() {

    underTest = utilityClass.setterAdministrationRestResource();

    Assertions.assertSame(underTest.getId(),testAdministrationRestResource.getId());
    Assertions.assertSame(underTest.getName(),testAdministrationRestResource.getName());
    Assertions.assertSame(underTest.getOarId(),testAdministrationRestResource.getOarId());
    Assertions.assertSame(underTest.getDescription(),testAdministrationRestResource.getDescription());
    Assertions.assertSame(underTest.getTerms().get(0).getName(),testAdministrationRestResource.getTerms().get(0).getName());
    Assertions.assertSame(underTest.getAuditDetails().getCreatedBy(),testAdministrationRestResource.getAuditDetails().getCreatedBy());
    Assertions.assertSame(underTest.getProducts().get(0),testAdministrationRestResource.getProducts().get(0));
  }


}
