package com.abnamro.gpa.restservices.glossaryconfiguration.restservice.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.abnamro.gpa.restresource.exception.Error;
import com.abnamro.gpa.restresource.exception.Errors;
import com.abnamro.gpa.restservices.glossaryconfiguration.util.ErrorAndLogUtils;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import java.util.List;
import org.junit.jupiter.api.Test;

class ErrorAndLogUtilsTest {

    Errors errors = new Errors();

    @Test
    public void setErrorTest() {
        String code = "ERROR_CODE";
        String message = "This is error message";

        ErrorAndLogUtils.setError(errors, code, message);

        assertNotNull(errors);
        assertNotNull(errors.getErrors());
        assertEquals(1L, errors.getErrors().size());

        @Valid @Size(min = 1, max = 5) List<Error> errorList = errors.getErrors();

        assertNotNull(errorList.get(0));

        Error error = errorList.get(0);

        assertEquals(code, error.getCode());
        assertEquals(message, error.getMessage());
    }

}
