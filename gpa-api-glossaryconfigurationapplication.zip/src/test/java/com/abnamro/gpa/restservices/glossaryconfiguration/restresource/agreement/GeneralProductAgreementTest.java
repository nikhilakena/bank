package com.abnamro.gpa.restservices.glossaryconfiguration.restresource.agreement;

import com.abnamro.gpa.restresource.agreement.GeneralProductAgreement;
import com.abnamro.gpa.restresource.agreement.Term;
import com.abnamro.gpa.restresource.enumeration.AgreementLifeCycleStatusType;
//import com.abnamro.nl.dto.util.AbstractDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class GeneralProductAgreementTest  {//extends AbstractDTO

  GeneralProductAgreement underTest;
  GeneralProductAgreement testGeneralProductAgreement;

  String productId = "1621";
  String customerId = "0001";
  String agreementStartDate = "2020-06-15 12:16:10";
  String agreementEndDate = "2018-06-15 12:16:10";
  String createdBy = "GPAA";
  String dateCreated = "";
  String modifiedBy = "GPAA Update";
  String dateModified = "";
  AgreementLifeCycleStatusType agreementLifeCycleStatusType = AgreementLifeCycleStatusType.INACTIVE;
  String agreementId = "121";

  List<Term> terms;

  @BeforeEach
  public void startUp() {
    underTest = new GeneralProductAgreement();

    //set default
    testGeneralProductAgreement = new GeneralProductAgreement();
    testGeneralProductAgreement.setProductId(productId);
    testGeneralProductAgreement.setCustomerId(customerId);
    testGeneralProductAgreement.setAgreementStartDate(agreementStartDate);
    testGeneralProductAgreement.setAgreementEndDate(agreementEndDate);
    testGeneralProductAgreement.setCreatedBy(createdBy);
    testGeneralProductAgreement.setDateCreated(dateCreated);
    testGeneralProductAgreement.setModifiedBy(modifiedBy);
    testGeneralProductAgreement.setDateModified(dateModified);
    testGeneralProductAgreement.setAgreementLifeCycleStatusType(agreementLifeCycleStatusType);
    testGeneralProductAgreement.setAgreementId(agreementId);
    terms = termsSetter();
    testGeneralProductAgreement.setTerms(terms);
  }

  @Test
  void testGettersSetterGeneralProductAgreement() {

    underTest = new GeneralProductAgreement();
    underTest.setProductId(productId);
    underTest.setCustomerId(customerId);
    underTest.setAgreementStartDate(agreementStartDate);
    underTest.setAgreementEndDate(agreementEndDate);
    underTest.setCreatedBy(createdBy);
    underTest.setDateCreated(dateCreated);
    underTest.setModifiedBy(modifiedBy);
    underTest.setDateModified(dateModified);
    underTest.setAgreementLifeCycleStatusType(agreementLifeCycleStatusType);
    underTest.setAgreementId(agreementId);
    terms = termsSetter();

    underTest.setTerms(terms);

    Assertions.assertSame(underTest.getProductId(),testGeneralProductAgreement.getProductId());
    Assertions.assertSame(underTest.getCustomerId(),testGeneralProductAgreement.getCustomerId());
    Assertions.assertSame(underTest.getAgreementStartDate(),testGeneralProductAgreement.getAgreementStartDate());
    Assertions.assertSame(underTest.getAgreementEndDate(),testGeneralProductAgreement.getAgreementEndDate());
    Assertions.assertSame(underTest.getCreatedBy(),testGeneralProductAgreement.getCreatedBy());
    Assertions.assertSame(underTest.getDateCreated(),testGeneralProductAgreement.getDateCreated());
    Assertions.assertSame(underTest.getModifiedBy(),testGeneralProductAgreement.getModifiedBy());
    Assertions.assertSame(underTest.getDateModified(),testGeneralProductAgreement.getDateModified());
    Assertions.assertSame(underTest.getAgreementLifeCycleStatusType(),testGeneralProductAgreement.getAgreementLifeCycleStatusType());
    Assertions.assertSame(underTest.getAgreementId(),testGeneralProductAgreement.getAgreementId());
    Assertions.assertSame(underTest.getTerms().get(0).getTermId(),testGeneralProductAgreement.getTerms().get(0).getTermId());
  }

  private List termsSetter() {
    terms = new ArrayList<>();

    Term term = new Term();
    term.setTermId("1");
    term.setAttributeName("test");
    term.setAttributeValue("testValue");
    terms.add(term);
    return terms;
  }

}
