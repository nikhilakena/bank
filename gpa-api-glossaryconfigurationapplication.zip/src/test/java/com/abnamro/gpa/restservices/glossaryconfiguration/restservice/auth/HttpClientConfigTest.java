package com.abnamro.gpa.restservices.glossaryconfiguration.restservice.auth;

import com.abnamro.gpa.restservices.glossaryconfiguration.config.ping.HttpClientConfig;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

@ExtendWith(MockitoExtension.class)
class HttpClientConfigTest {

    @InjectMocks
    HttpClientConfig httpClientConfig;

    @BeforeEach
    void setUp() throws GeneralSecurityException, IOException {
    }



    @Test

    void getHttpClientLocal() throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
        Assertions.assertNotNull(httpClientConfig.getHttpClientLocal());
    }
}
