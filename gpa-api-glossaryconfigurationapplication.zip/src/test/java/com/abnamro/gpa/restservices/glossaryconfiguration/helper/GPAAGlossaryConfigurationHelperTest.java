package com.abnamro.gpa.restservices.glossaryconfiguration.helper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossarySearchCriteriaDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GPAAGlossaryConfigurationHelperTest {

  @InjectMocks
  private GPAAGlossaryConfigurationHelper testSubject;

  @Test
  void testConvertToGlossarySearchCriteriaDTO() throws GPAAGlossaryApplicationException {
    GlossarySearchCriteriaDTO glossarySearchCriteriaDTO = testSubject.convertToGlossarySearchCriteriaDTO("12", "Name",
        "GPA", "datefrom", "dateto");
    assertEquals(12, glossarySearchCriteriaDTO.getTermId());
    assertEquals("Name", glossarySearchCriteriaDTO.getTermName());
  }
}