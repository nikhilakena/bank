package com.abnamro.gpa.restservices.glossaryconfiguration.restservice.test;

import com.abnamro.gpa.restresource.exception.Errors;
import com.abnamro.gpa.restresource.exception.RequestScopeBeans;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.context.request.WebRequest;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class GPAGlossaryConfigurationExceptionHandlerTest {


    @InjectMocks
    private  GPAGlossaryConfigurationExceptionHandler underTest;
    @Mock
    private Environment env;
    @Mock
    private RequestScopeBeans requestScopeBeans;
@Mock
private WebRequest request;


    @Test
    public void shouldCatchGPAGlossaryConfigurationException() {

       // Mockito.doReturn("MESSAGE_GLSC_018").when(env).getProperty("MESSAGE_GLSC_018_code");
       // when(env.getProperty("500_code")).thenReturn("500");
        when(requestScopeBeans.getTraceId()).thenReturn("dasdasdsd");
        Messages messages = new Messages();
        messages.addMessage(new Message(GPAAGlossaryConfigurationMessageKeyConstants.EXCEPTION_IN_GLOSSARY_TERM_NAME_UPDATE_NOT_ALLOWED),
                MessageType.getError());
        ResponseEntity response =underTest.handleGPAAGlossaryApplicationException(new GPAAGlossaryApplicationException(messages));
        Assertions.assertEquals(((Errors)response.getBody()).getErrors().get(0).getCode(),GPAAGlossaryConfigurationMessageKeyConstants.EXCEPTION_IN_GLOSSARY_TERM_NAME_UPDATE_NOT_ALLOWED.getId());

    }

    @Test
    public void shouldCatchBadCredentialsApplicationException() {

        when(env.getProperty("UnderInactive_code")).thenReturn("401");
        when(requestScopeBeans.getTraceId()).thenReturn("dasdasdsd");

        ResponseEntity response =underTest.handleBadCredentialsApplicationException(new BadCredentialsException("UnderInactive"));
        Assertions.assertEquals(((Errors)response.getBody()).getErrors().get(0).getCode(),String.valueOf(HttpStatus.UNAUTHORIZED.value()));

    }
    @Test
    public void shouldCatchGeneralException() {

        Mockito.doReturn("500").when(env).getProperty("500_code");
        // when(env.getProperty("500_code")).thenReturn("500");
        when(requestScopeBeans.getTraceId()).thenReturn("dasdasdsd");


        ResponseEntity response =underTest.handleGeneralException(new Exception("Generalexception"));
        Assertions.assertEquals(((Errors)response.getBody()).getErrors().get(0).getCode(),String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));

    }
}
