package com.abnamro.gpa.restservices.glossaryconfiguration.restservice.helper;

import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossarySearchCriteriaDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.helper.TermRestViewMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TermRestViewMapperTest {


    private TermRestViewMapper underTest;

    @Test
    public void testPopulateGlossarySearchCriteraView()
    {
        GlossarySearchCriteriaDTO inputDTO= new GlossarySearchCriteriaDTO();


    }
}
