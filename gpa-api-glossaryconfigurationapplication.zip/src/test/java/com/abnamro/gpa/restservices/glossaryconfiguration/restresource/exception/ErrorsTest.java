package com.abnamro.gpa.restservices.glossaryconfiguration.restresource.exception;

import com.abnamro.gpa.restresource.exception.Error;
import com.abnamro.gpa.restresource.exception.Errors;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


@ExtendWith(MockitoExtension.class)
class ErrorsTest {

    Errors underTest;
    Errors testErrors;

    List<Error> errors;

    @BeforeEach
    public void startUp() {
        underTest = new Errors();

        //set default
        testErrors = new Errors();

        errors = errorsSetter();
        testErrors.setErrors(errors);
    }

    @Test
    void testGettersSetterErrors() {

        underTest = new Errors();

        errors = errorsSetter();
        underTest.setErrors(errors);

        Assertions.assertSame(underTest.getErrors().get(0).getCode(),testErrors.getErrors().get(0).getCode());
        Assertions.assertSame(underTest.getErrors().get(0).getMessage(),testErrors.getErrors().get(0).getMessage());
        Assertions.assertSame(underTest.getErrors().get(0).getTraceId(),testErrors.getErrors().get(0).getTraceId());
        Assertions.assertSame(underTest.getErrors().get(0).getStatus(),testErrors.getErrors().get(0).getStatus());
        Assertions.assertSame(underTest.getErrors().get(0).getParams().get(0).toString(),testErrors.getErrors().get(0).getParams().get(0).toString());
    }

    private Error setError() {
        Error error = new Error();

        String code = "INTERNAL_SERVER_ERROR";
        String message = "Internal Server Error occured";
        String traceId = "NA";
        String status = "NA";
        List<String> params;

        error.setCode(code);
        error.setMessage(message);
        error.setTraceId(traceId);
        error.setStatus(status);

        params = Arrays.asList("1");

        error.setParams(params);

        return error;
    }

    private List errorsSetter() {
        errors = new ArrayList<>();

        errors.add(setError());
        return errors;
    }
    private List errorsSetterCompare() {
        errors = new ArrayList<>();

        errors.add(setErrorCompare());
        return errors;
    }

    private Error setErrorCompare() {
        Error error = new Error();

        String code = "INTERNAL_SERVER_ERROR!";
        String message = "Internal Server Error occured!";
        String traceId = "NA";
        String status = "NA";
        List<String> params;

        error.setCode(code);
        error.setMessage(message);
        error.setTraceId(traceId);
        error.setStatus(status);

        params = Arrays.asList("1");

        error.setParams(params);

        return error;
    }

    @Test
    void testEquals() {
        // Initialize objects
        underTest = new Errors();

        errors = errorsSetter();
        underTest.setErrors(errors);

        // Change value of var and test equal
        underTest.setErrors(errorsSetterCompare());
        Assertions.assertFalse(testErrors.equals(underTest));
        underTest.setErrors(errorsSetter());


        // Then at the end perform the other tests
        Assertions.assertTrue(testErrors.equals(testErrors));
        Assertions.assertTrue(testErrors.equals(underTest));
        Assertions.assertFalse(testErrors.equals(null));
        Assertions.assertFalse(testErrors.equals(42));
        Assertions.assertTrue(underTest.equals(testErrors));
    }

    @Test
    void testHashCode() {
        Assertions.assertSame(underTest.hashCode(), 31);
    }

    @Test
    void testToAddErrorsItem() {
        Assertions.assertSame(underTest.addErrorsItem(setError()).getErrors().get(0).getCode(), testErrors.getErrors().get(0).getCode());
        Assertions.assertSame(underTest.addErrorsItem(setError()).getErrors().get(0).getMessage(),testErrors.getErrors().get(0).getMessage());
        Assertions.assertSame(underTest.addErrorsItem(setError()).getErrors().get(0).getTraceId(),testErrors.getErrors().get(0).getTraceId());
        Assertions.assertSame(underTest.addErrorsItem(setError()).getErrors().get(0).getStatus(),testErrors.getErrors().get(0).getStatus());
        Assertions.assertSame(underTest.addErrorsItem(setError()).getErrors().get(0).getParams().get(0).toString(),testErrors.getErrors().get(0).getParams().get(0).toString());

    }

    @Test
    void testErrors() {
        Assertions.assertSame(underTest.errors(errorsSetter()).getErrors().get(0).getCode(),testErrors.getErrors().get(0).getCode());
        Assertions.assertSame(underTest.errors(errorsSetter()).getErrors().get(0).getMessage(),testErrors.getErrors().get(0).getMessage());
        Assertions.assertSame(underTest.errors(errorsSetter()).getErrors().get(0).getTraceId(),testErrors.getErrors().get(0).getTraceId());
        Assertions.assertSame(underTest.errors(errorsSetter()).getErrors().get(0).getStatus(),testErrors.getErrors().get(0).getStatus());
        Assertions.assertSame(underTest.errors(errorsSetter()).getErrors().get(0).getParams().get(0).toString(),testErrors.getErrors().get(0).getParams().get(0).toString());
    }
}