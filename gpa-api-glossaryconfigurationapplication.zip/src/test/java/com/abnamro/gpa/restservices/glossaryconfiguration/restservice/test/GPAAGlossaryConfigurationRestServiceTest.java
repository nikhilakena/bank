package com.abnamro.gpa.restservices.glossaryconfiguration.restservice.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restresource.helper.AuditDetails;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossaryConfigurationResultDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.dtos.GlossarySearchCriteriaDTO;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.helper.GPAAGlossaryConfigurationHelper;
import com.abnamro.gpa.restservices.glossaryconfiguration.helper.GPAAGlossaryValidator;
import com.abnamro.gpa.restservices.glossaryconfiguration.requestprocessor.GPAAGlossaryConfigurationRequestProcessor;
import com.abnamro.gpa.restservices.glossaryconfiguration.restservice.GPAAGlossaryConfigurationRestService;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
class GPAAGlossaryConfigurationRestServiceTest {

	GPAAGlossaryConfigurationRestService underTest;
	@Mock
	GPAAGlossaryConfigurationRequestProcessor processor;
	@Mock
	GPAAGlossaryConfigurationHelper helper;
	@Mock
	GPAAGlossaryValidator util;

	@BeforeEach
	void setUp() {
		underTest = new GPAAGlossaryConfigurationRestService(processor,helper,util);
	}

	@Test
	public void testSearchGlossary() {
		String termId = "10";
		String termName = "Name";
		String createdBy = "C36098";
		String createdTimeStampFrom = "10-08-2018";
		String createdTimeStampTo = "06-08-9999";

		List<TermRestResource> termResourceList = new ArrayList<TermRestResource>();
		GlossarySearchCriteriaDTO glossarySearchCriteriaDTO = new GlossarySearchCriteriaDTO();
		try {
			when(helper.convertToGlossarySearchCriteriaDTO(termId, termName, createdBy, createdTimeStampFrom, createdTimeStampTo)).thenReturn(glossarySearchCriteriaDTO);
			when(processor.searchGlossary(glossarySearchCriteriaDTO)).thenReturn(termResourceList);
			//assertEquals(Response.status(Status.OK).entity(termResourceList).build().getStatus(),underTest.searchGlossary(null, null, termId, termName, createdBy, createdTimeStampFrom, createdTimeStampTo).getStatus());
			assertEquals(new ResponseEntity<>(termResourceList, HttpStatus.OK),underTest.searchGlossary(null ,termId, termName, createdBy, createdTimeStampFrom, createdTimeStampTo));

		} catch (GPAAGlossaryApplicationException e) {
			fail("No Exception expected");
		}
	}

	@Test
	public void testCreateTerm() {
		TermRestResource termRestResource = new TermRestResource();
		termRestResource.setDataType(TermDataType.STRING);
		termRestResource.setDescription("description");
		termRestResource.setId(12);
		termRestResource.setName("name");
		AuditDetails auditDetails = new AuditDetails();
		auditDetails.setCreatedBy("C36098");
		auditDetails.setCreatedTimeStamp(new Date());
		termRestResource.setAuditDetails(auditDetails );

		GlossaryConfigurationResultDTO glossaryDTO = new GlossaryConfigurationResultDTO();
		glossaryDTO.setIdentifier(1);
		glossaryDTO.setIndicatorSuccess(true);
		try {
			when(processor.createTerm(termRestResource)).thenReturn(glossaryDTO);
			//assertEquals(glossaryDTO,underTest.createTerm(null, null, termRestResource));
			assertEquals(new ResponseEntity<>(glossaryDTO, HttpStatus.OK),underTest.createTerm(null,termRestResource));
		} catch (GPAAGlossaryApplicationException e) {
			fail("No Exception expected");
		}
	}


	@Test
	public void testReadTerm() {
		TermRestResource termRestResource = new TermRestResource();
		termRestResource.setDataType(TermDataType.STRING);
		termRestResource.setDescription("description");
		termRestResource.setId(12);
		termRestResource.setName("name");
		AuditDetails auditDetails = new AuditDetails();
		auditDetails.setCreatedBy("C36098");
		auditDetails.setCreatedTimeStamp(new Date());
		termRestResource.setAuditDetails(auditDetails );
		try {
			when(processor.readTerm(12)).thenReturn(termRestResource);
			//assertEquals(Response.status(Status.OK).entity(termRestResource).build().getStatus(),underTest.readTerm(null, null, "12").getStatus());
			assertEquals(new ResponseEntity<>(termRestResource, HttpStatus.OK),underTest.readTerm(null,"12"));
		} catch (GPAAGlossaryApplicationException e) {
			fail("No Exception expected");
		}
	}

	@Test
	public void testUpdateTerm() {
		TermRestResource termRestResource = new TermRestResource();
		termRestResource.setDescription("description");
		termRestResource.setName("");
		termRestResource.setDataType(TermDataType.STRING);
		termRestResource.setId(10);
		AuditDetails auditDetails = new AuditDetails();
		auditDetails.setModifiedBy("GPAGLO");
		auditDetails.setModifiedTimeStamp(new Date());
		termRestResource.setAuditDetails(auditDetails);

		GlossaryConfigurationResultDTO glossaryDTO = new GlossaryConfigurationResultDTO();
		glossaryDTO.setIndicatorSuccess(true);
		try {
			when(processor.updateTerm(termRestResource)).thenReturn(glossaryDTO);
			//assertEquals(Response.status(Status.OK).entity(glossaryDTO).build().getStatus(),underTest.updateTerm(null, null, termRestResource).getStatus());
			assertEquals(new ResponseEntity<>(glossaryDTO, HttpStatus.OK),underTest.updateTerm(null,termRestResource));

		} catch (GPAAGlossaryApplicationException e) {
			fail("No Exception expected");
		}
	}


	@Test
	@DisplayName("This method retrieves all the terms")
	void testRetrieveAllTerms() {
		TermRestResource termRestResource = new TermRestResource();
		termRestResource.setDataType(TermDataType.STRING);
		termRestResource.setDescription("description");
		termRestResource.setId(12);
		termRestResource.setName("name");
		AuditDetails auditDetails = new AuditDetails();
		auditDetails.setCreatedBy("C36098");
		auditDetails.setCreatedTimeStamp(new Date());
		termRestResource.setAuditDetails(auditDetails );
		ArrayList<TermRestResource> terms = new ArrayList<>();
		terms.add(termRestResource);
		try {
			when(processor.retrieveAllTerms()).thenReturn(terms);
			assertEquals(new ResponseEntity<List<TermRestResource>>(terms, HttpStatus.OK),underTest.retrieveAllTerms(null));
		} catch (GPAAGlossaryApplicationException e) {
			fail("No Exception expected");
		}
	}

	/*@Test
	public void testDeleteTermWithInvalidId() {
		try {
			underTest.deleteTerm(null, -1);
		} catch ( GPAAGlossaryApplicationException e) {
			e.getErrorMessageWrapper().getErrors();
			assertEquals(Response.Status.INTERNAL_SERVER_ERROR, e.getErrorMessageWrapper().getErrors());
		}
	}*/

}
