package com.abnamro.gpa.restservices.glossaryconfiguration.restresource.agreement;

import com.abnamro.gpa.restresource.agreement.Term;
//import com.abnamro.nl.dto.util.AbstractDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TermTest  {//extends AbstractDTO

  Term underTest;
  Term testTerm = new Term();

  String termId = "1";
  String attributeName = "test";
  String attributeValue = "testValue";

  @BeforeEach
  public void startUp() {
    underTest = new Term();

    //set default
    testTerm = new Term();
    testTerm.setTermId(termId);
    testTerm.setAttributeName(attributeName);
    testTerm.setAttributeValue(attributeValue);
  }

  @Test
  void testGettersSetterTerm() {
    underTest.setTermId(termId);
    underTest.setAttributeName(attributeName);
    underTest.setAttributeValue(attributeValue);

    Assertions.assertSame(underTest.getTermId(),testTerm.getTermId());
    Assertions.assertSame(underTest.getAttributeName(),testTerm.getAttributeName());
    Assertions.assertSame(underTest.getAttributeValue(),testTerm.getAttributeValue());
  }

}
