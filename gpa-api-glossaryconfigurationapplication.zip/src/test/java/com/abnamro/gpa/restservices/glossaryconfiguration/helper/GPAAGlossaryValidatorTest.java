/**
 * 
 */
package com.abnamro.gpa.restservices.glossaryconfiguration.helper;

import com.abnamro.gpa.restresource.enumeration.TermDataType;
import com.abnamro.gpa.restresource.glossary.TermRestResource;
import com.abnamro.gpa.restservices.glossaryconfiguration.constant.GPAAGlossaryConfigurationMessageKeyConstants;
import com.abnamro.gpa.restservices.glossaryconfiguration.exceptions.GPAAGlossaryApplicationException;
import com.abnamro.gpa.restservices.glossaryconfiguration.helper.GPAAGlossaryValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GPAAGlossaryValidatorTest {
    GPAAGlossaryValidator underTest;

	@BeforeEach
	void setup() {
		underTest = new GPAAGlossaryValidator();
	}

	@Test
	public void testValidateGlossarySearchCriteriaWithEmptyInput(){
		try {
			underTest.validateGlossarySearchCriteria("", "", "", "", "");
		} catch (GPAAGlossaryApplicationException e) {
			assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.ATLEAST_ONE_SEARCH_CRITERIA_IS_REQUIRED_IN_GLOSSARY_SEARCH, e.getMessages().getMessages().get(0).getMessageKey());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.ATLEAST_ONE_SEARCH_CRITERIA_IS_REQUIRED_IN_GLOSSARY_SEARCH, e.getMessage());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.ATLEAST_ONE_SEARCH_CRITERIA_IS_REQUIRED_IN_GLOSSARY_SEARCH, "MESSAGE_GLSC_004");
		}
	}

	@Test
	public void testValidateGlossarySearchCriteriaWithInvalidTermId(){
		try {
			underTest.validateGlossarySearchCriteria("-1", "", "", "", "");
		} catch (GPAAGlossaryApplicationException e) {
			assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_TERM_ID_IS_NOT_NUMERIC, e.getMessages().getMessages().get(0).getMessageKey());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_TERM_ID_IS_NOT_NUMERIC, e.getMessage());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_TERM_ID_IS_NOT_NUMERIC, "MESSAGE_GLSC_006");
		}
	}

    @Test
    public void testValidateGlossarySearchCriteriaWithNonNumericTermId(){
        try {
            underTest.validateGlossarySearchCriteria("testtermid", "", "", "", "");
        } catch (GPAAGlossaryApplicationException e) {
            assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.PARSING_EXCEPTION, e.getMessages().getMessages().get(0).getMessageKey());
            //assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.PARSING_EXCEPTION, e.getMessage());
            //assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.PARSING_EXCEPTION, "MESSAGE_GLSC_003");
        }
    }

	@Test
	public void testValidateGlossarySearchCriteriaWithInvalidDates(){
		try {
			underTest.validateGlossarySearchCriteria("1", "TestTerm", "PA2619", "23-10-2022", "01-10-2022");
		} catch (GPAAGlossaryApplicationException e) {
			assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_SEARCH_FROM_DATE_CAN_NOT_BE_GREATER_THAN_TO_DATE, e.getMessages().getMessages().get(0).getMessageKey());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_SEARCH_FROM_DATE_CAN_NOT_BE_GREATER_THAN_TO_DATE, e.getMessage());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_SEARCH_FROM_DATE_CAN_NOT_BE_GREATER_THAN_TO_DATE, "MESSAGE_GLSC_007");
		}
	}

	@Test
	public void testValidateGlossarySearchCriteriaWithInvalidDateFormat(){
		try {
			underTest.validateGlossarySearchCriteria("1", "TestTerm", "PA2619", "10.10.22", "01-10-2022");
		} catch (GPAAGlossaryApplicationException e) {
			assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.PARSING_EXCEPTION, e.getMessages().getMessages().get(0).getMessageKey());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.PARSING_EXCEPTION, e.getMessage());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.PARSING_EXCEPTION, "MESSAGE_GLSC_003");
		}
	}

	@Test
	public void testValidateUpdateTermWithEmptyTermName(){
		TermRestResource termRestResource = new TermRestResource();
		termRestResource.setId(1);
		termRestResource.setDescription("Test Description");
		termRestResource.setDataType(TermDataType.STRING);
		try {
			underTest.validateUpdateTerm(termRestResource);
		} catch (GPAAGlossaryApplicationException e) {
			assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, e.getMessages().getMessages().get(0).getMessageKey());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, e.getMessage());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, "MESSAGE_GLSC_016");
		}
	}

	@Test
	public void testValidateUpdateTermWithEmptyDescription(){
		TermRestResource termRestResource = new TermRestResource();
		termRestResource.setId(1);
		termRestResource.setName("Term Name");
		termRestResource.setDataType(TermDataType.STRING);
		try {
			underTest.validateUpdateTerm(termRestResource);
		} catch (GPAAGlossaryApplicationException e) {
			assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, e.getMessages().getMessages().get(0).getMessageKey());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, e.getMessage());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, "MESSAGE_GLSC_016");
		}
	}

	/*@Test
	public void testValidateUpdateTermWithEmptyTermDataType(){
		TermRestResource termRestResource = new TermRestResource();
		termRestResource.setId(1);
		termRestResource.setName("Term Name");
		termRestResource.setDescription("Term Description");
		try {
			underTest.validateUpdateTerm(termRestResource);
		} catch (GPAAGlossaryApplicationException e) {
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, e.getMessages().getMessages().get(0).getMessageKey());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, e.getMessage());
			assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, "MESSAGE_GLSC_016");
		}
	}*/

	@Test
	public void testValidateUpdateTermWithInvalidTermId(){
		TermRestResource termRestResource = new TermRestResource();
		termRestResource.setId(-1);
		termRestResource.setName("Term Name");
		termRestResource.setDescription("Term Description");
		termRestResource.setDataType(TermDataType.STRING);
		try {
			underTest.validateUpdateTerm(termRestResource);
		} catch (GPAAGlossaryApplicationException e) {
			assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, e.getMessages().getMessages().get(0).getMessageKey());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, e.getMessage());
			//assertEquals(GPAAGlossaryConfigurationMessageKeyConstants.VALIDATION_EXCEPTION_IN_GLOSSARY_UPDATE, "MESSAGE_GLSC_016");
		}
	}
}
