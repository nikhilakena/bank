# Introduction
This API maintains the glossary of an application.

# Build
To build the project locally, standard java17 and maven setup is required.
- Use command ```mvn clean install```

# Deployment
Standard CD pipeline is configured, and it is based on the PITA template.

# Documentation for Pingfederate
https://confluence.int.abnamro.com/pages/viewpage.action?pageId=88709666

# Certificate
To make a call to Pingfederate we need to trust their public certificate. This public certificate is stored in our keyvault as a secret.

# Team
PNC Core team (mail_pnc_core@nl.abnamro.com)