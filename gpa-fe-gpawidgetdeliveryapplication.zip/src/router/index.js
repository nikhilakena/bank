import Vue from 'vue';
import VueRouter from 'vue-router';

import glossaryOverview from '../views/app/gpaaglossaryconfigwidget/modules/glossaryoverview/glossaryOverview.vue';
import viewTermDetails from '../views/app/gpaaglossaryconfigwidget/modules/termview/termDetails';
import createTerm from '../views/app/gpaaglossaryconfigwidget/modules/createterm/createTerm';
import updateTerm from '../views/app/gpaaglossaryconfigwidget/modules/updateterm/updateTerm';
import administrationOverview from '../views/app/gpaaadminconfigwidget/modules/adminoverview/administrationOverview.vue';
import createAdmin from '../views/app/gpaaadminconfigwidget/modules/createadmin/createAdmin.vue';
import viewAdministrationDetails from '../views/app/gpaaadminconfigwidget/modules/adminview/adminDetails.vue';
import updateAdministration from '../views/app/gpaaadminconfigwidget/modules/updateadmin/updateAdmin.vue';
import store from '../store/centraliseStore';


Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    redirect: { name: 'glossaryOverview' },
  },
  {
    path: "/Redirect",
    name: "Redirect",
    component: () =>
        import("../views/Redirect.vue"),

    meta: {
      checkAuth: true
    }
  },
  {
    path: '/glossaryOverview',
    name: 'glossaryOverview',
    component: glossaryOverview,
    props: true,
  },
  {
    path: '/createTerm',
    name: 'createTerm',
    component: createTerm,
    props:true
  },
  {
    path: '/createAdmin',
    name: 'createAdmin',
    component: createAdmin,
    props:true
  },
  {
    path: '/viewTermDetails/:termId',
    name: 'viewTermDetails',
    component: viewTermDetails,
    props: true
  },
  {
    path: '/updateTerm/:termId',
    name: 'updateTerm',
    component: updateTerm,
    props: true
  },
  {
    path: '/administrationOverview',
    name: 'administrationOverview',
    component: administrationOverview,
    props: true
  },
  {
    path: '/viewAdministrationDetails/:adminId',
    name: 'viewAdministrationDetails',
    component: viewAdministrationDetails,
    props: true
  },
  {
    path: '/updateAdministration/:adminId',
    name: 'updateAdministration',
    component: updateAdministration,
    props: true
  }
];

const router = new VueRouter({
  base: "/gpa" ,
  routes,
});


router.beforeEach((to, from, next) => {

  if (to.matched.some((record) => record.meta.checkAuth)) {

    return next();
  }else {

    //  sessionStorage.setItem("returnPath", to.path);
    sessionStorage.setItem("route",window.location.origin+'/gpa/');
    sessionStorage.setItem("returnRoute",to.path);
    const accessToken = store.state.authToken;



    if (accessToken === "" || accessToken === undefined || accessToken === null) {


      const paramsString = window.location.search.substring(1);
      const searchParams = new URLSearchParams(paramsString);
      const code = searchParams.get('code')

      if (code) {
        sessionStorage.setItem("authcode", code);
        //setting the return url from state
        sessionStorage.setItem("returnRoute",atob(searchParams.get("state")));
        const redirectUrl = sessionStorage.getItem('route') + '#/' + 'Redirect';
        window.location.replace(encodeURI(redirectUrl))
      } else {
        sessionStorage.setItem("returnRoute",to.path);

      }
      //  const retr = sessionStorage.getItem("returnRoute");

      return next({ name: "Redirect" });
    }
    // user is logged in
    return next();
  }
  // eslint-disable-next-line no-unreachable
  //return next();
});

export default router;
