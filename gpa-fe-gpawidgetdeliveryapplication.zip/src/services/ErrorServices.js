import JQuery from 'jquery';
import i18n from '../i18n';

window.$ = JQuery;

const ErrorServices = {
    showError(error) {
      window.$('#http-error-id').empty();
      const text = this.gettextCatalog(error);
      console.log(text);
      window.$('#http-error-id')
      .addClass('xx-http-error-message')
      .html("<div class='alert alert-warning'><span class='glyphicon glyphicon-warning-sign' id='errorImage'></span> <h3>" + i18n.t(text) +'</h3></div>');
      window.$('#http-error-id').show();
      window.$('#dbody').removeClass('transparent');
    },
  // eslint-disable-next-line no-unused-vars
    showErrors: function (errors) {
      window.$('#http-error-id').empty();
      window.$('#http-error-id').addClass('xx-http-error-message');
      this.response.data.message.map(function(errors, key) {
        const text = this.gettextCatalog(key);
        window.$('#http-error-id')
        .append("<div class='mcf-notification-container' style='position:relative;'>"
            + "<div class='mcf-notification-icon mcf-notification-icon-warning' style='margin:-6px;position:absolute;'></div>"
            + "<div class='mcf-notification-message-container'><p style='margin-left:35px;'>" + text + '</p></div></div>');

      });
      window.$('#http-error-id').show();
      window.$('#dbody').removeClass('transparent');
    },
    showWarning: function (warnMsg) {
      window.$('#http-error-id').empty();
      const text = this.gettextCatalog(warnMsg);
      window.$('#http-error-id')
      .addClass('xx-http-error-message')
      .html("<div class='mcf-notification-container' style='position:relative;'>"
          + "<div class='mcf-notification-icon mcf-notification-icon-warning' style='margin:-6px;position:absolute;'></div>"
          + "<div class='mcf-notification-message-container'><p style='margin-left:35px;'>" + text + '</p></div></div>');
      window.$('#http-error-id').show();
      window.$('#dbody').removeClass('transparent');
      return true;
    },
    showInfoCustom: function (warnMsg) {
      window.$('#http-error-id').empty();
      const text = this.gettextCatalog(warnMsg);
      window.$('#http-error-id').addClass('xx-http-error-message').html("<div class='alert alert-warning'><h3>" + text +'</h3></div>');
      window.$('#http-error-id').show();
      window.$('#dbody').removeClass('transparent');
      return true;
    },
    isValid : function (d, m, y) {
      return m >= 0 && m < 12 && d > 0 && d <= this.daysInMonth(m, y);
    },
    // m is 0 indexed: 0-11
    daysInMonth(m, y) {
      switch (m) {
        case 1:
          return (y % 4 === 0 && y % 100) || y % 400 === 0 ? 29 : 28;
        case 8:
        case 3:
        case 5:
        case 10:
          return 30;
        default:
          return 31;
      }
    },
    gettextCatalog(object){
      return JSON.stringify(object);
    }

};
export default ErrorServices;
