import axios from 'axios';
import {v4 as uuidv4} from 'uuid';
const baseUrl = process.env.VUE_APP_APIURL;
const baseUrl2 = process.env.VUE_APP_APIURL2;


const interceptedAxiosInstance = axios.create();

interceptedAxiosInstance.interceptors.request.use(
    function(successfulReq) {
        successfulReq.headers.get['Trace-Id'] =  uuidv4();
        successfulReq.withCredentials = false;
        return successfulReq;
    },
    function(error) {
        return Promise.reject(error);
    }
);

interceptedAxiosInstance.interceptors.response.use(
    response => {
        if (response.status === 200 || response.status === 201) {
            return Promise.resolve(response);
        } else {
            return Promise.reject(response);
        }
    },
    error => {
        let redirectUrl;
        if (error.response.status) {
            if (error.response.status == 401) {
                redirectUrl = sessionStorage.getItem('route') + '#/' + 'Redirect' + '?sessionExipred=true';
                window.location.replace(encodeURI(redirectUrl))
            }
            return Promise.reject(error);
        }
    }
);

const headers = {
    'Content-Type': 'application/json',
};

const AppServices = {
    getAllTermsServiceCall(request) {
        const url =baseUrl + 'retrieveall'+'?'+ request.params;
        console.log(url);
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    getTermDetailsById(term,request) {
        const url = baseUrl + term.id+'?'+ request.params;
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    async getTermDetailsByRouteId(routeId,request) {
        const url = baseUrl + routeId+'?'+ request.params;
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    retrieveTerms(request){
        const url =baseUrl +'retrieve?'+ request.params;
        console.log(url);
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    createTermServiceCall(TermRestResource){
        const url =baseUrl;
        console.log(url);
        const data = JSON.stringify(TermRestResource);
        return axios.post(url, data, {
            headers: headers,
        });
    },
    /*
      This function is to set service call for updating term
     */
    updateTermServiceCall:function(TermRestResource){
        const url =baseUrl;
        console.log(url);
        const data = JSON.stringify(TermRestResource);
        console.log(data);
        return axios.put(url, data, {
            headers: headers,
        });
    },
    /*
      This function is to set service call for deleting term
     */
    deleteTermServiceCall:function(term){
        const temp = 'delete/' + term.id;
        console.log(temp);
        const url =baseUrl+temp;
        console.log(url);
        return axios.delete(url, {
            headers: headers,
        });
    },
    retrieveAdmins(queryToSend){
        const url =baseUrl2 +'retrieve?'+ queryToSend.params;
        console.log(url);
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    async getAdminDetailsById(admin,request) {
        const url = baseUrl2 +'read/' +admin+'?'+ request.params;
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    /*
      This function is to set service call for deleting admin
     */
    deleteAdminServiceCall:function(admin){
        const temp = 'delete/' + admin.id;
        console.log(temp);
        const url =baseUrl2+temp;
        console.log(url);
        return axios.delete(url, {
            headers: headers,
        });
    },
    createAdminServiceCall(AdministrationRestResource){
        const temp = 'create';
        const url =baseUrl2+temp;
        console.log(url);
        const data = JSON.stringify(AdministrationRestResource);
        return axios.post(url, data, {
            headers: headers,
        });
    },
    updateAdminServiceCall:function(AdminRestResource){
        const url =baseUrl2 + 'update/';
        console.log(url);
        const data = JSON.stringify(AdminRestResource);
        console.log(data);
        return axios.put(url, data, {
            headers: headers,
        });
    },
};
export default AppServices;
