import { v4 as uuidv4 } from 'uuid'
import axios from 'axios';

export default {


  async fetchIdToken(code) {

    const payload = new URLSearchParams({
    code: code,
    grant_type: 'authorization_code',
    redirect_uri: sessionStorage.getItem('route'),
  });

    console.log('BFF Backend Api :: ',process.env.VUE_APP_BACKEND_SERVER);
 return  axios.post(process.env.VUE_APP_BACKEND_SERVER+'/gpa-glossary-configuration/v1/authencationcheck/checkAccess', payload)

},

  //setting Authorization Request Headers with Access Token
    setHeaderAuthorization  (accessToken ) {
    if (accessToken) {
      axios.defaults.headers.post['Content-Type'] = 'application/json';
      axios.defaults.headers.post['Trace-Id'] =  uuidv4();
      axios.defaults.headers.common.Authorization = `Bearer ${accessToken}`;
      axios.defaults.withCredentials = false;
    } else {
      // specifically unset if no key present.
      delete axios.defaults.headers.common.Authorization;
    }
  },



  async validateToken() {

    return axios.post(process.env.VUE_APP_BACKEND_SERVER+'/gpa-glossary-configuration/v1/authencationcheck/validateToken')


  },

}
