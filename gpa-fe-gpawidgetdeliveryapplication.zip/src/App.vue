<template>
  <div style="width:100%">
    <my-header></my-header>
    <div class="container-fluid">
      <div class="margin-top">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                       <div class="col-md-10 offset-md-1">
                         <keep-alive include="glossaryOverview"> <router-view /> </keep-alive>
                       </div>
                </div>
              </div>
            </div>
      </div>
    </div>
  </div>
</template>
<script>
import Header from './components/Header';
import { mapMutations, mapState } from "vuex";
import Cookies from 'js-cookie';
import DataService from "@/services/data.service";
export default {
  name: 'App',
  components: {
    'my-header': Header,
  },
  computed: {

    ...mapState({

      accessToken: state => state.authToken,


    }),
  },
  async created() {
    // set locale from the session storage if present
    this.$i18n.locale = this.$store.state.currentLocale;
    /* Check if the Access Token is valid else route to Auth Endpoint*/
    if (this.accessToken) {
      await DataService.setHeaderAuthorization(this.accessToken);

      await DataService.validateToken().then((user) => {
        if (user.status !== 200 || user.data.active == false) {
          DataService.setHeaderAuthorization(null);

          const storage = window.localStorage;
          storage.clear();
          Cookies.remove('AUTHSESSION');
        }
        else {
          this.setAuthToken(this.accessToken);
          DataService.setHeaderAuthorization(this.accessToken);
        }

      }).catch((err) => {

        // token exchange error, fail graceful
        // redirect to homepage.
        console.log('data service validatetoken ', err);
        DataService.setHeaderAuthorization(null);
        DataService.setHeaderSMSession(null);
        Cookies.remove('AUTHSESSION');
        const storage = window.localStorage;
        storage.clear();

      });


    }
  },
  methods: {
    ...mapMutations({

      setAuthToken: 'setAuthToken',


    }),
  }
};
</script>


<style lang="css">
@import "./style/abnapp.css";
@import "./style/_alerts.scss";
</style>

