import utils from '@/scripts/utils';

export default{
    data(){ /* TODO document why this method 'data' is empty */ },
    methods:{
        /*
        this method is used for validating facet mantadory fileds
    */
        validateFacetsMandatoryFields(index, term, event) {
            if (term.dataType === 'BOOLEAN') {
                if (this.isMandatorySelected(term)) {
                    this.validateBooleanTypeSelected(index, term);
                }
            }
            if (term.dataType === 'DATE' || term.dataType === 'TIME' || term.dataType === 'DATETIME') {
                if (this.isMandatorySelected(term)) {
                    term.validated = true;
                    this.activeTermIndex = index + 1;
                } else {
                    term.validated = false;
                }
            }
            if (term.dataType === 'STRING') {
                if (this.isMandatorySelected(term)) {
                    this.validateStringTypeSelected(index, term, event);
                }
            }
            if (term.dataType === 'NUMERIC') {
                if (this.isMandatorySelected(term)) {
                    this.validateNumericTypeSelected(index, term);
                }
            }
        },

        isMandatorySelected(term) {
            if (utils.isEmpty(term.mandatory)) {
                term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                term.showMessage = true;
                term.validated = false;
                return false;
            } else {
                term.showMessage = false;
                return true;
            }
        },

        /*
          This method is used to validate Boolean data type validations
        */
        validateBooleanTypeSelected(index, term) {
            if (!utils.isEmpty(term.facetValue)) {
                if (term.isSpecialCharPresentInFacetValue) {
                    term.errorMsgLabel = 'ALERT_SPECIAL_CHAR_IN_CREATE';
                    term.showMessage = true;
                    return false;
                } else if (term.facetValue.split(',').length === 2
                    && !utils.isEmpty(term.facetValue.split(',')[0])
                    && !utils.isEmpty(term.facetValue.split(',')[1])
                    && term.facetValue.split(',')[0] !== ''
                    && term.facetValue.split(',')[1] !== ''
                    && term.facetValue.split(',')[0].toUpperCase().trim() !== term.facetValue.split(',')[1].toUpperCase().trim()) {

                    term.facets = [];
                    term.facets.push({ 'facetType': term.facetType, 'facetValue': term.facetValue });
                    term.validated = true;
                    this.activeTermIndex = index + 1;
                } else if (term.facetValue.split(',').length > 2) {
                    term.validated = false;
                    term.errorMsgLabel = 'LABEL_BOOLEAN_VALUE_MAX_LENGTH_ERROR';
                    term.showMessage = true;
                    return false;
                } else {
                    term.validated = false;
                    term.errorMsgLabel = 'LABEL_BOOLEAN_VALUE_MAX_LENGTH_ERROR';
                    term.showMessage = true;
                    return false;
                }
            } else {
                term.validated = false;
                term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                term.showMessage = true;
                return false;
            }
        },

        /*
          This method is used to validate String data type validations
        */
        validateStringTypeSelected(index, term, event) {
            if (!utils.isEmpty(term.facetCategory)) {//!angular.isUndefined(term.facetCategory)
                if (term.facetCategory === 'List') {
                    this.validateStringEnum(index, term);
                } else if (term.facetCategory === 'Single Value') {
                    this.validateStringSingle(index, term, event);
                } else if (term.facetCategory === 'Range') {
                    this.validateStringRange(index, term);
                }
                /*term.validated=true;
                $scope.activeTermIndex=index+1;*/
            } else {
                term.validated = false;
                term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                term.showMessage = true;
                return false;
            }
        },

        /*
          this function is used for validating String -Enum values
        */
        validateStringEnum(index, term) {
            if (!utils.isEmpty(term.facetCategory) && term.facetCategory !== '') {
                this.validateListTypeSelected(index, term);
            } else {
                term.validated = false;
                return false;
            }
        },
        /*
          This method is used to validate List type in String data type validations
        */
        validateListTypeSelected(index, term) {
            //var tempValue = angular.copy(term.facetValue);
            const tempValue = term.facetValue;
            this.formatListValues(tempValue);
            if (this.facetValueList.length < 1) {
                term.errorMsgLabel = 'LABEL_INVALID_LIST_INPUT';
                term.showMessage = true;
                return false;
            }
            if (!utils.isEmpty(term.facetValue)) {
                if (term.isSpecialCharPresentInFacetValue) {
                    term.errorMsgLabel = 'ALERT_SPECIAL_CHAR_IN_CREATE';
                    term.showMessage = true;
                    return false;
                }
                if (this.hasDuplicates(this.facetValueList)) {
                    term.validated = false;
                    term.errorMsgLabel = 'LABEL_DUPLICATE_LIST_VALUES';
                    term.showMessage = true;
                    return false;
                } else {
                    term.validated = true;
                    term.showMessage = false;
                    term.facets = [];
                    term.facets.push({ 'facetType': term.facetType, 'facetValue': term.facetValue });
                    this.activeTermIndex = index + 1;
                }
            } else {
                term.validated = false;
                term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                term.showMessage = true;
                return false;
            }
        },
        /*
          Formatting list values
        */
        formatListValues(tempValue) {
            this.facetValueList = [];
            let counter = 0;
            for (let i = 0; i < tempValue.length; i++) {
                if (tempValue.charAt(i) === ',') {
                    counter++;
                }
            }
            for (let j = 0; j < counter + 1; j++) {
                tempValue.split(',')[j];
                if (tempValue.split(',')[j] !== '') {
                    this.facetValueList.push(tempValue.split(',')[j]);
                }
            }
        },
        /*
         This function is used to check duplicates value in list-String
        */
        hasDuplicates(array) {
            const valuesSoFar = Object.create(null);
            for (let i = 0; i < array.length; ++i) {
                const value = array[i];
                if (isNaN(value)) {
                    if (value.toUpperCase().trim() in valuesSoFar) {
                        return true;
                    }
                } else {
                    if (value.trim() in valuesSoFar) {
                        return true;
                    }
                }
                if (isNaN(value)) {
                    valuesSoFar[value.toUpperCase().trim()] = true;
                } else {
                    valuesSoFar[value.trim()] = true;
                }
            }
            return false;
        },
        /*
          this function is used for validating String -Single values
        */
        validateStringSingle(index, term, event) {
            for (let i = 0; i < term.facets.length; i++) {
                if (term.facets[i].showFlag) {
                    if (term.facets[i].facetType === 'Maximum length' || term.facets[i].facetType === 'Length') {
                        this.stringSingleMandateField = true;
                        term.validated = false;
                        this.validateMaxMinLength(index, term, event);
                        if (term.validated) {
                            this.activeTermIndex = index + 1;
                        }
                        return false;
                    } else {
                        term.validated = false;
                        term.errorMsgLabel = 'LABEL_MAXLENGTH_LENGTH_MANDATE';
                        term.showMessage = true;
                        this.stringSingleMandateField = false;
                        if (!this.stringSingleMandateField && i === term.facets.length - 1) {
                            return false;
                        }
                    }
                }
            }
            if (this.stringSingleMandateField) {
                this.validateMaxMinLength(index, term, event);
            }
        },
        /*
          this function is used for validating String -Range values
        */
        validateStringRange(index, term) {
            for (let i = 0; i < term.facets.length; i++) {
                if (term.facets[i].showFlag) {
                    if (term.facets[i].facetType === 'MaxInclusive' || term.facets[i].facetType === 'MaxExclusive') {
                        this.stringRangeMandateField = true;
                        term.showMessage = false;
                        term.validated = false;
                        this.validateMaxMinExcInc(index, term);
                        if (term.validated) {
                            this.activeTermIndex = index + 1;
                        }
                        return false;
                    } else {
                        term.validated = false;
                        term.errorMsgLabel = 'LABEL_MAX_INC_EXC_MANDATE';
                        term.showMessage = true;
                        this.stringRangeMandateField = false;
                        if (!this.stringSingleMandateField && i === term.facets.length - 1) {
                            return false;
                        }
                    }
                }
            }
            if (this.stringRangeMandateField) {
                this.validateMaxMinExcInc(index, term);
            }
        },
        /*
          this function is used to validate max/min inc/exc value for range type
        */
        validateMaxMinExcInc(index, term) {
            let maxIncIndex = null;
            let maxExcIndex = null;
            let minIncIndex = null;
            let minExcIndex = null;
            term.validated = false;

            for (let i = 0; i < term.facets.length; i++) {
                if (term.facets[i].facetType === 'MinInclusive') {
                    minIncIndex = i;
                }
                if (term.facets[i].facetType === 'MaxInclusive') {
                    maxIncIndex = i;
                }
                if (term.facets[i].facetType === 'MinExclusive') {
                    minExcIndex = i;
                }
                if (term.facets[i].facetType === 'MaxExclusive') {
                    maxExcIndex = i;
                }
            }
            for (let j = 0; j < term.facets.length; j++) {
                if (term.facets[j].showFlag === true
                    && (utils.isEmpty(term.facets[j].facetType) || utils.isEmpty(term.facets[j].facetValue))) {
                    term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
            }
            if (minIncIndex !== null &&
                !utils.isEmpty(term.facets[minIncIndex].facetValue)
                && term.facets[minIncIndex].facetValue !== ''
                && term.facets[minIncIndex].facetValue <= 0) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (maxIncIndex !== null &&
                !utils.isEmpty(term.facets[maxIncIndex].facetValue)
                && term.facets[maxIncIndex].facetValue !== ''
                && term.facets[maxIncIndex].facetValue <= 0) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (minExcIndex !== null &&
                !utils.isEmpty(term.facets[minExcIndex].facetValue)
                && term.facets[minExcIndex].facetValue !== ''
                && term.facets[minExcIndex].facetValue <= 0) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (maxExcIndex !== null &&
                !utils.isEmpty(term.facets[maxExcIndex].facetValue)
                && term.facets[maxExcIndex].facetValue !== ''
                && term.facets[maxExcIndex].facetValue <= 0) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (minIncIndex != null &&
                !utils.isEmpty(term.facets[minIncIndex].facetValue)
                && term.facets[minIncIndex].facetValue !== ''
                && term.facets[minIncIndex].facetValue > 0) {
                term.validated = true;
            }
            if (maxIncIndex != null &&
                !utils.isEmpty(term.facets[maxIncIndex].facetValue)
                && term.facets[maxIncIndex].facetValue !== ''
                && term.facets[maxIncIndex].facetValue > 0) {
                term.validated = true;
            }
            if (minExcIndex != null &&
                !utils.isEmpty(term.facets[minExcIndex].facetValue)
                && term.facets[minExcIndex].facetValue !== ''
                && term.facets[minExcIndex].facetValue > 0) {
                term.validated = true;
            }
            if (maxExcIndex != null &&
                !utils.isEmpty(term.facets[maxExcIndex].facetValue)
                && term.facets[maxExcIndex].facetValue !== ''
                && term.facets[maxExcIndex].facetValue > 0) {
                term.validated = true;
            }
            if (minIncIndex != null &&
                !utils.isEmpty(term.facets[minIncIndex].facetValue)
                && term.facets[minIncIndex].facetValue !== ''
                && isNaN(term.facets[minIncIndex].facetValue)) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (maxIncIndex != null &&
                !utils.isEmpty(term.facets[maxIncIndex].facetValue)
                && term.facets[maxIncIndex].facetValue !== ''
                && isNaN(term.facets[maxIncIndex].facetValue)) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (minExcIndex != null &&
                !utils.isEmpty(term.facets[minExcIndex].facetValue)
                && term.facets[minExcIndex].facetValue !== ''
                && isNaN(term.facets[minExcIndex].facetValue)) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (maxExcIndex != null &&
                !utils.isEmpty(term.facets[maxExcIndex].facetValue)
                && term.facets[maxExcIndex].facetValue !== ''
                && isNaN(term.facets[maxExcIndex].facetValue)) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (maxIncIndex != null &&
                !utils.isEmpty(term.facets[maxIncIndex].facetValue)
                && term.facets[maxIncIndex].facetValue !== ''
                && term.facets[maxIncIndex].facetValue === 0) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (maxExcIndex != null &&
                !utils.isEmpty(term.facets[maxExcIndex].facetValue)
                && term.facets[maxExcIndex].facetValue !== ''
                && term.facets[maxExcIndex].facetValue === 0) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (minIncIndex != null
                && (maxIncIndex != null || maxExcIndex != null)) {
                if (maxIncIndex != null
                    && this.checkGreaterOrEqual(term.facets[minIncIndex].facetValue, term.facets[maxIncIndex].facetValue)
                ) {
                    term.errorMsgLabel = 'LABEL_MAX_MIN_INC_EXC_CHECK';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
                if (maxExcIndex != null
                    && this.checkGreaterOrEqual(term.facets[minIncIndex].facetValue, term.facets[maxExcIndex].facetValue)
                ) {
                    term.errorMsgLabel = 'LABEL_MAX_MIN_INC_EXC_CHECK';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
            }
            if (maxIncIndex != null
                && (minIncIndex != null || minExcIndex != null)) {
                if (minIncIndex != null
                    && this.checkGreaterOrEqual(term.facets[minIncIndex].facetValue, term.facets[maxIncIndex].facetValue)
                ) {
                    term.errorMsgLabel = 'LABEL_MAX_MIN_INC_EXC_CHECK';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
                if (minExcIndex != null
                    && this.checkGreaterOrEqual(term.facets[minExcIndex].facetValue, term.facets[maxIncIndex].facetValue)
                ) {
                    term.errorMsgLabel = 'LABEL_MAX_MIN_INC_EXC_CHECK';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
            }
            if (minExcIndex != null
                && (maxIncIndex != null || maxExcIndex != null)) {
                if (maxIncIndex != null
                    && this.checkGreaterOrEqual(term.facets[minExcIndex].facetValue, term.facets[maxIncIndex].facetValue)
                ) {
                    term.errorMsgLabel = 'LABEL_MAX_MIN_INC_EXC_CHECK';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
                if (maxExcIndex != null
                    && this.checkGreaterOrEqual(term.facets[minExcIndex].facetValue, term.facets[maxExcIndex].facetValue)
                ) {
                    term.errorMsgLabel = 'LABEL_MAX_MIN_INC_EXC_CHECK';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
            }
            if (maxExcIndex != null
                && (minIncIndex != null || minExcIndex != null)) {
                if (minIncIndex != null
                    && this.checkGreaterOrEqual(term.facets[minIncIndex].facetValue, term.facets[maxExcIndex].facetValue)
                ) {
                    term.errorMsgLabel = 'LABEL_MAX_MIN_INC_EXC_CHECK';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
                if (minExcIndex != null
                    && this.checkGreaterOrEqual(term.facets[minExcIndex].facetValue, term.facets[maxExcIndex].facetValue)
                ) {
                    term.errorMsgLabel = 'LABEL_MAX_MIN_INC_EXC_CHECK';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
            }
        },
        /*
          check greater or equal value
        */
        checkGreaterOrEqual(value1, value2) {
            if (Number(value1) > Number(value2)
                || Number(value1) === Number(value2)) {
                return true;
            }
        },
        /*
          This method is used to validate Numeric data type validations
        */
        validateNumericTypeSelected(index, term) {
            if (!utils.isEmpty(term.facetCategory)) {//!angular.isUndefined(term.facetCategory)
                if (term.facetCategory === 'List') {
                    this.validateNumericEnum(index, term);
                } else if (term.facetCategory === 'Single Value') {
                    this.validateNumericSingle(index, term);
                } else if (term.facetCategory === 'Range') {
                    this.validateNumericRange(index, term);
                }
                /*term.validated=true;
                $scope.activeTermIndex=index+1;*/
            } else {
                term.validated = false;
                term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                term.showMessage = true;
                return false;
            }
        },
        /*
          this function is used for validating Numeric -Enum values
        */
        validateNumericEnum(index, term) {
            if (!utils.isEmpty(term.facetCategory) && term.facetCategory !== '') {
                //validateListTypeSelected(index,term);
                this.validateNumericListTypeSelected(index, term);
            } else {
                term.validated = false;
                return false;
            }
        },
        /*
          This method is used to validate List type in Numeric data type validations
        */
        validateNumericListTypeSelected(index, term) {
            //var tempValue = angular.copy(term.facetValue);
            const tempValue = term.facetValue;
            this.formatListValues(tempValue);
            if (this.facetValueList.length < 1) {
                term.errorMsgLabel = 'LABEL_INVALID_LIST_INPUT';
                term.showMessage = true;
                return false;
            }
            // to check wether values given in in put are numeric or not.
            for (let i = 0; i < this.facetValueList.length; i++) {
                if (isNaN(this.facetValueList[i])) {
                    term.errorMsgLabel = 'LABEL_NUMERIC_LIST_VALUE';
                    term.showMessage = true;
                    return false;
                }
            }
            if (!utils.isEmpty(term.facetValue)) {
                if (term.isSpecialCharPresentInFacetValue) {
                    term.errorMsgLabel = 'ALERT_SPECIAL_CHAR_IN_CREATE';
                    term.showMessage = true;
                    return false;
                }
                if (this.hasDuplicates(this.facetValueList)) {
                    term.validated = false;
                    term.errorMsgLabel = 'LABEL_DUPLICATE_LIST_VALUES';
                    term.showMessage = true;
                    return false;
                } else {
                    term.validated = true;
                    term.showMessage = false;
                    term.facets = [];
                    term.facets.push({ 'facetType': term.facetType, 'facetValue': term.facetValue });
                    this.activeTermIndex = index + 1;
                }
            } else {
                term.validated = false;
                term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                term.showMessage = true;
                return false;
            }
        },
        /*
          this function is used for validating Numeric -Single values
        */
        validateNumericSingle(index, term) {
            for (let i = 0; i < term.facets.length; i++) {
                if (term.facets[i].showFlag) {
                    if (term.facets[i].facetType === 'Maximum length'
                        || term.facets[i].facetType === 'Length'
                        || term.facets[i].facetType === 'Total Digits') {
                        this.stringSingleMandateField = true;
                        term.validated = false;
                        this.validateMaxMinLength(index, term);
                        if (term.validated) {
                            this.activeTermIndex = index + 1;
                        }
                        return false;
                    } else {
                        term.validated = false;
                        term.errorMsgLabel = 'LABEL_MAXLENGTH_LENGTH_DIGIT_MANDATE';
                        term.showMessage = true;
                        this.stringSingleMandateField = false;
                        if (!this.stringSingleMandateField && i === term.facets.length - 1) {
                            return false;
                        }
                    }
                }
            }
            if (this.stringSingleMandateField) {
                this.validateMaxMinLength(index, term);
            }
        },
        /*
          this function is used for validating max-min , length, pattern selection and length check
        */
        validateMaxMinLength(index, term ) {//event
            let maxIndex = null;
            let minIndex = null;
            let lengthIndex = null;
            let patternIndex = null;
            term.validated = false;

            for (let i = 0; i < term.facets.length; i++) {
                if (term.facets[i].facetType === 'Maximum length') {
                    maxIndex = i;
                }
                if (term.facets[i].facetType === 'Minimum length') {
                    minIndex = i;
                }
                if (term.facets[i].facetType === 'Length') {
                    lengthIndex = i;
                }
                if (term.facets[i].facetType === 'Pattern') {
                    patternIndex = i;
                }
                if (term.facets[i].facetType === 'Fractions' || term.facets[i].facetType === 'Total Digits') {
                    this.validateFractionAndTotalDigits(index, term);
                    return false;
                }
            }
            for (let j = 0; j < term.facets.length; j++) {
                if (term.facets[j].showFlag === true
                    && (utils.isEmpty(term.facets[j].facetType) || utils.isEmpty(term.facets[j].facetValue))) {
                    term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
            }
            if (maxIndex != null) {
                // to prevent 'e, - , +' in input
                if (this.invalidInputValue(term.facets[maxIndex].facetValue, term)
                    || this.checkNegativeValue(term.facets[maxIndex].facetValue, term)) {
                    return false;
                }
            }
            if (minIndex != null) {
                // to prevent 'e, - , +' in input
                if (this.invalidInputValue(term.facets[minIndex].facetValue, term)
                    || this.checkNegativeValue(term.facets[minIndex].facetValue, term)) {
                    return false;
                }
            }
            if (lengthIndex != null) {
                // to prevent 'e, - , +' in input
                if (this.invalidInputValue(term.facets[lengthIndex].facetValue, term)
                    || this.checkNegativeValue(term.facets[lengthIndex].facetValue, term)) {
                    return false;
                }
            }
            if (patternIndex != null) {
                // to prevent 'e, - , +' in input
                if (this.invalidInputValue(term.facets[patternIndex].facetValue, term)
                    || this.checkNegativeValue(term.facets[patternIndex].facetValue, term)) {
                    return false;
                }
            }
            if (lengthIndex != null) {
                if (!isNaN(term.facets[lengthIndex].facetValue)
                    && (term.facets[lengthIndex].facetValue) % 1 === 0) {
                    term.validated = true;
                    term.showMessage = false;
                } else {
                    term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
            }
            if (lengthIndex != null) {
                if (term.facets[lengthIndex].facetValue === 0) {
                    term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                    term.showMessage = true;
                    return false;
                }
            }
            if (maxIndex != null && (utils.isEmpty(term.facets[maxIndex].facetValue) || term.facets[maxIndex].facetValue === '')) {
                term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (maxIndex != null && (!utils.isEmpty(term.facets[maxIndex].facetValue) && term.facets[maxIndex].facetValue === 0)) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (minIndex != null && (utils.isEmpty(term.facets[minIndex].facetValue) || term.facets[minIndex].facetValue === '')) {
                term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (minIndex != null && (!utils.isEmpty(term.facets[minIndex].facetValue) && term.facets[minIndex].facetValue === 0)) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (maxIndex !== null &&
                !utils.isEmpty(term.facets[maxIndex].facetValue)
                && term.facets[maxIndex].facetValue !== ''
                && !isNaN(term.facets[maxIndex].facetValue)
                && (term.facets[maxIndex].facetValue) % 1 === 0) {
                term.validated = true;
                term.showMessage = false;
            }
            if (maxIndex !== null &&
                !utils.isEmpty(term.facets[maxIndex].facetValue)
                && term.facets[maxIndex].facetValue !== ''
                && !isNaN(term.facets[maxIndex].facetValue)
                && (term.facets[maxIndex].facetValue) % 1 !== 0) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (maxIndex !== null &&
                !utils.isEmpty(term.facets[maxIndex].facetValue)
                && term.facets[maxIndex].facetValue !== ''
                && isNaN(term.facets[maxIndex].facetValue)) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (minIndex !== null &&
                !utils.isEmpty(term.facets[minIndex].facetValue)
                && term.facets[minIndex].facetValue !== ''
                && !isNaN(term.facets[minIndex].facetValue)
                && (term.facets[minIndex].facetValue) % 1 === 0) {
                term.validated = true;
                term.showMessage = false;
            }
            if (minIndex !== null &&
                !utils.isEmpty(term.facets[minIndex].facetValue)
                && term.facets[minIndex].facetValue !== ''
                && !isNaN(term.facets[minIndex].facetValue)
                && (term.facets[minIndex].facetValue) % 1 !== 0) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (minIndex !== null &&
                !utils.isEmpty(term.facets[minIndex].facetValue)
                && term.facets[minIndex].facetValue !== ''
                && isNaN(term.facets[minIndex].facetValue)) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (maxIndex !== null && minIndex !== null) {
                if (utils.isEmpty(term.facets[maxIndex].facetValue)
                    || utils.isEmpty(term.facets[minIndex].facetValue)
                    || term.facets[maxIndex].facetValue === ''
                    || term.facets[minIndex].facetValue === '') {
                    term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                    term.showMessage = true;
                    term.validated = false;
                }
                if (isNaN(term.facets[maxIndex].facetValue) || isNaN(term.facets[minIndex].facetValue)) {
                    term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
                if ((Number(term.facets[maxIndex].facetValue) < Number(term.facets[minIndex].facetValue))
                    || (Number(term.facets[maxIndex].facetValue) === Number(term.facets[minIndex].facetValue))) {
                    term.errorMsgLabel = 'LABEL_MAX_MIN_LENGTH';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
            }
            if (lengthIndex !== null
                && !utils.isEmpty(term.facets[lengthIndex].facetValue)
                && term.facets[lengthIndex].facetValue !== ''
                && patternIndex !== null
                && !utils.isEmpty(term.facets[patternIndex].facetValue)
                && term.facets[patternIndex].facetValue !== '') {
                term.validated = true;
                term.showMessage = false;
            }
            if (lengthIndex != null && patternIndex == null
                && !utils.isEmpty(term.facets[lengthIndex].facetValue)
                && term.facets[lengthIndex].facetValue !== '') {
                term.validated = true;
                term.showMessage = false;
            }
            if (patternIndex != null && !utils.isEmpty(term.facets[patternIndex].facetValue) && term.facets[patternIndex].facetValue !== '') {
                term.validated = true;
                term.showMessage = false;
            }
        },

        /*
          this function is used for validating total digits / fractions
        */
        validateFractionAndTotalDigits(index, term) {
            let fractionsIndex = null;
            let totalDigitsIndex = null;
            term.validated = false;
            for (let j = 0; j < term.facets.length; j++) {
                if (term.facets[j].showFlag === true
                    && (utils.isEmpty(term.facets[j].facetType) || utils.isEmpty(term.facets[j].facetValue))) {
                    term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                    term.showMessage = true;
                    term.validated = false;
                    return false;
                }
            }
            for (let i = 0; i < term.facets.length; i++) {
                if (term.facets[i].facetType === 'Fractions') {
                    fractionsIndex = i;
                }
                if (term.facets[i].facetType === 'Total Digits') {
                    totalDigitsIndex = i;
                }
            }
            if (fractionsIndex !== null && utils.isEmpty(term.facets[fractionsIndex].facetValue)) {
                term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (totalDigitsIndex !== null && utils.isEmpty(term.facets[totalDigitsIndex].facetValue)) {
                term.errorMsgLabel = 'ERROR_MANDATORY_FACETS_DTLS';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (fractionsIndex !== null
                && !utils.isEmpty(term.facets[fractionsIndex].facetValue)
                && isNaN(term.facets[fractionsIndex].facetValue)) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (fractionsIndex !== null) {
                if (term.facets[fractionsIndex].facetValue < 1) {
                    term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                    term.showMessage = true;
                    return false;
                }
            }
            if (totalDigitsIndex !== null) {
                if (term.facets[totalDigitsIndex].facetValue < 1) {
                    term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                    term.showMessage = true;
                    return false;
                }
            }
            if (fractionsIndex !== null
                && !utils.isEmpty(term.facets[fractionsIndex].facetValue)
                && !isNaN(term.facets[fractionsIndex].facetValue)
                && (term.facets[fractionsIndex].facetValue) % 1 === 0) {
                term.showMessage = false;
                term.validated = true;
            }
            if (fractionsIndex !== null
                && !utils.isEmpty(term.facets[fractionsIndex].facetValue)
                && !isNaN(term.facets[fractionsIndex].facetValue)
                && (term.facets[fractionsIndex].facetValue) % 1 !== 0) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (totalDigitsIndex !== null
                && !utils.isEmpty(term.facets[totalDigitsIndex].facetValue)
                && isNaN(term.facets[totalDigitsIndex].facetValue)) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (totalDigitsIndex !== null) {
                if (term.facets[totalDigitsIndex].facetValue === 0) {
                    term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                    term.showMessage = true;
                    return false;
                }
            }
            if (totalDigitsIndex !== null
                && !utils.isEmpty(term.facets[totalDigitsIndex].facetValue)
                && !isNaN(term.facets[totalDigitsIndex].facetValue)
                && (term.facets[totalDigitsIndex].facetValue) % 1 === 0) {
                term.showMessage = false;
                term.validated = true;
            }
            if (totalDigitsIndex != null
                && !utils.isEmpty(term.facets[totalDigitsIndex].facetValue)
                && !isNaN(term.facets[totalDigitsIndex].facetValue)
                && (term.facets[totalDigitsIndex].facetValue) % 1 !== 0) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
            if (totalDigitsIndex !== null && fractionsIndex !== null
                && this.checkGreaterOrEqual(term.facets[fractionsIndex].facetValue, term.facets[totalDigitsIndex].facetValue)
            ) {
                term.errorMsgLabel = 'LABEL_TOTAL_DIGITS_GREATER_THAN_FRACTION';
                term.showMessage = true;
                term.validated = false;
                return false;
            }
        },
        /*
          This method is used to check if input contains invalid character 'e'. which are allowed in input text & also not validated in NaN() method.
        */
        invalidInputValue(facetValue, term) {
            if (facetValue.indexOf('e') !== -1) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return true;
            }
        },
        /*
         this function is used for checking negative value
        */
        checkNegativeValue(facetValue, term) {
            if (facetValue < 1) {
                term.errorMsgLabel = 'LABEL_FACET_VALUE_NUMERIC';
                term.showMessage = true;
                term.validated = false;
                return true;
            }
        },
        /*
          this function is used for validating Numeric -Range values
        */
        validateNumericRange(index, term) {
            for (let i = 0; i < term.facets.length; i++) {
                if (term.facets[i].showFlag) {
                    if (term.facets[i].facetType === 'MaxInclusive' || term.facets[i].facetType === 'MaxExclusive') {
                        this.numericRangeMandateField = true;
                        term.showMessage = false;
                        term.validated = false;
                        this.validateMaxMinExcInc(index, term);
                        if (term.validated) {
                            this.activeTermIndex = index + 1;
                        }
                        return false;
                    } else {
                        term.validated = false;
                        term.errorMsgLabel = 'LABEL_MAX_INC_EXC_MANDATE';
                        term.showMessage = true;
                        this.numericRangeMandateField = false;
                        if (!this.numericRangeMandateField && i === term.facets.length - 1) {
                            return false;
                        }
                    }
                }
            }
            if (this.numericRangeMandateField) {
                this.validateMaxMinExcInc(index, term);
            }
        },

        checkDuplicateTerms(selectedTerms) {
            let index;
            this.selectedTermNameList = [];
            for (index = 0; index < selectedTerms.length; index++) {
                this.selectedTermNameList.push(selectedTerms[index].name);
            }

            if (this.hasDuplicates(this.selectedTermNameList)) {
                this.duplicateTermsPresent = true;
                this.showMessage = true;
                return false;
            }
        },
    }
};
