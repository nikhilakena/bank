import Cookies from 'js-cookie';

import Vue from 'vue';
import Vuex from 'vuex';
import VuexPersistence from 'vuex-persist';


Vue.use(Vuex);


const vuexCookie = new VuexPersistence({
  key: 'AUTHSESSION',
  reducer: (state) => ({ authToken: state.authToken, msecAuthToken : state.msecAuthToken} ),
  restoreState: (key) => Cookies.getJSON(key),
  saveState: (key, state) =>
      Cookies.set(key,  state, {
        secure: true
      }),

  removeItem: key => Cookies.remove(key),

})

const vuexLocal = new VuexPersistence({
  storage: window.sessionStorage,
});


const store = new Vuex.Store({
  modules: {
  },

  state: {
    searchModel : {
        termId: '',
        termName: '',
        createdBy: '',
        createdTimeStamp: '',
        createdFrom:'',
        createdTo:'',
    },
    glossaryOverviewFilteredData: '',
    authToken: "",
  },

  getters: {
    searchModel: state => state.searchModel,
    glossaryOverviewFilteredData: state => state.glossaryOverviewFilteredData,
    authToken: state => state.authToken,
  },

  mutations: {
    updateFilterData(state, value) {
      state.searchModel = value;
    },
    setAuthToken(state, value) {
      state.authToken=value;
    },
    updateGlossaryOverviewFilteredData(state, value) {
      state.glossaryOverviewFilteredData = value;
    },
  },

  actions: {
    updateFilterData(context, value) {
      context.commit('updateFilterData', value);
    },
    updateGlossaryOverviewFilteredData(context, value) {
      context.commit('updateGlossaryOverviewFilteredData', value);
    },
  },
  plugins: [vuexCookie.plugin,vuexLocal.plugin],
});
export default store;
