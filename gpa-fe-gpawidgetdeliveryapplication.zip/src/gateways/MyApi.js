import axios from 'axios';
export default axios.create({
  baseURL: 'http://vm00005620.nl.eu.abnamro.com:14886/',
  timeout: 5000,
//   withCredentials: true,
  // crossDomain: true,
  // headers: {
  //   'Content-Type': 'application/json',
  //   'Access-Control-Allow-Headers' : 'http://localhost:8080/'
  // }
});
