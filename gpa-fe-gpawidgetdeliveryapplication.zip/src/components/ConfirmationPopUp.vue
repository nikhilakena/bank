<template>
  <div class="popUp">
    <div>
      <h3 v-if="selectedAction==='backButton'" class="md-title">{{$t('ALERT_ON_BACK')}}
      </h3>
      <h3 v-if="selectedAction==='saveButton'" class="md-title">{{$t('ALERT_CREATE_TERM')}}
      </h3>
      <h3 v-if="selectedAction==='updateButton'" class="md-title">{{$t('ALERT_UPDATE_TERM')}}
      </h3>
      <h3 v-if="selectedAction==='deleteButton'" class="md-title">{{$t('ALERT_DELETE_TERM')}}
      </h3>
      <h3 v-if="selectedAction==='deleteAdminButton'" class="md-title">{{$t('ALERT_DELETE_ADMIN')}}
      </h3>
      <h3 v-if="selectedAction==='saveAdminButton'" class="md-title">{{$t('ALERT_CREATE_ADMIN')}}
      </h3>
      <h3 v-if="selectedAction==='deleteTermTabButton'" class="md-title">{{$t('ALERT_DELETE_TERM_HEAD')
      + ' ' + obj.name +' ' +$t('ALERT_DELETE_TERM_TRAIL')}}
      </h3>
    </div>
    <div>
      <p class="para" v-if="selectedAction==='backButton'">
        {{$t('ALERT_ON_BACK_MESSAGE')}}
      </p>
      <p class="para" v-if="selectedAction==='saveButton'">
        {{$t('ALERT_CREATE_TERM_MESSAGE')}}
      </p>
      <p class="para" v-if="selectedAction==='updateButton'">
        {{$t('ALERT_UPDATE_TERM_MESSAGE')}}
      </p>
      <p class="para" v-if="selectedAction==='deleteButton'">
        {{$t('ALERT_DELETE_TERM_MESSAGE')}}
      </p>
      <p class="para" v-if="selectedAction==='deleteAdminButton'">
        {{$t('ALERT_DELETE_ADMIN_MESSAGE')}}
      </p>
      <p class="para" v-if="selectedAction==='saveAdminButton'">
        {{$t('ALERT_CREATE_ADMIN_MESSAGE')}}
      </p>
      <p class="para" v-if="selectedAction==='deleteTermTabButton'">
        {{$t('ALERT_ADMIN_DELETE_TERM_MESSAGE')}}
      </p>
    </div>
    <br>
    <div class="modal-footer row"
         ng-style="currentLanguage=='nl' ? {'margin-left':'17px'} : {'margin-left':'-2px'}">
      <div>
        <button  type="button"
                @click="cancel()" class="myButton">
          Cancel
        </button>
      </div>
      <div>
        <button  type="button"
                @click="validatePopUpConfirm()" class="myButton">
          Ok
        </button>
      </div>
    </div>
  </div>
</template>
<script>
export default{
  name:'ConfirmationPopUp',
  props:['actionPopUp','cancel','validatePopUpConfirm','selectedAction','obj'],
  data(){
    return{
      action: this.actionPopUp,
    };
  }
};
</script>
<style scoped>
.popUp {
  position: relative;
  z-index: 101;
  background-color: #f5f5f5;
  width: auto;
  box-shadow: 0 5px 15px rgb(0 0 0 / 50%);
  flex-direction: column;
  padding: 24px;
  overflow: auto;
  box-sizing: border-box;
}

.modal-footer{
  padding-left: 90px
}
.md-title {
  font-size: 20px;
  font-weight: 500;
  letter-spacing: .005em;
  color:#005e5d;
}
.para {
  display: block;
  margin-block-start: 1em;
  margin-block-end: 1em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
}
.myButton{
  transition: color 0.15s ease-in-out 0s, background-color 0.15s ease-in-out 0s, border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
}
</style>

