<template>
  <transition name="fade">
    <div id="notify" v-if="notificationType !== ''" class="mb-1">
      <aab-notification
        :type="notificationType"
        :close-icon="closeNotification"
        id="aab-notification-custom-id"
        >{{ $t(displayMessage) }} {{ displayMessage2 }}
        {{ $t(displayMessage3) }}</aab-notification
      >
    </div>
  </transition>
</template>

<script>
import $ from 'jquery';
export default {
  name: 'Notify',
  props: [
    'notificationType',
    'displayMessage',
    'closeNotification',
    'displayMessage2',
    'displayMessage3',
  ],
  watch: {
    displayMessage: function (val) {
      if(val === "LABEL_ORDER_ENTRY_SUCCESS") { return; }

      if (val) {
        $('html, body').animate(
          {
            scrollTop: 0,
          },
          {
            duration: 1000,
          }
        );
      }
    },
  },
};
</script>
