<template v-show='tabsData.length>0'>
  <v-card >
    <ConfirmationPopUpTemplate
        v-if="confirmActionPopup"
        :actionPopUp="action"
        :cancel="cancel"
        :validatePopUpConfirm="validatePopUpConfirm"
        :selectedAction="selectedAction"
        :obj="deleteTermTabObj"
    />
    <v-tabs v-model="tab" background-color="#e0e0e0">
      <v-tab v-for="(term,index) in tabsData" :key="index" active="true" color="black">
        <div style="text-align: left;" :id="index">
          <span class="termName" style="position: relative;width: 60%;text-transform: none;">{{term.name}}</span>

          <span style="margin-right: 0px;  display: inline-block;">
            <span class="glyphicon glyphicon-trash"
                  @click.prevent="deleteTermTab($event,term);$event.preventDefault();$event.stopPropagation();">
            </span>
          </span>
          <span class="glyphicon glyphicon-ok-circle"
                v-if='term.validated===true'
                style="margin-right: 5px;  display: inline-block;">
          </span>

          <span v-if='term.showMessage===true' style="margin-right: 5px;  display: inline-block;">
            <span
                class="glyphicon glyphicon-warning-sign">
            </span>
          </span>




        </div>
      </v-tab>
    </v-tabs>

    <v-tabs-items v-model="tab">
      <v-tab-item v-for="(term,tabindex) in tabsData" :key="tabindex">
        <v-card flat>
          <v-card-text class="md-padding">
            <div class="tab-text">
              <div v-show="term.showMessage">
                <notify
                    :notificationType="msgType"
                    :displayMessage="displayMsg"
                    :closeNotification="closeNotify"
                    @clear="notify($event, $event)"
                    :title="toolMsg"
                />
              </div>
              <br>

              <div class="row">
                <div class="col-xs-3 ocf-label-static">
                  <p>{{$t("LABEL_TERM_NAME")}}</p>
                </div>
                <div class="col-xs-3 description" style="margin-bottom: 10px">{{term.name}}</div>
              </div>
              <div class="row">
                <div class="col-xs-3 ocf-label-static">
                  <p>{{$t("LABEL_TERM_DESCR")}}</p>
                </div>
                <div class="col-xs-3 description" style="margin-bottom: 10px">{{term.description}}</div>
              </div>
              <div class="row">
                <div class="col-xs-3 ocf-label-static">
                  <p>{{$t("LABEL_TERM_DATA_TYPE")}}</p>
                </div>
                <div class="col-xs-3 description" style="margin-bottom: 10px">{{$t(term.dataType)}}</div><!--| translate-->
              </div>
              <div class="row">
                <div class="col-xs-3 ocf-label-static">
                  <p><span>{{$t("LABEL_MANDATORY")}}</span>
                    <span style="color :#FF6347;">*</span></p>
                </div>
                <div class="col-xs-3">
                  <div>
                    <input class="radioClass" type="radio" :name=tabindex
                           value="term.mandatory" @click="updateMandatoryFlag(term,0)"
                           :checked="(term.mandatory == true)">
                    <label style="vertical-align: bottom;">Yes</label>
                  </div>
                  <div>
                    <input class="radioClass" type="radio" :name=tabindex
                           value="term.mandatory" @click="updateMandatoryFlag(term,1)"
                           :checked="(term.mandatory == false)">
                    <label style="vertical-align: bottom;">No</label>
                  </div>
                </div>
              </div>
              <br/>
              <div class="row" style="margin-top: 5px"
                   v-if="term.dataType ==='STRING' || term.dataType ==='BOOLEAN' || term.dataType ==='NUMERIC' ">
                <div class="ocf-i-text topx` collapse" data-collapse="collapse" role="tooltip" style="display: none;">
                  <div class="ocf-i-text-inner">
                    <button aria-label="Close" class="ocf-btn-icon glyphicon ocf-icon-close" type="button">
                      <span class="sr-only">Close</span>
                    </button>
                    <aab-info-popover>
                      <h3>{{ $t('LABEL_FACET_INFO_HEADING') }}</h3>
                      <p v-if="term.dataType ==='STRING' ">
                        {{ $t('LABEL_FACET_INFO_DETAIL_STRING') }}</p>
                      <p v-if="term.dataType ==='BOOLEAN' ">
                        {{ $t('LABEL_FACET_INFO_DETAIL_BOOLEAN') }}</p>
                      <p v-if="term.dataType ==='NUMERIC' ">
                        {{$t('LABEL_FACET_INFO_DETAIL_NUMERIC')}}</p>
                    </aab-info-popover>
                  </div>
                </div>

                <div class="col-xs-3 ocf-label-static">
                  <p ><span>{{$t('LABEL_FACET_CATEGORY')}} </span>
                    <span style="color :#FF6347;"
                          v-if="term.dataType ==='STRING' || term.dataType ==='BOOLEAN' || term.dataType ==='NUMERIC' ">*</span>
                    <button type="button"
                            class="ocf-btn-icon glyphicon glyphicon-info-sign"
                            aria-label="more information" >
                    </button>
                  </p>
                </div>
                <!-- facet Catagory drop doon for String -->
                <div class="col-xs-3 description"
                     v-if="term.dataType ==='STRING' || term.dataType ==='NUMERIC'"
                     style="margin-bottom: 10px">
                  <select
                      v-model="term.facetCategory"
                      class="form-control" style="width: 200px;"
                      @change="facetCategoryChange($event,term);"
                      @select="$emit('select', $event.target.facetCategory)">
                    <option v-for="(facetCategory , i) in facetCategoryList"
                            :key="`facetCategory${i}`"
                            :value="facetCategory">{{facetCategory}}</option>
                  </select>
                </div>

                <!-- facet Catagory drop down for Boolean -->
                <div class="col-xs-3 description"
                     v-if="term.dataType ==='BOOLEAN'"
                     style="margin-bottom: 10px">
                  <select :v-model="term.facetCategory=facetCategoryListForBoolean[0]"
                          class="form-control" style="width: 200px;">
                    <option disabled value="">Please Select</option>
                    <option v-for="(facetCategory , i) in facetCategoryListForBoolean"
                            :key="`facetCategory${i}`"
                            :value="facetCategory">
                      {{facetCategory}}
                    </option>
                  </select>
                </div>

                <!-- Info icon for all data type -->
                <div class="col-xs-1" style="margin-left: -20px; margin-top: 5px;">

                </div>
              </div>
              <br/>
              <div v-for="(facet,index) in term.facets" :key="index"
                   v-show="term.facetCategory === 'Single Value' || term.facetCategory === 'Range'">
                <div
                    :class="{custom:!facet.showFlag}"
                    v-show="facet.showFlag === true" class="row" :id="'id_'+''+tabindex+''+index"><!--  v-cloak-->
                  <div class="col-xs-3 ocf-label-static">
                    <p ><span>{{$t('LABEL_FACET_TYPE')}}</span>
                      <span style="color :#FF6347;">*</span> </p>
                  </div>
                  <div class="col-xs-3" style="margin-bottom: 10px">

                    <select
                        name="singleValueFacetType"
                        class="form-control" style="width: 200px;"
                        v-model="term.facets[index].facetType"
                        @click="getValidfacetTypesOnClick($event, index, term);"
                        @change="$event.stopPropagation(),getValidfacetTypesOnChange($event, index+1, term)">
                      <option v-for="(availableFacet , i) in term.facets[index].availableFacets"
                              :key="`availableFacet${i}`"
                              :value="availableFacet">
                        {{availableFacet}}
                      </option>
                    </select>
                  </div>
                  <div class="col-xs-2 ocf-label-static">
                    <p><span>{{$t('LABEL_FACET_VALUE')}}</span>
                      <span style="color :#FF6347;">*</span></p>
                  </div>
                  <div class="col-xs-3">
                    <input  name="length"
                            type="text"
                            v-model="term.facets[index].facetValue"
                            class="form-control" />
                    <span class="help-block" v-show="term.facets[index].isSpecialCharPresentInFacetValue">
                      <span class="glyphicon glyphicon-warning-sign"></span>
                      <span>{{$t('LABEL_SPECIAL_CHARACTER')}}</span>
                      {{term.facets[index].specialCharPresentInFacetValue}}
                      <span>{{$t('LABEL_NOT_ALLOWED')}}  </span>
                    </span>
                  </div>
                  <div class="col-xs-1">
                      <span class="glyphicon ocf-icon-add"
                            @click.prevent="addMorefacetTypeValues(term,index,tabindex)"
                            style="cursor: pointer;"
                            v-if="term.facets[index+1] && term.facets[index+1].availableFacets.length>0"
                            :id="'plusicon'+index">
                      </span>
                    <span class="glyphicon glyphicon-trash "
                          v-if="index !==0 && term.facets[index].facetType !==null && term.facets[index].facetType !=='' "
                          style="position: relative; float: right;margin-right: 2%;margin-top: 10%;cursor: pointer;"
                          @click="removefacetTypeValues($event,term,index); ">
                      </span>
                  </div>
                </div>
                <br/>
              </div>

              <div class="row" v-show="term.facetCategory === 'List'">
                <div class="col-xs-3 ocf-label-static" >
                  <p ><span>{{$t('LABEL_FACET_TYPE')}}</span>
                    <span style="color :#FF6347;">*</span></p>
                </div>
                <div class="col-xs-3" style="margin-bottom: 10px">
                  <select  name="enumFacetType"
                           :disabled="true"
                           :v-model="term.facetType=enumFacets[0]"
                           class="form-control" style="width: 200px;">
                    <option v-for="(enumFacetType , i) in enumFacets"
                            :key="`enumFacetType${i}`"
                            :value="enumFacetType">
                      {{enumFacetType}}
                    </option>
                  </select>
                </div>
                <div class="col-xs-2 ocf-label-static"
                     style="margin-left: -5%;width:20%">
                  <p ><span>{{$t('LABEL_FACET_VALUE')}}</span>
                    <span style="color :#FF6347;">*</span>
                  </p>
                </div>
                <div class="col-xs-4">
                    <textarea  name="enumeration" v-model="term.facetValue"
                               class="form-control"
                               @change="checkEnumValue(term)"/>
                  <span class="help-block" v-if="term.isSpecialCharPresentInFacetValue">
                      <span class="glyphicon glyphicon-warning-sign"></span>
                      <span>{{$t('LABEL_SPECIAL_CHARACTER')}}</span>
                      {{term.specialCharPresentInFacetValue}}
                      <span>{{$t('LABEL_NOT_ALLOWED')}}  </span>
                    </span>
                </div>
              </div>

              <br/>
              <br/>
              <div class="row btn-group" >
                <div class="col-xs-12">
                  <button  type="submit"
                           class="btn btn-primary"
                           :disabled="term.validated===true"
                           @click.prevent="validateTermFacets(tabindex,term,$event)"
                  >
                    <span>{{$t('LABEL_VALIDATE_NEXT')}}</span>
                  </button>
                </div>
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-tab-item>
    </v-tabs-items>
  </v-card>
</template>
<script>
import ConfirmationPopUpTemplate from '@/components/ConfirmationPopUp';
import Notify from '../components/Notify';
import utils from '../scripts/utils';
import common from "@/mixins/common";
export default {
  name:'updateTermViewPanel',
  props:['actionTab','tabsData'],
  components: { Notify , ConfirmationPopUpTemplate },
  mixins: [common] ,
  data(){
    return{
      actionTabFlag: this.actionTab,
      tab: 'null',
      availableFacetList:'',
      msgType: '',
      toolMsg: '',
      closeNotify: '',
      errorMsg: '',
      displayMsg: '',

      facetCategoryList : ['Single Value', 'Range', 'List'],
      facetCategoryListForBoolean : ['List'],
      rangeFacets : ['Minimum Inclusive', 'Minimum Exclusive', 'Maximum Inclusive', 'Maximum Exclusive'],
      enumFacets : ['List values'],
      ngChangeTrigger : false,

      stringSingleValueCombination : [
        ['Maximum length', 'Minimum length', 'Pattern'],
        ['Length', 'Pattern']
      ],

      stringRangeCombination : [
        ['MinInclusive', 'MaxInclusive'],
        ['MinInclusive', 'MaxExclusive'],
        ['MinExclusive', 'MaxInclusive'],
        ['MinExclusive', 'MaxExclusive']
      ],

      numericSingleValueCombination : [
        ['Maximum length', 'Minimum length', 'Pattern'],
        ['Length', 'Pattern'],
        ['Total Digits', 'Fractions']
      ],

      numericRangeCombination : [
        ['MinInclusive', 'MaxInclusive'],
        ['MinInclusive', 'MaxExclusive'],
        ['MinExclusive', 'MaxInclusive'],
        ['MinExclusive', 'MaxExclusive']
      ],
      action: '',
      confirmActionPopup: false,
      selectedAction: '',
      deleteTermTabObj:'',
      selectedIdForDelete:'',
    };
  },
  methods:{

    updateMandatoryFlag(term, index) {
      if (index=== 0) {
        term.mandatory = true;
      } else {
        term.mandatory = false;
      }
    },

    notify(type, msg, close = true) {
      this.msgType = type;
      this.displayMsg = msg !== '' ? msg : '';
      this.toolMsg = msg;
      this.closeNotify = close;
    },
    confirmPopUp() {
      this.confirmActionPopup = true;
    },
    cancel() {
      this.confirmActionPopup = false;
    },
    validatePopUpConfirm() {
      this.confirmActionPopup = false;
      this.deleteTermTabFunction();
    },
    deleteTermTabFunction() {
      this.showConfirmDeleteTerm();
    },
    deleteTermTab(ev, term){
      console.log('inside delete operation function'+ ev + term);
      this.selectedAction = 'deleteTermTabButton';
      this.deleteTermTabObj = term;
      this.selectedIdForDelete = term;
      this.confirmPopUp();
    },

    isEmpty(value) {
      if (value === undefined || value === null || value === '') {
        return true;
      }
    },
    facetCategoryChange($event,obj){
      if (!this.isEmpty(obj.facetValue)) {
        obj.facetValue = '';
      }
      if (!this.isEmpty(obj.facets) && obj.facets.length>0) {
        obj.facets[0].facetValue = '';
      }
      if (obj.validated) {
        obj.validated = false;
      }
      if (!this.isEmpty(obj.facets) && obj.facets.length > 0) {
        obj.facets.splice(0, obj.facets.length - 1);
      }
      this.getValidfacetTypesOnClick($event, 0, obj);
    },

    getValidfacetTypesOnClick($event, index, obj) {
      const allpossibleCombinations = this.getValidCombination(obj);
      this.getValidfacetTypes($event, index, obj, allpossibleCombinations);
    },
    getValidCombination(term) {
      if (term.dataType === 'STRING' && term.facetCategory === 'Single Value') {
        return this.stringSingleValueCombination;
      }
      if (term.dataType === 'STRING' && term.facetCategory === 'Range') {
        return this.stringRangeCombination;
      }
      if (term.dataType === 'NUMERIC' && term.facetCategory === 'Single Value') {
        return this.numericSingleValueCombination;
      }
      if (term.dataType === 'NUMERIC' && term.facetCategory === 'Range') {
        return this.numericRangeCombination;
      }
    },

    getValidfacetTypes(_$event, index, obj, allpossibleCombinations) {
      this.singleValueFacets = [];
      let temp = [];

      if (utils.isEmpty(obj.facets) || obj.facets.length < 1) {
        temp = [];
        obj.facets = [];
        obj.facets[index] = {};
      } else {
        for (let i = 0; i < obj.facets.length; i++) {
          temp.push(obj.facets[i].facetType);
        }
        if (obj.facets[index] === undefined) {
          obj.facets[index] = {};
        }
      }
      obj.facets[index].availableFacets = this.getStringSingleValueDropdown(allpossibleCombinations, temp, index);
      obj.facets[index].showFlag = true;
    },

    getStringSingleValueDropdown(allpossibleCombinations, selectedValues, index) {
      if (index > 0) {
        const fileredSelectedValues = [];
        for (let m = 0; m < index; m++) {
          fileredSelectedValues[m] = selectedValues[m];
        }
        const fileredStringSingleValueCombination = [];
        let k = -1;
        for (let i = 0; i < allpossibleCombinations.length; i++) {
          let flag = true;
          for (let j = 0; j < fileredSelectedValues.length; j++) {
            if (allpossibleCombinations[i].indexOf(fileredSelectedValues[j]) === -1) {
              flag = false;
            }
          }
          if (flag) {
            k++;
            fileredStringSingleValueCombination[k] = allpossibleCombinations[i];
          }
        }
        const allowedsubFacets = this.getAllStringSubFacets(fileredStringSingleValueCombination);
        const uniqueAllowedsubFacets = this.getUniqueArray(allowedsubFacets);
        return this.removeSelectedFacetsFromAllowed(uniqueAllowedsubFacets, fileredSelectedValues);
      } else {
        if (!this.isEmpty(allpossibleCombinations)) {
          const allSubFacets = this.getAllStringSubFacets(allpossibleCombinations);
          const uniqueItems = this.getUniqueArray(allSubFacets);
          return uniqueItems;
        }
      }
    },
    getUniqueArray(allValues) {
      const distinctValues = [];
      for (let i = 0; i < allValues.length; i++) {
        const str = allValues[i];
        if (distinctValues.indexOf(str) === -1) {
          distinctValues.push(str);
        }
      }
      return distinctValues;
    },

    removeSelectedFacetsFromAllowed(uniqueAllowedsubFacets, fileredSelectedValues) {
      const subFacets = [];
      let k = -1;
      for (let i = 0; i < uniqueAllowedsubFacets.length; i++) {
        let flag = false;
        for (let j = 0; j < fileredSelectedValues.length; j++) {
          if (fileredSelectedValues[j] === uniqueAllowedsubFacets[i]) {
            flag = true;
          }
        }
        if (!flag) {
          k++;
          subFacets[k] = uniqueAllowedsubFacets[i];
        }
      }
      return subFacets;
    },

    getAllStringSubFacets(stringSingleValueCombination) {
      if (!this.isEmpty(stringSingleValueCombination)) {
        const subFacets = [];
        let k = -1;
        for (let i = 0; i < stringSingleValueCombination.length; i++) {
          for (let j = 0; j < stringSingleValueCombination[i].length; j++) {
            k++;
            subFacets[k] = stringSingleValueCombination[i][j];
          }
        }
        return subFacets;
      }
    },

    addMorefacetTypeValues(term, index, tabindex) {

      if (this.isEmpty(term.facets[index + 1].facetValue)) {
        term.facets[index + 1].showFlag = true;
        term.facets[index + 1].facetValue = '';
        console.log('id_'+(index+1));
        document.getElementById('id_'+''+tabindex+''+(index+1)).style.display='block';
      }
      if (term.validated) {
        term.validated = false;
      }

    },

    removeItemWithValue(arr, value) {
      const arrlist = arr.filter(item => item !== value);
      return arrlist;
    },

    removefacetTypeValues($event, term, index) {
      term.facets.splice(index, 1);
      for (let i = 0; i < term.facets.length; i++) {
        this.getValidfacetTypesOnClick($event, i, term);
        this.ngChangeTrigger = false;
      }
      if (term.facets.length > 1) {
        term.facets[term.facets.length - 1].showFlag = false;
      } else {
        this.getValidfacetTypesOnChange($event, 1, term);
        this.ngChangeTrigger = false;
      }
      if (term.validated) {
        term.validated = false;
      }
    },















    hasDuplicates(array) {
      const valuesSoFar = Object.create(null);
      for (let i = 0; i < array.length; ++i) {
        const value = array[i];
        if (isNaN(value)) {
          if (value.toUpperCase().trim() in valuesSoFar) {
            return true;
          }
        } else {
          if (value.trim() in valuesSoFar) {
            return true;
          }
        }
        if (isNaN(value)) {
          valuesSoFar[value.toUpperCase().trim()] = true;
        } else {
          valuesSoFar[value.trim()] = true;
        }
      }
      return false;
    },



    checkGreaterOrEqual(value1, value2) {
      if (Number(value1) > Number(value2)
          || Number(value1) === Number(value2)) {
        return true;
      }
    },

    isSpecialCharacterPresentInFacetValue(input, term) {
      input.isSpecialCharPresentInFacetValue = false;
      if (term.validated === true) {
        term.validated = false;
      }
      if (null !== input && this.validateUnicode(input.facetValue) !== '') {
        input.isSpecialCharPresentInFacetValue = true;
        input.specialCharPresentInFacetValue = this.validateUnicode(input.facetValue);
        return true;
      }
      return false;
    },







    showConfirmDeleteTerm() {//ev, term
      console.warn(this.selectedIdForDelete);
      const index = this.tabsData.indexOf(this.selectedIdForDelete);
      for (let i = 0; i < this.tabsData.length; i++) {
        if (this.tabsData[index].id === this.tabsData[i].id) {
          this.tabsData[i].display = true;
          this.tabsData[i].selected = false;
          this.tabsData[i].mandatory = '';
          this.tabsData[i].facetCategory = '';
          this.tabsData[i].facetType = '';
          this.tabsData[i].facetValue = '';
          this.tabsData[i].validated = null;
          this.tabsData[i].errorMsgLabel = '';
          this.tabsData[i].showMessage = false;
        }
      }
      this.tabsData.splice(index, 1);
      this.showMessage = false;
      this.allTermsSelected = false;
      this.duplicateTermsPresent = false;
      this.checkDuplicateTerms(this.tabsData); // check wether duplicate terms present in admin or not.
      // checkToDeleteCharacters(); // To check deletion of character
    },


    checkForSpecialCharacters(_index, $event, _maxlength, inputData) {
      if ($event.target.innerHTML === 'undefined' || $event.target.innerHTML === '') {
        inputData = inputData + String.fromCharCode($event.keyCode);
      }
      else {
        inputData = $event.target.innerHTML + String.fromCharCode($event.keyCode);
      }
      return inputData;
    },

    checkToDeleteCharacters(_index,$event,_maxlength,inputData){
      if($event.target.innerHTML !== 'undefined' && $event.target.innerHTML !==''){
        inputData= $event.target.innerHTML;
      }
      return inputData;
    },
    checkEnumValue(term) {
      term.isSpecialCharPresentInFacetValue = false;
      if (term.validated === true) {
        term.validated = false;
      }
      if (this.isEmpty(term.facetValue)) {
        term.validated = false;
      } else {
        if (null !== term && term.facetValue.length > 0 && this.validateUnicode(term.facetValue) !== '') {
          term.isSpecialCharPresentInFacetValue = true;
          term.specialCharPresentInFacetValue = this.validateUnicode(term.facetValue);
          return true;
        }
        return false;
      }
    },

    validateTermFacets(index, term, event) {
      this.validateFacetsMandatoryFields(index, term, event);
      if(term.errorMsgLabel){
        this.notify('', '');
        this.notify('warning',term.errorMsgLabel,true);
      }
      this.$emit('childTermsData',term);
    },

    getValidfacetTypesOnChange($event, index, obj) {
      if (obj.validated) {
        obj.validated = false;
      }
      if (index === 1) {
        for (let i = 0; i < obj.facets.length; i++) {
          if (obj.facets[i].showFlag === true) {
            obj.facets[i].facetValue = '';
          }
        }
      } else {
        obj.facets[index - 1].facetValue = '';
      }

      if (!utils.isEmpty(obj.facets) && obj.facets.length > 0) {
        obj.facets.splice(index + 1, obj.facets.length - 1);
      }
      const allpossibleCombinations = this.getValidCombination(obj);
      this.getValidfacetTypes($event, index, obj, allpossibleCombinations);

      this.ngChangeTrigger = true;
      if (obj.facets[index] !== undefined) {
        if (index > 0) {
          obj.facets[index].showFlag = false;
        } else {
          obj.facets[index].showFlag = true;
        }
      }
    },






  }
};
</script>
<style>
.custom{
  display:none;
}
.termName{
  width:180px;
  white-space: nowrap;
  overflow: hidden !important;
  text-overflow: ellipsis;
}
.greenBackground{
  background-color: green;
}
.redBackground{
  background-color: red;
}

</style>
