<template>
     <header id="header">
      <!--  <div class="container-fluid-nomax ocf-header">
        <div class="container-fluid-custom">
            <div class="container-fluid">
                <span class="ocf-brand ocf-cutout">
                </span>
                <div class="ocf-header-right">
                    <div class="btn-group hidden-xs hidden-xxs" data-dropdown data-dropdown-toggle>
                        <select class="btn btn-link ocf-dropdown btn-smallest-width"  v-model="$i18n.locale">
                            <option value="nl">NL</option>
                            <option value="en">EN</option>
                        </select>
                    </div>
                </div>

            </div>
            </div>
                <div class="navbar-container">
                <nav class="navbar navbar-default navbar-main">
                </nav>
                <div class="navbar-hamburger">
                    <button type="button" class="btn-nav-expander hidden-lg hidden-md">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="small">Menu</span>
                    </button>
                </div>
            </div>
        </div> -->
        <div  class="container-fluid-nomax ocf-header">
					<div  class="container-fluid-custom">
							<div  class="container-fluid">
								<a v-on:click="backToHome">
									<span class="ocf-brand ocf-cutout"></span>
								</a>
								<div  class="ocf-header-right">
										<div class="col-md-4">
											<aab-icon
													slot="icon"
													:svg="sy_tools_globe"
													size="3"
													color="Green 150">
											</aab-icon>
										</div>
										<div  data-dropdown="" data-dropdown-toggle="" class="btn-group">
											<select  v-model="$i18n.locale" class="btn btn-link ocf-dropdown btn-smallest-width">
												<!-- <option  value="nl">NL</option>
                        <option  value="en">EN</option> -->
												<option v-for="(lang, i) in languages" :key="`Lang${i}`" :value="lang">{{ lang.toUpperCase() }}</option>
											</select>
										</div>
								</div>
							</div>
					</div>
					<!-- begin navigation -->
					<div class="navbar-container"  ng-controller="menuCtrl">
						<nav class="navbar navbar-default navbar-main">
							<div class="container-fluid" style="height: auto;">
								<!-- The actual items -->
								<ul class="nav navbar-nav">
									<li ng-class="{'active': page == 'glossaryOverview'}" ui-sref-active="active"
											ng-click="redirectToGlossaryConfig()">
										<a href="#/glossaryOverview" ui-sref="about"><span>{{$t("LABEL_GLOSSARY_OVERVIEW_SCREEN_NAME")}}</span></a>
									</li>
									<li ng-class="{'active': page == 'administrationOverview'}" ui-sref-active="active"
											ng-click="redirectToAdminConfig()">
										<a href="#/administrationOverview" ui-sref="releasenotes"><span>{{$t("LABEL_ADMIN_OVERVIEW_SCREEN_NAME")}}</span></a>
									</li>
								</ul>
							</div>
						</nav>
					</div>
					<!-- end navigation -->
					<!--<div  class="navbar-container">
						<nav  class="navbar navbar-default navbar-main"></nav>
						<div  class="navbar-hamburger">
							<button  type="button" class="btn-nav-expander hidden-lg hidden-md">
								<span  class="sr-only">Toggle navigation</span>
								<span  class="icon-bar"></span>
								<span  class="icon-bar"></span>
								<span  class="icon-bar"></span>
								<span  class="small">Menu</span>
							</button>
						</div>
					</div>-->
				</div>
    </header>
</template>

<script>
import '../style/header.scss';
import { sy_tools_globe as sy_tools_globe } from '@aab/sc-aab-icon-set';

export default {
  name: 'Header',
  data (){
    return { languages: ['en', 'nl'],sy_tools_globe };
  },
	methods: {
		backToHome() {
			this.$router.push('/');
		},
	},
};
</script>
