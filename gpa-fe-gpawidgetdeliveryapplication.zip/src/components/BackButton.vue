<template>
  <div>
    <aab-button fluid style-type="secondary">
      <button :aria-label="$t('LABEL_BACK')"
              @click="back()"
              type="submit">
        <aab-icon
            slot="icon"
            :svg="sy_arrow_arrow_left"
            size="3"
            color="black"
        /> <span style="vertical-align: super">{{$t('LABEL_BACK')}}</span>
      </button>
    </aab-button>
  </div>
</template>
<script>

import { sy_arrow_arrow_left as sy_arrow_arrow_left} from '@aab/sc-aab-icon-set';

export default {
  name:'BackButton',
  props:['actionBackButton','back'],
  data(){
    return{
      sy_arrow_arrow_left,
      backAction: this.actionBackButton,
    };
  },
};
</script>
