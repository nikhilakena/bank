import moment from 'moment';

export default {
  formatDate: function(value) {
    let newVal = value;
    newVal = moment(newVal).format('DD.MM.YYYY');
    return newVal;
  },
  formatDateTime: function(value) {
    if (value) {
      return moment(value).format('DD.MM.yyyy HH:mm:ss');
    }
  },
  formatLang: function(input, lang) {
    let newInp = input;
    if (lang === 'en') {
      if (newInp.indexOf('mrt') > -1) {
        newInp = newInp.replace('mrt', 'mar');
      }
      if (newInp.indexOf('mei') > -1) {
        newInp = newInp.replace('mei', 'may');
      }
      if (newInp.indexOf('okt') > -1) {
        newInp = newInp.replace('okt', 'oct');
      }
    }
    return newInp;
  },
};
