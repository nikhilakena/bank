<template>
  <div>
    <div id="overlay" :class="{ active1: enableSpinner }"></div>
<!--    <fade-loader :color='"black"' v-if="enableSpinner" style="position:fixed;top:50%; left:50%"></fade-loader>-->
    <div id="notification-block">
      <notify
        :notificationType="messageType"
        :displayMessage="displayMessage"
        :closeNotification="closeNotify"
      />
      <div></div>
      <div id="notification-block-unauthenticated">
      <notifyunauthorized
        :notificationType="messageTypeAuth"
        :displayMessage="displayMessageAuth"
        :closeNotification="closeNotifyAuth"
      />
      <div></div>
    </div>
    </div>
    <div v-if="showRedirectLoginLabel">
      <span v-if="showSessionExpiredLabel">Session Expired. </span> Redirecting to Login page.
    </div>
  </div>
</template>
<style scoped>
#overlay {
  position: fixed;
  opacity: 0;
  transition: all 200ms;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: -100;
}
#overlay.active1 {
  opacity: 1;
  z-index: 100;
}
</style>

<script>
import { mapMutations } from 'vuex';
import DataService from "@/services/data.service";
import Cookies from 'js-cookie';
import Notify from '../components/NotificationComponent.vue';


export default {
  name: 'Redirect',
    components: {
    notify: Notify,
    notifyunauthorized: Notify
  },

  data() {
    return {
      showSessionExpiredLabel: false,
      showRedirectLoginLabel: true,
      messageType: '',
      displayMessage: '',
      closeNotify: false,
      messageTypeAuth: '',
      displayMessageAuth: '',
      closeNotifyAuth: false,
      enableSpinner : false
    }
  },
  mounted() {
    const paramsString = window.location.search.substring(1);
    const searchParams = new URLSearchParams(paramsString);
    const sessionExipred = searchParams.get('sessionExipred');
    console.log(searchParams, sessionExipred);

    if (sessionExipred != null && sessionExipred == 'true') {
      this.showSessionExpiredLabel = true;
    }
  },
  async created() {
    const code = sessionStorage.getItem('authcode');
    if (code) {
      try {
        this.showRedirectLoginLabel = false;
        this.enableSpinner = true;
        await DataService.fetchIdToken(code)
          .then((accessTokens) => {
            console.log('Redirect Backend Api :: ', accessTokens.data);
            this.setAuthToken(accessTokens.data);
            DataService.setHeaderAuthorization(accessTokens.data);

            //return to the original requested page
            const retr = sessionStorage.getItem("returnRoute");

            return this.$router.replace({ path: retr });

          }).catch((error) => {
            // token exchange error, fail graceful
            this.enableSpinner = false;
            console.log('data service error', error,error.response);
            error && error.response && error.response.data
            ? this.notify("warning", error.response.data.errors[0].code)
            : this.notify("warning", "LABEL_ERROR");
            // redirect to homepage.
            // return this.goHome();
          })

      } catch (error) {
        if (process.env.NODE_ENV === 'development') {
          return this.goHome();
        }
      } finally {
        // sessionStorage.removeItem('route');
        sessionStorage.removeItem('authcode');
        // sessionStorage.removeItem('returnRoute');
      }
    }
    else {
      Cookies.remove('AUTHSESSION');
      this.setAuthToken(null);

      const returnUrl = btoa(sessionStorage.getItem("returnRoute"));
      const loginUrl = `${process.env.VUE_APP_AUTH_SERVER}/as/authorization.oauth2?scope=openid profile email roles corpid&redirect_uri=` + sessionStorage.getItem('route') + `&state=` + returnUrl + `&client_id=${process.env.VUE_APP_CLIENT_ID}&response_type=code`;
      window.location.replace(encodeURI(loginUrl))

    }

  },
  methods: {
    ...mapMutations({
      setAuthToken: 'setAuthToken',

    }),
    goHome: async function (path = '/') {
      return this.$router.replace(path);
    },
    /**
     * emptyNotify- initializes notification component
     */
    emptyNotify() {
      this.messageType = '';
      this.displayMessage = '';
      this.messageTypeAuth = '';
      this.displayMessageAuth = '';
      return new Promise((resolve) => {
        resolve();
      });
    },

    /** notify - sets the props of notify component
     * @param msgType - type of message
     * @param displayMsg - message to be displayed
     */
    notify(msgType, displayMsg) {
      this.emptyNotify().then(() => {
        this.messageType = msgType;
        this.displayMessage = displayMsg;
      });
    },

    /** notifyAuth - sets the props of notifyunauthorized component
     * @param msgType - type of message
     * @param displayMsg - message to be displayed
     */
    notifyAuth(msgType, displayMsg) {
      this.emptyNotify().then(() => {
        this.messageTypeAuth = msgType;
        this.displayMessageAuth = displayMsg;
      });
    },

  },
}

</script>
