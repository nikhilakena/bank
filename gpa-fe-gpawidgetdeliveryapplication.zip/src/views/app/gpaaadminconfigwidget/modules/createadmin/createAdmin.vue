<template>
  <div class="panel panel-default" id="createAdminConfigDiv">
    <div class="panel-heading" style="padding-top: 5px;">
      <BackButton
          :actionBackButton="backAction"
          :back="back"
      />
      <h2 class="panel-title"><span> {{ $t('LABEL_CREATE_ADMIN_SCREEN_NAME') }}</span></h2>
    </div>
    <div class="panel-body">
      <notify
          :notificationType="msgType"
          :displayMessage="displayMsg"
          :closeNotification="closeNotify"
          @clear="notify($event, $event)"
          :title="toolMsg"
      />
      <aab-spinner :size="12" v-if="enableSpinner"></aab-spinner>

      <ConfirmationPopUpTemplate
          v-if="confirmActionPopup"
          :actionPopUp="action"
          :cancel="cancel"
          :validatePopUpConfirm="validatePopUpConfirm"
          :selectedAction="selectedAction"
      />
      <div id="createBlock">
        <form class="form-horizontal v-pristine v-valid" name="createform">
          <!---->
          <div>
            <h4 class="panel-title" style="color: #608e28;">
              <span>{{ $t("LABEL_GENERAL_ADMIN_DETAILS") }}</span>
              <br />
              <br />
            </h4>
          </div>
          <div class="bs-component">
            <!--v-scope v-isolate-scope-->
            <div class="well">
              <div class="row">
                <div class="col-xs-6 ocf-label-static">
                  <span>{{ $t("LABEL_ADMIN_NAME") }}</span>&nbsp;
                  <span style="color: #ff6347;">*</span>
                </div>
                <div class="col-xs-5" style="border: none;">
                  <input
                      class="w120 form-control"
                      tabindex="1"
                      type="text"
                      maxlength="150"
                      id="adminName"
                      on-keyup-fn="handleKeypress"
                      v-model="admin.name"
                      name="adminName"
                  />
                </div>
              </div>
              <br />
              <br />
              <div class="row">
                <div class="col-xs-6 ocf-label-static"><span>{{ $t("LABEL_ADMIN_DESCR") }}</span>&nbsp;<span style="color: #ff6347;">*</span></div>
                <div class="col-xs-5">
                  <textarea class="w120 form-control" rows="2" tabindex="2"
                            name="description" spellcheck="false" type="text"
                            maxlength="300" id="description" on-keyup-fn="handleKeypress" v-model="admin.description" />

                  <span class="help-block" v-if="admin.isSpecialCharPresentInAdminDesc">
                                        <span class="glyphicon glyphicon-warning-sign"></span>
                                        <span>{{ $t("LABEL_SPECIAL_CHARACTER") }}</span>
                                        admin.specialCharPresentInAdminDesc
                                        <span>{{ $t("LABEL_NOT_ALLOWED") }} </span>
                                    </span>
                </div>
              </div>
              <br />
              <br />
              <div class="row">
                <div class="col-xs-6 ocf-label-static"><span>{{ $t("LABEL_ADMIN_OWNER") }}</span>&nbsp;<span style="color: #ff6347;">*</span></div>
                <div class="col-xs-5" style="border: none;">
                  <input
                      class="w120 form-control"
                      tabindex="3"
                      name="adminOAR"
                      type="text"
                      maxlength="50"
                      id="adminOAR"
                      on-keyup-fn="handleKeypress"
                      @keypress="checkForSpecialCharacters($index, $event, 150,admin.owner)"
                      v-on:change="isSpecialCharacterPresentInOAR(admin.owner)"
                      v-model="admin.owner"
                  />
                </div>
              </div>
              <br />
              <br />
              <div class="row">
                <div id="enableIText1111" class="ocf-i-text top collapse" role="tooltip" data-collapse="collapse" style="display: none;">
                  <div class="ocf-i-text-inner">
                    <h3>{{ $t("LABEL_PRODUCTS_INFO_HEADING") }}</h3>
                    <p>{{ $t("LABEL_PRODUCTS_INFO_DETAIL_STRING") }}</p>
                  </div>
                </div>
                <div class="col-xs-6 ocf-label-static">
                  <span>{{ $t("LABEL_PRODUCT_ID") }}</span>
                  <span style="color: #ff6347;">*</span>
                  <aab-info-popover>
                    <h4><span>How to set product IDs for an Administration?</span></h4>
                    <p><span>A numeric value for the Product ID has to be entered.
                      In case more than one Product ID is applicable the values should be separated with comma</span></p>
                  </aab-info-popover>
                </div>
                <div class="col-xs-5">
                  <textarea class="w120 form-control" rows="2" tabindex="4"
                            name="productid" spellcheck="false" type="text" id="productid" v-model="admin.productid"
                            on-keyup-fn="handleKeypress"
                            @pattern='/^[0-9 _ ,_]*$/'/>
                  <div>
                    <span class="glyphicon glyphicon-warning-sign form-control-feedback"
                          v-if="isProductIDValid()" style="position: relative; float: left; margin-top: -7%;"></span>
                    <span class="help-block" style="margin-left: 25px;" v-show="isProductIDValid()">{{ $t("LABEL_PRODUCTID_INVALID") }}</span>
                  </div>
                </div>
              </div>
              <br />
              <br />
              <div class="row btn-group">
                <div class="col-xs-6"></div>
                <div class="col-xs-5">
                  <aab-button>
                    <button type="submit" class="btn btn-primary" tabindex="5"
                            @click.prevent='checkGenericAdminDtls'>
                      <span>{{ $t("LABEL_ADD_TERMS") }}</span>
                    </button>
                  </aab-button>
                </div>
                <aab-modal modal-size="large">
                  <span slot="modal-title"  style='color: #608e28;font-size: 24px;margin-top: 10px;'>{{$t('LABEL_ADD_TERMS')}}
                    <!--<div  v-if="noTermsSelected"
                          class="alert alert-warning">
                      <span class="glyphicon glyphicon-warning-sign"
                            id="errorImage"></span>
                      <h3 translate>LABEL_NO_TERM_SELECTED</h3>
                    </div>-->
                  </span>
                  <span slot="modal-content"  style='color: #608e28;font-size: 18px;margin-top: 20px; height: 100px;'>
                    <br/>
                    <div class="row" style="width: 90%">
                      <div class="col-xs-4 ocf-label-static"><span>{{$t('LABEL_SEARCH')}}</span></div>
                      <div class="col-xs-5" >
                        <input class="w120 form-control" rows="2"
                               name="search"  spellcheck="false"
                               type="text" maxlength="80"
                               placeholder="Enter term name"
                               v-model="search" id="search"  on-keyup-fn="handleKeypress"/>
                      </div>
                    </div>
                    <br/>
                    <div class="modal-body"
                         style="height: 300px; width: 650px; overflow-y: auto;">
                      <br>
                      <div class="table-responsive" style="margin-top: -5px">
                        <table class="table table-striped table-hover"
                               style="margin-bottom: 0px">
                          <thead>
                          <tr>
                            <th>
                              <a href='' style="color :#608e28;text-decoration: none; cursor: default;" >{{$t('LABEL_GLOSSARY_DETAIL_SCREEN_NAME')}}</a>
                            </th>
                            <th>
                              <a href='' style="color :#608e28;    cursor: default;text-decoration: none;" >{{$t('LABEL_TERM_DATA_TYPE')}}</a>
                            </th>
                            <th>
                              <!-- <a href='' translate style="color :#608e28;text-decoration: none;    cursor: default;" >LABEL_SELECT_ALL</a>&nbsp;&nbsp;
                              <input type="checkbox" id ="selectTerm"
                              ng-disabled="filteredItems.length<terms.length"
                              ng-checked="allTermsSelected" ng-model="allTermsSelected" ng-change="selectAll();" /> -->
                            </th>
                          </tr>
                          </thead>
                          <tbody>
                          <tr class="pointer" style="background-color: #f9f9f9;    cursor: default;"
                              v-for="(term,index) in terms" :key="index"
                              v-show="showTerm(term)">
                            <td class='' v-if='term.display===true'
                                style="width: 45%;word-break: break-all;">{{term.name}}
                              <p style ="font-size: 13px;">{{term.description}}</p>
                            </td>
                            <td class='' v-if='term.display===true'>
                              <span>{{$t(term.dataType)}}</span><!-- | translate-->
                            </td>
                            <td v-if='term.display===true'>
<!--                              <input type="checkbox"
                                     @click="()=>{selectUsers(term.name)}"
                                     :value="term.name"
                                     style="margin-left: 30px;" />-->
                              <input type="checkbox"  v-model="term.selected"
                                     @change="unselectAll(),
                                     $event.stopImmediatePropagation()"
                                     style="margin-left: 30px;"
                              ></td>
                          </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <br>
                  </span>
                  <span slot="modal-footer">
                    <div class="modal-footer">
                      <aab-button style-type="primary" style="margin-right: 16px;">
                        <button type="button"
                                @click.prevent="saveAndCloseAdministrationTermsModal($event)"
                                :disabled='selectedCount<1'
                                style="margin-right: 35px" class="btn btn-primary">
                          <span>{{$t('LABEL_SAVE')}}</span><!--@click.prevent="saveTermsInAdmin()"-->
                        </button>
                      </aab-button>
                      <aab-button style-type="secondary">
                        <button type="button"
                                @click.prevent="allTermsSelected=false,
                            closeAdministrationTermsModal($event),
                            $event.preventDefault()"
                                class="btn btn-primary"
                                data-dismiss="modal"><!--selectAll()-->
                          <span>{{$t('LABEL_CLOSE')}}</span>
                        </button>
                      </aab-button>
                    </div>
                  </span>
                </aab-modal>
              </div>
              <br />
            </div>
          </div>
          <!--<aab-tabs class="tabs" id="tabdetails"
          v-if="showtabs" :tabs="tabInfo" selected="active" scrolling :fade-white="false" :full-width="false" divider>
                    </aab-tabs>-->

<!--          <aab-tabs :tabs="tabInfo"
                    selected=active
                    :scrolling=true
                    :fade-white=true
                    :full-width=false
                    :divider=true
                    @click.prevent="testFun"
                    v-if="showtabs"
          />-->
          <termViewPanel
              :actionTab='actionTab'
              :tabsData='selectedTerms'
              @childTermsData = 'catchChildTermsData'
          /><br/>

          <div class="row">
            <div class="col-xs-12">
              <aab-button class="btn-primary" @click.prevent="save()"><button id="saveButton"><span>{{$t("LABEL_SAVE")}}</span></button></aab-button>
              <!--              <aab-modal modal-size="medium">
                              <span slot="modal-title" style="line-height: 32px;font-size: 24px;color: #222;">
                              Are you sure you want to return to the overview page?</span>
                              <span slot="modal-content">If you have performed any updates they will be lost. Click on OK to return to the overview page</span>
                              <span slot="modal-footer" style="display: flex;justify-content: flex-end">
                          <aab-button
                              @click="closeDemoModal2($event)" style-type="primary" style="margin-right: 16px;"><button>Okay</button></aab-button>
                          <aab-button
                              @click="closeDemoModal2($event)" style-type="secondary"><button>Cancel</button></aab-button>
                          </span>
                            </aab-modal>-->
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>
<script>
import Notify from '@/components/Notify';
import termViewPanel from '@/components/termViewPanel';
import BackButton from '@/components/BackButton';
import ConfirmationPopUpTemplate from '@/components/ConfirmationPopUp';
import { sy_arrow_arrow_left } from '@aab/sc-aab-icon-set/src/lib/systems';
import utils from '@/scripts/utils';
import appServices from '@/services/AppServices';
import {required} from 'vuelidate/lib/validators';
import adminConfigUtility from '@/mixins/adminConfigUtility';

export default {
  name: 'createAdmin',
  components: { BackButton, Notify, ConfirmationPopUpTemplate, termViewPanel },
  mixins: [adminConfigUtility],

  data() {
    return {
      tabInfo: '[]',
      showtabs: false,

      viewResult: '',
      info: '',
      admin: {
        name: '',
        description: '',
        owner: '',
        productid: '',
        terms:[]
      },
      termListModal: '',
      queryToSend: {},
      sy_arrow_arrow_left,
      enableSpinner: false,
      displayMsg: '',
      allTermsSelected: false,
      showAdminTerms: true,
      msgType: '',
      toolMsg: '',
      closeNotify: '',
      errorMsg: '',
      action: '',
      confirmActionPopup: false,
      selectedAction: '',
      selectedTerms: [],
      selectedCount: 0,
      selectedTermNameList: [],
      search: [],
      backAction: '',
      actionBackButton: false,
      showMessage: false,
      terms:'',
      tabsData:'',
      actionTab:false,

      showErrorMessage : false,
      activeTermIndex : 0,
      enableAddAdmin : false,
      adminTerms : {},
      singleValueFacets : ['Length', 'Pattern', 'Maximum length', 'Minimum length'],


      facetTypeValueList : [{ 'singleValueFacets': this.singleValueFacets },
        {
          'facetType': [],
          'facetValue': []
        }],
    };
  },
  watch: {
    confirmActionPopup: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
    actionBackButton: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
    actionTab: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
  },
  mounted() {
    this.onLoad();
  },
  validations: {
    admin: {
      name: {required},
      description: {required},
      owner: {required},
      productid: {required}
    },
  },
  computed: {},
  methods: {
    onLoad() {

      const queryToSend = {};
      queryToSend.timeStamp = new Date().getTime();

      this.notify('', '');
      this.enableSpinner = true;

      queryToSend.currentTime= new Date();
      console.log(queryToSend);

      const params = new URLSearchParams();
      params.append('timeStamp',(queryToSend.timeStamp !== 'undefined'? queryToSend.timeStamp:''));

      const request = {
        params: params
      };
      console.log(request.params);
      appServices.getAllTermsServiceCall(request).then((result) => {
        console.log(result);
        this.enableSpinner = false;
        this.terms = result;
        this.updateTermsObj(this.terms);

        // term dtls template
        this.termViewTemplateURL = 'app/modules/createadmin/termViewPanel.html';
      }).catch((error) => {
        console.log(error.response.data.errors[0]);
        this.httpServiceErrorCall(error);
      });
    },
    catchChildTermsData(term){
      this.admin.terms = term;
    },
    updateTermsObj(obj) {
      this.terms = obj;
      this.terms.forEach(function (term) {
        term.display = true;
      });
    },

    updateTermsCheckBoxSelectedObj(obj) {
      this.terms = obj;
      this.terms.forEach(function (term) {
        term.selected = true;
      });
    },

    sortTable: function (col) {
      if (this.sortColumn === col) {
        this.ascending = !this.ascending;
      } else {
        this.ascending = true;
        this.sortColumn = col;
      }
      const isAscending = this.ascending;
      this.viewResult.sort(function (a, b) {
        if (a[col] > b[col]) {
          return isAscending ? 1 : -1;
        } else if (a[col] < b[col]) {
          return isAscending ? -1 : 1;
        }
        return 0;
      });
    },

    notify(type, msg, close = true) {
      this.msgType = type;
      this.displayMsg = msg !== '' ? msg : '';
      this.toolMsg = msg;
      this.closeNotify = close;
    },
    back() {
      this.selectedAction = 'backButton';
      this.actionBackButton = true;
      this.confirmPopUp();
    },
    confirmPopUp() {
      this.confirmActionPopup = true;
    },
    cancel() {
      this.confirmActionPopup = false;
    },
    validatePopUpConfirm() {
      if (this.selectedAction === 'backButton') {
        this.$router.push('administrationOverview');
        this.back();
      } else if (this.selectedAction === 'saveAdminButton') {
        this.confirmActionPopup = false;
        this.saveAdmin();
      }
    },

    /*
      Uncheck select all checkbox, in case of all terms are not selected
    */
    unselectAll() {
      let keepGoing = true;
      let count = 0;
      // Count for counting all selected terms
      let selectedCount = 0;
      const termCount = this.terms.length;
      this.terms.forEach(function (term) {
        if (term.selected === true) {
          selectedCount++;
          if (selectedCount === termCount) {
            this.allTermsSelected = true;
          }
        }
      });
      this.selectedCount = selectedCount;
      this.terms.forEach(function (term) {
        count = count+1;
        if (keepGoing && term.selected === false) {
            this.allTermsSelected = false;
            keepGoing = false;
          }
      });
    },

    /**/
    selectAll(){
      let selectedCount = 0;
      this.terms.forEach(function (term) {
        if (this.allTermsSelected) {
          selectedCount = this.terms.length;
          term.selected = true;
        } else {
          term.selected = false;
        }
      });
      this.selectedCount = selectedCount;
      this.search = '';
    },
    selectUsers(id) {
      //in here you can check what ever condition  before append to array.
      if (!this.selectedTerms.includes(id)) {
        const obj2 = JSON.parse(this.tabInfo);
        const obj = { title: id, id: id };
        this.selectedTerms.push(id);
        obj2.push(obj);
        this.tabInfo = JSON.stringify(obj2);
      }/*else {
         const obj3 = JSON.parse(this.tabInfo);
         console.log(obj3);
        this.selectedTerms.slice(id,);
      }*/

      console.log(this.selectedTerms);
      console.log(this.tabInfo);
    },
    showTerm(term) {
      if (this.search !== undefined && this.search !== '') {
        return term.name.indexOf(this.search) !== -1;
      } else {
        return true;
      }
    },
    showAdministrationTermsModal() {
      const modalDemo = document.querySelector('aab-modal');
      modalDemo.openModal();
    },

    save(){
      this.selectedAction = 'saveAdminButton';
      this.confirmPopUp();
    },
    /*
     this function is used to save admin and validating mandatory fields.
    */
    saveAdmin() {
      // disable create admnin btn in case duplicate terms are selected
      if (!utils.isEmpty(this.selectedTerms)
          && this.selectedTerms.length > 0
          && this.hasDuplicates(this.selectedTermNameList)) {
        this.duplicateTermsPresent = true;

        this.notify('', '');
        this.notify('warning', 'ERROR_DUPLICATE_TERMS_SELECTED', true);

        this.showMessage = true;
/*
        this.moveToTop();
*/
        return false;
      }

      /*hideAllInfoMsg();*/
      //validateProductIdFormat(admin.productid);
      if (!this.validateGeneralFormDtls(this.admin, 'ALERT_SPECIAL_CHAR_IN_CREATE')) {
        return false;
      } else if (this.validateGeneralFormDtls(this.admin, 'ALERT_SPECIAL_CHAR_IN_CREATE')
          && utils.isEmpty(this.validateProductIdFormat(this.admin.productid))
          && !this.validateProductIdFormat(this.admin.productid)
          && !this.hasDuplicatesPrducts(this.productList) && this.validateTermsDtls()) {

        this.showMessage = false;
        this.admin.terms = [];
        this.admin.terms = this.selectedTerms;
        this.createAdministrationRestResourceCall();
      }
      else if (this.validateGeneralFormDtls(this.admin, 'ALERT_SPECIAL_CHAR_IN_CREATE')
          || this.validateProductIdFormat(this.admin.productid)
          || this.hasDuplicatesPrducts(this.productList) || this.validateTermsDtls()) {
        this.showMessage = true;
        this.moveToTop();
      }

    },
    /*
     This function is to set service call for creating Admin
    */
    createAdministrationRestResourceCall() {
      const AdministrationRestResource = {};
      AdministrationRestResource.products = [];
      AdministrationRestResource.terms = [];
      AdministrationRestResource.name = utils.removeMultipleSpace(this.admin.name);
      AdministrationRestResource.description = utils.removeMultipleSpace(this.admin.description);
      AdministrationRestResource.oarId = this.admin.owner;
      //AdministrationRestResource.products.push(this.admin.productid);

      AdministrationRestResource.products = this.productList;
      if (!utils.isEmpty(this.admin.terms)) {
        const tempObj = this.validateFacetFormat(this.admin.terms);
        AdministrationRestResource.terms = tempObj;
        this.facetTypeEnumMapper(AdministrationRestResource.terms);
      }

      const PThis = this;
      appServices.createAdminServiceCall(AdministrationRestResource).then((response) => {
        console.log(response);
        //PThis.createAdminResponse = response;
        // PThis.processCreatetermResponse(PThis.createResult,PThis.term);
      }).catch((error) => {
        PThis.enableSpinner = false;
        PThis.httpServiceErrorCall(error);
      });
      this.$router.push('administrationOverview');
    },
    saveAndCloseAdministrationTermsModal(e) {
      const modalDemo = document.querySelector('aab-modal');
      modalDemo.closeModal(e);
      this.showtabs = true;
      this.saveTermsInAdmin();
    },
    closeAdministrationTermsModal(e) {
      const modalDemo = document.querySelector('aab-modal');
      modalDemo.closeModal(e);
    },

    checkDuplicateTerms(selectedTerms) {
      let index;
      this.selectedTermNameList = [];
      for (index = 0; index < selectedTerms.length; index++) {
        this.selectedTermNameList.push(selectedTerms[index].name);
      }

      if (this.hasDuplicates(this.selectedTermNameList)) {
        this.duplicateTermsPresent = true;
        this.notify('', '');
        this.notify('warning', 'ERROR_DUPLICATE_TERMS_SELECTED', true);
        this.showMessage = true;
        return false;
      }
    },

    saveTermsInAdmin() {
      this.selectedCount = 0;
      if (this.selectedTerms === undefined) {
        this.selectedTerms = [];
      }

      let index;
      for (index = 0; index < this.terms.length; index++) {
        if (this.terms[index].display === true && this.terms[index].selected) {
          // to hide from term list poup in case of selected
          this.terms[index].display = false;
          this.terms[index].facetTypeValueList = [{ singleValueFacets: this.singleValueFacets }];
          this.selectedTerms.push(this.terms[index]);
          this.showAdminTerms = true;
          this.terms[index].facets = [];
        }
      }
      this.checkDuplicateTerms(this.selectedTerms);

      /*if(this.selectedTerms.length>0){
this.noTermsSelected=false;
$('#myModal').modal('hide');
}*/
      this.search = '';
      // $('#myModal').modal('hide');
      //
      // if (!this.duplicateTermsPresent) {
      //   moveToBottom();
      // } else {
      //   moveToTop();
      // }
    },

    termViewTemplateURL() {
      this.$router.push({ name: 'viewAdministrationDetails' });
    },

    validateCreateTermParms() {
      if(utils.isEmpty(this.admin.name) || utils.isEmpty(this.admin.description)
          || (utils.isEmpty(this.admin.productid))){
        this.notify('', '');
        this.notify('warning','ERROR_MANDATORY_CREATE_TERM',true);
        return false;
      }
      else{
        return true;
      }
    },

    /*
     aligining page to top
    */
    /*moveToTop() {
      $('html, body').animate({
        scrollTop: 0
      }, 600);
      return false;
    },*/

    /*
     This function is used to check duplicates value in list-String
    */
    hasDuplicates(array) {
      const valuesSoFar = Object.create(null);
      for (let i = 0; i < array.length; ++i) {
        const value = array[i];
        if (isNaN(value)) {
          if (value.toUpperCase().trim() in valuesSoFar) {
            return true;
          }
        } else {
          if (value.trim() in valuesSoFar) {
            return true;
          }
        }

        if (isNaN(value)) {
          valuesSoFar[value.toUpperCase().trim()] = true;
        } else {
          valuesSoFar[value.trim()] = true;
        }
      }
      return false;
    },

    validateTermsDtls() {
      if (this.selectedTerms !== undefined && this.selectedTerms.length > 0) {
        let validatedtermsCount = 0;
        for (let j = 0; j < this.selectedTerms.length; j++) {
          this.validateFacetsMandatoryFields(j, this.selectedTerms[j]);
        }

        for (let i = 0; i < this.selectedTerms.length; i++) {
          if (this.selectedTerms[i].validated !== true) {
            this.selectedTerms[i].showMessage = true;
            this.showMessage = true;
            if (this.selectedTerms[i].errorMsgLabel === 'ERROR_MANDATORY_FACETS_DTLS') {
              this.notify('', '');
              this.notify('warning', 'ERROR_MANDATORY_CREATE_ADMIN', true);
            } else {
              this.notify('', '');
              this.notify('warning', 'ALERT_SPECIAL_CHAR_IN_CREATE', true);
            }
          } else {
            this.selectedTerms[i].showMessage = false;
            validatedtermsCount++;
          }
        }

        if (validatedtermsCount === this.selectedTerms.length) {
          return true;
        }
      } else {
        return true;
      }

      /*admin.terms = [];
      var index;
      if (!angular.isUndefined(this.selectedTerms)) {
      for (index=0; index< this.selectedTerms.length; index++) {
      addTermsToAdmin(this.selectedTerms[index]);
      }
      } else {
      ErrorService.showError('ERROR_ADMIN_TERM_REQUIRED');
      this.showMessage=true;
      return false;
      }*/

      //return true;
    },
    /*
     This function is to remove multiple spaces(if present) in string
   */
    /*removeMultipleSpace(obj) {
      // Spaces and new line is added
      return obj.replace(/  +/g, ' ');
    },*/

    validateFacetFormat(obj) {
      //the below line code is alternate to angular.copy(obj) code
      const temp = Object.assign([], obj);
      console.log(temp.length);
      for (let i = 0; i < temp.length; i++) {
        for (let j = 0; j < temp[i].facets.length; j++) {
          if (temp[i].facets[j].showFlag === false || temp[i].facets[j].facetValue === undefined) {
            temp[i].facets.splice(j, 1);
          }
        }
      }
      return temp;
    },
    facetTypeEnumMapper(value) {
      for (let j = 0; j < value.length; j++) {
        for (let i = 0; i < value[j].facets.length; i++) {
          if (value[j].facets[i].facetType === 'List values') {
            value[j].facets[i].facetType = 'ENUMERATION';
          }
          if (value[j].facets[i].facetType === 'Length') {
            value[j].facets[i].facetType = 'LENGTH';
          }
          if (value[j].facets[i].facetType === 'Pattern') {
            value[j].facets[i].facetType = 'PATTERN';
          }
          if (value[j].facets[i].facetType === 'Maximum length') {
            value[j].facets[i].facetType = 'MAXLENGTH';
          }
          if (value[j].facets[i].facetType === 'Minimum length') {
            value[j].facets[i].facetType = 'MINLENGTH';
          }
          if (value[j].facets[i].facetType === 'MinInclusive') {
            value[j].facets[i].facetType = 'MININCLUSIVE';
          }
          if (value[j].facets[i].facetType === 'MaxInclusive') {
            value[j].facets[i].facetType = 'MAXINCLUSIVE';
          }
          if (value[j].facets[i].facetType === 'MinExclusive') {
            value[j].facets[i].facetType = 'MINEXCLUSIVE';
          }
          if (value[j].facets[i].facetType === 'MaxExclusive') {
            value[j].facets[i].facetType = 'MAXEXCLUSIVE';
          }
          if (value[j].facets[i].facetType === 'Total Digits') {
            value[j].facets[i].facetType = 'TOTALDIGITS';
          }
          if (value[j].facets[i].facetType === 'Fractions') {
            value[j].facets[i].facetType = 'FRACTIONS';
          }
        }
      }
    },
    validateHttpErrorParams(params) {
      if (params !== null && params.length > 0) {
        return true;
      }
    },

    formatErrorMsgForProductValidation(errorCode, params) {
      if (errorCode === 'MESSAGE_ADDA_021') {
        this.errorMsg = 'The product(s) ' + params;
        this.notify('', '');
        this.notify('warning', this.errorMsg + '' +'LABEL_ERROR_PRODUCT_ALREADY_ADMINISTERED', true);
      }
      this.setDisplayErrorFlag();
    },
    // This method is to get msg (EN/NL) on the basis of label name.
    /*getTranslation(label) {
      return gettextCatalog.getString(label);
    },*/
    // This method is to set flag to display error block in widget.
    setDisplayErrorFlag() {
      this.showMessage = false;
      this.showErrorMessage = true;
    },
    httpServiceErrorCall(error) {
      if (error.status === 403 ) {
        this.notify('', '');
        this.notify('warning', 'LABEL_AUTHORIZATION_ERROR', true);
        this.showMessage = true;
      } else if (error.status === 500 && error.data.errors !== undefined && this.validateHttpErrorParams(error.data.errors[0].params)) {
        this.formatErrorMsgForProductValidation(error.data.errors[0].code, error.data.errors[0].params);
      } else if (error.status === 500 || error.status === 404 || error.status === 405) {
        this.notify('', '');
        this.notify('warning', 'LABEL_ERROR', true);
        this.showMessage = true;
      } else {
        this.notify('', '');
        this.notify('warning', error.data.errors[0].code, true);
        this.showMessage = true;
      }
    },

    /*
     This function is to check null/empty value
    */
    /*isEmpty(value) {
      if (value === undefined || value === null || value === '') {
        return true;
      }
    },*/
    validateUnicode(inpuString) {
      const unicodeArray = [];
      for (let i = 0; i < inpuString.length; i++) {
        const theUnicode = inpuString.charCodeAt(i).toString(16);
        if (theUnicode.length > 2) {
          unicodeArray.push(inpuString.charAt(i));
        }
      }

      const uniqueArray = [];
      for (let j = 0; j < unicodeArray.length; j++) {
        if (uniqueArray.indexOf(unicodeArray[j]) === -1 && unicodeArray[j] !== '') {
          uniqueArray.push(unicodeArray[j]);
        }
      }
      let message = '';
      for (let k = 0; k < uniqueArray.length; k++) {
        if (k < uniqueArray.length - 1) {
          message = message + uniqueArray[k] + ', ';
        } else {
          message = message + uniqueArray[k];
        }
      }
      return message;
    },

    isSpecialCharacterPresentInAdminName(input) {
      this.admin.isSpecialCharPresentInAdminName = false;
      if (null != input && input.length > 0 && this.validateUnicode(input) !== '') {
        this.admin.isSpecialCharPresentInAdminName = true;
        this.admin.specialCharPresentInAdminName = this.validateUnicode(input);
        return true;
      }
      return false;
    },

    isSpecialCharacterPresentInAdminDesc(input) {
      this.admin.isSpecialCharPresentInAdminDesc = false;
      if (null != this.input && input.length > 0 && this.validateUnicode(input) !== '') {
        this.admin.isSpecialCharPresentInAdminDesc = true;
        this.admin.specialCharPresentInAdminDesc = this.validateUnicode(input);
        return true;
      }
      return false;
    },

    isSpecialCharacterPresentInOAR(input) {
      this.admin.isSpecialCharPresentInOAR = false;
      if (null != input && input.length > 0 && this.validateUnicode(input) !== '') {
        this.admin.isSpecialCharPresentInOAR = true;
        this.admin.specialCharInAdminOAR = this.validateUnicode(input);
        return true;
      }
      return false;
    },

    isProductIDValid() {
      return (this.admin.productid.$invalid && !this.admin.$pristine);
    },

    validateGeneralFormDtls(admin, label) {
      console.log('Inside validateGeneralFormDtls - >' + label);
      if (
          utils.isEmpty(admin.name) ||
          utils.isEmpty(admin.description) ||
          utils.isEmpty(admin.owner) ||
          utils.isEmpty(document.getElementById('productid').value)
      ) {
        this.notify('', '');
        this.notify('warning', 'ERROR_MANDATORY_CREATE_ADMIN', true);
        this.showMessage = true;
        console.log('ShowMessage1', this.showMessage);
        return false;
      } else if (this.admin.isSpecialCharPresentInAdminName
          || this.admin.isSpecialCharPresentInAdminDesc
          || this.admin.isSpecialCharPresentInOAR
          || this.isProductIDValid()) {
        this.notify('', '');
        this.notify('warning', label, true);
        this.showMessage = true;
        this.moveToTop();
        return false;
      } /*else if(validateProductIdFormat(admin.productid)
                      && hasDuplicatesPrducts(this.productList)){
              this.showMessage=true;
              moveToTop();

            }*/ else {
        return true;
      }
    },

    hasDuplicatesPrducts(array) {
      const valuesSoFar = Object.create(null);
      if (array.length < 1) {
        this.notify('', '');
        this.notify('warning', 'LABEL_EMPTY_PRODUCTS', true);
        return true;
      }
      for (let i = 0; i < array.length; ++i) {
        const value = array[i];

        if (value in valuesSoFar) {
          this.notify('', '');
          this.notify('warning', 'LABEL_DUPLICATE_PRODUCTS', true);
          return true;
        }
        valuesSoFar[value] = true;
      }
      return false;
    },

    validateProductIdFormat(obj) {
      this.productList = [];
      let counter = 0;
      for (let i = 0; i < obj.length; i++) {
        if (obj.charAt(i) === ',') {
          counter++;
        }
      }
      if (counter > 0) {
        for (let j = 0; j < counter + 1; j++) {
          obj.split(',')[j];
          if (obj.split(',')[j] !== '') {
            if (obj.split(',')[j].trim().length > 6) {
              this.notify('', '');
              this.notify('warning', 'ERROR_INVALID_PRODUCT', true);
              this.showMessage = true;
              return false;
            } else {
              this.productList.push(Number(obj.split(',')[j]));
              //return true;
            }
          }
        }
      } else if (counter === 0 && obj.length > 0) {
        if (obj.trim().length > 6) {
          this.notify('', '');
          this.notify('warning', 'ERROR_INVALID_PRODUCT', true);
          this.showMessage = true;
          return false;
        } else {
          this.productList.push(Number(obj));
          //return true;
        }
      }
    },

    /*hideIText(id) {
      id = '#enableIText' + id;
      (id).slideUp();
    },*/

    /*hideAllInfoMsg() {
      this.hideIText(111);
      this.hideIText(222);
      this.showErrorMessage = false;
      if (this.selectedTerms !== undefined && this.selectedTerms.length > 0) {
        for (let i = 0; i < this.selectedTerms.length; i++) {
          this.hideIText(i + 1);
        }
      }
    },*/

    validateSpecialChars(admin) {
      if (admin.isSpecialCharPresentInAdminName !== true
          && admin.isSpecialCharPresentInAdminDesc !== true
          && admin.isSpecialCharPresentInOAR !== true
          && admin.isSpecialCharPresentInProductIds !== true) {
        return true;
      } else {
        this.notify('', '');
        this.notify('warning', 'ALERT_SPECIAL_CHAR_IN_CREATE', true);
        this.showMessage = true;
        return false;
      }
    },

    checkGenericAdminDtls() {
      if (!this.validateGeneralFormDtls(this.admin, 'ALERT_SPECIAL_CHAR_BEFORE_ATTACH_TERM')) {
        this.termListModal = '';
      } else if (this.validateProductIdFormat(this.admin.productid) !== undefined
          && !this.validateProductIdFormat(this.admin.productid)) {
        this.termListModal = '';
        this.showMessage = true;
        this.notify('', '');
        this.notify('warning', 'LABEL_ALL_TERMS_ADDED', true);
      } else if (this.hasDuplicatesPrducts(this.productList)) {
        this.termListModal = '';
        this.showMessage = true;
        this.notify('', '');
        this.notify('warning', 'ERROR_MANDATORY_CREATE_TERM', true);
      } /*else if (!this.validateSpecialChars()) {
        this.termListModal = '';
        this.notify('', '');
        this.notify('warning', 'ALERT_SPECIAL_CHAR_BEFORE_ATTACH_TERM', true);
      }*/ else if (this.selectedTerms !== undefined
          && this.selectedTerms.length === this.terms.length) {
        this.termListModal = '';
        this.showMessage = true;
        this.notify('', '');
        this.notify('warning', 'LABEL_ALL_TERMS_ADDED', true);
      } else {
        /*this.hideAllInfoMsg();*/
        this.showMessage = false;
        this.termListModal = '#myModal';
        this.showAdministrationTermsModal();
      }
    },
  },
};
</script>
