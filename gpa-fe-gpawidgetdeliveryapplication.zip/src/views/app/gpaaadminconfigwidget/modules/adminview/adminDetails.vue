<template>
  <div class="panel panel-default">
    <div class="panel-heading"  style="padding-top: 5px">
      <BackButton
          :actionBackButton="backAction"
          :back="back"
      />
      <br/><br/>
      <h2 class="panel-title">
        <span >{{ $t("LABEL_ADMIN_DETAIL_SCREEN_NAME")}}</span>
      </h2>
    </div>
    <div class="panel-body">


      <notify
          :notificationType="msgType"
          :displayMessage="displayMsg"
          :closeNotification="closeNotify"
          @clear="notify($event, $event)"
          :title="toolMsg"
      />
      <aab-spinner :size="12" v-if="enableSpinner"></aab-spinner>

      <ConfirmationPopUpTemplate
          v-if="confirmActionPopup"
          :actionPopUp="action"
          :cancel="cancel"
          :validatePopUpConfirm="validatePopUpConfirm"
          :selectedAction="selectedAction"
      />
      <div id="adminDetailsBlock">
        <form class="form-horizontal v-pristine v-valid"  v-cloak>
          <div>
            <h4 class="panel-title" style="color: #608e28;">
              <span >{{ $t("LABEL_GENERAL_ADMIN_DETAILS")}}</span>
            </h4>
          </div>
          <div class="bs-component v-scope v-isolate-scope">
            <div class="well">
              <div class="row">
                <div class="col-xs-6 ocf-label-static">
                  <p>{{ $t("LABEL_ADMIN_ID")}}</p>
                </div>
                <div class="col-xs-6 description">{{viewAdminResult.id}}</div>
              </div>
              <div class="row">
                <div class="col-xs-6 ocf-label-static">
                  <p >{{ $t("LABEL_ADMIN_NAME")}}</p>
                </div>
                <div class="col-xs-6 description">{{viewAdminResult.name}}</div>
              </div>
              <div class="row">
                <div class="col-xs-6 ocf-label-static">
                  <p >{{ $t("LABEL_ADMIN_DESCR")}}</p>
                </div>
                <div class="col-xs-6 description" style="margin-bottom: 10px">{{viewAdminResult.description}}</div>
              </div>
              <div class="row">
                <div class="col-xs-6 ocf-label-static">
                  <p >{{ $t("LABEL_ADMIN_OWNER")}}</p>
                </div>
                <div class="col-xs-6 description" style="margin-bottom: 10px">{{viewAdminResult.oarId}}</div>
              </div>
              <div class="row">
                <div class="col-xs-6 ocf-label-static">
                  <p >{{ $t("LABEL_PRODUCT_ID")}}</p>
                </div>
                <div class="col-xs-6 description" style="margin-bottom: 10px">
                  {{viewAdminResult.products.toString().split(',').join(', ')}}</div>
              </div>
            </div>
          </div>
          <div>
            <h4 class="panel-title" style="color: #608e28;">
              <span >{{ $t("LABEL_AUDIT_DETAILS")}}</span>
            </h4>
          </div>
          <div class="bs-component v-scope v-isolate-scope">
            <div class="well">
              <div class="row">
                <div class="col-xs-6 ocf-label-static">
                  <p >{{ $t("LABEL_CREATEDBY")}}</p>
                </div>
                <div class="col-xs-6">
                  <div>
                    {{viewAdminResult.auditDetails.createdBy}} <span>{{ $t("LABEL_ON")}}</span>
                    {{viewAdminResult.auditDetails.createdTimeStamp | formatDateTime}}
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-xs-6 ocf-label-static">
                  <p >{{ $t("LABEL_MODIFIEDBY")}}</p>
                </div>
                <div class="col-xs-6">
                  <div
                      v-show='viewAdminResult.auditDetails.modifiedBy!=null && viewAdminResult.auditDetails.modifiedBy!=""'>
                    {{viewAdminResult.auditDetails.modifiedBy}} <span>{{ $t("LABEL_ON")}}</span>
                    {{viewAdminResult.auditDetails.modifiedTimeStamp | formatDateTime}}
                  </div>
                  <div
                      v-if='viewAdminResult.auditDetails.modifiedBy==null && viewAdminResult.auditDetails.modifiedBy===""'>
                    -
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div v-if="viewAdminResult.terms>0">
            <h4 class="panel-title" style="color :#608e28;"><span>{{$t("LABEL_ATTACHED_TERMS_HEADER")}}</span></h4>
          </div>
          <Navbar
              :actionTab="actionTab"
              :tabsData='viewAdminResult.terms'
          /><br/>
          <div class="row">
            <div class="col-xs-12">
              <button type="submit" class="btn btn-primary" tabindex="6"
                      v-on:click.prevent="deleteOperation(viewAdminResult)">
                <span >{{ $t("LABEL_DELETE")}}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>
<script>
import appServices from '@/services/AppServices';
import BackButton from '../../../../../components/BackButton';
import Navbar from '../../../../../components/Navbar';
import Notify from '../../../../../components/Notify';
import ConfirmationPopUpTemplate from '../../../../../components/ConfirmationPopUp';
import {sy_tools_trash} from '@aab/sc-aab-icon-set';

export default{
  name:'viewAdministrationDetails',
  components: {BackButton,Navbar,Notify,ConfirmationPopUpTemplate},
  data(){
    return {
      viewAdminResult:{
        id:'',
        name:'',
        description:'',
        oarId:'',
        terms: {
          term: {
            id: '',
            name: '',
            description: '',
            dataType: [],
            auditDetails: {
              createdBy: '', modifiedBy: '', createdTimeStamp: '', modifiedTimeStamp: ''
            }
          },
          facets: {
            facet:{
              facetType: '',
              facetValue: '',
              auditDetails:{
                createdBy:'',modifiedBy:'',createdTimeStamp:'',modifiedTimeStamp:''
              },
            },
          },
        },
        auditDetails:{
          createdBy:'',modifiedBy:'',createdTimeStamp:'',modifiedTimeStamp:''
        },
        products:{},
      },
      enableSpinner: false,
      displayMsg: '',
      msgType: '',
      toolMsg: '',
      closeNotify: '',
      termOldObj:'',
      action: '',
      confirmActionPopup:false,
      selectedAction:'',
      backAction: '',
      actionBackButton:false,
      tabsData:'',
      actionTab:false,
      sy_tools_trash,
      selectedIdForDelete:'',
    };
  },
  watch: {
    confirmActionPopup: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
    actionBackButton: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
    actionTab: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
  },
  async mounted() {
    this.onLoad();
  },
  methods: {

    async onLoad() {
      // console.warn(this.$route.params.adminId);

      const queryToSend = {};
      queryToSend.currentTime= new Date();
      // console.log(queryToSend);

      const params = new URLSearchParams();
      params.append('currentTime',(queryToSend.currentTime !== 'undefined'? queryToSend.currentTime:''));

      const request = {
        params: params
      };
      this.result = await
      appServices.getAdminDetailsById(this.$route.params.adminId,request);
      this.viewAdminResult = this.result;
    },
    notify(type, msg, close=true) {
      this.msgType = type;
      this.displayMsg = msg !== '' ? msg : '';
      this.toolMsg = msg;
      this.closeNotify = close;
    },
    back() {
      this.actionBackButton = true;
      this.$router.push('/administrationOverview');
    },
    /**
     *  final service call to enter the Popup
     */
    confirmPopUp() {
      this.confirmActionPopup = true;
    },
    validatePopUpConfirm() {
      this.confirmActionPopup = false;
      this.deleteAdmin(this.selectedIdForDelete);
      },
    /**
     * cancel- function called when cancel button is clicked in popup
     */
    cancel() {
      this.confirmActionPopup = false;
    },
    deleteOperation(admin){
      this.selectedAction = 'deleteAdminButton';
      this.selectedIdForDelete = admin;
      this.confirmPopUp();
    },
    deleteAdmin(admin){
      this.deleteAdminServiceCall(admin);
      this.selectedAction = 'deleteAdminButton';
      this.confirmPopUp();
    },
    deleteAdminServiceCall(admin){
      console.warn(admin);

      this.notify('', '');
      this.enableSpinner = true;

      const PThis = this;
      appServices.deleteAdminServiceCall(admin).then((result) => {
        PThis.enableSpinner = false;
        console.log('result==>' + result);
        const queryToSend = {};
        if(admin.id!== undefined && !PThis.isEmpty(admin.id)){
          queryToSend.id= admin.id * 1;
        }
        console.log('queryToSend==>' + queryToSend);

        PThis.deleteAdminResponse = result;
        // identfier is true if delete is success
        if (PThis.deleteAdminResponse.data.indicatorSuccess) {
          PThis.$router.push('/administrationOverview');
        } else {
          PThis.notify('warning', 'LABEL_ERROR', true);
        }
      }).catch((error) => {
        console.log(error.response.data.errors[0]);
        PThis.enableSpinner = false;
        PThis.httpServiceErrorCall(error);
      });
    },
    isEmpty(str) {
      return (!str || 0 === str.length);
    },
    /*navtabFunction(){
      this.actionTab = true;
    },*/
  },
};
</script>
