import updateTermViewPanel from '@/components/updateTermViewPanel'
import {createLocalVue, shallowMount} from "@vue/test-utils";
/*import Notify from "@/components/Notify";
import ConfirmationPopUpTemplate from "@/components/ConfirmationPopUp";
import utils from "@/scripts/utils";
import appServices from "@/services/AppServices";*/
/*
import AdminOverviewSearchSuccessData from "./MockData/AdminOverviewSearchSuccessData.json";
*/
import term from "./MockData/TermsData.json";

const localVue = createLocalVue();


describe('should test updateTermViewPanel', () => {

    let wrapper;

    // const push = jest.fn();
    const $router = {
        push: jest.fn(),
        go: jest.fn()
    }

    beforeEach(() => {
        wrapper = shallowMount(updateTermViewPanel, {
            localVue,
            mocks: {
                $router,
                $t: () => {
                },
            },
            data() {
                return {
                    terms: ''
                }
            }
        });
    });

    it('should test notify method ', async () => {
        const notify = jest.spyOn(wrapper.vm, "notify");
        await notify();
        expect(notify).toHaveBeenCalled();
    });

    it('should test isEmpty method ', async () => {
        const isEmpty = jest.spyOn(wrapper.vm, "isEmpty");
        let value = null;
        await isEmpty(value);
        expect(isEmpty).toHaveBeenCalled();
    });

    it('should test facetCategoryChange method ', async () => {
        const facetCategoryChange = jest.spyOn(wrapper.vm, "facetCategoryChange");
        let obj = {'facetValue':"10", "facets": [{'facetValue':"123"}], 'validated':true}
        await facetCategoryChange(1,obj);
        expect(facetCategoryChange).toHaveBeenCalled();
    });

    it('should test getValidCombination method ', () => {
        let term = {};
        term.dataType = 'STRING'
        term.facetCategory = 'Single Value'
        wrapper.vm.getValidCombination(term);
        term.dataType = 'STRING'
        term.facetCategory = 'Range'
        wrapper.vm.getValidCombination(term);
        term.dataType = 'NUMERIC'
        term.facetCategory = 'Single Value'
        wrapper.vm.getValidCombination(term);
        term.dataType = 'NUMERIC'
        term.facetCategory = 'Range'
        wrapper.vm.getValidCombination(term);
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.getValidCombination()).toBeCalledTimes(1)
        // });
    });

    it('should test getValidfacetTypes method ', async () => {
        const getValidfacetTypes = jest.spyOn(wrapper.vm, "getValidfacetTypes");
        let obj =[
            {
                'facets': [undefined,
                    {
                        'showFlag' : 'false'
                    },
                    undefined,
                    {
                        "facetType": "List values",
                    },
                ],
                undefined,
                'facetCategory': [
                    {'showFlag' : 'false'
                    }
                ],'id': [
                    1
                ]
            }
        ]
        await getValidfacetTypes(0,0,obj,0);
        expect(getValidfacetTypes).toHaveBeenCalled();
    });

    it('should test getStringSingleValueDropdown method ', async () => {
        const getStringSingleValueDropdown = jest.spyOn(wrapper.vm, "getStringSingleValueDropdown");
        let allpossibleCombinations = [ "-1"];
        let selectedValues = [1,2,3];
        await getStringSingleValueDropdown(allpossibleCombinations,selectedValues,1);
        expect(getStringSingleValueDropdown).toHaveBeenCalled();
    });

    it('should test addMorefacetTypeValues method ', async () => {
        const addMorefacetTypeValues = jest.spyOn(wrapper.vm, "addMorefacetTypeValues");
        await addMorefacetTypeValues(term,0,0);
        expect(addMorefacetTypeValues).toHaveBeenCalled();
    });


    it('should test removeItemWithValue method ', async () => {
        const removeItemWithValue = jest.spyOn(wrapper.vm, "removeItemWithValue");
        let arr = [1,2]
        await removeItemWithValue(arr,0);
        expect(removeItemWithValue).toHaveBeenCalled();
    });

/*
    it('should test removefacetTypeValues method ', async () => {
        const removefacetTypeValues = jest.spyOn(wrapper.vm, "removefacetTypeValues");
        wrapper.vm.allpossibleCombinations = [ "-1"];
        wrapper.vm.selectedValues = [1,2,3];
        await removefacetTypeValues(0,term,1);
        expect(removefacetTypeValues).toHaveBeenCalled();
    });
*/

    it('should test isMandatorySelected method ', async () => {
        const isMandatorySelected = jest.spyOn(wrapper.vm, "isMandatorySelected");
        let term = {}
        term.mandatory= ''
        let term2 = {}
        term.mandatory= true
        await isMandatorySelected(term);
        await isMandatorySelected(term2);
        expect(isMandatorySelected).toHaveBeenCalled();
    });

    it('should test formatListValues method ', async () => {
        const formatListValues = jest.spyOn(wrapper.vm, "formatListValues");
        let tempValue = "abcd,efghi"
        await formatListValues(tempValue);
        expect(formatListValues).toHaveBeenCalled();
    });

    it('should test hasDuplicates method ', async () => {
        const hasDuplicates = jest.spyOn(wrapper.vm, "hasDuplicates");
        let selectedTerms = ['abcd','123','123','456']
        await hasDuplicates(selectedTerms);
        expect(hasDuplicates).toHaveBeenCalled();
    });

    it('should test checkGreaterOrEqual method ', async () => {
        const checkGreaterOrEqual = jest.spyOn(wrapper.vm, "checkGreaterOrEqual");
        await checkGreaterOrEqual(1,2);
        await checkGreaterOrEqual(1,1);
        expect(checkGreaterOrEqual).toHaveBeenCalled();
    });

    it('should test isSpecialCharacterPresentInFacetValue method ', async () => {
        const isSpecialCharacterPresentInFacetValue = jest.spyOn(wrapper.vm, "isSpecialCharacterPresentInFacetValue");
        let input = {}
        input.facetValue = "\u6f22\u5b57";
        let term2 = {"validated": true}
        await isSpecialCharacterPresentInFacetValue(input,term2);
        expect(isSpecialCharacterPresentInFacetValue).toHaveBeenCalled();
    });

    it('should test showConfirmDeleteTerm method ', async () => {
        const showConfirmDeleteTerm = jest.spyOn(wrapper.vm, "showConfirmDeleteTerm");
        let term = {id:1}
        wrapper.vm.selectedIdForDelete = term;
        wrapper.vm.tabsData = [term]
        await showConfirmDeleteTerm();
        expect(showConfirmDeleteTerm).toHaveBeenCalled();
    });

    it('should test checkForSpecialCharacters method ', async () => {
        const checkForSpecialCharacters = jest.spyOn(wrapper.vm, "checkForSpecialCharacters");
        let event={};
        event.keyCode = "";
        event.target = {};
        event.target.innerHTML = "undefined";
        await checkForSpecialCharacters(0,event,1,"1");
        event.target.innerHTML = undefined;
        await checkForSpecialCharacters(0,event,1,"1");
        expect(checkForSpecialCharacters).toHaveBeenCalled();
    });

    it('should test checkToDeleteCharacters method ', async () => {
        const checkToDeleteCharacters = jest.spyOn(wrapper.vm, "checkToDeleteCharacters");
        let event={}
        event.target = {};
        event.target.innerHTML = "123";
        await checkToDeleteCharacters(0,event,1,"1");
        expect(checkToDeleteCharacters).toHaveBeenCalled();
    });
    it('should test checkEnumValue method ', async () => {
        const checkEnumValue = jest.spyOn(wrapper.vm, "checkEnumValue");
        let term = {
            "id": 51,
            "name": "NewTestterm",
            "dataType": "BOOLEAN",
            "facets": [
                {
                    "facetType": "MAXLENGTH",
                    "facetValue": '',
                    "showFlag": true
                },
                {
                    "facetType": "MAXLENGTH",
                    "facetValue": '',
                    "showFlag": true
                }
            ],
            "facetValue":"",
            'facetCategory': "List | Range" ,
            "showMessage": '',
            "validated": true,
            "errorMsgLabel": "",
            'isSpecialCharPresentInFacetValue': ''
        }
        await checkEnumValue(term);
        term.facetValue = "\u6f22\u5b57";
        await checkEnumValue(term);
        expect(checkEnumValue).toHaveBeenCalled();
    });

    it('should test validateTermFacets method ', async () => {
        const validateTermFacets = jest.spyOn(wrapper.vm, "validateTermFacets");
        let term2 = {"errorMsgLabel":true}
        await validateTermFacets(0,term2,0);
        await validateTermFacets(0,0,0);
        expect(validateTermFacets).toHaveBeenCalled();
    });

    it('should test confirmPopUp method ', async () => {
        const confirmPopUp = jest.spyOn(wrapper.vm, "confirmPopUp");
        await confirmPopUp();
        expect(confirmPopUp).toHaveBeenCalled();
    });

    it('should test cancel method ', async () => {
        const cancel = jest.spyOn(wrapper.vm, "cancel");
        await cancel();
        expect(cancel).toHaveBeenCalled();
    });

    it('should test validatePopUpConfirm method ', async () => {
        const validatePopUpConfirm = jest.spyOn(wrapper.vm, "validatePopUpConfirm");
        let term = {id:1};
        wrapper.vm.selectedIdForDelete = term;
        wrapper.vm.tabsData = [term];
        await validatePopUpConfirm();
        expect(validatePopUpConfirm).toHaveBeenCalled();
    });

    it('should test deleteTermTabFunction method ', async () => {
        const deleteTermTabFunction = jest.spyOn(wrapper.vm, "deleteTermTabFunction");
        let term = {id:1};
        wrapper.vm.selectedIdForDelete = term;
        wrapper.vm.tabsData = [term];
        await deleteTermTabFunction();
        expect(deleteTermTabFunction).toHaveBeenCalled();
    });

    it('should test deleteTermTab method ', async () => {
        const deleteTermTab = jest.spyOn(wrapper.vm, "deleteTermTab");
        let term = {id:1};
        wrapper.vm.selectedIdForDelete = term;
        wrapper.vm.tabsData = [term];
        await deleteTermTab();
        expect(deleteTermTab).toHaveBeenCalled();
    })

    it('should test updateMandatoryFlag method ', async () => {
        const updateMandatoryFlag = jest.spyOn(wrapper.vm, "updateMandatoryFlag");
        await updateMandatoryFlag(term,0);
        await updateMandatoryFlag(term,1);
        expect(updateMandatoryFlag).toHaveBeenCalled();
    })


/*    it('should test getValidfacetTypesOnChange method ', async () => {
        const getValidfacetTypesOnChange = jest.spyOn(wrapper.vm, "getValidfacetTypesOnChange");
        let event = {}; let index = 1; let obj = term;
        wrapper.vm.selectedValues = [1,2,3];
        wrapper.vm.allpossibleCombinations = ["-1"]
        await getValidfacetTypesOnChange(event, index, obj);
        expect(getValidfacetTypesOnChange).toHaveBeenCalled();

    });*/
});


