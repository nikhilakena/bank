import utils from '@/scripts/utils';

import { shallowMount, createLocalVue } from '@vue/test-utils';

const localVue = createLocalVue();

describe("utils", () => {
    // eslint-disable-next-line no-unused-vars
    let wrapper;
    beforeEach(() => {
        wrapper = shallowMount(utils, {
            localVue,
            mocks: {
                $t: () => {
                }
            },
            data() {
                return {}
            }
        });
    });

    it('should test removeMultipleSpace method ', () => {
        expect(typeof utils.removeMultipleSpace).toBe('function');
    });

    it('should test isEmpty method ', () => {
        expect(typeof utils.isEmpty).toBe('function');
    });

});