import termViewPanel from '@/components/termViewPanel';
import { createLocalVue, shallowMount } from '@vue/test-utils';
import Notify from '@/components/Notify';
import ConfirmationPopUpTemplate from '@/components/ConfirmationPopUp';

const localVue = createLocalVue();

describe('should test termViewPanel', () => {
    // eslint-disable-next-line no-unused-vars
    let wrapper;
    let term = {
        id: 51,
        name: 'NewTestterm',
        dataType: 'BOOLEAN',
        facetValue: '12,34',
        facets: [
            {
                facetType: 'MAXLENGTH',
                facetValue: '123',
                showFlag: true,
            },
            {
                facetType: 'MAXLENGTH',
                facetValue: '456',
                showFlag: true,
            },
            {
                facetType: 'ENUMERATION',
            },
            {
                facetType: 'LENGTH',
            },
            {
                facetType: 'PATTERN',
            },
            {
                facetType: 'MAXLENGTH',
            },
            {
                facetType: 'MINLENGTH',
            },
            {
                facetType: 'MININCLUSIVE',
            },
            {
                facetType: 'MAXINCLUSIVE',
            },
            {
                facetType: 'MINEXCLUSIVE',
            },
            {
                facetType: 'MAXEXCLUSIVE',
            },
            {
                facetType: 'TOTALDIGITS',
            },
            {
                facetType: 'FRACTIONS',
            },
        ],
        facetCategory: 'List | Range',
        showMessage: '',
        validated: true,
        errorMsgLabel: '',
        isSpecialCharPresentInFacetValue: true,
        mandatory: true,
        showFlag: true,
    };
    beforeEach(() => {
        wrapper = shallowMount(termViewPanel, {
            localVue,
            mocks: {
                $t: () => {},
            },
            propsData: {
                actionTab: 'actionTab',
                tabsData: '',
            },
            data() {
                return {};
            },
        });
    });

    it('should test name termViewPanel', () => {
        expect(termViewPanel.name).toBe('termViewPanel');
        expect(typeof termViewPanel.name).toBe('string');
    });

    it('should test vue data and component', () => {
        expect(typeof termViewPanel.data).toBe('function');
        expect(termViewPanel.props).toEqual({
            actionTab: { type: null },
            tabsData: { type: null },
        });
        expect(termViewPanel.components).toStrictEqual({
            Notify,
            ConfirmationPopUpTemplate,
        });
    });

    it('should test notify method', async () => {
        const notify = jest.spyOn(wrapper.vm, 'notify');
        await notify();
        expect(notify).toHaveBeenCalled();
    });

    it('should test cancel method', async () => {
        const cancel = jest.spyOn(wrapper.vm, 'cancel');
        await cancel();
        expect(cancel).toHaveBeenCalled();
    });

    it('should test confirmPopUp method', async () => {
        const confirmPopUp = jest.spyOn(wrapper.vm, 'confirmPopUp');
        await confirmPopUp();
        expect(confirmPopUp).toHaveBeenCalled();
    });


    it('should test validatePopUpConfirm method', async () => {
        const validatePopUpConfirm = jest.spyOn(wrapper.vm, 'validatePopUpConfirm');
        wrapper.vm.selectedIdForDelete = term;
        wrapper.vm.tabsData = [term]
        await validatePopUpConfirm();
        expect(validatePopUpConfirm).toHaveBeenCalled();
    });


    it('should test deleteTermTabFunction method', async () => {
        const deleteTermTabFunction = jest.spyOn(wrapper.vm, 'deleteTermTabFunction');
        wrapper.vm.selectedIdForDelete = term;
        wrapper.vm.tabsData = [term]
        await deleteTermTabFunction();
        expect(deleteTermTabFunction).toHaveBeenCalled();
    });


    it('should test deleteTermTab method', async () => {
        const deleteTermTab = jest.spyOn(wrapper.vm, 'deleteTermTab');
        await deleteTermTab();
        expect(deleteTermTab).toHaveBeenCalled();
    });

    /*it('should test showConfirmDeleteTerm method',async () => {
          const showConfirmDeleteTerm = jest.spyOn(wrapper.vm, "showConfirmDeleteTerm");
          await showConfirmDeleteTerm();
          expect(showConfirmDeleteTerm).toHaveBeenCalled();
      });*/

    /*it('should test facetCategoryChange method',() => {
          expect(typeof wrapper.vm.facetCategoryChange).toBe('function');
      });*/

    it('should test facetCategoryChange method ', async () => {
        const facetCategoryChange = jest.spyOn(wrapper.vm, 'facetCategoryChange');
        let obj = {
            facetValue: '10',
            facets: [{ facetValue: '123' }],
            validated: true,
        };
        await facetCategoryChange(1, obj);
        expect(facetCategoryChange).toHaveBeenCalled();
    });

    it('should test getValidfacetTypesOnClick method', () => {
        expect(typeof wrapper.vm.getValidfacetTypesOnClick).toBe('function');
    });

    /*it('should test getValidCombination method',() => {
          expect(typeof wrapper.vm.getValidCombination).toBe('function');
      });*/

    it('should test getValidCombination method', () => {
        let term = {};
        term.dataType = 'STRING';
        term.facetCategory = 'Single Value';
        wrapper.vm.getValidCombination(term);
        term.dataType = 'STRING';
        term.facetCategory = 'Range';
        wrapper.vm.getValidCombination(term);
        term.dataType = 'NUMERIC';
        term.facetCategory = 'Single Value';
        wrapper.vm.getValidCombination(term);
        term.dataType = 'NUMERIC';
        term.facetCategory = 'Range';
        wrapper.vm.getValidCombination(term);
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.getValidCombination()).toBeCalledTimes(1)
        // });
    });

    /*it('should test getValidfacetTypes method',() => {
          expect(typeof wrapper.vm.getValidfacetTypes).toBe('function');
      });*/
    it('should test getValidfacetTypes method', async () => {
        const getValidfacetTypes = jest.spyOn(wrapper.vm, 'getValidfacetTypes');
        let obj = [
            {
                facets: [
                    undefined,
                    {
                        showFlag: 'false',
                    },
                    undefined,
                    {
                        facetType: 'List values',
                    },
                ],
                undefined,
                facetCategory: [{ showFlag: 'false' }],
                id: [1],
            },
        ];
        wrapper.vm.allpossibleCombinations = ['-1'];
        wrapper.vm.selectedValues = [1, 2, 3];
        await getValidfacetTypes(0, 0, obj, 0);
        expect(getValidfacetTypes).toHaveBeenCalled();
    });

    /*it('should test getStringSingleValueDropdown method',() => {
          expect(typeof wrapper.vm.getStringSingleValueDropdown).toBe('function');
      });*/
    it('should test getStringSingleValueDropdown method ', async () => {
        const getStringSingleValueDropdown = jest.spyOn(wrapper.vm, 'getStringSingleValueDropdown');
        let allpossibleCombinations = ['-1'];
        let selectedValues = [1, 2, 3];
        await getStringSingleValueDropdown(allpossibleCombinations, selectedValues, 1);
        expect(getStringSingleValueDropdown).toHaveBeenCalled();
    });

    it('should test getUniqueArray method', () => {
        expect(typeof wrapper.vm.getUniqueArray).toBe('function');
    });

    it('should test removeSelectedFacetsFromAllowed method', () => {
        expect(typeof wrapper.vm.removeSelectedFacetsFromAllowed).toBe('function');
    });

    it('should test getAllStringSubFacets method', () => {
        expect(typeof wrapper.vm.getAllStringSubFacets).toBe('function');
    });

    it('should test addMorefacetTypeValues method ', async () => {
        const addMorefacetTypeValues = jest.spyOn(wrapper.vm, 'addMorefacetTypeValues');
        await addMorefacetTypeValues(term, 0, 1);
        /*let term2 = term; term2.facets[1].facetValue= "";
        await addMorefacetTypeValues(term,0,1);*/
        expect(addMorefacetTypeValues).toHaveBeenCalled();
    });

    /*it('should test removeItemWithValue method',() => {
          expect(typeof wrapper.vm.removeItemWithValue).toBe('function');
      });*/
    it('should test removeItemWithValue method ', async () => {
        const removeItemWithValue = jest.spyOn(wrapper.vm, 'removeItemWithValue');
        let arr = [1, 2];
        await removeItemWithValue(arr, 0);
        expect(removeItemWithValue).toHaveBeenCalled();
    });

    it('should test removefacetTypeValues method', () => {
        expect(typeof wrapper.vm.removefacetTypeValues).toBe('function');
    });

/*    it('should test getValidfacetTypesOnChange method ', async () => {
        const getValidfacetTypesOnChange = jest.spyOn(wrapper.vm, 'getValidfacetTypesOnChange');
        let obj = term;
        obj.validated = true;
        wrapper.vm.allpossibleCombinations = [term];
        wrapper.vm.selectedValues = [1, 2, 3];
        await getValidfacetTypesOnChange({}, 1, obj);
        await getValidfacetTypesOnChange({}, 0, obj);
        expect(getValidfacetTypesOnChange).toHaveBeenCalled();
    });*/

    /*it('should test validateTermFacets method',() => {
          expect(typeof wrapper.vm.validateTermFacets).toBe('function');
      });*/
    it('should test validateTermFacets method ', async () => {
        const validateTermFacets = jest.spyOn(wrapper.vm, 'validateTermFacets');
        let ab = {"errorMsgLabel": true};
        await validateTermFacets(0, ab, 0);
        expect(validateTermFacets).toHaveBeenCalled();
    });

        it('should test showConfirmDeleteTerm method ', async () => {
        const showConfirmDeleteTerm = jest.spyOn(wrapper.vm, "showConfirmDeleteTerm");
            wrapper.vm.selectedIdForDelete = term;
            wrapper.vm.tabsData = [term]
        await showConfirmDeleteTerm();
        expect(showConfirmDeleteTerm).toHaveBeenCalled();
    });

    it('should test isSpecialCharacterPresentInFacetValue method ', async () => {
        const isSpecialCharacterPresentInFacetValue = jest.spyOn(wrapper.vm, 'isSpecialCharacterPresentInFacetValue');
        let input = {};
        input.facetValue = '\u6f22\u5b57';
        let term = { validated: true };
        await isSpecialCharacterPresentInFacetValue(input, term);
        input.facetValue = '';
        await isSpecialCharacterPresentInFacetValue(input, term);
        expect(isSpecialCharacterPresentInFacetValue).toHaveBeenCalled();
    });

    /*it('should test checkForSpecialCharacters method',() => {
          expect(typeof wrapper.vm.checkForSpecialCharacters).toBe('function');
      });*/
    it('should test checkForSpecialCharacters method', async () => {
        const checkForSpecialCharacters = jest.spyOn(wrapper.vm, 'checkForSpecialCharacters');
        let event = {};
        event.target = {};
        event.target.innerHTML = undefined;
        await checkForSpecialCharacters(0, event, 1, '1');
        expect(checkForSpecialCharacters).toHaveBeenCalled();
    });

    it('should test checkForSpecialCharacters method ', async () => {
        const checkForSpecialCharacters = jest.spyOn(wrapper.vm, 'checkForSpecialCharacters');
        let _index = 0;
        let $event = { target: { innerHTML: '' } };
        let _maxlength = 1;
        let inputData = 'abcd';
        await checkForSpecialCharacters(_index, $event, _maxlength, inputData);
        expect(checkForSpecialCharacters).toHaveBeenCalled();
    });

    it('should test checkToDeleteCharacters method ', async () => {
        const checkToDeleteCharacters = jest.spyOn(wrapper.vm, 'checkToDeleteCharacters');
        let _index = 0;
        let $event = { target: { innerHTML: '123' } };
        let _maxlength = 1;
        let inputData = 'abcd';
        await checkToDeleteCharacters(_index, $event, _maxlength, inputData);
        expect(checkToDeleteCharacters).toHaveBeenCalled();
    });

    /*it('should test checkEnumValue method',() => {
          expect(typeof wrapper.vm.checkEnumValue).toBe('function');
      });*/
    it('should test checkEnumValue method', async () => {
        const checkEnumValue = jest.spyOn(wrapper.vm, 'checkEnumValue');
        let term = {
            id: 51,
            name: 'NewTestterm',
            dataType: 'BOOLEAN',
            facets: [
                {
                    facetType: 'MAXLENGTH',
                    facetValue: '',
                    showFlag: true,
                },
                {
                    facetType: 'MAXLENGTH',
                    facetValue: '',
                    showFlag: true,
                },
            ],
            facetCategory: 'List | Range',
            showMessage: '',
            validated: true,
            errorMsgLabel: '',
            isSpecialCharPresentInFacetValue: '',
        };
        term.facetValue = '';
        await checkEnumValue(term);
        term.facetValue = '\u6f22\u5b57';
        await checkEnumValue(term);
        term.facetValue = 'hi';
        await checkEnumValue(term);
        expect(checkEnumValue).toHaveBeenCalled();
    });

    it('should test validateUnicode method ', async () => {
        const validateUnicode = jest.spyOn(wrapper.vm, 'validateUnicode');
        let input = '\u6f22\u5b57';
        await validateUnicode(input);
        expect(validateUnicode).toHaveBeenCalled();
    });
});
