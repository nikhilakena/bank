import createTerm from '@/views/app/gpaaglossaryconfigwidget/modules/createterm/createTerm';
import {createLocalVue, shallowMount} from "@vue/test-utils";
import BackButton from "@/components/BackButton";
import Notify from "@/components/Notify";
import ConfirmationPopUpTemplate from "@/components/ConfirmationPopUp";
import term from "./MockData/TermsData.json";

const localVue = createLocalVue();


describe('should test createTerm', () => {

    let wrapper;

    //const push = jest.fn();
    const $router = {
        push: jest.fn(),
        go: jest.fn()
    }

    beforeEach(() => {
        wrapper = shallowMount(createTerm, {
            localVue,
            mocks: {
                $router,
                $t: () => {
                },
            },
            data() {
                return {}
            }
        });
    });

    it('has name createTerm', () => {
        expect(createTerm.name).toBe('createTerm');
        expect(typeof createTerm.name).toBe('string');
    });

    it('should test vue data and component', () => {
        expect(typeof createTerm.data).toBe('function');
        expect(createTerm.components).toStrictEqual({
            Notify,ConfirmationPopUpTemplate,BackButton
        });
    });

    it('should test notify method createTerm',async () => {
        const notify = jest.spyOn(wrapper.vm, "notify");
        await notify();
        expect(notify).toHaveBeenCalled();
    });

    it("should test confirmPopUp method createTerm", async() => {
        const confirmPopUp = jest.spyOn(wrapper.vm, "confirmPopUp");
        await confirmPopUp();
        expect(confirmPopUp).toHaveBeenCalled();
    });

    it('should test back method createTerm', async() => {
        const back = jest.spyOn(wrapper.vm, "back");
        await back();
        expect(back).toHaveBeenCalled();
    });

    it('should test cancel method createTerm', async() => {
        const cancel = jest.spyOn(wrapper.vm, "cancel");
        await cancel();
        expect(cancel).toHaveBeenCalled();
    });

    it('should test validatePopUpConfirm method with backButton createTerm', async() => {
        wrapper.vm.selectedAction ='backButton';
        wrapper.vm.validatePopUpConfirm();

        const back = jest.spyOn(wrapper.vm, "back");
        await back();
        expect(back).toHaveBeenCalled();
        // expect(push).toHaveBeenCalledWith('createTerm');
    });

    it('should test validatePopUpConfirm method with saveButton createTerm', async() => {
        wrapper.vm.selectedAction ='saveButton';
        wrapper.vm.confirmActionPopup = false;
        wrapper.vm.validatePopUpConfirm();
    });

    it('should test save method createTerm', async() => {
        const save = jest.spyOn(wrapper.vm, "save");
        await save();
        expect(save).toHaveBeenCalled();
    });

    it('should test saveTerm method createTerm', async() => {
        const saveTerm = jest.spyOn(wrapper.vm, "saveTerm");
        wrapper.vm.term = {}
        wrapper.vm.term.name = "a"
        wrapper.vm.term.description = "a"
        wrapper.vm.term.datatype = "STRING"
        wrapper.vm.term.nameErrorFlag = false;
        wrapper.vm.term.isSpecialCharPresentInName = false;
        wrapper.vm.term.descErrorFlag = false;
        wrapper.vm.term.isSpecialCharPresentInDesc = false;
        await saveTerm();
        expect(saveTerm).toHaveBeenCalled();
    });

    /*it('should test processCreatetermResponse method createTerm', async() => {
        const processCreatetermResponse = jest.spyOn(wrapper.vm, "processCreatetermResponse");
        await processCreatetermResponse();
        expect(processCreatetermResponse).toHaveBeenCalled();
    });*/

    it('should test termTypeChanged method ', async () => {
        const termTypeChanged = jest.spyOn(wrapper.vm, "termTypeChanged");
        let event = {};
        event.detail= {};
        await termTypeChanged(event);
        expect(termTypeChanged).toHaveBeenCalled();
    });

    it('should test httpServiceErrorCall method ', async () => {
        const httpServiceErrorCall = jest.spyOn(wrapper.vm, "httpServiceErrorCall");
        const arrErrors= [{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 500,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 403,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 404,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 405,
        },{
            "data": {
                "errors": [
                    {
                        "code": null,
                        "params": null
                    }
                ]
            },
            "status": 503,
        }]
        await httpServiceErrorCall(arrErrors[0]);
        await httpServiceErrorCall(arrErrors[1]);
        await httpServiceErrorCall(arrErrors[2]);
        await httpServiceErrorCall(arrErrors[3]);
        await httpServiceErrorCall(arrErrors[4]);
        expect(httpServiceErrorCall).toHaveBeenCalled();
    });

    it('should test processCreatetermResponse method ', async () => {
        const processCreatetermResponse = jest.spyOn(wrapper.vm, "processCreatetermResponse");
        let response = {}
        response.data = {}
        let term = {}
        await processCreatetermResponse(response, term);
        expect(processCreatetermResponse).toHaveBeenCalled();
    });

    it('should test validateSpecialChars method ', async () => {
        const validateSpecialChars = jest.spyOn(wrapper.vm, "validateSpecialChars");
        wrapper.vm.term = {};
        wrapper.vm.term.nameErrorFlag = true;
        wrapper.vm.term.isSpecialCharPresentInName = true;
        wrapper.vm.term.descErrorFlag = true;
        wrapper.vm.term.isSpecialCharPresentInDesc = true;
        await validateSpecialChars();
        wrapper.vm.term.nameErrorFlag = false;
        wrapper.vm.term.isSpecialCharPresentInName = false;
        wrapper.vm.term.descErrorFlag = false;
        wrapper.vm.term.isSpecialCharPresentInDesc = false;
        await validateSpecialChars();
        expect(validateSpecialChars).toHaveBeenCalled();
    });

/*    it('should test termTypeItems method ', async () => {
        const termTypeItems = jest.spyOn(wrapper.vm, "termTypeItems");
        await termTypeItems();
        expect(termTypeItems).toHaveBeenCalled();
    });*/

    it('should test validateCreateTermParms method ', async () => {
        const validateCreateTermParms = jest.spyOn(wrapper.vm, "validateCreateTermParms");
        wrapper.vm.term = {}
        wrapper.vm.term.name = ""
        wrapper.vm.term.description = ""
        wrapper.vm.term.datatype = "0"
        wrapper.vm.term.datatype = ""
        await validateCreateTermParms();
        wrapper.vm.term.name = "a"
        wrapper.vm.term.description = "a"
        wrapper.vm.term.datatype = "STRING"
        await validateCreateTermParms();
        expect(validateCreateTermParms).toHaveBeenCalled();
    });











});