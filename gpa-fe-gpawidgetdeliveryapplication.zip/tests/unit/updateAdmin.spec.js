import updateAdmin from '@/views/app/gpaaadminconfigwidget/modules/updateadmin/updateAdmin';
import {createLocalVue, shallowMount} from "@vue/test-utils";
import BackButton from "@/components/BackButton";
import Notify from "@/components/Notify";
import ConfirmationPopUpTemplate from "@/components/ConfirmationPopUp";
import updateTermViewPanel from "@/components/updateTermViewPanel";
import utils from "@/scripts/utils";
import appServices from "@/services/AppServices";
import term from "./MockData/TermsData.json";
import AppServices from "@/services/AppServices";
/*
import AdminOverviewSearchSuccessData from "./MockData/AdminOverviewSearchSuccessData.json";
*/

const localVue = createLocalVue();


describe('should test updateAdmin', () => {

    let wrapper;

    // const push = jest.fn();
    const $router = {
        push: jest.fn(),
        go: jest.fn()
    }

    beforeEach(() => {
        wrapper = shallowMount(updateAdmin, {
            localVue,
            mocks: {
                $router,
                $t: () => {
                },
            },
            data() {
                return {
                    terms: ''
                }
            }
        });
    });

    // it('has name updateAdmin', () => {
    //     expect(updateAdmin.name).toBe('updateAdmin');
    //     expect(typeof updateAdmin.name).toBe('string');
    // });

/*
    it('should test async mounted in UpdateAdmin ',()=>{
        // wrapper.vm.$nextTick(()=>{
            wrapper.vm.queryToSend = {};
            expect(wrapper.vm.mounted).toBeCalledTimes(1);
            // expect(wrapper.vm.mounted).toBe('function');
        // })
    });
*/

    it('has name updateAdmin', () => {
        expect(updateAdmin.name).toBe('updateAdministration');
        expect(typeof updateAdmin.name).toBe('string');
    });

    it('should test vue data and component', () => {
        expect(typeof updateAdmin.data).toBe('function');
        expect(updateAdmin.components).toStrictEqual({
            BackButton,Notify, ConfirmationPopUpTemplate,updateTermViewPanel
        });
    });

/*    it('should test notify method updateAdmin',() => {
        wrapper.vm.notify();

        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.notify()).toBeCalledTimes(1)
        // });
    });*/
    it('should test notify method ', async () => {
        const notify = jest.spyOn(wrapper.vm, "notify");
        await notify();
        expect(notify).toHaveBeenCalled();
    });


    it('should test confirmPopUp method ', async () => {
        const confirmPopUp = jest.spyOn(wrapper.vm, "confirmPopUp");
        await confirmPopUp();
        expect(confirmPopUp).toHaveBeenCalled();
    });

    it('should test back method updateAdmin', async () => {
        const back = jest.spyOn(wrapper.vm, "back");
        await back();
        expect(back).toHaveBeenCalled();
    });


    it('should test cancel method updateAdmin', async () => {
        const cancel = jest.spyOn(wrapper.vm, "cancel");
        await cancel();
        expect(cancel).toHaveBeenCalled();
    });

    it('should test cancel validatePopUpConfirm updateAdmin', async () => {
        wrapper.vm.selectedAction ='backButton';
        const validatePopUpConfirm = jest.spyOn(wrapper.vm, "validatePopUpConfirm");
        await validatePopUpConfirm();
        expect(validatePopUpConfirm).toHaveBeenCalled();
    });



/*    it('checks selectUsers in updateAdmin ', () => {
        wrapper.vm.selectedTerms= [123445];
        wrapper.vm.selectUsers(123445); // if case
        wrapper.vm.selectUsers(123456); // else case
    });*/

    it('should test selectUsers method ', async () => {
        const selectUsers = jest.spyOn(wrapper.vm, "selectUsers");
        wrapper.vm.selectedTerms= [123445];
        await selectUsers(123445);
        await selectUsers(123456);
        expect(selectUsers).toHaveBeenCalled();
    });

    /*    it('should test unselectAll method updateAdmin', () => {
            wrapper.vm.unselectAll();
            wrapper.vm.$nextTick(() => {
                expect(wrapper.vm.forEach()).toBeCalledTimes(1)
                expect(wrapper.vm.unselectAll()).toBeCalledTimes(1)
            });
        });

        it('should test selectAll method updateAdmin', () => {
            wrapper.vm.selectAll();
            wrapper.vm.$nextTick(() => {
                expect(wrapper.vm.selectAll()).toBeCalledTimes(1)
            });
        });


*/

/*    it('should test checkDuplicateTerms method updateAdmin', () => {
        wrapper.vm.selectedTerms= [123445];
        wrapper.vm.checkDuplicateTerms(123445);
        wrapper.vm.checkDuplicateTerms(123446);
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.notify()).toBeCalledTimes(1)
            expect(wrapper.vm.checkDuplicateTerms()).toBeCalledTimes(1)
        });
    });*/

/*    it('should test checkDuplicateTerms method ', async () => {
        const checkDuplicateTerms = jest.spyOn(wrapper.vm, "checkDuplicateTerms");
        wrapper.vm.selectedTerms= [123445];
        await checkDuplicateTerms(123445);
        await checkDuplicateTerms(123446);
        expect(checkDuplicateTerms).toHaveBeenCalled();
    });*/


/*    it('should test saveTermsInAdmin method updateAdmin', () => {
        wrapper.vm.selectedTerms= undefined;
        wrapper.vm.terms = [{
            "id": 1,
            "name": "Datum ondertekening contract",
            "dataType": "DATE",
            "description": "Date when the contract was signed",
            "facets": null,
            "auditDetails": {
                "createdBy": "C57909",
                "createdTimeStamp": 1567756605730,
                "modifiedBy": null,
                "modifiedTimeStamp": 1628289144258
            },
            "mandatory": false,
            "display": ''
        },{
            "id": 2,
            "name": "IBAN",
            "dataType": "STRING",
            "description": "IBAN is used by the customer",
            "facets": null,
            "auditDetails": {
                "createdBy": "C57909",
                "createdTimeStamp": 1567757170506,
                "modifiedBy": null,
                "modifiedTimeStamp": 1628289144258
            },
            "mandatory": false,
            "display": ''
        },{
            "id": 4,
            "name": "Naam ondertekenaar",
            "dataType": "STRING",
            "description": "Name of the person who signed the contract",
            "facets": null,
            "auditDetails": {
                "createdBy": "C57909",
                "createdTimeStamp": 1567757288006,
                "modifiedBy": null,
                "modifiedTimeStamp": 1628289144258
            },
            "mandatory": false,
            "display": true,
            "selected": true,
            "facetTypeValueList": [
                {
                    "singleValueFacets": [
                        "Length",
                        "Pattern",
                        "Maximum length",
                        "Minimum length"
                    ]
                }
            ]
        }]
        wrapper.vm.saveTermsInAdmin();
    });*/

    it('should test saveTermsInAdmin method ', async () => {
        const saveTermsInAdmin = jest.spyOn(wrapper.vm, "saveTermsInAdmin");
        wrapper.vm.selectedTerms= undefined;
        wrapper.vm.terms = [{
            "id": 1,
            "name": "Datum ondertekening contract",
            "dataType": "DATE",
            "description": "Date when the contract was signed",
            "facets": null,
            "auditDetails": {
                "createdBy": "C57909",
                "createdTimeStamp": 1567756605730,
                "modifiedBy": null,
                "modifiedTimeStamp": 1628289144258
            },
            "mandatory": false,
            "display": ''
        },{
            "id": 2,
            "name": "IBAN",
            "dataType": "STRING",
            "description": "IBAN is used by the customer",
            "facets": null,
            "auditDetails": {
                "createdBy": "C57909",
                "createdTimeStamp": 1567757170506,
                "modifiedBy": null,
                "modifiedTimeStamp": 1628289144258
            },
            "mandatory": false,
            "display": ''
        },{
            "id": 4,
            "name": "Naam ondertekenaar",
            "dataType": "STRING",
            "description": "Name of the person who signed the contract",
            "facets": null,
            "auditDetails": {
                "createdBy": "C57909",
                "createdTimeStamp": 1567757288006,
                "modifiedBy": null,
                "modifiedTimeStamp": 1628289144258
            },
            "mandatory": false,
            "display": true,
            "selected": true,
            "facetTypeValueList": [
                {
                    "singleValueFacets": [
                        "Length",
                        "Pattern",
                        "Maximum length",
                        "Minimum length"
                    ]
                }
            ]
        }]
        await saveTermsInAdmin();
        expect(saveTermsInAdmin).toHaveBeenCalled();
    });



/*        it('should test showTerm method updateAdmin', () => {
            // wrapper.vm.name ='';
            let term = {};
            term.name = ["hello"]
            wrapper.vm.showTerm(term);
            wrapper.vm.$nextTick(() => {
                expect(wrapper.vm.showTerm(term)).toBeCalledTimes(1)
            });
        });*/

    it('should test showTerm method ', async () => {
        const showTerm = jest.spyOn(wrapper.vm, "showTerm");
        let term = {};
        term.name = ["hello"]
        await showTerm(term);
        expect(showTerm).toHaveBeenCalled();
    });


/*    it('should test invalidProductListFormat method updateAdmin', () => {
        let obj = {};
        obj.push = undefined;
        // wrapper.vm.invalidProductListFormat(obj);
        wrapper.vm.invalidProductListFormat(obj);
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.invalidProductListFormat(obj)).toBeCalledTimes(1)
        // });
    });*/

    it('should test invalidProductListFormat method ', async () => {
        const invalidProductListFormat = jest.spyOn(wrapper.vm, "invalidProductListFormat");
        let obj = {};
        obj.push = undefined;
        await invalidProductListFormat(obj);
        expect(invalidProductListFormat).toHaveBeenCalled();
    });


/*    it('should test hasDuplicatesPrducts method ', () => {
        let array = [
            5525,
            '5525', null
        ];
        wrapper.vm.hasDuplicatesPrducts([]);
        wrapper.vm.hasDuplicatesPrducts(array);
    });*/


    it('should test hasDuplicatesPrducts method ', async () => {
        const hasDuplicatesPrducts = jest.spyOn(wrapper.vm, "hasDuplicatesPrducts");
        let array = [
            5525,
            '5525', null
        ];
        await hasDuplicatesPrducts([]);
        await hasDuplicatesPrducts(array);
        expect(hasDuplicatesPrducts).toHaveBeenCalled();
    });



/*    it('should test updateAdmin method ', () => {
        let admin2 = {
            "id": 11,
            "name": "test2",
            "description": "final_test6",
            "oarId": "AAB.SYS.33333",
            "terms": [
                {
                    "id": 1,
                    "name": "Datum ondertekening contract",
                    "dataType": "DATE",
                    "description": "Date when the contract was signed",
                    "facets": null,
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1666163907630,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667808808086
                    },
                    "mandatory": true,
                    "facetType": "List values"
                },
                {
                    "id": 2,
                    "name": "IBAN",
                    "dataType": "STRING",
                    "description": "IBAN is used by the customer",
                    "facets": [
                        {
                            "facetType": "MAXLENGTH",
                            "facetValue": "10",
                            "auditDetails": {
                                "createdBy": "S03531",
                                "createdTimeStamp": 1667822403216,
                                "modifiedBy": null,
                                "modifiedTimeStamp": 1667822402995
                            },
                            "availableFacets": [
                                "Maximum length",
                                "Minimum length",
                                "Pattern",
                                "Length"
                            ],
                            "showFlag": true
                        }
                    ],
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1665538622865,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667822403216
                    },
                    "mandatory": false,
                    "facetCategory": "Single Value",
                    "facetType": "List values"
                },
                {
                    "id": 4,
                    "name": "Naam ondertekenaar",
                    "dataType": "STRING",
                    "description": "Name of the person who signed the contract",
                    "facets": [
                        {
                            "facetType": "ENUMERATION",
                            "facetValue": "123",
                            "auditDetails": {
                                "createdBy": "GPAADMIN",
                                "createdTimeStamp": 1667351336676,
                                "modifiedBy": "GPAADMIN",
                                "modifiedTimeStamp": 1667404663529
                            },
                            "showFlag": true
                        }
                    ],
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1667351336672,
                        "modifiedBy": "GPAADMIN",
                        "modifiedTimeStamp": 1667404663529
                    },
                    "mandatory": false,
                    "facetValue": "123",
                    "facetCategory": "List",
                    "facetType": "List values"
                },
                {
                    "id": 51,
                    "name": "NewTestterm",
                    "dataType": "BOOLEAN",
                    "description": "NewTestterm",
                    "facets": [
                        {
                            "facetType": "ENUMERATION",
                            "facetValue": "1,2",
                            "auditDetails": {
                                "createdBy": "S03531",
                                "createdTimeStamp": 1667822403013,
                                "modifiedBy": null,
                                "modifiedTimeStamp": 1667822402995
                            },
                            "showFlag": true
                        }
                    ],
                    "auditDetails": {
                        "createdBy": "S03531",
                        "createdTimeStamp": 1667822403006,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667822403013
                    },
                    "mandatory": false,
                    "facetValue": "1,2",
                    "facetCategory": "List",
                    "facetType": "List values"
                },
                {
                    "id": 3,
                    "name": "Kanaal",
                    "dataType": "STRING",
                    "description": "Channel through which the conditions were accepted",
                    "facets": [],
                    "auditDetails": {
                        "createdBy": "C57909",
                        "createdTimeStamp": 1567757267295,
                        "modifiedBy": null,
                        "modifiedTimeStamp": 1628289144258
                    },
                    "mandatory": false,
                    "display": false,
                    "selected": true,
                    "facetTypeValueList": [
                        {
                            "singleValueFacets": [
                                "Length",
                                "Pattern",
                                "Maximum length",
                                "Minimum length"
                            ]
                        }
                    ],
                    "facetType": "List values"
                }
            ],
            "auditDetails": {
                "createdBy": "GPAADMIN",
                "createdTimeStamp": 1665538622856,
                "modifiedBy": "S03531",
                "modifiedTimeStamp": 1667828154016
            },
            "products": "5526"
        };
        wrapper.vm.updateAdmin(admin2);
        wrapper.vm.validateGeneralFormDtls(admin2,'ALERT_SPECIAL_CHAR_IN_CREATE')
        wrapper.vm.validateGeneralFormDtls(admin2,'ALERT_SPECIAL_CHAR_IN_CREATE')
        wrapper.vm.hasDuplicatesPrducts([1,'1',2,null]);

    });*/

    it('should test updateAdmin method ', async () => {
        const updateAdmin = jest.spyOn(wrapper.vm, "updateAdmin");
        let admin2 = term;
        await updateAdmin(admin2);
        expect(updateAdmin).toHaveBeenCalled();
    });





/*    it('should test validateMandatoryTermEnumValue method ', () => {
        let admin3 = {
            "id": 11,
            "name": "test2",
            "description": "final_test6",
            "oarId": "AAB.SYS.33333",
            "terms": [
                {
                    "id": 1,
                    "name": "Datum ondertekening contract",
                    "dataType": "DATE",
                    "description": "Date when the contract was signed",
                    "facets": null,
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1666163907630,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667808808086
                    },
                    "mandatory": '',
                    "facetType": "List values"
                }
            ],
            "auditDetails": {
                "createdBy": "GPAADMIN",
                "createdTimeStamp": 1665538622856,
                "modifiedBy": "S03531",
                "modifiedTimeStamp": 1667828154016
            },
            "products": "5526"
        };
        wrapper.vm.validateMandatoryTermEnumValue(admin3)
    });*/

    it('should test validateMandatoryTermEnumValue method ', async () => {
        let admin3 = {
            "id": 11,
            "name": "test2",
            "description": "final_test6",
            "oarId": "AAB.SYS.33333",
            "terms": [
                {
                    "id": 1,
                    "name": "Datum ondertekening contract",
                    "dataType": "DATE",
                    "description": "Date when the contract was signed",
                    "facets": null,
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1666163907630,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667808808086
                    },
                    "mandatory": '',
                    "facetType": "List values"
                }
            ],
            "auditDetails": {
                "createdBy": "GPAADMIN",
                "createdTimeStamp": 1665538622856,
                "modifiedBy": "S03531",
                "modifiedTimeStamp": 1667828154016
            },
            "products": "5526"
        };
        const validateMandatoryTermEnumValue = jest.spyOn(wrapper.vm, "validateMandatoryTermEnumValue");
        await validateMandatoryTermEnumValue(admin3);
        expect(validateMandatoryTermEnumValue).toHaveBeenCalled();
    });



    it('should test isEmpty method ', () => {
        expect(typeof utils.isEmpty).toBe('function');
    });

/*    it('should test getValidfacetTypes method ', () => {
            let obj =[
                {
                    'facets': [undefined,
                        {
                            'showFlag' : 'false'
                        },
                        undefined,
                        {
                            "facetType": "List values",
                        },
                    ],
                    undefined,
                    'facetCategory': [
                        {'showFlag' : 'false'
                        }
                    ],'id': [
                        1
                    ]
                }
            ]
            wrapper.vm.getValidfacetTypes(0,0,obj,0)
        });*/

    it('should test getValidfacetTypes method ', async () => {
        const getValidfacetTypes = jest.spyOn(wrapper.vm, "getValidfacetTypes");
        let obj =[
            {
                'facets': [undefined,
                    {
                        'showFlag' : 'false'
                    },
                    undefined,
                    {
                        "facetType": "List values",
                    },
                ],
                undefined,
                'facetCategory': [
                    {'showFlag' : 'false'
                    }
                ],'id': [
                    1
                ]
            }
        ]
        await getValidfacetTypes(0,0,obj,0);
        expect(getValidfacetTypes).toHaveBeenCalled();
    });



/*    it('should test getUniqueArray method ', () => {
        let allValues = [1,2,3];
        // wrapper.vm.$nextTick(() => {
            wrapper.vm.getUniqueArray(allValues);
            // expect(wrapper.vm.getUniqueArray(allValues)).toBeCalledTimes(1)
        // });
    });*/


    it('should test getUniqueArray method ', async () => {
        const getUniqueArray = jest.spyOn(wrapper.vm, "getUniqueArray");
        let allValues = [1,2,3];
        await getUniqueArray(allValues);
        expect(getUniqueArray).toHaveBeenCalled();
    });

/*    it('should test getAllStringSubFacets method ', () => {
        let allValues = [[1,2],[1,2],[1,2]];
        // wrapper.vm.$nextTick(() => {
        //     wrapper.vm.getAllStringSubFacets(allValues);
            wrapper.vm.getAllStringSubFacets(allValues);
            // expect(wrapper.vm.getAllStringSubFacets(allValues)).toBeCalledTimes(1)
        // });
    });*/

    it('should test getAllStringSubFacets method ', async () => {
        const getAllStringSubFacets = jest.spyOn(wrapper.vm, "getAllStringSubFacets");
        let allValues = [[1,2],[1,2],[1,2]];
        await getAllStringSubFacets(allValues);
        expect(getAllStringSubFacets).toHaveBeenCalled();
    });




    it('should test getValidCombination method ', () => {
        let term = {};
        term.dataType = 'STRING'
        term.facetCategory = 'Single Value'
        wrapper.vm.getValidCombination(term);
        term.dataType = 'STRING'
        term.facetCategory = 'Range'
        wrapper.vm.getValidCombination(term);
        term.dataType = 'NUMERIC'
        term.facetCategory = 'Single Value'
        wrapper.vm.getValidCombination(term);
        term.dataType = 'NUMERIC'
        term.facetCategory = 'Range'
        wrapper.vm.getValidCombination(term);
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.getValidCombination()).toBeCalledTimes(1)
        // });
    });

/*
    it('should test getValidCombination method ', async () => {
        const getValidCombination = jest.spyOn(wrapper.vm, "getValidCombination");
        let term = {};
        term.dataType = 'STRING'
        term.facetCategory = 'Single Value'
        await getValidCombination(term);
        term.dataType = 'STRING'
        term.facetCategory = 'Range'
        await getValidCombination(term);
        term.dataType = 'NUMERIC'
        term.facetCategory = 'Single Value'
        await getValidCombination(term);
        term.dataType = 'NUMERIC'
        term.facetCategory = 'Range'
        await getValidCombination(term);
        expect(getValidCombination).toHaveBeenCalled();
    });
*/






/*    it('should test displayPreFilledFacetCatagory method updateAdmin', () => {
        let selectedTerms =[{
            'facets': [{'showFlag' : 'false'}, {"facetType": "List values",},{"facetType": "List values",}],
            'facetCategory': [{'showFlag' : 'false'}]
        }]
        // wrapper.vm.$nextTick(() => {
            wrapper.vm.displayPreFilledFacetCatagory(selectedTerms);
            // expect(wrapper.vm.displayPreFilledFacetCatagory(selectedTerms)).toBeCalledTimes(1)
        // });
    });*/

    it('should test displayPreFilledFacetCatagory method ', async () => {
        const displayPreFilledFacetCatagory = jest.spyOn(wrapper.vm, "displayPreFilledFacetCatagory");
        let selectedTerms =[{
            'facets': [{'showFlag' : 'false'}, {"facetType": "List values",},{"facetType": "List values",}],
            'facetCategory': [{'showFlag' : 'false'}]
        }]
        await displayPreFilledFacetCatagory(selectedTerms);
        expect(displayPreFilledFacetCatagory).toHaveBeenCalled();
    });




/*    it('should test displayPreSelectedTerms method updateAdmin', () => {
        let selectedTerms =[1,{
            'facets': [{'showFlag' : 'false'},
                {"facetType": "List values",},
                ],
            'facetCategory': [{'showFlag' : 'false'}],'id': [1]
        }];
        wrapper.vm.terms = [1,'1','a',null, undefined,1]
        wrapper.vm.displayPreSelectedTerms(selectedTerms)
        /!*wrapper.vm.$nextTick(() => {
            // wrapper.vm.displayPreSelectedTerms(selectedTerms);
            expect(wrapper.vm.displayPreSelectedTerms(selectedTerms)).toBeCalledTimes(1)
        });*!/
    });*/

    it('should test displayPreSelectedTerms method ', async () => {
        const displayPreSelectedTerms = jest.spyOn(wrapper.vm, "displayPreSelectedTerms");
        let selectedTerms =[{
            'facets': [{'showFlag' : 'false'},
                {"facetType": "List values",},
            ],
            'facetCategory': [{'showFlag' : 'false'}]
        }];
        wrapper.vm.terms = [{
            'facetCategory': [{'showFlag' : 'false'}]
        }]
        await displayPreSelectedTerms(selectedTerms);
        expect(displayPreSelectedTerms).toHaveBeenCalled();
    });


/*    it('should call getUniqueArray method ', () => {
        let allValues;
        allValues='1';

        wrapper.vm.getUniqueArray(allValues);
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm. getUniqueArray()).toBeCalledTimes(1)
        // });
    });*/

    it('should test getUniqueArray method ', async () => {
        const getUniqueArray = jest.spyOn(wrapper.vm, "getUniqueArray");
        let allValues;
        allValues='1';
        await getUniqueArray(allValues);
        expect(getUniqueArray).toHaveBeenCalled();
    });



    // '    TypeError: this.validateUnicode is not a function'
/*
    it('should call isSpecialCharacterPresentInOAR method ', () => {
        let input = 'AAB.SYS.33333';
        wrapper.vm.admin = {};
        wrapper.vm.admin.isSpecialCharPresentInOAR = false;
        wrapper.vm.isSpecialCharacterPresentInOAR(input);
        wrapper.vm.validateUnicode(input);

        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm. isSpecialCharacterPresentInOAR(input)).toBeCalledTimes(1)
        // });
    });
*/

/*
    it('should test isSpecialCharacterPresentInOAR method ', async () => {
        const isSpecialCharacterPresentInOAR = jest.spyOn(wrapper.vm, "isSpecialCharacterPresentInOAR");
        let input = 'AAB.SYS.33333';
        wrapper.vm.admin = {};
        wrapper.vm.admin.isSpecialCharPresentInOAR = false;
        await isSpecialCharacterPresentInOAR(input);
        expect(isSpecialCharacterPresentInOAR).toHaveBeenCalled();
    });
*/



/*    it('should call updateTermsObj', () => {
        wrapper.vm.updateTermsObj([]);
        wrapper.vm.terms = {};
    })*/

    it('should test updateTermsObj method ', async () => {
        const updateTermsObj = jest.spyOn(wrapper.vm, "updateTermsObj");
        let obj = [{"id":1, "id2":2}]
        await updateTermsObj(obj);
        expect(updateTermsObj).toHaveBeenCalled();
    });

/*
    it('should call isSpecialCharacterPresentInOAR method ', () => {
        let input = 'AAB.SYS.33333';
        wrapper.vm.admin = {};
        wrapper.vm.admin.isSpecialCharPresentInOAR = false;
        wrapper.vm.isSpecialCharacterPresentInOAR(input);

        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm. isSpecialCharacterPresentInOAR(input)).toBeCalledTimes(1)
        // });
    });
*/



/*
    it('should test facetTypeEnumtoViewMapper method updateAdmin', () => {
        let value =
            [
                {
                    "facets": null,
                },
                {
                    "facets": [
                        {
                            "facetType": "ENUMERATION",
                        },
                        {
                            "facetType": "LENGTH",
                        },
                        {
                            "facetType": "PATTERN",
                        },
                        {
                            "facetType": "MAXLENGTH",
                        },{
                            "facetType": "MINLENGTH",
                        },{
                            "facetType": "MININCLUSIVE",
                        },{
                            "facetType": "MAXINCLUSIVE",
                        },{
                            "facetType": "MINEXCLUSIVE",
                        },{
                            "facetType": "MAXEXCLUSIVE",
                        },{
                            "facetType": "TOTALDIGITS",
                        },{
                            "facetType": "FRACTIONS",
                        },

                    ],
                },
            ]
        // wrapper.vm.facetTypeEnumtoViewMapper(value);
        // wrapper.vm.$nextTick(() => {
            wrapper.vm.facetTypeEnumtoViewMapper(value);
            // expect(wrapper.vm.facetTypeEnumtoViewMapper(value)).toBeCalledTimes(1)
        // });
    });
*/

    it('should test facetTypeEnumtoViewMapper method ', async () => {
        const facetTypeEnumtoViewMapper = jest.spyOn(wrapper.vm, "facetTypeEnumtoViewMapper");
        let value = [
                {
                    "facets": null,
                },
                {
                    "facets": [
                        {
                            "facetType": "ENUMERATION",
                        },
                        {
                            "facetType": "LENGTH",
                        },
                        {
                            "facetType": "PATTERN",
                        },
                        {
                            "facetType": "MAXLENGTH",
                        },{
                            "facetType": "MINLENGTH",
                        },{
                            "facetType": "MININCLUSIVE",
                        },{
                            "facetType": "MAXINCLUSIVE",
                        },{
                            "facetType": "MINEXCLUSIVE",
                        },{
                            "facetType": "MAXEXCLUSIVE",
                        },{
                            "facetType": "TOTALDIGITS",
                        },{
                            "facetType": "FRACTIONS",
                        },

                    ],
                },
            ]
        await facetTypeEnumtoViewMapper(value);
        expect(facetTypeEnumtoViewMapper).toHaveBeenCalled();
    });


/*
    it('should test checkDuplicateTerms method updateAdmin', async() => {
        let selectedTerms = ['hi',{'name':'a'},{'name':'b'}]
        wrapper.vm.checkDuplicateTerms(selectedTerms);
        let array = [
            5525,
            '5525', null,'abcd'
        ];
        wrapper.vm.hasDuplicates(array);
        /!*
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.checkDuplicateTerms(selectedTerms)).toBeCalledTimes(1)
            // expect(wrapper.vm.hasDuplicates(selectedTerms)).toBeCalledTimes(1)
            wrapper.vm.checkDuplicateTerms(selectedTerms);
        });*!/
    });
*/

    it('should test hasDuplicates method ', async () => {
        const hasDuplicates = jest.spyOn(wrapper.vm, "hasDuplicates");
        let selectedTerms = ['123','123','456']
        await hasDuplicates(selectedTerms);
        expect(hasDuplicates).toHaveBeenCalled();
    });

    it('should test checkDuplicateTerms method ', async () => {
        const checkDuplicateTerms = jest.spyOn(wrapper.vm, "checkDuplicateTerms");
        let selectedTerms = [
            {
                "id": 1,
                "name": "Datum ondertekening contract",
                "dataType": "DATE",
                "description": "Date when the contract was signed",
                "facets": null,
                "auditDetails": {
                    "createdBy": "GPAADMIN",
                    "createdTimeStamp": 1666176507630,
                    "modifiedBy": "S03531",
                    "modifiedTimeStamp": 1667825008086
                },
                "mandatory": true,
                "$$hashKey": "object:997",
                "facetType": "List values"
            }]
        await checkDuplicateTerms(selectedTerms);
        expect(checkDuplicateTerms).toHaveBeenCalled();
    });

    it('should test updateAdminServiceCall method ', async () => {
        const updateAdminServiceCall = jest.spyOn(wrapper.vm, "updateAdminServiceCall");
        let admin = term;
        await updateAdminServiceCall(admin);
        expect(updateAdminServiceCall).toHaveBeenCalled();
    });



    /*
        it('should test updateAdminServiceCall method updateAdmin', async () => {
            let admin = {
                "id": 11,
                "name": "test2",
                "description": "final_test6",
                "oarId": "AAB.SYS.33333",
                "terms": [
                    {
                        "id": 1,
                        "name": "Datum ondertekening contract",
                        "dataType": "DATE",
                        "description": "Date when the contract was signed",
                        "facets": null,
                        "auditDetails": {
                            "createdBy": "GPAADMIN",
                            "createdTimeStamp": 1666163907630,
                            "modifiedBy": "S03531",
                            "modifiedTimeStamp": 1667808808086
                        },
                        "mandatory": true,
                        "facetType": "List values"
                    },
                    {
                        "id": 2,
                        "name": "IBAN",
                        "dataType": "STRING",
                        "description": "IBAN is used by the customer",
                        "facets": [
                            {
                                "facetType": "MAXLENGTH",
                                "facetValue": "10",
                                "auditDetails": {
                                    "createdBy": "S03531",
                                    "createdTimeStamp": 1667822403216,
                                    "modifiedBy": null,
                                    "modifiedTimeStamp": 1667822402995
                                },
                                "availableFacets": [
                                    "Maximum length",
                                    "Minimum length",
                                    "Pattern",
                                    "Length"
                                ],
                                "showFlag": true
                            }
                        ],
                        "auditDetails": {
                            "createdBy": "GPAADMIN",
                            "createdTimeStamp": 1665538622865,
                            "modifiedBy": "S03531",
                            "modifiedTimeStamp": 1667822403216
                        },
                        "mandatory": false,
                        "facetCategory": "Single Value",
                        "facetType": "List values"
                    },
                    {
                        "id": 4,
                        "name": "Naam ondertekenaar",
                        "dataType": "STRING",
                        "description": "Name of the person who signed the contract",
                        "facets": [
                            {
                                "facetType": "ENUMERATION",
                                "facetValue": "123",
                                "auditDetails": {
                                    "createdBy": "GPAADMIN",
                                    "createdTimeStamp": 1667351336676,
                                    "modifiedBy": "GPAADMIN",
                                    "modifiedTimeStamp": 1667404663529
                                },
                                "showFlag": true
                            }
                        ],
                        "auditDetails": {
                            "createdBy": "GPAADMIN",
                            "createdTimeStamp": 1667351336672,
                            "modifiedBy": "GPAADMIN",
                            "modifiedTimeStamp": 1667404663529
                        },
                        "mandatory": false,
                        "facetValue": "123",
                        "facetCategory": "List",
                        "facetType": "List values"
                    },
                    {
                        "id": 51,
                        "name": "NewTestterm",
                        "dataType": "BOOLEAN",
                        "description": "NewTestterm",
                        "facets": [
                            {
                                "facetType": "ENUMERATION",
                                "facetValue": "1,2",
                                "auditDetails": {
                                    "createdBy": "S03531",
                                    "createdTimeStamp": 1667822403013,
                                    "modifiedBy": null,
                                    "modifiedTimeStamp": 1667822402995
                                },
                                "showFlag": true
                            }
                        ],
                        "auditDetails": {
                            "createdBy": "S03531",
                            "createdTimeStamp": 1667822403006,
                            "modifiedBy": "S03531",
                            "modifiedTimeStamp": 1667822403013
                        },
                        "mandatory": false,
                        "facetValue": "1,2",
                        "facetCategory": "List",
                        "facetType": "List values"
                    },
                    {
                        "id": 3,
                        "name": "Kanaal",
                        "dataType": "STRING",
                        "description": "Channel through which the conditions were accepted",
                        "facets": [],
                        "auditDetails": {
                            "createdBy": "C57909",
                            "createdTimeStamp": 1567757267295,
                            "modifiedBy": null,
                            "modifiedTimeStamp": 1628289144258
                        },
                        "mandatory": false,
                        "display": false,
                        "selected": true,
                        "facetTypeValueList": [
                            {
                                "singleValueFacets": [
                                    "Length",
                                    "Pattern",
                                    "Maximum length",
                                    "Minimum length"
                                ]
                            }
                        ],
                        "facetType": "List values"
                    }
                ],
                "auditDetails": {
                    "createdBy": "GPAADMIN",
                    "createdTimeStamp": 1665538622856,
                    "modifiedBy": "S03531",
                    "modifiedTimeStamp": 1667828154016
                },
                "products": "5526"
            };
            let tempObj = admin.terms;
            expect(typeof !utils.isEmpty(tempObj)).toBe('boolean');
            wrapper.vm.updateAdminServiceCall(admin);
            wrapper.vm.validateFacetFormat(tempObj);
            wrapper.vm.facetTypeViewToEnumMapper(tempObj);


            const AdministrationRestResource = jest.spyOn(wrapper.vm, "updateAdminServiceCall");
            const updateAdminServiceCall = jest.spyOn(appServices, "updateAdminServiceCall");
            updateAdminServiceCall.mockResolvedValue(AdministrationRestResource);

            expect(AdministrationRestResource).not.toHaveBeenCalled();
            updateAdminServiceCall.mockResolvedValue(updateAdminServiceCall);
            await updateAdminServiceCall();
            expect(updateAdminServiceCall).toHaveBeenCalled();



            // wrapper.vm.$nextTick(() => {
            //     expect(wrapper.vm.updateAdminServiceCall(admin)).toBeCalledTimes(1)
            // });
        });
    */

/*
    it('should test facetTypeViewToEnumMapper method updateAdmin', () => {
        let value =
            [
                {
                    "facets": null,
                },
                {
                    "facets": [
                        {
                            "facetType": "List values",
                        },
                        {
                            "facetType": "MaxInclusive",
                        },
                        {
                            "facetType": "MinInclusive",
                        },
                        {
                            "facetType": "Minimum length",
                        },{
                            "facetType": "Pattern",
                        },{
                            "facetType": "Length",
                        },{
                            "facetType": "MinExclusive",
                        },{
                            "facetType": "MaxExclusive",
                        },{
                            "facetType": "Total Digits",
                        },{
                            "facetType": "Fractions",
                        },{
                            "facetType": "Maximum length",
                        },

                    ],
                },
            ]
        // wrapper.vm.facetTypeViewToEnumMapper(value);
        // wrapper.vm.$nextTick(() => {
            wrapper.vm.facetTypeViewToEnumMapper(value);

            // expect(wrapper.vm.facetTypeViewToEnumMapper(value)).toBeCalledTimes(1)
        // });
    });
*/

    it('should test facetTypeViewToEnumMapper method ', async () => {
        let value = [
                {
                    "facets": null,
                },
                {
                    "facets": [
                        {
                            "facetType": "List values",
                        },
                        {
                            "facetType": "MaxInclusive",
                        },
                        {
                            "facetType": "MinInclusive",
                        },
                        {
                            "facetType": "Minimum length",
                        },{
                            "facetType": "Pattern",
                        },{
                            "facetType": "Length",
                        },{
                            "facetType": "MinExclusive",
                        },{
                            "facetType": "MaxExclusive",
                        },{
                            "facetType": "Total Digits",
                        },{
                            "facetType": "Fractions",
                        },{
                            "facetType": "Maximum length",
                        },

                    ],
                },
            ]
        const facetTypeViewToEnumMapper = jest.spyOn(wrapper.vm, "facetTypeViewToEnumMapper");
        await facetTypeViewToEnumMapper(value);
        expect(facetTypeViewToEnumMapper).toHaveBeenCalled();
    });


    //  TypeError: this.isEmpty is not a function
/*
    it('should test validateStringEnum method updateAdmin', () => {
        let term = [{
            'facetCategory': [{'showFlag' : 'false'}]
        }]
        wrapper.vm.validateStringEnum(0, term);
        expect(typeof utils.isEmpty).toBe('function');
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.validateStringEnum(term)).toBeCalledTimes(1)
        });
    });
*/

    //         TypeError: this.validateStringEnum is not a function
/*
    it('should test validateStringTypeSelected method updateAdmin', () => {
        let term;
        term={
            'facetCategory':'List',
        };
        wrapper.vm.validateStringTypeSelected(0,term,0);
        wrapper.vm.validateStringTypeSelected(0,term,0);
        term={
            'facetCategory':'Single Value',
        };
        wrapper.vm.validateStringSingle(0,term,0);
        term={
            'facetCategory':'Range',
        };
        wrapper.vm.validateStringRange(0,term,0);



        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.validateStringTypeSelected(0,term,0)).toBeCalledTimes(1)
        });
    });
*/

/*    it('should test validateNumericSingle method updateAdmin', () => {
        let term = {}
        term.facets= [[{

            'showFlag':true,
            'facetType' : 'Maximum length'

        }]]


        wrapper.vm.validateNumericSingle(0, term);
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.validateNumericSingle(0, term)).toBeCalledTimes(1)
        // });
    });*/

/*
    it('should test validateNumericSingle method ', async () => {
        let term = {}
        term.facets= [[{

            'showFlag':true,
            'facetType' : 'Maximum length'

        }]]
        const validateNumericSingle = jest.spyOn(wrapper.vm, "validateNumericSingle");
        await validateNumericSingle(0,term);
        expect(validateNumericSingle).toHaveBeenCalled();
    });
*/




/*    it('should test getStringSingleValueDropdown method ', () => {
        let allpossibleCombinations = [ "-1"];
        let selectedValues = [1,2,3];
        wrapper.vm.getStringSingleValueDropdown(allpossibleCombinations,selectedValues,1);
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.getStringSingleValueDropdown(allpossibleCombinations,selectedValues,1)).toBeCalledTimes(1)
        // });
    });*/

    it('should test getStringSingleValueDropdown method ', async () => {
        const getStringSingleValueDropdown = jest.spyOn(wrapper.vm, "getStringSingleValueDropdown");
        let allpossibleCombinations = [ "-1"];
        let selectedValues = [1,2,3];
        await getStringSingleValueDropdown(allpossibleCombinations,selectedValues,1);
        expect(getStringSingleValueDropdown).toHaveBeenCalled();
    });

/*    it('should test removeSelectedFacetsFromAllowed method ', () => {
        let allpossibleCombinations = ['a','b'];
        let fileredSelectedValues = [1,2,3];
        wrapper.vm.removeSelectedFacetsFromAllowed(allpossibleCombinations,fileredSelectedValues);
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.getStringSingleValueDropdown(allpossibleCombinations,selectedValues,1)).toBeCalledTimes(1)
        // });
    });*/

    it('should test removeSelectedFacetsFromAllowed method ', async () => {
        const removeSelectedFacetsFromAllowed = jest.spyOn(wrapper.vm, "removeSelectedFacetsFromAllowed");
        let allpossibleCombinations = ['a','b'];
        let fileredSelectedValues = [1,2,3];
        await removeSelectedFacetsFromAllowed(allpossibleCombinations,fileredSelectedValues);
        expect(removeSelectedFacetsFromAllowed).toHaveBeenCalled();
    });

/*    it('should test getValidfacetTypesOnLoad method ', () => {
        //Ive called another function here
        let event ;
        let obj = {};
        wrapper.vm.getValidfacetTypesOnLoad(event,1,obj);
        // wrapper.vm.$nextTick(() => {

            wrapper.vm.getValidfacetTypes(0, 1, {}, [])
            // expect(wrapper.vm.getValidfacetTypes(0, 1, {}, [])).toBeCalledTimes(1)
    // });
    });*/

    it('should test getValidfacetTypesOnLoad method ', async () => {
        const getValidfacetTypesOnLoad = jest.spyOn(wrapper.vm, "getValidfacetTypesOnLoad");
        let event ;
        let obj = {};
        await getValidfacetTypesOnLoad(event,1,obj);
        expect(getValidfacetTypesOnLoad).toHaveBeenCalled();
    });

/*    it('should test getValidfacetTypesOnLoadNextValue method ', () => {
        let event ;
        let obj = {};
        obj.validated = true;
        wrapper.vm.getValidfacetTypesOnLoadNextValue(event,1,obj);
        // wrapper.vm.$nextTick(() => {

           wrapper.vm.getValidfacetTypes(0, 1, {}, []);
            // expect(wrapper.vm.getValidfacetTypes(0, 1, {}, [])).toBeCalledTimes(1)
        // });
    });*/

    it('should test getValidfacetTypesOnLoadNextValue method ', async () => {
        const getValidfacetTypesOnLoadNextValue = jest.spyOn(wrapper.vm, "getValidfacetTypesOnLoadNextValue");
        let event ;
        let obj = {};
        obj.validated = true;
        await getValidfacetTypesOnLoadNextValue(event,1,obj);
        expect(getValidfacetTypesOnLoadNextValue).toHaveBeenCalled();
    });


/*
    it('should test facetCategoryOnLoad method ', () => {
        let obj = [];
        obj.validated = true;
        obj.facets = [];
        wrapper.vm.facetCategoryOnLoad(0,obj);
        // wrapper.vm.$nextTick(() => {
            wrapper.vm.getValidfacetTypes(1, 1, obj,0)
            // expect(wrapper.vm.getValidfacetTypes(event, 1, obj)).toBeCalledTimes(1)
        // });
    });
*/

    it('should test facetCategoryOnLoad method ', async () => {
        const facetCategoryOnLoad = jest.spyOn(wrapper.vm, "facetCategoryOnLoad");
        let obj = [];
        obj.validated = true;
        obj.facets = [];
        await facetCategoryOnLoad(0,obj);
        expect(facetCategoryOnLoad).toHaveBeenCalled();
    });


/*
    it('should isMandatorySelected method updateAdmin', () => {
        let term = {}
        term.mandatory = '';
        term.showMessage = '';
        term.validated = '';
        wrapper.vm.isMandatorySelected(term);
        term.showMessage = false;
        wrapper.vm.isMandatorySelected(term);
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.isMandatorySelected(term)).toBeCalledTimes(1)
        // });
    });
*/

    it('should test isMandatorySelected method ', async () => {
        const isMandatorySelected = jest.spyOn(wrapper.vm, "isMandatorySelected");
        let term = {}
        term.mandatory = '';
        term.showMessage = '';
        term.validated = '';
        await isMandatorySelected(term);
        expect(isMandatorySelected).toHaveBeenCalled();
    });


/*
    it('should validateProductIdFormat method updateAdmin', () => {
        let obj = "123456,1234,1234,12345,12345,12345,123456";
        wrapper.vm.validateProductIdFormat(obj);
        obj = "1234567890";
        wrapper.vm.validateProductIdFormat(obj);

        wrapper.vm.invalidProductListFormat([]);
        // wrapper.vm.validateProductIdFormat(obj);
        /!*wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.validateProductIdFormat(obj)).toBeCalledTimes(1)
        });*!/
    });
*/

/*
    it('should test validateProductIdFormat method ', async () => {
        const validateProductIdFormat = jest.spyOn(wrapper.vm, "validateProductIdFormat");
        let obj = "123456,1234,1234,12345,12345,12345,123456";
        await validateProductIdFormat(obj);
        expect(validateProductIdFormat).toHaveBeenCalled();
    });
*/

/*    it('should test validateTermsDtls method updateAdmin', () => {
        wrapper.vm.validateTermsDtls();
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.validateTermsDtls()).toBeCalledTimes(1)
        // });
    });*/

/*
    it('should test validateTermsDtls method ', async () => {
        const validateTermsDtls = jest.spyOn(wrapper.vm, "validateTermsDtls");
        await validateTermsDtls();
        expect(validateTermsDtls).toHaveBeenCalled();
    });
*/

/*
    it('should test unselectAll method updateAdmin', () => {

        // wrapper.vm.unselectAll();
        wrapper.vm.terms = [{"selected":true}];
        // wrapper.vm.allTermsSelected= "";
        wrapper.vm.unselectAll();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.unselectAll()).toBeCalledTimes(1);
        });
    });
*/

/*    it('should test unselectAll method ', async () => {
        const unselectAll = jest.spyOn(wrapper.vm, "unselectAll");
        wrapper.vm.terms = [{"selected":true}]
        wrapper.vm.allTermsSelected = false;
        await unselectAll();
        expect(unselectAll).toHaveBeenCalled();
    });*/

/*
    it('should test saveAndCloseAdministrationTermsModal method updateAdmin', () => {
        const event = {
            "isTrusted": true
        }
        wrapper.vm.saveAndCloseAdministrationTermsModal(event);
        wrapper.vm.saveTermsInAdmin();
        // expect(typeof utils.isEmpty).toBe('function');
        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.saveAndCloseAdministrationTermsModal()).toBeCalledTimes(1)
            // expect(wrapper.vm.saveTermsInAdmin()).toBeCalledTimes(1)
        // });
    });
*/

/*
    it('should test saveAndCloseAdministrationTermsModal method ', async () => {
        const saveAndCloseAdministrationTermsModal = jest.spyOn(wrapper.vm, "saveAndCloseAdministrationTermsModal");
        const dc1 = jest.spyOn(document, "closeModal");
        await saveAndCloseAdministrationTermsModal(1);
        expect(saveAndCloseAdministrationTermsModal).toHaveBeenCalled();
        expect(dc1).toHaveBeenCalled();
    });
*/

/*
    it('should test validateBooleanTypeSelected method updateAdmin', async() => {
        let index = 3;
        let term = {
            "id": 51,
            "name": "NewTestterm",
            "dataType": "BOOLEAN",
            "facets": [],
            "facetValue": "1,2,3,4,5,6,7",
            "showMessage": '',
            "validated": '',
            "errorMsgLabel": "",
            'isSpecialCharPresentInFacetValue': ''
        }
        const validateBooleanTypeSelected = jest.spyOn(wrapper.vm, "validateBooleanTypeSelected");
        await validateBooleanTypeSelected(index, term);
        expect(validateBooleanTypeSelected).toHaveBeenCalled();

    });
*/

/*    it('should test validateStringTypeSelected method updateAdmin', () => {
        let index = 3;
        let term = {
            "id": 51,
            "name": "NewTestterm",
            "dataType": "BOOLEAN",
            "facets": [],
            "facetValue": "1,2,3,4,5,6,7",
            'facetCategory': "List | Range" ,
            "showMessage": '',
            "validated": '',
            "errorMsgLabel": "",
            'isSpecialCharPresentInFacetValue': ''
        }
        wrapper.vm.validateStringTypeSelected(index, term, undefined);
/!*        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.validateBooleanTypeSelected()).toBeCalledTimes(1)
        });*!/
    });*/

/*
    it('should test validateStringTypeSelected method ', async () => {
        const validateStringTypeSelected = jest.spyOn(wrapper.vm, "validateStringTypeSelected");
        let index = 3;
        let term = {
            "id": 51,
            "name": "NewTestterm",
            "dataType": "BOOLEAN",
            "facets": [],
            "facetValue": "1,2,3,4,5,6,7",
            'facetCategory': "List | Range" ,
            "showMessage": '',
            "validated": '',
            "errorMsgLabel": "",
            'isSpecialCharPresentInFacetValue': ''
        }
        await validateStringTypeSelected(index, term, undefined);
        expect(validateStringTypeSelected).toHaveBeenCalled();
    });
*/


/*    it('should test checkGenericAdminDtls method updateAdmin', () => {
        let admin = {
            "id": 11,
            "name": "test2",
            "description": "final_test6",
            "oarId": "AAB.SYS.33333",
            "terms": [
                {
                    "id": 1,
                    "name": "Datum ondertekening contract",
                    "dataType": "DATE",
                    "description": "Date when the contract was signed",
                    "facets": null,
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1666163907630,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667808808086
                    },
                    "mandatory": true,
                    "facetType": "List values"
                },
                {
                    "id": 2,
                    "name": "IBAN",
                    "dataType": "STRING",
                    "description": "IBAN is used by the customer",
                    "facets": [
                        {
                            "facetType": "MAXLENGTH",
                            "facetValue": "10",
                            "auditDetails": {
                                "createdBy": "S03531",
                                "createdTimeStamp": 1667822403216,
                                "modifiedBy": null,
                                "modifiedTimeStamp": 1667822402995
                            },
                            "availableFacets": [
                                "Maximum length",
                                "Minimum length",
                                "Pattern",
                                "Length"
                            ],
                            "showFlag": true
                        }
                    ],
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1665538622865,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667822403216
                    },
                    "mandatory": false,
                    "facetCategory": "Single Value",
                    "facetType": "List values"
                },
                {
                    "id": 4,
                    "name": "Naam ondertekenaar",
                    "dataType": "STRING",
                    "description": "Name of the person who signed the contract",
                    "facets": [
                        {
                            "facetType": "ENUMERATION",
                            "facetValue": "123",
                            "auditDetails": {
                                "createdBy": "GPAADMIN",
                                "createdTimeStamp": 1667351336676,
                                "modifiedBy": "GPAADMIN",
                                "modifiedTimeStamp": 1667404663529
                            },
                            "showFlag": true
                        }
                    ],
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1667351336672,
                        "modifiedBy": "GPAADMIN",
                        "modifiedTimeStamp": 1667404663529
                    },
                    "mandatory": false,
                    "facetValue": "123",
                    "facetCategory": "List",
                    "facetType": "List values"
                },
                {
                    "id": 51,
                    "name": "NewTestterm",
                    "dataType": "BOOLEAN",
                    "description": "NewTestterm",
                    "facets": [
                        {
                            "facetType": "ENUMERATION",
                            "facetValue": "1,2",
                            "auditDetails": {
                                "createdBy": "S03531",
                                "createdTimeStamp": 1667822403013,
                                "modifiedBy": null,
                                "modifiedTimeStamp": 1667822402995
                            },
                            "showFlag": true
                        }
                    ],
                    "auditDetails": {
                        "createdBy": "S03531",
                        "createdTimeStamp": 1667822403006,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667822403013
                    },
                    "mandatory": false,
                    "facetValue": "1,2",
                    "facetCategory": "List",
                    "facetType": "List values"
                },
                {
                    "id": 3,
                    "name": "Kanaal",
                    "dataType": "STRING",
                    "description": "Channel through which the conditions were accepted",
                    "facets": [],
                    "auditDetails": {
                        "createdBy": "C57909",
                        "createdTimeStamp": 1567757267295,
                        "modifiedBy": null,
                        "modifiedTimeStamp": 1628289144258
                    },
                    "mandatory": false,
                    "display": false,
                    "selected": true,
                    "facetTypeValueList": [
                        {
                            "singleValueFacets": [
                                "Length",
                                "Pattern",
                                "Maximum length",
                                "Minimum length"
                            ]
                        }
                    ],
                    "facetType": "List values"
                }
            ],
            "auditDetails": {
                "createdBy": "GPAADMIN",
                "createdTimeStamp": 1665538622856,
                "modifiedBy": "S03531",
                "modifiedTimeStamp": 1667828154016
            },
            "products": "5526"
        };
        wrapper.vm.validateGeneralFormDtls(admin);
        wrapper.vm.checkGenericAdminDtls(admin);
        wrapper.vm.hasDuplicatesPrducts([]);
        wrapper.vm.validateProductIdFormat(admin.products);
        wrapper.vm.validateProductIdFormat(admin.products);

        // wrapper.vm.$nextTick(() => {
        //     expect(wrapper.vm.validateTermsDtls()).toBeCalledTimes(1)
        // });
    });*/

    it('should test checkGenericAdminDtls method ', async () => {
        const checkGenericAdminDtls = jest.spyOn(wrapper.vm, "checkGenericAdminDtls");
        let admin = {
            "id": 11,
            "name": "test2",
            "description": "final_test6",
            "oarId": "AAB.SYS.33333",
            "terms": [
                {
                    "id": 1,
                    "name": "Datum ondertekening contract",
                    "dataType": "DATE",
                    "description": "Date when the contract was signed",
                    "facets": null,
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1666163907630,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667808808086
                    },
                    "mandatory": true,
                    "facetType": "List values"
                },
                {
                    "id": 2,
                    "name": "IBAN",
                    "dataType": "STRING",
                    "description": "IBAN is used by the customer",
                    "facets": [
                        {
                            "facetType": "MAXLENGTH",
                            "facetValue": "10",
                            "auditDetails": {
                                "createdBy": "S03531",
                                "createdTimeStamp": 1667822403216,
                                "modifiedBy": null,
                                "modifiedTimeStamp": 1667822402995
                            },
                            "availableFacets": [
                                "Maximum length",
                                "Minimum length",
                                "Pattern",
                                "Length"
                            ],
                            "showFlag": true
                        }
                    ],
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1665538622865,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667822403216
                    },
                    "mandatory": false,
                    "facetCategory": "Single Value",
                    "facetType": "List values"
                },
                {
                    "id": 4,
                    "name": "Naam ondertekenaar",
                    "dataType": "STRING",
                    "description": "Name of the person who signed the contract",
                    "facets": [
                        {
                            "facetType": "ENUMERATION",
                            "facetValue": "123",
                            "auditDetails": {
                                "createdBy": "GPAADMIN",
                                "createdTimeStamp": 1667351336676,
                                "modifiedBy": "GPAADMIN",
                                "modifiedTimeStamp": 1667404663529
                            },
                            "showFlag": true
                        }
                    ],
                    "auditDetails": {
                        "createdBy": "GPAADMIN",
                        "createdTimeStamp": 1667351336672,
                        "modifiedBy": "GPAADMIN",
                        "modifiedTimeStamp": 1667404663529
                    },
                    "mandatory": false,
                    "facetValue": "123",
                    "facetCategory": "List",
                    "facetType": "List values"
                },
                {
                    "id": 51,
                    "name": "NewTestterm",
                    "dataType": "BOOLEAN",
                    "description": "NewTestterm",
                    "facets": [
                        {
                            "facetType": "ENUMERATION",
                            "facetValue": "1,2",
                            "auditDetails": {
                                "createdBy": "S03531",
                                "createdTimeStamp": 1667822403013,
                                "modifiedBy": null,
                                "modifiedTimeStamp": 1667822402995
                            },
                            "showFlag": true
                        }
                    ],
                    "auditDetails": {
                        "createdBy": "S03531",
                        "createdTimeStamp": 1667822403006,
                        "modifiedBy": "S03531",
                        "modifiedTimeStamp": 1667822403013
                    },
                    "mandatory": false,
                    "facetValue": "1,2",
                    "facetCategory": "List",
                    "facetType": "List values"
                },
                {
                    "id": 3,
                    "name": "Kanaal",
                    "dataType": "STRING",
                    "description": "Channel through which the conditions were accepted",
                    "facets": [],
                    "auditDetails": {
                        "createdBy": "C57909",
                        "createdTimeStamp": 1567757267295,
                        "modifiedBy": null,
                        "modifiedTimeStamp": 1628289144258
                    },
                    "mandatory": false,
                    "display": false,
                    "selected": true,
                    "facetTypeValueList": [
                        {
                            "singleValueFacets": [
                                "Length",
                                "Pattern",
                                "Maximum length",
                                "Minimum length"
                            ]
                        }
                    ],
                    "facetType": "List values"
                }
            ],
            "auditDetails": {
                "createdBy": "GPAADMIN",
                "createdTimeStamp": 1665538622856,
                "modifiedBy": "S03531",
                "modifiedTimeStamp": 1667828154016
            },
            "products": "5526"
        };
        await checkGenericAdminDtls(admin);
        expect(checkGenericAdminDtls).toHaveBeenCalled();
    });

/*
    it('should test validateFacetFormat method updateAdmin', () => {
        let obj =[
            {
                'facets': [
                    {
                        'showFlag' : 'false'
                    },
                    undefined,
                    {
                        "facetType": "List values",
                    },
                ],
                undefined,
                'facetCategory': [
                    {'showFlag' : 'false'
                    }
                ],'id': [
                    1
                ]
            }
        ]
        wrapper.vm.validateFacetFormat(obj);
    });
*/

    it('should test validateFacetFormat method ', async () => {
        const validateFacetFormat = jest.spyOn(wrapper.vm, "validateFacetFormat");
        let obj =[
            {
                'facets': [
                    {
                        'showFlag' : 'false'
                    },
                    undefined,
                    {
                        "facetType": "List values",
                    },
                ],
                undefined,
                'facetCategory': [
                    {'showFlag' : 'false'
                    }
                ],'id': [
                    1
                ]
            }
        ]
        await validateFacetFormat(obj);
        expect(validateFacetFormat).toHaveBeenCalled();
    });

/*    it('clears timer when finish is called', () => {
        jest.spyOn(window, 'clearInterval')
        setInterval.mockReturnValue(123)
        const wrapper = shallowMount(ProgressBar)
        wrapper.vm.start()
        wrapper.vm.finish()
        expect(window.clearInterval).toHaveBeenCalledWith(123)
    })*/

    it('should test processUpdateAdminResponse method ', async () => {
        const processUpdateAdminResponse = jest.spyOn(wrapper.vm, "processUpdateAdminResponse");
        await processUpdateAdminResponse();
        expect(processUpdateAdminResponse).toHaveBeenCalled();
    });

    // it('should test mounted method ', async () => {
    //     const mounted = jest.spyOn(wrapper.vm, "mounted");
    //     await mounted();
    //     expect(mounted).toHaveBeenCalled();
    // });

    it('should test isSpecialCharacterPresentInOAR method ', async () => {
        const isSpecialCharacterPresentInOAR = jest.spyOn(wrapper.vm, "isSpecialCharacterPresentInOAR");
        let input = "\u6f22\u5b57"
        wrapper.vm.admin= {}
        wrapper.vm.admin.isSpecialCharPresentInOAR= true
        await isSpecialCharacterPresentInOAR(input);
        expect(isSpecialCharacterPresentInOAR).toHaveBeenCalled();
    });

/*
    it('should test validateGeneralFormDtls method ', async () => {
        const validateGeneralFormDtls = jest.spyOn(wrapper.vm, "validateGeneralFormDtls");
        let admin = term; let label = "";
        await validateGeneralFormDtls(admin, label);
        let admin1 = term; admin1.name = ""; admin1.description="";
        await validateGeneralFormDtls(admin1, label);
        expect(validateGeneralFormDtls).toHaveBeenCalled();
    });
*/

    it('should call onLoad method ', () => {
        wrapper.vm.onLoad();
        wrapper.vm.admin = {"term":term};
        const getAdminDetailsById = jest.spyOn(AppServices, "getAdminDetailsById");
        getAdminDetailsById.mockResolvedValue(term);
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. onLoad()).toBeCalledTimes(1)
        });
    });

    it('should test closePopModal method ', async () => {
        document.body.innerHTML = `<aab-modal></aab-modal>`;
        document.querySelector('aab-modal').closeModal = function () {
        };
        wrapper.vm.closePopModal();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. closePopModal()).toBeCalledTimes(1)
        });
    });

/*
    it('should test closePopModalUpdate method ', async () => {
        document.body.innerHTML = `<aab-modal></aab-modal>`;
        document.getElementById("modal-save").closeModal = function () {
        };
        wrapper.vm.closePopModalUpdate();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. closePopModalUpdate()).toBeCalledTimes(1)
        });
    });
*/

    it('should test saveAndCloseAdministrationUpdateModal method ', async () => {
        document.body.innerHTML = `<aab-modal></aab-modal>`;
        document.querySelector('aab-modal').closeModal = function () {
        };
        wrapper.vm.saveAndCloseAdministrationUpdateModal();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. saveAndCloseAdministrationUpdateModal()).toBeCalledTimes(1)
        });
    });

    it('should test closeAdministrationTermsModalModal method ', async () => {
        document.body.innerHTML = `<aab-modal></aab-modal>`;
        document.querySelector('aab-modal').closeModal = function () {
        };
        wrapper.vm.closeAdministrationTermsModalModal();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. closeAdministrationTermsModalModal()).toBeCalledTimes(1)
        });
    });


/*
    it('should test showDemoModal method ', async () => {
        document.body = `<div></div>`;
        document.getElementById('modal-save').openModal = function () {
        };
        wrapper.vm.showDemoModal();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. showDemoModal()).toBeCalledTimes(1)
        });
    });
*/


    it('should test showAdministrationTermsModal method ', async () => {
        document.body.innerHTML = `<aab-modal></aab-modal>`;
        document.querySelector('aab-modal').openModal = function () {
        };
        wrapper.vm.showAdministrationTermsModal();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. showAdministrationTermsModal()).toBeCalledTimes(1)
        });
    });

    it('should test saveAndCloseAdministrationTermsModal method ', async () => {
        document.body.innerHTML = `<aab-modal></aab-modal>`;
        document.querySelector('aab-modal').closeModal = function () {
        };
        wrapper.vm.saveAndCloseAdministrationTermsModal();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. saveAndCloseAdministrationTermsModal()).toBeCalledTimes(1)
        });
    });



});