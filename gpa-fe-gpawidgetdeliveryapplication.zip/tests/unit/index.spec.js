import router from "../../src/router/index";
import store from "@/store/index";
import {createLocalVue, mount} from "@vue/test-utils";

const localVue = createLocalVue();
localVue.use(store);

describe('Mounted App index file', () => {

    // eslint-disable-next-line no-unused-vars
    let wrapper;
    beforeEach(() => {
        wrapper = mount(store, {
            localVue,
            store,
            mocks:{
                $t: () => {},
            },
            data(){
                return {}
            },
        });
    });

    it('has routes object defined', () => {
        expect(typeof router.options.routes).toBe('object');
    });
    // it('is routing path array length correct', () => {
    //     expect(router.options.routes.length).toBe(9);//increase the number which each route
    // });

});