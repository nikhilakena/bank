import axios from 'axios';
//import { v4 as uuidv4 } from 'uuid';

import dataservice from "../../src/services/data.service";

jest.mock('axios');

describe('dataservice', () => {
    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('fetchIdToken', () => {
        it('should fetch ID token successfully', async () => {
            const idToken = 'validIDToken';

            axios.post.mockResolvedValue({ data: idToken });
        });

        it('should handle error while fetching ID token', async () => {
            const code = 'invalidAuthorizationCode';
            const error = new Error('Invalid authorization code');

            axios.post.mockRejectedValue(error);

            await expect(dataservice.fetchIdToken(code)).rejects.toThrow(error);
            expect(axios.post).toHaveBeenCalledWith(
                expect.stringContaining('checkAccess'),
                expect.any(URLSearchParams)
            );
        });
    });

    describe('setHeaderAuthorization', () => {
        it('should set authorization headers with access token', () => {
            const accessToken = 'validAccessToken';

            dataservice.setHeaderAuthorization(accessToken);

            expect(axios.defaults.headers.post['Content-Type']).toBe('application/json');
            expect(axios.defaults.headers.post['Trace-Id']).toBeDefined();
            expect(axios.defaults.headers.common.Authorization).toBe(`Bearer ${accessToken}`);
        });

        it('should unset authorization headers if no access token provided', () => {
            dataservice.setHeaderAuthorization();

            expect(axios.defaults.headers.common.Authorization).toBeUndefined();
        });
    });

    describe('validateToken', () => {
        it('should validate token successfully', async () => {
            const successResponse = { data: 'validToken' };

            axios.post.mockResolvedValue(successResponse);

        });

        it('should handle error while validating token', async () => {
            const error = new Error('Invalid token');

            axios.post.mockRejectedValue(error);

            await expect(dataservice.validateToken()).rejects.toThrow(error);

        });
    });
});
