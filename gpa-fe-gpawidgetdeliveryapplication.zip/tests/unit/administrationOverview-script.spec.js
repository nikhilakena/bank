import administrationOverview_Script from '@/views/app/gpaaadminconfigwidget/modules/adminoverview/administrationOverview-script';
import {mount} from "@vue/test-utils";
describe('Mounted App index file', () => {
    let wrapper;
    beforeEach(() => {
        wrapper = mount(administrationOverview_Script, {

            mocks: { $t: () => {} },

            data(){

                return{

                }

            }



        });

    })

    it('is a Vue name correct', () => {

        wrapper.vm.test = "test"
        expect(typeof administrationOverview_Script.data).toBe('function');





    });
});