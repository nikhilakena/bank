import AppServices from '../../src/services/AppServices';
describe("Mounted App index file", () => {
  it("has routes object defined", () => {
    expect(typeof AppServices).toBe("object");
    for (const c in AppServices) {
      if (c === "getData") {
        const mock = AppServices[c]();
        mock.catch(function () {
          // do nothing
        });
      }
    }
  });

  it('should test getTermDetailsByRouteId method ', async () => {
    AppServices.getTermDetailsByRouteId("1", "1")
  });
  it('should test getAllTermsServiceCall method ', async () => {
    AppServices.getAllTermsServiceCall({})
  });

  it('should test retrieveTerms method ', async () => {
    AppServices.retrieveTerms("1")
  });

  it('should test createTermServiceCall method ', async () => {
    AppServices.createTermServiceCall("1")
  });


  it('should test updateTermServiceCall method ', async () => {
    AppServices.updateTermServiceCall("1")
  });
  it('should test deleteTermServiceCall method ', async () => {
    AppServices.deleteTermServiceCall("1")
  });
  it('should test retrieveAdmins method ', async () => {
    AppServices.retrieveAdmins("1")
  });
  it('should test getAdminDetailsById method ', async () => {
    AppServices.getAdminDetailsById("1", {})
  });
  it('should test deleteAdminServiceCall method ', async () => {
    AppServices.deleteAdminServiceCall("1")
  });
  it('should test createAdminServiceCall method ', async () => {
    AppServices.createAdminServiceCall("1")
  });
  it('should test updateAdminServiceCall method ', async () => {
    AppServices.updateAdminServiceCall("1")
  });

  it('should test getTermDetailsById method ', async () => {
    AppServices.getTermDetailsById({}, "1")
  });

});
