import home from '../../src/views/home/home';

describe('Mounted home index file', () => {

    it('has name home', () => {
        expect(home.name).toBe('Home');
        expect(typeof home.name).toBe('string');
    });
});