import { mount } from '@vue/test-utils';
import Redirect from '@/views/Redirect.vue';

describe('Redirect', () => {
    let wrapper;

    beforeEach(() => {
        wrapper = mount(Redirect);
    });

    it('renders the component', () => {
        expect(wrapper.exists()).toBe(true);
    });


    it('calls goHome method and replaces the current route with the specified path', async () => {
        const mockReplace = jest.fn();
        wrapper.vm.$router = {
            replace: mockReplace,
        };

        await wrapper.vm.goHome('/');

        expect(mockReplace).toHaveBeenCalledWith('/');
    });

    it('sets the props of notify component correctly when calling the notify method', async () => {
        wrapper.vm.emptyNotify = jest.fn().mockResolvedValue();
        wrapper.vm.messageType = 'success';
        wrapper.vm.displayMessage = 'Notification Message';

        await wrapper.vm.notify('warning', 'New Notification');

        expect(wrapper.vm.emptyNotify).toHaveBeenCalled();
        expect(wrapper.vm.messageType).toBe('warning');
        expect(wrapper.vm.displayMessage).toBe('New Notification');
    });

    it('sets the props of notifyunauthorized component correctly when calling the notifyAuth method', async () => {
        wrapper.vm.emptyNotify = jest.fn().mockResolvedValue();
        wrapper.vm.messageTypeAuth = 'info';
        wrapper.vm.displayMessageAuth = 'Unauthorized Message';

        await wrapper.vm.notifyAuth('error', 'Unauthorized Access');

        expect(wrapper.vm.emptyNotify).toHaveBeenCalled();
        expect(wrapper.vm.messageTypeAuth).toBe('error');
        expect(wrapper.vm.displayMessageAuth).toBe('Unauthorized Access');
    });
});

