# gpa widget application
This is the GPA front end application created in vuejs and it provides the functionality to create administrations.

## git clone

```
git clone https://cbsp-abnamro@dev.azure.com/cbsp-abnamro/GRD0001002/_git/gpa-fe-gpawidgetdeliveryapplication
```

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your unit tests
```
jest
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

# Contribution
PNC-Core Team
