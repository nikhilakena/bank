
const utils = {
  /*
    This function is to remove multiple spaces(if present) in string
  */
  removeMultipleSpace:function(obj){
    // remove all spaces as well as new line
    //return obj.replace(/\s\s+/g, ' ');
    // Spaces and new line is added
    return obj.replace(/  +/g, ' ');
    // replace new line/ break with spaces
    //return obj.replace(/\r?\n?/g, '');
  },
  /*
     This function is to check null/empty value
  */
  isEmpty(value) {
    if (value === undefined || value === null || value === '') {
      return true;
    }
  }
};
export default utils;
