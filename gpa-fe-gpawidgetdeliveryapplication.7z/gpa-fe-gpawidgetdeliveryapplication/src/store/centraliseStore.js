import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

const store = new Vuex.Store({
  modules: {
  },

  state: {
    searchModel : {
        termId: '',
        termName: '',
        createdBy: '',
        createdTimeStamp: '',
        createdFrom:'',
        createdTo:'',
    },
    glossaryOverviewFilteredData: '',
  },

  getters: {
    searchModel: state => state.searchModel,
    glossaryOverviewFilteredData: state => state.glossaryOverviewFilteredData,
  },

  mutations: {
    updateFilterData(state, value) {
      state.searchModel = value;
    },
    updateGlossaryOverviewFilteredData(state, value) {
      state.glossaryOverviewFilteredData = value;
    },
  },

  actions: {
    updateFilterData(context, value) {
      context.commit('updateFilterData', value);
    },
    updateGlossaryOverviewFilteredData(context, value) {
      context.commit('updateGlossaryOverviewFilteredData', value);
    },
  },
});
export default store;
