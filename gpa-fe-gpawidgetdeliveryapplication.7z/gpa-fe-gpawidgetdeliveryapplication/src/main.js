import Vue from 'vue';
import Vuelidate from 'vuelidate';
import App from './App.vue';
import router from './router';
// import store from './store';
import store from './store/centraliseStore';
import VueRouter from 'vue-router';
import 'vue2-datepicker/index.css';
import 'aab-ui-components/dist/core.css';
import 'aab-ui-components/dist/icons.css';
import i18n from './i18n';
import 'emerald-global/dist/emerald-global-1.1.5/style.css';
import vuetify from './plugins/vuetify';
import sinon from 'sinon';
import '@aab/sc-aab-button';
import '@aab/sc-aab-modal';
import '@aab/sc-aab-info-popover';
import '@aab/sc-aab-notification';
import '@aab/sc-aab-datepicker';
import '@aab/sc-aab-icon';
import '@aab/sc-aab-spinner';
import '@aab/sc-aab-tabs';
import Filters from './filters/filters';
import '@aab/sc-aab-select';
import vSelect from "vue-select";
import "vue-select/src/scss/vue-select.scss";

import { ModalPlugin } from 'bootstrap-vue';
Vue.use(ModalPlugin);
Vue.config.productionTip = false;

Vue.use(Vuelidate);
Vue.use(VueRouter);
Vue.use(vSelect);
Vue.mixin({
  filters: Filters
});
document.body.setAttribute('data-app', true);

new Vue({
  router,
  store,
  i18n,
  vuetify,
  sinon,
  render: h => h(App)
}).$mount('#app');
