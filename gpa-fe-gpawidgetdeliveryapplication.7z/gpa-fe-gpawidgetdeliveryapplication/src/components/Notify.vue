<template>
  <transition name="fade">
    <div id="notify" v-if="msgType !== ''" class="mb-1">
      <aab-notification
        :type="msgType"
        :close-icon="showClose"
        id="aab-notification-custom-id"
        @aab-notification-close-icon-clicked="close"
      >{{$t(displayMsg)}}</aab-notification>
    </div>
  </transition>
</template>

<script>
export default {
  name: 'Notify',
  props: ['notificationType', 'displayMessage', 'closeNotification'],
  data() {
    return {
      msgType: '',
      displayMsg: '',
      showClose: true
    };
  },
  watch: {
        notificationType: function(val){
            if(val !== ''){
                this.notify(this.notificationType, this.displayMessage, this.closeNotification);
            }
            if(val === ''){
                this.msgType = val;
            }
        },
    },
  methods: {
    notify(type, msg, close=true) {
      this.msgType = type;
      this.displayMsg = msg;
      this.showClose = close;
      let el = '';

      setTimeout(() => {
        el = document.getElementById('notify');
        el.scrollIntoView({
          behavior: 'smooth',
          block: 'start',
          inline: 'nearest'
        });
      }, 100);
    },
    close() {
      this.msgType = '';
      this.$emit('clear', '');
    },
    // test(){
    //   console.log('hi' + this.displayMsg);
    // }
  },
  // updated(){
  //   this.test();
  // }
};
</script>
