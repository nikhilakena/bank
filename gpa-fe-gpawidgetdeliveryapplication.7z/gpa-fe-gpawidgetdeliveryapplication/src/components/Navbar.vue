<template>
  <v-card v-if="tabsData.length>0">
    <v-tabs
        v-model="tab"
        background-color="#e0e0e0"
    >
      <v-tab
          v-for="item in tabsData"
          :key="item.name" color="black"
      >
        <span class="itemName" style="position: relative;text-transform: none;">{{item.name}}</span>
      </v-tab>
    </v-tabs>

    <v-tabs-items v-model="tab">
      <v-tab-item
          v-for="item in tabsData"
          :key="item.name"
      >
        <v-card flat>
          <v-card-text>
            <div class="well">
              <h4 class="panel-title" style="color: #608e28;">
                <span>{{$t("LABEL_GENERAL_TERM_DETAILS")}}</span>
              </h4>
              <div class="well" style="border: 1px solid rgb(230, 230, 230);">
                <div class="row">
                  <div class="col-xs-6 ocf-label-static">
                    <p>{{$t("LABEL_TERM_NAME")}}</p>
                  </div>
                  <div class="col-xs-6 description" style="margin-bottom: 10px">{{item.name}}</div>
                </div>
                <div class="row">
                  <div class="col-xs-6 ocf-label-static">
                    <p>{{$t("LABEL_TERM_DESCR")}}</p>
                  </div>
                  <div class="col-xs-6 description" style="margin-bottom: 10px">
                    {{item.description }}</div>
                </div>
                <div class="row">
                  <div class="col-xs-6 ocf-label-static">
                    <p>{{$t("LABEL_TERM_DATA_TYPE")}}</p>
                  </div>
                  <div class="col-xs-6 description" style="margin-bottom: 10px">
                    {{$t(item.dataType)}}</div>
                </div>
                <div class="row">
                  <div class="col-xs-6 ocf-label-static">
                    <p>{{$t("LABEL_MANDATORY")}}</p>
                  </div>
                  <div class="col-xs-6 description" style="margin-bottom: 10px">
                    {{ ($t(item.mandatory ? 'LABEL_YES' : 'LABEL_NO'))}}
                  </div>
                </div>
                <div class="row" v-for="facet in item.facets"
                     :key="facet.facetType">
                  <div class="col-xs-6 ocf-label-static">
                    <p>{{$t(facet.facetType)}}</p>
                  </div>
                  <div class="col-xs-6 description" style="margin-bottom: 10px">
                    {{facet.facetValue}}</div>
                </div>
              </div>

              <h4 class="panel-title" style="color: #608e28;">
                <span>{{$t("LABEL_AUDIT_DETAILS")}}</span>
              </h4>
              <div class="well" style="border: 1px solid rgb(230, 230, 230);">
                <div class="row">
                  <div class="col-xs-6 ocf-label-static">
                    <p>{{$t("LABEL_CREATEDBY")}}</p>
                  </div>
                  <div class="col-xs-6">
                    <div>
                      {{item.auditDetails.createdBy}} <span>{{$t('LABEL_ON')}}</span>
                      {{item.auditDetails.createdTimeStamp | formatDateTime}}
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-xs-6 ocf-label-static">
                    <p>{{$t("LABEL_MODIFIEDBY")}}</p>
                  </div>
                  <div class="col-xs-6">
                    <div
                        v-show="item.auditDetails.modifiedBy!=null && item.auditDetails.modifiedBy!==''">
                      {{item.auditDetails.modifiedBy}} <span>{{$t('LABEL_ON')}}</span>
                      {{item.auditDetails.modifiedTimeStamp | formatDateTime}}
                    </div>
                    <div v-show="item.auditDetails.modifiedBy==null || item.auditDetails.modifiedBy===''">
                      -
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-tab-item>
    </v-tabs-items>
  </v-card>
</template>
<script>
export default {
  name:'Navbar',
  props:['actionTab','tabsData'],
  data(){
    return{
      actionTabFlag: this.actionTab,
      tab: 'null',
    };
  },
};
</script>
