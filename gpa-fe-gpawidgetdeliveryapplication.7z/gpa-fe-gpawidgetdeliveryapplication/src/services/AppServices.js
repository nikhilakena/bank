import axios from 'axios';
const baseUrl = process.env.VUE_APP_APIURL;
const baseUrl2 = process.env.VUE_APP_APIURL2;



const headers = {
    'Content-Type': 'application/json',
};

const AppServices = {
    getAllTermsServiceCall(request) {
        const url =baseUrl + 'retrieveall'+'?'+ request.params;
        console.log(url);
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    getTermDetailsById(term,request) {
        const url = baseUrl + term.id+'?'+ request.params;
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    async getTermDetailsByRouteId(routeId,request) {
        const url = baseUrl + routeId+'?'+ request.params;
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    retrieveTerms(request){
        const url =baseUrl +'retrieve?'+ request.params;
        console.log(url);
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    createTermServiceCall(TermRestResource){
        const url =baseUrl;
        console.log(url);
        const data = JSON.stringify(TermRestResource);
        return axios.post(url, data, {
            headers: headers,
        });
    },
    /*
      This function is to set service call for updating term
     */
    updateTermServiceCall:function(TermRestResource){
        const url =baseUrl;
        console.log(url);
        const data = JSON.stringify(TermRestResource);
        console.log(data);
        return axios.put(url, data, {
            headers: headers,
        });
    },
    /*
      This function is to set service call for deleting term
     */
    deleteTermServiceCall:function(term){
        const temp = 'delete/' + term.id;
        console.log(temp);
        const url =baseUrl+temp;
        console.log(url);
        return axios.delete(url, {
            headers: headers,
        });
    },
    retrieveAdmins(queryToSend){
        const url =baseUrl2 +'retrieve?'+ queryToSend.params;
        console.log(url);
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    async getAdminDetailsById(admin,request) {
        const url = baseUrl2 +'read/' +admin+'?'+ request.params;
        return axios.get(url).then((response) => response.data).catch(
            (error) => error.response.data);
    },
    /*
      This function is to set service call for deleting admin
     */
    deleteAdminServiceCall:function(admin){
        const temp = 'delete/' + admin.id;
        console.log(temp);
        const url =baseUrl2+temp;
        console.log(url);
        return axios.delete(url, {
            headers: headers,
        });
    },
    createAdminServiceCall(AdministrationRestResource){
        const temp = 'create';
        const url =baseUrl2+temp;
        console.log(url);
        const data = JSON.stringify(AdministrationRestResource);
        return axios.post(url, data, {
            headers: headers,
        });
    },
    updateAdminServiceCall:function(AdminRestResource){
        const url =baseUrl2 + 'update/';
        console.log(url);
        const data = JSON.stringify(AdminRestResource);
        console.log(data);
        return axios.put(url, data, {
            headers: headers,
        });
    },
};
export default AppServices;
