import axios from 'axios';
export default axios.create({
    timeout: 20000,
    headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Methods': 'POST, GET, PUT',
        // 'Access-Control-Allow-Origin': '*', // Maybe not needed
    },
});
