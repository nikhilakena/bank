<template>
  <div class="panel panel-default">
    <div class="panel-heading" style="padding-top: 5px;">
      <BackButton
          :actionBackButton="backAction"
          :back="back"
      />
      <h2 class="panel-title">
        <span>{{ $t("LABEL_UDPATE_ADMIN_SCREEN_NAME") }}</span>
      </h2>
    </div>
    <div class="panel-body">
      <notify
          :notificationType="msgType"
          :displayMessage="displayMsg"
          :closeNotification="closeNotify"
          @clear="notify($event, $event)"
          :title="toolMsg"
      />
      <ConfirmationPopUpTemplate
          v-if="confirmActionPopup"
          :actionPopUp="action"
          :cancel="cancel"
          :validatePopUpConfirm="validatePopUpConfirm"
          :selectedAction="selectedAction"
      />
      <div id="createBlock">
        <form class="form-horizontal v-pristine v-valid" name="createform">
          <div>
            <h4 class="panel-title" style="color: #608e28;">
              <span>{{ $t("LABEL_GENERAL_ADMIN_DETAILS") }}</span>
              <br />
              <br />
            </h4>
          </div>
          <div class="bs-component">
            <div class="well">
              <div class="row">
                <div class="col-xs-6 ocf-label-static">
                  <span>{{ $t("LABEL_ADMIN_NAME") }}</span>&nbsp;
                  <span style="color: #ff6347;">*</span>
                </div>
                <div class="col-xs-5" style="border: none;">
                  <input
                      class="w120 form-control"
                      tabindex="1"
                      type="text"
                      maxlength="150"
                      id="adminName"
                      on-keyup-fn="handleKeypress"
                      v-model="admin.name"
                      name="adminName"
                  />
                </div>
              </div>
              <br />
              <br />
              <div class="row">
                <div class="col-xs-6 ocf-label-static"><span>{{ $t("LABEL_ADMIN_DESCR") }}</span>&nbsp;<span style="color: #ff6347;">*</span></div>
                <div class="col-xs-5">
                  <textarea class="w120 form-control" rows="2" tabindex="2" name="description" spellcheck="false" type="text" maxlength="300" id="description" on-keyup-fn="handleKeypress" v-model="admin.description" />
                  <span class="help-block" v-if="admin.isSpecialCharPresentInAdminDesc">
                                        <span class="glyphicon glyphicon-warning-sign"></span>
                                        <span>{{ $t("LABEL_SPECIAL_CHARACTER") }}</span>
                                        admin.specialCharPresentInAdminDesc
                                        <span>{{ $t("LABEL_NOT_ALLOWED") }} </span>
                                    </span>
                </div>
              </div>
              <br />
              <br />
              <div class="row">
                <div class="col-xs-6 ocf-label-static"><span>{{ $t("LABEL_ADMIN_OWNER") }}</span>&nbsp;<span style="color: #ff6347;">*</span></div>
                <div class="col-xs-5" style="border: none;">
                  <input
                      class="w120 form-control"
                      tabindex="3"
                      name="adminOAR"
                      type="text"
                      maxlength="50"
                      id="adminOAR"
                      on-keyup-fn="handleKeypress"
                      v-model="admin.oarId"
                  />
                </div>
              </div>
              <br />
              <br />
              <div class="row">
                <div id="enableIText1111" class="ocf-i-text top collapse" role="tooltip" data-collapse="collapse" style="display: none;">
                  <div class="ocf-i-text-inner">
                    <h3>{{ $t("LABEL_PRODUCTS_INFO_HEADING") }}</h3>
                    <p>{{ $t("LABEL_PRODUCTS_INFO_DETAIL_STRING") }}</p>
                  </div>
                </div>
                <div class="col-xs-6 ocf-label-static">
                  <span>{{ $t("LABEL_PRODUCT_ID") }}</span>
                  <span style="color: #ff6347;">*</span>
                  <aab-info-popover>
                    <h4><span>How to set product IDs for an Administration?</span></h4>
                    <p><span>A numeric value for the Product ID has to be entered. In case more than one Product ID is applicable the values should be separated with comma</span></p>
                  </aab-info-popover>
                </div>
                <div class="col-xs-5">
                  <textarea class="w120 form-control" rows="2" tabindex="4" name="productid" spellcheck="false" type="text" id="productid" v-model="admin.products" on-keyup-fn="handleKeypress" />
                  <div>
                    <span class="glyphicon glyphicon-warning-sign form-control-feedback" v-if="isProductIDValid()" style="position: relative; float: left; margin-top: -7%;"></span>
                    <span class="help-block" style="margin-left: 25px;" v-show="isProductIDValid()">{{ $t("LABEL_PRODUCTID_INVALID") }}</span>
                  </div>
                </div>
              </div>
              <br />
              <br />

              <div class="row btn-group">
                <div class="col-xs-6"></div>
                <div class="col-xs-5">
                  <aab-button>
                    <button class="btn" tabindex="5" type="submit"
                            @click.prevent='checkGenericAdminDtls("admin")'>
                      <span>{{ $t("LABEL_ADD_TERMS") }}</span>
                    </button>
                  </aab-button>
                </div>

                <aab-modal modal-size="large">
                  <span slot="modal-title"  style='color: #608e28;font-size: 24px;margin-top: 10px;'>{{$t('LABEL_ADD_TERMS')}} </span>
                  <span slot="modal-content"  style='color: #608e28;font-size: 18px;margin-top: 20px; height: 100px;'>
                    <br/>
                    <div class="row" style="width: 90%">
                      <div class="col-xs-4 ocf-label-static"><span>{{$t('LABEL_SEARCH')}}</span></div>
                      <div class="col-xs-5" >
                        <input class="w120 form-control" rows="2"
                               name="search"  spellcheck="false"
                               type="text" maxlength="80"
                               placeholder="Enter term name"
                               v-model="search" id="search"  on-keyup-fn="handleKeypress"/>
                      </div>
                    </div>
                    <br/>
                    <div class="modal-body"
                         style="height: 300px; width: 650px; overflow-y: auto;">
                      <br>
                      <div class="table-responsive" style="margin-top: -5px">
                        <table class="table table-striped table-hover"
                               style="margin-bottom: 0px">
                                      <caption>Contains all available terms</caption>
                          <thead>
                          <tr>
                            <th>
                              <a href='' style="color :#608e28;text-decoration: none; cursor: default;" >{{$t('LABEL_GLOSSARY_DETAIL_SCREEN_NAME')}}</a>
                            </th>
                            <th>
                              <a href='' style="color :#608e28;    cursor: default;text-decoration: none;" >{{$t('LABEL_TERM_DATA_TYPE')}}</a>
                            </th>
                            <th>
                            </th>
                          </tr>
                          </thead>
                          <tbody>
                          <tr class="pointer" style="background-color: #f9f9f9;    cursor: default;"
                              v-for="(term,index) in terms" :key="index"
                              v-show="showTerm(term)">
                            <td class='' v-if='term.display===true'
                                style="width: 45%;word-break: break-all;">{{term.name}}
                              <p style ="font-size: 13px;">{{term.description}}</p>
                            </td>
                            <td class='' v-if='term.display===true'>
                              <span>{{$t(term.dataType)}}</span><!-- | translate-->
                            </td>
                            <td v-if='term.display===true'>
                              <input type="checkbox"  v-model="term.selected"
                                     @change="unselectAll(),
                                     $event.stopImmediatePropagation()"
                                     style="margin-left: 30px;"
                              ></td>
                          </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <br>

                  </span>
                  <span slot="modal-footer">
<!--                    <div class="modal-footer">-->
                      <aab-button style-type="primary" style="margin-right: 16px;">
                        <button type="button"
                                @click.prevent="saveAndCloseAdministrationTermsModal($event)"
                                :disabled='selectedCount<1'
                                class="btn">
                          <span>{{ $t('LABEL_SAVE') }}</span>
                        </button>
                      </aab-button>
                      <aab-button style-type="secondary">
                        <button type="button"
                                @click.prevent="allTermsSelected=false,
                            closePopModal($event)"
                                class="btn"
                                data-dismiss="modal">
                          <span>{{$t('LABEL_CLOSE')}}</span>
                        </button>
                      </aab-button>
<!--                    </div>-->
                  </span>
                </aab-modal>
              </div>
              <br />
            </div>
          </div>
          <updateTermViewPanel
              :actionTab='actionTab'
              :tabsData='this.admin.terms'
          /><br/>


          <div class="row">
            <div class="col-xs-12"></div>
            <div class="col-xs-12">
              <button class="btn btn-primary" tabindex="5" type="submit" @click.prevent="updateAdmin(admin)">
                <span>{{ $t("LABEL_SAVE") }}</span>  <!--showDemoModal-->
              </button>
            </div>
            <aab-modal id = "modal-save" modal-size="large">
              <span slot="modal-title" style="color: #608e28; font-size: 24px; margin-top: 10px;">{{$t("ALERT_UPDATE_ADMIN")}}</span>
              <span slot="modal-content" style="font-size: 18px; margin-top: 20px; height: 100px;"> {{$t("ALERT_UPDATE_ADMIN_MESSAGE")}} </span>
              <span slot="modal-footer">
<!--                <div class="modal-footer">-->
<button type="button"
        @click.prevent="closePopModalUpdate($event)"
        class="btn btn-primary"
        data-dismiss="modal">
                          <span>{{$t('LABEL_CLOSE')}}</span>
                        </button>                 <button type="primary" @click.prevent="updateAdminServiceCall(admin)" class="btn btn-primary">
                        <span>{{$t('LABEL_SAVE')}}</span> <!--saveAndCloseAdministrationUpdateModal($event)-->
                    </button>
<!--            </div>-->
        </span>
            </aab-modal>
          </div>
        </form>
      </div>
    </div>

  </div>
</template>
<script>
import BackButton from '../../../../../components/BackButton';
import updateTermViewPanel from '../../../../../components/updateTermViewPanel';
import ConfirmationPopUpTemplate from '../../../../../components/ConfirmationPopUp';
import utils from "../../../../../scripts/utils";
import appServices from "../../../../../services/AppServices";
import {sy_arrow_arrow_left} from "@aab/sc-aab-icon-set/src/lib/systems";
import {required} from "vuelidate/lib/validators";
import Notify from '../../../../../components/Notify';
import common from "@/mixins/common";

export default {
  name:'updateAdministration',
  components: { BackButton,Notify, ConfirmationPopUpTemplate,updateTermViewPanel },
  mixins: [common],
  data(){
    return {
      tabInfo: '[]',
      showtabs: false,
      viewResult: '',
      info: '',
      admin: '',
      terms:'',

      termListModal: '',
      queryToSend: {},
      sy_arrow_arrow_left,
      enableSpinner: false,
      displayMsg: '',
      allTermsSelected: false,
      showAdminTerms: true,
      msgType: '',
      toolMsg: '',
      closeNotify: '',
      errorMsg: '',
      action: '',
      confirmActionPopup: false,
      selectedAction: '',
      selectedTerms: [],
      selectedCount: 0,
      selectedTermNameList: [],
      search: [],
      backAction: '',
      actionBackButton: false,
      showMessage: false,
      actionTab:false,
      showErrorMessage : false,
      activeTermIndex : 0,
      enableAddAdmin : false,
      adminTerms : {},
      facetCategoryList : ['Single Value', 'Range', 'List'],
      facetCategoryListForBoolean : ['List'],
      singleValueFacets : ['Length', 'Pattern', 'Maximum length', 'Minimum length'],
      singleValueNumericFacets : ['Length', 'Pattern', 'Maximum length', 'Minimum length', 'Total Digits', 'Fractions'],
      rangeFacets : ['MinInclusive', 'MinExclusive', 'MaxInclusive', 'MaxExclusive'],
      enumFacets : ['List values'],
      ngChangeTrigger : false,

      stringSingleValueCombination : [
        ['Maximum length', 'Minimum length', 'Pattern'],
        ['Length', 'Pattern']
      ],

      stringRangeCombination : [
        ['MinInclusive', 'MaxInclusive'],
        ['MinInclusive', 'MaxExclusive'],
        ['MinExclusive', 'MaxInclusive'],
        ['MinExclusive', 'MaxExclusive']
      ],

      numericSingleValueCombination : [
        ['Maximum length', 'Minimum length', 'Pattern'],
        ['Length', 'Pattern'],
        ['Total Digits', 'Fractions']
      ],

      numericRangeCombination : [
        ['MinInclusive', 'MaxInclusive'],
        ['MinInclusive', 'MaxExclusive'],
        ['MinExclusive', 'MaxInclusive'],
        ['MinExclusive', 'MaxExclusive']
      ],

      facetTypeValueList : [{ 'singleValueFacets': this.singleValueFacets },
        {
          'facetType': [],
          'facetValue': []
        }],
    };
  },
  validations: {
    admin: {
      name: {required},
      description: {required},
      oarId: {required},
      products: {required}
    },
  },

  watch: {
    confirmActionPopup: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
    actionBackButton: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
  },

  mounted() {
    this.onLoad();
  },

  methods: {

    async onLoad(){
      // console.warn(this.$route.params.adminId);

      const queryToSend = {};
      queryToSend.currentTime= new Date();
      console.log(queryToSend);

      const params = new URLSearchParams();
      params.append('currentTime',(queryToSend.currentTime !== 'undefined'? queryToSend.currentTime:''));

      const request = {
        params: params
      };

      this.adminOldObj = await appServices.getAdminDetailsById(this.$route.params.adminId,request);
      this.admin = Object.assign({},this.adminOldObj);
      console.log("admin", this.admin);

      this.facetTypeEnumtoViewMapper(this.admin.terms);
      this.displayPreSelectedTerms(this.admin.terms);
      this.displayPreFilledFacetCatagory(this.selectedTerms);
      console.log('this.admin.terms', this.admin.terms);




      appServices.getAllTermsServiceCall(request).then((result) => {
        console.log("result", result);
        this.enableSpinner = false;
        this.terms = result;
        this.updateTermsObj(this.terms);
        console.log("this.terms", this.terms)


        this.termViewTemplateURL = "app/modules/createadmin/termViewPanel.html"; // term dtls template
      }).catch((error) => {
        console.log(error.response.data.errors[0]);
        this.httpServiceErrorCall(error);
      });},

    getValidCombination(term) {
      if (term.dataType === 'STRING' && term.facetCategory === 'Single Value') {
        return this.stringSingleValueCombination;
      }
      if (term.dataType === 'STRING' && term.facetCategory === 'Range') {
        return this.stringRangeCombination;
      }
      if (term.dataType === 'NUMERIC' && term.facetCategory === 'Single Value') {
        return this.numericSingleValueCombination;
      }
      if (term.dataType === 'NUMERIC' && term.facetCategory === 'Range') {
        return this.numericRangeCombination;
      }


    },
    getValidfacetTypes(_$event, index, obj, allpossibleCombinations) {
      if (!this.ngChangeTrigger) {
        let temp = [];

        if (utils.isEmpty(obj.facets) || obj.facets.length < 1) {
          temp = [];
          obj.facets = [];
          obj.facets[index] = {};
        } else {
          for (let i = 0; i < obj.facets.length; i++) {
            temp.push(obj.facets[i].facetType);
          }
          if (obj.facets[index] === undefined) {
            obj.facets[index] = {};
          }
        }
        obj.facets[index].availableFacets = this.getStringSingleValueDropdown(allpossibleCombinations, temp, index);
        obj.facets[index].showFlag = true;
      }
      this.ngChangeTrigger = false;
    },


    getStringSingleValueDropdown(allpossibleCombinations, selectedValues, index) {
      if (index > 0) {
        const fileredSelectedValues = [];
        for (let m = 0; m < index; m++) {
          fileredSelectedValues[m] = selectedValues[m];
        }

        const fileredStringSingleValueCombination = [];
        let k = -1;

        if ((allpossibleCombinations !== undefined)) {
          for (let i = 0; i < allpossibleCombinations.length; i++) {
            let flag = true;
            for (let j = 0; j < fileredSelectedValues.length; j++) {
              if (allpossibleCombinations[i].indexOf(fileredSelectedValues[j]) === -1) {
                flag = false;
              }
            }
            if (flag) {
              k++;
              fileredStringSingleValueCombination[k] = allpossibleCombinations[i];
            }
          }
        }

        const allowedsubFacets = this.getAllStringSubFacets(fileredStringSingleValueCombination);
        const uniqueAllowedsubFacets = this.getUniqueArray(allowedsubFacets);
        return this.removeSelectedFacetsFromAllowed(uniqueAllowedsubFacets, fileredSelectedValues);
      } else {
        if ((allpossibleCombinations !== undefined)) {
          const allSubFacets = this.getAllStringSubFacets(allpossibleCombinations);
          const uniqueItems = this.getUniqueArray(allSubFacets);
          return uniqueItems;
        }

      }
    },
    removeSelectedFacetsFromAllowed(uniqueAllowedsubFacets, fileredSelectedValues) {
      const subFacets = [];
      let k = -1;
      for (let i = 0; i < uniqueAllowedsubFacets.length; i++) {
        let flag = false;
        for (let j = 0; j < fileredSelectedValues.length; j++) {
          if (fileredSelectedValues[j] === uniqueAllowedsubFacets[i]) {
            flag = true;
          }
        }
        if (!flag) {
          k++;
          subFacets[k] = uniqueAllowedsubFacets[i]
        }
      }
      return subFacets;
    },


    getUniqueArray(allValues) {


      const distinctValues = [];

      for (let i = 0; i < allValues.length; i++) {
        const str = allValues[i];
        if (distinctValues.indexOf(str) === -1) {
          distinctValues.push(str);
        }
      }
      return distinctValues;
    },


    getAllStringSubFacets(stringSingleValueCombination) {
      if ((stringSingleValueCombination !== undefined)) {
        const subFacets = [];
        let k = -1;
        for (let i = 0; i < stringSingleValueCombination.length; i++) {
          for (let j = 0; j < stringSingleValueCombination[i].length; j++) {
            k++;
            subFacets[k] = stringSingleValueCombination[i][j];
          }
        }
        return subFacets;
      }

    },


    getValidfacetTypesOnLoad($event, index, obj) {
      const allpossibleCombinations = this.getValidCombination(obj);
      this.ngChangeTrigger = false;
      this.getValidfacetTypes($event, index, obj, allpossibleCombinations);
    },

    getValidfacetTypesOnLoadNextValue($event, index, obj) {
      if (obj.validated) {
        obj.validated = false;
      }

      const allpossibleCombinations = this.getValidCombination(obj);
      this.getValidfacetTypes($event, index, obj, allpossibleCombinations);

      this.ngChangeTrigger = true;
      if (obj.facets[index] !== undefined) {
        if (index > 0) {
          obj.facets[index].showFlag = false;
        } else {
          obj.facets[index].showFlag = true;
        }
      }
    },



    facetCategoryOnLoad($event, obj) {
      if (obj.validated) {
        obj.validated = false;

      }
      for (let i = 0; i < obj.facets.length; i++) {
        this.getValidfacetTypesOnLoad($event, i, obj);
      }
      const nextIndex = obj.facets.length;
      if (obj.facets[nextIndex] === undefined) {
        obj.facets[nextIndex] = {};
        this.ngChangeTrigger = false;
        this.getValidfacetTypesOnLoadNextValue($event, nextIndex, obj);
      }

    },


    displayPreFilledFacetCatagory(selectedTerms) {
      for (let i = 0; i < selectedTerms.length; i++) {

        if (selectedTerms[i].facets !== null) {
          for (let j = 0; j < selectedTerms[i].facets.length; j++) {
            if (this.singleValueFacets.indexOf(selectedTerms[i].facets[j].facetType) > -1) {
              selectedTerms[i].facetCategory = this.facetCategoryList[0];
            }
            if (this.rangeFacets.indexOf(selectedTerms[i].facets[j].facetType) > -1) {
              selectedTerms[i].facetCategory = this.facetCategoryList[1];
            }
            if (this.enumFacets.indexOf(selectedTerms[i].facets[j].facetType) > -1) {
              selectedTerms[i].facetCategory = this.facetCategoryList[2];
            }
            if (this.singleValueNumericFacets.indexOf(selectedTerms[i].facets[j].facetType) > -1) {
              selectedTerms[i].facetCategory = this.facetCategoryList[0];
            }
          }
          this.facetCategoryOnLoad(null, selectedTerms[i]);
        }
      }
    },

    facetTypeEnumtoViewMapper(value) {
      for (let j = 0; j < value.length; j++) {
        if (value[j].facets !== null) {
          for (let i = 0; i < value[j].facets.length; i++) {
            if (value[j].facets[i].facetType === 'ENUMERATION') {
              value[j].facets[i].facetType = 'List values';
              value[j].facetValue = value[j].facets[i].facetValue;
            }
            if (value[j].facets[i].facetType === 'LENGTH') {
              value[j].facets[i].facetType = 'Length';
            }
            if (value[j].facets[i].facetType === 'PATTERN') {
              value[j].facets[i].facetType = 'Pattern';
            }
            if (value[j].facets[i].facetType === 'MAXLENGTH') {
              value[j].facets[i].facetType = 'Maximum length';
            }
            if (value[j].facets[i].facetType === 'MINLENGTH') {
              value[j].facets[i].facetType = 'Minimum length';
            }
            if (value[j].facets[i].facetType === 'MININCLUSIVE') {
              value[j].facets[i].facetType = 'MinInclusive';
            }
            if (value[j].facets[i].facetType === 'MAXINCLUSIVE') {
              value[j].facets[i].facetType = 'MaxInclusive';
            }
            if (value[j].facets[i].facetType === 'MINEXCLUSIVE') {
              value[j].facets[i].facetType = 'MinExclusive';
            }
            if (value[j].facets[i].facetType === 'MAXEXCLUSIVE') {
              value[j].facets[i].facetType = 'MaxExclusive';
            }
            if (value[j].facets[i].facetType === 'TOTALDIGITS') {
              value[j].facets[i].facetType = 'Total Digits';
            }
            if (value[j].facets[i].facetType === 'FRACTIONS') {
              value[j].facets[i].facetType = 'Fractions';
            }
          }
        }
      }
    },

    displayPreSelectedTerms(selectedTerms) {
      this.selectedTerms = [];
      this.selectedTerms = selectedTerms;
      if (this.selectedTerms.length > 0) {
        this.showAdminTerms = true;
      }
      for (let i = 0; i < this.terms.length; i++) {
        let matchingFlag = false;
        for (let j = 0; j < selectedTerms.length; j++) {
          if (this.terms[i].id === selectedTerms[j].id) {
            matchingFlag = true;
            break;
          }
        }
        if (matchingFlag) {
          this.terms[i].display = false;
        }
      }
    },


    isSpecialCharacterPresentInOAR(input) {
      this.admin.isSpecialCharPresentInOAR = false;
      if (null != input && input.length > 0 && this.validateUnicode(input) !== '') {
        this.admin.isSpecialCharPresentInOAR = true;
        this.admin.specialCharInAdminOAR = this.validateUnicode(input);
        return true;
      }
      return false;
    },


    updateTermsObj(obj) {
      this.terms = obj;
      this.terms.forEach(function (term) {
        term.display = true;
      });
    },

    back() {
      this.selectedAction = 'backButton';
      this.actionBackButton = true;
      this.confirmPopUp();
    },

    confirmPopUp() {
      this.confirmActionPopup = true;
    },
    isProductIDValid() {
      // return (this.admin.products.$invalid && !this.admin.$pristine);
    },
    unselectAll() {
      let keepGoing = true;
      let count = 0;
      let selectedCount = 0;
      const termCount = this.terms.length;
      this.terms.forEach(function (term) {
        if (term.selected === true) {
          selectedCount++;
          if (selectedCount === termCount) {
            this.allTermsSelected = true;
          }
        }
      });
      this.selectedCount = selectedCount;
      this.terms.forEach(function (term) {
        count = count+1;
        if ((keepGoing) && (term.selected === false) ){
            this.allTermsSelected = false;
            keepGoing = false;
        }
      });
    },

    saveAndCloseAdministrationTermsModal(e) {
      const modalDemo = document.querySelector('aab-modal');
      modalDemo.closeModal(e);
      this.showtabs = true;
      this.saveTermsInAdmin();
    },

    saveAndCloseAdministrationUpdateModal(e) {
      const modalDemo = document.querySelector('aab-modal');
      modalDemo.closeModal(e);
      this.showtabs = true;
      this.updateAdmin(this.admin);
      this.$router.push({ name: 'administrationOverview' }, () => {
        window.location.reload();
      });
    },
    closePopModal(e) {
      const modalDemo = document.querySelector('aab-modal');
      modalDemo.closeModal(e);
    },
    closePopModalUpdate(e) {
      const modalDemo = document.getElementById("modal-save");
      modalDemo.closeModal(e);
      /*const modalDemo = document.querySelector('aab-modal');
      modalDemo.closeModal(e);*/
    },


    validatePopUpConfirm() {
      if(this.selectedAction==='backButton'){
        this.$router.push({ name: 'administrationOverview' }, () => {
          window.location.reload();
        });
        this.back();
      }
    },
    cancel() {
      this.confirmActionPopup = false;
    },

    saveTermsInAdmin() {
      this.selectedCount = 0;
      if (this.selectedTerms === undefined) {
        this.selectedTerms = [];
      }

      let index;
      for (index = 0; index < this.terms.length; index++) {
        if (this.terms[index].display === true && this.terms[index].selected) {
          this.terms[index].display = false;
          this.terms[index].facetTypeValueList = [{ singleValueFacets: this.singleValueFacets }];
          this.selectedTerms.push(this.terms[index]);
          this.showAdminTerms = true;
          this.terms[index].facets = [];
        }
      }
      this.checkDuplicateTerms(this.selectedTerms);
      this.search = '';
    },

    closeAdministrationTermsModalModal(e) {
      const modalDemo = document.querySelector('aab-modal');
      modalDemo.closeModal(e);
      this.showtabs = true;
      this.saveTermsInAdmin();
    },

    selectUsers(id) {
      if (this.selectedTerms.includes(id)) {
        /*this.selectedTerms= .without(this.selectedTerms,id)*/
      } else {
        const obj2 = JSON.parse(this.tabInfo);
        const obj = { title: id, id: id };
        this.selectedTerms.push(id);
        obj2.push(obj);
        this.tabInfo = JSON.stringify(obj2);
      }

      console.log(this.selectedTerms);
      console.log(this.tabInfo);
    },

/*    showDemoModal() {
      if (this.updateAdmin(this.admin) == true) {
        this.checkGenericAdminDtls('save');
        const modalDemo = document.getElementById("modal-save");
        modalDemo.openModal();
        // this.retrieveAll();
      }
    },*/

    showTerm(term) {
      if (this.search !== undefined && this.search !== '') {
        if (term.name.indexOf(this.search) !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return true;
      }
    },

    facetTypeViewToEnumMapper(value) {
      for (let j = 0; j < value.length; j++) {
        if ((value[j].facets) !== undefined && value[j].facets !== null) {
          for (let i = 0; i < value[j].facets.length; i++) {
            if (value[j].facets[i].facetType === 'List values') {
              value[j].facets[i].facetType = 'ENUMERATION';
            }
            if (value[j].facets[i].facetType === 'Length') {
              value[j].facets[i].facetType = 'LENGTH';
            }
            if (value[j].facets[i].facetType === 'Pattern') {
              value[j].facets[i].facetType = 'PATTERN';
            }
            if (value[j].facets[i].facetType === 'Maximum length') {
              value[j].facets[i].facetType = 'MAXLENGTH';
            }
            if (value[j].facets[i].facetType === 'Minimum length') {
              value[j].facets[i].facetType = 'MINLENGTH';
            }
            if (value[j].facets[i].facetType === 'MinInclusive') {
              value[j].facets[i].facetType = 'MININCLUSIVE';
            }
            if (value[j].facets[i].facetType === 'MaxInclusive') {
              value[j].facets[i].facetType = 'MAXINCLUSIVE';
            }
            if (value[j].facets[i].facetType === 'MinExclusive') {
              value[j].facets[i].facetType = 'MINEXCLUSIVE';
            }
            if (value[j].facets[i].facetType === 'MaxExclusive') {
              value[j].facets[i].facetType = 'MAXEXCLUSIVE';
            }
            if (value[j].facets[i].facetType === 'Total Digits') {
              value[j].facets[i].facetType = 'TOTALDIGITS';
            }
            if (value[j].facets[i].facetType === 'Fractions') {
              value[j].facets[i].facetType = 'FRACTIONS';
            }
          }
        }
      }
    },


    validateFacetFormat(obj) {
      const temp = Object.assign([], obj);
      for (let i = 0; i < temp.length; i++) {
        if ((temp[i].facets)!==undefined && temp[i].facets !== null) {
          for (let j = 0; j < temp[i].facets.length; j++) {
            if (temp[i].facets[j].showFlag === false || (temp[i].facets[j].facetValue)==undefined) {
              temp[i].facets.splice(j, 1);
            }
          }
        }

      }
      return temp;

    },

validateMandatoryTermEnumValue(AdministrationRestResource) {
  for (let i = 0; i < AdministrationRestResource.terms.length; i++) {
    if (!(AdministrationRestResource.terms[i].mandatory === true
        || AdministrationRestResource.terms[i].mandatory === false)) {
      AdministrationRestResource.terms[i].mandatory = false;
    }
  }
},



updateAdminServiceCall(admin) {
  const AdministrationRestResource = new Object();
  AdministrationRestResource.products = []
  AdministrationRestResource.terms = [];
  AdministrationRestResource.name = (this.admin.name);
  AdministrationRestResource.description = (this.admin.description);
  AdministrationRestResource.oarId = this.admin.oarId;
  AdministrationRestResource.id = this.admin.id;

  AdministrationRestResource.products = this.productList;
  if (!utils.isEmpty(this.admin.terms)) {
    const tempObj = this.validateFacetFormat(this.admin.terms);
    AdministrationRestResource.terms = tempObj;
    this.facetTypeViewToEnumMapper(AdministrationRestResource.terms);
  }

  this.validateMandatoryTermEnumValue(AdministrationRestResource);

  appServices.updateAdminServiceCall(AdministrationRestResource, function (result) {
    this.updateAdminResponse = result;
    this.processUpdateAdminResponse(this.updateAdminResponse, admin);
  }, function (error) {
    this.showProduct = false;
    this.httpServiceErrorCall(error);
  });
  this.$router.push({ name: 'administrationOverview' }, () => {
    window.location.reload();
  });
},


    updateAdmin(admin) {
      if (!this.validateGeneralFormDtls(admin, 'ALERT_SPECIAL_CHAR_IN_CREATE')) {
        return false;
      } else if (this.validateGeneralFormDtls(admin, 'ALERT_SPECIAL_CHAR_IN_CREATE')
          && (this.validateProductIdFormat(admin.products))==undefined
          && !this.validateProductIdFormat(admin.products)
          && !this.hasDuplicatesPrducts(this.productList)
          && this.validateTermsDtls()) {
        this.showMessage = false;
        admin.terms = [];
        admin.terms = this.selectedTerms;
        admin.id = this.admin.id;
        this.checkGenericAdminDtls('save');
        const modalDemo = document.getElementById("modal-save");
        modalDemo.openModal();
        this.showtabs = true;
      } else if (this.validateGeneralFormDtls(admin, 'ALERT_SPECIAL_CHAR_IN_CREATE')
          || this.validateProductIdFormat(admin.products)
          || this.validateTermsDtls()
          || this.hasDuplicatesPrducts(this.productList)) {
        this.showMessage = true;
      }

    },


    processUpdateAdminResponse(){
      const updateAdminResponse = {};

      updateAdminResponse.adminId=this.admin.id;
      this.$router.push({ name: 'administrationOverview' });
    },
    validateGeneralFormDtls(admin, label) {
      console.log('Inside validateGeneralFormDtls - >' + label);
      if (
          utils.isEmpty(admin.name) ||
          utils.isEmpty(admin.description) ||
          utils.isEmpty(admin.oarId) ||
          utils.isEmpty(admin.products)
      ) {
        this.notify('', '');
        this.notify('warning', 'ERROR_MANDATORY_CREATE_ADMIN', true);
        this.showMessage = true;
        console.log('ShowMessage1', this.showMessage);
        return false;
      } else {
        return true;
      }
    },
     hasDuplicatesPrducts(array) {
      const valuesSoFar = Object.create(null);
      if (array.length < 1) {
        this.notify('', '');
        this.notify('warning', 'LABEL_EMPTY_PRODUCTS', true);
        return true;
      }
      for (let i = 0; i < array.length; ++i) {
        const value = array[i];

        if (value in valuesSoFar) {
          this.notify('', '');
          this.notify('warning', 'LABEL_DUPLICATE_PRODUCTS', true);
          return true;
        }
        valuesSoFar[value] = true;
      }
      return false;
    },
    showAdministrationTermsModal() {
      const modalDemo = document.querySelector('aab-modal');
      modalDemo.openModal();
    },


    checkGenericAdminDtls(verificationType) {

      if (!this.validateGeneralFormDtls(this.admin, 'ALERT_SPECIAL_CHAR_BEFORE_ATTACH_TERM')) {
        this.termListModal = '';
      } else if (this.validateProductIdFormat(this.admin.products) !== undefined
          && !this.validateProductIdFormat(this.admin.products)) {
        this.termListModal = '';
        this.showMessage = true;
        this.notify('', '');
        this.notify('warning', 'LABEL_ALL_TERMS_ADDED', true);
      } else if (this.hasDuplicatesPrducts(this.productList)) {
        this.termListModal = '';
        this.showMessage = true;
        this.notify('', '');
        this.notify('warning', 'ERROR_MANDATORY_CREATE_TERM', true);
      } else if (this.selectedTerms !== undefined
          && this.selectedTerms.length === this.terms.length) {
        this.termListModal = '';
        this.showMessage = true;
        this.notify('', '');
        this.notify('warning', 'LABEL_ALL_TERMS_ADDED', true);
      } else {
        this.showMessage = false;
        this.termListModal = '#myModal';
        if (verificationType === "admin") {this.showAdministrationTermsModal();}
      }
    },

    notify(type, msg, close = true) {
      this.msgType = type;
      this.displayMsg = msg !== '' ? msg : '';
      this.toolMsg = msg;
      this.closeNotify = close;
    }

  }
};
</script>

