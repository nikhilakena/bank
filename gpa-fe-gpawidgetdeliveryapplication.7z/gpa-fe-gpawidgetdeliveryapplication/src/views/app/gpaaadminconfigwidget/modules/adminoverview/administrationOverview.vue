<template>
  <div class="panel panel-default">
    <div class="panel-heading" >
      <h2 class="panel-title"><span> {{ $t("LABEL_ADMIN_OVERVIEW_SCREEN_NAME") }}</span></h2>
    </div>
    <div class="panel-body" v-cloak>
      <notify
          :notificationType="msgType"
          :displayMessage="displayMsg"
          :closeNotification="closeNotify"
          @clear="notify($event, $event)"
          :title="toolMsg"
      />
      <div id ="searchblock" >
        <form class="form-horizontal v-pristine v-valid" name="searchform" v-cloak>
          <div class="bs-component">
            <div>
              <div class="well">
                <div class="row" style="margin-right: -45px;margin-top: -20px">
                  <div class="col-xs-11" style="padding-right: 0px; width: 94.5%;">
									<span class="btn-link v-scope" style="margin-top: 13px; float: right; cursor: pointer; text-decoration: underline;"
                        v-on:click="resetSearchCriteria"
                         alt="New Search">{{ $t("LABEL_NEW_SEARCH") }}</span>
                  </div>
                  <div class="col-xs-1" style="width: 4%;padding-left: 0px; margin-top: 12px;">
                    <span title="reset" class="glyphicon glyphicon-refresh" id="reset"  alt="reset"></span>
                  </div>
                </div>
                <br>
                <div class="row" id="searchblock2" style="text-align:right; display:block;">
                  <div class="row">
                    <div class="col-xs-5 form-group-first"><strong><p> {{ $t("LABEL_ADMIN_ID") }}</p></strong></div>
                    <div class="col-xs-3 form-group-first"  >
                      <input class="w120 form-control"
                             name="adminId"
                             type="text"
                             v-model="searchAdminModel.adminId"
                             :placeholder="$t('LABEL_ADMIN_ID')"
                             @input="
                        searchAdminModel.adminId.length
                          ? $v.searchAdminModel.adminId.$touch()
                          : $v.searchAdminModel.adminId.required"
                             maxlength="6"
                             id="adminId"
                             @keyup.enter="search"/>
                      <span
                          class="glyphicon glyphicon-warning-sign form-control-feedback"
                          v-if="isAdminIdValid"
                      ></span>
                      <span
                          class="help-block error-show"
                          v-show="isAdminIdValid"
                      >{{ $t("LABEL_ADMINID_INVALID") }}</span>
                      <br />
                  </div>
                  </div>
                  <br>

                  <div class="row">
                    <div class="col-xs-5 form-group-first"><strong><p> {{ $t("LABEL_ADMIN_NAME") }}</p></strong></div>
                    <div class="col-xs-3" >
                      <input class="w120 form-control"
                             name="adminName"
                             type="text"
                             v-model="searchAdminModel.adminName"
                             :placeholder="$t('LABEL_ADMIN_NAME')"
                             @input="
                        searchAdminModel.adminName.length
                          ? $v.searchAdminModel.adminName.$touch()
                          : $v.searchAdminModel.adminName.required"
                             maxlength="150"
                             id="adminName"
                             @keyup.enter="search"/>    <!---->
                      <br />
                    </div>

                  </div>
                  <br>

                  <div class="row">
                    <div class="col-xs-5 form-group-first"><strong><p>{{ $t("LABEL_ADMIN_OWNER") }}</p></strong></div>
                    <div class="col-xs-3" >
                      <input class="w120 form-control"
                             name="adminOwner"
                             type="text"		maxlength="50"
                             v-model="searchAdminModel.adminOwner"
                             :placeholder="$t('LABEL_ADMIN_OWNER')"
                              id="adminOwner" on-keyup-fn="handleKeypress"/>   <!---->
                      <br />
                    </div>

                  </div>
                  <br>

                  <div class="row">
                    <div class="col-xs-5 form-group-first"><strong><p>{{ $t("LABEL_CREATED_BY") }}</p></strong></div>
                    <div class="col-xs-3" >
                      <input
                        class="w120 form-control"
                        name="createdBy"
                        type="text"
                        v-model="searchAdminModel.createdBy"
                        :placeholder="$t('LABEL_CREATED_BY')"
                        @input="
                        searchAdminModel.createdBy.length
                          ? $v.searchAdminModel.createdBy.$touch()
                          : $v.searchAdminModel.createdBy.required"
                        maxlength="8"
                        id="createdBy"
                        @keyup.enter="search"
                    />
                      <br />
                    </div>

                  </div>
                  <br>

                  <div class="row">
                    <div class="col-xs-5 form-group-first" style="padding-top: 5px;"><strong><p>{{ $t("LABEL_CREATED_FROM") }}</p></strong></div>

                    <div  class="col-xs-3 form-group-first">

                      <date-picker v-model="searchAdminModel.createdFrom"
                                   format="DD.MM.YYYY"
                                   valuetype="format"
                                   lang="jp" style="color:seagreen"
                                   placeholder="DD.MM.YYYY"
                        id="createdFrom">
                      </date-picker>
                      <span class="help-block" v-show="!isCreatedFromValid" style="text-align: left;float:left" >
								<span class="glyphicon glyphicon-warning-sign" v-if="!isCreatedFromValid"></span>
								<span> {{ $t("LABEL_DATE_INVALID") }}</span>
								</span>

                    </div>
                    <br />
                  </div>

                  <br>

                  <div class="row">
                    <div class="col-xs-5 form-group-first" style="padding-top: 5px;" ><strong><p>{{ $t("LABEL_CREATED_TO") }}</p></strong></div>

                    <div  class="col-xs-3 form-group-first">

                      <date-picker v-model="searchAdminModel.createdTo"
                                   format="DD.MM.YYYY"
                                   valuetype="format"
                                   lang="jp" style="color:seagreen"
                                   placeholder="DD.MM.YYYY">
                      </date-picker>
                      <span class="help-block" v-show="!isCreatedToValid"  style="text-align: left; float:left">
								<span class="glyphicon glyphicon-warning-sign " v-show="!isCreatedToValid"  ></span>
								<span>{{ $t("LABEL_DATE_INVALID")}}</span>
								</span>

                    </div>

                  </div>
                  <br />
                </div>

                <br>

                <div class="row"   >

                  <div class="col-xs-7" >
                    <button v-on:click.prevent="searchAdminFun" id="searchAdminButton" type="submit" class="btn btn-primary"  >
                      <span> {{ $t("LABEL_SEARCH") }}</span>
                    </button>

                  </div>

                  <div class="col-xs-5" >
                    <button type="submit" style="float:right;" class="btn btn-primary" v-on:click.prevent="create" >
                      <span translate style="margin-left: 15px;margin-right: 10px;">{{ $t("LABEL_CREATE_NEW") }}</span>
                    </button>
                  </div>


                </div>
                <br>
              </div>

            </div>

          </div>
      </form>


        <div class="table-responsive" v-if="viewResult" >
          <table class="table table-striped table-hover" >
            <thead>
            <tr>
              <th v-column-sortable @click="sortTable('id')" style="color :#608e28;">
                {{ $t("LABEL_ADMIN_ID") }}
              </th>
              <th v-column-sortable @click="sortTable('name')" style="color :#608e28;">
                {{ $t("LABEL_ADMIN_NAME") }}
              </th>
              <th v-column-sortable @click="sortTable('oarId')" style="color :#608e28;">
                {{ $t("LABEL_ADMIN_OWNER") }}
              </th>
              <th style="color :#608e28;">
                {{ $t("LABEL_CREATED_BY") }}
              </th>
              <th style="color :#608e28;">
                {{ $t("LABEL_CREATED_TS") }}
              </th>
              <th></th>
            </tr>
            </thead>
            <tbody>
                <tr class="pointer" style="background-color: #f9f9f9;"
                    v-for="(admin) in viewResult" :key="admin.id" >
                  <td style="text-decoration: underline;" class="" v-on:click="viewAdmin(admin)" ><a>{{admin.id}}</a></td>
                  <td class="" style="word-break: break-all;word-wrap: break-word;">{{admin.name}}</td>
                  <td class="" style="word-break: break-all;word-wrap: break-word;">{{admin.oarId}}</td>
                  <td class="">{{admin.auditDetails.createdBy}}</td>
                  <td class="">{{admin.auditDetails.createdTimeStamp | formatDate}}</td>
                  <aab-button fluid style-type="primary">
                    <button :aria-label="$t('LABEL_UPDATE')"
                            class="nav-link"
                            v-on:click.prevent="updateAdmin(admin)" type="submit">
                      <aab-icon
                          slot="icon"
                          :svg="sy_tools_pencil"
                          size="3"
                          color="black"
                      /> <!---->
                    </button>
                  </aab-button>

                </tr>

            </tbody>
          </table>

        </div>


    </div>
  </div>
  </div>
</template>
<script>
import DatePicker from 'vue2-datepicker';
import {maxLength, required} from 'vuelidate/lib/validators';
import appServices from '@/services/AppServices';
import columnSortable from 'vue-column-sortable';
import { sy_tools_search as sy_tools_search,
  sy_shapes_plus_large as sy_shapes_plus_large,
  sy_tools_pencil as sy_tools_pencil,
  sy_tools_trash as sy_tools_trash} from '@aab/sc-aab-icon-set';

import Notify from '../../../../../components/Notify';
const adminIdPattern = (value) => /^[0-9]{1,6}$/.test(value);
export default {
  name: 'administrationOverview',
  components: {DatePicker, Notify},
  directives: {
    columnSortable
  },
  data() {
    return {
      mDatePicker: '',
      viewResult:'',
      sy_tools_search,
      sy_shapes_plus_large,
      sy_tools_pencil,
      sy_tools_trash,
      searchAdminModel: {
        adminId: '',
        adminName: '',
        createdBy: '',
        oarId: '',
        createdTimeStamp: '',
        createdFrom: '',
        createdTo: '',
      },
      showAdmin: false,
      showMessage: false,
      paramString: '',
      sort: {
        column: 'id',
        descending: false
      },
      enableSpinner: false,
      displayMsg: '',
      msgType: '',
      toolMsg: '',
      closeNotify: '',
    };
  },
  validations: {
    searchAdminModel: {
      adminId: {
        // eslint-disable-next-line no-undef
        required,
        adminIdPattern,
      },
      adminName: {
        required, maxLength,
      },
    },
  },
  computed: {
    isAdminIdValid() {
      return (
          this.$v.searchAdminModel.adminId.$error && !this.$v.searchAdminModel.$pristine
      );
    },
    disableSearchButton() {
      return this.$v.searchAdminModel.$invalid;
    },
  },
  methods:{
    isEmpty(str) {
      return (!str || 0 === str.length);
    },
    isAdminIDValidCheck() {
      return (
          this.searchAdminModel.adminId.$invalid && !this.searchAdminModel.$pristine
      );
    },
    isCreatedFromValid(){
      console.log('inside isCreatedFromValid2');
      if (this.searchAdminModel.createdFrom!==undefined && this.searchAdminModel.createdFrom !== '' && this.searchAdminModel.createdFrom !== 'DD.MM.YYYY') {
        return (this.searchAdminModel.createdFrom.$invalid);
      }
      return false;
    },
    isCreatedToValid(){
      console.log('inside isCreatedToValid2');
      if (this.searchAdminModel.createdTo!==undefined && this.searchAdminModel.createdTo !== '' && this.searchAdminModel.createdTo !== 'DD.MM.YYYY') {
        return (this.searchAdminModel.createdTo.$invalid);
      }
      return false;
    },

    sortTable: function(col) {
      if (this.sortColumn === col) {
        this.ascending = !this.ascending;
      } else {
        this.ascending = true;
        this.sortColumn = col;
      }
      const isAscending = this.ascending;
      this.viewResult.sort(function(a, b) {
        if (a[col] > b[col]) {
          return isAscending ? 1 : -1;
        } else if (a[col] < b[col]) {
          return isAscending ? -1 : 1;
        }
        return 0;
      });
    },
    updateAdmin(admin){
      this.$router.push('/updateAdministration/'+admin.id);
    },

    viewAdmin(admin){
      console.log(admin);
      this.$router.push('/viewAdministrationDetails/'+admin.id);
    },
    create() {
      this.$router.push({ name: 'createAdmin' });
    },
    moveToTop(){
      ('html, body').animate({
        scrollTop: 0
      }, 600);
      return false;

    },
    httpServiceErrorCall(error){
      // this.moveToTop();
      this.notify('', '');
      if(error.status===403||error.status===401){
        this.notify('warning','LABEL_AUTHORIZATION_ERROR',true);
        this.showMessage=true;
      }else if(error.status===500 || error.status===404 || error.status===405){
        this.notify('warning','LABEL_ERROR',true);
        this.showMessage=true;
      }else {
        this.notify('warning',error.data.errors[0].code,true);
        this.showMessage=true;
      }
    },
    setSearchCriteria(queryToSend){
      const queryToSendCopy=queryToSend;
      queryToSendCopy.createdFrom=new Date(this.searchAdminModel.createdFrom).getTime();
      queryToSendCopy.createdTo=new Date(this.searchAdminModel.createdTo).getTime();
    },
    notify(type, msg, close=true) {
      this.msgType = type;
      this.displayMsg = msg !== '' ? msg : '';
      this.toolMsg = msg;
      this.closeNotify = close;
    },

    getFormattedDate(date){
      const  year = '' + date.getFullYear();
      const  month = '' + (date.getMonth() + 1);
      const  day = '' + date.getDate();
      if (month.length === 1){
        this.month = '0' + month;
      }
      if (day.length === 1){
        this.day = '0' + day;
      }
      return  day + '-' + month + '-' + year;
    },
    resetSearchCriteria(){
      this.showAdmin= false;
      this.searchAdminModel= {};
      this.viewResult = {};
      this.$router.go(0);
    },
    searchAdminFun(){
      this.notify('', '');
      this.showAdmin = false;
      const queryToSend={};
      let isCriteriaValid= false;

      if((this.isAdminIDValidCheck() || this.isCreatedFromValid() || this.isCreatedToValid())){
        this.notify('', '');
        this.notify('warning', 'LABEL_FORM_ERRORS', true);
        this.showMessage=true;
        return false;
      }
      const params = new URLSearchParams();
      if(this.searchAdminModel.adminId!==undefined && !this.isEmpty(this.searchAdminModel.adminId)){
        queryToSend.id= this.searchAdminModel.adminId;
        params.append('id',this.searchAdminModel.adminId);
        isCriteriaValid = true;
      }
      if(this.searchAdminModel.adminOwner!==undefined && !this.isEmpty(this.searchAdminModel.adminOwner)){
        queryToSend.oarid=this.searchAdminModel.adminOwner;
        params.append('oarid',this.searchAdminModel.adminOwner);
        isCriteriaValid = true;
      }
      if(this.searchAdminModel.createdFrom!==undefined && !this.isEmpty(this.searchAdminModel.createdFrom)){
        queryToSend.createdFrom=this.getFormattedDate(this.searchAdminModel.createdFrom);
        params.append('createdFrom',this.getFormattedDate(this.searchAdminModel.createdFrom));
        isCriteriaValid = true;
      }
      if(this.searchAdminModel.createdTo!==undefined && !this.isEmpty(this.searchAdminModel.createdTo)){
        queryToSend.createdTo=this.getFormattedDate(this.searchAdminModel.createdTo);
        params.append('createdTo',this.getFormattedDate(this.searchAdminModel.createdTo));
        isCriteriaValid = true;
      }
      if(this.searchAdminModel.adminName!==undefined && !this.isEmpty(this.searchAdminModel.adminName)){
        queryToSend.name= this.searchAdminModel.adminName;
        params.append('name',this.searchAdminModel.adminName);
        isCriteriaValid = true;
      }
      if(this.searchAdminModel.createdBy!==undefined && !this.isEmpty(this.searchAdminModel.createdBy)){
        queryToSend.createdBy= this.searchAdminModel.createdBy;
        params.append('createdBy',this.searchAdminModel.createdBy);
        isCriteriaValid = true;
      }
      if (this.searchAdminModel.createdTo !== undefined
          && !this.isEmpty(this.searchAdminModel.createdTo || this.searchAdminModel.createdFrom)
          && this.searchAdminModel.createdFrom !== undefined
          && new Date(this.searchAdminModel.createdFrom) > new Date(this.searchAdminModel.createdTo)) {
        this.notify('warning', 'LABEL_DATE_CRITERIA_INVALID', true);
        this.showMessage=true;
        return false;
      }

      if(!isCriteriaValid){
        this.notify('warning', 'ERROR_INVALID_INPUT', true);
        this.showMessage=true;
        return false;
      } else {
        this.setSearchCriteria(queryToSend);
        this.retrieveAdmins(params);
      }
    },
    retrieveAdmins(params) {
      this.notify('', '');
      this.enableSpinner = true;
      const request = {
        params: params
      };
      const PThis = this;
      console.log(request.params);
      appServices.retrieveAdmins(request).then((response) => {
        console.log(response);
        PThis.enableSpinner = false;
        PThis.viewResult = response;
        if(PThis.viewResult.length===0 ){
          PThis.notify('warning', 'LABEL_NO_ADMINS_FOUND', true);
        }
      }).catch((error) => {
        console.log(error.response.data.errors[0]);
        PThis.httpServiceErrorCall(error);
      });
    },
  }
};
</script>
<style lang="css">
  /*@import './../../../styles/app.css';*/
</style>
