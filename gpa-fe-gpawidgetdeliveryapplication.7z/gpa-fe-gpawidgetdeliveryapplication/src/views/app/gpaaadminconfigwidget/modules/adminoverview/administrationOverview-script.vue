<script>
  export default {
    name:'administrationOverview',
    data() {
      return {
        withRange: false,
        leftLabel: '',
        rightLabel: '',
        leftMessageType: 'negative',
        leftMessageStartDate: '',
        fromInputInvalidStartDate: false,
        leftMessageEndDate: '',
        fromInputInvalidEndDate: false,
        mDatePicker: '',
      };
    },
  };
</script>
