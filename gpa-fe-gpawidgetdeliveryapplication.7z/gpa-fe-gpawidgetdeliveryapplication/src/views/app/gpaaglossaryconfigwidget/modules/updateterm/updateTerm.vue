<template>
  <div class="panel panel-default" id="updateProductDiv">
    <div class="panel-heading" style="padding-top: 5px">

      <BackButton
          :actionBackButton="backAction"
          :back="back"
      />
      <h2 class="panel-title"><span>{{$t('LABEL_UPDATE')}}</span></h2>
    </div>
    <div class="panel-body">
      <notify
          :notificationType="msgType"
          :displayMessage="displayMsg"
          :closeNotification="closeNotify"
          @clear="notify($event, $event)"
          :title="toolMsg"
      />
      <aab-spinner :size="12" v-if="enableSpinner"></aab-spinner>

      <ConfirmationPopUpTemplate
          v-if="confirmActionPopup"
          :actionPopUp="action"
          :cancel="cancel"
          :validatePopUpConfirm="validatePopUpConfirm"
          :selectedAction="selectedAction"
      />
      <div id ="updateBlock">
        <form class="form-horizontal ng-pristine ng-valid" name="updateForm">
          <div class="bs-component ng-scope ng-isolate-scope">
            <div class="well">
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p><span>{{$t('LABEL_TERM_NAME')}}</span>&nbsp;
                    <span style="color :#FF6347;">*</span></p>
                  </strong>
                </div>
                <div class="col-xs-5" style = "border: none">
                  <input class="w120 form-control"

                         ng-keypress="checkForSpecialCharacters($index, $event, 150,term.name)"
                         ng-keyup="checkToDeleteCharacters($index, $event, 150,term.name)"
                         ng-change="isSpecialCharacterPresentInName(term.name)"

                         name="termName"
                         type="text"
                         maxlength="150"
                         v-model="term.name" id="termName" on-keyup-fn="handleKeypress"/>

                  <span class="help-block" v-show="term.isSpecialCharPresentInName">
                    <span>{{$t('LABEL_SPECIAL_CHARACTER')}}</span>
                    {{term.specialCharInTermName}}
                    <span>{{$t('LABEL_NOT_ALLOWED')}}  </span>
                  </span>
                </div>
              </div>
              <br/><br/>
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p><span>{{$t('LABEL_TERM_DESCR')}}</span>&nbsp;
                    <span style="color :#FF6347;">*</span></p>
                  </strong>
                </div>
                <div class="col-xs-5" >
                  <textarea class="w120 form-control"
                            rows="2"
                            ng-keypress="checkForSpecialCharacters($index, $event,300,term.description)"
                            ng-change="isSpecialCharacterPresentInDesc(term.description)"

                            name="description"  spellcheck="false"
                            type="text" maxlength="300"
                            v-model="term.description" id="description"  on-keyup-fn="handleKeypress"/>
                  <span class="help-block" v-show="term.isSpecialCharPresentInDesc">
                    <span>{{$t('LABEL_SPECIAL_CHARACTER')}}</span>
                    {{term.specialCharInTermDesc}}
                    <span>{{$t('LABEL_NOT_ALLOWED')}}</span>
                  </span>
                </div>
              </div>
              <br/><br/>
              <div class="row">
                <div class="col-xs-6  form-group-first" style="text-align: right;"><strong><p><span>{{$t('LABEL_TERM_DATA_TYPE')}}</span>
                  &nbsp;<span style="color :#FF6347;">*</span></p></strong></div>

                <div class="col-xs-5" >
                  <span></span>
                  <select v-model="term.datatype" class="form-control" rows='2'
                          name="type" spellcheck="false">
                    <option v-for="(datatype, i) in termTypeList"
                            :key="`datatype${i}`"
                            :value="datatype.id">
                      {{ datatype.label }}
                    </option>
                  </select>
                  <span style="margin-top: -7%;position: absolute; margin-left: 2%;display: run-in; cursor: no-drop;"
                  >{{$t(term.dataType)}}</span>
                </div>
              </div>
              <br/><br/>
            </div>

            <div class="row btn-group" >
              <div class="col-xs-12">
                <button type="submit" class="btn btn-primary" v-on:click.prevent="update($event,term)">
                  <span>{{$t('LABEL_SAVE')}}</span>
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>

</template>
<script>
import {sy_arrow_arrow_left} from '@aab/sc-aab-icon-set/src/lib/systems';
import appServices from '../../../../../services/AppServices';
import utils from '../../../../../scripts/utils';
import Notify from '../../../../../components/Notify';
import ConfirmationPopUpTemplate from '../../../../../components/ConfirmationPopUp';
import BackButton from '../../../../../components/BackButton';

export default {
  name:'updateTerm',
  components: { Notify,ConfirmationPopUpTemplate,BackButton },
  data(){
    return{
      term:{
        id:'',name:'',description:'',datatype:[],
        isSpecialCharPresentInName:'',
        specialCharInTermName:'',isSpecialCharPresentInDesc:'',specialCharInTermDesc:'',
        nameErrorFlag:'',descErrorFlag:'',
      },
      termTypeList:[],
      sy_arrow_arrow_left,
      enableSpinner: false,
      displayMsg: '',
      msgType: '',
      toolMsg: '',
      closeNotify: '',
      termOldObj:'',
      action: '',
      confirmActionPopup:false,
      selectedAction:'',
      backAction: '',
      actionBackButton:false,
    };
  },
  watch: {
    confirmActionPopup: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
    actionBackButton: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
  },
/*
  computed:{
    termTypeItems(){
      const items = [];
      this.termTypeList.forEach(function(types){
        items.push({ name: types.label, value: types.id });
      });
      console.log(JSON.stringify(items));
      return JSON.stringify(items);
    },
  },
*/
  async mounted() {
    this.onLoad();
  },
  methods:{

    async onLoad(){
      // console.warn(this.$route.params.termId);

      const queryToSend = {};
      queryToSend.currentTime= new Date();
      console.log(queryToSend);

      const params = new URLSearchParams();
      params.append('currentTime',(queryToSend.currentTime !== 'undefined'? queryToSend.currentTime:''));

      const request = {
        params: params
      };

      this.termOldObj = await appServices.getTermDetailsByRouteId(this.$route.params.termId,request);
      this.term = Object.assign({},this.termOldObj);
      this.enableSpinner = false;
    },
    notify(type, msg, close=true) {
      this.msgType = type;
      this.displayMsg = msg !== '' ? msg : '';
      this.toolMsg = msg;
      this.closeNotify = close;
    },
    /*
      back : This function is used for redirection to back to Glossaray overview page.
    */
    back() {
      this.selectedAction = 'backButton';
      this.actionBackButton = true;
      this.confirmPopUp();
    },
    /**
     *  final service call to enter the Popup
     */
    confirmPopUp() {
      this.confirmActionPopup = true;
    },
    validatePopUpConfirm() {
      if(this.selectedAction==='backButton'){
        this.$router.push('/');
        this.back();
      }else if(this.selectedAction==='updateButton'){
        this.confirmActionPopup = false;
        this.updateTerm();
      }
    },
    /**
     * cancel- function called when cancel button is clicked in popup
     */
    cancel() {
      this.confirmActionPopup = false;
    },
    update(){
      this.selectedAction = 'updateButton';
      this.confirmPopUp();
    },
    /*
      This function is to check special character in term descritpion field
      */
    isSpecialCharacterPresentInDesc:function(input){
      this.term.isSpecialCharPresentInDesc=false;
      if(null!=input && input.length>0  && this.validateUnicode(input)!=='' ){
        this.term.isSpecialCharPresentInDesc=true;
        this.term.specialCharInTermDesc = this.validateUnicode(input);
        return true;
      }
      return false;
    },
    /*
      This function is to check special characters
    */
    // eslint-disable-next-line no-unused-vars
    checkForSpecialCharacters:function(index,$event,maxlength,inputData){
      if($event.target.innerHTML === 'undefined' || $event.target.innerHTML ===''){
        inputData=inputData + String.fromCharCode($event.keyCode);
      }
      else
      {
        inputData= $event.target.innerHTML+String.fromCharCode($event.keyCode);
      }
    },
    /*
   This function is to validate unicode for special charcter entered in field.
  */
    validateUnicode(inpuString) {
      const unicodeArray = [];
      for (let i=0; i < inpuString.length; i++) {
        const theUnicode = inpuString.charCodeAt(i).toString(16);
        if(theUnicode.length>2){
          unicodeArray.push(inpuString.charAt(i));
        }
      }

      const uniqueArray = [];
      for (let j=0; j<unicodeArray.length; j++){
        if (uniqueArray.indexOf(unicodeArray[j]) === -1 && unicodeArray[j] !== ''){
          uniqueArray.push(unicodeArray[j]);
        }
      }
      let message = '';
      for (let k=0; k < uniqueArray.length; k++) {
        if(k<(uniqueArray.length-1)){
          message = message + uniqueArray[k]+', ';
        }else{
          message = message + uniqueArray[k];
        }
      }
      return message;
    },
    /*
      This function is to validate special characters.
     */
    validateSpecialChars(){
      if(this.term.nameErrorFlag !==true  && this.term.isSpecialCharPresentInName !==true
          && this.term.descErrorFlag !==true  && this.term.isSpecialCharPresentInDesc !==true){
        return true;
      }
    },
    /*
     This function is to vlaidate all form fields(term name, term desc, term data type)
   */
    validateUpdateTermParms() {
      if(utils.isEmpty(this.term.name) || utils.isEmpty(this.term.description)){
        this.notify('', '');
        this.notify('warning','ERROR_MANDATORY_CREATE_TERM',true);
        return false;
      }
      return true;
    },
    /*
    This function is to check if term details are updated or not.
   */
    isTermUpdated: function () {
      let isUpdated = false;
      if (this.term.name !== this.termOldObj.name || this.term.description
          !== this.termOldObj.description) {
        isUpdated = true;
      }
      return isUpdated;
    },

    /*
      This function is to display confirmation box
     */
    /*save:function(ev,term) {
      if(!this.validateSpecialChars(term)){
        ErrorService.showError('ALERT_ERROR_CORRECTION_IN_CREATE');
        $scope.showMessage=true;
        return false;
      }
      if(!this.validateUpdateTermParms(term)){
        return false;
      }
      if (!this.isTermUpdated(term,$scope.termOldObj)) {
        ErrorService.showError('ERROR_NO_UPDATES_PERFORMED');
        $scope.showMessage=true;
        return false;
      } else {
        $scope.showMessage=false;
        var confirm = $mdDialog.confirm()
        .title(gettextCatalog.getString('ALERT_UPDATE_TERM'))
        .textContent(gettextCatalog.getString('ALERT_UPDATE_TERM_MESSAGE'))
        .ariaLabel('Lucky day')
        .targetEvent(ev)
        .ok('OK')
        .cancel('Cancel');
        $mdDialog.show(confirm).then(function() {
          updateTermServiceCall(term);
        }, function() {
        });
      }
    },*/
    updateTerm(){
      console.warn(this.term);
      console.warn(this.termOldObj);

      this.notify('', '');

      if(!this.validateSpecialChars(this.term)){
        this.notify('warning','ALERT_ERROR_CORRECTION_IN_CREATE',true);

        return false;
      }
      if(!this.validateUpdateTermParms(this.term)){
        return false;
      }
      if (!this.isTermUpdated(this.term,this.termOldObj)) {
        this.notify('warning','ERROR_NO_UPDATES_PERFORMED',true);

        return false;
      } else {
        this.enableSpinner = true;

        const TermRestResource = {};

        TermRestResource.name=utils.removeMultipleSpace(this.term.name);
        TermRestResource.description=utils.removeMultipleSpace(this.term.description);
        TermRestResource.dataType=this.term.dataType;
        TermRestResource.id=this.term.id;
        const PThis = this;

        appServices.updateTermServiceCall(TermRestResource).then((result) => {
          console.log(result);
          PThis.enableSpinner = false;
          PThis.updateTermResponse = result;
          this.$store.dispatch(
              'updateGlossaryOverviewFilteredData', result
          );
          PThis.processUpdateTermResponse(); //this.updateTermResponse,term
        }).catch((error) => {
          PThis.enableSpinner = false;
          PThis.httpServiceErrorCall(error);
        });
        this.$router.push({ name: 'glossaryOverview' });
      }
    },
    /*
      This function is to process response from update term Service & set msg for redirection to overview page
     */
    processUpdateTermResponse:function(){//response,term
      const updateTermResponse = {};

      updateTermResponse.termId=this.termId;
      this.$router.push({ name: 'glossaryOverview' });
    },
    /*
    this function is to handel error msgs in case of error code recived thru service call.
     */
    httpServiceErrorCall:function(error){
      this.notify('', '');

      if(error.status===403||error.status===401){
        this.notify('warning','LABEL_AUTHORIZATION_ERROR',true);
      } else if(error.status===500 && !utils.isEmpty(error.data) && !utils.isEmpty(error.data.errors) && !utils.isEmpty(error.data.errors[0].code)){
        this.notify('warning',error.data.errors[0].code,true);
      }else {
        this.notify('warning','LABEL_ERROR',true);
      }
    },

  }
};
</script>
