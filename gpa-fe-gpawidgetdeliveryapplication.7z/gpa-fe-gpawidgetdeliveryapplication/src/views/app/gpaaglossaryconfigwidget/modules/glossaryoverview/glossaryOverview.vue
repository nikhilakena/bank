<template>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h2 class="panel-title">
        <span>{{ $t("LABEL_GLOSSARY_OVERVIEW_SCREEN_NAME") }}</span>
      </h2>
    </div>
    <div class="panel-body" v-cloak>
      <notify
          :notificationType="msgType"
          :displayMessage="displayMsg"
          :closeNotification="closeNotify"
          @clear="notify($event, $event)"
          :title="toolMsg"
      />
      <aab-spinner :size="12" v-if="enableSpinner"></aab-spinner>

      <ConfirmationPopUpTemplate
          v-if="confirmActionPopup"
          :actionPopUp="action"
          :cancel="cancel"
          :validatePopUpConfirm="validatePopUpConfirm"
          :selectedAction="selectedAction"
      />

      <div id="searchBlockMain">
        <form class="form-horizontal" name="searchForm" v-cloak>
          <div class="bs-component">
            <div>
              <div class="well">

                <div class="row" style="margin-right: -45px; margin-top: -20px">
                  <div class="col-xs-11" style="padding-right: 0px; width: 94.5%">
                    <strong><span
                        class="btn-link"
                        style="
                        margin-top: 13px;
                        float: right;
                        cursor: pointer;
                        text-decoration: underline;"
                        v-on:click="resetSearchCriteria"
                        alt="New Search">{{ $t("LABEL_NEW_SEARCH") }}</span></strong>
                  </div>
                  <div class="col-xs-1" style="width: 5%; padding-left: 0px; margin-top: 12px">
                    &nbsp;<span
                      title="reset"
                      class="glyphicon glyphicon-refresh"
                      id="reset"
                      v-on:click="resetSearchCriteria"
                      alt="reset"
                  ></span>
                  </div>
                </div>
                <br />
                <div class="row" id="searchblock" style="text-align: right; display: block">
                  <div class="row">
                    <div class="col-xs-5 form-group-first">
                      <strong
                      ><p>{{ $t("LABEL_TERM_ID") }}</p>
                      </strong>
                    </div>
                    <div class="col-xs-3 form-group-first">
                      <div
                          :class="[
                      'form-group',
                      { 'has-warning has-feedback': isTermIdValid },
                    ]"
                      >
                        <input
                            class="w120 form-control"
                            name="termId"
                            type="text"
                            :placeholder="$t('LABEL_TERM_ID')"
                            v-model="searchModel.termId"
                            @input="
                        searchModel.termId.length
                          ? $v.searchModel.termId.$touch()
                          : $v.searchModel.termId.required"
                            maxlength="6"
                            id="termId"
                            @keyup.enter="search"
                        />
                        <span
                            class="glyphicon glyphicon-warning-sign form-control-feedback"
                            v-if="isTermIdValid"
                        ></span>
                        <span
                            class="help-block error-show"
                            v-show="isTermIdValid"
                        >{{ $t("LABEL_TERMID_INVALID") }}</span>
                      </div>
                    </div>
                  </div>
                  <br />

                  <div class="row">
                    <div class="col-xs-5 form-group-first">
                      <strong
                      ><p>{{ $t("LABEL_TERM_NAME") }}</p>
                      </strong>
                    </div>
                    <div class="col-xs-3 form-group-first">
                      <div class="form-group">
                        <input
                            class="w120 form-control"
                            name="termName"
                            type="text"
                            :placeholder="$t('LABEL_TERM_NAME')"
                            v-model="searchModel.termName"
                            @input="
                        searchModel.termName.length
                          ? $v.searchModel.termName.$touch()
                          : $v.searchModel.termName.required"
                            maxLength="150"
                            id="termName"
                            @keyup.enter="search"
                        />
                      </div>
                    </div>
                  </div>
                  <br />

                  <div class="row">
                    <div class="col-xs-5 form-group-first">
                      <strong
                      ><p>{{ $t("LABEL_CREATED_BY") }}</p>
                      </strong>
                    </div>
                    <div class="col-xs-3 form-group-first">
                      <div class="form-group">
                        <input
                            class="w120 form-control"
                            name="createdBy"
                            type="text"
                            :placeholder="$t('LABEL_CREATED_BY')"
                            v-model="searchModel.createdBy"
                            @input="
                        searchModel.createdBy.length
                          ? $v.searchModel.createdBy.$touch()
                          : $v.searchModel.createdBy.required"
                            maxlength="8"
                            id="createdBy"
                            @keyup.enter="search"
                        />
                      </div>
                    </div>
                  </div>
                  <br />

                  <div class="row">
                    <div class="col-xs-5 form-group-first" style="padding-top: 5px">
                      <strong><p>{{ $t("LABEL_CREATED_FROM") }}</p></strong>
                    </div>
                    <div class="col-xs-3 form-group-first" style="padding:0px">
                      <date-picker v-model="searchModel.createdFrom"
                                   format="DD.MM.YYYY"
                                   valuetype="format"
                                   lang="jp" style="color:seagreen"
                                   placeholder="DD.MM.YYYY"
                                   id="createdFrom">
                      </date-picker>
                      <span class="help-block" style="text-align: left; float: left" v-if="!isCreatedFromValid">
                        <span class="glyphicon glyphicon-warning-sign" v-if="!isCreatedFromValid"></span>
                        <span>{{ $t("LABEL_DATE_INVALID") }}</span>
                      </span>
                    </div>
                  </div>
                  <br />

                  <div class="row">
                    <div class="col-xs-5 form-group-first" style="padding-top: 5px">
                      <strong><p>{{ $t("LABEL_CREATED_TO") }}</p></strong>
                    </div>
                    <div class="col-xs-3 form-group-first" style="padding:0px">
                      <date-picker v-model="searchModel.createdTo"
                                   format="DD.MM.YYYY"
                                   valuetype="format"
                                   lang="$i18n.locale"
                                   placeholder="DD.MM.YYYY">
                      </date-picker>
                      <span class="help-block" v-show="!isCreatedToValid" style="text-align: left; float: left">
                        <span class="glyphicon glyphicon-warning-sign" v-show="!isCreatedToValid"></span>
                        <span>{{ $t("LABEL_DATE_INVALID") }}</span>
                      </span>
                    </div>
                  </div>
                  <br />
                </div>

                <br />
                <div class="row">
                  <div class="col-xs-7">
                    <aab-button fluid style-type="primary" class="ml-1" style="float:right">

                      <button :aria-label="$t('LABEL_SEARCH')"
                              v-on:click.prevent="searchTerm" id="searchGlossaryButton" style="vertical-align: super">
                        <span style="vertical-align: super">{{$t('LABEL_SEARCH')}}</span>
                        <aab-icon
                            slot="icon"
                            :svg="sy_tools_search"
                            size="3"
                            color="black"
                        />
                      </button>
                    </aab-button>
                  </div>
                  <div class="col-xs-5">
                    <aab-button fluid style-type="primary" class="ml-1" style="float:right">
                      <button :aria-label="$t('LABEL_CREATE_NEW')"
                              v-on:click.prevent="$router.push('/createTerm')"
                              type="submit">
                        <span style="vertical-align: super">{{$t('LABEL_CREATE_NEW')}}</span>
                        <aab-icon
                            slot="icon"
                            :svg="sy_shapes_plus_large"
                            size="3"
                            color="black"
                        />
                      </button>
                    </aab-button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>



        <div class="table-responsive" v-if="viewResult">
          <table class="table table-striped table-hover">
            <thead>
            <tr>
              <!--<th>
                <a href="/#/glossaryOverview" @click="changeSorting('id')" style="color :#608e28;" >{{ $t("LABEL_TERM_ID") }}</a>
                <span style="color :#608e28;" v-show="this.sort.column === 'id' && !this.sort.descending" class="glyphicon glyphicon-chevron-up"/>
                <span style="color :#608e28;" v-show="this.sort.column === 'id' && this.sort.descending" class="glyphicon glyphicon-chevron-down"/>
              </th>
              <th>
                <a href="/#/glossaryOverview" @click="changeSorting('name')" style="color :#608e28;">{{ $t("LABEL_TERM_NAME") }}</a>
                <span style="color :#608e28;" v-show="this.sort.column === 'name' && !this.sort.descending" class="glyphicon glyphicon-chevron-up"/>
                <span style="color :#608e28;" v-show="this.sort.column === 'name' && this.sort.descending" class="glyphicon glyphicon-chevron-down"/>
              </th>
              <th>
                <a href="/#/glossaryOverview" @click="changeSorting('auditDetails.createdBy')" style="color :#608e28;">{{ $t("LABEL_CREATED_BY") }}</a>
                <span style="color :#608e28;"
                      v-show="this.sort.column === 'auditDetails.createdBy'
                      && !this.sort.descending" class="glyphicon glyphicon-chevron-up"/>
                <span style="color :#608e28;"
                      v-show="this.sort.column === 'auditDetails.createdBy'
                      && this.sort.descending" class="glyphicon glyphicon-chevron-down"/>
              </th>
              <th>
                <a href="/#/glossaryOverview" @click="changeSorting('auditDetails.createdTimeStamp')" style="color :#608e28;">{{ $t("LABEL_CREATED_TS") }}</a>
                <span style="color :#608e28;"
                      v-show="this.sort.column === 'auditDetails.createdTimeStamp'
                      && !this.sort.descending" class="glyphicon glyphicon-chevron-up"/>
                <span style="color :#608e28;"
                      v-show="this.sort.column === 'auditDetails.createdTimeStamp'
                      && this.sort.descending" class="glyphicon glyphicon-chevron-down"/>
              </th>-->

              <th v-column-sortable @click="sortTable('id')" style="color :#608e28;">
                {{ $t("LABEL_TERM_ID") }}
              </th>
              <th v-column-sortable @click="sortTable('name')" style="color :#608e28;">
                {{ $t("LABEL_TERM_NAME") }}
              </th>
              <th style="color :#608e28;">
                {{ $t("LABEL_CREATED_BY") }}
              </th>
              <th style="color :#608e28;">
                {{ $t("LABEL_CREATED_TS") }}
              </th>

              <th></th>
            </tr>
            </thead>
            <tbody>
              <tr class="pointer" style="background-color: #f9f9f9"
                  v-for="(term) in viewResult" :key="term.id">
                <td style="text-decoration: underline;" v-on:click="viewTerm(term)"><a>{{term.id}}</a></td>
                <td class="" style="text-align: left; word-wrap: break-word; word-break: break-all;width:45%" >
                  {{term.name}}
                </td>
                <td class="">{{term.auditDetails.createdBy }}</td>
                <td class="">{{term.auditDetails.createdTimeStamp | formatDate }}</td><!--| date:'dd.MM.yyyy'-->
                <td style="margin-top: 7px;">
                  <aab-button fluid style-type="primary">
                    <button :aria-label="$t('LABEL_UPDATE')"
                            class="nav-link"
                            v-on:click.prevent="updateTerm(term)" type="submit">
                      <aab-icon
                          slot="icon"
                          :svg="sy_tools_pencil"
                          size="3"
                          color="black"
                      />
                    </button>
                  </aab-button>
                </td>
                <td style="margin-top: 7px;">
                  <aab-button fluid style-type="primary">
                    <button :aria-label="$t('LABEL_DELETE')"
                            class="nav-link"
                            v-on:click.prevent="deleteOperation(term)" type="submit">
                      <aab-icon
                          slot="icon"
                          :svg="sy_tools_trash"
                          size="3"
                          color="black"
                      />
                    </button>
                  </aab-button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import appServices from '../../../../../services/AppServices';
  import { sy_tools_search as sy_tools_search,
            sy_shapes_plus_large as sy_shapes_plus_large,
            sy_tools_pencil as sy_tools_pencil,
            sy_tools_trash as sy_tools_trash} from '@aab/sc-aab-icon-set';
  import { required,maxLength} from 'vuelidate/lib/validators';
  import DatePicker from 'vue2-datepicker';
  import Notify from '../../../../../components/Notify';
  import columnSortable from 'vue-column-sortable';
  import utils from '../../../../../scripts/utils';
  import ConfirmationPopUpTemplate from '../../../../../components/ConfirmationPopUp';

  const termIdPattern = (value) => /^[0]*[1-9][0-9]*$/.test(value);
  export default {
    name:'glossaryOverview',
    components: { DatePicker,Notify,ConfirmationPopUpTemplate },
    directives: {
      columnSortable
    },
    data() {
      return {
        withRange: false,
        leftLabel: '',
        rightLabel: '',
        leftMessageType: 'negative',
        leftMessageStartDate: '',
        fromInputInvalidStartDate: false,
        leftMessageEndDate: '',
        fromInputInvalidEndDate: false,
        mDatePicker: '',
        viewResult:'',
        sy_tools_search,
        sy_shapes_plus_large,
        sy_tools_pencil,
        sy_tools_trash,
        searchModel:{
          termId: '',
          termName: '',
          createdBy: '',
          createdTimeStamp: '',
          createdFrom:'',
          createdTo:'',
        },
        showTerm:false,
        showMessage:false,
        paramString:'',
        sort: {
          column: 'id',
          descending: false
        },
        enableSpinner: false,
        displayMsg: '',
        msgType: '',
        toolMsg: '',
        closeNotify: '',
        action: '',
        confirmActionPopup:false,
        selectedAction:'',
        selectedIdForDelete:'',
      };
    },
    watch: {
      confirmActionPopup: function (val) {
        if (val) {
          document.body.style.overflow = 'auto';
        }
      },
    },
    validations: {
      searchModel: {
        termId: {
          // eslint-disable-next-line no-undef
          required,
          termIdPattern,
        },
        termName:{
          required,maxLength,
        },
        createdBy:{
          required,
        }
      },
    },
    computed: {
      isTermIdValid() {
        return (
            this.$v.searchModel.termId.$error && !this.$v.searchModel.$pristine
        );
      },
      disableSearchButton() {
        return this.$v.searchModel.$invalid;
      },
    },
    created() {
      this.viewResult = this.$store.getters.glossaryOverviewFilteredData;
    },
    methods:{
      notify(type, msg, close=true) {
        this.msgType = type;
        this.displayMsg = msg !== '' ? msg : '';
        this.toolMsg = msg;
        this.closeNotify = close;
      },
      sortTable: function(col) {
        if (this.sortColumn === col) {
          this.ascending = !this.ascending;
        } else {
          this.ascending = true;
          this.sortColumn = col;
        }
        const isAscending = this.ascending;
        this.viewResult.sort(function(a, b) {
          if (a[col] > b[col]) {
            return isAscending ? 1 : -1;
          } else if (a[col] < b[col]) {
            return isAscending ? -1 : 1;
          }
          return 0;
        });
      },
      orderBy(fn) {
        this.viewResult.sort(fn);
      },
      /**
       *  final service call to enter the Popup
       */
      confirmPopUp() {
        this.confirmActionPopup = true;
      },
      validatePopUpConfirm() {
          this.confirmActionPopup = false;
          this.deleteTerm(this.selectedIdForDelete);
      },
      /**
       * cancel- function called when cancel button is clicked in popup
       */
      cancel() {
        this.confirmActionPopup = false;
      },
      deleteOperation(term){
        this.selectedAction = 'deleteButton';
        this.selectedIdForDelete = term;
        this.confirmPopUp();
      },
      createTerm(){
        this.$router.push({ name: 'createTerm' });
      },
      viewTerm(term) {
        this.$router.push('/viewTermDetails/'+term.id);
      },
      updateTerm(term) {
        this.$router.push('/updateTerm/'+term.id);
      },
      deleteTerm(term) {
        this.performTermDeletion(term);
      },
      performTermDeletion(term){
/*
        console.warn(term);
*/

        this.notify('', '');
        this.enableSpinner = true;

        const PThis = this;

        // eslint-disable-next-line no-unused-vars
        appServices.deleteTermServiceCall(term).then((result) => {
          // console.log('result==>' + result);
          const queryToSend = {};
          if(term.id!== undefined && !PThis.isEmpty(term.id)){
            queryToSend.id= term.id * 1;
          }
          // console.log('queryToSend==>' + queryToSend);

          if(PThis.viewResult.length>1){
            PThis.enableSpinner = false;
            PThis.retrieveTermDetails(queryToSend);
            PThis.$router.push('/');
          }else{
            this.showTerm = false;
          }
        }).catch((error) => {
          // console.log(error.response.data.errors[0]);
          PThis.enableSpinner = false;

          if(!utils.isEmpty(error.response.data) && !utils.isEmpty(error.response.data.errors) && error.response.data.errors[0].code ==='MESSAGE_GLSC_014'){
            PThis.notify('warning', 'LABEL_ERROR_TERM_IN_USE', true);
          }
          else{
            PThis.notify('warning', 'LABEL_ERROR', true);
          }
        });
      },
      resetSearchCriteria(){
        this.showTerm = false;
        this.searchModel = {};
        this.viewResult = {};
        this.$router.go(0);
      },
      /*async search() {
        const response = await appServices.getData();
        /!*alert(response);*!/
        this.viewResult = response;
      },*/
      searchTerm(){
        this.notify('', '');
        this.$store.dispatch(
            'updateFilterData', this.searchModel
        );
        // console.log(this.$store.getters.searchModel);



        this.searchModel = this.$store.getters.searchModel;
        let isCriteriaValid= false;
        const queryToSend = {};
        this.showTerm = false;
        if((this.isTermIDValidCheck() || this.isCreatedFromValid() || this.isCreatedToValid())){
          this.notify('', '');
          this.notify('warning', 'LABEL_FORM_ERRORS', true);
          this.showMessage=true;
          return false;
        }
        if(this.searchModel.termId!== undefined
            && !this.isEmpty(this.searchModel.termId)
            && !this.isEmpty(document.getElementById('termId').value)){
          queryToSend.id= this.searchModel.termId * 1;
          isCriteriaValid = true;
        }
        if(this.searchModel.termName!== undefined
            && !this.isEmpty(this.searchModel.termName)
            && !this.isEmpty(document.getElementById('termName').value)){
          queryToSend.termName= this.searchModel.termName;
          isCriteriaValid = true;
        }
        if(this.searchModel.createdFrom!== undefined
            && !this.isEmpty(this.searchModel.createdFrom)){
          queryToSend.createdFrom=this.getFormattedDate(this.searchModel.createdFrom);
          isCriteriaValid = true;
        }
        if(this.searchModel.createdTo!== undefined
            && !this.isEmpty(this.searchModel.createdTo)){
          queryToSend.createdTo=this.getFormattedDate(this.searchModel.createdTo);
          isCriteriaValid = true;
        }
        if(this.searchModel.createdBy!== undefined
            && !this.isEmpty(this.searchModel.createdBy)
            && !this.isEmpty(document.getElementById('createdBy').value)){
          queryToSend.createdBy= this.searchModel.createdBy;
          isCriteriaValid = true;
        }
        if(this.searchModel.createdTo!== undefined
            && !this.isEmpty(this.searchModel.createdTo || this.searchModel.createdFrom)
            && this.searchModel.createdFrom!== undefined
            && (new Date(this.searchModel.createdFrom) > new Date (this.searchModel.createdTo))){
              this.notify('warning', 'LABEL_DATE_CRITERIA_INVALID', true);
              this.showMessage=true;
              return false;
        }
        if(!isCriteriaValid){
          this.notify('warning', 'ERROR_INVALID_INPUT', true);
          this.showMessage=true;
          return false;
        }else {
          this.setSearchCriteria(queryToSend);
          this.retrieveTermDetails(queryToSend);
        }
      },
      isEmpty(str) {
        return (!str || 0 === str.length);
      },
      getFormattedDate(date){
        const  year = '' + date.getFullYear();
        const  month = '' + (date.getMonth() + 1);
        const  day = '' + date.getDate();
        if (month.length === 1){
          this.month = '0' + month;
        }
        if (day.length === 1){
          this.day = '0' + day;
        }
        return  day + '-' + month + '-' + year;
      },

      retrieveTermDetails(queryToSend) {
        this.notify('', '');
        this.enableSpinner = true;

        queryToSend.currentTime= new Date();
        // console.log(queryToSend);

        const params = new URLSearchParams();
        params.append('id',(this.searchModel.termId !== 'undefined'? this.searchModel.termId:''));
        params.append('termName',(this.searchModel.termName !== 'undefined'? this.searchModel.termName:''));
        params.append('createdBy',(this.searchModel.createdBy !== 'undefined'? this.searchModel.createdBy:''));
        params.append('createdFrom',(
            (this.searchModel.createdFrom!=='undefined'
                && this.searchModel.createdFrom !== '')
                ? this.getFormattedDate(this.searchModel.createdFrom)
                :''));
        params.append('createdTo',(
            (this.searchModel.createdTo !=='undefined'
                && this.searchModel.createdTo !=='')
                ? this.getFormattedDate(this.searchModel.createdTo)
                :''));
        params.append('currentTime',(queryToSend.currentTime !== 'undefined'? queryToSend.currentTime:''));

        const request = {
          params: params
        };
        const PThis = this;
        // console.log(request.params);
        appServices.retrieveTerms(request).then((response) => {
          // console.log(response);

          PThis.enableSpinner = false;
          PThis.viewResult = response;

          this.$store.dispatch(
              'updateGlossaryOverviewFilteredData', response
          );
          if(PThis.viewResult.length===0 ){
            PThis.notify('warning', 'LABEL_NO_TERMS_FOUND', true);
          }
        }).catch((error) => {
          // console.log(error.response.data.errors[0]);
          PThis.httpServiceErrorCall(error);
        });//.finally()
      },
      isTermIDValidCheck(){
        return (this.searchModel.termId.$invalid && !this.searchModel.$pristine);
      },
      isCreatedFromValid(){
        // console.log('inside isCreatedFromValid');
        if (this.searchModel.createdFrom!==undefined && this.searchModel.createdFrom !== '' && this.searchModel.createdFrom !== 'DD.MM.YYYY') {
          return (this.searchModel.createdFrom.$invalid);
        }
        return false;
      },
      isCreatedToValid(){
        // console.log('inside isCreatedToValid');
        if (this.searchModel.createdTo!==undefined && this.searchModel.createdTo !== '' && this.searchModel.createdTo !== 'DD.MM.YYYY') {
          return (this.searchModel.createdTo.$invalid);
        }
        return false;
      },
      /*
        This function is to set search criteria data for prefilling
       */
      setSearchCriteria(queryToSend){
        const queryToSendCopy = queryToSend;
        queryToSendCopy.createdFrom=new Date(this.searchModel.createdFrom).getTime();
        queryToSendCopy.createdTo=new Date(this.searchModel.createdTo).getTime();
      },
      httpServiceErrorCall(error){
        this.notify('', '');
        if(error.status===403||error.status===401){
          this.notify('warning','LABEL_AUTHORIZATION_ERROR',true);
          this.showMessage=true;
        }else if(error.status===500 || error.status===404 || error.status===405){
          this.notify('warning','LABEL_ERROR',true);
          this.showMessage=true;
        }else {
          this.notify('warning',error.response.data.errors[0].code,true);
          this.showMessage=true;
        }
      },
    },
    mounted() {
      this.enableSpinner = false;
    },
  };
</script>

<style lang="css">
  /*@import './../../../styles/app.css';*/
</style>
