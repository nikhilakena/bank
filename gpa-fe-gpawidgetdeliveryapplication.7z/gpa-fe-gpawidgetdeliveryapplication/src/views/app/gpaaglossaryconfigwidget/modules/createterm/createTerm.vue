<template>
  <div class="panel panel-default" id="createProductDiv">
    <div class="panel-heading" style="padding-top: 5px">

      <BackButton
          :actionBackButton="backAction"
          :back="back"
      />
      <h2 class="panel-title"><span>{{$t('LABEL_CREATE_GLOSSARY_SCREEN_NAME')}}</span></h2>
    </div>
    <div class="panel-body">
      <notify
          :notificationType="msgType"
          :displayMessage="displayMsg"
          :closeNotification="closeNotify"
          @clear="notify($event, $event)"
          :title="toolMsg"
      />
      <aab-spinner :size="12" v-if="enableSpinner"></aab-spinner>

      <ConfirmationPopUpTemplate
          v-if="confirmActionPopup"
          :actionPopUp="action"
          :cancel="cancel"
          :validatePopUpConfirm="validatePopUpConfirm"
          :selectedAction="selectedAction"
      />

      <div id ="crateBlock">
        <form class="form-horizontal" name="createForm">
          <div class="bs-component">
            <div class="well">
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p><span>{{$t('LABEL_TERM_NAME')}}</span>&nbsp;
                    <span style="color :#FF6347;">*</span></p>
                  </strong>
                </div>
                <div class="col-xs-5" style = "border: none">
                  <input class="w120 form-control"
                         ng-keypress="checkForSpecialCharacters($index, $event, 150,term.name)"
                         ng-change="isSpecialCharacterPresentInName(term.name)"
                         name="termName"
                         type="text"
                         maxlength="150"
                         v-model="term.name" id="termName" on-keyup-fn="handleKeypress"/>
                  <span class="form-control-feedback" ></span>
                  <span class="help-block" v-show="term.nameErrorFlag" style="color :#FF6347;">
                    <span>{{$t('LABEL_MAX_LIMIT_IS_REACHED')}}</span>
                      {{term.nameExtraChar}}
                    <span>{{$t('LABEL_MAX_CHARCTERS')}}</span>
                  </span>
                  <span class="help-block" v-show="term.isSpecialCharPresentInName">
                    <span>{{$t('LABEL_SPECIAL_CHARACTER')}}</span>
                      {{term.specialCharInTermName}}
                    <span>{{$t('LABEL_NOT_ALLOWED')}}</span>
                  </span>
                </div>
              </div>
              <br/><br/>
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p><span>{{$t('LABEL_TERM_DESCR')}}</span>&nbsp;
                    <span style="color :#FF6347;">*</span></p>
                  </strong>
                </div>
                <div class="col-xs-5" >
                  <textarea
                      class="w120 form-control"
                      rows="2"
                      name="description"
                      spellcheck="false"
                      type="text"
                      maxlength="300"
                      ng-keypress="checkForSpecialCharacters($index, $event, 300,term.description)"
                      ng-change="isSpecialCharacterPresentInDesc(term.description)"
                      v-model="term.description"
                      id="description"
                      on-keyup-fn="handleKeypress"/>

                  <span class="form-control-feedback" ></span>
                  <span class="help-block" v-show="term.descErrorFlag" style="color :#FF6347;">
                    <span>{{$t('LABEL_MAX_LIMIT_IS_REACHED')}}</span>
                      {{term.descExtraChar}}
                    <span>{{$t('LABEL_MAX_CHARCTERS')}}</span>
                  </span>
                  <span class="help-block" v-show="term.isSpecialCharPresentInDesc">
                    <span>{{$t('LABEL_SPECIAL_CHARACTER')}}</span>
                      {{term.specialCharInTermDesc}}
                    <span>{{$t('LABEL_NOT_ALLOWED')}}</span>
                  </span>
                </div>
              </div>
              <br/><br/>
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p><span>{{$t('LABEL_TERM_DATA_TYPE')}}</span>&nbsp;
                    <span style="color :#FF6347;">*</span></p>
                  </strong>
                </div>
                <div class="col-xs-5" >
                  <select v-model="term.datatype" class="form-control" rows="2"
                           name="type" spellcheck="false">
                    <option v-for="(datatype, i) in termTypeList"
                            :key="`datatype${i}`"
                            :value="datatype.id">
                      {{ datatype.label }}
                    </option>
                  </select>
                </div>
              </div>
              <br/><br/>
            </div>

            <div class="row btn-group" >
              <div class="col-xs-12">
                <button type="submit" class="btn btn-primary"
                        v-on:click.prevent="save"><!--$event-->
                  <span>{{$t('LABEL_SAVE')}}</span>
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>
<script>

import { sy_arrow_arrow_left as sy_arrow_arrow_left} from '@aab/sc-aab-icon-set';
import Notify from '../../../../../components/Notify';
import appServices from '../../../../../services/AppServices';
import utils from '../../../../../scripts/utils';
import ConfirmationPopUpTemplate from '../../../../../components/ConfirmationPopUp';
import BackButton from '../../../../../components/BackButton';

export default {
  name:'createTerm',
  components: {Notify,ConfirmationPopUpTemplate,BackButton},
  data(){
    return{
      term:{
        name:'',description:'',datatype:'',
        isSpecialCharPresentInName:'',
        specialCharInTermName:'',isSpecialCharPresentInDesc:'',specialCharInTermDesc:'',
        nameExtraChar:'',descExtraChar:'',
        nameErrorFlag:'',descErrorFlag:'',
      },
      termType:'',
      termTypeList:[],
      sy_arrow_arrow_left,
      enableSpinner: false,
      displayMsg: '',
      msgType: '',
      toolMsg: '',
      closeNotify: '',
      action: '',
      confirmActionPopup:false,
      selectedAction:'',
      backAction: '',
      actionBackButton:false,
    };
  },
  watch: {
    confirmActionPopup: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
    actionBackButton: function (val) {
      if (val) {
        document.body.style.overflow = 'auto';
      }
    },
  },
  mounted() {
    this.termTypeList =   [
      { label: 'Select', id: '0' },
      { label: 'String', id: 'STRING' },
      { label: 'Numeric', id: 'NUMERIC' },
      { label: 'Date', id: 'DATE' },
      { label: 'Boolean', id: 'BOOLEAN' },
      { label: 'Time', id: 'TIME' },
      { label: 'Date & Time', id: 'DATETIME' }];
    this.enableSpinner = false;
  },
/*
  computed:{
    termTypeItems(){
      const items = [];
      this.termTypeList.forEach(function(types){
        items.push({ name: types.label, value: types.id });
      });
      console.log(JSON.stringify(items));
      return JSON.stringify(items);
    },
  },
*/
  methods:{
    notify(type, msg, close=true) {
      this.msgType = type;
      this.displayMsg = msg !== '' ? msg : '';
      this.toolMsg = msg;
      this.closeNotify = close;
    },
    back() {
      this.selectedAction = 'backButton';
      this.actionBackButton = true;
      this.confirmPopUp();
    },
    /**
     *  final service call to enter the Popup
     */
    confirmPopUp() {
      this.confirmActionPopup = true;
    },
    validatePopUpConfirm() {
      if(this.selectedAction==='backButton'){
        this.$router.push('glossaryOverview');
        this.back();
      }else if(this.selectedAction==='saveButton'){
        this.confirmActionPopup = false;
        this.saveTerm();
      }
    },
    /**
     * cancel- function called when cancel button is clicked in popup
     */
    cancel() {
      this.confirmActionPopup = false;
    },
    save(){
      this.selectedAction = 'saveButton';
      this.confirmPopUp();
    },
    /*
    This function is used for redirection to back to Glossaray overview page.
     */
    /*back:function(ev) {
      var confirm = $mdDialog.confirm()
      .title(gettextCatalog.getString('ALERT_ON_BACK'))
      .textContent(gettextCatalog.getString('ALERT_ON_BACK_MESSAGE'))
      .ariaLabel('Lucky day')
      .targetEvent(ev)
      .ok('OK')
      .cancel('Cancel');
      $mdDialog.show(confirm).then(function() {
        $location.path("glossaryOverview");
      }, function() {});
    },*/
    termTypeChanged(event) {
      this.termTypeList = event.detail.value;
    },
    /*
      This function is to provide confirmation alert & checking validation
     */
    /*saveTerm1:function(ev,term) {
      if (this.validateCreateTermParms(term) && this.validateSpecialChars(term)) {
        $scope.showMessage=false;
        var confirm = $mdDialog.confirm()
        .title(gettextCatalog.getString('ALERT_CREATE_TERM'))
        .textContent(gettextCatalog.getString('ALERT_CREATE_TERM_MESSAGE'))
        .ariaLabel('Lucky day')
        .targetEvent(ev)
        .ok('OK')
        .cancel('Cancel');
        $mdDialog.show(confirm).then(function() {
          createTermServiceCall(term);
        }, function() {});
      }
    },*/
    /*
      This function is to check special characters
    */
    /*checkForSpecialCharacters:function(index,$event,maxlength,inputData){
      let inputDataValue;
      if($event.target.innerHTML === "undefined" || $event.target.innerHTML ===''){
        inputDataValue=inputData + String.fromCharCode($event.keyCode);
      }
      else
      {
        inputDataValue= $event.target.innerHTML+String.fromCharCode($event.keyCode);
      }
      return inputDataValue;
    },*/
    /*
      This function is to handel keyup events
     */
    /*checkToDeleteCharacters:function(index,$event,maxlength,inputData){
      if($event.target.innerHTML !== "undefined" && $event.target.innerHTML !==''){
        inputData= $event.target.innerHTML;
      }
    },*/
    /*
      This function is to check special character in term name field
     */
    /*isSpecialCharacterPresentInName:function(input){
      this.term.isSpecialCharPresentInName=false;
      if(null!=input && input.length>0  && this.validateUnicode(input)!='' ){
        this.term.isSpecialCharPresentInName=true;
        this.term.specialCharInTermName = this.validateUnicode(input);
        return true;
      }
      return false;
    },*/
    /*
     This function is to validate unicode for special charcter entered in field.
    */
    /*validateUnicode(inpuString) {
      var unicodeArray =[];
      for (var i=0; i < inpuString.length; i++) {
        var theUnicode = inpuString.charCodeAt(i).toString(16);
        if(theUnicode.length>2){
          unicodeArray.push(inpuString.charAt(i));
        }
      }
      var uniqueArray = [];
      for (var j=0; j<unicodeArray.length; j++){
        if (uniqueArray.indexOf(unicodeArray[j]) === -1 && unicodeArray[j] !== ''){
          uniqueArray.push(unicodeArray[j]);
        }
      }
      var message= '';
      for (var k=0; k < uniqueArray.length; k++) {
        if(k<(uniqueArray.length-1)){
          message = message + uniqueArray[k]+', ';
        }else{
          message = message + uniqueArray[k];
        }
      }
      return message;
    },*/
    /*
      This function is to check special character in term descritpion field
    */
    /*isSpecialCharacterPresentInDesc:function(input){
      this.term.isSpecialCharPresentInDesc=false;
      if(null!=input && input.length>0  && this.validateUnicode(input)!='' ){
        this.term.isSpecialCharPresentInDesc=true;
        this.term.specialCharInTermDesc = this.validateUnicode(input);
        return true;
      }
      return false;
    },*/

    /*
      This function is to vlaidate all form fields(term name, term desc, term data type)
     */
    validateCreateTermParms() {
      if(utils.isEmpty(this.term.name) || utils.isEmpty(this.term.description)
          || utils.isEmpty(this.term.datatype) || this.term.datatype ==='0'){
        this.notify('', '');
        this.notify('warning','ERROR_MANDATORY_CREATE_TERM',true);
        return false;
      }
      else{
        return true;
      }
    },
    /*
     This function is to validate special characters
    */
    validateSpecialChars(){
      if(this.term.nameErrorFlag !==true  && this.term.isSpecialCharPresentInName !==true
          && this.term.descErrorFlag !==true  && this.term.isSpecialCharPresentInDesc !==true){
        return true;
      }else{
        this.notify('', '');
        this.notify('warning','ALERT_ERROR_CORRECTION_IN_CREATE',true);
        return false;
      }
    },

    saveTerm(){
      //http://vm00006786.nl.eu.abnamro.com:14923/gpaaglossaryconfiguration/terms POST
      /*{name: "SampleTest", description: "Term description", dataType: "STRING"}
      dataType: "STRING"
      description: "Term description"
      name: "SampleTest"*/
      //http://vm00006786.nl.eu.abnamro.com:14923/gpaaglossaryconfiguration/terms/retrieve?currentTime=2022-04-05T10:06:32.349Z&id=15 GET
      if (this.validateCreateTermParms(this.term) && this.validateSpecialChars(this.term)) {
        console.warn(this.term);



        this.notify('', '');
        this.enableSpinner = true;

        const TermRestResource = {};
        TermRestResource.name=utils.removeMultipleSpace(this.term.name);
        TermRestResource.description=utils.removeMultipleSpace(this.term.description);
        TermRestResource.dataType=this.term.datatype;
        console.log('TermRestResource  ==>'+TermRestResource.name);
        console.log('TermRestResource  ==>'+TermRestResource.description);
        console.log('TermRestResource  ==>'+TermRestResource.dataType);

        const PThis = this;
        appServices.createTermServiceCall(TermRestResource).then((response) => {
          console.log(response);
          PThis.enableSpinner = false;
          PThis.createResult = response;

          let queryToSend = {};
          queryToSend = this.$store.getters.searchModel;
          console.log('queryToSend==>' + queryToSend);

          if(utils.isEmpty(PThis.createResult.data.identifier)){
            PThis.enableSpinner = false;
            PThis.retrieveTermDetails(queryToSend);
          }
          PThis.processCreatetermResponse(PThis.createResult,PThis.term);
        }).catch((error) => {
          PThis.enableSpinner = false;
          PThis.httpServiceErrorCall(error);
        });//.finally()
      }
    },
    /*
      This function is to process response from ceate Service & set msg for redirection to overview page
     */
    processCreatetermResponse(response,term){
      const createTermResponse = {};
      createTermResponse.termId=response.data.identifier;
      this.notify('', '');
      this.notify('warning', 'ALERT_LABEL_TERM_NAME' +this.term.name+' '+'ALERT_TERM_CREATED',true);

      const terms = [];
      term.termId = createTermResponse.termId;
      terms.push(term);
      this.$router.push({ name: 'glossaryOverview' });
    },
    /*
      this function is to handel error msgs in case of error code recived thru service call.
     */
      httpServiceErrorCall:function(error){
        this.notify('', '');
        if(error.status===403||error.status===401){
          this.notify('warning','LABEL_AUTHORIZATION_ERROR',true);
        }else if(error.status===500 || error.status===404 || error.status===405){
          this.notify('warning','LABEL_ERROR',true);
        }else {
          this.notify('warning',error.data.errors[0].code,true);
        }
      },
  }
};
</script>
