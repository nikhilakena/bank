<template>
  <div class="panel panel-default">
    <div class="panel-heading" style="padding-top: 5px">
      <BackButton
          :actionBackButton="backAction"
          :back="back"
      />
      <h2 class="panel-title"><span>{{$t('LABEL_GLOSSARY_DETAIL_SCREEN_NAME')}}</span></h2>
    </div>
    <div class="panel-body">
      <div id="http-error-id"
           class="http-error-messages" http-error-messages></div>
      <div id="viewBlock">
        <form class="form-horizontal" name="viewForm">
          <div>
            <h4 class="panel-title" style="color: #608e28;">
              <span>{{$t('LABEL_GENERAL_GLOSSARY_DETAILS')}}</span>
            </h4>
          </div>
          <div class="bs-component">
            <div class="well">
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p>{{$t('LABEL_TERM_ID')}}:</p></strong>
                </div>
                <div class="col-xs-6 description">{{viewTermResult.id}}</div>
              </div>
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p>{{$t('LABEL_TERM_NAME')}}:</p></strong>
                </div>
                <div class="col-xs-6 description">{{viewTermResult.name}}</div>
              </div>
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p>{{$t('LABEL_TERM_DESCR')}}:</p></strong>
                </div>
                <div class="col-xs-6 description" style="margin-bottom: 10px">{{viewTermResult.description}}</div>
              </div>
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p>{{$t('LABEL_TERM_DATA_TYPE')}}:</p></strong>
                </div>
                <div class="col-xs-6 description" style="margin-bottom: 10px">{{$t(viewTermResult.dataType)}}</div>
              </div>
            </div>

          </div>

          <div>
            <h4 class="panel-title" style="color: #608e28;">
              <span>{{$t('LABEL_AUDIT_DETAILS')}}</span>
            </h4>
          </div>
          <div class="bs-component">
            <div class="well">
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p>{{$t('LABEL_CREATEDBY')}}:</p></strong>
                </div>
                <div class="col-xs-6">
                  <div>
                    {{viewTermResult.auditDetails.createdBy}} <span>{{$t('LABEL_ON')}}</span>
                    {{viewTermResult.auditDetails.createdTimeStamp  | formatDateTime }}<!--| date:'dd.MM.yyyy HH:mm:ss'-->
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-xs-6 form-group-first" style="text-align: right;">
                  <strong><p>{{$t('LABEL_MODIFIEDBY')}}:</p></strong>
                </div>
                <div class="col-xs-6">
                  <div v-if="(viewTermResult.auditDetails.modifiedBy !='undefined'
                    && viewTermResult.auditDetails.modifiedBy!=null &&
                    viewTermResult.auditDetails.modifiedBy !='' )">
                    {{viewTermResult.auditDetails.modifiedBy}} <span>{{$t('LABEL_ON')}}</span>
                    {{viewTermResult.auditDetails.modifiedTimeStamp | formatDateTime }}<!--| date:'dd.MM.yyyy HH:mm:ss'-->
                  </div>
                  <div v-if="viewTermResult.auditDetails.modifiedBy =='undefined'
                  || viewTermResult.auditDetails.modifiedBy==null
                  || viewTermResult.auditDetails.modifiedBy==''">-</div>
                </div>
              </div>

            </div>
          </div>
        </form>
      </div>
    </div>
  </div>

</template>
<script>
  import appServices from '../../../../../services/AppServices';
  import BackButton from '../../../../../components/BackButton';

  export default {
    name:'viewTermDetails',
    components: {BackButton},
    data(){
      return{
        viewTermResult:{
          id:'',
          name:'',
          description:'',
          dataType:[],
          auditDetails:{
            createdBy:'',modifiedBy:'',createdTimeStamp:'',modifiedTimeStamp:''
          }
        },
        backAction: '',
        actionBackButton:false,
      };
    },
    watch: {
      actionBackButton: function (val) {
        if (val) {
          document.body.style.overflow = 'auto';
        }
      },
    },
    async mounted() {
      this.onLoad();
    },
    methods:{

      async onLoad(){
        // console.warn(this.$route.params.termId);

        const queryToSend = {};
        queryToSend.currentTime= new Date();
        console.log(queryToSend);

        const params = new URLSearchParams();
        params.append('currentTime',(queryToSend.currentTime !== 'undefined'? queryToSend.currentTime:''));

        const request = {
          params: params
        };
        this.result = await
            appServices.getTermDetailsByRouteId(this.$route.params.termId,request);
        this.viewTermResult = this.result;
      },

      back() {
        this.actionBackButton = true;
        this.$router.push('/');
      },
    }
  };
</script>
