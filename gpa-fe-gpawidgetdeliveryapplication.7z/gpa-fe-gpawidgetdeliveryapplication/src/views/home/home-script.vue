<script>
export default {
    'name': 'Home'
};
</script>
