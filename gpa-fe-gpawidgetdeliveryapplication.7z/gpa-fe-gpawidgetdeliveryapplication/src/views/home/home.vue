<template>
    <div>
        Hi Home
        {{$t('TEST_LABEL')}}
    </div>
</template>
<script>
    import homeScript from '@/views/home/home-script.vue';

    export default homeScript;
</script>
