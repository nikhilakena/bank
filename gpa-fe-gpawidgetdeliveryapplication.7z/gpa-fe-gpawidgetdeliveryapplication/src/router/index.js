import Vue from 'vue';
import VueRouter from 'vue-router';

import glossaryOverview from '../views/app/gpaaglossaryconfigwidget/modules/glossaryoverview/glossaryOverview.vue';
import viewTermDetails from '../views/app/gpaaglossaryconfigwidget/modules/termview/termDetails';
import createTerm from '../views/app/gpaaglossaryconfigwidget/modules/createterm/createTerm';
import updateTerm from '../views/app/gpaaglossaryconfigwidget/modules/updateterm/updateTerm';
import administrationOverview from '../views/app/gpaaadminconfigwidget/modules/adminoverview/administrationOverview.vue';
import createAdmin from '../views/app/gpaaadminconfigwidget/modules/createadmin/createAdmin.vue';
import viewAdministrationDetails from '../views/app/gpaaadminconfigwidget/modules/adminview/adminDetails.vue';
import updateAdministration from '../views/app/gpaaadminconfigwidget/modules/updateadmin/updateAdmin.vue';


Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    redirect: { name: 'glossaryOverview' },
  },
  {
    path: '/glossaryOverview',
    name: 'glossaryOverview',
    component: glossaryOverview,
    props: true,
  },
  {
    path: '/createTerm',
    name: 'createTerm',
    component: createTerm,
    props:true
  },
  {
    path: '/createAdmin',
    name: 'createAdmin',
    component: createAdmin,
    props:true
  },
  {
    path: '/viewTermDetails/:termId',
    name: 'viewTermDetails',
    component: viewTermDetails,
    props: true
  },
  {
    path: '/updateTerm/:termId',
    name: 'updateTerm',
    component: updateTerm,
    props: true
  },
  {
    path: '/administrationOverview',
    name: 'administrationOverview',
    component: administrationOverview,
    props: true
  },
  {
    path: '/viewAdministrationDetails/:adminId',
    name: 'viewAdministrationDetails',
    component: viewAdministrationDetails,
    props: true
  },
  {
    path: '/updateAdministration/:adminId',
    name: 'updateAdministration',
    component: updateAdministration,
    props: true
  }
];

const router = new VueRouter({
  routes
});

export default router;
