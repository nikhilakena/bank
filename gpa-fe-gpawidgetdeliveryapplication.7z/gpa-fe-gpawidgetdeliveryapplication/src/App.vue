<template>
  <div style="width:100%">
    <my-header></my-header>
    <div class="container-fluid">
      <div class="margin-top">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                       <div class="col-md-10 offset-md-1">
                         <keep-alive include="glossaryOverview"> <router-view /> </keep-alive>
                       </div>
                </div>
              </div>
            </div>
      </div>
    </div>
  </div>
</template>
<script>
import Header from './components/Header';
export default {
  name: 'App',
  components: {
    'my-header': Header
  }
};
</script>


<style lang="css">
@import "./style/abnapp.css";
@import "./style/_alerts.scss";
</style>

