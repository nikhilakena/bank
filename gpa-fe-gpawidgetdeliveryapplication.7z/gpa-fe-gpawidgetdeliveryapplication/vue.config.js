module.exports = {
  pluginOptions: {
    i18n: {
      locale: 'en',
      fallbackLocale: 'en',
      localeDir: 'src/locales/',
      enableInSFC: false
    }
  },
  transpileDependencies: ['vuetify']
};
const extraConfig = require('./vue.config-part.js').extraConfigureWebpack;
const chainConfig = require('./vue.config-part.js').chainWebpack;
module.exports = {
  publicPath: process.env.NODE_ENV === 'production' ? './.' : '/gpa',
  chainWebpack: chainConfig,
  configureWebpack: extraConfig,

  transpileDependencies: [
    '@aab',
    '@open-wc',
    'lit-html',
    'lit-element',
    'vuetify'
  ],
  /*pluginOptions: {
    i18n: {
      locale: 'nl',
      fallbackLocale: 'en',
      localeDir: 'locales',
      enableInSFC: false,
    },
  },*/
  pluginOptions: {
    i18n: {
      locale: 'en',
      fallbackLocale: 'en',
      localeDir: 'locales',
      enableInSFC: false
    }
  },
  css: {
    sourceMap: true,
  },
  productionSourceMap: false,
};
