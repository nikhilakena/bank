import viewAdministrationDetails from '@/views/app/gpaaadminconfigwidget/modules/adminview/adminDetails';
import {createLocalVue, mount} from "@vue/test-utils";
import BackButton from "@/components/BackButton";
import Navbar from "@/components/Navbar";
import Notify from "@/components/Notify";
import ConfirmationPopUpTemplate from "@/components/ConfirmationPopUp";
import term from "./MockData/TermsData.json";
import AppServices from "@/services/AppServices";

const localVue = createLocalVue();

describe('should test viewAdministrationDetails', () => {

    let wrapper;

    const $router = {
        push: jest.fn(),
        go: jest.fn(),
    };    const $route = {
        "params":{"adminId":1}
    };

    beforeEach(() => {
        wrapper = mount(viewAdministrationDetails, {
            localVue,
            mocks:{
                $t: () => {},
                $router,
                $route,
            },
            data(){
                return {}
            },
        });
    });

    it('should test name viewAdministrationDetails', () => {
        expect(viewAdministrationDetails.name).toBe('viewAdministrationDetails');
        expect(typeof viewAdministrationDetails.name).toBe('string');
    });

    it('should test vue data and component', async() => {
        expect(typeof viewAdministrationDetails.data).toBe('function');
        expect(viewAdministrationDetails.components).toStrictEqual({
            BackButton,Navbar,Notify,ConfirmationPopUpTemplate
        });
    });

    it('should test vue mounted for viewAdministrationDetails', async() => {
        expect(typeof viewAdministrationDetails.mounted).toBe('function');
        await wrapper.vm.$nextTick(() => {
            expect(viewAdministrationDetails.mounted()).toBeCalledTimes(1);
            expect($router).toHaveBeenCalledWith(0);
        });
    });

    it('should test notify method for viewAdministrationDetails',async () => {
        const notify = jest.spyOn(wrapper.vm, "notify");
        await notify();
        expect(notify).toHaveBeenCalled();
    });


    it('should test method backbutton for viewAdministrationDetails', async() => {
        const back = jest.spyOn(wrapper.vm, "back");
        await back();
        expect(back).toHaveBeenCalled();
    });

    it("should test confirmPopUp method for viewAdministrationDetails", async() => {
        const confirmPopUp = jest.spyOn(wrapper.vm, "confirmPopUp");
        await confirmPopUp();
        expect(confirmPopUp).toHaveBeenCalled();
    });

    it('should test back method for viewAdministrationDetails', async() => {
        const back = jest.spyOn(wrapper.vm, "back");
        await back();
        expect(back).toHaveBeenCalled();
    });

    it('should test cancel method for viewAdministrationDetails', async() => {
        const cancel = jest.spyOn(wrapper.vm, "cancel");
        await cancel();
        expect(cancel).toHaveBeenCalled();
    });

    it('should test validatePopUpConfirm method for viewAdministrationDetails', async() => {
        wrapper.vm.selectedAction ='deleteAdminButton';
        wrapper.vm.confirmActionPopup = false;
        wrapper.vm.validatePopUpConfirm();
        /*wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.deleteAdmin()).toBeCalledTimes(1)
        });*/
        const deleteAdmin = jest.spyOn(wrapper.vm, "deleteAdmin");
        await deleteAdmin(term);
        expect(deleteAdmin).toHaveBeenCalled();
    });

    it('should test deleteOperation method ', async() => {
        const deleteOperation = jest.spyOn(wrapper.vm, "deleteOperation");
        await deleteOperation();
        expect(deleteOperation).toHaveBeenCalled();
    });

    it('should test deleteAdminServiceCall method ', async() => {
        const deleteAdminServiceCall = jest.spyOn(wrapper.vm, "deleteAdminServiceCall");
        await deleteAdminServiceCall(term);
        const deleteAdminServiceCall1 = jest.spyOn(AppServices, "deleteAdminServiceCall");
        deleteAdminServiceCall1.mockResolvedValue(deleteAdminServiceCall1);

        expect(deleteAdminServiceCall).toHaveBeenCalled();
    });

    it('should test deleteAdmin method ', async () => {
        const deleteAdmin = jest.spyOn(wrapper.vm, "deleteAdmin");
        await deleteAdmin(term);
        expect(deleteAdmin).toHaveBeenCalled();
    });

    /*it('should test isEmpty method ', async() => {
        expect(typeof utils.isEmpty).toBe('function');
    });*/

    it('should test method with isEmpty', async() => {
        const isEmpty = jest.spyOn(wrapper.vm, "isEmpty");
        await isEmpty();
        expect(isEmpty).toHaveBeenCalled();
    });

/*    it('should test method with onLoad', async() => {
        const onLoad = jest.spyOn(wrapper.vm, "onLoad");
        /!*wrapper.vm.$route = {};
        wrapper.vm.$route.params = new URLSearchParams();
        wrapper.vm.$route.params.adminId = "1";*!/

        await onLoad();
        expect(onLoad).toHaveBeenCalled();
    });*/

});