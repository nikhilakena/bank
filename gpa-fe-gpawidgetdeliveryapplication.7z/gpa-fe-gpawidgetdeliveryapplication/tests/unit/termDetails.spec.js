import viewTermDetails from '@/views/app/gpaaglossaryconfigwidget/modules/termview/termDetails';
import {createLocalVue, mount} from "@vue/test-utils";
import BackButton from "@/components/BackButton";
import AppServices from "@/services/AppServices";
import GlossaryOverviewSearchSuccessData from "./MockData/GlossaryOverviewSearchSuccessData.json";

const localVue = createLocalVue();
localVue.use(viewTermDetails);

describe('should test term details', () => {

    let wrapper,glossaryOverviewDetailsData;

    const $router = {
        push: jest.fn(),
        go: jest.fn(),
    };

    beforeEach(() => {
        wrapper = mount(viewTermDetails, {
            localVue,
            mocks:{
                $t: () => {},
                $router,
            },
            data(){
                return {}
            },
        });
        glossaryOverviewDetailsData = jest.spyOn(AppServices, "getTermDetailsByRouteId");
    });

    it('should test name viewTermDetails', async() => {
        expect(viewTermDetails.name).toBe('viewTermDetails');
        expect(typeof viewTermDetails.name).toBe('string');
    });

    it('should test vue data and component', async() => {
        expect(typeof viewTermDetails.data).toBe('function');
        expect(viewTermDetails.components).toStrictEqual({
            BackButton
        });
    });

    it('should test vue mounted', async() => {
        expect(typeof viewTermDetails.mounted).toBe('function');
        await wrapper.vm.$nextTick(() => {
            expect(viewTermDetails.mounted()).toBeCalledTimes(1);
            expect($router).toHaveBeenCalledWith(0);
        });
    });

    it('should test method backbutton', async() => {
        /*await wrapper.vm.back();
        await wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.back()).toBeCalledTimes(1);
            expect($router).toHaveBeenCalledWith(0);
        });*/

        const back = jest.spyOn(wrapper.vm, "back");
        await back();
        expect(back).toHaveBeenCalled();
    });

    it("should test backend api calls terms", async () => {
        glossaryOverviewDetailsData.mockResolvedValue(GlossaryOverviewSearchSuccessData[0]);

        //let getTermDetailsByRouteId = jest.spyOn(viewTermDetails.mounted, "function");
        let getTermDetailsByRouteId = expect(typeof viewTermDetails.mounted).toBe('function');

        const queryToSend = {};

        await wrapper.vm.$nextTick(() => {
            expect(glossaryOverviewDetailsData).not.toHaveBeenCalled();
            expect(getTermDetailsByRouteId(queryToSend)).not.toHaveBeenCalled();
        });

        /*await wrapper.vm.$set(
            wrapper.vm.searchModel
        );*/
        //below conditions for -ve scenario
        glossaryOverviewDetailsData.mockRejectedValue();
        //await getTermDetailsByRouteId(queryToSend);

        await wrapper.vm.$nextTick(() => {
            expect(glossaryOverviewDetailsData).toHaveBeenCalled();
            expect(getTermDetailsByRouteId(queryToSend)).toHaveBeenCalled();
        });
    });

    it('should call onLoad method ', () => {
        wrapper.vm.onLoad();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. onLoad()).toBeCalledTimes(1)
        });
    });

});