import {shallowMount,createLocalVue} from "@vue/test-utils";
import Header from "../../src/components/Header";
import VueI18n from 'vue-i18n';
const localVue = createLocalVue()
localVue.use(VueI18n)
describe('Header Component', () => {
    let wrapper;
    const i18n = new VueI18n({
        locale: "en",
    });
    const $router = {
        push: jest.fn(),
        go: jest.fn(),
    };
    beforeEach(() => {
        wrapper = shallowMount(Header,{
            localVue,
            i18n,
            $router,
            mocks: {
                $t: () => {
                }
            },
            data() {
                return {}
            }
        });
    });
    it('is the name correct',() => {
        expect(Header.name).toBe('Header');
    });
    it('renders a valid vue instance', () => {
        // expect(wrapper.isVueInstance()).toBe(true);
        expect(wrapper.is(Header)).toBeTruthy();
    });

    /*it('should test backToHome method ', () => {
        expect(typeof wrapper.vm.backToHome).toBe('function');
    });*/

    it('should test backToHome method',async () => {
        /*const backToHome = jest.spyOn(wrapper.vm, "backToHome");
        await wrapper.vm.$router.push('/');
        expect(backToHome).toHaveBeenCalled();*/
        const push = jest.fn();
        await wrapper.vm.$nextTick(() => {
            expect(push).toHaveBeenCalledWith(wrapper.vm.backToHome());
            expect(wrapper.vm.backToHome()).toBeCalledTimes(1);
            expect($router).toHaveBeenCalledWith(0);
        });
    });
})