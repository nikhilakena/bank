import updateTerm from '@/views/app/gpaaglossaryconfigwidget/modules/updateterm/updateTerm';
import {createLocalVue, shallowMount} from "@vue/test-utils";
import BackButton from "@/components/BackButton";
import Notify from "@/components/Notify";
import ConfirmationPopUpTemplate from "@/components/ConfirmationPopUp";
import utils from "@/scripts/utils";
import appServices from "@/services/AppServices";
import GlossaryOverviewSearchSuccessData from "./MockData/GlossaryOverviewSearchSuccessData.json";
import term from "./MockData/TermsData.json";

const localVue = createLocalVue();

describe('should test updateTerm file', () => {

    let wrapper;

    const $router = {
        push: jest.fn(),
        go: jest.fn()
    }

    beforeEach(() => {
        wrapper = shallowMount(updateTerm, {
            localVue,
            mocks: {
                $router,
                $t: () => {
                },
            },
            data() {
                return {
                }
            }
        });
    });

    it('has name updateTerm', () => {
        expect(updateTerm.name).toBe('updateTerm');
        expect(typeof updateTerm.name).toBe('string');
    });

    it('should test vue data and component', () => {
        expect(typeof updateTerm.data).toBe('function');
        expect(updateTerm.components).toStrictEqual({
            Notify,ConfirmationPopUpTemplate,BackButton
        });
    });

    it('should test notify method updateTerm',async() => {
        const notify = jest.spyOn(wrapper.vm, "notify");
        await notify();
        expect(notify).toHaveBeenCalled();
    });

    it('should test back method updateTerm', async() => {
        const back = jest.spyOn(wrapper.vm, "back");
        await back();
        expect(back).toHaveBeenCalled();
    });

    it("should test confirmPopUp method updateTerm", async() => {
        const confirmPopUp = jest.spyOn(wrapper.vm, "confirmPopUp");
        await confirmPopUp();
        expect(confirmPopUp).toHaveBeenCalled();
    });

    it('should test cancel method updateTerm', async () => {
        wrapper.vm.cancel();
        const cancel = jest.spyOn(wrapper.vm, "confirmPopUp");
        await cancel();
        expect(cancel).toHaveBeenCalled();
    });

    it('should test validatePopUpConfirm method with backButton updateTerm', async() => {
        wrapper.vm.selectedAction ='backButton';
        wrapper.vm.validatePopUpConfirm();

        const back = jest.spyOn(wrapper.vm, "back");
        await back();
        expect(back).toHaveBeenCalled();
    });

    it('should test validatePopUpConfirm method with saveAdminButton updateTerm', async () => {
        wrapper.vm.selectedAction ='updateButton';
        wrapper.vm.confirmActionPopup = false;
        wrapper.vm.validatePopUpConfirm();

        const updateTerm = jest.spyOn(wrapper.vm, "updateTerm");
        await updateTerm();
        expect(updateTerm).toHaveBeenCalled();
    });

    it('should test update method updateTerm', async () => {
        const update = jest.spyOn(wrapper.vm, "update");
        await update();
        expect(update).toHaveBeenCalled();
    });

    it('should test updateTerm method', async () => {
        const updateTerm = jest.spyOn(wrapper.vm, "updateTerm");
        wrapper.vm.term = term;
        await updateTerm();
        await updateTerm();
        expect(updateTerm).toHaveBeenCalled();
    });

    it('should test isEmpty method updateTerm', async () => {
        expect(typeof utils.isEmpty).toBe('function');
    });

    it('should test processUpdateTermResponse method', async () => {
        const processUpdateTermResponse = jest.spyOn(wrapper.vm, "processUpdateTermResponse");
        await processUpdateTermResponse();
        expect(processUpdateTermResponse).toHaveBeenCalled();
    });

    it("should test updateTermServiceCall api call ", async () => {
        const updateTerm = jest.spyOn(wrapper.vm, "updateTerm");
        const updateTermServiceCall = jest.spyOn(appServices, "updateTermServiceCall");
        updateTermServiceCall.mockResolvedValue(GlossaryOverviewSearchSuccessData[1]);

        expect(updateTerm).not.toHaveBeenCalled();
        updateTermServiceCall.mockResolvedValue(GlossaryOverviewSearchSuccessData[1]);
        await updateTerm();
        expect(updateTerm).toHaveBeenCalled();
    });

    it('should test  isSpecialCharacterPresentInDesc method ', async () => {
        const  isSpecialCharacterPresentInDesc = jest.spyOn(wrapper.vm, "isSpecialCharacterPresentInDesc");
        let input = "\u6f22\u5b57";
        await isSpecialCharacterPresentInDesc(input);
        expect(isSpecialCharacterPresentInDesc).toHaveBeenCalled();
    });

    it('should test validateUnicode method ', async () => {
        const validateUnicode = jest.spyOn(wrapper.vm, "validateUnicode");
        let input = 't'
        wrapper.vm.theUnicode= "74"
        await validateUnicode(input);
        expect(validateUnicode).toHaveBeenCalled();
    });

    it('should test httpServiceErrorCall method ', async () => {
        const httpServiceErrorCall = jest.spyOn(wrapper.vm, "httpServiceErrorCall");
        const arrErrors= [{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 500,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 403,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 404,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 405,
        },{
            "data": {
                "errors": [
                    {
                        "code": null,
                        "params": null
                    }
                ]
            },
            "status": 503,
        }]
        await httpServiceErrorCall(arrErrors[0]);
        await httpServiceErrorCall(arrErrors[1]);
        await httpServiceErrorCall(arrErrors[2]);
        await httpServiceErrorCall(arrErrors[3]);
        await httpServiceErrorCall(arrErrors[4]);
        expect(httpServiceErrorCall).toHaveBeenCalled();
    });

    it('should test isTermUpdated method ', async () => {
        const isTermUpdated = jest.spyOn(wrapper.vm, "isTermUpdated");
        wrapper.vm.term = {}
        wrapper.vm.term.name = "Hi"
        await isTermUpdated();
        expect(isTermUpdated).toHaveBeenCalled();
    });

    it('should test checkForSpecialCharacters method ', async () => {
        const checkForSpecialCharacters = jest.spyOn(wrapper.vm, "checkForSpecialCharacters");
        let event = {}; let inputData = ""
        event.target = {}
        event.keyCode = "a"
        event.target.innerHTML = undefined;
        await checkForSpecialCharacters(0,event,0,inputData);
        expect(checkForSpecialCharacters).toHaveBeenCalled();
    });

    it('should call onLoad method ', () => {
        wrapper.vm.onLoad();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. onLoad()).toBeCalledTimes(1)
        });
    });

    it('should test validateUpdateTermParms method ', async () => {
        const validateUpdateTermParms = jest.spyOn(wrapper.vm, "validateUpdateTermParms");
        wrapper.vm.term = term;
        await validateUpdateTermParms(term);
        expect(validateUpdateTermParms).toHaveBeenCalled();
    });







});