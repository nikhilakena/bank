import App from "../../src/App";

describe('Mounted App index file', () => {

    it('has name App', () => {
        expect(App.name).toBe('App');
        expect(typeof App.name).toBe('string');
    });
});