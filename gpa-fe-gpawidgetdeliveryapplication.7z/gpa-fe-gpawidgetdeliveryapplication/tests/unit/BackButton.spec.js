import {shallowMount,createLocalVue} from "@vue/test-utils";
import VueI18n from 'vue-i18n'
import BackButton from '../../src/components/BackButton';
const localVue = createLocalVue()
localVue.use(VueI18n)
describe('BackButton Component', () => {
    // eslint-disable-next-line no-unused-vars
    let wrapper;
    const i18n = new VueI18n({
        locale: "en",
    });

    beforeEach(() => {
        wrapper = shallowMount(BackButton,{
            localVue,
            i18n,
            propsData: {
                actionBackButton:'backAction',
                back:'back'
            }
        });
    });
    it('is the name correct',() => {
        expect(BackButton.name).toBe('BackButton');
    });
})