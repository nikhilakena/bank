import glossaryOverview from '@/views/app/gpaaglossaryconfigwidget/modules/glossaryoverview/glossaryOverview';
import DatePicker from "vue2-datepicker";
import Notify from "@/components/Notify";
import ConfirmationPopUpTemplate from "@/components/ConfirmationPopUp";
import {createLocalVue, mount} from "@vue/test-utils";
import Vuelidate from "vuelidate";
import store from "@/store/centraliseStore";
import GlossaryOverviewSearchSuccessData from "./MockData/GlossaryOverviewSearchSuccessData.json";
import GlossaryOverviewDeleteSuccessData from "./MockData/GlossaryOverviewDeleteSuccessData.json";
import AppServices from "@/services/AppServices";
import term from "./MockData/TermsData.json";



const localVue = createLocalVue();
localVue.use(Vuelidate);

describe('should test glossaryOverview', () => {

    // eslint-disable-next-line no-unused-vars
    let wrapper,glossaryOverviewSearchData,glossaryOverviewDeleteData;

    const $router = {
        push: jest.fn(),
        go: jest.fn(),
    };

    beforeEach(() => {
        wrapper = mount(glossaryOverview, {
            localVue,
            store,
            mocks:{
                $t: () => {},
                $router,

            },
            data(){
                return {
                    viewResult: [],
                }
            },
        });
        glossaryOverviewSearchData = jest.spyOn(AppServices, "retrieveTerms");
        glossaryOverviewDeleteData = jest.spyOn(AppServices, "deleteTermServiceCall");

    });

    it('should test name glossaryOverview', () => {
        expect(glossaryOverview.name).toBe('glossaryOverview');
        expect(typeof glossaryOverview.name).toBe('string');
    });

    it('should test vue data and component', () => {
        expect(typeof glossaryOverview.data).toBe('function');
        expect(glossaryOverview.components).toStrictEqual({
            DatePicker,Notify,ConfirmationPopUpTemplate
        });
    });

    it('should test input for termId', async() => {
        let termId = wrapper.find('#termId');
        expect(termId.exists()).toBe(true);
        await termId.find('input').setValue(1111);
    });

    it('should test input for termName', async() => {
        let termName = wrapper.find('#termName');
        expect(termName.exists()).toBe(true);
        await termName.find('input').setValue('IBAN');
    });

    it('should test input for createdBy', async() => {
        let createdBy = wrapper.find('#createdBy');
        expect(createdBy.exists()).toBe(true);
        await createdBy.find('input').setValue('GPAADMIN');
    });

    it('should test input for createdFrom', async() => {
        document.body.innerHTML = `<date-picker id="createdFrom">
                      </date-picker>`
        expect(document.body.innerHTML).toContain(`<date-picker id="createdFrom">
                      </date-picker>`)
    });

    it("should test click of search glossary button", async () => {
        let searchGlossaryButton, searchTerm, adminId, adminName;
        adminId = wrapper.find("#termId");
        adminName = wrapper.find("#termName");
        searchGlossaryButton = wrapper.find("#searchGlossaryButton");
        searchTerm = jest.spyOn(wrapper.vm, "searchTerm");
        await wrapper.vm.$set(
            wrapper.vm.searchModel,
            adminId,
            adminName
        );
        await searchGlossaryButton.trigger("click");
        expect(searchTerm).toHaveBeenCalled();
    });

    it('should test method with createTerm', async() => {
        const createTerm = jest.spyOn(wrapper.vm, "createTerm");
        await createTerm();
        expect(createTerm).toHaveBeenCalled();
    });

    it('should test method with viewTerm', async() => {
        const viewTerm = jest.spyOn(wrapper.vm, "viewTerm");
        await viewTerm(GlossaryOverviewSearchSuccessData[0]);
        expect(viewTerm).toHaveBeenCalled();

        /*await wrapper.vm.$set(
            GlossaryOverviewSearchSuccessData[0].id
        );*/
       // let id  = GlossaryOverviewSearchSuccessData[0].id;
        //expect($router).toHaveBeenCalledWith('/viewTermDetails/'+wrapper.term.id);

    });

    it('should test method with updateTerm', async() => {
        const updateTerm = jest.spyOn(wrapper.vm, "updateTerm");
        await updateTerm(GlossaryOverviewSearchSuccessData[0]);
        expect(updateTerm).toHaveBeenCalled();
    });

    it('should test method with deleteTerm', async() => {
        const deleteTerm = jest.spyOn(wrapper.vm, "deleteTerm");
        await deleteTerm(GlossaryOverviewSearchSuccessData[0]);
        expect(deleteTerm).toHaveBeenCalled();
    });

    it('should test method with resetSearchCriteria Glossary', async() => {
        const resetSearchCriteria = jest.spyOn(wrapper.vm, "resetSearchCriteria");
        await resetSearchCriteria();
        expect(resetSearchCriteria).toHaveBeenCalled();
    });

    it('should test method with confirmPopUp Glossary', async() => {
        const confirmPopUp = jest.spyOn(wrapper.vm, "confirmPopUp");
        await confirmPopUp();
        expect(confirmPopUp).toHaveBeenCalled();
    });

    it('should test method with validatePopUpConfirm Glossary', async() => {
        const validatePopUpConfirm = jest.spyOn(wrapper.vm, "validatePopUpConfirm");
        await validatePopUpConfirm();
        expect(validatePopUpConfirm).toHaveBeenCalled();
    });

    it('should test method with deleteOperation Glossary', async() => {
        const deleteOperation = jest.spyOn(wrapper.vm, "deleteOperation");
        await deleteOperation();
        expect(deleteOperation).toHaveBeenCalled();
    });

    it('should test method with cancel Glossary', async() => {
        const cancel = jest.spyOn(wrapper.vm, "cancel");
        await cancel();
        expect(cancel).toHaveBeenCalled();
    });

    it('should test method with sortTable Glossary', async () => {
        let col = ""; wrapper.vm.sortColumn= ""; wrapper.vm.viewResult = ["1","2"]
        wrapper.vm.sortTable(col);
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. sortTable()).toBeCalledTimes(1)
        });
    });

    it('should test method with setSearchCriteria Glossary', async() => {
        const setSearchCriteria = jest.spyOn(wrapper.vm, "setSearchCriteria");

        const queryToSend = {};

        await wrapper.vm.$set(
            wrapper.vm.searchModel,
            wrapper.vm.searchModel.createdFrom,
            wrapper.vm.searchModel.createdTo
        );
        await wrapper.vm.setSearchCriteria(queryToSend);
        expect(setSearchCriteria).toBeCalledTimes(1);
    });

    it('should test method with isEmpty Glossary', async() => {
        const isEmpty = jest.spyOn(wrapper.vm, "isEmpty");
        await isEmpty();
        expect(isEmpty).toHaveBeenCalled();
    });

    it('should test method with getFormattedDate Glossary', async() => {
        let getFormattedDate = jest.spyOn(wrapper.vm, "getFormattedDate");
        let date = new Date("2022-00-00T18:30:00.000Z");
        await getFormattedDate(date);
        expect(getFormattedDate).toHaveBeenCalled();
    });

    it("should test checks proper invoking of backend api calls Glossary", async () => {
        glossaryOverviewSearchData.mockResolvedValue(GlossaryOverviewSearchSuccessData[0]);

        let retrieveTermDetails = jest.spyOn(wrapper.vm, "retrieveTermDetails");
        let callretrieveTerms = jest.spyOn(
            wrapper.vm,
            "retrieveTermDetails"
        );
        const queryToSend = {};

        await wrapper.vm.$nextTick(() => {
            expect(glossaryOverviewSearchData).not.toHaveBeenCalled();
            expect(retrieveTermDetails(queryToSend)).not.toHaveBeenCalled();
            expect(callretrieveTerms).not.toHaveBeenCalled();
        });
        await wrapper.vm.$set(
            wrapper.vm.searchModel
        );
        //below conditions for -ve scenario
        glossaryOverviewSearchData.mockRejectedValue();
        await retrieveTermDetails(queryToSend);

        await wrapper.vm.$nextTick(() => {
            expect(glossaryOverviewSearchData).toHaveBeenCalled();
            expect(retrieveTermDetails).toHaveBeenCalled();
            expect(callretrieveTerms).toHaveBeenCalled();
        });

    });

/*
    it('should test httpServiceErrorCall method ', async () => {
        const httpServiceErrorCall = jest.spyOn(wrapper.vm, "httpServiceErrorCall");
        const arrErrors= [{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 500,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 403,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 404,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 405,
        },{
            "data": {
                "errors": [
                    {
                        "code": null,
                        "params": null
                    }
                ]
            },
            "status": 503,
        }]
        await httpServiceErrorCall(arrErrors[0]);
        await httpServiceErrorCall(arrErrors[1]);
        await httpServiceErrorCall(arrErrors[2]);
        expect(httpServiceErrorCall).toHaveBeenCalled();
    });
*/

/*
    it("to check performTermDeletion function", async () => {
/!*
        await wrapper.setData({
            searchModel:{
                termId: '1',
                termName: 'GPA',
                createdBy: 'GPAADMIN',
            }
        })
*!/
        const performTermDeletion = jest.spyOn(wrapper.vm, "performTermDeletion");
        const deleteTermServiceCall = jest.spyOn(AppServices, "deleteTermServiceCall");
        expect(performTermDeletion).not.toHaveBeenCalled();

        deleteTermServiceCall.mockResolvedValue(GlossaryOverviewDeleteSuccessData);

        await performTermDeletion();

        expect(performTermDeletion).toHaveBeenCalled();

    });
*/


/*
    it('should test performTermDeletion method ', async () => {
        const performTermDeletion = jest.spyOn(wrapper.vm, "performTermDeletion");
        let a = {
            "adminId": "11",
            "adminName": "test2",
            "createdBy": "GPAADMIN",
            "oarId": "",
            "createdTimeStamp": "",
            "createdFrom": "2022-11-28T18:30:00.000Z",
            "createdTo": "2022-11-28T18:30:00.000Z",
            "adminOwner": "AAB.SYS.33333\t"};
        await performTermDeletion(a);
        expect(performTermDeletion).toHaveBeenCalled();
    });
*/



    /*it("should test delete backend api calls Glossary", async () => {
        glossaryOverviewDeleteData.mockResolvedValue(GlossaryOverviewDeleteSuccessData[0]);
        glossaryOverviewSearchData.mockResolvedValue(GlossaryOverviewSearchSuccessData[0]);

        let performTermDeletion = jest.spyOn(wrapper.vm, "performTermDeletion");
        let retrieveTermDetails = jest.spyOn(wrapper.vm, "retrieveTermDetails");
        const queryToSend = {};
        await wrapper.vm.$set(
            wrapper.vm.searchModel,
        );
        await performTermDeletion(wrapper.vm.term);
        await retrieveTermDetails(queryToSend);

        await wrapper.vm.$nextTick(() => {
            expect(glossaryOverviewDeleteData).not.toHaveBeenCalled();
            expect(performTermDeletion).not.toHaveBeenCalled();
            expect(retrieveTermDetails).not.toHaveBeenCalled();
            expect(glossaryOverviewSearchData).not.toHaveBeenCalled();
        });
    });*/

    /*it("should not test delete backend api calls Glossary", async () => {
        glossaryOverviewDeleteData.mockResolvedValue(GlossaryOverviewDeleteSuccessData[0]);
        glossaryOverviewSearchData.mockResolvedValue(GlossaryOverviewSearchSuccessData[18]);

        let performTermDeletion = jest.spyOn(wrapper.vm, "performTermDeletion");
        let retrieveTermDetails = jest.spyOn(wrapper.vm, "retrieveTermDetails");
        const queryToSend = {};

        await wrapper.vm.$set(
            wrapper.vm.searchModel.createdBy,
        );

        /!*let callretrieveTerms = jest.spyOn(
            wrapper.vm,
            "performTermDeletion"
        );*!/

        //below code to check for -ve scenario
        glossaryOverviewDeleteData.mockRejectedValue();
        await performTermDeletion(queryToSend);

        await wrapper.vm.$nextTick(() => {
            expect(glossaryOverviewDeleteData).toHaveBeenCalled();
            expect(performTermDeletion).toHaveBeenCalled();
            expect(retrieveTermDetails).toHaveBeenCalled();
            //expect(callretrieveTerms).toHaveBeenCalled();
        });
    });*/

/*
    it('should test sortTable method ', async () => {
        const sortTable = jest.spyOn(wrapper.vm, "sortTable");
        wrapper.vm.sortColumn = "name";
        wrapper.vm.viewResult = [
            {
                "id": 5556,
                "name": "SampleTest",
                "dataType": "STRING",
                "description": "description1@",
                "facets": null,
                "auditDetails": {
                    "createdBy": "GPAGLO",
                    "createdTimeStamp": 1668394890423,
                    "modifiedBy": "GPAGLO",
                    "modifiedTimeStamp": 1668395233053
                },
                "mandatory": false
            },
            {
                "id": 5557,
                "name": "SampleTest",
                "dataType": "NUMERIC",
                "description": "description5",
                "facets": null,
                "auditDetails": {
                    "createdBy": "GPAGLO",
                    "createdTimeStamp": 1668395422496,
                    "modifiedBy": "S03531",
                    "modifiedTimeStamp": 1668495413189
                },
                "mandatory": false
            }
        ];
        await sortTable("name");
        expect(sortTable).toHaveBeenCalled();
    });*/
/*
    it('should test orderBy method ', async () => {
        const orderBy = jest.spyOn(wrapper.vm, "orderBy");
        wrapper.vm.viewResult = [
            {
                "id": 5556,
                "name": "SampleTest",
                "dataType": "STRING",
                "description": "description1@",
                "facets": null,
                "auditDetails": {
                    "createdBy": "GPAGLO",
                    "createdTimeStamp": 1668394890423,
                    "modifiedBy": "GPAGLO",
                    "modifiedTimeStamp": 1668395233053
                },
                "mandatory": false
            },
            {
                "id": 5557,
                "name": "SampleTest",
                "dataType": "NUMERIC",
                "description": "description5",
                "facets": null,
                "auditDetails": {
                    "createdBy": "GPAGLO",
                    "createdTimeStamp": 1668395422496,
                    "modifiedBy": "S03531",
                    "modifiedTimeStamp": 1668495413189
                },
                "mandatory": false
            }
        ];
        await orderBy();
        expect(orderBy).toHaveBeenCalled();
    });*/


});