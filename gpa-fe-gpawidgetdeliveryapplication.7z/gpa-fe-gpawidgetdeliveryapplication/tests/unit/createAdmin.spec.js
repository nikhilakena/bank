import createAdmin from '@/views/app/gpaaadminconfigwidget/modules/createadmin/createAdmin';
import { shallowMount, createLocalVue } from '@vue/test-utils';
import BackButton from "@/components/BackButton";
import Notify from "@/components/Notify";
import ConfirmationPopUpTemplate from "@/components/ConfirmationPopUp";
import termViewPanel from "@/components/termViewPanel";
import utils from "@/scripts/utils";
import AppServices from "@/services/AppServices";
import AdminCreateServiceData from "./MockData/AdminCreateServiceData.json";
import appServices from "@/services/AppServices";
import term from "./MockData/TermsData.json";

const localVue = createLocalVue();

describe('should test createAdmin', () => {

    // eslint-disable-next-line no-unused-vars
    let wrapper, getAllTermsServiceCall;


    //const push = jest.fn();
    const $router = {
        push: jest.fn(),
    }
    beforeEach(() => {
        wrapper = shallowMount(createAdmin, {
            localVue,
            mocks: {
                $router,
                $t: () => {
                }
            },
            data() {
                return {
                    viewResult: [],
                    name:'',
                    allTermsSelected: false
                }
            }
        });
        getAllTermsServiceCall = jest.spyOn(AppServices, "getAllTermsServiceCall");

    });

    it('should test name createAdmin', () => {
        expect(createAdmin.name).toBe('createAdmin');
        expect(typeof createAdmin.name).toBe('string');
    });

    it('should test vue data and component', () => {
        expect(typeof createAdmin.data).toBe('function');
        expect(createAdmin.components).toStrictEqual({
            BackButton, Notify, ConfirmationPopUpTemplate, termViewPanel
        });
    });

    it('should test catchChildTermsData method ', async () => {
        const catchChildTermsData = jest.spyOn(wrapper.vm, "catchChildTermsData");
        await catchChildTermsData();
        expect(catchChildTermsData).toHaveBeenCalled();
    });

    it('should test notify method',async () => {
        const notify = jest.spyOn(wrapper.vm, "notify");
        await notify();
        expect(notify).toHaveBeenCalled();
    });

    it("should test confirmPopUp method", async () => {
        const confirmPopUp = jest.spyOn(wrapper.vm, "confirmPopUp");
        await confirmPopUp();
        expect(confirmPopUp).toHaveBeenCalled();
    });

    it('should test back method ', async () => {
        const back = jest.spyOn(wrapper.vm, "back");
        await back();
        expect(back).toHaveBeenCalled();
    });

    it('should test cancel method ', async () => {
        const cancel = jest.spyOn(wrapper.vm, "cancel");
        await cancel();
        expect(cancel).toHaveBeenCalled();
    });

    it('should test sortTable method ', async () => {
        const sortTable = jest.spyOn(wrapper.vm, "sortTable");
        wrapper.vm.sortColumn = "1";
        wrapper.vm.viewResult = [{"id":"17"}, {"id":"18"}]
        let col = "1"
        await sortTable(col);
        await sortTable("2");
        expect(sortTable).toHaveBeenCalled();
    });

    it('should test validatePopUpConfirm method with backButton', async () => {
        wrapper.vm.selectedAction ='backButton';
        wrapper.vm.validatePopUpConfirm();

        /*wrapper.vm.$nextTick(() => {
            expect(push).toHaveBeenCalledWith('administrationOverview');
            expect(wrapper.vm.back()).toBeCalledTimes(1)
        });*/

        const back = jest.spyOn(wrapper.vm, "back");
        await back();
        expect(back).toHaveBeenCalled();
        //expect(push).toHaveBeenCalledWith('administrationOverview');
    });

    it('should test validatePopUpConfirm method with saveAdminButton', async () => {
        wrapper.vm.selectedAction ='saveAdminButton';
        wrapper.vm.confirmActionPopup = false;
        wrapper.vm.validatePopUpConfirm();
        /*wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.saveAdmin()).toBeCalledTimes(1)
        });*/
        const saveAdmin = jest.spyOn(wrapper.vm, "saveAdmin");
        await saveAdmin();
        expect(saveAdmin).toHaveBeenCalled();
    });

    it('should test save method ', async () => {
        const save = jest.spyOn(wrapper.vm, "save");
        await save();
        expect(save).toHaveBeenCalled();
    });

    it('should test saveAdmin method ', async () => {
        const saveAdmin = jest.spyOn(wrapper.vm, "saveAdmin");
        wrapper.vm.selectedTerms = "abcd";
        wrapper.vm.selectedTermNameList = ["a","a"]
        wrapper.vm.admin = term;
        await saveAdmin();
        expect(saveAdmin).toHaveBeenCalled();
    });

    it('should test isEmpty method ', async () => {
        expect(typeof utils.isEmpty).toBe('function');
    });

    /*it('should test hasDuplicates method ', async () => {
        let array = [];
        const hasDuplicates = jest.spyOn(wrapper.vm, "hasDuplicates");
        await hasDuplicates(array);
        expect(hasDuplicates).toHaveBeenCalled();
    });*/

    it("should allow input for adminName", async () => {
        let adminName = wrapper.find("#adminName");
        expect(adminName.exists()).toBe(true);
        await adminName.find("input").setValue("Tikkie");
    });

    it("should allow input for description", async () => {
        let description = wrapper.find("#description");
        expect(description.exists()).toBe(true);
        await description.find("textarea").setValue("Tikkie description");
    });

    it("should allow input for adminOAR", async () => {
        let adminOAR = wrapper.find("#adminOAR");
        expect(adminOAR.exists()).toBe(true);
        await adminOAR.find("input").setValue("AAB.SYS.333.444");
    });

    it("should allow input for productid", async () => {
        let productid = wrapper.find("#productid");
        expect(productid.exists()).toBe(true);
        await productid.find("textarea").setValue(5567);
    });

    it("should test createAdministrationRestResourceCall api call ", async () => {
        const createAdministrationRestResourceCall = jest.spyOn(wrapper.vm, "createAdministrationRestResourceCall");
        const createAdminServiceCall = jest.spyOn(appServices, "createAdminServiceCall");
        createAdminServiceCall.mockResolvedValue(AdminCreateServiceData);

        expect(createAdministrationRestResourceCall).not.toHaveBeenCalled();
        createAdminServiceCall.mockResolvedValue(AdminCreateServiceData);
        await createAdministrationRestResourceCall();
        expect(createAdministrationRestResourceCall).toHaveBeenCalled();
    });

    it('should test hasDuplicates method ', async () => {
        const hasDuplicates = jest.spyOn(wrapper.vm, "hasDuplicates");
        let selectedTerms = ['123','123','456']
        await hasDuplicates(selectedTerms);
        expect(hasDuplicates).toHaveBeenCalled();
    });

    it('should test checkDuplicateTerms method ', async () => {
        const checkDuplicateTerms = jest.spyOn(wrapper.vm, "checkDuplicateTerms");
        let selectedTerms = [
            {
                "id": 1,
                "name": "Datum ondertekening contract",
                "dataType": "DATE",
                "description": "Date when the contract was signed",
                "facets": null,
                "auditDetails": {
                    "createdBy": "GPAADMIN",
                    "createdTimeStamp": 1666176507630,
                    "modifiedBy": "S03531",
                    "modifiedTimeStamp": 1667825008086
                },
                "mandatory": true,
                "$$hashKey": "object:997",
                "facetType": "List values"
            },{
                "id": 1,
                "name": "Datum ondertekening contract",
                "dataType": "DATE",
                "description": "Date when the contract was signed",
                "facets": null,
                "auditDetails": {
                    "createdBy": "GPAADMIN",
                    "createdTimeStamp": 1666176507630,
                    "modifiedBy": "S03531",
                    "modifiedTimeStamp": 1667825008086
                },
                "mandatory": true,
                "$$hashKey": "object:997",
                "facetType": "List values"
            } ]
        await checkDuplicateTerms(selectedTerms);
        expect(checkDuplicateTerms).toHaveBeenCalled();
    });

    it('should test facetTypeEnumMapper method ', async () => {
        let value = [
            {
                "facets": [
                    {
                        "facetType": "List values",
                    },
                    {
                        "facetType": "MaxInclusive",
                    },
                    {
                        "facetType": "MinInclusive",
                    },
                    {
                        "facetType": "Minimum length",
                    },{
                        "facetType": "Pattern",
                    },{
                        "facetType": "Length",
                    },{
                        "facetType": "MinExclusive",
                    },{
                        "facetType": "MaxExclusive",
                    },{
                        "facetType": "Total Digits",
                    },{
                        "facetType": "Fractions",
                    },{
                        "facetType": "Maximum length",
                    },

                ],
            },
        ]
        const facetTypeEnumMapper = jest.spyOn(wrapper.vm, "facetTypeEnumMapper");
        await facetTypeEnumMapper(value);
        expect(facetTypeEnumMapper).toHaveBeenCalled();
    });

    it('should test validateProductIdFormat method ', async () => {
        const validateProductIdFormat = jest.spyOn(wrapper.vm, "validateProductIdFormat");
        let obj = "21222,3212";
        let obj2 = "2122233";
        let obj3 = "2122233,2122233,2122233,2122233,2122233,2122233,2122233,2122233";
        await validateProductIdFormat(obj);
        await validateProductIdFormat(obj2);
        await validateProductIdFormat(obj3);
        expect(validateProductIdFormat).toHaveBeenCalled();
    });

    it('should test checkGenericAdminDtls method ', async () => {
        const checkGenericAdminDtls = jest.spyOn(wrapper.vm, "checkGenericAdminDtls");
        await checkGenericAdminDtls();
        expect(checkGenericAdminDtls).toHaveBeenCalled();
    });

    it('should test validateSpecialChars method ', async () => {
        const validateSpecialChars = jest.spyOn(wrapper.vm, "validateSpecialChars");

        let admin = {};
        admin.isSpecialCharPresentInAdminName = true;
        await validateSpecialChars(admin);
        expect(validateSpecialChars).toHaveBeenCalled();

        let admin2 = {};
        admin2.isSpecialCharPresentInAdminName = false
        await validateSpecialChars(admin2);
        expect(wrapper.vm.showMessage).toBe(true);
        expect(validateSpecialChars).toHaveBeenCalled();
    });

    it('should test hasDuplicatesPrducts method ', async () => {
        const hasDuplicatesPrducts = jest.spyOn(wrapper.vm, "hasDuplicatesPrducts");
        let array = [
            5525,
            '5525', null
        ];
        await hasDuplicatesPrducts([]);
        await hasDuplicatesPrducts(array);
        expect(hasDuplicatesPrducts).toHaveBeenCalled();
    });


    it('should test validateUnicode method ', async () => {
        const validateUnicode = jest.spyOn(wrapper.vm, "validateUnicode");
        let input = '\u6f22\u5b57';
        wrapper.vm.theUnicode = "74";
        await validateUnicode(input);
        expect(validateUnicode).toHaveBeenCalled();
    });

    it('should test httpServiceErrorCall method ', async () => {
        const httpServiceErrorCall = jest.spyOn(wrapper.vm, "httpServiceErrorCall");
        const arrErrors= [{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": []
                    }
                ]
            },
            "status": 500,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": []
                    }
                ]
            },
            "status": 403,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": []
                    }
                ]
            },
            "status": 404,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": []
                    }
                ]
            },
            "status": 405,
        },{
            "data": {
                "errors": [
                    {
                        "code": null,
                        "params": []
                    }
                ]
            },
            "status": 503,
        }]
        await httpServiceErrorCall(arrErrors[0]);
        await httpServiceErrorCall(arrErrors[1]);
        await httpServiceErrorCall(arrErrors[2]);
        await httpServiceErrorCall(arrErrors[3]);
        await httpServiceErrorCall(arrErrors[4]);
        expect(httpServiceErrorCall).toHaveBeenCalled();
    });



    it('should test formatErrorMsgForProductValidation method ', async () => {
        const formatErrorMsgForProductValidation = jest.spyOn(wrapper.vm, "formatErrorMsgForProductValidation");
        let errorCode = 'MESSAGE_ADDA_021'
        await formatErrorMsgForProductValidation(errorCode,null);
        expect(formatErrorMsgForProductValidation).toHaveBeenCalled();
    });

    it('should test isSpecialCharacterPresentInAdminName method ', async () => {
        const isSpecialCharacterPresentInAdminName = jest.spyOn(wrapper.vm, "isSpecialCharacterPresentInAdminName");
        let input = "\u6f22\u5b57"
        await isSpecialCharacterPresentInAdminName(input);
        expect(isSpecialCharacterPresentInAdminName).toHaveBeenCalled();
    });

    it('should test isSpecialCharacterPresentInAdminDesc method ', async () => {
        const isSpecialCharacterPresentInAdminDesc = jest.spyOn(wrapper.vm, "isSpecialCharacterPresentInAdminDesc");
        wrapper.vm.input = "\u6f22\u5b57"
        let input = "\u6f22\u5b57"
        await isSpecialCharacterPresentInAdminDesc(input);
        expect(isSpecialCharacterPresentInAdminDesc).toHaveBeenCalled();
    });

    it('should test isSpecialCharacterPresentInOAR method ', async () => {
        const isSpecialCharacterPresentInOAR = jest.spyOn(wrapper.vm, "isSpecialCharacterPresentInOAR");
        let input = "\u6f22\u5b57";
        await isSpecialCharacterPresentInOAR(input);
        expect(isSpecialCharacterPresentInOAR).toHaveBeenCalled();
    });

    it('should test catchChildTermsData method ', async () => {
        const catchChildTermsData = jest.spyOn(wrapper.vm, "catchChildTermsData");
        await catchChildTermsData();
        expect(catchChildTermsData).toHaveBeenCalled();
    });

    it('should test updateTermsObj method ', async () => {
        const updateTermsObj = jest.spyOn(wrapper.vm, "updateTermsObj");
        let obj = [{"id":1, "id2":2}]
        await updateTermsObj(obj);
        expect(updateTermsObj).toHaveBeenCalled();
    });

/*    it('should test unselectAll method createAdmin',async () => {
        wrapper.vm.terms = [{"selected":true},{"selected":true}];
        allTermsSelected = true;
        wrapper.vm.unselectAll();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.unselectAll()).toBeCalledTimes(1);
        });
    });*/

    it('should test unselectAll method ', async () => {
        const unselectAll = jest.spyOn(wrapper.vm, "unselectAll");
        wrapper.vm.terms = [];
        wrapper.vm.allTermsSelected = true;
        await unselectAll();
        expect(unselectAll).toHaveBeenCalled();
    });

    it('should test selectAll method ', async () => {
        const selectAll = jest.spyOn(wrapper.vm, "selectAll");
        wrapper.vm.terms = [];
        wrapper.vm.allTermsSelected = true;
        await selectAll();
        expect(selectAll).toHaveBeenCalled();
    });


    /*it('should test selectAll method createAdmin',async () => {
        wrapper.vm.terms = ['a','b'];
        wrapper.vm.term = {}
        wrapper.vm.term.selected = true;
        wrapper.vm.allTermsSelected = true;
        wrapper.vm.selectedCount = 0;
        wrapper.vm.selectAll();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.selectAll()).toBeCalledTimes(1);
        });
    });*/

    it('should test selectUsers method ', async () => {
        const selectUsers = jest.spyOn(wrapper.vm, "selectUsers");
        wrapper.vm.selectedTerms= [123445];
        await selectUsers(123445);
        await selectUsers(123456);
        expect(selectUsers).toHaveBeenCalled();
    });

    it('should test showTerm method ', async () => {
        const showTerm = jest.spyOn(wrapper.vm, "showTerm");
        let term = {};
        term.name = ["hello"]
        await showTerm(term);
        expect(showTerm).toHaveBeenCalled();
    });

    it('should test onLoad method ', async () => {
        const onLoad = jest.spyOn(wrapper.vm, "onLoad");
        const getAllTermsServiceCall = jest.spyOn(AppServices, "getAllTermsServiceCall");
        getAllTermsServiceCall.mockResolvedValue(term);

        await onLoad();
        expect(onLoad).toHaveBeenCalled();
    });

    it('should test showAdministrationTermsModal method ', async () => {
        document.body.innerHTML = `<aab-modal></aab-modal>`;
        document.querySelector('aab-modal').openModal = function () {
        };
        wrapper.vm.showAdministrationTermsModal();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. showAdministrationTermsModal()).toBeCalledTimes(1)
        });
    });

    it('should test saveAndCloseAdministrationTermsModal method ', async () => {
        document.body.innerHTML = `<aab-modal></aab-modal>`;
        document.querySelector('aab-modal').closeModal = function () {
        };
        wrapper.vm.saveAndCloseAdministrationTermsModal();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. saveAndCloseAdministrationTermsModal()).toBeCalledTimes(1)
        });
    });

    it('should test closeAdministrationTermsModal method ', async () => {
        document.body.innerHTML = `<aab-modal></aab-modal>`;
        document.querySelector('aab-modal').closeModal = function () {
        };
        wrapper.vm.closeAdministrationTermsModal();
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. closeAdministrationTermsModal()).toBeCalledTimes(1)
        });
    });


        it('should test updateTermsCheckBoxSelectedObj method ', async () => {
            const updateTermsCheckBoxSelectedObj = jest.spyOn(wrapper.vm, "updateTermsCheckBoxSelectedObj");
            await updateTermsCheckBoxSelectedObj([term]);
            expect(updateTermsCheckBoxSelectedObj).toHaveBeenCalled();
        });

        it('should test validateCreateTermParms method ', async () => {
            const validateCreateTermParms = jest.spyOn(wrapper.vm, "validateCreateTermParms");
            await validateCreateTermParms();
            expect(validateCreateTermParms).toHaveBeenCalled();
        });

        it('should test termViewTemplateURL method ', async () => {
            const termViewTemplateURL = jest.spyOn(wrapper.vm, "termViewTemplateURL");
            await termViewTemplateURL();
            expect(termViewTemplateURL).toHaveBeenCalled();
        });

        it('should test saveTermsInAdmin method ', async () => {
            const saveTermsInAdmin = jest.spyOn(wrapper.vm, "saveTermsInAdmin");
            wrapper.vm.terms = [term]
            await saveTermsInAdmin();
            expect(saveTermsInAdmin).toHaveBeenCalled();
        });


        it('should test validateGeneralFormDtls method ', async () => {
            const validateGeneralFormDtls = jest.spyOn(wrapper.vm, "validateGeneralFormDtls");
            let a = {};
            a.name = "";
            a.description = "";
            a.owner = "";
            await validateGeneralFormDtls(a, "0");
            wrapper.vm.admin = {};
            wrapper.vm.admin.isSpecialCharPresentInAdminDesc = true;
            await validateGeneralFormDtls(a, "0");
            expect(validateGeneralFormDtls).toHaveBeenCalled();
        });

    it('should test validateTermsDtls method ', async () => {
        const validateTermsDtls = jest.spyOn(wrapper.vm, "validateTermsDtls");
        wrapper.vm.selectedTerms = [{"errorMsgLabel":"ERROR_MANDATORY_FACETS_DTLS"},{}]
        await validateTermsDtls();
        expect(validateTermsDtls).toHaveBeenCalled();
    });


    it('should test validateHttpErrorParams method ', async () => {
        const validateHttpErrorParams = jest.spyOn(wrapper.vm, "validateHttpErrorParams");
        await validateHttpErrorParams(["1"]);
        expect(validateHttpErrorParams).toHaveBeenCalled();
    });


    it('should test validateFacetFormat method ', async () => {
        const validateFacetFormat = jest.spyOn(wrapper.vm, "validateFacetFormat");
        let obj =[
            {
                'facets': [
                    {
                        'showFlag' : 'false'
                    },
                    undefined,
                    {
                        "facetType": "List values",
                    },
                ],
                undefined,
                'facetCategory': [
                    {'showFlag' : 'false'
                    }
                ],'id': [
                    1
                ]
            }
        ]
        await validateFacetFormat(obj);
        expect(validateFacetFormat).toHaveBeenCalled();
    });





});