import {shallowMount,createLocalVue} from "@vue/test-utils";
import VueI18n from 'vue-i18n'
import ConfirmationPopUp from "../../src/components/ConfirmationPopUp";
const localVue = createLocalVue()
localVue.use(VueI18n)
describe('ConfirmationPopUp Component', () => {
    // eslint-disable-next-line no-unused-vars
    let wrapper;
    const i18n = new VueI18n({
        locale: "en",
    });

    beforeEach(() => {
        wrapper = shallowMount(ConfirmationPopUp,{
            localVue,
            i18n,
            propsData: {
                actionPopUp:"action",
                cancel:"cancel",
                validatePopUpConfirm:"validatePopUpConfirm",
                selectedAction:"selectedAction",
                obj:"obj",
            }
        });
    });
    it('is the name correct',() => {
        expect(ConfirmationPopUp.name).toBe('ConfirmationPopUp');
    });
})