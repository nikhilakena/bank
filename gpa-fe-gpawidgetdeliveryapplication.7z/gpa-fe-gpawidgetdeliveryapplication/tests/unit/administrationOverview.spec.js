import administrationOverview from '@/views/app/gpaaadminconfigwidget/modules/adminoverview/administrationOverview';
import Notify from "@/components/Notify";
import DatePicker from "vue2-datepicker";
import Vuelidate from "vuelidate";
//import {maxLength, required} from 'vuelidate/lib/validators';
import {createLocalVue, mount} from "@vue/test-utils";
import AdminOverviewSearchSuccessData from "./MockData/AdminOverviewSearchSuccessData.json";
import AppServices from "@/services/AppServices";
import term from "./MockData/TermsData.json";



const localVue = createLocalVue();
localVue.use(Vuelidate);

describe('should test administrationOverview', () => {

    let wrapper,
        // eslint-disable-next-line no-unused-vars
        notify,
        adminOverviewSearchData;
    const $router = {
        push: jest.fn(),
        go: jest.fn(),
    }

    beforeEach(() => {
        wrapper = mount(administrationOverview, {
            localVue,
            mocks: {
                $router,
                $t: () => {
                },
            },
            data() {
                return {}
            }
        });
        notify = jest.spyOn(wrapper.vm, "notify");
        adminOverviewSearchData = jest.spyOn(AppServices, "retrieveAdmins");
    });

    it('should test name administrationOverview', () => {
        expect(administrationOverview.name).toBe('administrationOverview');
        expect(typeof administrationOverview.name).toBe('string');
    });

    it('should test vue data and component', () => {
        expect(typeof administrationOverview.data).toBe('function');
        expect(administrationOverview.components).toStrictEqual({
            DatePicker, Notify
        });
    });

    it('should test notify method', async () => {
        const notify = jest.spyOn(wrapper.vm, 'notify');
        await notify();
        expect(notify).toHaveBeenCalled();
    });

    it("should allow input for adminId", async () => {
        let adminId = wrapper.find("#adminId");
        expect(adminId.exists()).toBe(true);
        await adminId.find("input").setValue("12345");
    });

    it("should allow input for adminName", async () => {
        let adminName = wrapper.find("#adminName");
        expect(adminName.exists()).toBe(true);
        await adminName.find("input").setValue("Tikkie");
    });

    it("should allow input for adminOwner", async () => {
        let adminOwner = wrapper.find("#adminOwner");
        expect(adminOwner.exists()).toBe(true);
        await adminOwner.find("input").setValue("AAB.SYS.333.444");
    });

    it("should allow input for createdBy", async () => {
        let createdBy = wrapper.find("#createdBy");
        expect(createdBy.exists()).toBe(true);
        await createdBy.find("input").setValue("GPAADMIN");
    });

    it("should validates click of search button", async () => {
        let searchAdminButton, searchAdminFun, adminId, adminName;
        adminId = wrapper.find("#adminId");
        adminName = wrapper.find("#adminName");
        searchAdminButton = wrapper.find("#searchAdminButton");
        searchAdminFun = jest.spyOn(wrapper.vm, "searchAdminFun");
        await wrapper.vm.$set(
            wrapper.vm.searchAdminModel,
            adminId,
            adminName
        );
        await searchAdminButton.trigger("click");
        expect(searchAdminFun).toHaveBeenCalled();
    });

    it("should allow checks proper invoking of backend api calls", async () => {
        adminOverviewSearchData.mockResolvedValue(AdminOverviewSearchSuccessData[0]);

        let retrieveAdmins = jest.spyOn(wrapper.vm, "retrieveAdmins");
        let callretrieveAdmins = jest.spyOn(
            wrapper.vm,
            "retrieveAdmins"
        );
        await retrieveAdmins();
        await wrapper.vm.$nextTick(() => {
            expect(adminOverviewSearchData).not.toHaveBeenCalled();
            expect(retrieveAdmins).not.toHaveBeenCalled();
            expect(callretrieveAdmins).not.toHaveBeenCalled();
        });
        await wrapper.vm.$set(
            wrapper.vm.searchAdminModel,
            123456,
            "adminname"
        );
        //below code to check for -ve scenario
        adminOverviewSearchData.mockRejectedValue();
        await retrieveAdmins();

        await wrapper.vm.$nextTick(() => {
            expect(adminOverviewSearchData).toHaveBeenCalled();
            expect(retrieveAdmins).toHaveBeenCalled();
            expect(callretrieveAdmins).toHaveBeenCalled();
        });
    });

    it('should test method with updateAdmin', async() => {
        /*await wrapper.vm.updateAdmin(AdminOverviewSearchSuccessData[0]);
        await wrapper.vm.$nextTick(() => {
            expect(wrapper.vm.updateAdmin(AdminOverviewSearchSuccessData[0])).toBeCalledTimes(1);
            expect($router).toHaveBeenCalledWith('/updateAdministration/'+this.admin.id);
        });*/

        const updateAdmin = jest.spyOn(wrapper.vm, "updateAdmin");
        await updateAdmin(AdminOverviewSearchSuccessData[0]);
        expect(updateAdmin).toHaveBeenCalled();
    });

    it('should test method with viewAdmin', async() => {
        const viewAdmin = jest.spyOn(wrapper.vm, "viewAdmin");
        await viewAdmin(AdminOverviewSearchSuccessData[0]);
        expect(viewAdmin).toHaveBeenCalled();
    });

    it('should test method with create Admin', async() => {
        const create = jest.spyOn(wrapper.vm, "create");
        await create();
        expect(create).toHaveBeenCalled();
    });

    it('should test method with resetSearchCriteria Admin', async() => {
        const resetSearchCriteria = jest.spyOn(wrapper.vm, "resetSearchCriteria");
        await resetSearchCriteria();
        expect(resetSearchCriteria).toHaveBeenCalled();
    });

/*

    it('should test method with getFormattedDate', async() => {
        let getFormattedDate;
        getFormattedDate = jest.spyOn(wrapper.vm, "getFormattedDate");
        await wrapper.vm.$set(
            wrapper.vm.searchAdminModel,
        );
        await wrapper.vm.$nextTick(() => {
            expect(getFormattedDate(wrapper.vm.searchAdminModel.createdTo)).toHaveBeenCalled();
        });
    });
*/

    it('should test method with setSearchCriteria Admin', async() => {
        let queryToSend = {};
        const setSearchCriteria = jest.spyOn(wrapper.vm, "setSearchCriteria");
        await setSearchCriteria(queryToSend);
        expect(setSearchCriteria).toHaveBeenCalled();
    });

/*
    it('should test httpServiceErrorCall method ', async () => {
        const httpServiceErrorCall = jest.spyOn(wrapper.vm, "httpServiceErrorCall");
        let error = {
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI693_013",
                        "params": null
                    }
                ]
            },
            "status": 500,
        }
        let error2 = {
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI693_013",
                        "params": null
                    }
                ]
            },
            "status": 403,
        }
        await httpServiceErrorCall(error);
        await httpServiceErrorCall(error2);
        expect(httpServiceErrorCall).toHaveBeenCalled();
    });*/

    it('should test getFormattedDate method ', async () => {
        const getFormattedDate = jest.spyOn(wrapper.vm, "getFormattedDate");
        let date = new Date("2022-11-20T18:30:00.000Z");
        await getFormattedDate(date);
        expect(getFormattedDate).toHaveBeenCalled();
    });

/*
    it('should call getFormattedDate method ', () => {
        let dateValue;
        dateValue='1';
        const myMock1 = jest.fn();
        const bound = myMock1.getFullYear();
        bound();
        wrapper.vm.getFormattedDate(dateValue);
        wrapper.vm.$nextTick(() => {
            expect(wrapper.vm. getFormattedDate()).toBeCalledTimes(1)
        });
    });
*/

    it('should test searchAdminFun method ', async () => {
        const searchAdminFun = jest.spyOn(wrapper.vm, "searchAdminFun");
        wrapper.vm.searchAdminModel= {
            "adminId": "11",
            "adminName": "test2",
            "createdBy": "GPAADMIN",
            "oarId": "",
            "createdTimeStamp": "",
            "createdFrom": "2022-11-28T18:30:00.000Z",
            "createdTo": "2022-11-28T18:30:00.000Z",
            "adminOwner": "AAB.SYS.33333\t"};
        wrapper.vm.searchAdminModel.createdFrom = new Date("2022-11-20T18:30:00.000Z");
        wrapper.vm.searchAdminModel.createdTo = new Date("2022-11-20T18:30:00.000Z");
        await searchAdminFun();
        expect(searchAdminFun).toHaveBeenCalled();
    });

    it('should test isEmpty method ',  () => {
        wrapper.vm.isEmpty("");
    });

    it('should test sortTable method ', async () => {
        const sortTable = jest.spyOn(wrapper.vm, "sortTable");
        wrapper.vm.sortColumn = "1";
        wrapper.vm.viewResult = [{"id":"17"}, {"id":"18"}]
        let col = "1"
        await sortTable(col);
        await sortTable("2");
        expect(sortTable).toHaveBeenCalled();
    });

/*    it('should test disableSearchButton method ', async () => {
        wrapper.vm.disableSearchButton();
    });*/

    it('should test httpServiceErrorCall method ', async () => {
        const httpServiceErrorCall = jest.spyOn(wrapper.vm, "httpServiceErrorCall");
        const arrErrors= [{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 500,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 403,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 404,
        },{
            "data": {
                "errors": [
                    {
                        "code": "MESSAGE_BAI692_013",
                        "params": null
                    }
                ]
            },
            "status": 405,
        },{
            "data": {
                "errors": [
                    {
                        "code": null,
                        "params": null
                    }
                ]
            },
            "status": 503,
        }]
        await httpServiceErrorCall(arrErrors[0]);
        await httpServiceErrorCall(arrErrors[1]);
        await httpServiceErrorCall(arrErrors[2]);
        await httpServiceErrorCall(arrErrors[3]);
        await httpServiceErrorCall(arrErrors[4]);
        expect(httpServiceErrorCall).toHaveBeenCalled();
    });











});