import {shallowMount,createLocalVue} from "@vue/test-utils";
import VueI18n from 'vue-i18n'
import Navbar from '../../src/components/Navbar';
const localVue = createLocalVue()
localVue.use(VueI18n)
describe('Navbar Component', () => {
    // eslint-disable-next-line no-unused-vars
    let wrapper;
    const i18n = new VueI18n({
        locale: "en",
    });

    beforeEach(() => {
        wrapper = shallowMount(Navbar,{
            localVue,
            i18n,
            propsData: {
                actionTab:'actionTab',
                tabsData:''
            }
        });
    });
    it('is the name correct',() => {
        expect(Navbar.name).toBe('Navbar');
    });
})