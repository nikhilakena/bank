import common from "@/mixins/common";
import { createLocalVue, shallowMount } from "@vue/test-utils";
import term from "./MockData/TermsData.json";
const localVue = createLocalVue();

describe("should test common", () => {
    let wrapper;
    const push = jest.fn();
    const $router = {
        push: jest.fn(),
        go: jest.fn(),
    };

    beforeEach(() => {
        wrapper = shallowMount(common, {
            localVue,
            term,
            mocks: {
                $router,
                $t: () => {},
            },
            data() {
                return {
                };
            },
        });
    });

    it("should test validateTermsDtls method ", async () => {
        const validateTermsDtls = jest.spyOn(wrapper.vm, "validateTermsDtls");
        wrapper.vm.selectedTerms = [
            {
                validated: 1,
                showMessage: true,
                errorMsgLabel: "ERROR_MANDATORY_FACETS_DTLS",
            },
        ];
        await validateTermsDtls();

        wrapper.vm.selectedTerms = [
            { validated: 1, showMessage: true, errorMsgLabel: "" },
        ];
        await validateTermsDtls();

        wrapper.vm.selectedTerms = [
            { validated: true, showMessage: true, errorMsgLabel: "" },
        ];
        await validateTermsDtls();

        wrapper.vm.selectedTerms = undefined;
        await validateTermsDtls();
        expect(validateTermsDtls).toHaveBeenCalled();
    });

    it("should test validateNumericRange method ", async () => {
        const validateNumericRange = jest.spyOn(wrapper.vm, "validateNumericRange");
        let index = 0;
        let term2 = term;
        term2.facets[0].facetType = "MaxInclusive";
        await validateNumericRange(index, term2);
        let term3 = term;
        term3.facets[0].facetType = "MaxExclusive";
        await validateNumericRange(index, term3);

        term2.facets[0].facetType = "";
        await validateNumericRange(index, term2);

        wrapper.vm.numericRangeMandateField = true;
        expect(validateNumericRange).toHaveBeenCalled();
    });

    it("should test validateUnicode method ", async () => {
        const validateUnicode = jest.spyOn(wrapper.vm, "validateUnicode");
        let input = "\u6f22\u5b57";
        await validateUnicode(input);
        expect(validateUnicode).toHaveBeenCalled();
    });

    it("should test validateNumericRange method ", async () => {
        const validateNumericRange = jest.spyOn(wrapper.vm, "validateNumericRange");
        let index = 0;
        let VNR1 = {"facets" :[{"facetType": "MaxInclusive", showFlag: true}]};
        await validateNumericRange(index, VNR1);
        VNR1.facets[0].facetType = "MaxExclusive"
        await validateNumericRange(index, VNR1);
        VNR1.facets[0].facetType = ""
        await validateNumericRange(index, VNR1);
        expect(validateNumericRange).toHaveBeenCalled();
    });

    it("should test validateFractionAndTotalDigits method ", async () => {
        const validateFractionAndTotalDigits = jest.spyOn(wrapper.vm,"validateFractionAndTotalDigits");
        const _index = 0;
        let v = { facets: [{ facetType: "", "showFlag":true,facetValue:""},{}] };
        await validateFractionAndTotalDigits(_index, v);
        let v1 = { facets: [{ facetType: "Fractions"}] };
        await validateFractionAndTotalDigits(_index, v1);
        let v2 = { facets: [{ facetType: "Total Digits"}] };
        await validateFractionAndTotalDigits(_index, v2);

        v1.facets[0].facetValue= "a";
        await validateFractionAndTotalDigits(_index, v1);
        v1.facets[0].facetValue= 0;
        await validateFractionAndTotalDigits(_index, v1);
        v1.facets[0].facetValue= "1";
        await validateFractionAndTotalDigits(_index, v1);
        v1.facets[0].facetValue= undefined;
        await validateFractionAndTotalDigits(_index, v1);
        v2.facets[0].facetValue= "a";
        await validateFractionAndTotalDigits(_index, v2);
        v2.facets[0].facetValue= 0;
        await validateFractionAndTotalDigits(_index, v2);
        v2.facets[0].facetValue= "1";
        await validateFractionAndTotalDigits(_index, v2);
        v2.facets[0].facetValue= undefined;
        await validateFractionAndTotalDigits(_index, v2);
        expect(validateFractionAndTotalDigits).toHaveBeenCalled();
    });

    it("should test validateMaxMinLength method ", async () => {
        const validateMaxMinLength = jest.spyOn(wrapper.vm, "validateMaxMinLength");
        let MNL1 = {"facets":[{"facetType":"Maximum length", "facetValue":"e"}]};
        await validateMaxMinLength(0, MNL1);
        let MNL2 = {"facets":[{"facetType":"Minimum length", "facetValue":"e"}]};
        await validateMaxMinLength(0, MNL2);
        let MNL3 = {"facets":[{"facetType":"Length","facetValue":"e"}]};
        await validateMaxMinLength(0, MNL3);
        let MNL4 = {"facets":[{"facetType":"Pattern","facetValue":"e"}]};
        await validateMaxMinLength(0, MNL4);
        let MNL5 = {"facets":[{"facetType":"Fractions","facetValue":"e"}]};
        await validateMaxMinLength(0, MNL5);
        let MNL6 = {"facets":[{"facetType":"Total Digits","facetValue":"e"}]};
        await validateMaxMinLength(0, MNL6);


        MNL3.facets[0].facetValue= "1";
        await validateMaxMinLength(0, MNL3);
        MNL3.facets[0].facetValue= "a";
        await validateMaxMinLength(0, MNL3);
        MNL1.facets[0].facetValue= "1";
        await validateMaxMinLength(0, MNL1);
        MNL1.facets[0].facetValue= "a";
        await validateMaxMinLength(0, MNL1);
        MNL2.facets[0].facetValue= "1";
        await validateMaxMinLength(0, MNL2);
        MNL2.facets[0].facetValue= "a";
        await validateMaxMinLength(0, MNL2);
        MNL4.facets[0].facetValue= "1";
        await validateMaxMinLength(0, MNL4);
        MNL4.facets[0].facetValue= "a";
        await validateMaxMinLength(0, MNL4);
        expect(validateMaxMinLength).toHaveBeenCalled();
    });

    it("should test validateNumericSingle method ", async () => {
        const validateNumericSingle = jest.spyOn(wrapper.vm,"validateNumericSingle"
        );
        let term2 = {"facets":[{},{}]};
        term2.facets[0].showFlag= true;
        term2.facets[0].facetType = "Maximum length";
        term2.validated = true;
        await validateNumericSingle(1, term2);
        term2.facets[0].facetType = "";
        await validateNumericSingle(1, term2);
        expect(validateNumericSingle).toHaveBeenCalled();
    });

    it("should test validateNumericListTypeSelected method ", async () => {
        const validateNumericListTypeSelected = jest.spyOn(wrapper.vm,"validateNumericListTypeSelected"
        );
        let t = {};
        t.facetValue= "12,12";
        await validateNumericListTypeSelected(0,t);
        t.isSpecialCharPresentInFacetValue = true;
        t.facetValue= "12,34";
        await validateNumericListTypeSelected(0,t);
        t.facetValue= "a,b";
        await validateNumericListTypeSelected(0,t);
        t.facetValue= "";
        await validateNumericListTypeSelected(0,t);
        expect(validateNumericListTypeSelected).toHaveBeenCalled();
    });
    it("should test validateNumericEnum method ", async () => {
        const validateNumericEnum = jest.spyOn(wrapper.vm, "validateNumericEnum");
        await validateNumericEnum(1, term);
        expect(validateNumericEnum).toHaveBeenCalled();
        let term2 = term;
        term2.facetCategory = "";
        await validateNumericEnum(1, term2);
        expect(validateNumericEnum).toHaveBeenCalled();
    });

    it("should test validateNumericTypeSelected method ", async () => {
        const validateNumericTypeSelected = jest.spyOn(
            wrapper.vm,
            "validateNumericTypeSelected"
        );
        let term2 = term;
        term2.facetCategory = "List";
        await validateNumericTypeSelected(1, term2);
        term2.facetCategory = "Single Value";
        await validateNumericTypeSelected(1, term2);
        term2.facetCategory = "Range";
        await validateNumericTypeSelected(1, term2);
        expect(validateNumericTypeSelected).toHaveBeenCalled();
    });

    it("should test validateMaxMinExcInc method ", async () => {
        const validateMaxMinExcInc = jest.spyOn(wrapper.vm, "validateMaxMinExcInc");
        let term2 = { facets: [{ facetType: "MinInclusive" }] };
        await validateMaxMinExcInc(1, term2);
        let term3 = { facets: [{ facetType: "MaxInclusive" }] };
        await validateMaxMinExcInc(1, term3);
        let term4 = { facets: [{ facetType: "MinExclusive" }] };
        await validateMaxMinExcInc(1, term4);
        let term5 = { facets: [{ facetType: "MaxExclusive" }] };
        await validateMaxMinExcInc(1, term5);/*
        let term6 = { facets: [{ facetType: "", facetValue: "", showFlag: true }] };
        await validateMaxMinExcInc(1, term6);*/

        term2.facets[0].facetValue= "0"
        await validateMaxMinExcInc(1, term2);
        term3.facets[0].facetValue= "0"
        await validateMaxMinExcInc(1, term3);
        term4.facets[0].facetValue= "0"
        await validateMaxMinExcInc(1, term4);
        term5.facets[0].facetValue= "0"
        await validateMaxMinExcInc(1, term5);

        term2.facets[0].facetValue= "12"
        await validateMaxMinExcInc(1, term2);
        term3.facets[0].facetValue= "12"
        await validateMaxMinExcInc(1, term3);
        term4.facets[0].facetValue= "12"
        await validateMaxMinExcInc(1, term4);
        term5.facets[0].facetValue= "12"
        await validateMaxMinExcInc(1, term5);

        term2.facets[0].facetValue= "ab";
        await validateMaxMinExcInc(1, term2);
        term3.facets[0].facetValue= "ab";
        await validateMaxMinExcInc(1, term3);
        term4.facets[0].facetValue= "ab";
        await validateMaxMinExcInc(1, term4);
        term5.facets[0].facetValue= "ab";
        await validateMaxMinExcInc(1, term5);

        let maxIncIndex = 0
        term3.facets[maxIncIndex].facetValue= 0;
        await validateMaxMinExcInc(0, term3);
        term5.facets[maxIncIndex].facetValue= 0;
        await validateMaxMinExcInc(0, term5);
        expect(validateMaxMinExcInc).toHaveBeenCalled();
    });

    it("should test validateStringRange method ", async () => {
        const validateStringRange = jest.spyOn(wrapper.vm, "validateStringRange");

        let term2 = {
            facets: [{ facetType: "MaxInclusive", facetValue: "", showFlag: true }],
            validated: 1,
        };
        await validateStringRange(1, term2);
        let term3 = {
            facets: [{ facetType: "", facetValue: "", showFlag: true }],
            validated: 1,
        };
        await validateStringRange(1, term3);
        let term4 = {
            facets: [{ facetType: "", facetValue: "", showFlag: true }],
            validated: 1,
        };
        await validateStringRange(1, term4);

        expect(validateStringRange).toHaveBeenCalled();
    });

    it("should test validateStringSingle method ", async () => {
        const validateStringSingle = jest.spyOn(wrapper.vm, "validateStringSingle");
        let term2 = {
            facets: [{ facetType: "Maximum length", facetValue: "", showFlag: true }],
            validated: true,
        };
        await validateStringSingle(1, term2, {});
        let term3 = {
            facets: [{ facetType: "M", facetValue: "", showFlag: true }],
            validated: true,
        };
        await validateStringSingle(1, term3, {});
        await validateStringSingle(1, term, {});
        expect(validateStringSingle).toHaveBeenCalled();
    });
    it("should test validateListTypeSelected method ", async () => {
        const validateListTypeSelected = jest.spyOn(wrapper.vm,"validateListTypeSelected");
        let term2 = term ; term2.isSpecialCharPresentInFacetValue = true;
        await validateListTypeSelected(0,term2);
        let t = {}; t.facetValue= "";
        await validateListTypeSelected(0,t);
        t.facetValue= "12,12";
        await validateListTypeSelected(0,t);
        t.facetValue= "12,34";
        await validateListTypeSelected(0,t);
        expect(validateListTypeSelected).toHaveBeenCalled();
    });
    it("should test validateStringEnum method ", async () => {
        const validateStringEnum = jest.spyOn(wrapper.vm, "validateStringEnum");
        await validateStringEnum(1, term);
        term.facetCategory = "";
        await validateStringEnum(1, term);
        expect(validateStringEnum).toHaveBeenCalled();
    });

    /*
      it('should test validateStringEnum method ', async () => {
          const validateStringEnum = jest.spyOn(wrapper.vm, "validateStringEnum");

          await validateStringEnum(1,term);
          expect(validateStringEnum).toHaveBeenCalled();

          await validateStringEnum(1,term);
          expect(wrapper.term.validated).toBe(false);
          expect(validateStringEnum).toHaveBeenCalled();
      });
  */

    it("should test validateStringTypeSelected method ", async () => {
        const validateStringTypeSelected = jest.spyOn(
            wrapper.vm,
            "validateStringTypeSelected"
        );
        let term2 = term;
        term2.facetCategory = "List";
        await validateStringTypeSelected(1, term2, {});
        let term3 = term;
        term3.facetCategory = "Single Value";
        await validateStringTypeSelected(1, term3, {});
        let term4 = term;
        term.facetCategory = "Range";
        await validateStringTypeSelected(1, term4, {});
        let term5 = term;
        term5.facetCategory = "";
        await validateStringTypeSelected(1, term5, {});
        expect(validateStringTypeSelected).toHaveBeenCalled();
    });
    it("should test validateBooleanTypeSelected method ", async () => {
        const validateBooleanTypeSelected = jest.spyOn(
            wrapper.vm,
            "validateBooleanTypeSelected"
        );
        term.isSpecialCharPresentInFacetValue = true;
        await validateBooleanTypeSelected(1, term, {});

        term.isSpecialCharPresentInFacetValue = false;
        await validateBooleanTypeSelected(1, term, {});

        let term2 = {};
        term2.facetValue = ",,,";
        await validateBooleanTypeSelected(1, term2, {});
        expect(validateBooleanTypeSelected).toHaveBeenCalled();
        let term3 = {};
        term3.facetValue = ",";
        await validateBooleanTypeSelected(1, term3, {});
        expect(validateBooleanTypeSelected).toHaveBeenCalled();

        let term4 = {};
        term3.facetValue = "";
        await validateBooleanTypeSelected(1, term4, {});
        expect(validateBooleanTypeSelected).toHaveBeenCalled();
    });
    it("should test validateFacetsMandatoryFields method ", async () => {
        const validateFacetsMandatoryFields = jest.spyOn(
            wrapper.vm,
            "validateFacetsMandatoryFields"
        );
        await validateFacetsMandatoryFields(1, term, {});
        expect(validateFacetsMandatoryFields).toHaveBeenCalled();

        term.dataType = "DATE";
        await validateFacetsMandatoryFields(1, term, {});

        let term2 = {};
        term2.mandatory = 0;
        await validateFacetsMandatoryFields(1, term2, {});
        expect(validateFacetsMandatoryFields).toHaveBeenCalled();

        term.dataType = "STRING";
        await validateFacetsMandatoryFields(1, term, {});
        expect(validateFacetsMandatoryFields).toHaveBeenCalled();

        term.dataType = "NUMERIC";
        await validateFacetsMandatoryFields(1, term, {});
        expect(validateFacetsMandatoryFields).toHaveBeenCalled();
    });
    it("should test invalidProductListFormat method ", async () => {
        const invalidProductListFormat = jest.spyOn(
            wrapper.vm,
            "invalidProductListFormat"
        );
        await invalidProductListFormat([]);
        await invalidProductListFormat("1234");

        expect(invalidProductListFormat).toHaveBeenCalled();
    });

    it("should test validateProductIdFormat method ", async () => {
        const validateProductIdFormat = jest.spyOn(
            wrapper.vm,
            "validateProductIdFormat"
        );
        let obj = "1234";
        await validateProductIdFormat(obj);
        expect(validateProductIdFormat).toHaveBeenCalled();

        let obj2 = [];
        await validateProductIdFormat(obj2);
        expect(validateProductIdFormat).toHaveBeenCalled();

        let obj3 = "1234567,1234567,1234567,41234567,1234567,1234567,1234567";
        await validateProductIdFormat(obj3);
        expect(validateProductIdFormat).toHaveBeenCalled();

        let obj4 = "1,2,3";
        await validateProductIdFormat(obj4);
        expect(validateProductIdFormat).toHaveBeenCalled();

        let obj5 = "1234567 ";
        await validateProductIdFormat(obj5);
        expect(validateProductIdFormat).toHaveBeenCalled();
    });

    it("should test invalidInputValue method ", async () => {
        const invalidInputValue = jest.spyOn(wrapper.vm, "invalidInputValue");
        let facetValue = ["e"];
        await invalidInputValue(facetValue, term);
        expect(invalidInputValue).toHaveBeenCalled();
    });
    it("should test checkNegativeValue method ", async () => {
        const checkNegativeValue = jest.spyOn(wrapper.vm, "checkNegativeValue");
        let facetValue = "";
        await checkNegativeValue(facetValue, term);
        expect(checkNegativeValue).toHaveBeenCalled();
    });
    it("should test formatListValues method ", async () => {
        const formatListValues = jest.spyOn(wrapper.vm, "formatListValues");
        let tempValue = "1234, 5678";
        await formatListValues(tempValue);
        expect(formatListValues).toHaveBeenCalled();
    });

    it("should test isMandatorySelected method ", async () => {
        const isMandatorySelected = jest.spyOn(wrapper.vm, "isMandatorySelected");
        term.mandatory = "";
        await isMandatorySelected(term);
        expect(isMandatorySelected).toHaveBeenCalled();
        term.mandatory = false;
        await isMandatorySelected(term);
        expect(isMandatorySelected).toHaveBeenCalled();
    });

    it("should test checkGreaterOrEqual method ", async () => {
        const checkGreaterOrEqual = jest.spyOn(wrapper.vm, "checkGreaterOrEqual");
        await checkGreaterOrEqual(1, 2);
        await checkGreaterOrEqual(1, 1);
        expect(checkGreaterOrEqual).toHaveBeenCalled();
    });

    it("should test hasDuplicates method ", async () => {
        const hasDuplicates = jest.spyOn(wrapper.vm, "hasDuplicates");
        let selectedTerms = ["123", "123", "456"];
        await hasDuplicates(["abcd"]);
        await hasDuplicates(["", ""]);
        await hasDuplicates([]);
        await hasDuplicates(selectedTerms);
        expect(hasDuplicates).toHaveBeenCalled();
    });

    it("should test checkDuplicateTerms method ", async () => {
        const checkDuplicateTerms = jest.spyOn(wrapper.vm, "checkDuplicateTerms");
        let selectedTerms = [{name:"a"},{name:"a"}, "123", "456"];
        await checkDuplicateTerms(selectedTerms);
        expect(checkDuplicateTerms).toHaveBeenCalled();

    });


});
