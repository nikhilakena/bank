import filters from '../../src/filters/filters';
import { shallowMount, createLocalVue } from '@vue/test-utils';

const localVue = createLocalVue();

describe("filter", () => {
  // eslint-disable-next-line no-unused-vars
  let wrapper;
  beforeEach(() => {
    wrapper = shallowMount(filters, {
      localVue,
    });
  });

  test("to test formatDate function", () => {
    const formatDate = jest.spyOn(filters, "formatDate");
    expect(formatDate("2022-05-30T10:00:00.000Z")).toBe("30.05.2022");
  });
  test("to test formatDateTime function", async () => {
    const formatDateTime = jest.spyOn(filters, "formatDateTime");
    await formatDateTime("2022-05-30T10:00:00.000Z");
    expect(formatDateTime).toHaveBeenCalled();
  });
  test("to test formatLang function", () => {
    const formatLang = jest.spyOn(filters, "formatLang");
    expect(formatLang("mrt","en")).toBe("mar");
    expect(formatLang("mei","en")).toBe("may");
    expect(formatLang("okt","en")).toBe("oct");
  });
});
