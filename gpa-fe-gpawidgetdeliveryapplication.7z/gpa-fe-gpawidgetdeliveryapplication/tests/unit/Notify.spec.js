import {shallowMount,createLocalVue} from "@vue/test-utils";
import VueI18n from 'vue-i18n'
import Notify from "../../src/components/Notify";
const localVue = createLocalVue()
localVue.use(VueI18n)
describe('Notify Component', () => {
    // eslint-disable-next-line no-unused-vars
    let wrapper;
    const i18n = new VueI18n({
        locale: "en",
    });

    beforeEach(() => {
        wrapper = shallowMount(Notify,{
            localVue,
            i18n,
            propsData: {
                notificationType:"msgType",
                displayMessage:"displayMsg",
                closeNotification:"closeNotify",
            }
        });
    });
    it('is the name correct',() => {
        expect(Notify.name).toBe('Notify');
    });

    it('should test notify method',async () => {
        const notify = jest.spyOn(wrapper.vm, "notify");
        await wrapper.vm.$nextTick(() => {
            expect(notify).toHaveBeenCalledWith(wrapper.vm.notify());
            expect(wrapper.vm.notify()).toBeCalledTimes(1);
        });
    });

    it('should test close method',async () => {
        const close = jest.spyOn(wrapper.vm, "close");
        await wrapper.vm.$nextTick(() => {
            expect(close).toHaveBeenCalledWith(wrapper.vm.close());
            expect(wrapper.vm.close()).toBeCalledTimes(1);
        });
    });
})