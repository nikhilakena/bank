import adminConfigUtility from '@/mixins/adminConfigUtility';
import term from "./MockData/TermsData.json";
import { mount, createLocalVue } from '@vue/test-utils';

const localVue = createLocalVue();

describe("adminConfigUtility", () => {
    // eslint-disable-next-line no-unused-vars
    let wrapper;
    beforeEach(() => {
        wrapper = mount(adminConfigUtility, {
            localVue,
            mocks: {
                $t: () => {
                }
            },
            data() {
                return {}
            }
        });
    });

    it("should test validateFacetsMandatoryFields method ", async () => {
        const validateFacetsMandatoryFields = jest.spyOn(
            wrapper.vm,
            "validateFacetsMandatoryFields"
        );
        await validateFacetsMandatoryFields(1, term, {});
        expect(validateFacetsMandatoryFields).toHaveBeenCalled();

        term.dataType = "DATE";
        await validateFacetsMandatoryFields(1, term, {});

        let term2 = {};
        term2.mandatory = 0;
        await validateFacetsMandatoryFields(1, term2, {});
        expect(validateFacetsMandatoryFields).toHaveBeenCalled();

        term.dataType = "STRING";
        await validateFacetsMandatoryFields(1, term, {});
        expect(validateFacetsMandatoryFields).toHaveBeenCalled();

        term.dataType = "NUMERIC";
        await validateFacetsMandatoryFields(1, term, {});
        expect(validateFacetsMandatoryFields).toHaveBeenCalled();
    });


    it("should test isMandatorySelected method ", async () => {
        const isMandatorySelected = jest.spyOn(wrapper.vm, "isMandatorySelected");
        term.mandatory = "";
        await isMandatorySelected(term);
        expect(isMandatorySelected).toHaveBeenCalled();
        term.mandatory = false;
        await isMandatorySelected(term);
        expect(isMandatorySelected).toHaveBeenCalled();
    });

    it("should test validateStringTypeSelected method ", async () => {
        const validateStringTypeSelected = jest.spyOn(
            wrapper.vm,
            "validateStringTypeSelected"
        );
        let term2 = term;
        term2.facetCategory = "List";
        await validateStringTypeSelected(1, term2, {});
        let term3 = term;
        term3.facetCategory = "Single Value";
        await validateStringTypeSelected(1, term3, {});
        let term4 = term;
        term.facetCategory = "Range";
        await validateStringTypeSelected(1, term4, {});
        let term5 = term;
        term5.facetCategory = "";
        await validateStringTypeSelected(1, term5, {});
        expect(validateStringTypeSelected).toHaveBeenCalled();
    });

    it("should test validateStringEnum method ", async () => {
        const validateStringEnum = jest.spyOn(wrapper.vm, "validateStringEnum");
        await validateStringEnum(1, term);
        term.facetCategory = "";
        await validateStringEnum(1, term);
        expect(validateStringEnum).toHaveBeenCalled();
    });

    it("should test validateListTypeSelected method ", async () => {
        const validateListTypeSelected = jest.spyOn(wrapper.vm,"validateListTypeSelected");
        let term2 = term ; term2.isSpecialCharPresentInFacetValue = true;
        await validateListTypeSelected(0,term2);
        let t = {}; t.facetValue= "";
        await validateListTypeSelected(0,t);
        t.facetValue= "12,12";
        await validateListTypeSelected(0,t);
        t.facetValue= "12,34";
        await validateListTypeSelected(0,t);
        expect(validateListTypeSelected).toHaveBeenCalled();
    });

    it("should test formatListValues method ", async () => {
        const formatListValues = jest.spyOn(wrapper.vm, "formatListValues");
        let tempValue = "1234, 5678";
        await formatListValues(tempValue);
        expect(formatListValues).toHaveBeenCalled();
    });

    it("should test hasDuplicates method ", async () => {
        const hasDuplicates = jest.spyOn(wrapper.vm, "hasDuplicates");
        let selectedTerms = ["123", "123", "456"];
        await hasDuplicates(["abcd"]);
        await hasDuplicates(["", ""]);
        await hasDuplicates([]);
        await hasDuplicates(selectedTerms);
        expect(hasDuplicates).toHaveBeenCalled();
    });

    it("should test checkDuplicateTerms method ", async () => {
        const checkDuplicateTerms = jest.spyOn(wrapper.vm, "checkDuplicateTerms");
        let selectedTerms = [{name:"a"},{name:"a"}, "123", "456"];
        await checkDuplicateTerms(selectedTerms);
        expect(checkDuplicateTerms).toHaveBeenCalled();

    });


    it("should test validateStringSingle method ", async () => {
        const validateStringSingle = jest.spyOn(wrapper.vm, "validateStringSingle");
        let term2 = {
            facets: [{ facetType: "Maximum length", facetValue: "", showFlag: true }],
            validated: true,
        };
        await validateStringSingle(1, term2, {});
        let term3 = {
            facets: [{ facetType: "M", facetValue: "", showFlag: true }],
            validated: true,
        };
        await validateStringSingle(1, term3, {});
        await validateStringSingle(1, term, {});
        expect(validateStringSingle).toHaveBeenCalled();
    });

    it("should test validateStringRange method ", async () => {
        const validateStringRange = jest.spyOn(wrapper.vm, "validateStringRange");

        let term2 = {
            facets: [{ facetType: "MaxInclusive", facetValue: "", showFlag: true }],
            validated: 1,
        };
        await validateStringRange(1, term2);
        let term3 = {
            facets: [{ facetType: "", facetValue: "", showFlag: true }],
            validated: 1,
        };
        await validateStringRange(1, term3);
        let term4 = {
            facets: [{ facetType: "", facetValue: "", showFlag: true }],
            validated: 1,
        };
        await validateStringRange(1, term4);

        expect(validateStringRange).toHaveBeenCalled();
    });

    it("should test validateNumericTypeSelected method ", async () => {
        const validateNumericTypeSelected = jest.spyOn(wrapper.vm,"validateNumericTypeSelected"
        );
        let term2 = term;
        term2.facetCategory = "List";
        await validateNumericTypeSelected(1, term2);
        term2.facetCategory = "Single Value";
        await validateNumericTypeSelected(1, term2);
        term2.facetCategory = "Range";
        await validateNumericTypeSelected(1, term2);
        term2.facetCategory = "";
        await validateNumericTypeSelected(1, term2);
        expect(validateNumericTypeSelected).toHaveBeenCalled();
    });

    it("should test validateNumericEnum method ", async () => {
        const validateNumericEnum = jest.spyOn(wrapper.vm, "validateNumericEnum");
        await validateNumericEnum(1, term);
        expect(validateNumericEnum).toHaveBeenCalled();
        let term2 = term;
        term2.facetCategory = "";
        await validateNumericEnum(1, term2);
        expect(validateNumericEnum).toHaveBeenCalled();
    });

    it("should test validateNumericListTypeSelected method ", async () => {
        const validateNumericListTypeSelected = jest.spyOn(wrapper.vm,"validateNumericListTypeSelected"
        );
        let t = {};
        t.facetValue= "12,12";
        await validateNumericListTypeSelected(0,t);
        t.facetValue= "12,34";
        await validateNumericListTypeSelected(0,t);
        t.facetValue= "a,b";
        await validateNumericListTypeSelected(0,t);
        t.facetValue= "";
        await validateNumericListTypeSelected(0,t);
        expect(validateNumericListTypeSelected).toHaveBeenCalled();
    });

    it("should test validateNumericSingle method ", async () => {
        const validateNumericSingle = jest.spyOn(wrapper.vm,"validateNumericSingle"
        );
        wrapper.vm.stringSingleMandateField = true;
        let term2 = {"facets":[{},{}]};
        term2.facets[0].showFlag= true;
        term2.facets[0].facetType = "Maximum length";
        term2.validated = true;
        await validateNumericSingle(1, term2);
        term2.facets[0].facetType = "";
        await validateNumericSingle(1, term2);
        expect(validateNumericSingle).toHaveBeenCalled();
    });

    it("should test validateFractionAndTotalDigits method ", async () => {
        const validateFractionAndTotalDigits = jest.spyOn(wrapper.vm,"validateFractionAndTotalDigits");
        const _index = 0;
        let v = { facets: [{ facetType: "", "showFlag":true,facetValue:""},{}] };
        await validateFractionAndTotalDigits(_index, v);
        let v1 = { facets: [{ facetType: "Fractions"}] };
        await validateFractionAndTotalDigits(_index, v1);
        let v2 = { facets: [{ facetType: "Total Digits"}] };
        await validateFractionAndTotalDigits(_index, v2);

        v1.facets[0].facetValue= "a";
        await validateFractionAndTotalDigits(_index, v1);
        v1.facets[0].facetValue= 0;
        await validateFractionAndTotalDigits(_index, v1);
        v1.facets[0].facetValue= "1";
        await validateFractionAndTotalDigits(_index, v1);
        v1.facets[0].facetValue= undefined;
        await validateFractionAndTotalDigits(_index, v1);
        v2.facets[0].facetValue= "a";
        await validateFractionAndTotalDigits(_index, v2);
        v2.facets[0].facetValue= 0;
        await validateFractionAndTotalDigits(_index, v2);
        v2.facets[0].facetValue= "1";
        await validateFractionAndTotalDigits(_index, v2);
        v2.facets[0].facetValue= undefined;
        await validateFractionAndTotalDigits(_index, v2);
        v2.facets[0].facetValue= "1a";
        await validateFractionAndTotalDigits(_index, v2);
        v1.facets[0].facetValue= "1a";
        await validateFractionAndTotalDigits(_index, v1);

        expect(validateFractionAndTotalDigits).toHaveBeenCalled();
    });

    it("should test invalidInputValue method ", async () => {
        const invalidInputValue = jest.spyOn(wrapper.vm, "invalidInputValue");
        let facetValue = ["e"];
        await invalidInputValue(facetValue, term);
        expect(invalidInputValue).toHaveBeenCalled();
    });

    it("should test checkNegativeValue method ", async () => {
        const checkNegativeValue = jest.spyOn(wrapper.vm, "checkNegativeValue");
        let facetValue = "";
        await checkNegativeValue(facetValue, term);
        expect(checkNegativeValue).toHaveBeenCalled();
    });

    it("should test validateNumericRange method ", async () => {
        const validateNumericRange = jest.spyOn(wrapper.vm, "validateNumericRange");
        let index = 0;
        let VNR1 = {"facets" :[{"facetType": "MaxInclusive", showFlag: true}]};
        await validateNumericRange(index, VNR1);
        VNR1.facets[0].facetType = "MaxExclusive"
        await validateNumericRange(index, VNR1);
        VNR1.facets[0].facetType = ""
        await validateNumericRange(index, VNR1);
        expect(validateNumericRange).toHaveBeenCalled();
    });

    it("should test validateBooleanTypeSelected method ", async () => {
        const validateBooleanTypeSelected = jest.spyOn(wrapper.vm,"validateBooleanTypeSelected"
        );
        let termm = term; termm.isSpecialCharPresentInFacetValue = true;
        await validateBooleanTypeSelected(1, termm, {});

        termm.isSpecialCharPresentInFacetValue = false;
        await validateBooleanTypeSelected(1, termm, {});

        let term2 = {};
        term2.facetValue = ",,,";
        await validateBooleanTypeSelected(1, term2, {});
        expect(validateBooleanTypeSelected).toHaveBeenCalled();
        let term3 = {};
        term3.facetValue = ",";
        await validateBooleanTypeSelected(1, term3, {});
        expect(validateBooleanTypeSelected).toHaveBeenCalled();

        let term4 = {};
        term3.facetValue = "";
        await validateBooleanTypeSelected(1, term4, {});
        expect(validateBooleanTypeSelected).toHaveBeenCalled();
    });

    it("should test validateMaxMinExcInc method ", async () => {
        const validateMaxMinExcInc = jest.spyOn(wrapper.vm, "validateMaxMinExcInc");
        let term2 = { facets: [{ facetType: "MinInclusive" }] };
        await validateMaxMinExcInc(1, term2);
        let term3 = { facets: [{ facetType: "MaxInclusive" }] };
        await validateMaxMinExcInc(1, term3);
        let term4 = { facets: [{ facetType: "MinExclusive" }] };
        await validateMaxMinExcInc(1, term4);
        let term5 = { facets: [{ facetType: "MaxExclusive" }] };
        await validateMaxMinExcInc(1, term5);/*
        let term6 = { facets: [{ facetType: "", facetValue: "", showFlag: true }] };
        await validateMaxMinExcInc(1, term6);*/

        term2.facets[0].facetValue= "0"
        await validateMaxMinExcInc(1, term2);
        term3.facets[0].facetValue= "0"
        await validateMaxMinExcInc(1, term3);
        term4.facets[0].facetValue= "0"
        await validateMaxMinExcInc(1, term4);
        term5.facets[0].facetValue= "0"
        await validateMaxMinExcInc(1, term5);

        term2.facets[0].facetValue= "12"
        await validateMaxMinExcInc(1, term2);
        term3.facets[0].facetValue= "12"
        await validateMaxMinExcInc(1, term3);
        term4.facets[0].facetValue= "12"
        await validateMaxMinExcInc(1, term4);
        term5.facets[0].facetValue= "12"
        await validateMaxMinExcInc(1, term5);

        term2.facets[0].facetValue= "ab";
        await validateMaxMinExcInc(1, term2);
        term3.facets[0].facetValue= "ab";
        await validateMaxMinExcInc(1, term3);
        term4.facets[0].facetValue= "ab";
        await validateMaxMinExcInc(1, term4);
        term5.facets[0].facetValue= "ab";
        await validateMaxMinExcInc(1, term5);


        term3.facets[0].facetValue=0;
        await validateMaxMinExcInc(0, term3);
        term5.facets[0].facetValue= 0;
        await validateMaxMinExcInc(0, term5);
        expect(validateMaxMinExcInc).toHaveBeenCalled();
    });

    it("should test checkGreaterOrEqual method ", async () => {
        const checkGreaterOrEqual = jest.spyOn(wrapper.vm, "checkGreaterOrEqual");
        await checkGreaterOrEqual(1, 2);
        await checkGreaterOrEqual(1, 1);
        expect(checkGreaterOrEqual).toHaveBeenCalled();
    });

    it("should test validateMaxMinLength method ", async () => {
        const validateMaxMinLength = jest.spyOn(wrapper.vm, "validateMaxMinLength");
        let MNL1 = {"facets":[{"facetType":"Maximum length", "facetValue":"e"}]};
        await validateMaxMinLength(0, MNL1);
        let MNL2 = {"facets":[{"facetType":"Minimum length", "facetValue":"e"}]};
        await validateMaxMinLength(0, MNL2);
        let MNL3 = {"facets":[{"facetType":"Length","facetValue":"e"}]};
        await validateMaxMinLength(0, MNL3);
        let MNL4 = {"facets":[{"facetType":"Pattern","facetValue":"e"}]};
        await validateMaxMinLength(0, MNL4);
        let MNL5 = {"facets":[{"facetType":"Fractions","facetValue":"e"}]};
        await validateMaxMinLength(0, MNL5);
        let MNL6 = {"facets":[{"facetType":"Total Digits","facetValue":"e"}]};
        await validateMaxMinLength(0, MNL6);
/*
        MNL1 = {"facets":[{"facetType":"Maximum length", "facetValue":"1"}]};
        await validateMaxMinLength(0, MNL1);
        MNL1 = {"facets":[{"facetType":"Maximum length", "facetValue":"a"}]};
        await validateMaxMinLength(0, MNL1);
        MNL2 = {"facets":[{"facetType":"Minimum length", "facetValue":"1"}]};
        await validateMaxMinLength(0, MNL2);
        MNL2 = {"facets":[{"facetType":"Minimum length", "facetValue":"a"}]};
        await validateMaxMinLength(0, MNL2);*/
        MNL3.facets[0].facetValue= "1";
        await validateMaxMinLength(0, MNL3);
        MNL3.facets[0].facetValue= "a";
        await validateMaxMinLength(0, MNL3);
        MNL1.facets[0].facetValue= "1";
        await validateMaxMinLength(0, MNL1);
        MNL1.facets[0].facetValue= "a";
        await validateMaxMinLength(0, MNL1);
        MNL2.facets[0].facetValue= "1";
        await validateMaxMinLength(0, MNL2);
        MNL2.facets[0].facetValue= "a";
        await validateMaxMinLength(0, MNL2);
        MNL4.facets[0].facetValue= "1";
        await validateMaxMinLength(0, MNL4);
        MNL4.facets[0].facetValue= "a";
        await validateMaxMinLength(0, MNL4);
        /*MNL4 = {"facets":[{"facetType":"Pattern","facetValue":"1"}]};
        await validateMaxMinLength(0, MNL4);
        MNL4 = {"facets":[{"facetType":"Pattern","facetValue":"a"}]};
        await validateMaxMinLength(0, MNL4);*/
/*
        MNL3.facets[0].facetValue= "";
        await validateMaxMinLength(0, MNL3);
        MNL2.facets[0].facetValue= "";
        await validateMaxMinLength(0, MNL2);
        MNL1.facets[0].facetValue= "";
        await validateMaxMinLength(0, MNL1);*/

        expect(validateMaxMinLength).toHaveBeenCalled();
    });





});