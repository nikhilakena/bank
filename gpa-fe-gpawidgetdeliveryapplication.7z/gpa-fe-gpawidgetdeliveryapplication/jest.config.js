module.exports = {
  preset: '@vue/cli-plugin-unit-jest',
  silent:true,
  roots: [
    '<rootDir>/src/',
    '<rootDir>/tests/'
  ],
  moduleFileExtensions: ['js', 'json', 'vue', 'ts'],
  transform: {
    '^.+\\.vue$': 'vue-jest',
    '.+\\.(css|styl|less|sass|scss|svg|png|jpg|ttf|woff|woff2)$':
      'jest-transform-stub',
    '^.+\\.ts$': 'ts-jest'
  },
  // transformIgnorePatterns: ['/node_modules/'],
  transformIgnorePatterns: [
    '<rootDir>/node_modules/(?!(@aab|@open-wc|lit-html|lit-element|chai-a11y-axe)/)',
  ],
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1'
  },
  snapshotSerializers: ['jest-serializer-vue'],
  testURL: 'http://localhost/',
  testMatch: [
    '<rootDir>/tests/unit/*.spec.js'
  ],
  collectCoverage: true,
  collectCoverageFrom: ['<rootDir>/src/**/*.{vue,js}',
    '!src/api.js',
    '!src/i18n.js',
    '!src/main.js',
    '!src/gateways/*.js',
    '!src/generic/**/*.js',
    '!src/plugins/*.js',
    '!src/services/ErrorServices.js'],
  coverageReporters: ['json', 'lcov', 'text', 'clover', 'html', 'cobertura'],
  coverageDirectory: 'tests/unit/coverage'
};
