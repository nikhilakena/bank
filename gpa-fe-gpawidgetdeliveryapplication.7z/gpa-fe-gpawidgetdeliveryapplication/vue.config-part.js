// eslint-disable-next-line no-unused-vars
let title;
try {
  ({ title } = require('./src/locales/nl.json'));
  title = title || {};
} catch (ex) {
  title = {};
}
// This pattern should only apply to web-components
// sc-aab-* added to exclude cases like sc-vue-*
const aabWebComponentsFolder = /node_modules[/\\]@aab[/\\]sc-aab-/;
module.exports = {
  extraConfigureWebpack: {
    // For easier local development with symlinked node-modules
    resolve: { symlinks: false },
    // enable sass for webcomponents when bundling up
    module: {
      rules: [{
        test: /\.scss$/,
        include: aabWebComponentsFolder,
        use: [{
          loader: 'lit-scss-loader',
          options: {
            minify: true,
          },
        }, 'extract-loader', 'css-loader', 'sass-loader'],
      }],
    },
    externals: [
      'canvas',
    ],
  },
  chainWebpack: (webpackConfig) => {
    webpackConfig
    .plugin('html')
    .tap((args) => {
      args[0].appName = args[0].title;
      args[0].title = title.long || args[0].title;
      return args;
    });
    webpackConfig.module.rule('scss')
    .exclude.add(aabWebComponentsFolder);
  },
};
